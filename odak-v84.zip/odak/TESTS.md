# Testler

Çalıştırma (GitHub Actions bunu her derlemeden önce otomatik yapar):

    gradle testDebugUnitTest --no-daemon

## Ne test ediliyor

| Dosya | Kapsam |
|---|---|
| `PureLogicTest` | Kural eşleştirme (+istisna), sessiz saat, süre limiti/uyarı eşiği, saat çevirme, emoji etiketi, alışkanlık serisi |
| `RulesFileTest` | `block_rules.json` ↔ katalog tutarlılığı; her özelliğin kuralı var mı; çok genel parça yok mu |
| `CatalogSourceTest` | Uygulama kataloğu: tekrarlı id/paket, geçersiz paket adı, ≥65 uygulama, büyük uygulamaların özellik sayısı |
| `ResourcesTest` | 8 dilde aynı anahtarlar, boş çeviri, `%d` yer tutucuları, kodda kullanılan her `R.string` tanımlı mı, manifest sınıfları, ses dosyaları |

## Kural: her yeni şeyde test ekle

1. Yeni mantık → `logic/Pure.kt` içine koy, `PureLogicTest`'e en az bir olumlu, bir olumsuz, bir sınır durumu testi yaz.
2. Yeni uygulama / özellik → kataloğa ekle **ve** `block_rules.json`'a kural yaz (aksi halde `everyFeatureHasARule` kırılır).
3. Yeni metin → 8 dilde de ekle (aksi halde `everyLanguageHasSameKeys` kırılır).
4. Yeni tasarım → 4 ses dosyası ekle (`everySoundResourceExistsForEveryDesign`).
5. Yeni sınıf (servis/alıcı) → manifest'e ekle (`manifestClassesExist`).

## Kural doğrulama durumu

`block_rules.json` içindeki `_verified` listesi, açık kaynak projelerde (short-video-rules, Scrollhalt) belgelenmiş
kimliklerle uyuşan kuralları gösterir. Listede olmayanlar tahmindir; yanlış çıkarsa "Ekran kimliklerini kaydet" ile
gerçek kimlikleri toplayıp düzeltin.

## v0.36 eklenenler
- Snap eşleşmesi (`desc:` / `text:` / kimlik, istisna, boş önek), `Pure.derive` (Kural Lab türetme), `Pure.topSlices`, `Pure.pctChange` — PureLogicTest.
- Yeni stringler (rl_*, st_unlocks/st_avg/st_other) ResourcesTest ile 9 dilde doğrulanır.
- Elle: Kural Lab (🎯) ile bir bölümü kaydet; user_rules.json oluşur ve engelleme çalışır.

## v0.37
- staleDayKey (günlük anahtar temizliği) PureLogicTest; ManifestTest (alarm yeniden kurma eylemleri, servis izinleri).

## v0.38
- Katalog >=135 uygulama; Pure.nameMatches (arama).

## v0.39
- Katalog >=190 uygulama (paketler Play Store ile doğrulandı).
- 20 yeni özellik: Pure.nightMs/perUnlockMs/barFractions/pct/todoOrder/isOverdue/moveOverdue/parseQuickDue/weekRate/bestStreak/waterFraction/overlaps/conflictIndexes/freeSlot/totalPlanned/fmtDur/summaryText testli.

## v0.40
- Pure.niceStepMin/axisMaxMs/slicePct (grafik ekseni) testli.

## v0.41
- Pure.isLandscape (yatay düzen eşiği), ManifestTest: MainActivity configChanges (dönünce yeniden oluşturulmaz, yön kilitli değil).
- Elle dene: telefonu yan çevir; yan şerit, Ekran Süresi iki sütun, Görev/Engel/Ayar 720dp ortalı.

## v0.42
- Pure.winClass/useRail/contentMaxDp/pomoLeftMs, ManifestTest: resizeableActivity, alarm/boot izinleri.
- Elle dene: çok pencere/katlanır/tablet; Pomodoro başlat, uygulamayı kapat, bildirimin geldiğini ve sayacın doğru devam ettiğini gör.

## v0.44 — Özel bildirim/uyarı metinleri
- PureLogicTest.fillTplReplacesPlaceholders / msgOrDefaultFallsBack
- MsgsSourceTest (her tür bağlı + tüm dillerde etiket)

## v0.45 — +334 test (BulkLogicTest)
Tablo tabanlı: parseTime/fmtTime/inQuiet, autoScale/effectiveScale, pct/slicePct/perUnlock/nightMs/barFractions, winClass/useRail/isLandscape/contentMaxDp, niceStep/axisMax, fmtDur/totalPlanned/overlaps/freeSlot, nameMatches/fillTpl/msgOrDefault, waterFraction, inWarnWindow/limitReached, staleDayKey, pomoLeft, pctChange, streak; 9 dil dosyası × 5 kontrol. Toplam 414 test.

## v0.46 — +323 test (AppIntegrityTest)
- Katalogdaki her uygulama için ayrı test (ad, geçerli paket adı, kendi paketimiz değil) — 194 test
- Her Kotlin kaynak dosyası için 3 test: paket adı yolla uyumlu, parantez/süslü parantez dengeli (yorum ve dizgeler çıkarılarak), kalıntı println/TODO/printStackTrace yok — 129 test

## v0.47 — Hata avı düzeltmeleri (BugFixTest)
- Sessiz saat: gece yarısını aşan aralıkta sabah saatleri bir önceki günün seçimine bağlı (quietActive)
- Ekran süresi: aynı uygulamada etkinlik geçişi yeni "açılış" sayılmaz; hâlâ açık uygulamanın süresi aralık sonuna kadar eklenir
- Özellik süre sınırı: uygulamadan ayrılıp dönünce haksız +3 sn eklenmez (featDelta)

## v0.48 — Tam yedek v2 (BackupTest)
- Yedek artık engel ayarları, renkler, özel metinler, ölçek vb. tüm tercihleri içerir; PIN dahil edilmez
- İçe aktarma önce doğrular (tür, dosya izin listesi, JSON dizisi), sonra yazar; hatalı dosyada hiçbir şey değişmez
- Dışa/içe aktarma hataları artık çökmez, ✗ gösterir

## v0.49 — Bildirim eylemi (NotifActionsTest)
- Plan hatırlatma bildirimine "Tamamlandı" düğmesi (planı bildirimden bitirir, pencere öğesi yenilenir)
- Sabah özetinde geciken görev sayısı (⚠ n) ve {overdue} yer tutucusu

## v0.50 — Belgeler okuyucusu (DocParseTest, DocUiSourceTest)
- Okunan biçimler: PDF (Android PdfRenderer), docx/dotx/docm, pptx/potx/ppsx/pptm, xlsx/xlsm, vsdx, odt/odp/ods/odg/odf, rtf, txt/csv/md, Google (.gdoc/.gsheet/.gslides/.gform → bağlantı), eski ikili (doc/ppt/xls/wps/dps/et → kaba metin), pub/one/odb → yalnızca "başka uygulamada aç"
- Gerçek zip/XML üretilerek 61 ayrıştırma testi; XXE/DOCTYPE, bozuk dosya, boş girdi, 40 MB sınırı sınanır
- "Başka uygulamada aç" ve VIEW filtresi (dosya yöneticisinden Odak ile aç)

## v0.51 — Eski biçimler, Publisher, OneNote, Base (OleDocTest)
- docs/OleDoc.kt: OLE/CFB okuyucu; .doc (parça tablosuyla birebir metin), .xls (SST+CONTINUE, sayı/RK/formül önbelleği/mantık), .ppt (slayt metinleri). WPS (.wps/.et/.dps) aynı yapıyı kullanır
- Gerçek LibreOffice dosyaları src/test/fixtures/ içinde (fx.doc, fx.xls, fx.ppt); Türkçe karakter, tablo, 2500 satırlık CONTINUE kaydı sınanır
- .pub: Quill/Contents akışından kaba metin; .one: UTF-16 kaba metin (gerçek dosyayla SINANMADI)
- .odb: HSQLDB betiğinden tablo ve satırlar (gerçek .odb ile SINANMADI; satırlar ikili dosyada tutulmuşsa yalnızca tablo yapısı görünür)

## v0.52 — sağlamlaştırma ve toplu testler
Düzeltmeler:
- `Pure.fillTpl`: tek geçişli doldurma (bir değerin içindeki `{x}` yeniden doldurulmaz); 200 karakter sınırı vekil çiftini bölmez.
- `DocParse.safeGoogleUrl`: ters eğik çizgi, boşluk, `@` (kullanıcı bilgisi) ve geçersiz karakterli adresler reddedilir; alan adı küçük harfe çevrilir.

Yeni test dosyaları (4533 test, beklenen değerler bağımsız Python hesabından):
- ScaleGenTest (318): autoScale / effectiveScale ızgarası
- QuietGenTest (2240): sessiz saat + gün maskesi (gece yarısını aşan aralıklar dahil)
- TplGenTest (175): bildirim şablonları, varsayılan metin, uzunluk sınırı
- OpenFeatGenTest (135): isNewOpen / featDelta
- BackupGenTest (25): yedek dosya izin listesi, JSON dizisi ön kontrolü
- DocGenTest (1640): uzantı/imza tespiti, colIndex, Google adres güvenliği, son açılanlar

Sandbox toplamı: 5403 geçti, 0 kalan. Cihazda çalıştırılmadı.

## v0.53 — özellik süresi dolunca ana sayfaya dön
- `Pure.isHomeLabel`, `Pure.featExit`: ana sayfa sekmesi etiketleri (8 dil) ve çıkış kararı (ayar açık + en çok 2 deneme → ana sekme, aksi halde geri tuşu).
- Servis: süre/engel dolunca önce ana sayfa sekmesine tıklar; bulamazsa geri tuşuna düşer. Özellik ekrandan çıkınca deneme sayacı sıfırlanır.
- Ayar: Uyarılar ekranında "Özelliğin süresi bitince uygulamada kal, ana sayfaya dön" (varsayılan açık).
- HomeExitTest (51): etiketler, karar tablosu, kaynak bağlantıları, 9 dilde metin.
Sandbox toplamı: 5454 geçti, 0 kalan. Cihazda çalıştırılmadı.

## v0.54 — Not defteri (Samsung Notes tarzı) + belge okuyucu birleşik
Yeni: `notes/` (NotePure, NoteStore, NoteEditor, NotesList, NotesActivity). Ayarlar → Not defteri; iki sekme: Notlar / Belgeler (belge okuyucu burada).
- Notlar: başlık + metin, yapılacak maddeleri (☐/☑), el yazısı (kalem, fosforlu, kurşun kalem, silgi, geri al/yinele, 6 mürekkep rengi, 3 kalınlık, kaydırma aracı), 4 kâğıt türü (düz/çizgili/kareli/noktalı), not rengi, sabitleme, klasör, arama, PIN ile kilit, 30 gün çöp kutusu, metin olarak paylaşma, otomatik kaydetme.
- Saklama: her not ayrı dosya (`files/notes/<id>.odn`), atomik yazma, bozuk dosya yalnızca kendini etkiler.
Testler: NotePureTest (55, el yazımı), NoteGenTest (1905: 800 gidiş-dönüş/özellik testi rastgele notlarla + Python hesaplı tablolar).
Sandbox toplamı: 7413 geçti. Compose ekranları yalnızca sözdizimi denetiminden geçti; cihazda ve derlemede denenmedi.

## v0.55 — Not defteri: kalem basıncı, resim, ses kaydı, PDF üstüne yazma, resim/PDF paylaşma
- Kalem basıncı: yalnızca kalemle (stylus) gelen basınç kaydedilir (`Pt.p`); çizgi kalınlığı `pressW` ile %35–%100 arası değişir. Parmakta ve fosforlu kalemde sabit.
- Resim: galeriden seç, 1600 px'e küçült, sayfada taşı/büyüt/küçült/sil (✥ aracı).
- Ses kaydı: mikrofon izni istenir, m4a (AAC), en çok 1 saat, listeden dinle/sil.
- PDF üstüne yazma: PDF uygulama klasörüne kopyalanır (en çok 100 MB, doğrulanır), sayfalar tembel çizilir; çizgiler sayfa yerleşimine göre saklanır; "PDF olarak paylaş" çizimlerle yeni PDF üretir.
- Resim olarak paylaş: not (kâğıt+resim+çizim) PNG; FileProvider yalnızca cache/share.
- Güvenlik: dosya adları `safeFile` ile doğrulanır (yol kaçışı yok), kalıcı silmede ekler de silinir.
Testler: NoteMediaTest (27), NoteMediaGenTest (1162: gidiş-dönüş, basınç, fitSize, süre, PDF yerleşimi, resim taşıma/ölçekleme, dosya adı), NoteMediaSourceTest (15).
Sandbox toplamı: 8618 geçti, 0 kalan. Compose/Android kodu (kayıt, PDF, paylaşım) yalnızca sözdizimi denetiminden geçti; cihazda denenmedi.

## v0.56 — Atlas + dosya dönüştürme
- Uygulama adı **Atlas** (9 dilde app_name ve görünen metinler; gradle kök adı, APK artifact adı). Sınıf/paket adları değişmedi.
- Dönüştürme: TXT, MD, HTML, CSV, RTF, DOCX, XLSX, PPTX, ODT, ODS, ODP, PDF; PDF kaynak → sayfa PNG'leri (zip). Yalnızca metin ve tablolar taşınır; düzen, resim, biçim taşınmaz. PDF'ten metin çıkarılamaz. Google/okunamayan dosyalar dönüştürülemez.
- Yazıcılar saf Kotlin (`DocWrite`), PDF Android `PdfDocument` ile (`DocPdf`). Kaydetme: sistem "Farklı kaydet" penceresi.
- Doğrulama: python-docx/openpyxl/python-pptx/LibreOffice ile açıldı.
Testler: DocWriteTest (64), DocWriteGenTest (4: 60 rastgele belge × 8 biçim gidiş-dönüş, XML geçerliliği, kontrol karakterleri).
Sandbox toplamı: 8686 geçti, 0 kalan. ConvertBar/DocPdf cihazda denenmedi.

## v0.56.1 — PDF → tüm biçimler, büyük dosya
- PDF'ten yazı çıkarılır (pdfbox-android, geçici dosya modu) ve TXT/MD/HTML/CSV/RTF/DOCX/XLSX/PPTX/ODT/ODS/ODP'ye çevrilir; PNG zip de durur. Taranmış (resim) PDF'te yazı yoktur → "taranmış olabilir" uyarısı (OCR yok).
- Sınırlar: PDF açma/dönüştürme boyut sınırsız (dosyadan akıtılır). Diğer belgeler bellekte okunur: 40 → 256 MB, `largeHeap` açık. 2 GB bellekte mümkün değil.
Testler: DocWriteTest +8 (toplam 72), DocParseTest sınır testi küçük tavanla. Sandbox toplamı: 8694 geçti, 0 kalan. pdfbox ve arayüz cihazda denenmedi.

## v0.56.2 — 3 GB+ dosya
- Belge 32 MB üstündeyse bellekte tutulmaz: /proc/self/fd üzerinden (kopyasız) ya da cache'e akıtılarak açılır; DOCX/XLSX/PPTX/ODF için `ZipFile` (ZIP64, rastgele erişim) ile yalnız XML parçaları okunur, resim/medya hiç açılmaz. Gerçek denemede 3,3 GB'lık DOCX 128 MB yığınla 39 ms'de açıldı.
- Düz metin 256 MB üstünde: ilk 64 MB okunur, "eksik olabilir" uyarısı. Eski OLE (DOC/XLS/PPT) 256 MB'a kadar. PDF sınırsız.
- XML girdisi 128 MB üstündeyse reddedilir (zip bombası koruması).
Testler: DocBigFileTest (11). Sandbox toplamı: 8705 geçti, 0 kalan. Telefonda denenmedi (fd yolu sağlayıcıya göre değişebilir).

## v0.56.3 — büyük dosyada resim, grafik, diyagram; çok büyük düz metin
- Belgedeki **resimler** (DOCX/PPTX/XLSX/ODF) yalnız ekrana gelince, küçültülerek (örnekleme) zip'ten okunur; dokununca tam ekran/yakınlaştırma. Büyük dosyada ZipFile oturum boyunca açık kalır. Android'in çözemediği biçimler (EMF/WMF/SVG/TIFF) için uyarı gösterilir.
- **Grafikler** (çubuk, yatay çubuk*, çizgi, alan, pasta/halka, dağılım) hem OOXML (DOCX/PPTX/XLSX) hem ODF (ODS/ODT/ODP) için veriden çizilir; dokununca veri tablosu. (*yatay çubuk şimdilik dikey çizilir.) Grafikte kayıtlı (önbellek) veri yoksa gösterilemez.
- **Diyagramlar**: SmartArt (kayıtlı çizim) ve Visio (.vsdx) şekilleri/bağlantıları kutu-çizgi olarak çizilir. Slayt şekilleri, çizim tuvalleri, formül nesneleri çizilmez.
- Resim/grafik/diyagram sayfa metninden sonra gösterilir (metin içindeki yerine değil). Arama yaparken gizlenir.
- 256 MB üstü **düz metin** (GB'lar): 1 MB'lık pencereler, sürgü, ◀ ▶, dosya içinde arama; tamamı belleğe alınmaz. UTF-8 varsayılır.
Testler: DocVisualTest (64), DocVisualGenTest (5: 300 rastgele grafik gidiş-dönüş, aralık/pasta özellikleri, Visio, yol çözümü), BigTextTest (21: pencere örtüşmesiz tam kapsama, çok baytlı karakter, 3 GB üstü ofset, parça sınırında arama).
Sandbox toplamı: 8795 geçti, 0 kalan. Gerçek DOCX/PPTX/XLSX (python-docx/pptx/openpyxl) ve LibreOffice ODF dosyalarıyla doğrulandı. Compose çizimleri (ImageBlock/ChartBlock/DiagramBlock/BigTextView) cihazda denenmedi.

## v0.56.4 — Kodlama doğrulama, TIFF / EMF / WMF / SVG
- BigTextTest (36): BOM, UTF-16 (BOM'suz dahil), UTF-8 geçerlilik örneklemesi (baş/orta/son), Windows-1254 geri dönüşü, pencere/arama kodlamaya duyarlı.
- TiffDecoderTest (10): PIL/ImageMagick ile piksel-piksel eşleşen gerçek TIFF'ler (sıkıştırmasız, PackBits, LZW, Deflate, paletli, 16-bit, RGBA).
- MetafileTest (~50): LibreOffice'in ürettiği gerçek EMF/WMF dosyaları (şekil, renk, metin, bitmap yönü), elle üretilmiş kayıtlar (eşleme modları, pencere başlangıcı, dünya dönüşümü, yollar, ARCTO, DIB 1/4/8/24/32, STRETCHDIBITS, WMF kayıtları), bozuk/kesik girdi asla hata fırlatmaz (fuzz).
- Düzeltilen hata: 16-bit çokgen/çizgi kayıtlarında y koordinatı yanlış ofsetten okunuyordu.
- DocVisualTest: imageKind (bitmap/tiff/meta/svg), isDecodable güncellendi; kaynak denetimleri: decodeSampled yönlendirmesi, androidsvg bağımlılığı.
- Doğrulanmadı: MetaRender/SvgRender (Android çizimi) yalnızca sözdizimi denetimli.

## v0.56.5 — TIFF (CCITT, JPEG, BigTIFF) ve EMF/WMF eklentileri
- TiffExtTest (13): libtiff/ImageMagick/PIL ile üretilmiş gerçek dosyalar — CCITT MH, Group 3 (1B ve 2B), Group 4 (şeritli, uzun >2560 koşular) piksel-piksel; BigTIFF (ham, LZW, döşemeli, şeritli, G4); JPEG-içi-TIFF (şerit, döşeme, gri; ImageIO ile çözülüp referansa yakınlık); çözücüsüz null, çözücü hata fırlatırsa çökmez, bozuk/kesik girdi (fuzz), Ccitt doğrudan (G4, 1B, çöp veri, saçma boyut).
- MetafileExtTest (~60): RLE8/RLE4 (mutlak, delta, bozuk); kırpma (INTERSECT/EXCLUDE rect, yol, bölge, WMF) ve Save/Restore; desenli fırçalar (tarama, DIB, mono, WMF); GRADIENTFILL; çizgi stilleri; EMF+ (yalnız-EMF+ ve dual ayrımı, dolgu/çizim kayıtları, yol nesneleri, bezier/eğriler, dünya/sayfa dönüşümü, Save/Restore, kırpma, doğrusal gradyan, tarama fırçası, DrawString, resim: piksel/kırpma/sıkıştırılmış, parçalı nesne, fuzz); LibreOffice EMF'inde kırpma/Save dengesi.
- Düzeltme: TIFF CCITT'de siyah koşu = bit 1 (libtiff ile aynı), fotometrik yorumu sonra uygulanır.
- Doğrulanmadı: Android çizim kodu (MetaRender: kırpma, BitmapShader, LinearGradient, DashPathEffect, Img) yalnız sözdizimi denetimli; EMF+ gerçek Windows çıktısıyla değil, şartnameye göre üretilen kayıtlarla test edildi.

## v0.56.6 — Uygulama listesi ve uygulama içi özellik engelleme
- BlockExtTest (19): `sel:` kuralı (alt çubukta SEÇİLİ sekme etiketi; seçili olmayan eşleşmez, büyük/küçük harf, istisnayla birlikte, eski Snap kurucuları), `Pure.deriveSel` (RuleLab artık seçili sekmeden de kural öğretir), katalog ≥ 290 uygulama (105 yeni), yeni özellikler (LinkedIn video/iş ilanları, Netflix oyunlar), kural dosyasında çok dilli sekme etiketleri, doğrulanmış kuralların korunması, servis kaynak denetimi, yeni metinler 8 dilde.
- Doğrulanmadı: `sel:` etiketleri ve yeni uygulama paket adları cihazda denenmedi (etiketler uygulamanın dil/sürümüne göre değişebilir; tutmazsa "Kural öğret" ile düzeltilir).

## v0.56.7 — Skeuomorphism, Neumorphism, Glassmorphism tasarımları
- NewStylesTest (27): enum kaydı (9 tasarım, benzersiz ad/anahtar, taban renkleri); her `when (DesignStyle)` bloğunun (else yoksa) 9 tasarımı da kapsaması (tarayıcı yanlış-pozitif/negatif kendini de sınar); 12 yeni WAV (tap/success/delete/notify × 3) mono PCM16, süre aralıkları, kırpma yok / duyulabilir, tıksız başlangıç-bitiş, hepsi birbirinden ve eski tasarımların seslerinden farklı; WCAG kontrastı: Neumorphism metin ≥ 7:1, vurgu ≥ 4.5:1; Skeuomorphism metin ≥ 7:1 (masa + kâğıt), deri düğme yazısı ≥ 4.5:1; Glassmorphism beyaz metin her küre × her gradyan durağı × cam panel en açık köşesinde ≥ 4.5:1; kaynak denetimi: çift gölge + inset, doku/parlama/kabartma kenar, cam kenar/ışık süpürmesi/bulanık küreler, PressFx'te üç ayrı tepki, hareket/şekil/geçiş fonksiyonlarında üç dal, bileşenlerde dallar, plan ekranı yönlendirmesi, bildirim kanalı (tasarıma özel ses) ve eski tasarımların eski kanalda kalması, durum çubuğu rengi, kayıtlı tasarım adı uyumu.
- Doğrulanmadı: çizimler (gölgeler, doku, cam, animasyonlar), plan ekranları ve bildirim kanalı sesi cihazda görülmedi; GitHub Actions derlemesi bekleniyor. Cam panellerin arkası gerçek "arka plan bulanıklığı" değil; arkadaki renkli küreler bulanıktır, paneller yarı saydamdır. Sesler sentezlenmiştir (gerçek kayıt değil).

## v0.56.8 — Y2K, Aurora UI, Claymorphism, Dark Mode tasarımları
- NewStyles2Test (18): enum 13 tasarım ve yeni anahtarlar, taban renkleri; 16 yeni WAV (mono PCM16, süre aralıkları, kırpma yok, tıksız başlangıç/bitiş) ve 13 tasarım × 4 sesin hepsinin birbirinden farklı olması; WCAG kontrastı: Y2K metin ≥ 7:1 (aqua/lavanta/pembe/yüzey), vurgu ve jel düğme yazısı ≥ 4.5:1; Clay metin ≥ 7:1 tüm pastellerde (doymuş lavanta ≥ 4.5), mercan düğme + koyu yazı ≥ 4.5:1, ClayInk ≥ 4.5:1; Dark #121212 (saf siyah/saf beyaz değil), metin ≥ 7:1, vurgu ≥ 4.5:1, yükseklik formülü; Aurora beyaz metin her bulut × örtü × panelde ≥ 4.5:1, düğme yazısı ≥ 4.5:1; araştırılan gölge/degrade tariflerinin kaynakta bulunması; PressFx'te dört ayrı tepki; hareket/şekil/geçiş dalları; bileşen/gezinme/seçici/başlık dalları; plan ekranı yönlendirmesi; koyu/açık durum çubuğu; bildirim kanalı kapsamı; arka plan katmanları.
- NewStylesTest güncellendi (13 tasarım); `when (DesignStyle)` kapsam denetimi artık 13 tasarımı da zorunlu kılıyor.
- Doğrulanmadı: çizimler, animasyonlar, plan ekranları ve kanal sesleri cihazda görülmedi; GitHub Actions derlemesi bekleniyor. Claymorphism yuvarlak sans yazı tipi sistemde yok, varsayılan sans kullanılır. Sesler sentezlenmiştir.

## v0.56.9 — Cosmic Dark, Sci-Fi HUD, Cyber-Industrial, Neoclassical tasarımları
- NewStyles3Test (17): enum 17 tasarım ve yeni anahtarlar, taban renkleri; 16 yeni WAV (mono PCM16, süre aralıkları, kırpma yok, tıksız başlangıç/bitiş) ve hepsinin birbirinden farklı olması; WCAG kontrastı: Cosmic metin her nebula bulutu × örtü üzerinde ≥ 4.5:1, yüzey ≥ 7:1, lavanta düğme koyu yazı ≥ 7:1; HUD amber/camgöbeği ≥ 7:1, bugün hücresi ≥ 7:1; Cyber sarı plaka + siyah yazı ≥ 7:1, çelik üstü metin ≥ 7:1; Neoklasik mürekkep/fildişi ≥ 7:1, koyu altın ≥ 4.5:1, bugün hücresi ≥ 6.5:1; yardımcı çizim fonksiyonlarının ve nebula blur'unun kaynakta bulunması; PressFx'te dört ayrı tepki (warp halkaları, kilitlenme, piston inişi, yükselen altın); hareket/şekil/geçiş dalları; bileşen/gezinme/seçici/başlık dalları ve NewLookStyles kapsamı; plan ekranı yönlendirmesi ve 4 ızgara görünümü; bildirim kanalı, durum çubuğu ve koyu-doğal tasarım listesi; Roma rakamı kuralı.
- NewStylesTest ve NewStyles2Test güncellendi (17 tasarım; 17 × 4 ses).
- Doğrulanmadı: çizimler, animasyonlar (yıldız alanı, radar taraması), plan ekranları ve kanal sesleri cihazda görülmedi; GitHub Actions derlemesi bekleniyor. Sürekli animasyonlar pil tüketir. Sesler sentezlenmiştir.

## v0.56.10 — Ekran süresi / engelleme: odak modunu uzatma
- FocusExtendTest (5): süren odak modu mevcut bitişten uzar; süresi dolmuş olan şimdiden uzar; varsayılan adım 10 dk; bitiş asla geriye gitmez; `focus_extend` ve `focus_ends` dizgileri 9 dilde var; BlockScreen'de uzat düğmesi ve bitiş saati bağlı, bildirim yeniden kuruluyor.
- Doğrulanmadı: düğmenin ve bitiş saatinin cihazda görünümü, bildirimin yeni saatte çalışması; GitHub Actions derlemesi bekleniyor. "Uzat" çevirisi DeepL'den geldi; Azerbaycanca "Uzadın" (geçmiş zaman) bir yazım kontrolü ister.

## v0.56.11 — Ekran süresi / engelleme: günlük sınır uyarısı
- LimitRowTest (4): sınıra tam ulaşınca ve aşınca uyarı, altındayken yok, 0 = sınırsız asla uyarmaz; LimitRow'da uyarının hem renk hem ✖ işaretiyle gösterildiği kaynak denetimi.
- Doğrulanmadı: kırmızı metin ve ✖ işaretinin cihazda görünümü; GitHub Actions derlemesi bekleniyor.

## v0.56.12 — Ekran süresi: günlük hedef kartında kullanım/hedef gösterimi
- GoalCardTest (1): hedef kartı "kullanılan / hedef" biçiminde gösterir; hedef aşılınca ✖ işareti ve hata rengi; hedef 0 iken uyarı yok.
- Doğrulanmadı: görünüm cihazda kontrol edilmedi; GitHub Actions derlemesi bekleniyor.
- Bilinen sınır: seri (🔥) sayacı yalnızca son 7 güne bakıyor; uzun seriler 6 günde kesilir. Düzeltmek için geçmiş verisinin daha uzun okunması gerekir; bu sürümde değişmedi.

## v0.56.13 — Ekran süresi: hedef serisi (🔥) tüm geçmişe bakıyor
- Düzeltilen sorun: seri sayacı en fazla 13 gün geriye bakıyordu (grafik penceresi 14 gündü). Artık 60 günlük ayrı bir geçmiş okunuyor; grafik ve gün gezgini eskisi gibi 14 günde kalıyor.
- Yeni `Pure.goalStreak` (saf mantık): bugün sayılmaz, eşitlik hedefin altında sayılır, ilk aşan gün seriyi keser, hedef 0 iken seri 0.
- GoalStreakTest (9): boş geçmiş, sıfır hedef, tüm günler altında, bugün aşılsa da seri korunur, geriye yürürken ilk aşımda kesilme, tam hedef eşitliği, 60 gün sınırı, ekran kodunun yeni yolu kullandığının kaynak denetimi.
- Doğrulanmadı: 60 günlük okuma IO iş parçacığında ~60 sorgu yapar; cihazda gecikme ölçülmedi. Veri olmayan günler (uygulama izni kapalıyken veya telefon kapalıyken) 0 sayılır ve seriyi uzatır; bu eski davranıştır, değişmedi.

## v0.56.14 — Ekran süresi / engelleme: sessiz saatler
- Sessiz saat kartına anlık durum satırı eklendi: "Şu an sessiz saat aktif", "Şu an sessiz saat dışında" ya da başlangıç ve bitiş aynıysa kırmızı "aralık kapalı" uyarısı. Mantık `Pure.quietState` içinde (OFF / SAME_TIMES / ACTIVE / IDLE).
- Saat ayarı 30 dk yerine 15 dk adımla değişiyor; `Pure.stepTime` 24 saate sarıyor (23:50 + 15 = 00:05, 00:00 − 15 = 23:45). 96 adım tam 24 saat eder.
- QuietStateTest (7): kapalı, aralık kapalı, gece aralığında aktif, aralık dışı / izinsiz günde beklemede, iki yöne sarma, 15 dk adım ve tam gün, 9 dilde durum dizgileri, kart bağlantısı.
- Doğrulanmadı: durum satırının ve 15 dk adımın cihazda görünümü; mevcut sessiz saat mantığı (`quietActive`) değişmedi ve önceki testleri geçiyor. GitHub Actions derlemesi bekleniyor.
- Dikkat: "Şu an sessiz saat dışında" İngilizce çevirisi DeepL'den geldi ve biraz dolambaçlı; gözden geçirilmeli.

## v0.56.15 — Ekran süresi / engelleme: uygulama arama ve seçici
- Arama artık ortak `Pure.nameMatches` ile yapılıyor (uygulama listesi ve "Kendi uygulamanı ekle" seçici). Küçük harf, Türkçe ı/i, İ (birleşik nokta dahil), ş/ğ/ü/ö/ç/â/î/û aksanları yok sayılıyor: "ışık" ↔ "isik", "İSTANBUL" ↔ "istanbul".
- Seçicide paket adıyla da arama yapılıyor (ör. "whatsapp" → com.whatsapp) ve her satırda paket adı gösteriliyor; aynı adlı uygulamalar artık ayırt edilebiliyor.
- Sonuç yoksa "Sonuç bulunamadı" gösteriliyor (9 dilde).
- AppSearchTest (9): boş sorgu, büyük/küçük harf, Türkçe harf ve aksan toleransı, İ katlaması, paket adı araması, eski iki parametreli çağrının çalışması, seçici ve arama bağlantısının kaynak denetimi, dizgilerin 9 dilde varlığı.
- Doğrulanmadı: seçicinin iki satırlı düğme görünümü ve uzun paket adlarının kesilmesi cihazda kontrol edilmedi; GitHub Actions derlemesi bekleniyor.

## v0.56.16 — Ekran süresi / engelleme: PIN özeti güçlendirildi
- Sorun: PIN, tek turlu SHA-256 (tuz + PIN) ile saklanıyordu. 4–8 haneli bir PIN bu özetle çok hızlı denenebilir.
- Yeni `logic/PinHash.kt` (saf mantık): yeni PIN'ler PBKDF2-HMAC-SHA256, 120 000 tur, 256 bit, rastgele 16 baytlık tuzla saklanır (sürüm 2).
- Eski kayıtlar (sürüm bilgisi yok = 1) doğrulanmaya devam eder. Doğru PIN girildiğinde kayıt otomatik olarak sürüm 2'ye yükseltilir. Kullanıcının PIN'i değişmez; ekranda bir şey görünmez.
- PIN yedeklenmez kuralı ve `odak_pin` dosya adı değişmedi.
- PinHashTest (10): PBKDF2 belirleyiciliği ve 64 hex uzunluğu, PIN/tuz değişince özet değişimi, tur sayısı ≥ 100 000, eski özetin korunması, sürüme göre doğrulama, yükseltme kuralı, rastgele tuz, Pin.kt kaynak denetimi, yedek dışı kalması.
- Doğrulanmadı: cihazda PIN ayarlama, girme ve eski PIN ile yükseltmenin gerçekten çalıştığı; PBKDF2 süresi (120 000 tur) düşük sınıf telefonlarda bir–iki saniye sürebilir, bu ölçülmedi. GitHub Actions derlemesi bekleniyor.

## v0.56.17 — Ekran süresi / engelleme: öğrenilen kuralları görme ve silme
- Sorun: Kural Laboratuvarı'nda öğrenilen kurallar görünmüyordu; kaydedilmiş kuralı silmenin yolu yoktu. Yeniden öğrenme ise eski kuralları sessizce üzerine yazıyordu.
- Kural laboratuvarı artık bölüm için kayıtlı kimlik sayısını gösteriyor ("Kayıtlı kural: N kimlik") ve kural oluşturulunca sayıyı yeniler.
- "Kayıtlı kuralı sil" yalnızca bölüm engelli değilken görünür: engel kapatma akışındaki bekleme süresi atlanamasın diye. Silme iki adımlı onay ister (ilk dokunuş "Emin misin?" der). Silme engeli kapatmaz; kural yoksa engel de bir şey yapmaz.
- Pure.ruleKey ile dosya anahtarı tek yerde.
- LearnedRuleTest (6): anahtar biçimi, silme düğmesinin engelliyken gizlenmesi, iki adımlı onay ve engeli kapatmama, sayının gösterilmesi ve yenilenmesi, RuleLab yardımcıları, 9 dilde dizgiler.
- Doğrulanmadı: diyalogun cihazda görünümü ve JSON okuma/yazma (org.json) gerçek cihazda denenmedi; GitHub Actions derlemesi bekleniyor.

## v0.56.18 — Ekran süresi / engelleme: bildirim gizleme
- Devam eden bildirimler (müzik, arama, konum) artık gizlenmiyor. Bunlar iptal edilemiyordu ve kontrol düğmelerini de kaybettiriyordu.
- Günlük süre sınırı dolan uygulamanın bildirimleri de gizleniyor. Önceden yalnızca tam engel, odak ve sessiz saat dikkate alınıyordu; sınır engeliyle tutarlı oldu. Kullanım izni yoksa bu kontrol atlanır.
- Karar `Pure.hideNotification` içinde (engelli && devam eden değil && geçici izin yok).
- NotifHideTest (5): karar tablosu (engelli gizlenir, engelsiz gizlenmez, devam eden korunur, geçici izinde korunur) ve servis bağlantısı kaynak denetimi.
- Doğrulanmadı: bildirim gizlemenin cihazda davranışı; sınır kontrolü her bildirimde kullanım sorgusu yapar, pil/gecikme ölçülmedi. GitHub Actions derlemesi bekleniyor.

## v0.56.19 — Belge okuma: Türkçe harf toleranslı arama, sonuç sayacı ve vurgu
- Sorun: belge araması `ignoreCase` ile yapılıyordu; "isik" "Işık"ı, "cicek" "Çiçek"i bulamıyordu. Eşleşen yerler işaretlenmiyor, toplam sonuç sayısı da gösterilmiyordu.
- `Pure.matchStarts` (saf mantık): aynı katlama kuralı uygulama aramasıyla ortak (`foldForSearch`). Sorgu boşsa eşleşme yok; örtüşmeyen eşleşmeler soldan sağa bulunur.
- Belge görünümü: paragraf ve tablo eşleşmelerini sayan "N sonuç" satırı; paragraflarda eşleşen yerler açık sarı zeminle işaretleniyor, yazı rengi koyu tutuluyor (iki temada okunur).
- Bilinen sınır: büyük İ gibi katlamanın metin uzunluğunu değiştirdiği paragraflarda vurgu konumu küçük harf üzerinden hesaplanır; bu paragraflarda aksan toleransı yoktur. Tablo satırları vurgulanmıyor (yalnızca sayılıyor ve filtreleniyor).
- DocSearchTest (9): boş sorgu, örtüşmesiz eşleşme, büyük/küçük harf, Türkçe ı/i ve aksan toleransı, İ katlaması, bulunamama, DocParse'ın ortak eşleştiriciyi kullandığı, görünümün sayaç ve vurguyu bağladığı (kaynak denetimi), 9 dilde sayaç dizgisi.
- Doğrulanmadı: vurgunun ve sayaç satırının cihazda görünümü; uzun belgede aramanın hızı ölçülmedi. GitHub Actions derlemesi bekleniyor.

## v0.56.20 — Notlar: sıralama seçimi (son değişen / oluşturulma / A-Z)
- Sorun: Not listesinde sıralama sabit "son değişen"di; `NotePure.sorted` içinde oluşturulma ve A-Z modları vardı ama hiçbir yerden seçilemiyordu. A-Z de Türkçe alfabeye uymuyordu (Ç, Ğ, ı, İ, Ş, Ö, Ü yanlış yerdeydi).
- Liste üstünde üç seçenek çipi eklendi; seçili olan "✔" ile gösteriliyor. Seçim `odak_notes` tercih dosyasında saklanıyor, uygulama kapanıp açılınca korunuyor.
- A-Z sıralaması Türkçe `Collator` ile yapılıyor (Ağaç, Çay, Ilık, Şeker, Ütü, Zeytin).
- Bilinmeyen kayıtlı değer son değişen moduna düşüyor. Sabitlenen notlar her modda en üstte.
- BackupTest: yedek dosya listesine `odak_notes` eklendi (sıralama tercihi yedeğe girer); sayı 6'dan 7'ye çıktı.
- NoteSortTest (7): üç mod, Türkçe alfabe, sabitlenenler, bilinmeyen değer, liste bağlantısı ve kalıcılık, 9 dilde dizgiler.
- Doğrulanmadı: çiplerin cihazda görünümü ve Türkçe Collator'ün Android'de JVM ile aynı sonucu vermesi (test JVM'de geçti; Android ICU farklı olabilir); GitHub Actions derlemesi bekleniyor.

## v0.56.21 — Notlar: Türkçe harf toleranslı arama
- Sorun: not araması `contains(ignoreCase = true)` kullanıyordu; "isik" "Işık"ı, "is" "İş" klasörünü (büyük İ) tutarlı bulamıyordu.
- `NotePure.matches` artık ortak `Pure.foldForSearch` ile arıyor: başlık, klasör ve gövde aynı kuralla. Kilitli notların gövdesi yine aranmaz; yalnızca başlık ve klasör.
- NoteSearchTest (6): boş sorgu, başlık/klasör/gövde kapsamı, Türkçe ı/i ve aksan toleransı, büyük İ, kilitli not kuralı, eşleşmeyen sorgu, arama bağlantısının kaynak denetimi.
- Doğrulanmadı: cihazdaki arama sonuçları ve uzun notlarda arama hızı ölçülmedi; GitHub Actions derlemesi bekleniyor. Arama hâlâ tam metin taramasıdır (indeks yok); çok büyük not koleksiyonlarında yavaşlayabilir.

## v0.56.22 — Notlar: yapılacaklar listesinde Enter ile sonraki madde
- Sorun: yapılacaklar notunda Enter yeni satırı açıyordu ama "[ ] " öneki eklenmiyordu; her madde için kullanıcının önekini elle yazması gerekiyordu. Boş maddede Enter de listeyi bitirmiyordu.
- `NotePure.enterInList` (saf mantık): Enter bir işaretli/işaretsiz maddenin içinde ya da sonunda basılırsa yeni satıra "[ ] " eklenir (kuyruk metin yeni maddeye taşınır). Boş maddede Enter, önek kaldırarak listeyi bitirir. Yapıştırma ve harf yazma olduğu gibi kalır.
- Notlar düzenleyicisi bu kuralı `onValueChange` içinde kullanıyor.
- ChecklistEnterTest (8): işaretli/işaretsiz madde sonunda Enter, düz satır, boş madde, madde ortasında Enter, ilk satır, yazma ve yapıştırma, düzenleyici bağlantısı.
- Bilinen sorunlar (bu sürümde düzeltilmedi): yapılacaklar notunda işaretli satırlar hem üstte tıklanabilir satır olarak hem de altta düzenleme alanında ham metin olarak görünüyor (çift gösterim). Enter ile imleç ortada basılırsa imlecin sona atlaması ihtimali var; cihazda kontrol edilmeli.
- Doğrulanmadı: cihazda Enter davranışı ve imleç konumu; GitHub Actions derlemesi bekleniyor.

## v0.56.23 — Notlar: paylaşılan metinde yapılacak glifleri ve temiz biçim
- Sorun: not paylaşılınca yapılacak satırları ham önekle ("[ ] süt", "[x] ekmek") gidiyordu; sondaki boş satırlar da metinle birlikte taşınıyordu.
- `NotePure.exportText`: yapılacak satırları ☐ / ☑ olarak yazılır; sondaki boşluklar atılır; başlık boşsa gövde doğrudan başlar, gövde boşsa yalnızca başlık gider.
- NoteExportTest (6): başlık+gövde birleşimi, boş başlık, boş gövde, ☐/☑ dönüşümü, sondaki boşluklar, paylaşım bağlantısı.
- Not: bu sürümde yapılacak notundaki çift gösterim sorunu (üstte satır, altta ham metin) hâlâ açık; düzenleme modeli değiştirilmeden çözülemiyor.
- Doğrulanmadı: paylaşılan metnin hedef uygulamada (ör. mesajlaşma) ☐/☑ karakterlerini gösterdiği cihazda kontrol edilmedi; GitHub Actions derlemesi bekleniyor.

## v0.56.24 — Grafikler: yatay çubuk, pasta etiket kontrastı, ekran okuyucu özeti
- Sorun: `BAR` ve `HBAR` aynı kod yolunda çizilyordu; yatay çubuk grafikler dikey sütun olarak görünüyordu. Pasta dilimi üstündeki beyaz yüzde etiketleri açık renkli dilimlerde (sarı, turuncu, yeşil) okunmuyordu. Grafik erişilebilirlik özeti taşımıyordu; ekran okuyucu yalnızca boş bir tuval görüyordu. Yatay çubuklarda kategori sayısı arttığında çubuklar çok incelip sığmıyordu.
- `VisualPure` (saf mantık, docs/DocVisual.kt): `frac` ve `barSpan` (çubuğun sıfırdan değere uzanan oranı, negatif değerler dahil), `chartHeightDp` (pasta 220, çubuk/çizgi 240, yatay çubuk kategori başına 22 dp, 240–640 arası), `contrastRatio` (WCAG) ve `labelOn` (dilim üstü için beyaz ya da koyu yazı, yüksek kontrastlı olan), `maxEntry` (erişilebilirlik için en yüksek değer), ortak `PALETTE`.
- Arayüz (docs/DocVisualUi.kt): `drawHBar` ayrı çizer: kategoriler solda (12 karakterde kısaltılır, satır yüksekliğine sığmazsa atlanır), çubuklar sıfırdan değere yatay uzanır, değer ızgarası alt eksende; aralıkta negatif değer varsa sıfır çizgisi çizilir. Pasta etiketleri `labelOn` ile renklenir. Tuval `semantics { contentDescription }` ile "Grafik. En yüksek: X (Y)." özetini okutur.
- Yeni metin: `chart_a11y` (9 dil; DeepL ile çevrildi; tr/tr-values dahil).
- DocChartTest (18): oran ve sınır durumları, çubuk aralığı (negatif dahil), yükseklikler, kontrast oranı, her palet rengi için 4.5 üstü etiket kontrastı, en yüksek değer (çoklu seri, NaN/null atlama, eksik kategori), arayüz bağlantılarının kaynak doğrulaması, 9 dilde `chart_a11y` ve iki yer tutucu.
- Sürüm: versionCode 81, versionName 0.56.24.
- Doğrulanmadı: yatay çubuğun cihazda doğru çizildiği, etiketlerin dar ekranda taşmadığı ve pasta kontrastının görsel olarak uygun olduğu cihazda kontrol edilmedi. Compose kodu yalnızca ayrıştırıldı (Android SDK yok); GitHub Actions derlemesi bekleniyor.
- Bilinen açık konu (değiştirilmedi): dikey çizgi/alan grafiklerinde eksen etiketleri yine 7 karakterde kısaltılıyor; tablo satırlarında belge içi arama vurgusu yok.

## v0.56.25 — Derleme düzeltmeleri: fr tırnak kaçışı, MainActivity dp importu
- Sorun (GitHub Actions, v81 zip'i): `values-fr/strings.xml` içinde `quiet_state_same` satırında kaçışsız tek tırnak (`l'intervalle`) AAPT'yi düşürüyordu ("Invalid unicode escape sequence"); `MainActivity.kt` içinde `.dp` kullanılıyor ama `androidx.compose.ui.unit.dp` import edilmemişti ("Unresolved reference 'dp'").
- Düzeltme: fr metninde `l\'intervalle`; `MainActivity.kt`'ye `import androidx.compose.ui.unit.dp` eklendi.
- BuildFixTest (4): tüm dillerde kaçışsız tek tırnak yok, geçersiz `\u` kaçışı yok, fr düzeltmesi yerinde, MainActivity kullandığı `dp`'yi import ediyor.
- Sürüm: versionCode 82, versionName 0.56.25.
- Doğrulanmadı: GitHub Actions derlemesi bu sürüm için henüz çalıştırılmadı. Log'da ayrıca uyarılar var (compileSdk 37 için AGP uyarısı, setup-java v4 kullanımdan kaldırma uyarısı); bunlar derlemeyi durdurmuyor.

## v0.56.26 — GitHub uyarıları: Node 24 action sürümleri ve compileSdk bastırma
- Log'daki iki uyarı: (1) setup-java@v4 kullanımdan kaldırma uyarısı, (2) checkout@v4, setup-java@v4, setup-gradle@v4 için Node 20 kullanımdan kaldırma uyarısı. Ayrıca AGP'nin compileSdk 37 için "tested up to 36.1" uyarısı vardı.
- Düzeltme: workflow'da actions/checkout@v5, actions/setup-java@v5, gradle/actions/setup-gradle@v5 (Node 24). gradle.properties içinde `android.suppressUnsupportedCompileSdk=37,37.0` (uyarının önerdiği biçim; önceki `37` değeri eşleşmiyordu). compileSdk 37 korundu.
- BuildFixTest'e 3 test eklendi: Node 24 sürümleri kullanılıyor, zip açma adımı var, compileSdk uyarısı bastırılmış.
- Sürüm: versionCode 83, versionName 0.56.26.
- Doğrulanmadı: GitHub derlemesi henüz çalıştırılmadı. v5 action sürümlerinin girdileri (gradle-version, distribution, java-version) önceki sürümle aynı kabul edildi; derleme logunda kontrol edilmeli. AGP 9.0.1 compileSdk 37'yi resmi olarak test etmiş değil; uyarı bastırıldı ama derleme sorunu çıkarsa compileSdk 36'ya dönmek gerekebilir.
