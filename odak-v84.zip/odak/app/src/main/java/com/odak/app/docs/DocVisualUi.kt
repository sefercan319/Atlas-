package com.odak.app.docs

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.odak.app.R
import com.odak.app.theme.LocalDesign
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Belge içi görseller: resim, grafik ve diyagram bileşenleri. */

/** Resmi bellek dostu biçimde çözer: PNG/JPEG/GIF/BMP/WebP/HEIC (örnekleme), TIFF (TiffDecoder), EMF/WMF (Metafile), SVG (AndroidSVG). Çözülemezse null. */
fun decodeSampled(media: MediaSource, entry: String, maxSide: Int = 2048): Bitmap? {
    val kind = DocVisual.imageKind(entry)
    if (kind == "none") return null
    val sz = media.size(entry)
    if (sz > VisualPure.MAX_IMAGE_BYTES) return null
    return try {
        when (kind) {
            "bitmap" -> {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                media.open(entry)?.use { BitmapFactory.decodeStream(it, null, o) }
                if (o.outWidth <= 0 || o.outHeight <= 0) return null
                val o2 = BitmapFactory.Options().apply { inSampleSize = VisualPure.sampleSize(o.outWidth, o.outHeight, maxSide) }
                media.open(entry)?.use { BitmapFactory.decodeStream(it, null, o2) }
            }
            "tiff" -> {
                val bytes = media.open(entry)?.use { it.readBytes() } ?: return null
                val img = TiffDecoder.decode(bytes, maxSide) { jpg ->
                    // JPEG-içi-TIFF: şerit/döşeme JPEG'lerini Android çözer
                    val bm = BitmapFactory.decodeByteArray(jpg, 0, jpg.size)
                    if (bm == null) null else {
                        val px = IntArray(bm.width * bm.height); bm.getPixels(px, 0, bm.width, 0, 0, bm.width, bm.height)
                        val r = TiffDecoder.Img(bm.width, bm.height, px); bm.recycle(); r
                    }
                } ?: return null
                Bitmap.createBitmap(img.argb, img.w, img.h, Bitmap.Config.ARGB_8888)
            }
            "meta" -> {
                val bytes = media.open(entry)?.use { it.readBytes() } ?: return null
                val m = Metafile.parse(bytes) ?: return null
                MetaRender.render(m, maxSide)
            }
            else -> {
                val bytes = media.open(entry)?.use { it.readBytes() } ?: return null
                if (bytes.size > 8 * 1024 * 1024) return null
                SvgRender.render(bytes, maxSide)
            }
        }
    } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }
}

@Composable
fun ImageBlock(media: MediaSource?, entry: String) {
    val tk = LocalDesign.current.tokens
    var bmp by remember(entry) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(entry) { mutableStateOf(false) }
    var full by remember(entry) { mutableStateOf(false) }
    LaunchedEffect(entry, media) {
        val m = media
        if (m == null) { failed = true; return@LaunchedEffect }
        val b = withContext(Dispatchers.IO) { decodeSampled(m, entry) }
        if (b == null) failed = true else bmp = b
    }
    val b = bmp
    if (b != null) {
        Image(b.asImageBitmap(), contentDescription = null, contentScale = ContentScale.FillWidth,
            modifier = Modifier.fillMaxWidth().clickable { full = true })
        if (full) ZoomDialog(b) { full = false }
    } else if (failed) {
        Text("🖼 " + stringResource(R.string.doc_img_unsupported) + " " + entry.substringAfterLast('/'),
            color = tk.text.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
    } else {
        Box(Modifier.fillMaxWidth().height(80.dp).background(tk.text.copy(alpha = 0.06f)))
    }
}

@Composable
private fun ZoomDialog(b: Bitmap, onClose: () -> Unit) {
    var scale by remember { mutableStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).clipToBounds()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 8f)
                    off = if (scale <= 1f) Offset.Zero else off + pan
                }
            }
            .clickable { if (scale <= 1.01f) onClose() }
        ) {
            Image(b.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = off.x, translationY = off.y))
        }
    }
}

private val PALETTE = VisualPure.PALETTE.map { Color(it) }

@Composable
fun ChartBlock(c: DocChart) {
    val tk = LocalDesign.current.tokens
    var table by remember(c) { mutableStateOf(false) }
    val mx = VisualPure.maxEntry(c)
    val desc = if (mx != null) stringResource(R.string.chart_a11y, mx.first, mx.second) else c.title
    Column(Modifier.fillMaxWidth()) {
        if (c.title.isNotBlank()) Text(c.title, color = tk.text, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(4.dp))
        val density = LocalDensity.current
        Canvas(Modifier.fillMaxWidth().height(VisualPure.chartHeightDp(c.kind, c.cats.size).dp)
            .semantics { contentDescription = desc }
            .clickable { table = !table }) {
            val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.argb(200, (tk.text.red * 255).toInt(), (tk.text.green * 255).toInt(), (tk.text.blue * 255).toInt()); textSize = 10f * density.density; textAlign = Paint.Align.CENTER }
            drawChart(c, txt)
        }
        // Gösterge
        val names = if (c.kind == ChartKind.PIE) c.cats else c.series.map { it.name }
        Row(Modifier.horizontalScrollSafe(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            names.take(40).forEachIndexed { i, n ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(PALETTE[i % PALETTE.size]))
                    Spacer(Modifier.width(4.dp))
                    Text(n, color = tk.text, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                }
            }
        }
        if (table) {
            Spacer(Modifier.height(4.dp))
            Column(Modifier.horizontalScrollSafe()) {
                Row { Cell(""); c.series.forEach { Cell(it.name, true) } }
                c.cats.take(60).forEachIndexed { i, cat ->
                    Row { Cell(cat); c.series.forEach { s -> Cell(s.values.getOrNull(i)?.let { DocVisual.num(it) } ?: "") } }
                }
            }
        }
    }
}

@Composable
private fun Modifier.horizontalScrollSafe(): Modifier = this.horizontalScroll(rememberScrollState())

@Composable
private fun Cell(t: String, bold: Boolean = false) {
    val tk = LocalDesign.current.tokens
    Box(Modifier.width(96.dp).border(1.dp, tk.text.copy(alpha = 0.2f)).padding(4.dp)) {
        Text(t, color = tk.text, style = MaterialTheme.typography.bodySmall, maxLines = 2)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawChart(c: DocChart, txt: Paint) {
    val padL = 40f * (txt.textSize / 10f); val padB = 26f * (txt.textSize / 10f); val padT = 8f; val padR = 8f
    val n = c.cats.size
    val axis = Color.Gray.copy(alpha = 0.6f)
    val grid = Color.Gray.copy(alpha = 0.2f)
    if (c.kind == ChartKind.PIE) {
        val sh = DocVisual.pieShares(c)
        if (sh.isEmpty()) return
        val d = minOf(size.width, size.height) - 8f
        val tl = Offset((size.width - d) / 2, (size.height - d) / 2)
        var a = -90f
        sh.forEachIndexed { i, s ->
            val sweep = (s * 360).toFloat()
            drawArc(PALETTE[i % PALETTE.size], a, sweep, true, tl, Size(d, d))
            if (s >= 0.04) {
                val mid = Math.toRadians((a + sweep / 2).toDouble())
                val r = d * 0.34f
                val lbl = txt.apply { color = VisualPure.labelOn(VisualPure.PALETTE[i % VisualPure.PALETTE.size]) }
                drawContext.canvas.nativeCanvas.drawText("${(s * 100).toInt()}%", (size.width / 2 + Math.cos(mid) * r).toFloat(), (size.height / 2 + Math.sin(mid) * r).toFloat() + txt.textSize / 3, lbl)
            }
            a += sweep
        }
        return
    }
    if (c.kind == ChartKind.HBAR) { drawHBar(c, txt); return }
    val (lo, hi) = if (c.kind == ChartKind.SCATTER) scatterRange(c) else DocVisual.range(c)
    val w = size.width - padL - padR
    val h = size.height - padT - padB
    if (w <= 0 || h <= 0) return
    fun yOf(v: Double): Float = (padT + h - ((v - lo) / (hi - lo)).toFloat() * h)
    // yatay çizgiler ve değer etiketleri
    val ticks = 4
    for (t in 0..ticks) {
        val v = lo + (hi - lo) * t / ticks
        val y = yOf(v)
        drawLine(grid, Offset(padL, y), Offset(size.width - padR, y), 1f)
        drawContext.canvas.nativeCanvas.apply { val al = txt.textAlign; txt.textAlign = Paint.Align.RIGHT; drawText(DocVisual.num(v), padL - 4f, y + txt.textSize / 3, txt); txt.textAlign = al }
    }
    drawLine(axis, Offset(padL, padT), Offset(padL, padT + h), 1.5f)
    drawLine(axis, Offset(padL, yOf(0.0.coerceIn(lo, hi))), Offset(size.width - padR, yOf(0.0.coerceIn(lo, hi))), 1.5f)
    if (n == 0) return
    val slot = w / maxOf(n, 1)
    val step = maxOf(1, Math.ceil((txt.textSize * 4.5 / slot)).toInt())
    for (i in 0 until n step step) {
        val cx = padL + slot * (i + 0.5f)
        val label = c.cats[i].let { if (it.length > 8) it.take(7) + "…" else it }
        drawContext.canvas.nativeCanvas.drawText(label, cx, size.height - 6f, txt)
    }
    val zeroY = yOf(0.0.coerceIn(lo, hi))
    when (c.kind) {
        ChartKind.BAR -> {
            val ns = maxOf(1, c.series.size)
            val bw = (slot * 0.8f) / ns
            c.series.forEachIndexed { si, s ->
                s.values.forEachIndexed { i, v ->
                    if (v == null) return@forEachIndexed
                    val x = padL + slot * i + slot * 0.1f + bw * si
                    val y = yOf(v)
                    drawRect(PALETTE[si % PALETTE.size], Offset(x, minOf(y, zeroY)), Size(bw.coerceAtLeast(1f), Math.abs(zeroY - y).coerceAtLeast(1f)))
                }
            }
        }
        ChartKind.LINE, ChartKind.AREA -> c.series.forEachIndexed { si, s ->
            val col = PALETTE[si % PALETTE.size]
            val path = Path(); var started = false; var lastX = 0f; var firstX = 0f
            s.values.forEachIndexed { i, v ->
                if (v == null) { started = false; return@forEachIndexed }
                val x = padL + slot * (i + 0.5f); val y = yOf(v)
                if (!started) { path.moveTo(x, y); started = true; firstX = x } else path.lineTo(x, y)
                lastX = x
                if (n <= 60) drawCircle(col, 3f, Offset(x, y))
            }
            if (c.kind == ChartKind.AREA && started) {
                val fill = Path(); fill.addPath(path); fill.lineTo(lastX, zeroY); fill.lineTo(firstX, zeroY); fill.close()
                drawPath(fill, col.copy(alpha = 0.25f))
            }
            drawPath(path, col, style = Stroke(width = 3f))
        }
        ChartKind.SCATTER -> {
            val xs = c.series.flatMap { it.xs }.filterNotNull()
            val xlo = xs.minOrNull() ?: 0.0; val xhi = (xs.maxOrNull() ?: 1.0).let { if (it == xlo) xlo + 1 else it }
            c.series.forEachIndexed { si, s ->
                s.values.forEachIndexed { i, v ->
                    val xv = s.xs.getOrNull(i) ?: (i + 1).toDouble()
                    if (v == null) return@forEachIndexed
                    drawCircle(PALETTE[si % PALETTE.size], 4f, Offset(padL + ((xv - xlo) / (xhi - xlo)).toFloat() * w, yOf(v)))
                }
            }
        }
        else -> {}
    }
}

/** Yatay çubuk grafiği: kategoriler solda, çubuklar sıfırdan değere yatay uzanır, değer ekseni altta. */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawHBar(c: DocChart, txt: Paint) {
    val n = c.cats.size
    if (n == 0) return
    val (lo, hi) = DocVisual.range(c)
    val scale = txt.textSize / 10f
    val labels = c.cats.map { if (it.length > 12) it.take(11) + "…" else it }
    val labelW = minOf(labels.maxOf { txt.measureText(it) } + 6f * scale, size.width * 0.4f)
    val padL = labelW + 4f * scale; val padR = 12f; val padT = 8f; val padB = 22f * scale
    val w = size.width - padL - padR
    val h = size.height - padT - padB
    if (w <= 0 || h <= 0) return
    val axis = Color.Gray.copy(alpha = 0.6f)
    val grid = Color.Gray.copy(alpha = 0.2f)
    val nc = drawContext.canvas.nativeCanvas
    // dikey ızgara ve değer etiketleri (alt eksen)
    val ticks = 4
    for (t in 0..ticks) {
        val v = lo + (hi - lo) * t / ticks
        val x = padL + w * VisualPure.frac(v, lo, hi).toFloat()
        drawLine(grid, Offset(x, padT), Offset(x, padT + h), 1f)
        nc.drawText(DocVisual.num(v), x, size.height - 6f, txt)
    }
    drawLine(axis, Offset(padL, padT), Offset(padL, padT + h), 1.5f)
    if (lo < 0) {
        val zx = padL + w * VisualPure.frac(0.0, lo, hi).toFloat()
        drawLine(axis, Offset(zx, padT), Offset(zx, padT + h), 1.5f)
    }
    val rowH = h / n
    val ns = maxOf(1, c.series.size)
    val bh = (rowH * 0.8f) / ns
    // kategori etiketleri: satır yüksekliğine sığmıyorsa atlanır
    val step = maxOf(1, Math.ceil((txt.textSize * 1.3 / rowH)).toInt())
    val al = txt.textAlign
    txt.textAlign = Paint.Align.RIGHT
    for (i in 0 until n step step) {
        nc.drawText(labels[i], padL - 4f * scale, padT + rowH * (i + 0.5f) + txt.textSize / 3, txt)
    }
    txt.textAlign = al
    c.series.forEachIndexed { si, s ->
        s.values.forEachIndexed { i, v ->
            if (v == null) return@forEachIndexed
            val (a, b) = VisualPure.barSpan(v, lo, hi)
            val x0 = padL + w * a.toFloat()
            val x1 = padL + w * b.toFloat()
            val y = padT + rowH * i + rowH * 0.1f + bh * si
            drawRect(PALETTE[si % PALETTE.size], Offset(x0, y), Size((x1 - x0).coerceAtLeast(1f), bh.coerceAtLeast(1f)))
        }
    }
}

private fun scatterRange(c: DocChart): Pair<Double, Double> {
    val vs = c.series.flatMap { it.values }.filterNotNull()
    if (vs.isEmpty()) return 0.0 to 1.0
    var lo = vs.min(); var hi = vs.max()
    if (hi == lo) { lo -= 1; hi += 1 }
    return lo to hi
}

@Composable
fun DiagramBlock(d: DocDiagram) {
    val tk = LocalDesign.current.tokens
    val ratio = DocVisual.aspect(d.w, d.h).coerceIn(0.2, 3.0).toFloat()
    val density = LocalDensity.current
    val edge = tk.text.copy(alpha = 0.7f)
    val fill = tk.primary.copy(alpha = 0.12f)
    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth()) {
        val wDp = maxWidth
        Canvas(Modifier.width(wDp).height(wDp * ratio).border(1.dp, tk.text.copy(alpha = 0.15f))) {
            val pad = 6f
            val sx = (size.width - 2 * pad) / d.w.toFloat()
            val sy = (size.height - 2 * pad) / d.h.toFloat()
            val s = minOf(sx, sy)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.argb(230, (tk.text.red * 255).toInt(), (tk.text.green * 255).toInt(), (tk.text.blue * 255).toInt()); textAlign = Paint.Align.CENTER }
            d.lines.forEach { l -> drawLine(edge, Offset(pad + l.x1.toFloat() * s, pad + l.y1.toFloat() * s), Offset(pad + l.x2.toFloat() * s, pad + l.y2.toFloat() * s), 1.5f) }
            d.boxes.forEach { b ->
                val x = pad + b.x.toFloat() * s; val y = pad + b.y.toFloat() * s; val bw = b.w.toFloat() * s; val bh = b.h.toFloat() * s
                if (b.round) {
                    drawRoundRect(fill, Offset(x, y), Size(bw, bh), androidx.compose.ui.geometry.CornerRadius(bh / 3, bh / 3))
                    drawRoundRect(edge, Offset(x, y), Size(bw, bh), androidx.compose.ui.geometry.CornerRadius(bh / 3, bh / 3), style = Stroke(1.5f))
                } else {
                    drawRect(fill, Offset(x, y), Size(bw, bh)); drawRect(edge, Offset(x, y), Size(bw, bh), style = Stroke(1.5f))
                }
                if (b.text.isNotBlank() && bw > 12f && bh > 8f) {
                    val lines = b.text.split('\n').filter { it.isNotBlank() }.take(6)
                    paint.textSize = (bh / (lines.size + 1)).coerceIn(7f * density.density, 14f * density.density)
                    val total = lines.size * paint.textSize * 1.1f
                    var ty = y + (bh - total) / 2 + paint.textSize * 0.85f
                    for (ln in lines) {
                        val cut = paint.breakText(ln, true, bw - 4f, null)
                        drawContext.canvas.nativeCanvas.drawText(if (cut < ln.length && cut > 1) ln.take(cut - 1) + "…" else ln.take(maxOf(cut, 0)), x + bw / 2, ty, paint)
                        ty += paint.textSize * 1.1f
                    }
                }
            }
        }
    }
}
