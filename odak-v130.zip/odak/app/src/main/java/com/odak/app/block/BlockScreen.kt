package com.odak.app.block

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.ThemedHeader
import com.odak.app.theme.plainClick
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun BlockScreen() {
    val ctx = LocalContext.current
    var locked by remember { mutableStateOf(Pin.locked(ctx)) }
    if (locked) PinGate(stringResource(R.string.pin_title)) { locked = false } else BlockContent()
}

@Composable
private fun BlockContent() {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(BlockStore.a11yEnabled(ctx)) }
    var tick by remember { mutableIntStateOf(0) }
    var used by remember { mutableStateOf(emptyMap<String, Long>()) }
    var cooldown by remember { mutableStateOf<(() -> Unit)?>(null) }
    var picker by remember { mutableStateOf(false) }
    var lab by remember { mutableStateOf<Pair<String, String>?>(null) }
    var detail by remember { mutableStateOf<String?>(null) }
    lab?.let { RuleLabDialog(it.first, it.second) { lab = null; tick++ } }
    var appQ by remember { mutableStateOf("") }
    var onlyActive by rememberSaveable { mutableStateOf(false) }
    val PAGE = com.odak.app.logic.Pure.APP_PAGE
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var shown by remember(appQ, onlyActive) { mutableIntStateOf(PAGE) }
    val allApps = BlockCatalog.apps
    var sortMode by rememberSaveable { mutableIntStateOf(BlockStore.appSort(ctx)) }
    val filtered = remember(appQ, tick, allApps.size, onlyActive, sortMode) {
        com.odak.app.logic.AppList.order(
            allApps.filter { com.odak.app.logic.Pure.nameMatches(it.name, appQ) && (!onlyActive || BlockStore.isActiveApp(ctx, it)) },
            com.odak.app.logic.AppList.sortOf(sortMode), { it.name }, { a -> a.packages.sumOf { used[it] ?: 0L } }
        )
    }
    LaunchedEffect(Unit) { BlockCatalog.loadCustom(ctx) }
    if (picker) CustomAppPicker { picker = false; tick++ }
    detail?.let { id ->
        allApps.firstOrNull { it.id == id }?.let { app ->
            AppDetailDialog(app, used, enabled, openSettings = {
                com.odak.app.Launch.go(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, onCooldown = { cooldown = it }, onLab = { a, f -> lab = a to f }, bump = { tick++ }, onClose = { detail = null })
        } ?: run { detail = null }
    }
    cooldown?.let { act -> CooldownDialog({ act(); cooldown = null }, { cooldown = null }) }

    LaunchedEffect(Unit) {
        while (true) {
            enabled = BlockStore.a11yEnabled(ctx)
            if (BlockStore.usageAccess(ctx)) used = withContext(Dispatchers.IO) { BlockStore.usageToday(ctx) }
            tick++
            delay(2000)
        }
    }
    val openSettings = {
        com.odak.app.Launch.go(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(16.dp))
            ThemedHeader(stringResource(R.string.tab_block))
        }
        item {
            com.odak.app.theme.ThemedTabBar(
                listOf(
                    stringResource(R.string.blk_tab_apps),
                    stringResource(R.string.focus_title),
                    stringResource(R.string.blk_tab_quiet),
                    stringResource(R.string.blk_tab_adv)
                ),
                tab, { tab = it }, bottom = false
            )
        }
        if (!enabled) {
            item {
                ThemedCard(Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.block_perm_needed))
                    Spacer(Modifier.height(10.dp))
                    ThemedButton(stringResource(R.string.block_grant), openSettings)
                }
            }
        }
        if (tab == 0) {
        item {
            val activeCount = remember(tick, allApps.size) { allApps.count { BlockStore.isActiveApp(ctx, it) } }
            if (activeCount > 0) Text("🛡 " + stringResource(R.string.blk_active_count, activeCount), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(bottom = 6.dp).alpha(0.8f))
            com.odak.app.theme.ThemedTextField(appQ, { appQ = it }, "🔍 " + stringResource(R.string.app_search), Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            ThemedButton((if (onlyActive) "✔ " else "") + stringResource(R.string.blk_only_active), { onlyActive = !onlyActive })
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf("A–Z", "Z–A", "⏱ " + stringResource(R.string.sort_usage)).forEachIndexed { i, label ->
                    ThemedButton((if (sortMode == i) "✔ " else "") + label, { sortMode = i; BlockStore.setAppSort(ctx, i) })
                }
            }
        }
        if (filtered.isEmpty()) item {
            com.odak.app.theme.EmptyState(if (onlyActive && appQ.isBlank()) "🛡" else "🔍", stringResource(if (onlyActive && appQ.isBlank()) R.string.blk_only_active else R.string.custom_app_none), if (onlyActive && appQ.isBlank()) stringResource(R.string.blk_none_hint) else null)
        }
        items(filtered.take(com.odak.app.logic.Pure.appsVisible(shown, filtered.size)), key = { it.id }) { app ->
            val rev = tick // tercih değişince yeniden okumak için
            val whole = BlockStore.isAppBlocked(ctx, app.id)
            val ms = app.packages.sumOf { used[it] ?: 0L }
            val oc = BlockStore.opensToday(ctx, app.id)
            val badges = com.odak.app.logic.AppList.badges(
                whole, BlockStore.appLimit(ctx, app.id), BlockStore.openLimit(ctx, app.id),
                BlockStore.appQuiet(ctx, app.id), app.features.count { BlockStore.isFeatureBlocked(ctx, app.id, it.id) || BlockStore.featLimit(ctx, app.id, it.id) > 0 }
            )
            ThemedCard(Modifier.fillMaxWidth()) {
                // Sade satır: ad + özet rozetler, dokununca ayrıntı penceresi açılır
                Row(Modifier.fillMaxWidth().plainClick { detail = app.id }.padding(vertical = 4.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(app.name, style = MaterialTheme.typography.titleMedium)
                        val sub = listOfNotNull(
                            if (ms >= 60_000) "${ms / 60_000}m" else null, if (oc > 0) "${oc}×" else null, badges.ifBlank { null }
                        ).joinToString("  ·  ")
                        if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.75f))
                    }
                    ThemedCheck(enabled && whole) {
                        if (!enabled) openSettings()
                        else if (!it && whole) cooldown = { BlockStore.setAppBlocked(ctx, app.id, false); tick++ }
                        else { BlockStore.setAppBlocked(ctx, app.id, it); tick++ }
                    }
                    Text("  ⋯")
                }
            }
        }
        item {
            val rem = com.odak.app.logic.Pure.appsRemaining(shown, filtered.size)
            if (rem > 0) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemedButton(stringResource(R.string.blk_more, rem), { shown = com.odak.app.logic.Pure.appsNextShown(shown, filtered.size) })
                ThemedButton(stringResource(R.string.blk_all), { shown = filtered.size })
            }
        }
        item { ThemedButton("➕ " + stringResource(R.string.custom_app_add), { picker = true }) }
        }
        if (tab == 1) {
        item {
            val until = BlockStore.focusUntil(ctx)
            val left = ((until - System.currentTimeMillis()) / 60_000L).toInt() + 1
            ThemedCard(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.focus_title), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                if (BlockStore.focusActive(ctx)) {
                    Text(stringResource(R.string.focus_left) + ": " + stringResource(R.string.fmt_min, left))
                    val endAt = java.time.Instant.ofEpochMilli(until).atZone(java.time.ZoneId.systemDefault()).toLocalTime()
                    Text(
                        stringResource(R.string.focus_ends) + ": " + "%02d:%02d".format(endAt.hour, endAt.minute),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ThemedButton("+" + stringResource(R.string.fmt_min, com.odak.app.logic.Pure.FOCUS_EXTEND_MIN) + " " + stringResource(R.string.focus_extend), {
                            val ext = com.odak.app.logic.Pure.focusExtend(until, System.currentTimeMillis(), com.odak.app.logic.Pure.FOCUS_EXTEND_MIN)
                            BlockStore.setFocusUntil(ctx, ext)
                            com.odak.app.notify.Reminders.scheduleAt(ctx, "focus_end", ctx.getString(R.string.focus_done_title), com.odak.app.notify.Msgs.text(ctx, "focus", ""), ext)
                            tick++
                        })
                        ThemedButton(stringResource(R.string.focus_stop), {
                            BlockStore.setFocusUntil(ctx, 0L)
                            com.odak.app.notify.Reminders.cancelId(ctx, "focus_end")
                            tick++
                        })
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(25, 45, 60).forEach { m ->
                            ThemedButton("▶ " + stringResource(R.string.fmt_min, m), {
                                if (!enabled) openSettings()
                                else {
                                    val until2 = System.currentTimeMillis() + m * 60_000L
                                    BlockStore.setFocusUntil(ctx, until2)
                                    com.odak.app.notify.Reminders.scheduleAt(ctx, "focus_end", ctx.getString(R.string.focus_done_title), com.odak.app.notify.Msgs.text(ctx, "focus", ""), until2)
                                    tick++
                                }
                            })
                        }
                    }
                }
            }
        }
        item {
            Text(
                stringResource(R.string.blk_today, BlockStore.blockedToday(ctx).also { tick }),
                style = MaterialTheme.typography.bodySmall
            )
        }
        }
        if (tab == 2) {
        item {
            val q = BlockStore.quietOn(ctx)
            ThemedCard(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.quiet_title), style = MaterialTheme.typography.titleMedium)
                ToggleRow(stringResource(R.string.quiet_apply), enabled && q) {
                    if (!enabled) openSettings() else { BlockStore.setQuietOn(ctx, it); tick++ }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween) {
                    val mask = BlockStore.quietDays(ctx)
                    for (i in 0..6) {
                        val on = (mask shr i) and 1 == 1
                        val tk = com.odak.app.theme.LocalDesign.current.tokens
                        androidx.compose.foundation.layout.Box(
                            Modifier.size(34.dp)
                                .background(if (on) tk.primary else tk.text.copy(alpha = 0.12f), androidx.compose.foundation.shape.CircleShape)
                                .plainClick { BlockStore.setQuietDays(ctx, mask xor (1 shl i)); tick++ },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                java.time.DayOfWeek.of(i + 1).getDisplayName(java.time.format.TextStyle.NARROW, java.util.Locale.getDefault()),
                                color = if (on) tk.surface else tk.text
                            )
                        }
                    }
                }
                run {
                    val now = java.time.LocalTime.now().let { it.hour * 60 + it.minute }
                    val st = com.odak.app.logic.Pure.quietState(
                        BlockStore.quietOn(ctx), now, BlockStore.quietFrom(ctx), BlockStore.quietTo(ctx),
                        java.time.LocalDate.now().dayOfWeek.value - 1, BlockStore.quietDays(ctx)
                    )
                    Text(
                        stringResource(
                            when (st) {
                                com.odak.app.logic.Pure.QuietState.ACTIVE -> R.string.quiet_state_active
                                com.odak.app.logic.Pure.QuietState.SAME_TIMES -> R.string.quiet_state_same
                                else -> R.string.quiet_state_idle
                            }
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (st == com.odak.app.logic.Pure.QuietState.SAME_TIMES) MaterialTheme.colorScheme.error else Color.Unspecified
                    )
                }
                TimeStep(BlockStore.quietFrom(ctx)) { BlockStore.setQuietFrom(ctx, it); tick++ }
                TimeStep(BlockStore.quietTo(ctx)) { BlockStore.setQuietTo(ctx, it); tick++ }
            }
        }
        }
        if (tab == 3) {
        item { AlertsCard() }
        item { ScreensCard() }
        item { NotifHideCard() }
        item { LearnCard(tick) { tick++ } }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    modifier: Modifier = Modifier,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier.fillMaxWidth().padding(vertical = 6.dp),
        Arrangement.SpaceBetween,
        Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f))
        ThemedCheck(checked, onChange)
    }
}

/** − 5 dk + ; 0 = sınırsız. */
@Composable
private fun LimitRow(
    label: String,
    minutes: Int,
    modifier: Modifier = Modifier,
    usedMin: Int = 0,
    onChange: (Int) -> Unit
) {
    Row(
        modifier.fillMaxWidth().padding(bottom = 4.dp),
        Arrangement.SpaceBetween,
        Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
        ThemedButton("−", { onChange((minutes - 5).coerceAtLeast(0)) })
        // Sınıra ulaşınca metin kırmızılaşır ve ✖ işareti eklenir (renge tek başına bağlı kalmamak için).
        val reached = minutes > 0 && com.odak.app.logic.Pure.limitReached(usedMin * 60_000L, minutes)
        Text(
            if (minutes == 0) stringResource(R.string.limit_none)
            else (if (reached) "✖ " else "") + "$usedMin / " + stringResource(R.string.fmt_min, minutes),
            Modifier.padding(horizontal = 8.dp),
            color = if (reached) MaterialTheme.colorScheme.error else Color.Unspecified,
            style = MaterialTheme.typography.bodySmall
        )
        ThemedButton("+", { onChange((minutes + 5).coerceAtMost(600)) })
    }
}

/** − 1 kez + ; 0 = sınırsız. */
@Composable
private fun CountRow(label: String, limit: Int, used: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
        ThemedButton("−", { onChange((limit - 1).coerceAtLeast(0)) })
        val hit = com.odak.app.logic.Pure.openLimitHit(used, limit)
        Text(
            if (limit == 0) stringResource(R.string.limit_none)
            else (if (hit) "✖ " else "") + "${minOf(used, limit)} / " + stringResource(R.string.fmt_times, limit),
            Modifier.padding(horizontal = 8.dp),
            color = if (hit) MaterialTheme.colorScheme.error else Color.Unspecified,
            style = MaterialTheme.typography.bodySmall
        )
        ThemedButton("+", { onChange((limit + 1).coerceAtMost(99)) })
    }
}

/** − 30 dk + */
@Composable
private fun TimeStep(minutes: Int, onChange: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        Arrangement.SpaceBetween,
        Alignment.CenterVertically
    ) {
        ThemedButton("−", { onChange(com.odak.app.logic.Pure.stepTime(minutes, -com.odak.app.logic.Pure.TIME_STEP_MIN)) })
        Text(com.odak.app.plan.fmtTime(minutes), style = MaterialTheme.typography.titleMedium)
        ThemedButton("+", { onChange(com.odak.app.logic.Pure.stepTime(minutes, com.odak.app.logic.Pure.TIME_STEP_MIN)) })
    }
}

@Composable
private fun LearnCard(rev: Int, onChange: () -> Unit) {
    val ctx = LocalContext.current
    val import = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() }
            if (text != null) BlockStore.importRules(ctx, text)
        }
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        ToggleRow(stringResource(R.string.learn_title), BlockStore.learnOn(ctx)) {
            BlockStore.setLearnOn(ctx, it)
            onChange()
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ThemedButton(stringResource(R.string.learn_share), {
                val send = Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, BlockStore.seenText(ctx).lines().takeLast(600).joinToString("\n"))
                com.odak.app.Launch.go(ctx, Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
            ThemedButton(stringResource(R.string.learn_clear), { BlockStore.clearSeen(ctx); onChange() })
        }
        Spacer(Modifier.height(6.dp))
        ThemedButton(stringResource(R.string.rules_import), { import.launch(arrayOf("application/json", "*/*")) })
    }
}

/** Uygulama ayrıntı penceresi: Engel · Sınırlar · Özellikler bölümleri. */
@Composable
private fun AppDetailDialog(
    app: BlockApp, used: Map<String, Long>, enabled: Boolean, openSettings: () -> Unit,
    onCooldown: ((() -> Unit)) -> Unit, onLab: (String, String) -> Unit, bump: () -> Unit, onClose: () -> Unit
) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    fun changed() { rev++; bump() }
    @Composable fun Section(res: Int) = Text(
        stringResource(res), style = MaterialTheme.typography.labelLarge,
        modifier = Modifier.padding(top = 14.dp, bottom = 4.dp).alpha(0.7f)
    )
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onClose,
        title = { Text(app.name) },
        confirmButton = { ThemedButton(stringResource(R.string.pin_ok), onClose) },
        text = {
            androidx.compose.runtime.key(rev) {
                androidx.compose.foundation.layout.Column(
                    Modifier.fillMaxWidth().heightIn(max = 440.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())
                ) {
                    val whole = BlockStore.isAppBlocked(ctx, app.id)
                    Section(R.string.blk_sec_block)
                    ToggleRow(stringResource(R.string.block_whole), enabled && whole) {
                        if (!enabled) openSettings()
                        else if (!it && whole) onCooldown { BlockStore.setAppBlocked(ctx, app.id, false); changed() }
                        else { BlockStore.setAppBlocked(ctx, app.id, it); changed() }
                    }
                    ToggleRow(stringResource(R.string.quiet_apply), enabled && BlockStore.appQuiet(ctx, app.id)) {
                        if (!enabled) openSettings() else { BlockStore.setAppQuiet(ctx, app.id, it); changed() }
                    }
                    Section(R.string.blk_sec_limits)
                    LimitRow(
                        stringResource(R.string.limit_daily), BlockStore.appLimit(ctx, app.id),
                        usedMin = (app.packages.sumOf { used[it] ?: 0L } / 60_000).toInt()
                    ) { BlockStore.setAppLimit(ctx, app.id, it); changed() }
                    CountRow(stringResource(R.string.limit_opens), BlockStore.openLimit(ctx, app.id), BlockStore.opensToday(ctx, app.id)) {
                        BlockStore.setOpenLimit(ctx, app.id, it); changed()
                    }
                    if (app.features.isNotEmpty()) Section(R.string.blk_sec_features)
                    app.features.forEach { f ->
                        val label = f.res?.let { stringResource(it) } ?: f.text.orEmpty()
                        val on = enabled && BlockStore.isFeatureBlocked(ctx, app.id, f.id)
                        ToggleRow(label, on, Modifier.alpha(if (whole) 0.45f else 1f)) {
                            if (!enabled) openSettings()
                            else if (!it && on) onCooldown { BlockStore.setFeatureBlocked(ctx, app.id, f.id, false); changed() }
                            else { BlockStore.setFeatureBlocked(ctx, app.id, f.id, it); changed() }
                        }
                        LimitRow(
                            stringResource(R.string.limit_daily), BlockStore.featLimit(ctx, app.id, f.id), Modifier.padding(start = 12.dp),
                            usedMin = (BlockStore.featUsedMs(ctx, app.id, f.id) / 60_000).toInt()
                        ) { BlockStore.setFeatLimit(ctx, app.id, f.id, it); changed() }
                        ThemedButton("🎯 " + stringResource(R.string.rl_title), { onLab(app.id, f.id) })
                    }
                    if (app.id.startsWith("c:")) {
                        Spacer(Modifier.height(10.dp))
                        ThemedButton("🗑", { BlockCatalog.removeCustom(ctx, app.id); changed(); onClose() })
                    }
                }
            }
        }
    )
}

/** Engeli kapatmadan önce 10 sn bekleme: dürtüyle kapatmayı zorlaştırır. */
@Composable
private fun CooldownDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    var left by remember { mutableIntStateOf(10) }
    LaunchedEffect(Unit) {
        while (left > 0) {
            delay(1000)
            left--
        }
    }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            if (left == 0) ThemedButton(stringResource(R.string.pin_ok), onConfirm) else Text("$left")
        },
        dismissButton = { ThemedButton("✕", onDismiss) },
        text = { Text(stringResource(R.string.motiv_1)) }
    )
}
