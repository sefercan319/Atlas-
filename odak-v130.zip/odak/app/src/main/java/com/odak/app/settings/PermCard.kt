package com.odak.app.settings

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.odak.app.R
import com.odak.app.block.BlockStore
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import kotlinx.coroutines.delay

/** Tüm izinlerin durumu tek yerde. */
@Composable
fun PermCard() {
    val ctx = LocalContext.current
    var acc by remember { mutableStateOf(false) }
    var usage by remember { mutableStateOf(false) }
    var notif by remember { mutableStateOf(false) }
    var batt by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val pm = ctx.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
        while (true) {
            acc = BlockStore.a11yEnabled(ctx)
            usage = BlockStore.usageAccess(ctx)
            notif = ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            batt = pm.isIgnoringBatteryOptimizations(ctx.packageName)
            delay(1000)
        }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notif = it }
    fun open(i: Intent) = com.odak.app.Launch.go(ctx, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.perm_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        PermRow(stringResource(R.string.perm_acc), acc) { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        PermRow(stringResource(R.string.perm_usagename), usage) { open(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        PermRow(stringResource(R.string.perm_notif), notif) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
        PermRow(stringResource(R.string.perm_batt), batt) {
            open(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:" + ctx.packageName))
            )
        }
        if (!batt) {
            Text(stringResource(R.string.perm_batt_hint), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PermRow(label: String, ok: Boolean, onGrant: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        Arrangement.SpaceBetween,
        Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f))
        if (ok) Text("✓") else ThemedButton(stringResource(R.string.block_grant), onGrant)
    }
}
