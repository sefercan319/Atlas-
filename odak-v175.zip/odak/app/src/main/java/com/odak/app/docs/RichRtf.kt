package com.odak.app.docs

import java.nio.charset.Charset

/**
 * RTF → zengin sayfa: kalın/italik/altı çizili/boyut/renk, hizalama, girinti, basit tablolar ve gömülü resimler
 * (\pngblip, \jpegblip, \emfblip, \wmetafile…). Kod sayfası \ansicpg ve yazı tipi \fcharset'ten okunur (Türkçe doğru çıkar).
 * Saf mantık: Android'e bağlı değil.
 */
object RichRtf {
    private const val MAX_BLOCKS = 6000
    private const val MAX_IMG = 24L * 1024 * 1024

    private class Pic { var kind = ""; var w = 0; var h = 0; var gw = 0; var gh = 0; val hex = StringBuilder() }

    private class St(
        var b: Boolean = false, var i: Boolean = false, var u: Boolean = false, var sz: Int = 0, var color: Int = 0,
        var skip: Boolean = false, var uc: Int = 1, var font: Int = -1, var pic: Pic? = null, var dest: String = "", var sup: Int = 0
    ) {
        fun copy() = St(b, i, u, sz, color, skip, uc, font, pic, dest, sup)
    }

    private val CHARSET_CP = mapOf(162 to "windows-1254", 238 to "windows-1250", 204 to "windows-1251", 161 to "windows-1253",
        177 to "windows-1255", 178 to "windows-1256", 186 to "windows-1257", 163 to "windows-1258", 222 to "windows-874",
        128 to "Shift_JIS", 134 to "GB2312", 136 to "Big5", 129 to "windows-949", 130 to "windows-1361")

    private fun cs(name: String?): Charset = try { Charset.forName(name ?: "windows-1252") } catch (e: Exception) { Charsets.ISO_8859_1 }

    fun parse(s: String): RichPage? = try { parseInner(s) } catch (e: Exception) { null } catch (e: StackOverflowError) { null }

    private fun parseInner(s: String): RichPage? {
        if (!s.startsWith("{\\rtf")) return null
        var ansiCp: String? = null
        val fontCs = HashMap<Int, Int>()
        val colors = ArrayList<String?>()
        val blocks = ArrayList<RBlock>()
        val runs = ArrayList<RRun>()
        val text = StringBuilder()
        val stack = ArrayList<St>()
        var st = St()
        var align = ""; var left = 0; var first = 0; var before = -1; var after = -1
        var sawFormat = false
        var imgBytes = 0L

        // tablo
        val rowCells = ArrayList<RCell>(); val cellParas = ArrayList<RPara>(); val cellX = ArrayList<Int>()
        val tableRows = ArrayList<List<RCell>>(); var tableCols: List<Int> = emptyList()
        var inRow = false
        var curFont = -1
        var colorR = -1; var colorG = -1; var colorB = -1
        val pend = java.io.ByteArrayOutputStream() // \'xx baytları (çok baytlı kod sayfaları için birikir)

        fun curCharset(): Charset = cs(CHARSET_CP[fontCs[st.font] ?: -1] ?: ansiCp)

        fun flushPend() {
            if (pend.size() > 0) { text.append(String(pend.toByteArray(), curCharset())); pend.reset() }
        }
        fun flushText() {
            flushPend()
            if (text.isEmpty()) return
            val col = colors.getOrNull(st.color)
            runs.add(RRun(text.toString(), st.b, st.i, st.u, false, col, null, st.sz, null, st.sup))
            text.setLength(0)
        }
        lateinit var flushTable: () -> Unit
        var pendingBreak = false
        fun endPara(force: Boolean) {
            flushText()
            if (runs.isEmpty() && !force) return
            val p = RPara(ArrayList(runs), align, 0, "", left, first, before, after, pageBreak = pendingBreak && !inRow)
            if (!inRow) pendingBreak = false
            runs.clear()
            if (inRow) cellParas.add(p) else {
                if (tableRows.isNotEmpty()) flushTable()
                if (blocks.size < MAX_BLOCKS) blocks.add(p)
            }
        }
        fun endCell() {
            endPara(false)
            rowCells.add(RCell(ArrayList(cellParas), 1, 0, null, Bd(4, "808080"), Bd(4, "808080"), Bd(4, "808080"), Bd(4, "808080")))
            cellParas.clear()
        }
        flushTable = {
            if (tableRows.isNotEmpty()) {
                val n = tableRows.maxOf { it.size }
                val cols = if (tableCols.size == n) tableCols else List(n) { 9000 / n }
                if (blocks.size < MAX_BLOCKS) blocks.add(RTable(ArrayList(tableRows), cols))
                tableRows.clear()
            }
        }
        fun endRow() {
            if (cellParas.isNotEmpty() || runs.isNotEmpty()) endCell()
            if (rowCells.isNotEmpty()) {
                val widths = ArrayList<Int>(); var prev = 0
                for (x in cellX) { widths.add((x - prev).coerceAtLeast(300)); prev = x }
                if (widths.size == rowCells.size) tableCols = widths
                tableRows.add(ArrayList(rowCells))
            }
            rowCells.clear(); cellX.clear()
        }
        fun finishPic(p: Pic) {
            val hex = p.hex
            if (hex.length < 16 || imgBytes > MAX_IMG) return
            val n = hex.length / 2
            val data = ByteArray(n)
            for (k in 0 until n) data[k] = ((Character.digit(hex[2 * k], 16) shl 4) or Character.digit(hex[2 * k + 1], 16)).toByte()
            val made = RImg.make("", data) ?: return
            imgBytes += made.first.size
            val px = RImg.pixelSize(made.first)
            var w = if (p.gw > 0) p.gw else (px?.first ?: 200) * 15
            var h = if (p.gh > 0) p.gh else (px?.second ?: 150) * 15
            if (w > 9000) { h = (h.toLong() * 9000 / w).toInt(); w = 9000 }
            flushText()
            runs.add(RRun("", img = RImg(made.first, made.second, w.coerceAtLeast(100), h.coerceAtLeast(100))))
        }

        var i = 0
        val n = s.length
        while (i < n) {
            val c = s[i]
            when (c) {
                '{' -> { flushText(); stack.add(st.copy()); i++ }
                '}' -> {
                    flushText()
                    val closing = st
                    st = if (stack.isNotEmpty()) stack.removeAt(stack.size - 1) else St()
                    closing.pic?.let { p -> if (st.pic !== p) finishPic(p) }
                    if (closing.dest == "colortbl" && st.dest != "colortbl") { /* tablo bitti */ }
                    i++
                }
                '\r', '\n' -> i++
                '\\' -> {
                    i++
                    if (i >= n) break
                    val d = s[i]
                    when {
                        d == '\\' || d == '{' || d == '}' -> { if (!st.skip) text.append(d); i++ }
                        d == '\'' -> {
                            val v = s.substring(i + 1, minOf(n, i + 3)).toIntOrNull(16)
                            i += 3
                            if (v != null && !st.skip && st.pic == null) pend.write(v)
                        }
                        d == '*' -> { i++; if (!s.startsWith("\\shppict", i)) st.skip = true }
                        d == '~' -> { if (!st.skip) text.append(' '); i++ }
                        d == '-' -> { i++ }
                        d == '_' -> { if (!st.skip) text.append('‑'); i++ }
                        d.isLetter() -> {
                            var j = i
                            while (j < n && s[j].isLetter()) j++
                            val word = s.substring(i, j)
                            var k = j
                            if (k < n && (s[k] == '-' || s[k].isDigit())) { k++; while (k < n && s[k].isDigit()) k++ }
                            val param = s.substring(j, k).toIntOrNull()
                            if (k < n && s[k] == ' ') k++
                            i = k
                            run handle@{
                                when (word) {
                                    "ansicpg" -> { if (param != null) ansiCp = "windows-$param" ; return@handle }
                                    "fonttbl", "colortbl" -> { st.dest = word; if (word == "fonttbl") st.skip = false; return@handle }
                                    "f" -> { if (st.dest == "fonttbl") { curFont = param ?: -1 } else { flushText(); st.font = param ?: -1 }; return@handle }
                                    "fcharset" -> { if (st.dest == "fonttbl" && param != null && curFont >= 0) fontCs[curFont] = param; return@handle }
                                    "red" -> { colorR = param ?: 0; return@handle }
                                    "green" -> { colorG = param ?: 0; return@handle }
                                    "blue" -> { colorB = param ?: 0; return@handle }
                                    "pict" -> { if (!st.skip) st.pic = Pic(); return@handle }
                                    "nonshppict", "stylesheet", "info", "header", "footer", "headerl", "headerr", "headerf", "footerl", "footerr", "footerf",
                                    "object", "themedata", "colorschememapping", "latentstyles", "datastore", "listtable", "listoverridetable", "rsidtbl",
                                    "generator", "xmlnstbl", "fldinst", "bkmkstart", "bkmkend", "shpinst", "pgdsctbl", "revtbl", "mmathPr", "template", "filetbl", "pnseclvl" -> { st.skip = true; return@handle }
                                }
                                val pic = st.pic
                                if (pic != null) {
                                    when (word) {
                                        "pngblip", "jpegblip", "emfblip", "wmetafile", "dibitmap", "wbitmap", "macpict" -> pic.kind = word
                                        "picw" -> pic.w = param ?: 0
                                        "pich" -> pic.h = param ?: 0
                                        "picwgoal" -> pic.gw = param ?: 0
                                        "pichgoal" -> pic.gh = param ?: 0
                                    }
                                    return@handle
                                }
                                if (st.skip) return@handle
                                flushPend()
                                when (word) {
                                    "par", "sect" -> endPara(true)
                                    "line" -> { flushText(); runs.add(RRun("\n", st.b, st.i, st.u, false, colors.getOrNull(st.color), null, st.sz)) }
                                    "page" -> { endPara(false); pendingBreak = true }
                                    "tab" -> text.append('\t')
                                    "emdash" -> text.append('—'); "endash" -> text.append('–'); "bullet" -> text.append('•')
                                    "lquote" -> text.append('‘'); "rquote" -> text.append('’'); "ldblquote" -> text.append('“'); "rdblquote" -> text.append('”')
                                    "emspace", "enspace" -> text.append(' ')
                                    "b" -> { flushText(); st.b = param != 0; sawFormat = true }
                                    "i" -> { flushText(); st.i = param != 0; sawFormat = true }
                                    "ul", "uld", "uldb", "ulw" -> { flushText(); st.u = param != 0; sawFormat = true }
                                    "ulnone" -> { flushText(); st.u = false }
                                    "fs" -> { flushText(); st.sz = (param ?: 0).coerceIn(0, 400); sawFormat = true }
                                    "cf" -> { flushText(); st.color = param ?: 0; sawFormat = true }
                                    "super" -> { flushText(); st.sup = 1 }
                                    "sub" -> { flushText(); st.sup = -1 }
                                    "nosupersub" -> { flushText(); st.sup = 0 }
                                    "plain" -> { flushText(); st.b = false; st.i = false; st.u = false; st.sz = 0; st.color = 0; st.sup = 0 }
                                    "pard" -> { align = ""; left = 0; first = 0; before = -1; after = -1 }
                                    "qc" -> align = "center"; "qr" -> align = "right"; "qj" -> align = "justify"; "ql" -> align = ""
                                    "li" -> left = param ?: 0
                                    "fi" -> first = param ?: 0
                                    "sb" -> before = param ?: -1
                                    "sa" -> after = param ?: -1
                                    "uc" -> st.uc = param ?: 1
                                    "u" -> if (param != null) {
                                        flushPend()
                                        text.append((if (param < 0) param + 65536 else param).toChar())
                                        // izleyen uc sayıda yedek karakteri atla
                                        var skipN = st.uc
                                        while (skipN > 0 && i < n) {
                                            if (s[i] == '\\' && i + 1 < n && s[i + 1] == '\'') i += 4
                                            else if (s[i] == '\\' || s[i] == '{' || s[i] == '}') break
                                            else i++
                                            skipN--
                                        }
                                    }
                                    "trowd" -> { if (!inRow) { endPara(false) }; inRow = true; cellX.clear() }
                                    "cellx" -> cellX.add(param ?: 0)
                                    "intbl" -> { if (!inRow) { endPara(false); inRow = true } }
                                    "cell" -> endCell()
                                    "row" -> { endRow(); inRow = false }
                                }
                                Unit
                            }
                        }
                        else -> i++
                    }
                }
                else -> {
                    if (st.pic != null) {
                        if (c.isLetterOrDigit()) st.pic!!.hex.append(c)
                    } else if (st.dest == "colortbl") {
                        if (c == ';') {
                            colors.add(if (colorR >= 0) String.format("%02X%02X%02X", colorR.coerceIn(0, 255), colorG.coerceIn(0, 255), colorB.coerceIn(0, 255)) else null)
                            colorR = -1; colorG = -1; colorB = -1
                        }
                    } else if (!st.skip && st.dest != "fonttbl") {
                        if (pend.size() > 0) flushPend()
                        text.append(c)
                    }
                    i++
                }
            }
        }
        inRow = false
        endPara(false)
        flushTable()
        if (blocks.isEmpty()) return null
        return RichPage(blocks, PageSetup(), 22, null, 0, 0)
    }
}
