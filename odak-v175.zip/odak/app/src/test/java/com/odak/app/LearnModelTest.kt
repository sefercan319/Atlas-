package com.odak.app

import com.odak.app.logic.LearnPure
import com.odak.app.logic.ModelPure
import com.odak.app.logic.UserFeatPure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class LearnModelTest {
    private fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()

    // ---- görsel sınırı / indirme yardımcıları ----
    @Test fun photoLimitIs70Mb() { assertEquals(70L * 1024 * 1024, ModelPure.PHOTO_MAX) }
    @Test fun urlMustBeHttps() {
        assertTrue(ModelPure.urlOk("https://huggingface.co/a/b/resolve/main/m.task"))
        assertFalse(ModelPure.urlOk("http://x.com/a")); assertFalse(ModelPure.urlOk("https://x")); assertFalse(ModelPure.urlOk("https://x.com/a b"))
        assertFalse(ModelPure.urlOk("ftp://x.com/a")); assertFalse(ModelPure.urlOk("https://x.com/" + "a".repeat(2000)))
    }
    @Test fun fileNameIsSafe() {
        assertEquals("m.task", ModelPure.fileName("https://h.co/a/b/m.task?download=true"))
        assertEquals("model.bin", ModelPure.fileName("https://h.co/a/b/"))
        assertTrue(ModelPure.fileName("https://h.co/..%2F..%2Fx.bin").none { it == '/' || it == '%' })
    }
    @Test fun authOnlyForOriginalHostAndRedirectsOnlyHttps() {
        assertTrue(ModelPure.sendAuth("huggingface.co", "huggingface.co", "t")); assertFalse(ModelPure.sendAuth("huggingface.co", "cdn.x.com", "t"))
        assertFalse(ModelPure.sendAuth("a.com", "a.com", ""))
        assertEquals("huggingface.co", ModelPure.host("https://HuggingFace.co:443/x?y"))
        assertTrue(ModelPure.redirectOk("https://cdn.x/y")); assertFalse(ModelPure.redirectOk("http://cdn.x/y")); assertFalse(ModelPure.redirectOk(null))
    }
    @Test fun progressAndSizeAndSpace() {
        assertEquals(50, ModelPure.percent(50, 100)); assertEquals(0, ModelPure.percent(5, 0)); assertEquals(100, ModelPure.percent(200, 100))
        assertEquals("1.5 MB", ModelPure.fmtSize(1_572_864)); assertEquals("2 KB", ModelPure.fmtSize(2048)); assertTrue(ModelPure.fmtSize(300L shl 20).endsWith("MB"))
        assertFalse(ModelPure.enoughSpace(50L shl 20, 10L shl 20)); assertTrue(ModelPure.enoughSpace(1L shl 30, 300L shl 20))
    }

    // ---- cihazda eğitilen öğrenici ----
    private fun data(): List<LearnPure.Ex> {
        val l = ArrayList<LearnPure.Ex>()
        repeat(15) { l += LearnPure.Ex("sel:reels", 0.9, false, true, true); l += LearnPure.Ex("text:home", 0.95, true, false, false) }
        repeat(15) { l += LearnPure.Ex("desc:keşfet", 0.8, false, true, true); l += LearnPure.Ex("id_container_5", 0.9, true, false, false) }
        return l
    }
    @Test fun trainingLearnsWhatUsersPick() {
        val ex = data(); val w = LearnPure.train(ex, 60)
        assertTrue("doğruluk ${LearnPure.accuracy(w, ex)}", LearnPure.accuracy(w, ex) >= 95)
        assertTrue(LearnPure.predict(w, LearnPure.Ex("sel:shorts", 0.9, false, true, true)) > LearnPure.predict(w, LearnPure.Ex("text:home", 0.9, true, false, true)))
    }
    @Test fun trainingIsDeterministicAndResumable() {
        val a = LearnPure.train(data(), 30); val b = LearnPure.train(data(), 30)
        assertEquals(LearnPure.encodeW(a), LearnPure.encodeW(b))
        val more = LearnPure.train(data(), 10, a)
        assertTrue(LearnPure.accuracy(more, data()) >= LearnPure.accuracy(a, data()) - 2)
    }
    @Test fun noPicksUntilEnoughExamples() {
        val c = listOf(UserFeatPure.Cand("sel:reels", false, 0.9))
        val w = LearnPure.train(data(), 60)
        assertTrue(LearnPure.pick(w, 5, c, setOf("sel:reels")).isEmpty()); assertTrue(LearnPure.pick(null, 100, c, emptySet()).isEmpty())
        assertEquals(listOf("sel:reels"), LearnPure.pick(w, 100, c, setOf("sel:reels")))
        assertTrue("negatifte görülen asla seçilmez", LearnPure.pick(w, 100, listOf(UserFeatPure.Cand("sel:reels", true, 0.9)), emptySet()).isEmpty())
    }
    @Test fun serializationRoundTrips() {
        val w = LearnPure.train(data(), 20); assertEquals(LearnPure.encodeW(w), LearnPure.encodeW(LearnPure.decodeW(LearnPure.encodeW(w))!!))
        assertNull(LearnPure.decodeW("1,2,3")); assertNull(LearnPure.decodeW("a,b"))
        val e = LearnPure.Ex("text:a\tb", 0.5, true, false, true); val back = LearnPure.decode(LearnPure.encode(e))!!
        assertEquals("text:a b", back.entry); assertTrue(back.inNeg && back.label && !back.name); assertNull(LearnPure.decode("bozuk"))
        assertTrue(LearnPure.toJsonl(listOf(LearnPure.Ex("text:\"q\"", 0.5, false, true, true))).contains("\\\"q\\\""))
    }
    @Test fun candidatesCarryRatio() {
        val c = UserFeatPure.candidates(mapOf("sel:reels" to 8), 10, emptySet())
        assertEquals(0.8, c[0].ratio, 1e-9)
    }

    // ---- bağlantılar ----
    @Test fun settingsAndPlumbingAreWired() {
        val m = src("settings/ModelCard.kt")
        assertTrue(m.contains("FLAG_KEEP_SCREEN_ON") && m.contains("ModelDownloader.start(ctx)") && m.contains("LearnStore.train(ctx, 80)") && m.contains("ModelPure.PAGE"))
        assertTrue(src("settings/SettingsScreen.kt").contains("ModelCard()"))
        assertTrue(src("MainActivity.kt").contains("KeepAwake.apply(this)") && src("MainActivity.kt").split("override fun onResume").size == 2)
        val d = src("block/ModelDownloader.kt")
        assertTrue(d.contains("\"Range\"") && d.contains("instanceFollowRedirects = false") && d.contains("sendAuth(") && d.contains("redirectOk(") && d.contains("enoughSpace("))
        assertTrue(src("block/RuleLab.kt").contains("LearnStore.record(c, candidates(LearnStore.otherEntries(c, app, feat)), r, fn)"))
        assertTrue(src("block/Extras.kt").contains("LearnStore.pick(ctx, cands, featName)"))
        assertTrue(File(TestFiles.main, "AndroidManifest.xml").readText().contains("android.permission.INTERNET"))
    }
    @Test fun newStringsInAllLocalesWithSamePlaceholders() {
        val keys = listOf("ai_title", "ai_keep", "ai_keep_hint", "ai_page", "ai_url", "ai_token", "ai_dl", "ai_dl_stop", "ai_dl_del", "ai_dl_state", "ai_dl_done", "ai_dl_fail", "ai_learn", "ai_learn_n", "ai_train", "ai_trained", "ai_auto", "ai_export", "ai_note")
        for ((n, f) in TestFiles.stringFiles()) {
            val t = f.readText()
            for (k in keys) assertTrue("$n/$k", t.contains("name=\"$k\""))
            assertTrue(n, t.contains("%1\$s / %2\$s") && t.contains("%1\$d") && t.contains("%%%2\$d"))
        }
    }

    // ---- doğrulamalı eğitim + arka plan ----
    @Test fun fitUsesHeldOutValidationAndStopsEarly() {
        val ex = data()
        val f = LearnPure.fit(ex, 200)
        assertTrue(Math.abs(ex.size / 5 - f.valN) <= 2)
        assertTrue("doğrulama ${f.valAcc}", f.valAcc >= 90); assertTrue(f.trainAcc >= 90)
        assertTrue("erken durma: ${f.epochs}", f.epochs in 1 until 200)
        assertEquals(LearnPure.encodeW(f.w), LearnPure.encodeW(LearnPure.fit(ex, 200).w))   // tekrarlanabilir
    }
    @Test fun smallDataTrainsWithoutValidationAndResumes() {
        val few = data().take(10)
        val f = LearnPure.fit(few, 30); assertEquals(0, f.valN); assertEquals(30, f.epochs)
        val g = LearnPure.fit(data(), 40, f.w); assertTrue(g.valAcc >= 85)
        assertEquals(0, LearnPure.fit(emptyList(), 10).epochs)
    }
    @Test fun spellingVariantsShareTrigrams() {
        val a = LearnPure.features("text:keşfet", 0.9, false, true); val b = LearnPure.features("text:keşfetme", 0.9, false, true)
        var shared = 0; for (i in LearnPure.BASE + LearnPure.WORDS until LearnPure.DIM) if (a[i] > 0 && b[i] > 0) shared++
        assertTrue("ortak üçlü $shared", shared >= 3)
    }
    @Test fun backgroundTrainsOnlyForNewExamples() {
        assertTrue(LearnPure.needsTrain(30, 20)); assertFalse(LearnPure.needsTrain(20, 20)); assertFalse(LearnPure.needsTrain(0, 0))
        val j = src("block/LearnJobService.kt")
        assertTrue(j.contains("setRequiresCharging(true)") && j.contains("setRequiresBatteryNotLow(true)") && j.contains("setPersisted(true)") && j.contains("LearnStore.needsTrain(this)"))
        val m = File(TestFiles.main, "AndroidManifest.xml").readText()
        assertTrue(m.contains(".block.LearnJobService") && m.contains("BIND_JOB_SERVICE") && m.contains("RECEIVE_BOOT_COMPLETED"))
        assertTrue(src("MainActivity.kt").contains("LearnJobService.sync(") && src("settings/ModelCard.kt").contains("LearnJobService.sync(ctx)"))
        assertTrue(src("block/LearnStore.kt").contains("LearnPure.fit("))
        for ((n, f) in TestFiles.stringFiles()) { val t = f.readText(); for (k in listOf("ai_trained2", "ai_val", "ai_bg", "ai_bg_hint")) assertTrue("$n/$k", t.contains("name=\"$k\"")) }
    }

    // ---- kısmi / tam eğitim kapsamı ----
    @Test fun maskTrainsTheRequestedShareAndIsStable() {
        assertNull(LearnPure.mask(100, 0))
        val m = LearnPure.mask(25, 0)!!
        assertEquals(LearnPure.DIM * 25 / 100, LearnPure.trainable(m)); assertEquals(LearnPure.DIM, LearnPure.trainable(null))
        assertTrue(m.contentEquals(LearnPure.mask(25, 0)!!)); assertFalse(m.contentEquals(LearnPure.mask(25, 1)!!))
        assertEquals(1, LearnPure.trainable(LearnPure.mask(0, 0)))   // en az bir parametre
    }
    @Test fun frozenWeightsDoNotChange() {
        val base = LearnPure.train(data(), 20)
        val m = LearnPure.mask(25, 3)!!
        val w = LearnPure.train(data(), 5, base, 0, m)
        for (i in w.indices) if (!m[i]) assertEquals("dondurulan $i", base[i], w[i], 0.0)
        assertTrue((w.indices).any { m[it] && w[it] != base[it] })
    }
    @Test fun rotatingMasksEventuallyCoverEveryParameter() {
        val covered = BooleanArray(LearnPure.DIM)
        for (r in 0 until 16) LearnPure.mask(25, r)!!.forEachIndexed { i, b -> if (b) covered[i] = true }
        assertTrue("kapsanan ${covered.count { it }}", covered.count { it } >= LearnPure.DIM * 95 / 100)
    }
    @Test fun partialTrainingStillLearnsAndFullFromScratchResets() {
        val part = LearnPure.fit(data(), 80, null, mask = BooleanArray(LearnPure.DIM) { it % 2 == 0 || it == 6 || it == 8 })
        assertTrue("kısmi ${part.valAcc}", part.valAcc >= 80)
        val full = LearnPure.fit(data(), 80, part.w)       // tam kapsam: önceki ağırlıktan
        val fresh = LearnPure.fit(data(), 80, null)        // baştan
        assertTrue(full.valAcc >= 85 && fresh.valAcc >= 85)
    }
    @Test fun bigModelMemoryEstimateAndFeasibility() {
        val t = ModelPure.MODEL_PARAMS
        assertEquals(t / 4, ModelPure.trainableParams(t, 25))
        assertTrue(ModelPure.trainMemBytes(t, 100) > ModelPure.trainMemBytes(t, 25) && ModelPure.trainMemBytes(t, 25) > ModelPure.trainMemBytes(t, 2))
        assertEquals(t * 16, ModelPure.trainMemBytes(t, 100))
        val ram8 = 8L shl 30
        assertFalse(ModelPure.feasibleOnPhone(t, 100, ram8)); assertTrue(ModelPure.feasibleOnPhone(t, 10, ram8))
        assertEquals(50, ModelPure.maxFeasiblePct(t, ram8))
        assertEquals(0, ModelPure.maxFeasiblePct(t, 0)); assertEquals(0, ModelPure.maxFeasiblePct(t, 1L shl 30))
        assertEquals(listOf(2, 5, 10, 25, 50, 100), ModelPure.SCOPES)
    }
    @Test fun scopeIsWiredIntoStoreUiAndExport() {
        val st = src("block/LearnStore.kt")
        assertTrue(st.contains("LearnPure.mask(if (fresh) 100 else scope(c)") && st.contains("if (fresh) null else weights(c)") && st.contains("_plan") && st.contains("scope_pct"))
        val ui = src("settings/ModelCard.kt")
        assertTrue(ui.contains("ModelPure.SCOPES.forEach") && ui.contains("fresh = true") && ui.contains("confirmFresh") && ui.contains("trainMemBytes") && ui.contains("maxFeasiblePct"))
        for ((n, f) in TestFiles.stringFiles()) { val t = f.readText(); for (k in listOf("ai_scope", "ai_rotate", "ai_fresh", "ai_fresh_confirm", "ai_est", "ai_est_ok", "ai_est_no", "ai_params")) assertTrue("$n/$k", t.contains("name=\"$k\"")) }
    }

    // ---- aday değerlendirme (kritik) ----
    @Test fun genericStructuralIdsAreRecognised() {
        assertTrue(LearnPure.generic("main_container")); assertTrue(LearnPure.generic("toolbar_title")); assertTrue(LearnPure.generic("sel:Root"))
        assertFalse(LearnPure.generic("reels_tab")); assertFalse(LearnPure.generic("text:keşfet"))
    }
    @Test fun conflictAndGenericLowerTheScore() {
        val ex = ArrayList<LearnPure.Ex>()
        repeat(20) {
            ex += LearnPure.Ex("sel:reels", 0.9, false, true, true)
            ex += LearnPure.Ex("main_container", 0.95, false, false, false)
            ex += LearnPure.Ex("sel:mesajlar", 0.9, false, false, false, true)
        }
        val w = LearnPure.fit(ex, 80).w
        val good = LearnPure.score(w, UserFeatPure.Cand("sel:shorts", false, 0.9), true)
        assertTrue(good > LearnPure.score(w, UserFeatPure.Cand("top_container", false, 0.9), false))
        assertTrue(good > LearnPure.score(w, UserFeatPure.Cand("sel:shorts", false, 0.9, true), true))
    }
    @Test fun pickSkipsConflictingCandidates() {
        val w = LearnPure.train(data(), 60)
        val c = listOf(UserFeatPure.Cand("sel:reels", false, 0.9, true))
        assertTrue(LearnPure.pick(w, 100, c, setOf("sel:reels")).isEmpty())
    }
    @Test fun metricsAndBestThreshold() {
        val ex = data(); val w = LearnPure.fit(ex, 80).w
        val m = LearnPure.metrics(w, ex)
        assertTrue(m.precision >= 90 && m.recall >= 90 && m.f1 >= 90 && m.acc >= 90)
        assertEquals(0, LearnPure.metrics(w, emptyList()).f1)
        val t = LearnPure.bestThreshold(w, ex); assertTrue(t in 0.5..0.9)
        assertEquals(0.7, LearnPure.bestThreshold(w, ex.take(5)), 0.0)
    }
    @Test fun crossValidationNeedsEnoughDataAndIsSane() {
        assertNull(LearnPure.crossVal(data().take(10)))
        val cv = LearnPure.crossVal(data(), 5, 30)!!; assertTrue("cv f1 ${cv.f1}", cv.f1 >= 85)
    }
    @Test fun oldExampleLinesStillLoad() {
        val old = LearnPure.decode("sel:a\t0.900\t0\t1\t1")!!; assertFalse(old.conflict)
        val neu = LearnPure.decode(LearnPure.encode(LearnPure.Ex("sel:a", 0.9, false, true, true, true)))!!; assertTrue(neu.conflict)
        assertTrue(LearnPure.toJsonl(listOf(neu)).contains("\"conflict\":true"))
    }
    @Test fun candidatesFlagConflictsAndTagsExplainThem() {
        val c = UserFeatPure.candidates(mapOf("sel:reels" to 10, "sel:mesajlar" to 10), 10, emptySet(), conflicts = setOf("sel:mesajlar"))
        assertEquals("sel:reels", c[0].entry); assertTrue(c[1].conflict)
        assertTrue(LearnPure.tags(UserFeatPure.Cand("main_container", true, 0.95, true), true).let { it.contains("🎯") && it.contains("⚠") && it.contains("⛔") && it.contains("💤") })
        assertEquals("📌", LearnPure.tags(UserFeatPure.Cand("sel:x", false, 0.95), false))
    }
    @Test fun criticIsWiredIntoUiAndStore() {
        val e = src("block/Extras.kt")
        assertTrue(e.contains("LearnStore.otherEntries(ctx, appId, featId)") && e.contains("LearnPure.tags(c,") && e.contains("LearnStore.scorer(ctx)") && e.contains("R.string.rl_legend"))
        val st = src("block/LearnStore.kt")
        assertTrue(st.contains("bestThreshold(f.w, ex)") && st.contains("crossVal(ex, 5, 30)") && st.contains("threshold(c))") && st.contains("BlockStore.rules(c).filterKeys"))
        assertTrue(src("block/RuleLab.kt").contains("candidates(LearnStore.otherEntries(c, app, feat))"))
        assertTrue(src("settings/ModelCard.kt").contains("R.string.ai_quality"))
        for ((n, f) in TestFiles.stringFiles()) { val t = f.readText(); assertTrue(n, t.contains("name=\"rl_legend\"") && t.contains("name=\"ai_quality\"")) }
    }

    @Test fun litertRuntimeWired() {
        assertTrue(ModelPure.runnable("a.litertlm")); assertFalse(ModelPure.runnable("a.task"))
        assertEquals(listOf(1, 0), ModelPure.parsePicks("2, 1 ve 99", 3))
        assertTrue(ModelPure.probePrompt("DM", "X", listOf("a", "b")).contains("2. b"))
        assertTrue(src("block/ModelRunner.kt").contains("Engine(") && src("block/ModelRunner.kt").contains("createConversation"))
        assertTrue(src("settings/ModelCard.kt").contains("ModelRunner.ask"))
    }

    @Test fun balancedWeightAndStratifiedSplit() {
        val ex = (0 until 50).map { LearnPure.Ex("e$it", 0.5, false, false, it < 5) }
        assertEquals(6.0, LearnPure.posWeight(ex), 0.0); assertEquals(2.0, LearnPure.posWeight(ex.take(3).filter { it.label }), 0.0)
        val (tr, va) = LearnPure.split(ex)
        assertEquals(50, tr.size + va.size); assertTrue(va.any { it.label }); assertTrue(tr.count { it.label } >= 4)
    }
    @Test fun modelEngineCachedAndSuggestionWired() {
        val r = src("block/ModelRunner.kt")
        assertTrue(r.contains("engineFor") && r.contains("fun release") && r.contains("fun rank"))
        assertTrue(src("block/ModelDownloader.kt").contains("ModelRunner.release()"))
        assertTrue(src("block/Extras.kt").contains("ModelRunner.rank"))
    }

    @Test fun engineBlendAndSmileWiring() {
        assertEquals(0.4, LearnPure.blend(LearnPure.ENG_BUILTIN, 0.4, 0.9), 1e-9)
        assertEquals(0.9, LearnPure.blend(LearnPure.ENG_SMILE, 0.4, 0.9), 1e-9)
        assertEquals(0.65, LearnPure.blend(LearnPure.ENG_BOTH, 0.4, 0.9), 1e-9)
        assertEquals(0.4, LearnPure.blend(LearnPure.ENG_BOTH, 0.4, null), 1e-9)
        val cs = listOf(UserFeatPure.Cand("a", false), UserFeatPure.Cand("b", false), UserFeatPure.Cand("c", true))
        assertEquals(listOf("b", "a"), LearnPure.pickBy(30, cs, 0.5) { if (it.entry == "b") 0.9 else if (it.entry == "a") 0.6 else 0.99 })
        assertTrue(LearnPure.pickBy(5, cs) { 1.0 }.isEmpty())
        assertTrue(src("block/SmileTrainer.kt").contains("LogisticRegression.fit"))
        assertTrue(src("block/LearnStore.kt").contains("SmileTrainer.fit") && src("block/LearnStore.kt").contains("fun scorer"))
        assertTrue(src("settings/ModelCard.kt").contains("setEngine"))
    }

    // ---- gelişmiş katman (Adam, yenilik ağırlığı, kalibrasyon, neden, aktif öğrenme) ----
    @Test fun adamLearnsAndIsRepeatable() {
        val ex = data()
        val w = com.odak.app.logic.LearnPlus.trainAdam(ex, 30)
        assertTrue("doğruluk ${LearnPure.accuracy(w, ex)}", LearnPure.accuracy(w, ex) >= 90)
        assertEquals(LearnPure.encodeW(w), LearnPure.encodeW(com.odak.app.logic.LearnPlus.trainAdam(ex, 30)))
        val mask = LearnPure.mask(25, 0)!!
        val w2 = com.odak.app.logic.LearnPlus.trainAdam(ex, 10, w, 0, mask)
        for (j in 0 until LearnPure.DIM) if (!mask[j]) assertEquals(w[j], w2[j], 0.0)
    }
    @Test fun recencyWeightsNewerMore() {
        assertEquals(0.4, com.odak.app.logic.LearnPlus.recency(0, 10), 1e-9); assertEquals(1.0, com.odak.app.logic.LearnPlus.recency(9, 10), 1e-9)
        val ex = com.odak.app.logic.LearnPlus.weighted(data()); assertTrue(ex.first().weight < ex.last().weight)
        assertEquals(1.0, com.odak.app.logic.LearnPlus.recency(0, 1), 0.0)
    }
    @Test fun exampleWeightRoundTripsAndOldRowsStillRead() {
        val e = LearnPure.Ex("a", 0.5, false, true, true, false, 0.6)
        val d = LearnPure.decode(LearnPure.encode(e))!!; assertEquals(0.6, d.weight, 1e-3)
        assertEquals(1.0, LearnPure.decode(LearnPure.encode(LearnPure.Ex("a", 0.5, false, true, true)))!!.weight, 0.0)
        assertEquals(1.0, LearnPure.decode("a\t0.5\t0\t1\t1")!!.weight, 0.0)
    }
    @Test fun calibrationEncodesAndKeepsOrder() {
        val c = com.odak.app.logic.LearnPlus.Calib.decode("1.5000,-0.2000"); assertEquals(1.5, c.a, 1e-9)
        assertTrue(c.apply(0.9) > c.apply(0.6) && c.apply(0.6) > c.apply(0.2))
        assertEquals(com.odak.app.logic.LearnPlus.Calib.NONE.a, com.odak.app.logic.LearnPlus.Calib.decode("bozuk").a, 0.0)
        val ex = data(); val w = com.odak.app.logic.LearnPlus.trainAdam(ex, 20)
        val cal = com.odak.app.logic.LearnPlus.calibrate(w, ex)
        assertTrue(com.odak.app.logic.LearnPlus.ece(w, ex, cal) in 0..100)
        assertEquals(com.odak.app.logic.LearnPlus.Calib.NONE.a, com.odak.app.logic.LearnPlus.calibrate(w, ex.take(5)).a, 0.0)
    }
    @Test fun explainAndUncertaintyPickSensibleThings() {
        val ex = data(); val w = com.odak.app.logic.LearnPlus.trainAdam(ex, 30)
        val c = UserFeatPure.Cand("clips_viewer", false, 0.95)
        assertTrue(com.odak.app.logic.LearnPlus.explain(w, c, true).isNotEmpty())
        val cs = listOf(UserFeatPure.Cand("a", false), UserFeatPure.Cand("b", false), UserFeatPure.Cand("c", true))
        assertEquals(setOf("b"), com.odak.app.logic.LearnPlus.uncertain(cs, 1) { if (it.entry == "a") 0.95 else if (it.entry == "b") 0.52 else 0.5 })
    }
    @Test fun advancedEngineWired() {
        assertEquals(3, LearnPure.ENG_ADV); assertEquals(0.65, LearnPure.blend(LearnPure.ENG_ADV, 0.4, 0.9), 1e-9)
        assertTrue(src("block/LearnStore.kt").contains("trainAdam") && src("block/LearnStore.kt").contains("learn_cal"))
        assertTrue(src("settings/ModelCard.kt").contains("ENG_ADV"))
        assertTrue(src("block/Extras.kt").contains("LearnPlus.explain") && src("block/Extras.kt").contains("LearnPlus.uncertain"))
    }

    // ---- eğitim eleştirmeni (Apache Commons Math) ----
    @Test fun criticAucAndIntervalAndConflicts() {
        val ex = data(); val w = LearnPure.train(ex, 60)
        assertTrue(com.odak.app.logic.CriticPure.auc(w, ex) >= 95); assertEquals(0, com.odak.app.logic.CriticPure.auc(w, ex.filter { it.label }))
        val (lo, hi) = com.odak.app.logic.CriticPure.interval(100, 90); assertTrue(lo in 80..89 && hi in 90..100)
        assertEquals(0 to 0, com.odak.app.logic.CriticPure.interval(0, 0))
        val dup = ex + LearnPure.Ex("sel:reels", 0.9, false, true, false)
        assertEquals(1, com.odak.app.logic.CriticPure.conflicts(dup)); assertEquals(0, com.odak.app.logic.CriticPure.conflicts(ex))
    }
    @Test fun criticFindsSuspiciousLabelAndComparesEngines() {
        val ex = data() + LearnPure.Ex("sel:reels2", 0.9, false, true, false)
        val w = LearnPure.train(ex, 60)
        assertTrue(com.odak.app.logic.CriticPure.suspicious(w, ex, 0.3).contains("sel:reels2"))
        assertEquals(1.0, com.odak.app.logic.CriticPure.pairedP(doubleArrayOf(.9, .8, .7), doubleArrayOf(.9, .8, .7))!!, 0.0)
        val p = com.odak.app.logic.CriticPure.pairedP(doubleArrayOf(.9, .95, .92, .94, .93), doubleArrayOf(.5, .55, .52, .6, .5))!!; assertTrue(p < 0.05)
        assertNull(com.odak.app.logic.CriticPure.pairedP(doubleArrayOf(.9), doubleArrayOf(.8)))
        assertEquals("<0.001", com.odak.app.logic.CriticPure.fmtP(0.0001)); assertEquals("–", com.odak.app.logic.CriticPure.fmtP(null))
    }
    @Test fun criticReviewNeedsEnoughExamplesAndIsWired() {
        assertNull(com.odak.app.logic.CriticPure.review(data().take(20)))
        val r = com.odak.app.logic.CriticPure.review(data())!!; assertEquals(60, r.n); assertTrue(r.acc >= 90 && r.accLo <= r.acc && r.accHi >= r.acc)
        assertTrue(src("settings/ModelCard.kt").contains("CriticPure.review"))
    }

    // ---- çok katmanlı güven (olasılık + uyum + kararlılık + destek) ----
    @Test fun bootstrapIsRepeatableAndRoundTrips() {
        val b = com.odak.app.logic.LearnConf.bootstrap(data()); assertEquals(8, b.size)
        assertEquals(com.odak.app.logic.LearnConf.encodeBoots(b), com.odak.app.logic.LearnConf.encodeBoots(com.odak.app.logic.LearnConf.bootstrap(data())))
        assertEquals(8, com.odak.app.logic.LearnConf.decodeBoots(com.odak.app.logic.LearnConf.encodeBoots(b)).size)
        assertTrue(com.odak.app.logic.LearnConf.bootstrap(data().take(5)).isEmpty()); assertTrue(com.odak.app.logic.LearnConf.decodeBoots(null).isEmpty())
        val x = LearnPure.features("sel:reels", 0.9, false, true)
        val (m, sd) = com.odak.app.logic.LearnConf.bag(b, x); assertTrue(m > 0.7 && sd >= 0.0 && sd < 0.3)
    }
    @Test fun supportCountsSimilarExamples() {
        val s = com.odak.app.logic.LearnConf.Support(data())
        assertTrue(s.count("sel:reels", LearnPure.features("sel:reels", 0.9, false, true)) >= 15)
        assertTrue(s.count("zzzz_qqq", LearnPure.features("zzzz_qqq", 0.5, false, false)) < 10)
        assertTrue(com.odak.app.logic.LearnConf.supportFactor(0) < com.odak.app.logic.LearnConf.supportFactor(2) && com.odak.app.logic.LearnConf.supportFactor(2) < com.odak.app.logic.LearnConf.supportFactor(10))
    }
    @Test fun confidenceDropsOnDisagreementInstabilityAndLowSupport() {
        val b = com.odak.app.logic.LearnConf.bootstrap(data()); val x = LearnPure.features("sel:reels", 0.9, false, true)
        val good = com.odak.app.logic.LearnConf.assess(0.95, b, x, 0.94, 20)
        val split = com.odak.app.logic.LearnConf.assess(0.95, b, x, 0.30, 20)
        val thin = com.odak.app.logic.LearnConf.assess(0.95, b, x, 0.94, 0)
        assertEquals(com.odak.app.logic.LearnConf.HIGH, good.level); assertTrue(split.score < good.score); assertTrue(thin.score < good.score)
        assertEquals(com.odak.app.logic.LearnConf.LOW, com.odak.app.logic.LearnConf.assess(0.3, b, x, null, 20).level)
        assertEquals(com.odak.app.logic.LearnConf.MID, com.odak.app.logic.LearnConf.levelOf(0.5))
        assertEquals("🟢", com.odak.app.logic.LearnConf.symbol(2)); assertTrue(com.odak.app.logic.LearnConf.plusMinus(good) >= 0)
    }
    @Test fun confidenceWiredIntoStoreAndUi() {
        val st = src("block/LearnStore.kt")
        assertTrue(st.contains("fun confer") && st.contains("LearnConf.bootstrap") && st.contains("LearnConf.HIGH"))
        assertTrue(src("block/Extras.kt").contains("LearnConf.symbol") && src("block/Extras.kt").contains("plusMinus"))
    }

    // ---- eğitim araç takımı: otomatik ayar, öğrenme eğrisi, sürüm kontrol noktaları ----
    @Test fun autoTuneSearchesGridAndNeedsData() {
        val t = com.odak.app.logic.LearnTune.tune(data())!!
        assertEquals(9, t.tried); assertTrue(t.best.lr in com.odak.app.logic.LearnTune.LRS && t.best.l2 in com.odak.app.logic.LearnTune.L2S); assertTrue(t.f1 >= 80)
        assertNull(com.odak.app.logic.LearnTune.tune(data().take(10)))
        assertNull(com.odak.app.logic.LearnTune.tune(data().filter { it.label }))
    }
    @Test fun learningCurveAndVerdict() {
        val c = com.odak.app.logic.LearnTune.curve(data())!!; assertEquals(4, c.size); assertTrue(c.all { it in 0..100 })
        assertNull(com.odak.app.logic.LearnTune.curve(data().take(10)))
        assertEquals(1, com.odak.app.logic.LearnTune.verdict(listOf(40, 55, 70, 85))); assertEquals(2, com.odak.app.logic.LearnTune.verdict(listOf(88, 90, 91, 92)))
    }
    @Test fun checkpointsRoundTripAndRollbackRule() {
        val w = LearnPure.train(data(), 10)
        val k = com.odak.app.logic.LearnTune.Ckpt(123L, 90, w)
        val d = com.odak.app.logic.LearnTune.decode(com.odak.app.logic.LearnTune.encode(k))!!; assertEquals(90, d.f1); assertEquals(123L, d.ts)
        assertNull(com.odak.app.logic.LearnTune.decode("bozuk"))
        var l = emptyList<com.odak.app.logic.LearnTune.Ckpt>(); repeat(5) { l = com.odak.app.logic.LearnTune.push(l, com.odak.app.logic.LearnTune.Ckpt(it.toLong(), 80, w)) }
        assertEquals(3, l.size); assertEquals(4L, l.last().ts)
        assertTrue(com.odak.app.logic.LearnTune.rollbackNeeded(70, k)); assertFalse(com.odak.app.logic.LearnTune.rollbackNeeded(85, k)); assertFalse(com.odak.app.logic.LearnTune.rollbackNeeded(10, null))
    }
    @Test fun toolsWiredIntoStoreAndCard() {
        val st = src("block/LearnStore.kt")
        assertTrue(st.contains("fun autoTune") && st.contains("fun rollback") && st.contains("rollbackNeeded") && st.contains("l2(c), lr(c)"))
        val mc = src("settings/ModelCard.kt"); assertTrue(mc.contains("autoTune") && mc.contains("LearnStore.curve") && mc.contains("LearnStore.rollback"))
    }

    // ---- ONNX Runtime (içe aktarılan sınıflandırıcı) ----
    @Test fun onnxOutputToProbability() {
        assertEquals(0.8, ModelPure.pickProbability(floatArrayOf(0.2f, 0.8f))!!, 1e-6)
        assertTrue(ModelPure.pickProbability(floatArrayOf(-2f, 3f))!! > 0.95)
        assertEquals(0.3, ModelPure.pickProbability(floatArrayOf(0.3f))!!, 1e-6); assertTrue(ModelPure.pickProbability(floatArrayOf(4f))!! > 0.98)
        assertNull(ModelPure.pickProbability(floatArrayOf(1f, 2f, 3f))); assertNull(ModelPure.pickProbability(FloatArray(0)))
        assertTrue(ModelPure.onnx("a.ONNX") && !ModelPure.onnx("a.litertlm"))
        assertEquals(0.5, LearnPure.blendOnnx(0.4, 0.6), 1e-9); assertEquals(0.4, LearnPure.blendOnnx(0.4, null), 1e-9); assertEquals(4, LearnPure.ENG_ONNX)
    }
    @Test fun onnxWiredAndPythonTrainerMatchesFeatures() {
        assertTrue(src("block/OnnxScorer.kt").contains("createSession") && src("block/OnnxScorer.kt").contains("pickProbability"))
        assertTrue(src("block/LearnStore.kt").contains("ExtScorer.prob") && src("settings/ModelCard.kt").contains("ENG_ONNX"))
        assertTrue(src("block/ModelDownloader.kt").contains("fun find") && src("block/ModelRunner.kt").contains("find(c, \".litertlm\")"))
        val py = File(TestFiles.main, "../../../tools/train_onnx.py").let { if (it.exists()) it.readText() else "" }
        if (py.isNotEmpty()) assertTrue(py.contains("DIM = BASE + WORDS + GRAMS") && py.contains("BASE, WORDS, GRAMS = 16, 64, 64") && py.contains("skl2onnx"))
    }

    // ---- TensorFlow Lite / PyTorch Mobile / ExecuTorch ----
    @Test fun runtimeChosenByExtension() {
        assertEquals("onnx", ModelPure.kind("a.onnx")); assertEquals("tflite", ModelPure.kind("A.TFLITE")); assertEquals("torch", ModelPure.kind("m.ptl")); assertEquals("executorch", ModelPure.kind("m.pte"))
        assertNull(ModelPure.kind("m.bin")); assertNull(ModelPure.kind("m.litertlm"))
        assertTrue(floatArrayOf(0f, 1f).contentEquals(ModelPure.oneHot(true))); assertTrue(floatArrayOf(1f, 0f).contentEquals(ModelPure.oneHot(false)))
        assertEquals(listOf(0..15, 16..31, 32..34), ModelPure.batches(35, 16).map { it.first..it.last }); assertTrue(ModelPure.batches(0, 16).isEmpty())
    }
    @Test fun threeRuntimesWiredAndScriptsPresent() {
        assertTrue(src("block/TfliteRunner.kt").contains("runSignature") && src("block/TfliteRunner.kt").contains("\"train\"") && src("block/TfliteRunner.kt").contains("\"save\""))
        assertTrue(src("block/TorchRunner.kt").contains("LiteModuleLoader.load") && src("block/TorchRunner.kt").contains("EtModule.load"))
        val sc = src("block/ExtScorer.kt"); assertTrue(sc.contains("TfliteRunner.prob") && sc.contains("probTorch") && sc.contains("probExecutorch") && sc.contains("OnnxScorer.prob"))
        assertTrue(src("block/LearnStore.kt").contains("ExtScorer.prob") && src("block/LearnStore.kt").contains("TfliteRunner.train"))
        for (n in listOf("export_tflite_train.py", "export_pytorch.py")) { val f = File(TestFiles.main, "../../../tools/$n"); if (f.exists()) assertTrue(f.readText().contains("144")) }
    }
}
