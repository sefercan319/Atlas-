plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.odak.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.odak.app"
        minSdk = 33
        targetSdk = 37
        // Yalnız 64 bit ARM: LiteRT-LM yerel kütüphaneleri sadece bunun için gerekli, APK çok küçülür.
        ndk { abiFilters += listOf("arm64-v8a") }
        versionCode = 168
        versionName = "0.56.111"
    }

    // Sabit imza: her derlemede aynı anahtar kullanılır, böylece yeni APK eskinin üstüne güncelleme olarak kurulur.
    signingConfigs {
        create("atlas") {
            storeFile = file("atlas-release.jks")
            storePassword = "atlas2026"
            keyAlias = "atlas"
            keyPassword = "atlas2026"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("atlas") }
        getByName("release") { signingConfig = signingConfigs.getByName("atlas") }
    }

    // Smile / LiteRT-LM / pdfbox aynı META-INF dosyalarını getirir: çakışmayı derleme hatası yapmasın.
    packaging {
        resources {
            excludes += listOf(
                "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/INDEX.LIST", "META-INF/*.kotlin_module.bak",
                "META-INF/AL2.0", "META-INF/LGPL2.1", "META-INF/io.netty.versions.properties", "META-INF/versions/**", "**/module-info.class",
                "META-INF/*.SF", "META-INF/*.DSA", "META-INF/*.RSA", "META-INF/MANIFEST.MF"
            )
            pickFirsts += listOf("**/*.properties", "META-INF/services/**", "**/*.txt")
        }
        jniLibs { pickFirsts += listOf("**/libc++_shared.so", "**/libfbjni.so") }
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.10.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.caverock:androidsvg-aar:1.4")
    implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")
    implementation("com.github.haifengl:smile-core:3.1.1") {
        // Java masaüstü / yerel BLAS bağımlılıkları Android'de gereksiz ve çakışma çıkarır.
        exclude(group = "org.bytedeco")
        exclude(group = "org.slf4j")
    }
    implementation("org.slf4j:slf4j-nop:2.0.16")
    // Apache Commons Math: yaygın, açık kaynaklı istatistik kütüphanesi (güven aralığı, t-testi) — eğitim eleştirmeni için
    implementation("org.apache.commons:commons-math3:3.6.1")
    // ONNX Runtime (Microsoft): bilgisayarda/Colab'da eğitilen sınıflandırıcıyı cihazda çalıştırır
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")
    // TensorFlow Lite (Google): çıkarım + cihazda eğitim imzaları
    implementation("org.tensorflow:tensorflow-lite:2.16.1")
    // PyTorch Mobile (.ptl) ve ExecuTorch (.pte): içe aktarılan sınıflandırıcıyı cihazda çalıştırır
    implementation("org.pytorch:pytorch_android_lite:1.13.1")
    implementation("org.pytorch:executorch-android:0.5.0")

    testImplementation("junit:junit:4.13.2")
}
