package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class TurkishSearchTest {
    @Test fun dottedAndDotlessI() {
        assertTrue(Pure.nameMatches("İş toplantısı", "is"))
        assertTrue(Pure.nameMatches("ISIK", "ışık"))
        assertTrue(Pure.nameMatches("Çocuk okula git", "cocuk"))
        assertFalse(Pure.nameMatches("Süt al", "ekmek"))
    }
    @Test fun blankQueryMatchesAll() { assertTrue(Pure.nameMatches("x", "   ")) }
    @Test fun todoAndPlanSearchUseSharedMatcher() {
        val t = File(TestFiles.code, "com/odak/app/todo/TodoScreen.kt").readText()
        val p = File(TestFiles.code, "com/odak/app/plan/PlanCommon.kt").readText()
        assertTrue(t.contains("Pure.nameMatches(it.title, query)") && !t.contains("ignoreCase = true"))
        assertTrue(p.contains("Pure.nameMatches(it.title, q)") && !p.contains("title.contains(q.trim(), ignoreCase = true)"))
    }
}
