package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test

/** Kotlin derleyicisi yalnız GitHub'da görülen Compose hataları: inline olmayan lambdada @Composable çağrısı. */
class ComposeSafetyTest {
    @Test fun noStringResourceInsideNonInlineLambdas() {
        val re = Regex("""(joinToString\([^)]*\)|sortedBy|sortedWith\([^)]*\))\s*\{[^}]*stringResource\(""")
        val bad = TestFiles.kotlinSources().filter { re.containsMatchIn(it.readText()) }.map { it.name }
        assertTrue("Composable çağrısı yasak lambdada: $bad", bad.isEmpty())
    }
}
