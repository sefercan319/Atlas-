package com.odak.app

import com.odak.app.logic.PermKind
import com.odak.app.logic.PermNeeds
import com.odak.app.logic.PermPlan
import com.odak.app.logic.PermStep
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class PermGuideTest {
    private fun code(p: String) = File(TestFiles.code, p).readText()

    @Test fun detailPagesByApiLevel() {
        assertFalse(PermPlan.hasDetailPage(PermKind.ACC, 33)); assertTrue(PermPlan.hasDetailPage(PermKind.ACC, 34))
        assertTrue(PermPlan.hasDetailPage(PermKind.NOTIF, 33)); assertTrue(PermPlan.hasDetailPage(PermKind.USAGE, 33))
    }
    @Test fun restrictedHintOnlyWhereItHappens() {
        assertTrue(PermPlan.mayBeRestricted(PermKind.ACC, 33)); assertTrue(PermPlan.mayBeRestricted(PermKind.NOTIF, 36))
        assertFalse(PermPlan.mayBeRestricted(PermKind.USAGE, 36)); assertFalse(PermPlan.mayBeRestricted(PermKind.ACC, 31))
    }
    @Test fun stepKeysExistInAllLocales() {
        val keys = (PermKind.values().flatMap { k -> listOf(PermPlan.stepKey(k, true), PermPlan.stepKey(k, false)) } +
            listOf("pg_restricted", "pg_appinfo", "pg_open")).toSet()
        for ((n, f) in TestFiles.stringFiles()) { val t = f.readText(); for (k in keys) assertTrue("$n $k", t.contains("name=\"$k\"")) }
    }
    @Test fun grantButtonsOpenGuideAndExactPage() {
        val go = code("com/odak/app/block/PermGuide.kt")
        assertTrue(go.contains("ACTION_ACCESSIBILITY_DETAIL_SETTINGS") && go.contains("ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS"))
        assertTrue(go.contains("package:") && go.contains("ACTION_APPLICATION_DETAILS_SETTINGS"))
        // eski doğrudan genel-ayar çağrıları kalmamalı
        for (f in listOf("block/BlockScreen.kt", "block/ScreenTimeScreen.kt", "block/Extras.kt", "settings/PermCard.kt")) {
            val s = code("com/odak/app/$f")
            assertTrue(f, s.contains("PermGuideDialog") || s.contains("guide ="))
            assertFalse(f, s.contains("Launch.go(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)"))
            assertFalse(f, s.contains("ACTION_USAGE_ACCESS_SETTINGS") || s.contains("ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
    }

    @Test fun restrictedGoesToAppInfoFirstOtherwiseDirectPage() {
        assertEquals(PermStep.APP_INFO, PermPlan.firstStep(PermKind.ACC, 34, true))
        assertEquals(PermStep.APP_INFO, PermPlan.firstStep(PermKind.NOTIF, 33, true))
        assertEquals(PermStep.PAGE, PermPlan.firstStep(PermKind.ACC, 34, false))
        assertEquals(PermStep.PAGE, PermPlan.firstStep(PermKind.USAGE, 34, true))
        assertEquals(PermStep.PAGE, PermPlan.firstStep(PermKind.BATT, 34, true))
        assertEquals(PermStep.PAGE, PermPlan.firstStep(PermKind.ACC, 31, true))
    }
    @Test fun featureNeeds() {
        assertEquals(PermKind.ACC, PermNeeds.BLOCK.first { it.second }.first)
        assertEquals(listOf(PermKind.USAGE, PermKind.BATT), PermNeeds.BLOCK.filter { !it.second }.map { it.first })
        assertEquals(listOf(PermKind.NOTIF to true), PermNeeds.NOTIF_HIDE)
        assertEquals(listOf(PermKind.USAGE to true), PermNeeds.SCREEN_TIME)
        assertEquals(3, PermNeeds.missing(PermNeeds.BLOCK, emptySet()).size)
        assertEquals(listOf(PermKind.ACC to true), PermNeeds.requiredMissing(PermNeeds.BLOCK, setOf(PermKind.USAGE)))
        assertTrue(PermNeeds.requiredMissing(PermNeeds.BLOCK, setOf(PermKind.ACC)).isEmpty())
    }
    @Test fun noMiddleDialogAndAllGrantsGoThroughPermGo() {
        val go = code("com/odak/app/block/PermGuide.kt")
        assertFalse(go.contains("AlertDialog"))
        assertTrue(go.contains("fun grant(") && go.contains("access_restricted_settings") && go.contains("ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"))
        assertTrue(code("com/odak/app/block/BlockScreen.kt").contains("PermNeedCard(com.odak.app.logic.PermNeeds.BLOCK)"))
        assertFalse(code("com/odak/app/settings/PermCard.kt").contains("ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"))
    }
    @Test fun permStringsInAllLocales() {
        val keys = listOf("pw_title", "perm_required", "perm_optional", "pw_acc", "pw_usage", "pw_batt", "pw_notif", "pg_batt_steps", "pg_appinfo_gray", "pg_done")
        for ((n, f) in TestFiles.stringFiles()) { val t = f.readText(); for (k in keys) assertTrue("$n $k", t.contains("name=\"$k\"")) }
    }
}
