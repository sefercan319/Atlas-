package com.odak.app

import com.odak.app.docs.DocKind
import com.odak.app.docs.DocParse
import com.odak.app.logic.AppList
import com.odak.app.logic.MoreAppsData3
import com.odak.app.logic.Pure
import com.odak.app.logic.UserFeatPure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class UserFeatTest {
    private fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()

    // ---- kendi özelliğini tanımlama ----
    @Test fun idIsStableAndSafe() {
        assertEquals("u:keşfet", UserFeatPure.id(" Keşfet "))
        assertEquals(UserFeatPure.id("Reels!"), UserFeatPure.id("reels"))
        assertTrue(UserFeatPure.id("😀😀").startsWith("u:"))
        assertTrue(UserFeatPure.id("a/b c|d").none { it == '/' || it == ' ' || it == '|' })
    }
    @Test fun cleanNameStripsSeparators() {
        assertEquals("a b", UserFeatPure.cleanName("a|\tb"))
        assertEquals(UserFeatPure.MAX_NAME, UserFeatPure.cleanName("x".repeat(100)).length)
    }
    @Test fun serializeRoundTripAndDedupe() {
        val l = listOf(UserFeatPure.UF("c:a.b", "u:x", "X"), UserFeatPure.UF("c:a.b", "u:x", "X"), UserFeatPure.UF("bluesky", "u:feed", "Feed"))
        val back = UserFeatPure.parse(UserFeatPure.serialize(l))
        assertEquals(2, back.size); assertEquals("Feed", back[1].name)
        assertTrue(UserFeatPure.parse("bozuk\nsatır").isEmpty())
        assertTrue(UserFeatPure.exists(back, "bluesky", "feed")); assertFalse(UserFeatPure.exists(back, "x", "feed"))
    }
    @Test fun everyTemplateIsUsableByTheEngine() {
        for ((k, rules) in UserFeatPure.TEMPLATES) {
            assertTrue(k, rules.isNotEmpty())
            for (r in rules) assertTrue("$k:$r", r.startsWith("sel:") || r.startsWith("desc:") || r.startsWith("text:"))
        }
        val map = mapOf("bsky/u:explore" to UserFeatPure.templateRules("explore"))
        assertTrue(Pure.matches(Pure.Snap(emptySet(), sel = setOf("keşfet")), map, "bsky", "u:explore"))
        assertFalse(Pure.matches(Pure.Snap(emptySet(), sel = setOf("home")), map, "bsky", "u:explore"))
        assertTrue(UserFeatPure.templateRules("yok").isEmpty())
    }
    @Test fun manualEntryTypes() {
        assertEquals("text:reels", UserFeatPure.manualEntry("text", " Reels "))
        assertEquals("desc:keşfet", UserFeatPure.manualEntry("desc", "KEŞFET"))
        assertEquals("sel:home", UserFeatPure.manualEntry("sel", "Home"))
        assertEquals("ReelsTab", UserFeatPure.manualEntry("id", "ReelsTab"))   // kimlik büyük/küçük harfe duyarlı
        assertNull(UserFeatPure.manualEntry("id", "a b")); assertNull(UserFeatPure.manualEntry("text", "a"))
        assertNull(UserFeatPure.manualEntry("text", "x".repeat(61))); assertNull(UserFeatPure.manualEntry("zzz", "abcd"))
        assertNull(UserFeatPure.manualEntry("text", "satır\nsonu"))
    }
    @Test fun manualRuleActuallyBlocksOnlyThatScreen() {
        val rules = mapOf("c:x.y/u:f" to listOf(UserFeatPure.manualEntry("text", "Reels")!!))
        assertTrue(Pure.matches(Pure.Snap(emptySet(), texts = setOf("reels", "x")), rules, "c:x.y", "u:f"))
        assertFalse(Pure.matches(Pure.Snap(emptySet(), texts = setOf("home")), rules, "c:x.y", "u:f"))
    }
    @Test fun mergeKeepsOldRulesAndCaps() {
        assertEquals(listOf("a", "b", "c"), UserFeatPure.merge(listOf("a", "b"), listOf("b", "c")))
        assertEquals(UserFeatPure.MAX_RULES, UserFeatPure.merge(List(30) { "r$it" }, emptyList()).size)
    }

    // ---- desc/text türetme ----
    @Test fun deriveWordsPicksStableDistinctiveLabels() {
        val pos = mapOf("reels" to 9, "home" to 10, "ok" to 10, "12345" to 10, "story ring" to 3)
        val neg = setOf("home", "feed")
        assertEquals(listOf("desc:reels"), Pure.deriveWords("desc:", pos, 10, neg))   // home negatifte, ok kısa, 12345 harfsiz, story ring seyrek
        assertTrue(Pure.deriveWords("text:", pos, 0, neg).isEmpty())
        assertTrue(Pure.deriveWords("text:", mapOf("a".repeat(41) to 10), 10, emptySet()).isEmpty())
    }

    // ---- bağlantılar ----
    @Test fun featuresAreDynamicAndWired() {
        val d = src("block/BlockData.kt")
        assertTrue(d.contains("private val fixed: List<Feat>") && d.contains("fixed + UserFeats.of(id)"))
        assertTrue(d.contains("UserFeats.load(c)") && d.contains("UserFeats.removeAll(c, id)"))
        val u = src("block/UserFeats.kt")
        assertTrue(u.contains("RuleLab.addEntries") && u.contains("RuleLab.removeSaved") && u.contains("setFeatureBlocked(c, app, id, false)"))
        val ui = src("block/BlockScreen.kt")
        assertTrue(ui.contains("AddFeatDialog(app.id)") && ui.contains("UserFeats.remove(ctx, app.id, f.id)"))
        assertTrue("silme yalnız engel kapalıyken", ui.contains("f.id.startsWith(\"u:\") && !on"))
        assertTrue(src("block/Extras.kt").contains("fun AddFeatDialog") && src("block/Extras.kt").contains("RuleLab.addManual"))
        assertTrue(src("block/OdakAccessibilityService.kt").contains("RuleLab.feed(seen, snap.sel, snap.descs, snap.texts)"))
        assertTrue(src("block/RuleLab.kt").contains("deriveWords(\"desc:\"") && src("block/RuleLab.kt").contains("merge(saved(c, app, feat), add)"))
    }
    @Test fun biometricPromptIsCancelledWhenGateLeaves() {
        assertTrue(src("block/Bio.kt").contains("fun cancel()") && src("block/Bio.kt").contains("fresh()"))
        assertTrue(src("block/Pin.kt").contains("onDispose { Bio.cancel() }"))
    }
    @Test fun newStringsInAllLocales() {
        val keys = listOf("uf_add", "uf_name", "uf_create", "uf_tpl", "uf_del", "uf_exists", "tpl_short", "tpl_stories", "tpl_live", "tpl_msg", "tpl_explore", "tpl_shop", "tpl_comments", "tpl_feed", "tpl_games", "rl_manual", "rl_t_id", "rl_t_text", "rl_t_desc", "rl_t_sel", "rl_value", "rl_add", "rl_added", "rl_hint_manual", "rl_saved_list")
        for ((n, f) in TestFiles.stringFiles()) { val t = f.readText(); for (k in keys) assertTrue("$n/$k", t.contains("name=\"$k\"")) }
    }

    // ---- büyük uygulama listesi ----
    @Test fun thirdAppGroupIsValidAndWired() {
        val e = AppList.parse(MoreAppsData3.ALL)
        assertTrue("uygulama sayısı ${e.size}", e.size >= 400)
        val re = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+")
        for (x in e) { assertTrue(x.pkg, re.matches(x.pkg)); assertTrue(x.name, x.name.length in 1..40) }
        assertEquals(e.size, e.map { it.pkg }.toSet().size)
        assertTrue(src("block/BlockData.kt").contains("MoreAppsData3.ALL"))
    }

    // ---- ODS / ODP resimleri ----
    private val png = byteArrayOf(0x89.toByte(), 'P'.code.toByte(), 'N'.code.toByte(), 'G'.code.toByte(), 13, 10, 26, 10) + ByteArray(32)
    @Test fun odsImagesAreMatchedToTheirSheet() {
        val xml = """<office:spreadsheet><table:table table:name="Bir"><draw:frame><draw:image xlink:href="Pictures/a.png"/></draw:frame></table:table>
            <table:table table:name="İki"></table:table></office:spreadsheet>"""
        val r = DocParse.odfImageBlocks(DocKind.ODS, xml, mapOf("Pictures/a.png" to png))
        assertEquals(2, r.size); assertEquals("Bir", r[0].first); assertEquals(1, r[0].second.size); assertEquals(0, r[1].second.size)
    }
    @Test fun odpImagesFollowSlideOrderAndMissingFilesAreSkipped() {
        val xml = """<draw:page draw:name="s1"><draw:image xlink:href="./Pictures/x.png"/><draw:image xlink:href="Pictures/yok.png"/></draw:page><draw:page draw:name="s2"/>"""
        val r = DocParse.odfImageBlocks(DocKind.ODP, xml, mapOf("Pictures/x.png" to png))
        assertEquals(2, r.size); assertEquals(1, r[0].second.size); assertTrue(r[1].second.isEmpty())
    }
    @Test fun pdfPageImagesAreWired() {
        val p = src("docs/DocPdf.kt")
        assertTrue(p.contains("pageImages(") && p.contains("PDImageXObject") && p.contains("imgs: List<RImg>"))
        assertTrue(src("docs/DocParse.kt").contains("odfWithImages("))
    }

    @Test fun candidatesWorkWithSingleRecording() {
        val pos = mapOf("sel:reels" to 10, "text:home" to 10, "ReelsTab" to 9, "text:ab" to 10, "desc:12345" to 10, "text:nadir yazı" to 2)
        val c = UserFeatPure.candidates(pos, 10, setOf("text:home"))
        assertEquals(listOf("sel:reels", "ReelsTab", "text:home"), c.map { it.entry })
        assertTrue(c.first { it.entry == "text:home" }.inNeg); assertFalse(c.first { it.entry == "sel:reels" }.inNeg)
        assertEquals("negatifte olmayanlar önce", "text:home", c.last().entry)
        assertTrue(UserFeatPure.candidates(pos, 0, emptySet()).isEmpty())
    }
    @Test fun pickerIsWired() {
        val l = src("block/RuleLab.kt"); val u = src("block/Extras.kt")
        assertTrue(l.contains("fun toggle(") && l.contains("fun toSave()") && l.contains("val r = toSave()"))
        assertTrue(u.contains("RuleLab.candidates()") && u.contains("RuleLab.toggle(c.entry)") && u.contains("RuleLab.picked.isNotEmpty()"))
        for ((n, f) in TestFiles.stringFiles()) { val t = f.readText(); assertTrue(n, t.contains("name=\"rl_pick\"") && t.contains("name=\"rl_auto\"")) }
    }

    @Test fun suggestPicksByFeatureName() {
        val c = listOf(UserFeatPure.Cand("sel:keşfet", false), UserFeatPure.Cand("text:home", false), UserFeatPure.Cand("sel:explore", true), UserFeatPure.Cand("desc:search", false))
        assertEquals(listOf("sel:keşfet", "desc:search"), UserFeatPure.suggest(c, "Keşfet"))   // eşanlamlı şablon + negatifte görülen elenir
        assertEquals(listOf("sel:keşfet"), UserFeatPure.suggest(c.take(2), "keşfet"))
        assertTrue(UserFeatPure.suggest(c, "ab").isEmpty()); assertTrue(UserFeatPure.suggest(c, "Zzzzz").isEmpty())
        assertTrue(src("block/Extras.kt").contains("UserFeatPure.suggest(cands, fn)"))
    }
}
