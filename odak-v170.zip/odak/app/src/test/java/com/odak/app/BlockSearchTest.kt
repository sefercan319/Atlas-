package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class BlockSearchTest {
    @Test fun packageNameFindsApp() {
        assertTrue(Pure.nameMatches("Whatsapp", "com.whatsapp", "com.whatsapp"))
        assertFalse(Pure.nameMatches("Whatsapp", "telegram", "com.whatsapp"))
    }
    @Test fun turkishCaseFolding() { assertTrue(Pure.nameMatches("Işık Uygulaması", "isik")) }
    @Test fun screenSearchesPackagesAndShowsCount() {
        val ui = File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()
        assertTrue(ui.contains("it.packages.firstOrNull") && ui.contains("R.string.app_count, filtered.size"))
        for (l in listOf("", "-tr", "-en", "-de", "-fr", "-es", "-ar", "-ru", "-az"))
            assertTrue(l, File(TestFiles.main, "res/values$l/strings.xml").readText().contains("name=\"app_count\""))
    }
}
