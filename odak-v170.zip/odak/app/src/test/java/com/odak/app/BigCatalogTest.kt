package com.odak.app

import com.odak.app.logic.AppList
import com.odak.app.logic.MoreAppsData
import com.odak.app.logic.MoreAppsData2
import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class BigCatalogTest {
    private val pkgRe = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+")
    private fun base(): Set<String> =
        Regex("\"([a-z][a-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)\"").findAll(File(TestFiles.code, "com/odak/app/block/BlockData.kt").readText()).map { it.groupValues[1] }.toSet()

    @Test fun secondGroupIsValid() {
        for (e in AppList.parse(MoreAppsData2.ALL)) {
            assertTrue(e.pkg, pkgRe.matches(e.pkg)); assertTrue(e.name, e.name.length in 1..40)
        }
    }
    @Test fun totalCatalogAtLeast3000() {
        val all = base() + AppList.parse(MoreAppsData.ALL).map { it.pkg } + AppList.parse(MoreAppsData2.ALL).map { it.pkg }
        assertTrue("toplam ${all.size}", all.size >= 3000)
    }
    @Test fun secondGroupHasNoInternalDuplicates() {
        val p = AppList.parse(MoreAppsData2.ALL).map { it.pkg }
        assertEquals(p.size, p.toSet().size)
    }
    @Test fun secondGroupMergedIntoCatalog() {
        assertTrue(File(TestFiles.code, "com/odak/app/block/BlockData.kt").readText().contains("MoreAppsData2.ALL"))
    }
    @Test fun lessStepsBackOnePage() {
        val P = Pure.APP_PAGE
        assertEquals(P, Pure.appsLessShown(P, 100)); assertEquals(P, Pure.appsLessShown(2 * P, 100))
        assertEquals(2 * P, Pure.appsLessShown(3 * P, 100)); assertEquals(P, Pure.appsLessShown(100, 100)); assertEquals(P, Pure.appsLessShown(3000, 3000))
    }
    @Test fun listStartsSmallWithMoreAndLessButtons() {
        assertTrue(Pure.APP_PAGE <= 20)
        val ui = File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()
        assertTrue(ui.contains("R.string.blk_less") && ui.contains("appsLessShown(shown, filtered.size)") && ui.contains("shown > PAGE"))
        for (l in listOf("", "-tr", "-en", "-de", "-fr", "-es", "-ar", "-ru", "-az"))
            assertTrue(l, File(TestFiles.main, "res/values$l/strings.xml").readText().contains("name=\"blk_less\""))
    }
}
