package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

class ShapeSheetTest {
    private fun entries(b: ByteArray): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        ZipInputStream(ByteArrayInputStream(b)).use { z -> while (true) { val e = z.nextEntry ?: break; m[e.name] = String(z.readBytes(), Charsets.UTF_8) } }
        return m
    }
    private fun png(): ByteArray {
        fun u32(v: Int) = byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())
        return byteArrayOf(0x89.toByte(), 'P'.code.toByte(), 'N'.code.toByte(), 'G'.code.toByte(), 13, 10, 26, 10) + u32(13) + "IHDR".toByteArray() + u32(10) + u32(10) + byteArrayOf(8, 6, 0, 0, 0) + ByteArray(16)
    }

    // ---------- DOCX şekil okuma ----------
    private fun docx(shape: String, extra: String = ""): ByteArray = ("""<?xml version="1.0" encoding="UTF-8"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"><w:body>
<w:p><w:r><w:t>Metin</w:t></w:r><w:r><w:drawing><wp:anchor><wp:positionH relativeFrom="page"><wp:posOffset>914400</wp:posOffset></wp:positionH><wp:positionV relativeFrom="page"><wp:posOffset>1828800</wp:posOffset></wp:positionV><wp:extent cx="1828800" cy="914400"/><wp:wrapNone/><a:graphic><a:graphicData>$shape</a:graphicData></a:graphic></wp:anchor></w:drawing></w:r></w:p>$extra</w:body></w:document>""").toByteArray()

    private fun shapeXml(prst: String, fill: String, ln: String) = """<wps:wsp><wps:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="1828800" cy="914400"/></a:xfrm><a:prstGeom prst="$prst"><a:avLst/></a:prstGeom>$fill$ln</wps:spPr><wps:bodyPr/></wps:wsp>"""
    private val red = """<a:solidFill><a:srgbClr val="FF0000"/></a:solidFill>"""
    private val blueLn = """<a:ln w="19050"><a:solidFill><a:srgbClr val="0000FF"/></a:solidFill></a:ln>"""

    private fun shapes(rp: RichPage) = rp.blocks.filterIsInstance<RTable>().filter { it.at != null }

    @Test fun docxEllipseKeepsGeometryColorsAndPlace() {
        val rp = RichDocx.parse(docx(shapeXml("ellipse", red, blueLn)), null, null)
        val t = shapes(rp).single()
        assertEquals("ellipse", t.prst)
        val c = t.rows[0][0]
        assertEquals("FF0000", c.fill); assertEquals("0000FF", c.bt!!.color); assertEquals(12, c.bt!!.w)
        assertEquals(1440, t.at!![0]); assertEquals(2880, t.at!![1]); assertEquals(2880, t.at!![2]); assertEquals(1440, t.at!![3])
    }

    @Test fun docxNoFillNoLineShape() {
        val rp = RichDocx.parse(docx(shapeXml("rect", "<a:noFill/>", "<a:ln><a:noFill/></a:ln>")), null, null)
        val c = shapes(rp).single().rows[0][0]
        assertEquals(null, c.fill); assertEquals(null, c.bt)
    }

    @Test fun docxLinesAndConnectorsAreSkipped() {
        assertTrue(shapes(RichDocx.parse(docx(shapeXml("line", "", blueLn)), null, null)).isEmpty())
        assertTrue(shapes(RichDocx.parse(docx(shapeXml("straightConnector1", "", blueLn)), null, null)).isEmpty())
    }

    @Test fun docxGroupChildrenAreNotMisplaced() {
        val g = "<wpg:wgp>" + shapeXml("ellipse", red, blueLn) + "</wpg:wgp>"
        assertTrue(shapes(RichDocx.parse(docx(g), null, null)).isEmpty())
    }

    @Test fun docxInlineShapeWithoutAnchorIsIgnored() {
        val d = String(docx(shapeXml("ellipse", red, blueLn))).replace("wp:anchor", "wp:inline").toByteArray()
        assertTrue(shapes(RichDocx.parse(d, null, null)).isEmpty())
    }

    // ---------- Şekil → PPTX / ODP ----------
    private fun docWithShape(prst: String = "ellipse"): Doc {
        val rp = RichDocx.parse(docx(shapeXml(prst, red, blueLn)), null, null)
        return Doc(DocKind.DOCX, listOf(DocPage("", Rich.plain(rp), null, null, rp)))
    }

    @Test fun docxShapeBecomesPptxShapeSlide() {
        val sl = DocWrite.slides(docWithShape())
        assertEquals(2, sl.size); assertTrue(sl[0].shapes.isEmpty()); assertEquals(1, sl[1].shapes.size)
        val x = entries(DocWrite.write(docWithShape(), ConvTarget.PPTX)!!)["ppt/slides/slide2.xml"]!!
        assertTrue(x.contains("prst=\"ellipse\"")); assertTrue(x.contains("srgbClr val=\"FF0000\"")); assertTrue(x.contains("srgbClr val=\"0000FF\"")); assertTrue(x.contains("<a:ln w="))
    }

    @Test fun docxShapeBecomesOdpCustomShape() {
        val c = entries(DocWrite.write(docWithShape(), ConvTarget.ODP)!!)["content.xml"]!!
        assertTrue(c.contains("<draw:custom-shape")); assertTrue(c.contains("draw:type=\"ellipse\"")); assertTrue(c.contains("draw:fill-color=\"#FF0000\"")); assertTrue(c.contains("svg:stroke-color=\"#0000FF\""))
    }

    private fun slidePage(): Doc {
        val box1 = RBox(1000, 2000, 6000, 3000, listOf(RPara(listOf(RRun("Merhaba", b = true, color = "FFFFFF", sz = 40)), align = "center")), fill = "00AA00", border = Bd(16, "003300"), valign = "center", round = true)
        val box2 = RBox(8000, 500, 3000, 2000, listOf(RPara(listOf(RRun("", img = RImg(png(), "image/png", 2000, 2000))))))
        val rp = RichPage(listOf(box1, box2), PageSetup(19200, 10800, 0, 0, 0, 0), 22, null, 0, 0)
        return Doc(DocKind.PPTX, listOf(DocPage("1", Rich.plain(rp), null, null, rp)))
    }

    @Test fun pptxSourceBoxesStayShapes() {
        val d = slidePage()
        val sl = DocWrite.slides(d)
        assertEquals(1, sl.size); assertEquals(2, sl[0].shapes.size)
        val e = entries(DocWrite.write(d, ConvTarget.PPTX)!!)
        val x = e["ppt/slides/slide1.xml"]!!
        assertTrue(x.contains("<a:off x=\"${1000 * 635}\" y=\"${2000 * 635}\"/>"))
        assertTrue(x.contains("prst=\"ellipse\"") && x.contains("srgbClr val=\"00AA00\"") && x.contains("anchor=\"ctr\"") && x.contains("algn=\"ctr\""))
        assertTrue(x.contains("Merhaba") && x.contains("b=\"1\"") && x.contains("srgbClr val=\"FFFFFF\""))
        assertTrue(x.contains("<p:pic>")); assertTrue(e.containsKey("ppt/media/image1.png"))
        assertTrue(e["ppt/slides/_rels/slide1.xml.rels"]!!.contains("../media/image1.png"))
        assertFalse(x.contains("name=\"Title\""))
    }

    @Test fun pptxSourceToOdp() {
        val e = entries(DocWrite.write(slidePage(), ConvTarget.ODP)!!)
        val c = e["content.xml"]!!
        assertTrue(c.contains("draw:type=\"ellipse\"") && c.contains("draw:fill-color=\"#00AA00\"") && c.contains("Merhaba") && c.contains("fo:font-size="))
        assertTrue(c.contains("draw:textarea-vertical-align=\"middle\"")); assertTrue(e.keys.any { it.startsWith("Pictures/shape") })
        assertTrue(DocParse.parse("x.odp", DocWrite.write(slidePage(), ConvTarget.ODP)!!).pages.isNotEmpty())
        assertTrue(DocParse.parse("x.pptx", DocWrite.write(slidePage(), ConvTarget.PPTX)!!).pages.isNotEmpty())
    }

    @Test fun slideFitKeepsAspectAndCenters() {
        val f = DocWrite.slideFit(10800, 10800)
        assertEquals(6858000.0 / (10800 * 635.0), f[0], 1e-9); assertEquals(0.0, f[2], 1e-6); assertTrue(f[1] > 0)
        val g = DocWrite.slideFit(19200, 10800); assertEquals(1.0, g[0], 1e-9); assertEquals(0.0, g[1], 1e-6)
    }

    @Test fun flowTextStillGoesToTextSlides() {
        val rp = RichPage(listOf(RPara(listOf(RRun("A"))), RBox(0, 0, 100, 100, emptyList(), fill = "FF0000"), RPara(listOf(RRun("B")))))
        val sl = DocWrite.slides(Doc(DocKind.DOCX, listOf(DocPage("P", listOf("A", "B"), null, null, rp))))
        assertEquals(listOf("A", "B"), sl[0].lines); assertEquals(1, sl[1].shapes.size)
    }

    // ---------- XLSX / ODS biçim ----------
    private fun coloredTable(): Doc {
        fun cell(t: String, color: String? = null, b: Boolean = false, fill: String? = null, al: String = "") = RCell(listOf(RPara(listOf(RRun(t, b = b, color = color)), align = al)), fill = fill)
        val tb = RTable(listOf(
            listOf(cell("Ad", "FFFFFF", true, "1F4E79"), cell("Tutar", "FFFFFF", true, "1F4E79", "right")),
            listOf(cell("Elma"), cell("12.5", "C00000", false, "FFFF00", "right"))
        ), listOf(2000, 2000))
        val rp = RichPage(listOf(RPara(listOf(RRun("Başlık", i = true, color = "00B050"))), tb))
        return Doc(DocKind.DOCX, listOf(DocPage("S", Rich.plain(rp), null, null, rp)))
    }

    @Test fun gridKeepsValuesAndFormats() {
        val g = SheetFmt.grid(coloredTable().pages[0])
        assertEquals(listOf(listOf("Başlık"), listOf("Ad", "Tutar"), listOf("Elma", "12.5")), g.rows)
        assertEquals("00B050", g.fmts[0][0]!!.color); assertTrue(g.fmts[0][0]!!.i)
        assertEquals("1F4E79", g.fmts[1][0]!!.fill); assertTrue(g.fmts[1][0]!!.b); assertEquals("right", g.fmts[1][1]!!.align)
        assertEquals(null, g.fmts[2][0]); assertEquals("FFFF00", g.fmts[2][1]!!.fill)
    }

    @Test fun gridPlainPageUnchanged() {
        val g = SheetFmt.grid(DocPage("P", listOf("a", "b"), listOf(listOf("1", "2"))))
        assertEquals(listOf(listOf("a"), listOf("b"), listOf("1", "2")), g.rows); assertTrue(g.fmts.all { r -> r.all { it == null } })
    }

    @Test fun gridSpansPadAndMergedContinuationsAreEmpty() {
        val t = RTable(listOf(listOf(RCell(listOf(RPara(listOf(RRun("geniş")))), span = 2, fill = "FF0000"), RCell(listOf(RPara(listOf(RRun("x")))))),
            listOf(RCell(listOf(RPara(listOf(RRun("y"))))), RCell(listOf(RPara(emptyList())), vMerge = 2), RCell(listOf(RPara(listOf(RRun("z"))))))), listOf(1, 1, 1))
        val g = SheetFmt.grid(DocPage("", emptyList(), null, null, RichPage(listOf(t))))
        assertEquals(listOf("geniş", "", "x"), g.rows[0]); assertEquals(listOf("y", "", "z"), g.rows[1]); assertEquals("FF0000", g.fmts[0][1]!!.fill)
    }

    @Test fun xlsxHasStylesAndStyledCells() {
        val b = DocWrite.write(coloredTable(), ConvTarget.XLSX)!!
        val e = entries(b)
        val st = e["xl/styles.xml"]!!
        assertTrue(st.contains("fgColor rgb=\"FF1F4E79\"") && st.contains("fgColor rgb=\"FFFFFF00\"") && st.contains("<b/>") && st.contains("<i/>") && st.contains("color rgb=\"FFC00000\"") && st.contains("horizontal=\"right\""))
        assertTrue(e["[Content_Types].xml"]!!.contains("/xl/styles.xml")); assertTrue(e["xl/_rels/workbook.xml.rels"]!!.contains("styles.xml"))
        val sh = e["xl/worksheets/sheet1.xml"]!!
        assertTrue(sh.contains(" s=\"1\"") || sh.contains(" s=\"2\"")); assertTrue(sh.contains("<v>12.5</v>"))
        assertFalse(sh.contains("s=\"0\""))
        assertTrue(DocParse.parse("x.xlsx", b).pages.isNotEmpty())
    }

    @Test fun xlsxPlainSheetStaysUnstyled() {
        val e = entries(DocWrite.write(Doc(DocKind.TEXT, listOf(DocPage("P", listOf("a"), listOf(listOf("1", "2"))))), ConvTarget.XLSX)!!)
        assertFalse(e["xl/worksheets/sheet1.xml"]!!.contains(" s=\""))
    }

    @Test fun odsHasCellStyles() {
        val b = DocWrite.write(coloredTable(), ConvTarget.ODS)!!
        val c = entries(b)["content.xml"]!!
        assertTrue(c.contains("fo:background-color=\"#1F4E79\"") && c.contains("fo:background-color=\"#FFFF00\"") && c.contains("fo:color=\"#C00000\"") && c.contains("fo:font-weight=\"bold\"") && c.contains("fo:font-style=\"italic\""))
        assertTrue(c.contains("table:style-name=\"ce1\"")); assertTrue(c.contains("fo:text-align=\"end\""))
        assertTrue(DocParse.parse("x.ods", b).pages.isNotEmpty())
    }

    @Test fun styleTablesDedupe() {
        val st = DocWrite.XlsxStyles(); val f = SheetFmt.Fmt("FF0000", true, false, false, false, null, "")
        assertEquals(st.index(f), st.index(SheetFmt.Fmt("FF0000", true, false, false, false, null, ""))); assertEquals(1, st.index(f)); assertEquals(2, st.index(SheetFmt.Fmt(null, false, true, false, false, null, "")))
    }
}
