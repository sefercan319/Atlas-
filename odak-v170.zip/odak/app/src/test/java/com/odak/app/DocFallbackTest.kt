package com.odak.app

import com.odak.app.docs.DocKind
import com.odak.app.docs.DocParse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DocFallbackTest {
    @Test fun codeFilesOpenAsText() {
        for (n in listOf("a.py", "b.kt", "c.js", "d.css", "e.sh", "f.gradle", "g.jsonl", "h.ass")) assertEquals(n, DocKind.TEXT, DocParse.detect(n, "x".toByteArray()))
        val d = DocParse.parse("main.py", "print(1)\nprint(2)".toByteArray())
        assertEquals(DocKind.TEXT, d.kind); assertEquals(2, d.pages[0].paragraphs.size)
    }
    @Test fun unknownTextExtensionStillConverts() {
        val d = DocParse.parse("notlar.xyz", "merhaba dünya\nikinci satır".toByteArray())
        assertEquals(DocKind.TEXT, d.kind); assertEquals(2, d.pages[0].paragraphs.size)
        val bin = DocParse.parse("a.bin", ByteArray(200) { (it % 7).toByte() })
        assertFalse(bin.kind == DocKind.TEXT)
    }
    @Test fun looksTextRules() {
        assertTrue(DocParse.looksText("abc\n".toByteArray())); assertFalse(DocParse.looksText(ByteArray(50)))
        assertFalse(DocParse.looksText(ByteArray(0)))
    }
    @Test fun brokenParseFallsBackToText() {
        val d = DocParse.fallback(DocKind.XLSX, "a;b\nc;d".toByteArray())
        assertTrue(d.approx); assertEquals(2, d.pages[0].paragraphs.size)
        assertTrue(DocParse.fallback(DocKind.PDF, ByteArray(3)).pages.isEmpty())
    }
}
