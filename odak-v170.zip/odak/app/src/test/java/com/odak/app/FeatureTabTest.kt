package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class FeatureTabTest {
    private val s = File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()
    private val data = File(TestFiles.code, "com/odak/app/block/BlockData.kt").readText()

    @Test fun featureTabIsSecondInTheBar() {
        assertTrue(s.contains("val tabOrder = listOf(0, 4, 1, 2, 3)"))
        val bar = s.substring(s.indexOf("val tabOrder"), s.indexOf("bottom = false"))
        val order = listOf("blk_tab_apps", "blk_sec_features", "focus_title", "blk_tab_quiet", "blk_tab_adv").map { bar.indexOf(it) }
        assertTrue(order.all { it > 0 } && order == order.sorted())
        assertTrue(bar.contains("tabOrder.indexOf(tab)") && bar.contains("tab = tabOrder[it]"))
    }
    @Test fun featureTabListsOnlyAppsWithFeatures() {
        val t = s.substring(s.indexOf("if (tab == 4) {"))
        assertTrue(t.contains("allApps.filter { it.features.isNotEmpty() }"))
        assertTrue(t.contains("FeatureAppCard(") && t.contains("blk_feat_hint"))
    }
    @Test fun cardExpandsToToggleAndLimit() {
        val c = s.substring(s.indexOf("private fun FeatureAppCard("), s.indexOf("private fun AppDetailDialog("))
        assertTrue(c.contains("open = !open") && c.contains("setFeatureBlocked") && c.contains("onCooldown"))
        assertTrue(c.contains("featLimit") && c.contains("onLab(app.id, f.id)"))
        assertTrue(c.contains("joinToString(\" · \")"))   // kapalıyken özellik adları önizlenir
    }
    @Test fun everyTabContentIdStillExists() {
        for (i in 0..4) assertTrue("tab $i", s.contains("if (tab == $i) {"))
    }
    @Test fun catalogHasManyAppsWithFeatures() {
        val n = Regex("listOf\\(Feat\\(").findAll(data).count()
        assertTrue("özellikli uygulama $n", n >= 8)
    }
    @Test fun hintStringInEveryLocale() {
        for (l in listOf("", "-tr", "-en", "-de", "-fr", "-es", "-ar", "-ru", "-az"))
            assertTrue(l, File(TestFiles.main, "res/values$l/strings.xml").readText().contains("name=\"blk_feat_hint\""))
    }
}
