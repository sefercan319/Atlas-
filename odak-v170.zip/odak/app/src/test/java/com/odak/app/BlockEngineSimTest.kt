package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Özellik engelleme motorunun simülasyonu: gerçek kural dosyası + sahte ekran görüntüleri. */
class BlockEngineSimTest {
    private val rules = TestFiles.parseRules(File(TestFiles.main, "assets/block_rules.json"))
    private val feats = rules.keys.filter { !it.startsWith("_") && !it.startsWith("!") }

    private fun snapFor(key: String, only: String? = null): Pure.Snap {
        val pos = rules[key]!!
        val ids = pos.filter { !it.contains(":") }.let { if (only != null) it.filter { x -> x == only } else it }.map { "x_$it" }.toSet()
        val sel = pos.filter { it.startsWith("sel:") }.map { it.substring(4) }.toSet()
        return Pure.Snap(ids, sel = if (only == null) sel else emptySet())
    }
    private fun app(k: String) = k.substringBefore('/')
    private fun feat(k: String) = k.substringAfter('/')

    @Test fun everyRuleEntryAloneBlocksItsFeature() {
        val bad = feats.flatMap { k ->
            rules[k]!!.mapNotNull { e ->
                val s = if (e.startsWith("sel:")) Pure.Snap(emptySet(), sel = setOf(e.substring(4)))
                else if (e.startsWith("desc:")) Pure.Snap(emptySet(), descs = setOf(e.substring(5)))
                else if (e.startsWith("text:")) Pure.Snap(emptySet(), texts = setOf(e.substring(5)))
                else Pure.Snap(setOf("com.app:id/$e".substringAfter(":id/")))
                val neg = rules["!$k"].orEmpty()
                if (neg.any { n -> e.contains(n) }) null
                else if (Pure.matches(s, rules, app(k), feat(k))) null else "$k->$e"
            }
        }
        assertTrue("Tek başına eşleşmeyen girdiler: $bad", bad.isEmpty())
    }

    @Test fun homeScreenNeverBlocks() {
        val home = Pure.Snap(setOf("tab_bar", "toolbar", "main_content", "bottom_nav"), setOf("home", "ana sayfa"), setOf("hello"), setOf("home", "ana sayfa"))
        val bad = feats.filter { Pure.matches(home, rules, app(it), feat(it)) }
        assertTrue("Ana ekranda tetiklenenler: $bad", bad.isEmpty())
    }

    @Test fun emptyScreenNeverBlocks() {
        val e = Pure.Snap(emptySet())
        assertTrue(feats.none { Pure.matches(e, rules, app(it), feat(it)) })
    }

    @Test fun unknownFeatureNeverMatches() =
        assertFalse(Pure.matches(Pure.Snap(setOf("reel_recycler")), rules, "youtube", "nope"))

    @Test fun negativeVetoWorks() {
        val live = Pure.Snap(setOf("reel_player_page_container", "live_chat_content"))
        assertFalse(Pure.matches(live, rules, "youtube", "shorts"))
        assertTrue(Pure.matches(Pure.Snap(setOf("reel_player_page_container")), rules, "youtube", "shorts"))
    }

    @Test fun siblingFeaturesDoNotTrigger() {
        val bad = feats.flatMap { a ->
            feats.filter { it != a && app(it) == app(a) && Pure.matches(snapFor(a), rules, app(it), feat(it)) }.map { "$a→$it" }
        }
        assertTrue("Kardeş özellik sızması: $bad", bad.isEmpty())
    }

    @Test fun featDeltaAccumulatesOnlySmallGaps() {
        assertEquals(0L, Pure.featDelta(null, 1000))
        assertEquals(500L, Pure.featDelta(1000, 1500))
        assertEquals(0L, Pure.featDelta(1000, 9000))
        assertEquals(0L, Pure.featDelta(2000, 1000))
    }

    @Test fun exitFallsBackToBackAfterTwoHomeTries() {
        assertEquals(Pure.EXIT_HOME_TAB, Pure.featExit(true, 0))
        assertEquals(Pure.EXIT_BACK, Pure.featExit(true, 2))
        assertEquals(Pure.EXIT_BACK, Pure.featExit(false, 0))
    }

    @Test fun homeLabels() {
        assertTrue(Pure.isHomeLabel("Home, tab 1 of 5"))
        assertTrue(Pure.isHomeLabel("Ana sayfa"))
        assertFalse(Pure.isHomeLabel("Homework"))
        assertFalse(Pure.isHomeLabel("Reels"))
    }
}
