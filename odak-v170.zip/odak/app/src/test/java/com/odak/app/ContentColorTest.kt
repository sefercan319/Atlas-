package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File

class ContentColorTest {
    @Test fun backgroundProvidesStyleTextAsContentColor() {
        // Rengi verilmeyen Text, LocalContentColor'u (varsayılan siyah) kullanır; koyu stillerde okunmaz.
        val s = File("src/main/java/com/odak/app/theme/ThemedComponents.kt").readText()
        val a = s.indexOf("fun ThemedBackground"); val b = s.indexOf("private fun BoxScope.Decor")
        val body = s.substring(a, b)
        assertEquals(2, Regex("LocalContentColor provides t\\.text").findAll(body).count())
    }
}
