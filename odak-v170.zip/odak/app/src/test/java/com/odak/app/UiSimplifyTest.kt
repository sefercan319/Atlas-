package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.27: ayarlar kategorilere ayrıldı; minimal stilde ana ekran sadeleştirildi. */
class UiSimplifyTest {
    private val settings: String get() = File(TestFiles.code, "com/odak/app/settings/SettingsScreen.kt").readText()
    private val planThemes: String get() = File(TestFiles.code, "com/odak/app/plan/PlanThemes.kt").readText()

    /** Yalnızca çağrı noktalarını sayar (tanımlar "fun X(" hariç). */
    private fun callCount(src: String, call: String): Int =
        Regex("(?<!fun )\\b" + Regex.escape(call) + "\\(").findAll(src).count()

    @Test fun everySettingsCardAppearsExactlyOnce() {
        val cards = listOf("NotesCard", "StatsCard", "DailyCard", "MsgsCard", "LeadCard", "SoundCard",
            "EmojiCard", "SummaryCard", "BackupCard", "LanguageCard", "FontCard", "ScaleCard", "PinCard", "PermCard", "ColorsCard")
        for (c in cards) assertEquals(c, 1, callCount(settings, c))
    }

    @Test fun settingsHasFiveGroupsWithBackNavigation() {
        val t = settings
        assertEquals(5, Regex("^\\s+[A-Z]+\\(\"", RegexOption.MULTILINE).findAll(t.substringAfter("enum class SettingsGroup").substringBefore("}")).count())
        assertTrue(t.contains("BackHandler(enabled = group != null) { group = null }"))
        assertTrue(t.contains("QuietAction(\"‹ \" + stringResource(R.string.sg_back)"))
        for (k in listOf("SOUND", "LOOK", "PLAN", "DATA", "SECURITY")) assertTrue(k, t.contains("SettingsGroup.$k ->"))
    }

    @Test fun settingsGroupTitlesExistInEveryLocale() {
        val dirs = TestFiles.res.listFiles { f -> f.isDirectory && f.name.startsWith("values") }!!
        for (d in dirs) {
            val f = File(d, "strings.xml")
            if (!f.exists()) continue
            val text = f.readText()
            for (k in listOf("sg_look", "sg_sound", "sg_plan", "sg_data", "sg_security", "sg_back")) {
                assertTrue("${d.name}:$k", text.contains("name=\"$k\""))
            }
        }
    }

    @Test fun minimalDayViewHasNoWeekStripOrDayName() {
        val start = planThemes.indexOf("fun MinimalPlan(")
        val end = planThemes.indexOf("private fun MinWeekStrip(", start)
        assertTrue(start >= 0 && end > start)
        val body = planThemes.substring(start, end)
        assertFalse(body.contains("MinWeekStrip(vm)"))
        assertFalse(body.contains("dayName(vm.anchor, JTextStyle.FULL)"))
        assertTrue(body.contains("Period.DAY -> MinList(vm)"))
        assertTrue(body.contains("Arrangement.End"))
    }

    @Test fun minimalKeepsNavigationAndAddRow() {
        val start = planThemes.indexOf("fun MinimalPlan(")
        val body = planThemes.substring(start, planThemes.indexOf("private fun MinWeekStrip(", start))
        assertTrue(body.contains("NavRow(vm)"))
        assertTrue(body.contains("AddRow(vm)"))
        assertTrue(body.contains("PeriodSelector("))
    }
}
