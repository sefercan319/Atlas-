package com.odak.app

import com.odak.app.logic.CatalogSync
import com.odak.app.logic.CatalogSync.SyncApp
import com.odak.app.logic.MiniJson
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class MiniJsonTest {
    @Test fun parsesBasics() {
        val m = MiniJson.parse("""{"a": [1, "x\nç", true, null], "b": {"c": -2.5e1}}""") as Map<*, *>
        assertEquals(listOf(1.0, "x\nç", true, null), m["a"])
        assertEquals(-25.0, (m["b"] as Map<*, *>)["c"])
    }
    @Test fun badInputIsNull() {
        for (s in listOf("", "{", "[1,", "{\"a\" 1}", "nul", "{\"a\":1} x", "\"abc")) assertNull(MiniJson.parse(s))
    }
    @Test fun deepNestingIsRejected() = assertNull(MiniJson.parse("[".repeat(500) + "]".repeat(500)))
    @Test fun writeRoundTrip() {
        val r = mapOf("a/b" to listOf("x\"y", "sel:ç\\"), "c/d" to listOf("z"))
        assertEquals(r, (MiniJson.parse(MiniJson.writeRules(r)) as Map<*, *>).mapValues { (it.value as List<*>) })
    }
    @Test fun readsTheRealRulesFile() {
        val f = File(TestFiles.main, "assets/block_rules.json")
        val a = (MiniJson.parse(f.readText()) as Map<*, *>).filterKeys { !(it as String).startsWith("_") }
        assertEquals(TestFiles.parseRules(f).filterKeys { !it.startsWith("_") }.keys, a.keys)
    }
}

class CatalogSyncTest {
    private val repo = File(TestFiles.main, "../../../catalog/atlas_catalog.json")
    private val rulesFile = File(TestFiles.main, "assets/block_rules.json")

    @Test fun repoCatalogParsesAndMatchesShippedRules() {
        val p = CatalogSync.parseAtlas(repo.readText())
        assertNotNull(p)
        val shipped = TestFiles.parseRules(rulesFile).filterKeys { !it.startsWith("_") }
        assertEquals(shipped, p!!.rules)
        assertTrue(CatalogSync.changedRules(shipped, p.rules).isEmpty())
    }

    @Test fun repoCatalogAppsMatchBuiltInCatalog() {
        val p = CatalogSync.parseAtlas(repo.readText())!!
        val cat = TestFiles.catalog().associateBy { it.id }
        assertEquals(cat.keys, p.apps.map { it.id }.toSet())
        p.apps.forEach { assertEquals(it.id, cat[it.id]!!.packages, it.pkgs) }
        val known = cat.values.flatMap { it.packages }.toSet()
        assertTrue(CatalogSync.merge(CatalogSync.Store.EMPTY, p.apps, known, cat.keys).size == 0)
    }

    @Test fun validation() {
        assertTrue(CatalogSync.validPkg("com.instagram.android"))
        assertFalse(CatalogSync.validPkg("nodots")); assertFalse(CatalogSync.validPkg("com.a b")); assertFalse(CatalogSync.validPkg("1com.x"))
        assertFalse(CatalogSync.validPkg("com." + "a".repeat(200)))
        assertTrue(CatalogSync.validRuleKey("youtube/shorts")); assertTrue(CatalogSync.validRuleKey("!youtube/shorts"))
        assertFalse(CatalogSync.validRuleKey("youtube")); assertFalse(CatalogSync.validRuleKey("Y/x"))
        assertTrue(CatalogSync.validRuleEntry("reel_recycler")); assertTrue(CatalogSync.validRuleEntry("sel:ara ve keşfet"))
        assertFalse(CatalogSync.validRuleEntry("feed")); assertFalse(CatalogSync.validRuleEntry("toolbar"))
        assertFalse(CatalogSync.validRuleEntry("sel:")); assertFalse(CatalogSync.validRuleEntry("has space here"))
    }

    @Test fun badAtlasEntriesAreDropped() {
        val p = CatalogSync.parseAtlas("""{"rules":{"x/y":["reel_player","feed","sel:video"],"BAD":["reel_player"],"a/b":["x"]},
            "apps":[{"id":"x","name":"Ok App","packages":["com.ok.app","bad pkg"]},{"name":"","packages":["com.a.b"]},{"name":"NoPkg","packages":[]},{"name":"Http http://x","packages":["com.h.h"]}]}""")!!
        assertEquals(mapOf("x/y" to listOf("reel_player", "sel:video")), p.rules)
        assertEquals(1, p.apps.size); assertEquals(listOf("com.ok.app"), p.apps[0].pkgs)
    }

    @Test fun garbageIsNull() {
        assertNull(CatalogSync.parseAtlas("not json")); assertNull(CatalogSync.parseAtlas("[]")); assertNull(CatalogSync.parseAtlas("{}"))
        assertNull(CatalogSync.parseUad("{}"))
    }

    @Test fun uadOnlyMiscWithMatchingPlayLink() {
        val p = CatalogSync.parseUad("""{
          "com.tripadvisor.tripadvisor": {"list":"Misc","description":"Trip advisor (https://play.google.com/store/apps/details?id=com.tripadvisor.tripadvisor)\nmore"},
          "com.other.app": {"list":"Misc","description":"Name (https://play.google.com/store/apps/details?id=com.different.app)"},
          "com.oem.thing": {"list":"Oem","description":"Thing (https://play.google.com/store/apps/details?id=com.oem.thing)"},
          "com.mediatek.ims": {"list":"Misc","description":"Mediatek's implementation of IMS"}}""")!!
        assertEquals(1, p.apps.size)
        assertEquals("Trip advisor", p.apps[0].name); assertEquals(listOf("com.tripadvisor.tripadvisor"), p.apps[0].pkgs)
    }

    @Test fun mergeAddsOnlyNewAndAliasesBaseApps() {
        val inc = listOf(SyncApp("", "Known", listOf("com.known.app")), SyncApp("", "New", listOf("com.new.app")),
            SyncApp("tiktok", "TikTok", listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.aweme")))
        val st = CatalogSync.merge(CatalogSync.Store.EMPTY, inc, setOf("com.known.app", "com.zhiliaoapp.musically"), setOf("tiktok"))
        assertEquals(listOf("x:com.new.app"), st.apps.map { it.id })
        assertEquals(mapOf("tiktok" to listOf("com.ss.android.ugc.aweme")), st.aliases)
        val again = CatalogSync.merge(st, inc, setOf("com.known.app", "com.zhiliaoapp.musically"), setOf("tiktok"))
        assertEquals(st.size, again.size)
    }

    @Test fun mergeIsCapped() {
        val inc = (0 until CatalogSync.MAX_APPS + 50).map { SyncApp("", "App $it", listOf("com.gen.p$it")) }
        assertEquals(CatalogSync.MAX_APPS, CatalogSync.merge(CatalogSync.Store.EMPTY, inc, emptySet(), emptySet()).apps.size)
    }

    @Test fun storeRoundTripAndCorruption() {
        val st = CatalogSync.Store(listOf(SyncApp("x:com.a.b", "A|B", listOf("com.a.b", "com.a.c"))), mapOf("tiktok" to listOf("com.t.t")))
        val back = CatalogSync.deserialize(CatalogSync.serialize(st))
        assertEquals(1, back.apps.size); assertEquals("A B", back.apps[0].name); assertEquals(st.aliases, back.aliases)
        val bad = CatalogSync.deserialize("junk\nA|x|n|nodot\nL|BAD ID|com.a.b\nA|x:com.q.q|QQ|com.q.q")
        assertEquals(1, bad.apps.size); assertTrue(bad.aliases.isEmpty())
    }

    @Test fun changedRulesOnlyDifferences() {
        val cur = mapOf("a/b" to listOf("x1234"), "c/d" to listOf("y1234"))
        assertEquals(mapOf("c/d" to listOf("z1234"), "e/f" to listOf("w1234")),
            CatalogSync.changedRules(cur, mapOf("a/b" to listOf("x1234"), "c/d" to listOf("z1234"), "e/f" to listOf("w1234"), "g/h" to emptyList())))
    }

    @Test fun mirrorOnlyWhenPrimaryFailed() {
        val m = CatalogSync.SOURCES.first { it.id == "mirror" }; val a = CatalogSync.SOURCES.first { it.id == "atlas" }
        assertFalse(CatalogSync.shouldTry(m, setOf("atlas"))); assertTrue(CatalogSync.shouldTry(m, emptySet())); assertTrue(CatalogSync.shouldTry(a, setOf("atlas")))
    }

    @Test fun dueLogic() {
        val day = 86_400_000L
        assertTrue(CatalogSync.isDue(0, 1000)); assertFalse(CatalogSync.isDue(1000, 1000 + 6 * day))
        assertTrue(CatalogSync.isDue(1000, 1000 + 7 * day)); assertTrue(CatalogSync.isDue(5000, 1000))
    }

    @Test fun sourcesAreSafe() {
        assertTrue(CatalogSync.SOURCES.size >= 3)
        assertEquals(CatalogSync.SOURCES.size, CatalogSync.SOURCES.map { it.id }.toSet().size)
        assertTrue(CatalogSync.SOURCES.all { it.url.startsWith("https://") })
        assertFalse(CatalogSync.SOURCES.first { it.id == "uad" }.defaultOn)
    }

    @Test fun wiringInSources() {
        val man = File(TestFiles.main, "AndroidManifest.xml").readText()
        assertTrue(man.contains("android.permission.INTERNET"))
        val run = File(TestFiles.code, "com/odak/app/block/SyncRunner.kt").readText()
        assertTrue(run.contains("startsWith(\"https://\")")); assertTrue(run.contains("MAX_BYTES"))
        val svc = File(TestFiles.code, "com/odak/app/block/OdakAccessibilityService.kt").readText()
        assertTrue("servis özel/eşitlenen uygulamaları yüklemeli", svc.contains("BlockCatalog.loadCustom(this)") && svc.contains("loadSynced(this)"))
        assertTrue(File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText().contains("SyncCard()"))
        assertTrue(File(TestFiles.code, "com/odak/app/MainActivity.kt").readText().contains("SyncRunner.autoIfDue"))
    }
}
