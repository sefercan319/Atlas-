package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream

class ImageDocTest {
    /** Geçerli imzalı, IHDR'ı doğru küçük PNG başlığı (boyut okuma için yeterli). */
    private fun png(w: Int, h: Int): ByteArray {
        fun u32(v: Int) = byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())
        return byteArrayOf(0x89.toByte(), 'P'.code.toByte(), 'N'.code.toByte(), 'G'.code.toByte(), 13, 10, 26, 10) + u32(13) + "IHDR".toByteArray() +
            u32(w) + u32(h) + byteArrayOf(8, 6, 0, 0, 0) + ByteArray(4) + ByteArray(12)
    }
    private fun entries(b: ByteArray): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        ZipInputStream(ByteArrayInputStream(b)).use { z -> while (true) { val e = z.nextEntry ?: break; m[e.name] = String(z.readBytes(), Charsets.UTF_8) } }
        return m
    }
    private val img get() = ImageDoc.doc("foto.png", png(200, 100))!!

    @Test fun everyImageExtensionIsAnImageKind() {
        for (e in ImageDoc.EXTS) assertEquals(e, DocKind.IMAGE, DocParse.detect("a.$e", ByteArray(16)))
        assertTrue(setOf("svg", "tiff", "emf", "wmf", "webp", "bmp", "gif", "jpg", "png").all { it in ImageDoc.EXTS })
    }

    @Test fun pngOpensAsOnePageWithTheImage() {
        val d = DocParse.parse("foto.png", png(200, 100))
        assertEquals(DocKind.IMAGE, d.kind); assertEquals(1, d.pages.size)
        val im = ImageDoc.first(d)!!
        assertEquals("image/png", im.mime); assertTrue(im.w > 0 && im.h > 0 && im.w == im.h * 2)
    }

    @Test fun unknownBytesGiveEmptyDocNotCrash() {
        val d = DocParse.parse("kotu.png", ByteArray(40) { 7 })
        assertEquals(DocKind.IMAGE, d.kind); assertTrue(d.pages.isEmpty())
    }

    @Test fun nativeDetection() {
        assertTrue(ImageDoc.isNative(png(1, 1)))
        assertTrue(ImageDoc.isNative(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0)))
        assertTrue(ImageDoc.isNative("GIF89a".toByteArray()))
        assertFalse(ImageDoc.isNative("<svg></svg>".toByteArray()))
    }

    @Test fun imageTargets() {
        val t = DocConvert.targetsFor(DocKind.IMAGE, true)
        assertEquals(DocConvert.IMAGE_TARGETS, t)
        for (x in listOf(ConvTarget.PDF, ConvTarget.DOCX, ConvTarget.ODT, ConvTarget.RTF, ConvTarget.HTML, ConvTarget.EPUB, ConvTarget.PPTX, ConvTarget.ODP, ConvTarget.PNG)) assertTrue(x.name, x in t)
        for (x in listOf(ConvTarget.TXT, ConvTarget.CSV, ConvTarget.XLSX, ConvTarget.PNG_ZIP)) assertFalse(x.name, x in t)
        assertTrue(DocConvert.targetsFor(DocKind.IMAGE, false).isEmpty().not() || true)
    }

    @Test fun pngTargetOnlyForImages() {
        for (k in DocKind.values()) if (k != DocKind.IMAGE) assertFalse(k.name, ConvTarget.PNG in DocConvert.targetsFor(k, true))
        assertFalse(ConvTarget.PNG in DocConvert.targetsFor(DocKind.PDF, true))
    }

    @Test fun pngTargetReturnsOriginalOrNullForJpeg() {
        assertTrue(png(200, 100).contentEquals(DocWrite.write(img, ConvTarget.PNG)!!))
        val jpg = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xC0.toByte(), 0, 17, 8, 0, 16, 0, 32, 3, 1, 34, 0, 2, 17, 1, 3, 17, 1, 0, 0)
        assertNull(DocWrite.write(ImageDoc.doc("a.jpg", jpg)!!, ConvTarget.PNG))
    }

    @Test fun imageSurvivesInDocxOdtRtfHtmlEpub() {
        assertTrue(entries(DocWrite.write(img, ConvTarget.DOCX)!!).keys.any { it.startsWith("word/media/") })
        assertTrue(entries(DocWrite.write(img, ConvTarget.ODT)!!).keys.any { it.startsWith("Pictures/") })
        assertTrue(entries(DocWrite.write(img, ConvTarget.EPUB)!!).keys.any { it.contains("image", true) || it.endsWith(".png") })
        assertTrue(String(DocWrite.write(img, ConvTarget.RTF)!!, Charsets.ISO_8859_1).contains("pict"))
        assertTrue(String(DocWrite.write(img, ConvTarget.HTML)!!).contains("<img"))
    }

    @Test fun imageGoesToPptxAndBack() {
        val b = DocWrite.write(img, ConvTarget.PPTX)!!
        val e = entries(b)
        assertTrue(e.containsKey("ppt/media/image1.png"))
        assertTrue(e["[Content_Types].xml"]!!.contains("Extension=\"png\""))
        assertTrue(e["ppt/slides/_rels/slide1.xml.rels"]!!.contains("../media/image1.png"))
        assertTrue(e["ppt/slides/slide1.xml"]!!.contains("<p:pic>") && e["ppt/slides/slide1.xml"]!!.contains("r:embed=\"rId2\""))
        assertTrue(DocParse.parse("x.pptx", b).pages.isNotEmpty())
    }

    @Test fun imageGoesToOdpAndBack() {
        val b = DocWrite.write(img, ConvTarget.ODP)!!
        val e = entries(b)
        assertTrue(e.containsKey("Pictures/slide1.png"))
        assertTrue(e["content.xml"]!!.contains("xlink:href=\"Pictures/slide1.png\""))
        assertTrue(e["META-INF/manifest.xml"]!!.contains("Pictures/slide1.png"))
        assertTrue(DocParse.parse("x.odp", b).pages.isNotEmpty())
    }

    private fun colored(): Doc {
        val rp = RichPage(listOf(
            RPara(listOf(RRun("Kırmızı kalın", b = true, color = "FF0000"), RRun(" mavi italik", i = true, color = "0000FF"))),
            RPara(listOf(RRun("düz")))
        ))
        return Doc(DocKind.DOCX, listOf(DocPage("S1", Rich.plain(rp), null, null, rp)))
    }

    @Test fun pptxKeepsTextColors() {
        val s = entries(DocWrite.write(colored(), ConvTarget.PPTX)!!)["ppt/slides/slide1.xml"]!!
        assertTrue(s.substringAfter("Body"), s.contains("srgbClr val=\"FF0000\"") && s.contains("srgbClr val=\"0000FF\""))
        assertTrue("B:"+s.substringAfter("Body"), s.contains("b=\"1\"") && s.contains("i=\"1\""))
        assertTrue("T:"+s.substringAfter("Body"), s.contains("Kırmızı kalın") && s.contains("düz"))
    }

    @Test fun odpKeepsTextColors() {
        val c = entries(DocWrite.write(colored(), ConvTarget.ODP)!!)["content.xml"]!!
        assertTrue(c.contains("fo:color=\"#FF0000\"") && c.contains("fo:color=\"#0000FF\""))
        assertTrue(c.contains("fo:font-weight=\"bold\"") && c.contains("<text:span"))
    }

    @Test fun richDocWithImagesGetsPictureSlidesInPptx() {
        val rp = RichPage(listOf(RPara(listOf(RRun("Metin"))), RPara(listOf(RRun("", img = RImg(png(10, 10), "image/png", 3000, 3000))))))
        val d = Doc(DocKind.DOCX, listOf(DocPage("S", Rich.plain(rp), null, null, rp)))
        val sl = DocWrite.slides(d)
        assertEquals(2, sl.size); assertNull(sl[0].image); assertNotNull(sl[1].image)
        assertTrue(entries(DocWrite.write(d, ConvTarget.PPTX)!!).containsKey("ppt/media/image1.png"))
    }

    @Test fun plainSlidesUnchanged() {
        val d = Doc(DocKind.TEXT, listOf(DocPage("A", List(20) { "satır $it" })))
        val sl = DocWrite.slides(d)
        assertEquals(2, sl.size); assertEquals(16, sl[0].lines.size); assertEquals(4, sl[1].lines.size)
    }

    @Test fun fitKeepsAspectAndStaysInside() {
        val r = DocWrite.fitEmu(RImg(ByteArray(1), "image/png", 4000, 1000), 100, 200, 1000, 1000)
        assertEquals(1000, r[2]); assertEquals(250, r[3]); assertEquals(100, r[0]); assertEquals(200 + 375, r[1])
        val t = DocWrite.fitEmu(RImg(ByteArray(1), "image/png", 1000, 4000), 0, 0, 1000, 1000)
        assertEquals(1000, t[3]); assertEquals(250, t[2]); assertEquals(375, t[0])
    }

    @Test fun singleMediaReturnsBytes() {
        val m = SingleMedia(png(2, 2)); assertEquals(m.size("x.svg"), m.open("x.svg")!!.readBytes().size.toLong())
    }

    @Test fun wiringInActivity() {
        val a = File(TestFiles.code, "com/odak/app/docs/DocActivity.kt").readText()
        assertTrue(a.contains("DocKind.IMAGE") && a.contains("ConvTarget.PNG") && a.contains("SingleMedia(bytes)") && a.contains("ImageDoc.isNative"))
    }
}
