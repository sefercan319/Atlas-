package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class CalmUiTest {
    private fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()

    @Test fun quietActionIsSharedAndImportsCompile() {
        val q = src("theme/QuietAction.kt")
        for (i in listOf("clickable", "Box", "heightIn", "padding", "RoundedCornerShape", "Alignment", "clip", "FontWeight", "TextOverflow", "dp", "sp"))
            assertTrue(i, q.contains("import") && Regex("import [\\w.]*\\b$i\\b").containsMatchIn(q))
        assertTrue(q.contains("heightIn(min = 44.dp)"))   // dokunma hedefi ≥ 44dp
    }
    @Test fun spacingConstantsAreUsedByCardAndTodo() {
        val q = src("theme/QuietAction.kt")
        assertTrue(q.contains("LIST_GAP = 12") && q.contains("CARD_PAD = 16") && q.contains("SCREEN_SIDE = 16"))
        assertTrue(src("theme/ThemedComponents.kt").contains("padding(Space.CARD_PAD.dp)"))
        assertTrue(src("todo/TodoScreen.kt").contains("Space.LIST_GAP.dp"))
    }
    @Test fun blockSortAndPagingAreQuiet() {
        val b = src("block/BlockScreen.kt")
        assertTrue(b.contains("QuietAction(label,") && b.contains("selected = sortMode == i"))
        assertTrue(b.contains("QuietAction(stringResource(R.string.blk_less)") && b.contains("QuietAction(stringResource(R.string.blk_all)"))
        assertTrue(b.contains("ThemedButton(stringResource(R.string.blk_more, rem)"))   // ana eylem öne çıkar
    }
    @Test fun todoSecondaryActionsAreQuietPrimaryStays() {
        val t = src("todo/TodoScreen.kt")
        for (k in listOf("QuietAction(\"🧰\"", "QuietAction(\"⋯\"", "QuietAction(\"⇅\""))
            assertTrue(k, t.contains(k))
        assertTrue(t.contains("ThemedButton(\"+\""))
    }
    @Test fun planNavAndOptionsAreQuiet() {
        val p = src("plan/PlanCommon.kt")
        assertTrue(p.contains("QuietAction(\"‹\"") && p.contains("QuietAction(\"›\"") && p.contains("\"⋯ •\" else \"⋯\", { optOpen = true }"))
        assertTrue(p.contains("text = stringResource(R.string.plan_add)"))   // Ekle düğmesi ana eylem
    }
    @Test fun moreScreenHasAiryLayout() {
        val m = src("settings/MoreScreen.kt")
        assertTrue(m.contains("padding(vertical = 6.dp)") && m.contains("spacedBy(12.dp)") && m.contains("top = 20.dp"))
    }
}

class CalmUiEverywhereTest {
    private fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    @Test fun quietActionMarksCheckedChoicesAutomatically() {
        assertTrue(src("theme/QuietAction.kt").contains("selected: Boolean = text.startsWith(\"✔\")"))
    }
    @Test fun dialogDismissButtonsAreQuietEverywhere() {
        File(TestFiles.code, "com/odak/app").walkTopDown().filter { it.extension == "kt" }.forEach {
            val t = it.readText()
            assertTrue("${it.name}: ✕ kapat düğmesi sönük olmalı", !Regex("dismissButton = \\{\\s*ThemedButton\\(\"✕\"").containsMatchIn(t))
        }
    }
    @Test fun settingsChoiceRowsAreQuiet() {
        val s = src("settings/SettingsScreen.kt"); val m = src("settings/MoreCards.kt")
        assertTrue(s.contains("QuietAction((if (sub == i)") || s.contains("names.forEachIndexed { i, n -> com.odak.app.theme.QuietAction("))
        assertTrue(s.contains("QuietAction(if (mode == i)"))
        for (k in listOf("(m == lead)", "(scale == v)", "(cur == v)")) assertTrue(k, m.contains("QuietAction((if $k"))
    }
    @Test fun notesScreensUseQuietToolbars() {
        val e = src("notes/NoteEditor.kt"); val l = src("notes/NotesList.kt")
        for (k in listOf("QuietAction(\"←\"", "QuietAction(\"↶\"", "QuietAction(\"↷\"", "QuietAction(\"⋯\", { more")) assertTrue(k, e.contains(k))
        assertTrue(l.contains("QuietAction((if (sort == mode)") && l.contains("QuietAction((if (trash)"))
        assertTrue(l.contains("ThemedButton(\"＋ \" + stringResource(R.string.notes_new)"))   // ana eylem
    }
    @Test fun screenTimeDocsScheduleQuietNav() {
        val st = src("block/ScreenTimeScreen.kt"); val d = src("docs/DocActivity.kt"); val sc = src("schedule/ScheduleScreen.kt")
        assertTrue(st.contains("QuietAction(\"◀\"") && st.contains("QuietAction(\"▶\"") && st.contains("QuietAction(\"ⓘ\""))
        assertTrue(d.contains("QuietAction(\"◀\"") && d.contains("QuietAction(\"🔍\""))
        assertTrue(sc.contains("QuietAction((if (day == d)") && sc.contains("ThemedButton(\"＋ \" + stringResource(R.string.plan_add)"))
    }
    @Test fun primaryActionsStayProminent() {
        assertTrue(src("block/BlockScreen.kt").contains("ThemedButton(\"➕ \" + stringResource(R.string.custom_app_add)"))
        assertTrue(src("settings/Guide.kt").contains("ThemedButton(stringResource(R.string.guide_start)"))
        assertTrue(src("docs/DocActivity.kt").contains("ThemedButton(\"📂 \" + stringResource(R.string.doc_open)"))
    }
}

class CalmUiCarefulTest {
    private fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    @Test fun quietTextKeepsContrast() {
        val q = src("theme/QuietAction.kt")
        assertTrue(q.contains("Contrast.alphaFor(") && q.contains("Contrast.readable("))
        assertTrue(!q.contains("alpha = 0.6f"))
    }
    @Test fun dimAlphaMeetsMinimumRatioOnDarkAndLight() {
        for ((fg, bg) in listOf(0xFFB8FFC8.toInt() to 0xFF020B04.toInt(), 0xFF1A1A1A.toInt() to 0xFFF3F3F3.toInt(), 0xFF2B1D12.toInt() to 0xFFD8C9AC.toInt())) {
            val a = com.odak.app.theme.Contrast.alphaFor(fg, bg, 0.7)
            val c = ((Math.round(a * 255).toInt()) shl 24) or (fg and 0xFFFFFF)
            assertTrue("$fg/$bg", a >= 0.7 && com.odak.app.theme.Contrast.ratio(c, bg) >= 4.5)
        }
    }
    @Test fun languageCardMarksCurrentAndRowsFillWidth() {
        val m = src("settings/MoreCards.kt")
        assertTrue(m.contains("applicationLocales") && m.contains("(if (tag == curTag) \"✔ \" else \"\") + name"))
        assertTrue(m.contains("Modifier.weight(1f))") && m.contains("Spacer(Modifier.weight((3 - rowItems.size).toFloat()))"))
    }
    @Test fun crowdedRowsScrollOrSplitEvenly() {
        assertTrue(src("notes/NotesList.kt").contains("Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {\n            ThemedButton(\"＋ \""))
        assertTrue(src("block/ScreenTimeScreen.kt").contains("{ tab = i }, Modifier.weight(1f))"))
    }
}

class TodoRowCalmTest {
    private val t = File(TestFiles.code, "com/odak/app/todo/TodoScreen.kt").readText()
    @Test fun collapsedRowKeepsOnlyCheckTitleDelete() {
        val head = t.substring(t.indexOf("Column(Modifier.weight(1f).plainClick { open = !open })"), t.indexOf("if (open) {"))
        assertTrue(!head.contains("\"📅\"") && !head.contains("\"⏭\"") && head.contains("DeleteMark("))
    }
    @Test fun extraActionsAppearWhenOpened() {
        val open = t.substring(t.indexOf("if (open) {"))
        assertTrue(open.contains("QuietAction(\"📅\"") && open.contains("QuietAction(\"⏭\""))
    }
}
