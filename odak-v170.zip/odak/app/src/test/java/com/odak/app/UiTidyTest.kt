package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class UiTidyTest {
    private fun src(p: String) = File("src/main/java/com/odak/app/$p").readText()
    @Test fun sortButtonsShareOneRowWithWeights() {
        val s = src("block/BlockScreen.kt")
        assertTrue(s.contains("Modifier.weight(if (i == 2) 1.6f else 1f)"))
        assertTrue(s.contains("{ onlyActive = !onlyActive }, Modifier.fillMaxWidth())"))
    }
    @Test fun scheduleDeleteMovedIntoBody() {
        val s = src("schedule/ScheduleScreen.kt")
        assertTrue(s.contains("ThemedButton(\"🗑\", onDelete, Modifier.fillMaxWidth())"))
        assertTrue(!s.contains("dismissButton = {\n            Row"))
    }
    @Test fun moreTilesEqualHeightPerRow() {
        val s = src("settings/MoreScreen.kt")
        assertTrue(s.contains("IntrinsicSize.Min") && s.contains("fillMaxHeight()") && s.contains("import androidx.compose.foundation.layout.fillMaxHeight"))
    }
    @Test fun buttonLabelNeverWrapsPerLetter() {
        assertTrue(src("theme/ThemedComponents.kt").contains("maxLines = 2, overflow = TextOverflow.Ellipsis"))
    }
}
