package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class CatalogPerfTest {
    private val src = File(TestFiles.code, "com/odak/app/block/BlockData.kt").readText()
    @Test fun appsListIsCachedNotResortedEachCall() {
        assertTrue(src.contains("private var appsCache") && src.contains("if (c != null && key == appsCacheKey) return c"))
    }
    @Test fun baseIdsAreUniqueForLazyListKeys() {
        val ids = Regex("BlockApp\\(\"([^\"]+)\"").findAll(src).map { it.groupValues[1] }.filter { !it.contains("$") }.toList()
        assertTrue(ids.size > 200)
        assertEquals(ids.size, ids.toSet().size)
    }
    @Test fun pinGateCountsDownAndStartsLocked() {
        val s = File(TestFiles.code, "com/odak/app/block/Pin.kt").readText()
        assertTrue(s.contains("LaunchedEffect(lockSec)") && s.contains("kotlinx.coroutines.delay(1000)") && s.contains("mutableStateOf(((Pin.lockRemainingMs(ctx)"))
    }
}
