package com.odak.app

import com.odak.app.docs.*
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ImageNormTest {
    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }
    private fun pad(h: ByteArray, n: Int = 64) = h + ByteArray(maxOf(0, n - h.size))
    private val png = pad(bytes(0x89, 'P'.code, 'N'.code, 'G'.code, 13, 10, 26, 10), 40)
    private val bmp = pad("BM".toByteArray() + ByteArray(20))
    private val webp = pad("RIFF".toByteArray() + bytes(0, 0, 0, 0) + "WEBPVP8 ".toByteArray())

    @After fun reset() { RImg.converter = null }

    @Test fun sniffKinds() {
        assertEquals("png", ImgSniff.kind(png))
        assertEquals("jpeg", ImgSniff.kind(pad(bytes(0xFF, 0xD8, 0xFF, 0xE0))))
        assertEquals("gif", ImgSniff.kind(pad("GIF89a".toByteArray())))
        assertEquals("bmp", ImgSniff.kind(bmp)); assertEquals("webp", ImgSniff.kind(webp))
        assertEquals("tiff", ImgSniff.kind(pad(bytes('I'.code, 'I'.code, '*'.code, 0))))
        assertEquals("tiff", ImgSniff.kind(pad(bytes('M'.code, 'M'.code, 0, 42))))
        val emf = ByteArray(80); emf[0] = 1; " EMF".toByteArray().copyInto(emf, 40)
        assertEquals("emf", ImgSniff.kind(emf))
        assertEquals("wmf", ImgSniff.kind(pad(bytes(0xD7, 0xCD, 0xC6, 0x9A))))
        assertEquals("svg", ImgSniff.kind("<?xml version=\"1.0\"?><svg xmlns=\"x\"></svg>".toByteArray()))
        assertEquals("svg", ImgSniff.kind("﻿  <svg width=\"1\"/>".toByteArray()))
        assertEquals("svgz", ImgSniff.kind(pad(bytes(0x1F, 0x8B, 8, 0))))
        assertEquals("avif", ImgSniff.kind(pad(bytes(0, 0, 0, 24) + "ftypavif".toByteArray())))
        assertEquals("heif", ImgSniff.kind(pad(bytes(0, 0, 0, 24) + "ftypheic".toByteArray())))
        assertEquals("none", ImgSniff.kind("hello world, not an image".toByteArray()))
        assertEquals("none", ImgSniff.kind(bytes(1, 2)))
    }

    @Test fun makeConvertsOnlyWithConverter() {
        assertNull(RImg.make("a.bmp", bmp))
        RImg.converter = { png }
        val r = RImg.make("a.bmp", bmp)!!
        assertEquals("image/png", r.second); assertTrue(r.first.contentEquals(png))
        assertEquals("image/png", RImg.make("x.png", png)!!.second)   // yerel biçim olduğu gibi
        RImg.converter = { null }
        assertNull(RImg.make("a.webp", webp))
        RImg.converter = { throw IllegalStateException("x") }
        assertNull(RImg.make("a.webp", webp))                          // çevirici çökse de belge okunur
        RImg.converter = { bytes(1, 2, 3, 4, 5, 6, 7, 8, 9) }
        assertNull(RImg.make("a.webp", webp))                          // geçersiz çıktı kabul edilmez
    }

    private fun docx(): Pair<ByteArray, Map<String, ByteArray>> {
        val d = """<?xml version="1.0"?><w:document xmlns:w="w" xmlns:wp="wp" xmlns:a="a" xmlns:r="r"><w:body><w:p><w:r><w:drawing><wp:inline><wp:extent cx="1828800" cy="914400"/><a:graphic><a:graphicData><a:blip r:embed="rId5"/></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p></w:body></w:document>"""
        val rels = """<?xml version="1.0"?><Relationships><Relationship Id="rId5" Type="x/image" Target="media/image1.bmp"/></Relationships>"""
        return d.toByteArray() to mapOf("word/_rels/document.xml.rels" to rels.toByteArray(), "word/media/image1.bmp" to bmp)
    }
    @Test fun docxBmpImageIsKeptViaConverter() {
        val (d, e) = docx()
        val none = RichDocx.parse(d, null, null, e)
        assertTrue(none.blocks.filterIsInstance<RPara>().none { p -> p.runs.any { it.img != null } })
        RImg.converter = { png }
        val rp = RichDocx.parse(d, null, null, e)
        val im = rp.blocks.filterIsInstance<RPara>().flatMap { it.runs }.mapNotNull { it.img }.single()
        assertEquals("image/png", im.mime); assertEquals(2880, im.w); assertEquals(1440, im.h)
    }

    // ---------- RTF ----------
    private fun rtfImgs(rp: RichPage) = rp.blocks.filterIsInstance<RPara>().flatMap { it.runs }.mapNotNull { it.img }
    private val hexPng = png.joinToString("") { "%02x".format(it) }

    @Test fun rtfTurkishCodepageAndBold() {
        val rp = RichRtf.parse("{\\rtf1\\ansi\\ansicpg1254\\deff0{\\fonttbl{\\f0\\fcharset162 Arial;}}\\pard \\'fe\\'f0\\'fd\\'e7 \\b kalin\\b0  son\\par}")!!
        val p = rp.blocks.filterIsInstance<RPara>().single()
        assertEquals("şğıç kalin son", p.plain)
        assertTrue(p.runs.any { it.b && it.text.contains("kalin") })
    }
    @Test fun rtfUnicodeEscapeSkipsFallback() {
        val rp = RichRtf.parse("{\\rtf1\\ansi\\uc1 a\\u351?b\\par}")!!
        assertEquals("aşb", rp.blocks.filterIsInstance<RPara>().single().plain)
    }
    @Test fun rtfPictureEmbedded() {
        val rp = RichRtf.parse("{\\rtf1\\ansi Metin {\\pict\\pngblip\\picwgoal1440\\pichgoal720 $hexPng}\\par}")!!
        val im = rtfImgs(rp).single()
        assertEquals("image/png", im.mime); assertEquals(1440, im.w); assertEquals(720, im.h)
    }
    @Test fun rtfShppictCountsOnceNonshppictSkipped() {
        val rp = RichRtf.parse("{\\rtf1{\\*\\shppict{\\pict\\pngblip\\picwgoal100\\pichgoal100 $hexPng}}{\\nonshppict{\\pict\\wmetafile8 $hexPng}}\\par}")!!
        assertEquals(1, rtfImgs(rp).size)
    }
    @Test fun rtfEmfGoesThroughConverter() {
        val emf = ByteArray(80); emf[0] = 1; " EMF".toByteArray().copyInto(emf, 40)
        val hex = emf.joinToString("") { "%02x".format(it) }
        val src = "{\\rtf1{\\pict\\emfblip\\picwgoal500\\pichgoal500 $hex}\\par}"
        assertEquals(0, rtfImgs(RichRtf.parse(src)!!).size) // çevirici yok → resim yok (belge yine açılır)
        RImg.converter = { png }
        assertEquals(1, rtfImgs(RichRtf.parse(src)!!).size)
    }
    @Test fun rtfTable() {
        val rp = RichRtf.parse("{\\rtf1\\trowd\\cellx3000\\cellx6000\\intbl A\\cell B\\cell\\row\\trowd\\cellx3000\\cellx6000\\intbl C\\cell D\\cell\\row\\pard Sonra\\par}")!!
        val t = rp.blocks.filterIsInstance<RTable>().single()
        assertEquals(2, t.rows.size); assertEquals(listOf(3000, 3000), t.cols)
        assertEquals("A", t.rows[0][0].paras.single().plain); assertEquals("D", t.rows[1][1].paras.single().plain)
        assertEquals("Sonra", (rp.blocks.last() as RPara).plain)
    }
    @Test fun rtfColorAndNotRtf() {
        val rp = RichRtf.parse("{\\rtf1{\\colortbl;\\red255\\green0\\blue0;}\\cf1 kirmizi\\par}")!!
        assertEquals("FF0000", rp.blocks.filterIsInstance<RPara>().single().runs.single().color)
        assertNull(RichRtf.parse("duz metin"))
    }

    // ---------- XLSX ----------
    @Test fun xlsxDrawingImages() {
        RImg.converter = { png }
        val e = mapOf(
            "xl/worksheets/_rels/sheet1.xml.rels" to """<Relationships><Relationship Id="rId1" Type="http://x/vmlDrawing" Target="../drawings/vml1.vml"/><Relationship Id="rId2" Type="http://x/drawing" Target="../drawings/drawing1.xml"/></Relationships>""".toByteArray(),
            "xl/drawings/drawing1.xml" to """<xdr:wsDr><xdr:pic><xdr:blipFill><a:blip r:embed="rId1"/></xdr:blipFill></xdr:pic><xdr:pic><a:blip r:embed="rId2"/></xdr:pic></xdr:wsDr>""".toByteArray(),
            "xl/drawings/_rels/drawing1.xml.rels" to """<Relationships><Relationship Id="rId1" Type="x/image" Target="../media/image1.png"/><Relationship Id="rId2" Type="x/image" Target="../media/image2.webp"/></Relationships>""".toByteArray(),
            "xl/media/image1.png" to png, "xl/media/image2.webp" to webp
        )
        assertEquals(2, RichXlsx.images(e, "xl/worksheets/sheet1.xml").size)
        assertTrue(RichXlsx.images(emptyMap(), "xl/worksheets/sheet1.xml").isEmpty())
    }

    // ---------- bağlantılar ----------
    private fun code(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    @Test fun wiring() {
        assertTrue(code("CrashReport.kt").contains("ImageConv.install()"))
        assertTrue(code("docs/ImageConv.kt").contains("RImg.converter") && code("docs/ImageConv.kt").contains("decodeSampled"))
        assertTrue(code("docs/DocParse.kt").contains("RichRtf.parse") && code("docs/DocParse.kt").contains("RichXlsx.images"))
        for (f in listOf("docs/RichDocx.kt", "docs/RichOdt.kt", "docs/RichPptx.kt", "docs/HtmlRich.kt")) assertTrue(f, code(f).contains("RImg.make("))
        assertTrue(code("docs/RichWrite.kt").contains("RImg.converter"))
    }
}
