package com.odak.app

import com.odak.app.logic.LockPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class LockPolicyTest {
    private val LP = LockPolicy

    @Test fun defaultsKeepOldBehaviour() {
        assertEquals(LP.BLOCK or LP.NOTES, LP.DEFAULT_SCOPES); assertEquals(3, LP.DEFAULT_TIMEOUT)
    }

    @Test fun scopeToggling() {
        var s = LP.DEFAULT_SCOPES
        assertTrue(LP.has(s, LP.BLOCK)); assertFalse(LP.has(s, LP.APP))
        s = LP.toggle(s, LP.APP); assertTrue(LP.has(s, LP.APP))
        s = LP.toggle(s, LP.BLOCK); assertFalse(LP.has(s, LP.BLOCK))
        assertEquals(LP.APP or LP.NOTES, s)
        assertEquals(LP.ALL, LP.cleanScopes(-1)); assertEquals(0, LP.cleanScopes(16))
    }

    @Test fun timeoutsAreValidated() {
        assertEquals(listOf(0, 1, 3, 5, 15, -1), LP.TIMEOUTS)
        for (t in LP.TIMEOUTS) assertEquals(t, LP.cleanTimeout(t))
        assertEquals(3, LP.cleanTimeout(7)); assertEquals(3, LP.cleanTimeout(-5))
    }

    @Test fun unlockWindow() {
        assertEquals(1000 + 180_000L, LP.unlockedUntil(1000, 3))
        assertEquals(1000L, LP.unlockedUntil(1000, 0))
        assertEquals(Long.MAX_VALUE, LP.unlockedUntil(1000, LP.FOREVER))
    }

    @Test fun lockedLogic() {
        assertFalse(LP.isLocked(false, 5, 0))
        assertTrue(LP.isLocked(true, 5, 0))
        val until = LP.unlockedUntil(1000, 1)
        assertFalse(LP.isLocked(true, 1000 + 59_999, until)); assertTrue(LP.isLocked(true, 1000 + 60_000, until))
        assertTrue("0 dk: hemen kilitli", LP.isLocked(true, 1000, LP.unlockedUntil(1000, 0)))
        assertFalse("kapanana dek: hiç kilitlenmez", LP.isLocked(true, Long.MAX_VALUE - 1, LP.unlockedUntil(1000, LP.FOREVER)))
    }

    @Test fun gateOnlyForChosenScopes() {
        val s = LP.BLOCK or LP.NOTES
        assertTrue(LP.needsGate(true, s, LP.BLOCK, 10, 0)); assertTrue(LP.needsGate(true, s, LP.NOTES, 10, 0))
        assertFalse(LP.needsGate(true, s, LP.APP, 10, 0)); assertFalse(LP.needsGate(true, s, LP.SETTINGS, 10, 0))
        assertFalse("şifre yoksa hiçbir yer kilitlenmez", LP.needsGate(false, LP.ALL, LP.APP, 10, 0))
        assertFalse("açıkken sormaz", LP.needsGate(true, s, LP.BLOCK, 10, 100))
    }

    @Test fun pinRules() {
        assertEquals("1234", LP.filterInput("1a2b3c4", false)); assertEquals("12345678", LP.filterInput("1234567890", false))
        assertTrue(LP.valid("1234", false)); assertTrue(LP.valid("12345678", false))
        assertFalse(LP.valid("123", false)); assertFalse(LP.valid("123456789", false)); assertFalse(LP.valid("12a4", false))
    }

    @Test fun passwordRules() {
        assertEquals("Ab1!çş", LP.filterInput("Ab1!çş", true)); assertEquals(32, LP.filterInput("a".repeat(50), true).length)
        assertTrue(LP.valid("abcd", true)); assertTrue(LP.valid("Sifre 123!", true)); assertTrue(LP.valid("a".repeat(32), true))
        assertFalse(LP.valid("abc", true)); assertFalse(LP.valid("    ", true)); assertFalse(LP.valid("a".repeat(33), true))
    }

    private fun code(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()

    @Test fun wiring() {
        val pin = code("block/Pin.kt")
        assertTrue(pin.contains("fun needs(") && pin.contains("fun unlock(c: Context)") && pin.contains("fun applySecure") && pin.contains("fun LockGate"))
        assertFalse("sabit 3 dk kalmamalı", pin.contains("3 * 60_000"))
        assertTrue(code("block/BlockScreen.kt").contains("LockPolicy.BLOCK"))
        assertTrue(code("notes/NotesList.kt").contains("LockPolicy.NOTES"))
        val main = code("MainActivity.kt")
        assertTrue(main.contains("LockPolicy.APP") && main.contains("LockPolicy.SETTINGS") && main.contains("LockSignal.tick++") && main.contains("applySecure"))
        val st = code("settings/SettingsScreen.kt")
        assertTrue(st.contains("lock_title") && st.contains("lock_timeout") && st.contains("lock_secure") && st.contains("Pin.setWithType"))
        assertTrue(code("theme/ThemedComponents.kt").contains("textPassword"))
    }

    @Test fun lockStringsInAllLocales() {
        val keys = listOf("lock_title", "lock_type", "lock_type_pin", "lock_type_pw", "lock_enter", "lock_set", "lock_change", "lock_remove", "lock_new", "lock_len_pin", "lock_len_pw",
            "lock_protect", "lock_s_app", "lock_s_block", "lock_s_notes", "lock_s_settings", "lock_timeout", "lock_t0", "lock_tend", "lock_secure", "lock_manage", "lock_open")
        for ((n, f) in TestFiles.stringFiles()) { val m = TestFiles.parseStrings(f); for (k in keys) assertTrue("$n $k", !m[k].isNullOrBlank()) }
    }

    @Test fun backupStillExcludesPinFile() {
        assertTrue(File(TestFiles.res, "xml/backup_rules.xml").readText().contains("odak_pin.xml"))
    }
}

class BiometricTest {
    private val main = com.odak.app.TestFiles.main
    private fun code(p: String) = java.io.File(com.odak.app.TestFiles.code, p).readText()

    @Test fun offeredOnlyWhenAllTrue() {
        val f = LockPolicy::biometricOffered
        assertTrue(f(true, true, true))
        assertFalse(f(false, true, true)); assertFalse(f(true, false, true)); assertFalse(f(true, true, false))
    }
    @Test fun wiring() {
        val bio = code("com/odak/app/block/Bio.kt")
        assertTrue(bio.contains("BIOMETRIC_WEAK") && bio.contains("canAuthenticate"))
        assertFalse(bio.contains("androidx.biometric"))
        assertTrue(java.io.File(main, "AndroidManifest.xml").readText().contains("android.permission.USE_BIOMETRIC"))
        val pin = code("com/odak/app/block/Pin.kt")
        assertTrue(pin.contains("Bio.prompt") && pin.contains("biometricOffered") && pin.contains("fun setBio"))
        assertTrue(code("com/odak/app/settings/SettingsScreen.kt").contains("bio_option"))
    }
    @Test fun forgotPasswordResetsViaPhoneAuth() {
        val bio = code("com/odak/app/block/Bio.kt")
        assertTrue(bio.contains("DEVICE_CREDENTIAL") && bio.contains("fun promptReset") && bio.contains("fun resetAvailable"))
        val pin = code("com/odak/app/block/Pin.kt")
        assertTrue(pin.contains("Bio.promptReset(ctx, forgotT) { Pin.clear(ctx)"))
    }
    @Test fun passwordStaysFallback() {
        assertTrue(code("com/odak/app/block/Pin.kt").contains("R.string.pin_ok"))
    }
    @Test fun stringsInAllLocales() {
        val keys = listOf("pin_forgot", "pin_forgot_title", "bio_option", "bio_use", "bio_none", "bio_title", "bio_cancel")
        val all = com.odak.app.TestFiles.stringFiles()
        assertTrue(all.size >= 9)
        for ((name, f) in all) { val txt = f.readText(); for (k in keys) assertTrue("$name $k", txt.contains("name=\"$k\"")) }
    }
}
