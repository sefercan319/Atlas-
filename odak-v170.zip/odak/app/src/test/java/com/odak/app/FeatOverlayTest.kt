package com.odak.app

import com.odak.app.logic.ScrPure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class FeatOverlayTest {
    private fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()

    @Test fun placeholdersAreFilled() {
        assertEquals("DM süren bitti · Instagram", ScrPure.fill("{feature} süren bitti · {app}", "DM", "Instagram"))
        assertEquals("{x} DM", ScrPure.fill("{x} {feature}", "DM", "A"))
    }
    @Test fun textColorFollowsBackground() {
        assertTrue(ScrPure.isLight(0xFFFFFFFF.toInt())); assertFalse(ScrPure.isLight(0xFF2B2930.toInt()))
        assertTrue(ScrPure.isLight(0xFFFFEB3B.toInt())); assertFalse(ScrPure.isLight(0xFF1B5E20.toInt()))
    }
    @Test fun scaleAndRateLimit() {
        assertEquals(0.75f, ScrPure.scale("0")); assertEquals(1.35f, ScrPure.scale("2")); assertEquals(1f, ScrPure.scale(""))
        assertFalse(ScrPure.mayShow(1000, 0, 2500)); assertTrue(ScrPure.mayShow(3000, 0, 2500))
    }
    @Test fun serviceShowsOverlayInsteadOfClosingApp() {
        val s = src("block/OdakAccessibilityService.kt")
        assertTrue(s.contains("FeatOverlay.show(this, fname, app.name,"))
        assertTrue("toast yalnız yedek", s.indexOf("FeatOverlay.show") < s.indexOf("Toast.makeText(this, com.odak.app.notify.Msgs.text(this, \"toast\""))
    }
    @Test fun warningUsesTheSelectedDesignStylesCardAndButton() {
        val a = src("block/FeatWarnActivity.kt")
        assertTrue(a.contains("ThemedCard(w)") && a.contains("ThemedButton(stringResource(R.string.pin_ok)") && a.contains("tokensFor(style)") && a.contains("Design(style)"))
        assertTrue(a.contains("ScrPure.fill(") && a.contains("ScrPhoto.bitmap(me, \"ftr\")") && a.contains("delay(15_000)"))
        assertFalse("düz Android Button yok", a.contains("android.widget.Button"))
        assertTrue(src("block/FeatOverlay.kt").contains("FeatWarnActivity::class.java"))
        val m = File(TestFiles.main, "AndroidManifest.xml").readText()
        assertTrue(m.contains(".block.FeatWarnActivity") && m.contains("Theme.Translucent.NoTitleBar"))
    }
    @Test fun photoAcceptsEveryImageTypeThroughTheConverter() {
        val p = src("block/ScrPhoto.kt")
        assertTrue(p.contains("RImg.make(\"\", raw)") && p.contains("ModelPure.PHOTO_MAX") && p.contains("OutOfMemoryError"))
        assertTrue(src("block/Extras.kt").contains("launch(\"image/*\")"))
    }
    @Test fun settingsEditThreeScreensWithPhoto() {
        val e = src("block/Extras.kt")
        assertTrue(e.contains("listOf(\"blk\", \"lim\", \"ftr\")") && e.contains("ScrPhoto.save(ctx, kind, uri)") && e.contains("ScrPhoto.clear(ctx, kind)"))
        assertTrue(src("block/BlockActivity.kt").contains("ScrPhoto.bitmap(me, kind)"))
    }
    @Test fun newStringsInAllLocales() {
        for ((n, f) in TestFiles.stringFiles()) { val t = f.readText(); for (k in listOf("scr_ftr", "ftr_blocked", "ftr_limit", "scr_photo", "scr_photo_clear")) assertTrue("$n/$k", t.contains("name=\"$k\"")) }
        for ((n, f) in TestFiles.stringFiles()) { val t = f.readText(); assertTrue(n, t.contains("%1\$s")) }
    }
}
