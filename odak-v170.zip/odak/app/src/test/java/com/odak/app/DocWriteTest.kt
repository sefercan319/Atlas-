package com.odak.app

import com.odak.app.docs.ConvTarget
import com.odak.app.docs.Doc
import com.odak.app.docs.DocConvert
import com.odak.app.docs.DocKind
import com.odak.app.docs.DocPage
import com.odak.app.docs.DocParse
import com.odak.app.docs.DocWrite
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream

/** v0.56: dosya türleri arası dönüştürme — yazıcılar, planlama ve geri okuma. */
class DocWriteTest {
    private val sample = Doc(DocKind.DOCX, listOf(
        DocPage("Giriş", listOf("Merhaba dünya ğüşiöçİ", "İkinci\nsatır"), listOf(listOf("Ad", "Puan"), listOf("Ali", "12"), listOf("Zeynep", "3.5"))),
        DocPage("Sayfa 2", listOf("Sadece yazı"), null)
    ))

    private fun unzip(b: ByteArray): LinkedHashMap<String, ByteArray> {
        val m = LinkedHashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(b)).use { z -> while (true) { val e = z.nextEntry ?: break; m[e.name] = z.readBytes() } }
        return m
    }
    private fun wellFormed(b: ByteArray) {
        val f = javax.xml.parsers.DocumentBuilderFactory.newInstance()
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
        f.isNamespaceAware = true
        f.newDocumentBuilder().parse(ByteArrayInputStream(b))
    }
    private fun allText(d: Doc) = d.pages.joinToString("\u0001") { p -> p.title + "\u0001" + p.paragraphs.joinToString("\u0001") + "\u0001" + (p.table ?: emptyList()).joinToString("\u0001") { it.joinToString("\u0001") } }
    private fun squash(s: String) = s.filterNot { it.isWhitespace() }

    // ---- planlama
    @Test fun pdfGoesToEverythingButPdf() { val t = DocConvert.targetsFor(DocKind.PDF, true); assertFalse(ConvTarget.PDF in t); assertTrue(ConvTarget.PNG_ZIP in t); assertEquals(ConvTarget.values().size - 2, t.size); for (x in listOf(ConvTarget.DOCX, ConvTarget.XLSX, ConvTarget.PPTX, ConvTarget.ODT, ConvTarget.TXT, ConvTarget.CSV, ConvTarget.HTML)) assertTrue(x.name, x in t) }
    @Test fun noTargetsForGoogleOpaqueUnknown() { for (k in listOf(DocKind.GOOGLE, DocKind.OPAQUE, DocKind.UNKNOWN)) assertTrue(DocConvert.targetsFor(k, true).isEmpty()) }
    @Test fun noTargetsWithoutContent() { assertTrue(DocConvert.targetsFor(DocKind.DOCX, false).isEmpty()) }
    @Test fun docxExcludesItselfOnly() { val t = DocConvert.targetsFor(DocKind.DOCX, true); assertFalse(ConvTarget.DOCX in t); assertTrue(ConvTarget.PDF in t); assertTrue(ConvTarget.XLSX in t); assertFalse(ConvTarget.PNG_ZIP in t); assertEquals(ConvTarget.values().size - 3, t.size) }
    @Test fun textGetsAllTargets() { assertEquals(ConvTarget.values().size - 2, DocConvert.targetsFor(DocKind.TEXT, true).size) }
    @Test fun legacyGetsAllTargets() { assertEquals(ConvTarget.values().size - 2, DocConvert.targetsFor(DocKind.LEGACY, true).size) }
    @Test fun everyOfficeKindCanReachEveryOther() {
        val pairs = mapOf(DocKind.DOCX to ConvTarget.DOCX, DocKind.XLSX to ConvTarget.XLSX, DocKind.PPTX to ConvTarget.PPTX, DocKind.ODT to ConvTarget.ODT, DocKind.ODS to ConvTarget.ODS, DocKind.ODP to ConvTarget.ODP)
        for ((k, self) in pairs) for ((_, other) in pairs) if (other != self) assertTrue("$k → $other", other in DocConvert.targetsFor(k, true))
    }
    @Test fun outNameReplacesExtension() { assertEquals("rapor.pdf", DocConvert.outName("rapor.docx", ConvTarget.PDF)); assertEquals("a.final.csv", DocConvert.outName("a.final.xlsx", ConvTarget.CSV)); assertEquals("dosya.txt", DocConvert.outName("dosya", ConvTarget.TXT)) }
    @Test fun outNameSanitizes() { assertEquals("a_b_c_.txt", DocConvert.outName("a/b:c?.doc", ConvTarget.TXT)); assertEquals("belge.pdf", DocConvert.outName(".docx", ConvTarget.PDF)); assertEquals("belge.md", DocConvert.outName("...", ConvTarget.MD)) }
    @Test fun outNameCapped() { assertEquals(80 + 5, DocConvert.outName("x".repeat(200) + ".doc", ConvTarget.HTML).length) }

    // ---- yardımcılar
    @Test fun xmlDropsControlChars() { assertEquals("ab", DocConvert.xml("a\u0001\u0008b")); assertEquals("a\tb\nc\r", DocConvert.xml("a\tb\nc\r")) }
    @Test fun xmlEscapes() { assertEquals("&amp;&lt;&gt;&quot;", DocConvert.xml("&<>\"")) }
    @Test fun xmlKeepsEmojiDropsLoneSurrogate() { assertEquals("😀", DocConvert.xml("😀")); assertEquals("ab", DocConvert.xml("a\uD83Db")); assertEquals("ab", DocConvert.xml("a\uDE00b")); assertEquals("ab", DocConvert.xml("a\uFFFEb\uFFFF")) }
    @Test fun sheetNameRules() {
        assertEquals("Sayfa3", DocConvert.sheetName("", 3, emptySet())); assertEquals("a b c", DocConvert.sheetName("a[b]c", 1, emptySet()).replace("  ", " "))
        assertEquals(31, DocConvert.sheetName("x".repeat(60), 1, emptySet()).length); assertEquals("Ad (2)", DocConvert.sheetName("Ad", 2, setOf("ad"))); assertEquals("Ad (3)", DocConvert.sheetName("Ad", 3, setOf("Ad", "Ad (2)")))
    }
    @Test fun sheetNameDuplicateStaysWithin31() { val base = "y".repeat(31); val n = DocConvert.sheetName(base, 1, setOf(base)); assertEquals(31, n.length); assertTrue(n.endsWith(" (2)")) }
    @Test fun plainNumbers() { for (s in listOf("0", "12", "-3", "3.5", "-0.25", "123456789012345")) assertTrue(s, DocConvert.isPlainNumber(s)); for (s in listOf("", "007", "1,5", "1e5", "+1", "0x1", "1.", ".5", "1234567890123456", " 1")) assertFalse(s, DocConvert.isPlainNumber(s)) }
    @Test fun colNames() { assertEquals("A", DocConvert.colName(0)); assertEquals("Z", DocConvert.colName(25)); assertEquals("AA", DocConvert.colName(26)); assertEquals("AZ", DocConvert.colName(51)); assertEquals("BA", DocConvert.colName(52)); assertEquals("ZZ", DocConvert.colName(701)); assertEquals("AAA", DocConvert.colName(702)) }
    @Test fun csvCellQuoting() { assertEquals("a", DocConvert.csvCell("a")); assertEquals("\"a,b\"", DocConvert.csvCell("a,b")); assertEquals("\"a\"\"b\"", DocConvert.csvCell("a\"b")); assertEquals("\"a\nb\"", DocConvert.csvCell("a\r\nb")); assertEquals("\" a\"", DocConvert.csvCell(" a")) }
    @Test fun rtfEscapes() { assertEquals("a\\\\b\\{c\\}", DocConvert.rtf("a\\b{c}")); assertEquals("\\u252?", DocConvert.rtf("ü")); assertEquals("a\\line b", DocConvert.rtf("a\nb")); assertEquals("a\\tab b", DocConvert.rtf("a\tb")); assertEquals("\\u-30050?", DocConvert.rtf("語")) }
    @Test fun mdCellEscapes() { assertEquals("a\\|b c", DocConvert.mdCell("a|b\nc")) }
    @Test fun wrapBasics() {
        val m = { s: String -> s.length.toFloat() }
        assertEquals(listOf("aaa bbb", "ccc"), DocConvert.wrap("aaa bbb ccc", 7f, m)); assertEquals(listOf("abcd", "efgh", "ij"), DocConvert.wrap("abcdefghij", 4f, m))
        assertEquals(listOf("a", "", "b"), DocConvert.wrap("a\n\nb", 10f, m)); assertEquals(listOf(""), DocConvert.wrap("", 10f, m))
    }
    @Test fun wrapNeverExceedsWidth() { val m = { s: String -> s.length.toFloat() }; for (w in 1..12) for (l in DocConvert.wrap("kısa sözcükler ve çok_uzun_bir_sözcük burada", w.toFloat(), m)) assertTrue(l.length <= w) }
    @Test fun wrapKeepsAllText() { val m = { s: String -> s.length.toFloat() }; val t = "bir iki üç dört beş altı"; assertEquals(squash(t), squash(DocConvert.wrap(t, 6f, m).joinToString(""))) }
    @Test fun padRowsEvens() { assertEquals(listOf(listOf("a", ""), listOf("b", "c")), DocConvert.padRows(listOf(listOf("a"), listOf("b", "c")))); assertEquals(60, DocConvert.padRows(listOf(List(80) { "x" }))[0].size) }
    @Test fun showTitleRules() {
        val one = Doc(DocKind.DOCX, listOf(DocPage("T", listOf("x")))); assertFalse(DocConvert.showTitle(one, one.pages[0]))
        assertTrue(DocConvert.showTitle(sample, sample.pages[1])); assertFalse(DocConvert.showTitle(sample, DocPage("", listOf("x"))))
        val tab = Doc(DocKind.XLSX, listOf(DocPage("S", emptyList(), listOf(listOf("a"))))); assertTrue(DocConvert.showTitle(tab, tab.pages[0]))
    }

    // ---- yazıcılar
    @Test fun txtExact() { assertEquals("Giriş\nMerhaba dünya ğüşiöçİ\nİkinci\nsatır\nAd\tPuan\nAli\t12\nZeynep\t3.5\n\nSayfa 2\nSadece yazı", DocWrite.txt(sample)) }
    @Test fun mdTableAndTitles() { val m = DocWrite.md(sample); assertTrue(m.contains("## Giriş")); assertTrue(m.contains("| Ad | Puan |")); assertTrue(m.contains("| --- | --- |")); assertTrue(m.contains("| Ali | 12 |")); assertTrue(m.contains("## Sayfa 2")) }
    @Test fun htmlEscapesAndTables() { val h = DocWrite.html(Doc(DocKind.TEXT, listOf(DocPage("", listOf("a<b>&\"c"), listOf(listOf("x", "y")))))); assertTrue(h.contains("a&lt;b&gt;&amp;&quot;c")); assertTrue(h.contains("<td>x</td><td>y</td>")); assertTrue(h.contains("<meta charset=\"utf-8\">")); assertFalse(h.contains("<b>")) }
    @Test fun csvHasBomAndCrlf() { val b = DocWrite.write(sample, ConvTarget.CSV)!!; assertEquals(0xEF.toByte(), b[0]); assertEquals(0xBB.toByte(), b[1]); assertEquals(0xBF.toByte(), b[2]); assertTrue(String(b, 3, b.size - 3, Charsets.UTF_8).contains("Ad,Puan\r\nAli,12\r\n")) }
    @Test fun rtfStartsAndEnds() { val r = DocWrite.rtf(sample); assertTrue(r.startsWith("{\\rtf1")); assertTrue(r.endsWith("}")); assertTrue(r.all { it.code < 128 }); assertTrue(r.contains("\\trowd")); assertTrue(r.contains("\\page")) }
    @Test fun pdfAndPngNotWrittenHere() { assertEquals(null, DocWrite.write(sample, ConvTarget.PDF)); assertEquals(null, DocWrite.write(sample, ConvTarget.PNG_ZIP)) }
    @Test fun docxPackageParts() { val z = unzip(DocWrite.docx(sample)); assertEquals(listOf("[Content_Types].xml", "_rels/.rels", "word/document.xml"), z.keys.toList()); for ((_, v) in z) wellFormed(v) }
    @Test fun docxTableAndPageBreak() { val x = String(unzip(DocWrite.docx(sample))["word/document.xml"]!!, Charsets.UTF_8); assertTrue(x.contains("<w:tbl>")); assertTrue(x.contains("w:type=\"page\"")); assertTrue(x.contains("xml:space=\"preserve\"")) }
    @Test fun xlsxPackageParts() { val z = unzip(DocWrite.xlsx(sample)); for (n in listOf("[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels", "xl/worksheets/sheet1.xml", "xl/worksheets/sheet2.xml")) assertNotNull(n, z[n]); for ((_, v) in z) wellFormed(v) }
    @Test fun xlsxNumbersAndStrings() { val x = String(unzip(DocWrite.xlsx(sample))["xl/worksheets/sheet1.xml"]!!, Charsets.UTF_8); assertTrue(x.contains("<v>12</v></c>")); assertTrue(x.contains("t=\"inlineStr\"")); assertTrue(x.contains("Zeynep")) }
    @Test fun xlsxEmptyDocStillValid() { val z = unzip(DocWrite.xlsx(Doc(DocKind.TEXT, emptyList()))); assertNotNull(z["xl/worksheets/sheet1.xml"]); for ((_, v) in z) wellFormed(v) }
    @Test fun pptxPackageParts() { val z = unzip(DocWrite.pptx(sample)); for (n in listOf("ppt/presentation.xml", "ppt/slideMasters/slideMaster1.xml", "ppt/slideLayouts/slideLayout1.xml", "ppt/theme/theme1.xml", "ppt/slides/slide1.xml", "ppt/slides/slide2.xml", "ppt/slides/_rels/slide1.xml.rels")) assertNotNull(n, z[n]); for ((_, v) in z) wellFormed(v) }
    @Test fun pptxSplitsLongPages() { val d = Doc(DocKind.TEXT, listOf(DocPage("Uzun", List(DocWrite.SLIDE_LINES * 2 + 1) { "satır $it" }))); val s = DocWrite.slides(d); assertEquals(3, s.size); assertEquals("Uzun", s[0].title); assertEquals("Uzun (2)", s[1].title); assertEquals(1, s[2].lines.size) }
    @Test fun pptxTableRowsBecomeLines() { val s = DocWrite.slides(Doc(DocKind.XLSX, listOf(DocPage("T", emptyList(), listOf(listOf("a", "b")))))); assertEquals(listOf("a  |  b"), s[0].lines) }
    @Test fun pptxEmptyDocStillValid() { val z = unzip(DocWrite.pptx(Doc(DocKind.TEXT, emptyList()))); assertNotNull(z["ppt/slides/slide1.xml"]); for ((_, v) in z) wellFormed(v) }
    @Test fun odfMimetypeFirstAndStored() {
        for (t in listOf(ConvTarget.ODT, ConvTarget.ODS, ConvTarget.ODP)) {
            val b = DocWrite.write(sample, t)!!
            ZipInputStream(ByteArrayInputStream(b)).use { z ->
                val e = z.nextEntry!!; assertEquals("mimetype", e.name); assertEquals(java.util.zip.ZipEntry.STORED, e.method); assertEquals(t.mime, String(z.readBytes(), Charsets.UTF_8))
            }
            val z2 = unzip(b); assertNotNull(z2["content.xml"]); assertNotNull(z2["META-INF/manifest.xml"]); for ((n, v) in z2) if (n != "mimetype") wellFormed(v)
        }
    }
    @Test fun odtSpacesTabsAndBreaks() { val s = DocWrite.odfText("a  b\tc\nd"); assertTrue(s.contains("<text:s")); assertTrue(s.contains("<text:tab/>")); assertTrue(s.contains("<text:line-break/>")) }
    @Test fun odtLeadingSpacesKept() { assertTrue(DocWrite.odfText("   x").startsWith("<text:s text:c=\"3\"/>")) }
    @Test fun odsNumbersAreFloat() { val x = String(unzip(DocWrite.ods(sample))["content.xml"]!!, Charsets.UTF_8); assertTrue(x.contains("office:value-type=\"float\" office:value=\"12\"")); assertTrue(x.contains("table:name=\"Giriş\"")) }

    // ---- gidiş-dönüş
    private fun back(t: ConvTarget): Doc = DocParse.parse("x." + t.ext, DocWrite.write(sample, t)!!)
    private fun assertHasAll(t: ConvTarget, d: Doc) { val a = squash(allText(d)); for (tok in listOf("Merhaba", "ğüşiöçİ", "Sadece", "Zeynep", "3.5", "Puan")) assertTrue("$t: $tok", a.contains(squash(tok))) }
    @Test fun roundTripDocx() { assertHasAll(ConvTarget.DOCX, back(ConvTarget.DOCX)) }
    @Test fun roundTripXlsx() { val d = back(ConvTarget.XLSX); assertHasAll(ConvTarget.XLSX, d); assertEquals(2, d.pages.size); assertEquals("Giriş", d.pages[0].title) }
    @Test fun roundTripPptx() { val d = back(ConvTarget.PPTX); assertHasAll(ConvTarget.PPTX, d); assertEquals(2, d.pages.size) }
    @Test fun roundTripOdt() { assertHasAll(ConvTarget.ODT, back(ConvTarget.ODT)) }
    @Test fun roundTripOds() { val d = back(ConvTarget.ODS); assertHasAll(ConvTarget.ODS, d); assertEquals(2, d.pages.size) }
    @Test fun roundTripOdp() { val d = back(ConvTarget.ODP); assertHasAll(ConvTarget.ODP, d); assertEquals(2, d.pages.size) }
    @Test fun roundTripRtf() { assertHasAll(ConvTarget.RTF, back(ConvTarget.RTF)) }
    @Test fun roundTripTxt() { assertHasAll(ConvTarget.TXT, back(ConvTarget.TXT)) }
    @Test fun roundTripMdAsText() { assertHasAll(ConvTarget.MD, back(ConvTarget.MD)) }
    @Test fun emptyDocWritesEveryTarget() { for (t in ConvTarget.values()) { val b = DocWrite.write(Doc(DocKind.TEXT, emptyList()), t); if (t == ConvTarget.PDF || t == ConvTarget.PNG_ZIP || t == ConvTarget.PNG) assertEquals(null, b) else assertNotNull(t.name, b) } }

    // ---- kaynak ve kaynak dosyaları
    private fun code(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    @Test fun uiHasConvertBarForBothViews() { val s = code("docs/DocActivity.kt"); assertTrue(s.contains("ConvertBar(s.name, DocKind.PDF, null, s.renderer, s.uri)")); assertTrue(s.contains("ConvertBar(s.name, doc.kind, doc, null)")) }
    @Test fun saveUsesCreateDocument() { assertTrue(code("docs/DocActivity.kt").contains("ACTION_CREATE_DOCUMENT")) }
    @Test fun conversionRunsOffMainThread() { val s = code("docs/DocActivity.kt"); assertTrue(s.substringAfter("fun convert(").contains("Dispatchers.IO")) }
    @Test fun tempFilesCleanedAfterSave() { val s = code("docs/DocActivity.kt"); assertTrue(s.contains("f.delete()")); assertTrue(s.contains("dir.listFiles()?.forEach { it.delete() }")) }
    @Test fun pdfWriterUsesPdfDocument() { val s = code("docs/DocPdf.kt"); assertTrue(s.contains("PdfDocument")); assertTrue(s.contains("DocConvert.wrap")) }
    @Test fun noPlatformTypesInWriters() { val s = code("docs/DocWrite.kt"); assertFalse(s.contains("import android.")) }
    @Test fun convStringsEverywhere() {
        val keys = listOf("conv_btn", "conv_pick", "conv_done", "conv_fail", "conv_none", "conv_note", "conv_pdf_note", "conv_busy", "conv_nopick")
        for ((lang, f) in TestFiles.stringFiles()) { val m = TestFiles.parseStrings(f); for (k in keys) assertTrue("$lang: $k", m.containsKey(k)) }
    }
    @Test fun appIsCalledAtlas() { for ((lang, f) in TestFiles.stringFiles()) assertEquals(lang, "Atlas", TestFiles.parseStrings(f)["app_name"]) }
    @Test fun noOldBrandInUserFacingText() { for ((lang, f) in TestFiles.stringFiles()) { val m = TestFiles.parseStrings(f); for (k in listOf("app_name", "perm_batt_hint", "guide_title", "rl_help", "sum_title")) assertFalse("$lang $k", (m[k] ?: "").contains("Odak")) } }
    @Test fun gradleRootNameAtlas() { val s = listOf(File("settings.gradle.kts"), File("../settings.gradle.kts")).firstOrNull { it.exists() }; if (s != null) assertTrue(s.readText().contains("rootProject.name = \"Atlas\"")) }

    // ---- v0.56b: PDF → her biçim, büyük dosya
    @Test fun pdfTextExtractionWired() { val s = code("docs/DocPdf.kt"); assertTrue(s.contains("PDFTextStripper")); assertTrue(s.contains("setupTempFileOnly")); assertTrue(s.contains("fun extractText")) }
    @Test fun pdfBoxDependencyDeclared() { val f = listOf(File("build.gradle.kts"), File("app/build.gradle.kts")).first { it.exists() }; assertTrue(f.readText().contains("com.tom-roush:pdfbox-android")) }
    @Test fun convertUsesExtractedTextForPdf() { val s = code("docs/DocActivity.kt"); assertTrue(s.contains("DocPdf.extractText(ctx, uri)")); assertTrue(s.contains("R.string.conv_scanned")) }
    @Test fun limitsRaised() { assertEquals(256 * 1024 * 1024, DocParse.MAX_BYTES) }
    @Test fun parseHonoursCustomCap() { assertEquals(DocKind.UNKNOWN, DocParse.parse("a.txt", ByteArray(11), 10).kind); assertEquals(DocKind.TEXT, DocParse.parse("a.txt", ByteArray(10) { 65 }, 10).kind) }
    @Test fun largeHeapOn() { assertTrue(File(TestFiles.main, "AndroidManifest.xml").readText().contains("android:largeHeap=\"true\"")) }
    @Test fun pdfViewHasNoSizeCap() { val s = code("docs/DocActivity.kt"); assertTrue(s.substringAfter("if (kind == DocKind.PDF) {").substringBefore("} else {").let { !it.contains("readCapped") }) }
    @Test fun pdfStringsEverywhere() { for ((lang, f) in TestFiles.stringFiles()) { val m = TestFiles.parseStrings(f); assertTrue(lang, m.containsKey("conv_scanned")); assertTrue(lang, (m["doc_toobig"] ?: "").contains("256")) } }
}
