package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class VectorFidelityTest {
    private fun doc(cx: Int, cy: Int, shape: String): ByteArray = ("""<?xml version="1.0" encoding="UTF-8"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"><w:body>
<w:p><w:r><w:t>Metin</w:t></w:r><w:r><w:drawing><wp:anchor><wp:positionH relativeFrom="page"><wp:posOffset>914400</wp:posOffset></wp:positionH><wp:positionV relativeFrom="page"><wp:posOffset>1828800</wp:posOffset></wp:positionV><wp:extent cx="$cx" cy="$cy"/><wp:wrapNone/><a:graphic><a:graphicData>$shape</a:graphicData></a:graphic></wp:anchor></w:drawing></w:r></w:p></w:body></w:document>""").toByteArray()

    private fun wsp(prst: String, offX: Long, offY: Long, cx: Long, cy: Long, extra: String) =
        """<wps:wsp><wps:spPr><a:xfrm><a:off x="$offX" y="$offY"/><a:ext cx="$cx" cy="$cy"/></a:xfrm><a:prstGeom prst="$prst"><a:avLst/></a:prstGeom>$extra</wps:spPr><wps:bodyPr/></wps:wsp>"""
    private val red = """<a:solidFill><a:srgbClr val="FF0000"/></a:solidFill>"""
    private fun ln(c: String, w: Int) = """<a:ln w="$w"><a:solidFill><a:srgbClr val="$c"/></a:solidFill></a:ln>"""
    private fun shapes(rp: RichPage) = rp.blocks.filterIsInstance<RTable>().filter { it.at != null }

    @Test fun horizontalLineBecomesThinColoredBar() {
        val rp = RichDocx.parse(doc(1828800, 0, wsp("line", 0, 0, 1828800, 0, ln("00AA00", 19050))), null, null)
        val t = shapes(rp).single()
        assertEquals("00AA00", t.rows[0][0].fill)
        assertEquals(1440, t.at!![0]); assertEquals(2880, t.at!![1]); assertEquals(2880, t.at!![2]); assertEquals(30, t.at!![3])
    }
    @Test fun verticalConnectorBecomesThinBar() {
        val rp = RichDocx.parse(doc(0, 914400, wsp("straightConnector1", 0, 0, 0, 914400, ln("112233", 12700))), null, null)
        val t = shapes(rp).single()
        assertEquals("112233", t.rows[0][0].fill); assertEquals(20, t.at!![2]); assertEquals(1440, t.at!![3])
    }
    @Test fun diagonalLineIsSkippedNotMisdrawn() {
        val rp = RichDocx.parse(doc(1828800, 914400, wsp("line", 0, 0, 1828800, 914400, ln("000000", 12700))), null, null)
        assertTrue(shapes(rp).isEmpty())
    }
    @Test fun groupChildrenKeepScaledPosition() {
        val grp = """<wpg:wgp><wpg:cNvGrpSpPr/><wpg:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="1828800" cy="914400"/><a:chOff x="0" y="0"/><a:chExt cx="3657600" cy="1828800"/></a:xfrm></wpg:grpSpPr>""" +
            wsp("rect", 1828800, 914400, 1828800, 914400, red) + wsp("ellipse", 0, 0, 914400, 914400, red) + "</wpg:wgp>"
        val rp = RichDocx.parse(doc(1828800, 914400, grp), null, null)
        val l = shapes(rp)
        assertEquals(2, l.size)
        val r = l.first { it.prst == "rect" }.at!!
        assertEquals(2880, r[0]); assertEquals(3600, r[1]); assertEquals(1440, r[2]); assertEquals(720, r[3])
        val e = l.first { it.prst == "ellipse" }.at!!
        assertEquals(1440, e[0]); assertEquals(2880, e[1]); assertEquals(720, e[2]); assertEquals(720, e[3])
        assertEquals("FF0000", l[0].rows[0][0].fill)
    }

    // ---------- şekil geometrisi ----------
    @Test fun polygonsAreInsideUnitSquare() {
        for (n in listOf("triangle", "rtTriangle", "diamond", "parallelogram", "trapezoid", "pentagon", "hexagon", "octagon", "rightArrow", "leftArrow", "upArrow", "downArrow", "chevron", "homePlate", "plus", "star5", "mathPlus", "flowChartDecision")) {
            val p = ShapeGeom.poly(n)!!
            assertTrue(n, p.size >= 6 && p.size % 2 == 0)
            assertTrue(n, p.all { it in 0f..1f })
        }
    }
    @Test fun plainShapesHaveNoPolygon() {
        assertNull(ShapeGeom.poly("rect")); assertNull(ShapeGeom.poly("ellipse")); assertNull(ShapeGeom.poly(""))
        assertTrue(ShapeGeom.isEllipse("ellipse")); assertFalse(ShapeGeom.isEllipse("rect"))
        assertEquals(0.1667f, ShapeGeom.corner("roundRect"), 0.0001f); assertEquals(0f, ShapeGeom.corner("rect"), 0f)
    }
    @Test fun cssClipPath() {
        assertEquals("polygon(50.0% 0.0%,100.0% 100.0%,0.0% 100.0%)", ShapeGeom.clipPath("triangle"))
        assertNull(ShapeGeom.clipPath("rect"))
    }
    @Test fun htmlUsesGeometry() {
        val b = RBox(0, 0, 2000, 1000, emptyList(), "FF0000", null, "", false, 0, prst = "triangle")
        val h = RichHtml.page(RichPage(listOf(b), PageSetup(11906, 6000)))
        assertTrue(h.contains("clip-path:polygon("))
        val r = RichHtml.page(RichPage(listOf(RBox(0, 0, 2000, 1000, emptyList(), "00FF00", null, "", false, 0, prst = "roundRect")), PageSetup(11906, 6000)))
        assertTrue(r.contains("border-radius:16.7%"))
    }
    @Test fun shapeTableBecomesGeometryBox() {
        val t = RTable(listOf(listOf(RCell(emptyList(), 1, 0, "123456", Bd(8, "654321"), Bd(8, "654321"), Bd(8, "654321"), Bd(8, "654321")))), listOf(2880))
        t.prst = "hexagon"
        val b = t.asBox(10, 20, 2880, 1440)!!
        assertEquals("hexagon", b.prst); assertEquals("123456", b.fill); assertEquals("654321", b.border!!.color)
        assertNull(RTable(listOf(listOf(RCell(emptyList()))), listOf(100)).asBox(0, 0, 1, 1))
    }
    @Test fun pptxShapeNameSurvivesToBox() {
        assertTrue(File(TestFiles.code, "com/odak/app/docs/RichPptx.kt").readText().contains("prst = s.prst"))
    }

    // ---------- ODP dönme / tür ----------
    @Test fun odfPositionNoRotation() {
        assertEquals("svg:x=\"1.000cm\" svg:y=\"2.000cm\"", DocWrite.odfPos(1.0, 2.0, 4.0, 2.0, 0.0))
        assertEquals("svg:x=\"1.000cm\" svg:y=\"2.000cm\"", DocWrite.odfPos(1.0, 2.0, 4.0, 2.0, 360.0))
    }
    @Test fun odfPositionRotated90() {
        // 4x2 şekil (1,2), 90° saat yönü: merkez (3,3); sol-üst köşe (4,1) olur
        val s = DocWrite.odfPos(1.0, 2.0, 4.0, 2.0, 90.0)
        assertTrue(s, s.startsWith("draw:transform=\"rotate (-1.57080) translate (4.000cm 1.000cm)\""))
    }
    @Test fun odfShapeTypes() {
        assertEquals("round-rectangle", DocWrite.odfShapeType("roundRect")); assertEquals("right-arrow", DocWrite.odfShapeType("rightArrow"))
        assertEquals("rectangle", DocWrite.odfShapeType("unknownThing")); assertEquals("ellipse", DocWrite.odfShapeType("ellipse"))
    }
    @Test fun pdfDrawsGeometry() {
        val s = File(TestFiles.code, "com/odak/app/docs/DocPdfRich.kt").readText()
        assertTrue(s.contains("private fun drawShape") && s.contains("ShapeGeom.poly") && s.contains("drawRoundRect"))
        assertFalse(s.contains("if (b.round) c.drawOval(rect"))
    }
}
