package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class BuildDepsTest {
    private val root: File get() = File(TestFiles.main, "../../..").canonicalFile
    private val gradle get() = File(root, "app/build.gradle.kts").readText()

    @Test fun mlLibrariesDeclared() {
        assertTrue(gradle.contains("com.google.ai.edge.litertlm:litertlm-android"))
        assertTrue(gradle.contains("com.github.haifengl:smile-core")); assertTrue(gradle.contains("org.apache.commons:commons-math3")); assertTrue(gradle.contains("com.microsoft.onnxruntime:onnxruntime-android")); assertTrue(gradle.contains("org.tensorflow:tensorflow-lite") && gradle.contains("org.pytorch:pytorch_android_lite") && gradle.contains("org.pytorch:executorch-android"))
        assertTrue(gradle.contains("exclude(group = \"org.bytedeco\")"))
    }
    @Test fun packagingAndAbiKeepApkInstallable() {
        assertTrue(gradle.contains("abiFilters += listOf(\"arm64-v8a\")"))
        assertTrue(gradle.contains("packaging") && gradle.contains("META-INF/DEPENDENCIES") && gradle.contains("pickFirsts"))
    }
    @Test fun workflowKeepsLogsAndFallback() {
        val wf = File(root, ".github/workflows/build-apk.yml").readText()
        assertTrue(wf.contains("build-logs") && wf.contains("PIPESTATUS") && wf.contains("if-no-files-found: error"))
        assertTrue(wf.contains("bir önceki zip deneniyor"))
    }
    @Test fun gradleMemoryRaised() {
        assertTrue(File(root, "gradle.properties").readText().contains("-Xmx4096m"))
    }
}
