package com.odak.app.docs

import java.io.ByteArrayInputStream
import java.io.InputStream

/**
 * Tek başına resim/vektör dosyaları (PNG, JPG, GIF, BMP, WebP, SVG, TIFF, EMF, WMF…): tek sayfalık zengin belge olarak açılır,
 * böylece PDF, DOCX, ODT, RTF, HTML, EPUB, PPTX, ODP'ye dönüşür. PNG/JPEG/GIF olduğu gibi gömülür; diğerleri Android tarafında
 * PNG'ye çevrilip buraya verilir.
 */
object ImageDoc {
    val EXTS = setOf("png", "jpg", "jpeg", "jfif", "gif", "bmp", "webp", "heic", "heif", "avif", "tif", "tiff", "svg", "svgz", "emf", "wmf")

    /** Doğrudan gömülebilir mi (PNG/JPEG/GIF imzası)? */
    fun isNative(data: ByteArray): Boolean = RImg.mimeOf("", data) != null

    fun doc(name: String, data: ByteArray): Doc? {
        val img = HtmlRich.image(data, name) ?: return null
        val rp = RichPage(listOf(RPara(listOf(RRun("", img = img)), align = "center")), PageSetup(), 22, null, 0, 0)
        return Doc(DocKind.IMAGE, listOf(DocPage("", emptyList(), null, null, rp)))
    }

    /** Belgedeki ilk resim (PNG/JPEG/GIF). */
    fun first(doc: Doc): RImg? = images(doc).firstOrNull()

    /** Sayfalardaki tüm satır içi resimler, görünme sırasıyla (kutular düzleştirilir). */
    fun images(doc: Doc): List<RImg> = doc.pages.flatMap { pageImages(it) }

    fun pageImages(p: DocPage): List<RImg> {
        val rp = p.rich?.let { Rich.flat(it) } ?: return emptyList()
        return rp.blocks.flatMap { b ->
            when (b) {
                is RPara -> b.runs.mapNotNull { it.img }
                is RTable -> b.rows.flatMap { r -> r.flatMap { c -> c.paras.flatMap { q -> q.runs.mapNotNull { it.img } } } }
                else -> emptyList()
            }
        }
    }

    /** PNG hedefi: ilk resim zaten PNG ise baytlar; değilse null (Android tarafı çevirir). */
    fun png(doc: Doc): ByteArray? = first(doc)?.takeIf { it.mime == "image/png" }?.data
}

/** Tek girdili bellek kaynağı (zip değil): [open] hangi ad istenirse o resmi verir. */
class SingleMedia(private val bytes: ByteArray) : MediaSource {
    override fun open(entry: String): InputStream? = ByteArrayInputStream(bytes)
    override fun size(entry: String): Long = bytes.size.toLong()
    override fun close() { }
}
