package com.odak.app.docs

/**
 * (X)HTML → biçimli blok listesi (başlık, paragraf, liste, tablo, resim, kalın/italik/renk/köprü). Saf Kotlin.
 * E-kitap (EPUB/MOBI/FB2) bölümleri için; kapsamlı bir tarayıcı değildir: CSS dosyaları okunmaz, yalnız satır içi style özniteliği.
 */
object HtmlRich {
    private const val MAX_BLOCKS = 20000
    private val TOKEN = Regex("<!--.*?-->|<(/?)([a-zA-Z][a-zA-Z0-9:_-]*)((?:[^>\"']|\"[^\"]*\"|'[^']*')*)>|([^<]+)", RegexOption.DOT_MATCHES_ALL)
    private val ATTR = Regex("([a-zA-Z_:][-a-zA-Z0-9_:.]*)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s\"'>]+))")
    private val BLOCK = setOf("p", "div", "section", "article", "header", "footer", "aside", "nav", "figure", "figcaption", "main", "address", "dl", "dt", "dd", "center", "body", "html")
    private val VOID = setOf("br", "hr", "img", "meta", "link", "input", "image", "col", "area", "base", "wbr", "source")
    private val SKIP = setOf("head", "script", "style", "title", "svg-never")

    fun attrs(s: String): Map<String, String> {
        val m = HashMap<String, String>()
        for (x in ATTR.findAll(s)) m[x.groupValues[1].lowercase()] = DocParse.htmlDecode(x.groupValues[2].ifEmpty { x.groupValues[3].ifEmpty { x.groupValues[4] } })
        return m
    }

    /** Ham resim baytlarından sayfaya sığan bir [RImg] (en çok 6,5 inç genişlik); biçim tanınmazsa null. */
    fun image(raw: ByteArray, name: String = ""): RImg? {
        val (data, mime) = RImg.make(name, raw) ?: return null
        val px = RImg.pixelSize(data)
        var w = (px?.first ?: 320) * 15; var h = (px?.second ?: 240) * 15
        if (w <= 0 || h <= 0) { w = 4800; h = 3600 }
        val max = 9000
        if (w > max) { h = (h.toLong() * max / w).toInt(); w = max }
        if (h > 12000) { w = (w.toLong() * 12000 / h).toInt(); h = 12000 }
        return RImg(data, mime, w.coerceAtLeast(150), h.coerceAtLeast(150))
    }

    /** data:image/...;base64,... adresi → bayt. */
    fun dataUri(src: String): ByteArray? {
        if (!src.startsWith("data:", true)) return null
        val c = src.indexOf(','); if (c < 0 || !src.substring(0, c).contains("base64", true)) return null
        return try { java.util.Base64.getMimeDecoder().decode(src.substring(c + 1).trim()) } catch (e: Exception) { null }
    }

    /** Basit CSS: yalnız etiket, .sınıf, #kimlik ve bunların birleşimi (virgüllü liste dahil). Bileşik/sözde seçiciler ve @-kuralları atlanır. */
    class Anc(val tag: String, val classes: List<String>, val id: String?, val attrs: Map<String, String> = emptyMap(), val prev: List<Anc> = emptyList(), val pos: Int = 1,
              val fromEnd: Int = 0, val typePos: Int = 1, val typeFromEnd: Int = 0, val empty: Boolean = false) {
        var after: String? = null
        val last get() = fromEnd == 1
    }

    class Css(src: String) {
        class Ps(val kind: String, val a: Int = 0, val b: Int = 0)
        class Simple(val tag: String?, val classes: List<String>, val id: String?, val attrs: List<Triple<String, String, String>> = emptyList(),
                     val ps: List<Ps> = emptyList(), val nots: List<Simple> = emptyList(), val anyOf: List<List<Simple>> = emptyList()) {
            fun matches(e: Anc): Boolean {
                if (tag != null && tag != e.tag) return false
                if (!classes.all { it in e.classes }) return false
                if (id != null && id != e.id) return false
                for (q in ps) when (q.kind) {
                    "child" -> if (!nthOk(q.a, q.b, e.pos)) return false
                    "last-child" -> if (e.fromEnd <= 0 || !nthOk(q.a, q.b, e.fromEnd)) return false
                    "type" -> if (!nthOk(q.a, q.b, e.typePos)) return false
                    "last-type" -> if (e.typeFromEnd <= 0 || !nthOk(q.a, q.b, e.typeFromEnd)) return false
                    "empty" -> if (!e.empty) return false
                    "link" -> if (e.tag != "a" || !e.attrs.containsKey("href")) return false
                    "never" -> return false
                }
                for ((n, op, v) in attrs) {
                    val x = e.attrs[n] ?: return false
                    val ok = when (op) { "" -> true; "=" -> x == v; "~=" -> x.split(Regex("\\s+")).contains(v); "^=" -> x.startsWith(v); "$=" -> x.endsWith(v); "*=" -> x.contains(v); "|=" -> x == v || x.startsWith("$v-"); else -> false }
                    if (!ok) return false
                }
                if (nots.any { it.matches(e) }) return false
                for (g in anyOf) if (g.none { it.matches(e) }) return false
                return true
            }
            val spec: Int get() = (if (tag != null) 1 else 0) + (classes.size + attrs.size + ps.size) * 10 + (if (id != null) 100 else 0) + (nots.maxOfOrNull { it.spec } ?: 0) + anyOf.sumOf { g -> g.maxOfOrNull { it.spec } ?: 0 }
        }
        /** parts[0] en dıştaki; combs[i], parts[i] ile parts[i+1] arasındaki ilişki (' ' torun, '>' çocuk, '+' hemen sonraki kardeş, '~' sonraki kardeş). */
        class Rule(val parts: List<Simple>, val combs: List<Char>, val decl: String, val order: Int, val pseudo: String = "") {
            val spec = parts.sumOf { it.spec }
            val last get() = parts.last()
            val tag get() = last.tag
            val classes get() = last.classes
            val id get() = last.id
        }
        val rules = ArrayList<Rule>()
        companion object {
            fun nthOk(a: Int, b: Int, pos: Int): Boolean = if (a == 0) pos == b else { val d = pos - b; d % a == 0 && d / a >= 0 }
            fun parseNth(t0: String): Pair<Int, Int>? {
                val t = t0.trim().lowercase().replace(" ", "")
                if (t == "odd") return 2 to 1; if (t == "even") return 2 to 0
                t.toIntOrNull()?.let { return 0 to it }
                val m = Regex("^([+-]?\\d*)n([+-]\\d+)?$").find(t) ?: return null
                val a = when (m.groupValues[1]) { "", "+" -> 1; "-" -> -1; else -> m.groupValues[1].toInt() }
                return a to (m.groupValues[2].toIntOrNull() ?: 0)
            }
        }
        /** Kural, ardıl bilgisi (sondan sıra, boş eleman) gerektiriyor mu → ön tarama yapılır. */
        var usesLast = false
        private val PIECE = Regex("\\.[-_a-zA-Z0-9]+|#[-_a-zA-Z0-9]+|\\[[^\\]\\s]+\\]|:(?:first|last|only)-(?:child|of-type)|:empty|:link|:nth-(?:last-)?(?:child|of-type)\\([^)\\s]*\\)|:(?:hover|focus|focus-within|focus-visible|visited|active|target|checked|disabled)|:root")
        private val ATTRSEL = Regex("^\\[([-_a-zA-Z0-9:]+)(?:([~^$*|]?=)[\"']?([^\"'\\]]*)[\"']?)?\\]$")
        private fun splitTop(t: String, sep: Char): List<String> {
            val out = ArrayList<String>(); var depth = 0; var br = 0; var st = 0
            for ((i, c) in t.withIndex()) { when (c) { '(' -> depth++; ')' -> depth--; '[' -> br++; ']' -> br--; sep -> if (depth == 0 && br == 0) { out.add(t.substring(st, i)); st = i + 1 } } }
            out.add(t.substring(st)); return out
        }
        private fun simple(t: String): Simple? {
            val head = Regex("^([a-zA-Z][a-zA-Z0-9]*|\\*)?").find(t)!!.value
            var rest = t.substring(head.length)
            val cls = ArrayList<String>(); var id: String? = null; val attrs = ArrayList<Triple<String, String, String>>(); val ps = ArrayList<Ps>(); val nots = ArrayList<Simple>(); val anyOf = ArrayList<List<Simple>>()
            var tagOverride: String? = null
            while (rest.isNotEmpty()) {
                val fn = Regex("^:(not|is|where|matches)\\(").find(rest)
                if (fn != null) {
                    var depth = 0; var end = -1
                    for (ix in fn.value.length - 1 until rest.length) { if (rest[ix] == '(') depth++ else if (rest[ix] == ')') { depth--; if (depth == 0) { end = ix; break } } }
                    if (end < 0) return null
                    val inner = splitTop(rest.substring(fn.value.length, end), ',').map { simple(it.trim()) ?: return null }
                    if (inner.isEmpty() || inner.size > 8) return null
                    if (fn.groupValues[1] == "not") nots.addAll(inner) else anyOf.add(inner)
                    rest = rest.substring(end + 1); continue
                }
                val m = PIECE.find(rest)?.takeIf { it.range.first == 0 } ?: return null
                val v = m.value
                when {
                    v.startsWith(".") -> cls.add(v.substring(1))
                    v.startsWith("#") -> id = v.substring(1)
                    v.startsWith("[") -> { val am = ATTRSEL.find(v) ?: return null; attrs.add(Triple(am.groupValues[1].lowercase(), am.groupValues[2], am.groupValues[3])) }
                    v == ":root" -> tagOverride = "html"
                    v.startsWith(":") && v.length > 2 && v.substring(1) in setOf("hover", "focus", "focus-within", "focus-visible", "visited", "active", "target", "checked", "disabled") -> ps.add(Ps("never"))
                    v == ":first-child" -> ps.add(Ps("child", 0, 1))
                    v == ":last-child" -> { ps.add(Ps("last-child", 0, 1)); usesLast = true }
                    v == ":only-child" -> { ps.add(Ps("child", 0, 1)); ps.add(Ps("last-child", 0, 1)); usesLast = true }
                    v == ":first-of-type" -> ps.add(Ps("type", 0, 1))
                    v == ":last-of-type" -> { ps.add(Ps("last-type", 0, 1)); usesLast = true }
                    v == ":only-of-type" -> { ps.add(Ps("type", 0, 1)); ps.add(Ps("last-type", 0, 1)); usesLast = true }
                    v == ":empty" -> { ps.add(Ps("empty")); usesLast = true }
                    v == ":link" -> ps.add(Ps("link"))
                    else -> {
                        val nt = parseNth(v.substringAfter('(').removeSuffix(")")) ?: return null
                        val kind = when { v.startsWith(":nth-last-child") -> "last-child"; v.startsWith(":nth-last-of-type") -> "last-type"; v.startsWith(":nth-of-type") -> "type"; else -> "child" }
                        ps.add(Ps(kind, nt.first, nt.second)); if (kind.startsWith("last")) usesLast = true
                    }
                }
                rest = rest.substring(v.length)
            }
            val tag = tagOverride ?: head.lowercase().takeIf { it.isNotEmpty() && it != "*" }
            if (tag == null && head != "*" && cls.isEmpty() && id == null && attrs.isEmpty() && ps.isEmpty() && nots.isEmpty() && anyOf.isEmpty()) return null
            return Simple(tag, cls, id, attrs, ps, nots, anyOf)
        }
        init {
            var t = src.replace(Regex("(?s)/\\*.*?\\*/"), " ").replace(Regex("@import[^;]*;"), " ")
            t = t.replace(Regex("(?s)@[a-zA-Z-]+[^{;]*\\{(?:[^{}]*\\{[^{}]*\\})*[^{}]*\\}"), " ")
            var order = 0
            for (m in Regex("([^{}]+)\\{([^{}]*)\\}").findAll(t)) {
                if (rules.size > 4000) break
                for (selRaw in splitTop(m.groupValues[1], ',')) {
                    var sel = selRaw.trim()
                    var pseudo = ""
                    Regex("::?(before|after)$").find(sel)?.let { pseudo = it.groupValues[1]; sel = sel.substring(0, it.range.first) }
                    if (sel.isEmpty() && pseudo.isNotEmpty()) sel = "*"
                    if (sel.isEmpty()) continue
                    val partsS = ArrayList<String>(); val combs = ArrayList<Char>(); var last = 0
                    for (x in Regex("\\s*[>+~]\\s*|\\s+").findAll(sel)) {
                        val pre = sel.substring(0, x.range.first)
                        if (pre.count { it == '[' } != pre.count { it == ']' } || pre.count { it == '(' } != pre.count { it == ')' }) continue
                        partsS.add(sel.substring(last, x.range.first)); combs.add(x.value.trim().firstOrNull() ?: ' '); last = x.range.last + 1
                    }
                    partsS.add(sel.substring(last))
                    if (partsS.size > 6) continue
                    val sp = partsS.map { simple(it) }
                    if (sp.any { it == null }) continue
                    rules.add(Rule(sp.map { it!! }, combs, m.groupValues[2].trim(), order++, pseudo))
                }
            }
        }
        private fun m(r: Rule, idx: Int, el: Anc, ancs: List<Anc>): Boolean {
            if (!r.parts[idx].matches(el)) return false
            if (idx == 0) return true
            return when (r.combs[idx - 1]) {
                '>' -> ancs.lastOrNull()?.let { m(r, idx - 1, it, ancs.subList(0, ancs.size - 1)) } ?: false
                '+' -> el.prev.lastOrNull()?.let { m(r, idx - 1, it, ancs) } ?: false
                '~' -> el.prev.any { m(r, idx - 1, it, ancs) }
                else -> (ancs.size - 1 downTo 0).any { k -> m(r, idx - 1, ancs[k], ancs.subList(0, k)) }
            }
        }
        fun styleFor(el: Anc, ancs: List<Anc>): String {
            if (rules.isEmpty()) return ""
            return rules.filter { r -> r.pseudo.isEmpty() && m(r, r.parts.size - 1, el, ancs) }.sortedWith(compareBy({ it.spec }, { it.order })).joinToString(";") { it.decl }
        }
        val hasPseudo get() = rules.any { it.pseudo.isNotEmpty() }
        /** ::before / ::after içeriği ("content" bildirimi); yoksa null. */
        fun pseudoContent(el: Anc, ancs: List<Anc>, which: String): String? {
            var out: String? = null
            for (r in rules.filter { it.pseudo == which && m(it, it.parts.size - 1, el, ancs) }.sortedWith(compareBy({ it.spec }, { it.order }))) {
                for (d in r.decl.split(';')) if (d.substringBefore(':', "").trim().lowercase() == "content") out = contentValue(d.substringAfter(':', "").trim(), el)
            }
            return out?.takeIf { it.isNotEmpty() }
        }
        private fun contentValue(v: String, el: Anc): String? {
            if (v == "none" || v == "normal") return null
            val sb = StringBuilder()
            for (m in Regex("\"((?:[^\"\\\\]|\\\\.)*)\"|'((?:[^'\\\\]|\\\\.)*)'|attr\\(\\s*([-\\w:]+)\\s*\\)").findAll(v)) {
                val str = m.groupValues[1].ifEmpty { m.groupValues[2] }
                if (m.groupValues[3].isNotEmpty()) sb.append(el.attrs[m.groupValues[3].lowercase()] ?: "")
                else sb.append(Regex("\\\\([0-9a-fA-F]{1,6})\\s?|\\\\(.)").replace(str) { e -> e.groupValues[1].takeIf { it.isNotEmpty() }?.let { h -> String(Character.toChars(h.toInt(16).coerceIn(1, 0x10FFFF))) } ?: e.groupValues[2] })
            }
            return sb.toString()
        }
        fun styleFor(tag: String, classAttr: String?, id: String?, anc: List<Anc> = emptyList()): String =
            styleFor(Anc(tag, classAttr?.split(Regex("\\s+"))?.filter { it.isNotEmpty() } ?: emptyList(), id), anc)
    }

    private fun cssLen(v: String): Int? {
        val n = Regex("^(-?[0-9.]+)(pt|px|em|rem|cm|mm|in)?$").find(v.trim()) ?: return null
        val x = n.groupValues[1].toDoubleOrNull() ?: return null
        return when (n.groupValues[2]) { "pt" -> x * 20; "px" -> x * 15; "em", "rem" -> x * 220; "cm" -> x * 567; "mm" -> x * 56.7; "in" -> x * 1440; "" -> if (x == 0.0) 0.0 else null; else -> null }?.toInt()
    }

    private fun decl(style: String, key: String): String? {
        var out: String? = null
        for (d in style.split(';')) if (d.substringBefore(':', "").trim().lowercase() == key) out = d.substringAfter(':', "").trim().lowercase().removeSuffix("!important").trim()
        return out
    }

    private class St(
        var b: Boolean = false, var i: Boolean = false, var u: Boolean = false, var s: Boolean = false,
        var color: String? = null, var font: String? = null, var sz: Int = 0, var sup: Int = 0, var href: String? = null, var hl: String? = null
    ) { fun copy() = St(b, i, u, s, color, font, sz, sup, href, hl) }

    private class ListCtx(val ordered: Boolean, var n: Int = 0)

    private fun styleOf(a: Map<String, String>, st: St) {
        val css = a["style"] ?: return
        for (d in css.split(';')) {
            val k = d.substringBefore(':', "").trim().lowercase(); val v = d.substringAfter(':', "").trim().lowercase()
            when (k) {
                "font-weight" -> st.b = v == "bold" || v == "bolder" || (v.toIntOrNull() ?: 0) >= 600
                "font-style" -> st.i = v == "italic" || v == "oblique"
                "text-decoration", "text-decoration-line" -> { if (v.contains("underline")) st.u = true; if (v.contains("line-through")) st.s = true }
                "color" -> Rich.hex(v)?.let { st.color = it } ?: cssName(v)?.let { st.color = it }
                "background-color" -> Rich.hex(v)?.let { st.hl = it }
                "font-family" -> st.font = v.substringBefore(',').trim().trim('"', '\'').ifEmpty { null }
                "font-size" -> cssSize(v)?.let { st.sz = it }
            }
        }
    }

    private fun cssName(v: String) = mapOf("red" to "FF0000", "blue" to "0000FF", "green" to "008000", "black" to "000000", "gray" to "808080", "grey" to "808080", "white" to "FFFFFF", "orange" to "FFA500", "purple" to "800080")[v]

    private fun cssSize(v: String): Int? {
        val n = Regex("^([0-9.]+)(pt|px|em|rem|%)?$").find(v) ?: return null
        val x = n.groupValues[1].toDoubleOrNull() ?: return null
        return when (n.groupValues[2]) { "pt" -> (x * 2).toInt(); "px" -> (x * 1.5).toInt(); "em", "rem" -> (x * 22).toInt(); "%" -> (x * 0.22).toInt(); else -> null }?.takeIf { it in 8..144 }
    }

    fun parse(html: String, resolve: (String) -> RImg? = { null }, base: RRun = RRun(""), css: String = ""): List<RBlock> {
        val sheet = if (css.isNotBlank()) Css(css) else null
        val endIdx = HashMap<Int, Int>(); val typeEnd = HashMap<Int, Int>(); val emptySet = HashSet<Int>()
        if (sheet != null && sheet.usesLast) {
            class N(val tag: String, val off: Int) { val kids = ArrayList<Pair<Int, String>>(); var content = false }
            val root = N("", -1); val ns = ArrayList<N>(); ns.add(root)
            fun finish(n: N) {
                val k = n.kids.size
                val cnt = HashMap<String, Int>()
                for (i in k - 1 downTo 0) { endIdx[n.kids[i].first] = k - i; val c = (cnt[n.kids[i].second] ?: 0) + 1; cnt[n.kids[i].second] = c; typeEnd[n.kids[i].first] = c }
            }
            for (m in TOKEN.findAll(html)) {
                if (m.value.startsWith("<!--")) continue
                if (m.groups[2] == null) { if (m.groupValues[4].isNotBlank()) ns.last().content = true; continue }
                val closing = m.groupValues[1] == "/"; val tg = m.groupValues[2].lowercase().substringAfter(':'); val self = m.groupValues[3].trimEnd().endsWith("/")
                if (!closing) {
                    ns.last().kids.add(m.range.first to tg); ns.last().content = true
                    if (!self && tg !in VOID) ns.add(N(tg, m.range.first))
                } else if (tg !in VOID) {
                    val k = ns.indexOfLast { it.tag == tg }
                    if (k > 0) while (ns.size > k) { val n = ns.removeAt(ns.size - 1); finish(n); if (!n.content && n.kids.isEmpty()) emptySet.add(n.off) }
                }
            }
            while (ns.isNotEmpty()) { val n = ns.removeAt(ns.size - 1); finish(n); if (n.off >= 0 && !n.content && n.kids.isEmpty()) emptySet.add(n.off) }
        }
        var pendingBefore: String? = null
        var hideTag = ""; var hideDepth = 0
        val anc = ArrayList<Anc>(); val sibs = ArrayList<ArrayList<Anc>>().also { it.add(ArrayList()) }; val tagCnt = ArrayList<HashMap<String, Int>>().also { it.add(HashMap()) }
        var pFirstCss: Int? = null; var pBeforeCss: Int? = null; var pAfterCss: Int? = null
        val root = ArrayList<RBlock>()
        val sinks = ArrayList<ArrayList<RBlock>>().also { it.add(root) }
        val stack = ArrayList<Pair<String, St>>()
        var cur = St(base.b, base.i, base.u, base.s, base.color, base.font, base.sz)
        val runs = ArrayList<RRun>()
        var pHead = 0; var pAlign = ""; var pLeft = 0; var pMarker = ""; var pFill: String? = null
        var pre = 0; var skip = 0; var quote = 0
        val lists = ArrayList<ListCtx>()
        var pendingSpace = false
        var total = 0
        // tablo durumu
        class Tbl { val rows = ArrayList<List<RCell>>(); var row = ArrayList<RCell>(); var span = 1; var header = false; var vspan = 0 }
        val tbls = ArrayList<Tbl>()

        fun trimRuns(): List<RRun> {
            val l = ArrayList(runs)
            while (l.isNotEmpty() && l.last().img == null && l.last().text.isBlank()) l.removeAt(l.size - 1)
            if (l.isNotEmpty() && l.last().img == null) { val r = l.last(); l[l.size - 1] = RRun(r.text.trimEnd(), r.b, r.i, r.u, r.s, r.color, r.hl, r.sz, r.font, r.sup, r.href) }
            return l
        }
        fun flush(force: Boolean = false) {
            val l = trimRuns()
            if (l.isNotEmpty() || force || pMarker.isNotEmpty()) {
                if (total < MAX_BLOCKS && (l.isNotEmpty() || force)) {
                    val sz = when (pHead) { 1 -> 36; 2 -> 30; 3 -> 26; 4 -> 24; else -> 0 }
                    val rr = if (pHead in 1..4 && l.isNotEmpty()) l.map { RRun(it.text, true, it.i, it.u, it.s, it.color, it.hl, if (it.sz == 0) sz else it.sz, it.font, it.sup, it.href, it.img) } else l
                    sinks.last().add(RPara(rr, pAlign, pHead, pMarker, if (pMarker.isNotEmpty()) 720 * maxOf(1, lists.size) + pLeft else pLeft, if (pMarker.isNotEmpty()) -360 else (pFirstCss ?: 0),
                        pBeforeCss ?: (if (pHead in 1..2) 240 else 0), pAfterCss ?: (if (pHead > 0) 120 else 160), 0, fill = pFill))
                    total++
                }
            }
            runs.clear(); pMarker = ""; pendingSpace = false; pFirstCss = null; pBeforeCss = null; pAfterCss = null
        }
        fun text(t0: String) {
            if (skip > 0) return
            var t = DocParse.htmlDecode(t0)
            if (pre > 0) {
                if (t.isEmpty()) return
                runs.add(RRun(t.replace("\t", "    "), cur.b, cur.i, cur.u, cur.s, cur.color, cur.hl, if (cur.sz > 0) cur.sz else 20, "Courier New", cur.sup, cur.href)); return
            }
            t = t.replace(Regex("[\\s\\u00A0&&[^\\u00A0]]+"), " ")
            if (t.isBlank()) { if (runs.isNotEmpty()) pendingSpace = true; return }
            if (runs.isEmpty() || (runs.last().img == null && runs.last().text.endsWith(" "))) t = t.trimStart()
            else if (t.startsWith(" ") ) { /* tek boşluk kalır */ }
            if (pendingSpace && !t.startsWith(" ") && runs.isNotEmpty()) t = " $t"
            pendingSpace = false
            if (t.isEmpty()) return
            runs.add(RRun(t, cur.b, cur.i, cur.u, cur.s, cur.color, cur.hl, cur.sz, cur.font, cur.sup, cur.href))
        }
        fun open(tag: String) { stack.add(tag to cur); cur = cur.copy() }
        fun close(tag: String) {
            val k = stack.indexOfLast { it.first == tag }
            if (k >= 0) { cur = stack[k].second; while (stack.size > k) stack.removeAt(stack.size - 1) }
        }
        fun endCell() {
            val t = tbls.lastOrNull() ?: return
            if (sinks.size < 2) return
            flush()
            val sink = sinks.removeAt(sinks.size - 1)
            val paras = ArrayList<RPara>()
            for (b in sink) when (b) { is RPara -> paras.add(b); is RTable -> b.rows.forEach { r -> r.forEach { c -> paras.addAll(c.paras) } }; is RBox -> b.blocks.forEach { x -> if (x is RPara) paras.add(x) } }
            val bd = Bd(4, "999999")
            t.row.add(RCell(if (paras.isEmpty()) listOf(RPara(emptyList(), after = 0)) else paras.map { RPara(it.runs, it.align, 0, it.marker, it.left, it.first, 0, 0, 0) },
                t.span, 0, if (t.header) "EEEEEE" else null, bd, bd, bd, bd))
        }

        for (m in TOKEN.findAll(html)) {
            if (total >= MAX_BLOCKS) break
            pendingBefore = null
            val tx = m.groupValues[4]
            if (m.value.startsWith("<!--")) continue
            if (m.groups[2] == null) { if (hideDepth == 0) text(tx); continue }
            val closing = m.groupValues[1] == "/"
            val tag = m.groupValues[2].lowercase().substringAfter(':')
            val raw = m.groupValues[3]
            var a = if (closing) emptyMap() else attrs(raw)
            val self = raw.trimEnd().endsWith("/")
            if (hideDepth > 0) { if (tag == hideTag) { if (closing) hideDepth-- else if (!self) hideDepth++ }; continue }
            if (sheet != null && tag !in VOID) {
                if (closing) { val k = anc.indexOfLast { it.tag == tag }; if (k >= 0) { for (ix in anc.size - 1 downTo k) anc[ix].after?.let { text(it) }; while (anc.size > k) anc.removeAt(anc.size - 1); while (sibs.size > k + 1) { sibs.removeAt(sibs.size - 1); tagCnt.removeAt(tagCnt.size - 1) } } }
            }
            if (!closing && sheet != null) {
                val el = Anc(tag, (a["class"] ?: "").split(Regex("\\s+")).filter { it.isNotEmpty() }, a["id"], a, sibs.last().let { if (it.size > 30) it.subList(it.size - 30, it.size).toList() else it.toList() }, sibs.last().size + 1, endIdx[m.range.first] ?: 0, (tagCnt.last().merge(tag, 1) { x, y -> x + y } ?: 1), typeEnd[m.range.first] ?: 0, m.range.first in emptySet)
                val cs = sheet.styleFor(el, anc)
                if (sibs.last().size < 100000) sibs.last().add(el)
                if (sheet.hasPseudo && !self && tag !in VOID) { pendingBefore = sheet.pseudoContent(el, anc, "before"); el.after = sheet.pseudoContent(el, anc, "after") }
                if (!self && tag !in VOID && anc.size < 200) { anc.add(el); sibs.add(ArrayList()); tagCnt.add(HashMap()) }
                if (cs.isNotEmpty()) a = a + ("style" to (cs + ";" + (a["style"] ?: "")))
            }
            if (!closing && !self && decl(a["style"] ?: "", "display") == "none" && tag !in setOf("br", "hr", "img", "meta", "link", "input")) { hideTag = tag; hideDepth = 1; continue }
            if (tag in SKIP) { if (!closing && !self) skip++ else if (closing && skip > 0) skip--; continue }
            if (skip > 0) continue
            when (tag) {
                "br" -> { if (!closing) { if (pre > 0 || runs.isNotEmpty()) runs.add(RRun("\n", cur.b, cur.i, cur.u, cur.s, cur.color, cur.hl, cur.sz, cur.font)) else flush(true) } }
                "hr" -> { flush(); sinks.last().add(RPara(emptyList(), after = 120, bottom = Bd(8, "808080"))) }
                "img", "image" -> if (!closing) {
                    flush0@ run {
                        val src = a["src"] ?: a.entries.firstOrNull { it.key.endsWith("href") }?.value ?: a["recindex"]?.let { "recindex:$it" } ?: return@run
                        val im = resolve(src)
                        if (im != null) runs.add(RRun("", img = im)) else a["alt"]?.takeIf { it.isNotBlank() }?.let { runs.add(RRun("[$it]", cur.b, true, cur.u, cur.s, cur.color, cur.hl, cur.sz, cur.font)) }
                    }
                }
                "b", "strong" -> if (closing) close(tag) else { open(tag); cur.b = true }
                "i", "em", "cite", "dfn", "var" -> if (closing) close(tag) else { open(tag); cur.i = true }
                "u", "ins" -> if (closing) close(tag) else { open(tag); cur.u = true }
                "s", "strike", "del" -> if (closing) close(tag) else { open(tag); cur.s = true }
                "sup" -> if (closing) close(tag) else { open(tag); cur.sup = 1 }
                "sub" -> if (closing) close(tag) else { open(tag); cur.sup = -1 }
                "code", "tt", "kbd", "samp" -> if (closing) close(tag) else { open(tag); cur.font = "Courier New" }
                "a" -> if (closing) close(tag) else { open(tag); styleOf(a, cur); (a["href"] ?: a.entries.firstOrNull { it.key.endsWith(":href") }?.value)?.takeIf { it.startsWith("http", true) || it.startsWith("mailto:", true) }?.let { cur.href = it; cur.u = true; if (cur.color == null) cur.color = "0563C1" } }
                "span", "font", "small", "big", "mark", "abbr", "q", "label" -> if (closing) close(tag) else {
                    open(tag); styleOf(a, cur)
                    if (tag == "font") { a["color"]?.let { c -> Rich.hex(c)?.let { cur.color = it } ?: cssName(c.lowercase())?.let { cur.color = it } }; a["face"]?.let { cur.font = it } }
                    if (tag == "small") cur.sz = 18; if (tag == "mark") cur.hl = "FFFF00"
                }
                "h1", "h2", "h3", "h4", "h5", "h6" -> { flush(); if (closing) { pHead = 0; pAlign = ""; close(tag) } else { open(tag); styleOf(a, cur); pHead = tag[1] - '0'; pAlign = alignOf(a) } }
                "ul", "ol" -> { flush(); if (closing) { if (lists.isNotEmpty()) lists.removeAt(lists.size - 1) } else lists.add(ListCtx(tag == "ol")) }
                "li" -> { flush(); if (closing) close(tag) else { open(tag); styleOf(a, cur) }; if (!closing) { val l = lists.lastOrNull(); l?.let { it.n++ }; pMarker = if (l == null || !l.ordered) "•" else "${l.n}."; pAlign = alignOf(a) } else pMarker = "" }
                "blockquote" -> { flush(); if (closing) { quote--; pLeft = (pLeft - 720).coerceAtLeast(0); pFill = if (quote > 0) pFill else null; close(tag) } else { quote++; pLeft += 720; open(tag); styleOf(a, cur) } }
                "pre" -> { flush(); if (closing) { pre = maxOf(0, pre - 1); pFill = null; close(tag) } else { pre++; open(tag); pFill = "F5F5F5" } }
                "table" -> { flush(); if (closing) {
                        val t = tbls.removeLastOrNull()
                        if (t != null) {
                            if (t.row.isNotEmpty()) t.rows.add(t.row)
                            if (t.rows.isNotEmpty()) {
                                val n = t.rows.maxOf { r -> r.sumOf { it.span } }
                                val rows = t.rows.map { r -> val s = r.sumOf { it.span }; if (s < n) r + RCell(listOf(RPara(emptyList(), after = 0)), n - s) else r }
                                sinks.last().add(RTable(rows, List(n) { 9000 / n.coerceAtLeast(1) }))
                                total++
                            }
                        }
                    } else tbls.add(Tbl()) }
                "tr" -> tbls.lastOrNull()?.let { t -> if (!closing) { if (t.row.isNotEmpty()) t.rows.add(t.row); t.row = ArrayList() } else { endCell0(sinks, tbls, ::endCell, sinks.size > 1 && tbls.isNotEmpty()); if (t.row.isNotEmpty()) { t.rows.add(t.row); t.row = ArrayList() } } }
                "td", "th" -> tbls.lastOrNull()?.let { t ->
                    if (closing) { if (sinks.size > 1) endCell() }
                    else { if (sinks.size > 1 && tbls.isNotEmpty()) endCell(); flush(); t.span = (a["colspan"]?.toIntOrNull() ?: 1).coerceIn(1, 30); t.header = tag == "th"; sinks.add(ArrayList()); if (tag == "th") { open(tag); cur.b = true } }
                }
                "thead", "tbody", "tfoot", "caption", "colgroup", "col" -> {}
                else -> if (tag in BLOCK) { flush(); if (!closing) { pAlign = alignOf(a); if (a.containsKey("style") && tag != "html" && tag != "body") { open(tag); styleOf(a, cur) } } else { pAlign = ""; close(tag) } }
            }
            if (!closing && (tag == "p" || tag in BLOCK || tag == "li" || tag.length == 2 && tag[0] == 'h' && tag[1] in '1'..'6')) {
                val st0 = a["style"] ?: ""
                decl(st0, "text-indent")?.let { cssLen(it) }?.let { pFirstCss = it }
                decl(st0, "margin-top")?.let { cssLen(it) }?.let { pBeforeCss = it.coerceIn(0, 1200) }
                decl(st0, "margin-bottom")?.let { cssLen(it) }?.let { pAfterCss = it.coerceIn(0, 1200) }
                decl(st0, "margin-left")?.let { cssLen(it) }?.let { pLeft = (pLeft + it).coerceIn(0, 6000) }
            }
            if (!closing && tag == "p") { pAlign = alignOf(a); open("p"); styleOf(a, cur) }
            if (closing && tag == "p") { close("p") }
            pendingBefore?.let { text(it); pendingBefore = null }
        }
        while (sinks.size > 1) endCell()
        flush()
        return root
    }

    private fun endCell0(sinks: List<*>, tbls: List<*>, f: () -> Unit, cond: Boolean) { if (cond) f() }

    private fun alignOf(a: Map<String, String>): String {
        val v = (a["align"] ?: Regex("text-align\\s*:\\s*([a-z]+)").find(a["style"] ?: "")?.groupValues?.get(1) ?: "").lowercase()
        return if (v == "center" || v == "right" || v == "justify") v else ""
    }

    /** Sayfa boyutlu, e-kitap okuma için uygun kenar boşluklu sayfa. */
    fun page(blocks: List<RBlock>) = RichPage(blocks, PageSetup(11906, 16838, 1134, 1134, 1134, 1134), 22, null, 0, 0)
}
