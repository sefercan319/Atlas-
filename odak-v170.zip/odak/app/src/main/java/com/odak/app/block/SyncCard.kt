package com.odak.app.block

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.logic.CatalogSync
import com.odak.app.theme.Text
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck

/** Uygulama kimlikleri ve kuralları açık kaynak listelerden güncelleme kartı. */
@Composable
fun SyncCard() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(SyncRunner.running) }
    androidx.compose.runtime.key(tick) {
        ThemedCard(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.sync_title), style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.sync_hint), style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.7f))
            val st = SyncRunner.status(ctx)
            if (st != 0) {
                val line = when (st) {
                    SyncRunner.OK -> "✔ " + stringResource(R.string.sync_done) + " · +" + SyncRunner.newApps(ctx) + " " + stringResource(R.string.sync_new_apps) +
                        " · " + SyncRunner.newRules(ctx) + " " + stringResource(R.string.sync_rules)
                    SyncRunner.NOTHING -> "✔ " + stringResource(R.string.sync_none)
                    else -> "✖ " + stringResource(R.string.sync_fail)
                }
                Text(line, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
            }
            val last = SyncRunner.last(ctx)
            if (last > 0L) Text(
                stringResource(R.string.sync_last) + ": " + java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(java.util.Date(last)),
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.6f)
            )
            Text(stringResource(R.string.sync_sources), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 12.dp))
            CatalogSync.SOURCES.forEach { s ->
                var on by remember(s.id) { mutableStateOf(SyncRunner.enabled(ctx, s.id)) }
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text(s.label, Modifier.weight(1f))
                    ThemedCheck(on) { on = it; SyncRunner.setEnabled(ctx, s.id, it) }
                }
            }
            var auto by remember { mutableStateOf(SyncRunner.auto(ctx)) }
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text(stringResource(R.string.sync_auto), Modifier.weight(1f))
                ThemedCheck(auto) { auto = it; SyncRunner.setAuto(ctx, it) }
            }
            Spacer(Modifier.height(8.dp))
            ThemedButton(
                if (busy) stringResource(R.string.sync_running) else stringResource(R.string.sync_now),
                { if (!busy) { busy = true; SyncRunner.run(ctx) { busy = false; tick++ } } },
                Modifier.fillMaxWidth()
            )
        }
    }
}
