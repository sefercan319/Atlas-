package com.odak.app.docs

import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler

/** XLSX sayfası → zengin tablo: hücre rengi/gölgesi/kenarlığı, kalın/italik, hizalama, sütun genişliği, birleşik hücreler. */
object RichXlsx {
    private const val MAX_ROWS = 3000
    private const val MAX_COLS = 60
    private val THEME = listOf("FFFFFF", "000000", "E7E6E6", "44546A", "4472C4", "ED7D31", "A5A5A5", "FFC000", "5B9BD5", "70AD47")

    internal class Font(var b: Boolean = false, var i: Boolean = false, var u: Boolean = false, var s: Boolean = false, var color: String? = null, var sz: Int = 0, var name: String? = null)
    internal class Xf(val font: Int, val fill: Int, val border: Int, var h: String = "", var v: String = "", val numFmt: Int = 0)

    class Styles internal constructor() {
        internal val fonts = ArrayList<Font>()
        val fills = ArrayList<String?>()
        internal val borders = ArrayList<Array<Bd?>>()   // top, left, bottom, right
        internal val xfs = ArrayList<Xf>()
        internal val numFmts = HashMap<Int, String>()
        var locale: java.util.Locale = java.util.Locale.ENGLISH

        /** Hücre ham değerini biçim koduna göre metne çevirir (yalnız sayısal hücreler için çağır). */
        fun fmt(sIdx: Int, raw: String): String {
            val id = xfs.getOrNull(sIdx)?.numFmt ?: 0
            return NumFmt.format(raw, NumFmt.codeFor(id, numFmts), locale)
        }
    }

    private fun tint(hex: String, t: Double): String {
        if (t == 0.0) return hex
        val c = IntArray(3) { hex.substring(it * 2, it * 2 + 2).toInt(16) }
        val r = c.map { v -> (if (t > 0) v + (255 - v) * t else v * (1 + t)).toInt().coerceIn(0, 255) }
        return r.joinToString("") { "%02X".format(it) }
    }

    private fun color(a: Attributes?): String? {
        if (a == null) return null
        a.getValue("rgb")?.let { v -> return Rich.hex(v.takeLast(6)) }
        a.getValue("theme")?.toIntOrNull()?.let { th -> return tint(THEME.getOrNull(th) ?: return null, a.getValue("tint")?.toDoubleOrNull() ?: 0.0) }
        return null
    }

    private fun bdWidth(style: String) = when (style) { "hair" -> 2; "thin", "dashed", "dotted", "dashDot", "dashDotDot" -> 4; "medium", "mediumDashed", "double" -> 12; "thick" -> 18; else -> 4 }

    fun styles(xml: ByteArray?): Styles? {
        if (xml == null) return null
        val s = Styles()
        var inFonts = false; var inFills = false; var inBorders = false; var inXfs = false
        var font: Font? = null; var fill: String? = null; var fillSolid = false; var inFill = false
        var border: Array<Bd?>? = null; var side = -1; var sideStyle = ""
        var xf: Xf? = null
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) {
                    "fonts" -> inFonts = true
                    "fills" -> inFills = true
                    "borders" -> inBorders = true
                    "cellXfs" -> inXfs = true
                    "font" -> if (inFonts) font = Font()
                    "b" -> font?.b = a?.getValue("val") != "0"
                    "i" -> font?.i = a?.getValue("val") != "0"
                    "u" -> font?.u = a?.getValue("val") != "none"
                    "strike" -> font?.s = a?.getValue("val") != "0"
                    "sz" -> font?.sz = ((a?.getValue("val")?.toDoubleOrNull() ?: 0.0) * 2).toInt()
                    "name" -> font?.name = a?.getValue("val")
                    "color" -> if (font != null) font!!.color = color(a) else if (border != null && side >= 0 && sideStyle.isNotEmpty()) border!![side] = Bd(bdWidth(sideStyle), color(a) ?: "000000")
                    "fill" -> if (inFills) { inFill = true; fill = null; fillSolid = false }
                    "patternFill" -> if (inFill) fillSolid = a?.getValue("patternType") == "solid"
                    "fgColor" -> if (inFill && fillSolid) fill = color(a)
                    "border" -> if (inBorders) border = arrayOfNulls(4)
                    "top", "left", "bottom", "right" -> if (border != null) {
                        side = when (q) { "top" -> 0; "left" -> 1; "bottom" -> 2; else -> 3 }
                        sideStyle = a?.getValue("style") ?: ""
                        if (sideStyle.isNotEmpty()) border!![side] = Bd(bdWidth(sideStyle), "000000")
                    }
                    "numFmt" -> { val id = a?.getValue("numFmtId")?.toIntOrNull(); val code = a?.getValue("formatCode"); if (id != null && code != null && s.numFmts.size < 500) s.numFmts[id] = code }
                    "xf" -> if (inXfs) xf = Xf(a?.getValue("fontId")?.toIntOrNull() ?: 0, a?.getValue("fillId")?.toIntOrNull() ?: 0, a?.getValue("borderId")?.toIntOrNull() ?: 0, numFmt = a?.getValue("numFmtId")?.toIntOrNull() ?: 0)
                    "alignment" -> xf?.let { it.h = a?.getValue("horizontal") ?: ""; it.v = a?.getValue("vertical") ?: "" }
                }
            }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) {
                    "fonts" -> inFonts = false
                    "fills" -> inFills = false
                    "borders" -> inBorders = false
                    "cellXfs" -> inXfs = false
                    "font" -> { font?.let { s.fonts.add(it) }; font = null }
                    "fill" -> if (inFill) { s.fills.add(fill); inFill = false }
                    "border" -> { border?.let { s.borders.add(it) }; border = null; side = -1 }
                    "top", "left", "bottom", "right" -> { side = -1; sideStyle = "" }
                    "xf" -> { xf?.let { s.xfs.add(it) }; xf = null }
                }
            }
        })
        return s
    }

    private class Cell(var text: String, val style: Int, val numeric: Boolean)

    fun page(xml: ByteArray, shared: List<String>, st: Styles, title: String?): RichPage? {
        val cells = HashMap<Long, Cell>()
        val colW = HashMap<Int, Int>()
        val merges = ArrayList<IntArray>()      // r1, c1, r2, c2
        var rowIdx = -1; var ref = ""; var type = ""; var sIdx = 0
        val v = StringBuilder(); var inV = false; var inIs = false
        var maxR = -1; var maxC = -1
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) {
                    "row" -> rowIdx = (a?.getValue("r")?.toIntOrNull() ?: (rowIdx + 2)) - 1
                    "c" -> { ref = a?.getValue("r") ?: ""; type = a?.getValue("t") ?: ""; sIdx = a?.getValue("s")?.toIntOrNull() ?: 0; v.setLength(0) }
                    "v" -> inV = true
                    "is" -> inIs = true
                    "t" -> if (inIs) inV = true
                    "col" -> {
                        val mn = a?.getValue("min")?.toIntOrNull() ?: return; val mx = (a.getValue("max")?.toIntOrNull() ?: mn).coerceAtMost(MAX_COLS)
                        val w = a.getValue("width")?.toDoubleOrNull() ?: return
                        for (c in mn..mx) colW[c - 1] = (w * 105).toInt() + 80
                    }
                    "mergeCell" -> a?.getValue("ref")?.let { r ->
                        val p = r.split(':')
                        if (p.size == 2) { val a1 = ref2(p[0]); val b1 = ref2(p[1]); if (a1 != null && b1 != null && merges.size < 2000) merges.add(intArrayOf(a1.first, a1.second, b1.first, b1.second)) }
                    }
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inV) v.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) {
                    "v" -> inV = false
                    "t" -> if (inIs) inV = false
                    "is" -> inIs = false
                    "c" -> {
                        val raw = v.toString()
                        val text = when (type) { "s" -> raw.trim().toIntOrNull()?.let { shared.getOrNull(it) } ?: ""; "b" -> if (raw.trim() == "1") "TRUE" else "FALSE"; else -> raw }
                        val rc = ref2(ref)
                        val row = rc?.first ?: rowIdx; val col = rc?.second ?: 0
                        if (row in 0 until MAX_ROWS && col in 0 until MAX_COLS && (text.isNotEmpty() || sIdx != 0)) {
                            val numeric = type == "" || type == "n"
                            cells[row.toLong() * 100 + col] = Cell(if (numeric && text.isNotBlank()) st.fmt(sIdx, text) else text, sIdx, numeric)
                            if (row > maxR) maxR = row; if (col > maxC) maxC = col
                        }
                    }
                }
            }
        })
        if (maxR < 0 || maxC < 0) return null
        for (m in merges) { if (m[2] > maxR) maxR = minOf(m[2], MAX_ROWS - 1); if (m[3] > maxC) maxC = minOf(m[3], MAX_COLS - 1) }
        val nCols = maxC + 1
        val cols = (0 until nCols).map { colW[it] ?: 960 }
        val rows = ArrayList<List<RCell>>()
        for (r in 0..maxR) {
            val out = ArrayList<RCell>()
            var c = 0
            while (c < nCols) {
                val mg = merges.firstOrNull { r in it[0]..it[2] && c in it[1]..it[3] }
                val cell = cells[r.toLong() * 100 + c]
                if (mg != null && !(r == mg[0] && c == mg[1])) {
                    if (c == mg[1] && r > mg[0]) { out.add(RCell(emptyList(), minOf(mg[3], maxC) - mg[1] + 1, 2)); c = minOf(mg[3], maxC) + 1; continue }
                    c++; continue
                }
                val span = if (mg != null) minOf(mg[3], maxC) - mg[1] + 1 else 1
                val vm = if (mg != null && mg[2] > mg[0]) 1 else 0
                val xf = st.xfs.getOrNull(cell?.style ?: 0)
                val f = xf?.let { st.fonts.getOrNull(it.font) }
                val fillC = xf?.let { st.fills.getOrNull(it.fill) }
                val bd = xf?.let { st.borders.getOrNull(it.border) }
                val align = when { xf?.h == "center" || xf?.h == "centerContinuous" -> "center"; xf?.h == "right" -> "right"; xf?.h == "left" -> ""; xf?.h == "justify" -> "justify"; cell?.numeric == true && cell.text.isNotEmpty() -> "right"; else -> "" }
                val run = RRun(cell?.text ?: "", f?.b == true, f?.i == true, f?.u == true, f?.s == true, f?.color, null, if ((f?.sz ?: 0) > 0) f!!.sz else 22, f?.name)
                out.add(RCell(listOf(RPara(listOf(run), align, before = 0, after = 0)), span, vm, fillC, bd?.get(0), bd?.get(1), bd?.get(2), bd?.get(3), 0,
                    when (xf?.v) { "center" -> "center"; "top" -> ""; else -> "bottom" }))
                c += span
            }
            rows.add(out)
        }
        val blocks = ArrayList<RBlock>()
        if (!title.isNullOrBlank()) blocks.add(RPara(listOf(RRun(title, b = true, sz = 28)), head = 2, after = 120))
        blocks.add(RTable(rows, cols))
        return RichPage(blocks, PageSetup(16838, 11906, 720, 720, 720, 720), 22, st.fonts.firstOrNull()?.name, 0, 0)
    }

    private val REL_TAG = Regex("<Relationship\\b[^>]*>")
    private fun relAttr(tag: String, name: String) = Regex("\\b$name\\s*=\\s*\"([^\"]*)\"").find(tag)?.groupValues?.get(1)

    /** Sayfaya gömülü resimler (çizim katmanı), belgedeki sırayla; tanınmayan biçimler çeviriciyle PNG'ye çevrilir. */
    fun images(e: Map<String, ByteArray>, sheetPath: String): List<RImg> {
        val out = ArrayList<RImg>()
        try {
            val dir = sheetPath.substringBeforeLast('/', "")
            val relsXml = e[dir + "/_rels/" + sheetPath.substringAfterLast('/') + ".rels"] ?: return out
            val drawingPath = REL_TAG.findAll(String(relsXml, Charsets.UTF_8)).mapNotNull { m ->
                val t = m.value
                val type = relAttr(t, "Type") ?: return@mapNotNull null
                if (!type.endsWith("/drawing")) return@mapNotNull null
                relAttr(t, "Target")
            }.firstOrNull() ?: return out
            val dPath = DocVisual.resolve("$dir/", drawingPath)
            val dXml = e[dPath] ?: return out
            val dDir = dPath.substringBeforeLast('/', "")
            val dRels = e[dDir + "/_rels/" + dPath.substringAfterLast('/') + ".rels"] ?: return out
            val targets = HashMap<String, String>()
            for (m in REL_TAG.findAll(String(dRels, Charsets.UTF_8))) {
                val id = relAttr(m.value, "Id") ?: continue; val tg = relAttr(m.value, "Target") ?: continue
                targets[id] = DocVisual.resolve("$dDir/", tg)
            }
            var total = 0L
            for (m in Regex("r:embed\\s*=\\s*\"([^\"]+)\"").findAll(String(dXml, Charsets.UTF_8))) {
                val data = targets[m.groupValues[1]]?.let { e[it] } ?: continue
                if (total + data.size > 24L * 1024 * 1024) break
                val im = HtmlRich.image(data) ?: continue
                total += data.size
                out.add(im)
                if (out.size >= 60) break
            }
        } catch (x: Exception) { }
        return out
    }

    /** "B3" → (satır 2, sütun 1). */
    private fun ref2(r: String): Pair<Int, Int>? {
        val m = Regex("^([A-Za-z]+)(\\d+)$").find(r.trim()) ?: return null
        var c = 0
        for (ch in m.groupValues[1].uppercase()) c = c * 26 + (ch - 'A' + 1)
        return (m.groupValues[2].toInt() - 1) to (c - 1)
    }
}
