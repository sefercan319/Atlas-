package com.odak.app.logic

import java.util.Locale

/**
 * Uygulama kimliklerini (paket adları) ve engelleme kurallarını açık kaynak listelerden güncelleme mantığı.
 * Ağ ve dosya işi block/SyncRunner.kt'de; burada yalnız doğrulama, ayrıştırma ve birleştirme var (JVM'de testlenir).
 */
object CatalogSync {
    const val KIND_ATLAS = 0
    const val KIND_UAD = 1

    class Source(val id: String, val label: String, val url: String, val kind: Int, val defaultOn: Boolean, val fallbackOf: String? = null)

    /** Kaynaklar. "mirror" yalnız "atlas" ulaşılamazsa denenir (aynı dosyanın yansıması). */
    val SOURCES = listOf(
        Source("atlas", "Atlas (GitHub)", "https://raw.githubusercontent.com/sefercan319/Atlas-/main/catalog/atlas_catalog.json", KIND_ATLAS, true),
        Source("mirror", "Atlas (jsDelivr)", "https://cdn.jsdelivr.net/gh/sefercan319/Atlas-@main/catalog/atlas_catalog.json", KIND_ATLAS, true, "atlas"),
        Source("uad", "UAD-NG (GitHub)", "https://raw.githubusercontent.com/Universal-Debloater-Alliance/universal-android-debloater-next-generation/main/resources/assets/uad_lists.json", KIND_UAD, false)
    )

    const val MAX_BYTES = 8_000_000
    const val MAX_APPS = 6000
    const val INTERVAL_DAYS = 7

    class SyncApp(val id: String, val name: String, val pkgs: List<String>)
    class Parsed(val rules: Map<String, List<String>>, val apps: List<SyncApp>)
    /** Telefonda saklanan eşitlenmiş veri: yeni uygulamalar + var olan uygulamalara eklenen paket adları. */
    class Store(val apps: List<SyncApp>, val aliases: Map<String, List<String>>) {
        val size: Int get() = apps.size + aliases.values.sumOf { it.size }
        companion object { val EMPTY = Store(emptyList(), emptyMap()) }
    }

    private val PKG = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")
    private val RULE_KEY = Regex("^!?[a-z0-9_]+/[a-z0-9_]+$")
    private val RULE_ID = Regex("^[A-Za-z0-9_.]{5,80}$")
    private val APP_ID = Regex("^[a-z0-9_]{1,30}$")
    private val TOO_GENERIC = setOf("main_fragment_container", "container", "toolbar", "recycler_view", "recyclerview", "list_view", "bottom_nav")

    fun validPkg(s: String) = s.length <= 150 && PKG.matches(s)
    fun validRuleKey(k: String) = RULE_KEY.matches(k)
    fun validRuleEntry(e: String): Boolean {
        for (p in listOf("sel:", "desc:", "text:")) if (e.startsWith(p)) return e.length - p.length in 2..60 && !e.contains('\n')
        return RULE_ID.matches(e) && e.lowercase(Locale.ROOT) !in TOO_GENERIC
    }
    fun cleanName(s: String): String? =
        s.replace(Regex("\\s+"), " ").replace("|", " ").trim().trimEnd('.', ',', ':', ';').takeIf { it.length in 1..40 && !it.contains("http") }

    @Suppress("UNCHECKED_CAST")
    private fun map(o: Any?): Map<String, Any?>? = o as? Map<String, Any?>
    @Suppress("UNCHECKED_CAST")
    private fun list(o: Any?): List<Any?>? = o as? List<Any?>

    /** Atlas biçimi: {"rules": {"app/ozellik": ["..."]}, "apps": [{"id": "...", "name": "...", "packages": ["..."]}]} */
    fun parseAtlas(text: String): Parsed? {
        val root = map(MiniJson.parse(text)) ?: return null
        val rules = LinkedHashMap<String, List<String>>()
        map(root["rules"])?.forEach { (k, v) ->
            if (!validRuleKey(k)) return@forEach
            val l = list(v)?.mapNotNull { it as? String }?.filter { validRuleEntry(it) }?.distinct().orEmpty()
            if (l.isNotEmpty()) rules[k] = l.take(40)
        }
        val apps = ArrayList<SyncApp>()
        list(root["apps"])?.take(MAX_APPS)?.forEach { a ->
            val m = map(a) ?: return@forEach
            val name = cleanName(m["name"] as? String ?: return@forEach) ?: return@forEach
            val pk = list(m["packages"])?.mapNotNull { it as? String }?.filter { validPkg(it) }?.distinct().orEmpty()
            if (pk.isEmpty()) return@forEach
            val id = (m["id"] as? String)?.takeIf { APP_ID.matches(it) } ?: ""
            apps.add(SyncApp(id, name, pk.take(8)))
        }
        if (rules.isEmpty() && apps.isEmpty()) return null
        return Parsed(rules, apps)
    }

    private val PLAY = Regex("^(.{2,60}?)\\s*\\(https://play\\.google\\.com/store/apps/details\\?id=([A-Za-z0-9_.]+)")

    /** UAD-NG uad_lists.json: yalnız "Misc" listesindeki, Play bağlantısı olan üçüncü taraf uygulamalar. */
    fun parseUad(text: String): Parsed? {
        val root = map(MiniJson.parse(text)) ?: return null
        val apps = ArrayList<SyncApp>()
        for ((pkg, v) in root) {
            if (apps.size >= MAX_APPS) break
            val m = map(v) ?: continue
            if (m["list"] != "Misc" || !validPkg(pkg)) continue
            val first = (m["description"] as? String)?.lineSequence()?.firstOrNull().orEmpty()
            val g = PLAY.find(first)?.groupValues ?: continue
            if (g[2] != pkg) continue
            val name = cleanName(g[1])?.takeIf { it.length >= 2 } ?: continue
            apps.add(SyncApp("", name, listOf(pkg)))
        }
        return if (apps.isEmpty()) null else Parsed(emptyMap(), apps)
    }

    fun parse(kind: Int, text: String): Parsed? = if (kind == KIND_UAD) parseUad(text) else parseAtlas(text)

    /**
     * [incoming] içinden yalnız yeni olanları [old] mağazasına ekler.
     * [known]: gömülü katalogdaki tüm paketler; [baseIds]: gömülü uygulama kimlikleri (id eşleşirse paket, o uygulamaya eklenir).
     */
    fun merge(old: Store, incoming: List<SyncApp>, known: Set<String>, baseIds: Set<String>): Store {
        val have = HashSet<String>(known)
        old.apps.forEach { have.addAll(it.pkgs) }
        old.aliases.values.forEach { have.addAll(it) }
        val apps = ArrayList(old.apps)
        val ali = LinkedHashMap<String, List<String>>(old.aliases)
        for (a in incoming) {
            if (apps.size >= MAX_APPS) break
            val fresh = a.pkgs.filter { have.add(it) }
            if (fresh.isEmpty()) continue
            if (a.id in baseIds) ali[a.id] = ((ali[a.id] ?: emptyList()) + fresh).distinct()
            else apps.add(SyncApp("x:" + fresh[0], a.name, fresh))
        }
        return Store(apps, ali)
    }

    /** Yalnız değişen/yeni kural anahtarları. */
    fun changedRules(current: Map<String, List<String>>, incoming: Map<String, List<String>>): Map<String, List<String>> =
        incoming.filter { (k, v) -> v.isNotEmpty() && current[k] != v }

    // ---- Saklama biçimi: "A|id|ad|paket,paket" ve "L|uygulamaId|paket,paket" ----
    fun serialize(s: Store): String = buildString {
        s.apps.forEach { append("A|").append(it.id).append('|').append(it.name.replace("|", " ").replace("\n", " ")).append('|').append(it.pkgs.joinToString(",")).append('\n') }
        s.aliases.forEach { (id, p) -> append("L|").append(id).append('|').append(p.joinToString(",")).append('\n') }
    }

    fun deserialize(t: String): Store {
        val apps = ArrayList<SyncApp>()
        val ali = LinkedHashMap<String, List<String>>()
        for (line in t.lines()) {
            val p = line.split('|')
            if (p.size == 4 && p[0] == "A") {
                val pk = p[3].split(',').filter { validPkg(it) }
                val nm = cleanName(p[2])
                if (pk.isNotEmpty() && nm != null) apps.add(SyncApp(p[1], nm, pk))
            } else if (p.size == 3 && p[0] == "L" && APP_ID.matches(p[1])) {
                val pk = p[2].split(',').filter { validPkg(it) }
                if (pk.isNotEmpty()) ali[p[1]] = pk
            }
        }
        return Store(apps, ali)
    }

    /** Aynı kaynakta "mirror" gibi yedekler yalnız ana kaynak başarısızsa denenir. */
    fun shouldTry(src: Source, okIds: Set<String>): Boolean = src.fallbackOf == null || src.fallbackOf !in okIds

    fun isDue(lastMs: Long, nowMs: Long, days: Int = INTERVAL_DAYS): Boolean =
        lastMs <= 0L || nowMs < lastMs || nowMs - lastMs >= days * 86_400_000L
}
