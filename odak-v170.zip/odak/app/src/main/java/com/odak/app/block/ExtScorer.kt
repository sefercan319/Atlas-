package com.odak.app.block

import android.content.Context
import com.odak.app.logic.ModelPure
import java.io.File

/** İçe aktarılan sınıflandırıcıyı uzantıya göre doğru çalışma zamanına yollar: ONNX Runtime · TensorFlow Lite · PyTorch Mobile · ExecuTorch. */
object ExtScorer {
    /** İndirilen dosyalar içinde desteklenen en yenisi. */
    fun file(c: Context): File? = ModelPure.EXT_KINDS.keys.mapNotNull { ModelDownloader.find(c, it) }.maxByOrNull { it.lastModified() }
    fun available(c: Context) = file(c) != null
    fun kind(c: Context): String? = file(c)?.let { ModelPure.kind(it.name) }

    fun prob(c: Context, x: DoubleArray): Double? = when (kind(c)) {
        "onnx" -> OnnxScorer.prob(c, x)
        "tflite" -> TfliteRunner.prob(c, x)
        "torch" -> TorchRunner.probTorch(c, x)
        "executorch" -> TorchRunner.probExecutorch(c, x)
        else -> null
    }

    fun release() { OnnxScorer.release(); TfliteRunner.release(); TorchRunner.release() }
}
