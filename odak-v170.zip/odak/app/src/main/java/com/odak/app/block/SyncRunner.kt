package com.odak.app.block

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.odak.app.logic.CatalogSync
import com.odak.app.logic.MiniJson
import com.odak.app.logic.SafeFile
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Uygulama kimliklerini ve engelleme kurallarını açık kaynak listelerden çeker (yalnız kullanıcı basınca ya da haftada bir). */
object SyncRunner {
    const val OK = 1
    const val NOTHING = 2
    const val FAIL = 3

    @Volatile var running = false
    private fun p(c: Context) = c.getSharedPreferences("odak_sync", Context.MODE_PRIVATE)

    fun enabled(c: Context, id: String) = p(c).getBoolean("src:$id", CatalogSync.SOURCES.first { it.id == id }.defaultOn)
    fun setEnabled(c: Context, id: String, v: Boolean) = p(c).edit().putBoolean("src:$id", v).apply()
    fun auto(c: Context) = p(c).getBoolean("auto", true)
    fun setAuto(c: Context, v: Boolean) = p(c).edit().putBoolean("auto", v).apply()
    fun last(c: Context) = p(c).getLong("last", 0L)
    fun status(c: Context) = p(c).getInt("status", 0)
    fun newApps(c: Context) = p(c).getInt("n_apps", 0)
    fun newRules(c: Context) = p(c).getInt("n_rules", 0)

    private fun fetch(url: String): String {
        require(url.startsWith("https://"))
        val con = URL(url).openConnection() as HttpURLConnection
        try {
            con.connectTimeout = 15000; con.readTimeout = 30000; con.instanceFollowRedirects = true
            con.setRequestProperty("User-Agent", "Atlas-catalog-sync")
            if (con.responseCode != 200) throw java.io.IOException("http " + con.responseCode)
            val out = java.io.ByteArrayOutputStream()
            con.inputStream.use { i ->
                val buf = ByteArray(16384)
                while (true) {
                    val n = i.read(buf); if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > CatalogSync.MAX_BYTES) throw java.io.IOException("too big")
                }
            }
            return out.toString("UTF-8")
        } finally { con.disconnect() }
    }

    /** Arka planda çalışır; bitince [done] ana iş parçacığında çağrılır. Zaten çalışıyorsa yok sayılır. */
    fun run(c: Context, done: () -> Unit = {}) {
        if (running) return
        running = true
        val app = c.applicationContext
        Thread {
            var status = FAIL; var nApps = 0; var nRules = 0
            try {
                val ok = HashSet<String>()
                var store = try { CatalogSync.deserialize(SafeFile.read(File(app.filesDir, "synced_apps.txt")) ?: "") } catch (e: Exception) { CatalogSync.Store.EMPTY }
                val before = store.size
                val known = BlockCatalog.knownPackages(); val ids = BlockCatalog.baseIds()
                var changed = emptyMap<String, List<String>>()
                val current = BlockStore.rules(app)
                for (s in CatalogSync.SOURCES) {
                    if (!enabled(app, s.id) || !CatalogSync.shouldTry(s, ok)) continue
                    val parsed = try { CatalogSync.parse(s.kind, fetch(s.url)) } catch (e: Exception) { null } ?: continue
                    ok.add(s.id)
                    store = CatalogSync.merge(store, parsed.apps, known, ids)
                    changed = changed + CatalogSync.changedRules(current, parsed.rules)
                }
                if (ok.isNotEmpty()) {
                    nApps = store.size - before; nRules = changed.size
                    if (nApps > 0) SafeFile.write(File(app.filesDir, "synced_apps.txt"), CatalogSync.serialize(store))
                    if (nRules > 0) {
                        val f = File(app.filesDir, "block_rules.json")
                        val over = SafeFile.read(f) { RuleLab.validJson(it) }
                        val merged = LinkedHashMap<String, List<String>>()
                        (over?.let { MiniJson.parse(it) } as? Map<*, *>)?.forEach { (k, v) ->
                            if (k is String && v is List<*>) merged[k] = v.mapNotNull { it as? String }
                        }
                        merged.putAll(changed)
                        SafeFile.write(f, MiniJson.writeRules(merged))
                    }
                    status = if (nApps > 0 || nRules > 0) OK else NOTHING
                }
            } catch (e: Exception) { status = FAIL }
            p(app).edit().putInt("status", status).putInt("n_apps", nApps).putInt("n_rules", nRules)
                .apply { if (status != FAIL) putLong("last", System.currentTimeMillis()) }.apply()
            Handler(Looper.getMainLooper()).post {
                try { BlockCatalog.loadSynced(app) } catch (e: Exception) { }
                running = false
                done()
            }
        }.start()
    }

    /** Uygulama açılırken: otomatik açıksa ve 7 gün geçtiyse sessizce güncelle. */
    fun autoIfDue(c: Context) {
        if (auto(c) && CatalogSync.isDue(last(c), System.currentTimeMillis())) run(c)
    }
}
