package com.odak.app.block

import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import com.odak.app.R
import androidx.compose.ui.graphics.Color
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedHeader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private class UsageRow(val label: String, val ms: Long, val pkg: String, val cat: Int)

private fun fmt(ms: Long): String {
    val m = ms / 60_000
    return if (m >= 60) "${m / 60}h ${"%02d".format(m % 60)}m" else "${m}m"
}

@Composable
fun ScreenTimeScreen() {
    val ctx = LocalContext.current
    val t = LocalDesign.current.tokens
    var granted by remember { mutableStateOf(BlockStore.usageAccess(ctx)) }
    var guide by remember { mutableStateOf(false) }
    if (guide) PermGrantNow(com.odak.app.logic.PermKind.USAGE) { guide = false }
    var rows by remember { mutableStateOf(emptyList<UsageRow>()) }

    var stats by remember { mutableStateOf<BlockStore.DayStats?>(null) }
    var week by remember { mutableStateOf(emptyList<Pair<java.time.LocalDate, Long>>()) }
    // Seri için daha uzun geçmiş (grafik ve gün gezgini 14 günle sınırlı kalır).
    var history by remember { mutableStateOf(emptyList<Pair<java.time.LocalDate, Long>>()) }
    var day by remember { mutableStateOf(java.time.LocalDate.now()) }
    var rowsShown by remember(day) { mutableStateOf(com.odak.app.logic.Pure.APP_PAGE) }
    val isToday = day == java.time.LocalDate.now()

    LaunchedEffect(Unit) {
        while (true) {
            granted = BlockStore.usageAccess(ctx)
            if (granted) {
                week = withContext(Dispatchers.IO) { weekTotals(ctx) }
                history = withContext(Dispatchers.IO) { weekTotals(ctx, STREAK_WINDOW_DAYS) }
            }
            delay(60_000)
        }
    }
    // Gece yarısı gün değişince (ya da uygulama uykudan dönünce) "bugün" otomatik yeni güne geçer ve veri yenilenir.
    LaunchedEffect(Unit) {
        var last = java.time.LocalDate.now()
        while (true) {
            delay(2000)
            val n = java.time.LocalDate.now()
            if (n != last) {
                day = com.odak.app.logic.Pure.followToday(day, last, n)
                last = n
                if (granted) {
                    week = withContext(Dispatchers.IO) { weekTotals(ctx) }
                    history = withContext(Dispatchers.IO) { weekTotals(ctx, STREAK_WINDOW_DAYS) }
                }
            }
        }
    }
    LaunchedEffect(granted, day) {
        while (granted) {
            val pm = ctx.packageManager
            val z = java.time.ZoneId.systemDefault()
            val s0 = day.atStartOfDay(z).toInstant().toEpochMilli()
            val e0 = minOf(day.plusDays(1).atStartOfDay(z).toInstant().toEpochMilli(), System.currentTimeMillis())
            val res = withContext(Dispatchers.IO) {
                val r = BlockStore.usageRange(ctx, s0, e0)
                    .filter { it.value >= 60_000 && it.key != ctx.packageName }
                    .mapNotNull { (pkg, ms) ->
                        try {
                            if (pm.getLaunchIntentForPackage(pkg) == null) null
                            else pm.getApplicationInfo(pkg, 0).let { ai -> UsageRow(pm.getApplicationLabel(ai).toString(), ms, pkg, ai.category) }
                        } catch (e: PackageManager.NameNotFoundException) {
                            null
                        }
                    }
                    .sortedByDescending { it.ms }
                val home = pm.resolveActivity(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
                )?.activityInfo?.packageName
                val st = BlockStore.eventStats(ctx, s0, e0) { p ->
                    p != ctx.packageName && p != home && pm.getLaunchIntentForPackage(p) != null
                }
                r to st
            }
            rows = res.first
            stats = res.second
            if (!isToday) break
            delay(5000)
        }
    }

    val total = rows.sumOf { it.ms }
    val top = rows.firstOrNull()?.ms ?: 1L

    val land = com.odak.app.theme.rememberLandscape()
    val headPane: androidx.compose.foundation.lazy.LazyListScope.() -> Unit = {
        item {
            Spacer(Modifier.height(16.dp))
            ThemedHeader(stringResource(R.string.tab_screen_time))
        }
        if (granted) item { DayNav(day, week) { day = it } }
        if (!granted) {
            item {
                ThemedCard(Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.perm_usage))
                    Spacer(Modifier.height(10.dp))
                    ThemedButton(stringResource(R.string.block_grant), { guide = true })
                }
            }
        } else if (rows.isEmpty()) {
            item { com.odak.app.theme.EmptyState("⏱", stringResource(R.string.st_empty), stringResource(R.string.empty_st_hint)) }
        }
    }
    val summaryPane: androidx.compose.foundation.lazy.LazyListScope.() -> Unit = {
        if (granted && rows.isNotEmpty()) {
            item {
                var more by remember { mutableStateOf(false) }
                ThemedCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(R.string.st_total), style = MaterialTheme.typography.bodySmall)
                            Text(fmt(total), style = MaterialTheme.typography.headlineMedium)
                            if (isToday && week.size >= 2) {
                                com.odak.app.logic.Pure.pctChange(week[week.size - 2].second, total)?.let { pct ->
                                    Text(
                                        (if (pct > 0) "↑ " else "↓ ") + kotlin.math.abs(pct) + "% " + stringResource(R.string.st_vs_yday),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (pct > 0) Color(0xFFE53935) else Color(0xFF43A047)
                                    )
                                }
                            }
                        }
                        com.odak.app.theme.QuietAction("ⓘ", { more = true })
                    }
                }
                if (more) androidx.compose.material3.AlertDialog(
                    onDismissRequest = { more = false },
                    title = { Text(stringResource(R.string.tab_screen_time)) },
                    confirmButton = { ThemedButton(stringResource(R.string.pin_ok), { more = false }) },
                    text = {
                        Column {
                            Text(stringResource(R.string.st_total) + ": " + fmt(total))
                            stats?.let { st ->
                                Text("🔓 " + stringResource(R.string.st_unlocks) + ": " + st.unlocks)
                                if (st.unlocks > 0) Text(stringResource(R.string.st_per_unlock) + ": " + fmt(com.odak.app.logic.Pure.perUnlockMs(total, st.unlocks)))
                                val night = com.odak.app.logic.Pure.nightMs(st.hourMs)
                                if (night >= 60_000) Text("🌙 " + stringResource(R.string.st_night) + ": " + fmt(night))
                            }
                            val avg = week.takeLast(7).map { it.second }.filter { it > 0 }
                            if (avg.isNotEmpty()) Text(stringResource(R.string.st_avg) + ": " + fmt(avg.sum() / avg.size))
                            Spacer(Modifier.height(10.dp))
                            ThemedButton(stringResource(R.string.learn_share), {
                                val csv = "app,minutes\n" + rows.joinToString("\n") { "\"" + it.label + "\"," + it.ms / 60_000 }
                                val send = android.content.Intent(android.content.Intent.ACTION_SEND)
                                    .setType("text/plain").putExtra(android.content.Intent.EXTRA_TEXT, csv)
                                com.odak.app.Launch.go(ctx, 
                                    android.content.Intent.createChooser(send, null)
                                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            })
                        }
                    }
                )
            }
            item { Donut(rows, total) }
            item { GoalCard(if (isToday) total else (week.firstOrNull { it.first == java.time.LocalDate.now() }?.second ?: total), history) }
        }
    }
    val chartsPane: androidx.compose.foundation.lazy.LazyListScope.() -> Unit = {
        if (granted && rows.isNotEmpty()) {
            item { stats?.let { HourChart(it.hourMs) } }
            item { CategoryCard(rows) }
            item { WeekChart(week, day) { day = it } }
        }
    }
    val appsPane: androidx.compose.foundation.lazy.LazyListScope.() -> Unit = {
        if (granted && rows.isNotEmpty()) {
            items(rows.take(com.odak.app.logic.Pure.appsVisible(rowsShown, rows.size))) { r ->
                var open by remember(r.pkg) { mutableStateOf(false) }
                ThemedCard(Modifier.fillMaxWidth().clickable { open = true }) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text(
                            r.label + (stats?.opens?.get(r.pkg)?.let { "  ·  $it×" } ?: ""),
                            Modifier.weight(1f)
                        )
                        Text(fmt(r.ms) + "  ·  " + com.odak.app.logic.Pure.slicePct(r.ms, total) + "%")
                    }
                    Spacer(Modifier.height(8.dp))
                    RoundedBar(r.ms.toFloat() / top, height = 8.dp)
                }
                if (open) androidx.compose.material3.AlertDialog(
                    onDismissRequest = { open = false },
                    title = { Text(r.label) },
                    confirmButton = { ThemedButton(stringResource(R.string.pin_ok), { open = false }) },
                    text = {
                        Column {
                            Text(fmt(r.ms) + "  ·  " + com.odak.app.logic.Pure.slicePct(r.ms, total) + "%" + (stats?.opens?.get(r.pkg)?.let { "  ·  $it×" } ?: ""))
                            Spacer(Modifier.height(8.dp))
                            AppWeekBars(r.pkg)
                        }
                    }
                )
            }
            item {
                val rem = com.odak.app.logic.Pure.appsRemaining(rowsShown, rows.size)
                if (rem > 0) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemedButton(stringResource(R.string.blk_more, rem), { rowsShown = com.odak.app.logic.Pure.appsNextShown(rowsShown, rows.size) })
                    com.odak.app.theme.QuietAction(stringResource(R.string.blk_all), { rowsShown = rows.size })
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
    var tab by remember { mutableStateOf(0) }
    if (land) {
        Row(Modifier.fillMaxSize().padding(horizontal = 16.dp), Arrangement.spacedBy(12.dp)) {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                headPane(); summaryPane(); item { Spacer(Modifier.height(16.dp)) }
            }
            LazyColumn(Modifier.weight(1.15f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { Spacer(Modifier.height(16.dp)) }
                chartsPane(); appsPane()
            }
        }
    } else {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            headPane()
            if (granted && rows.isNotEmpty()) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(R.string.st_tab_sum, R.string.st_tab_charts, R.string.st_tab_apps).forEachIndexed { i, r ->
                            com.odak.app.theme.QuietAction((if (tab == i) "✔ " else "") + stringResource(r), { tab = i }, Modifier.weight(1f))
                        }
                    }
                }
                when (tab) { 0 -> summaryPane(); 1 -> chartsPane(); else -> appsPane() }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

/** Seri hesabı için geriye bakılan gün sayısı. */
private const val STREAK_WINDOW_DAYS = 60

/** Son [days] günün (bugün dahil, eskiden yeniye) toplam kullanımı. */
private fun weekTotals(ctx: android.content.Context, days: Int = 14): List<Pair<java.time.LocalDate, Long>> {
    val z = java.time.ZoneId.systemDefault()
    val pm = ctx.packageManager
    val today = java.time.LocalDate.now()
    return (days - 1 downTo 0).map { back ->
        val d = today.minusDays(back.toLong())
        val s = d.atStartOfDay(z).toInstant().toEpochMilli()
        val e = minOf(d.plusDays(1).atStartOfDay(z).toInstant().toEpochMilli(), System.currentTimeMillis())
        val sum = try {
            BlockStore.usageRange(ctx, s, e)
                .filter { it.key != ctx.packageName && pm.getLaunchIntentForPackage(it.key) != null }
                .values.sum()
        } catch (ex: Exception) {
            0L
        }
        d to sum
    }
}

@Composable
private fun GoalCard(todayMs: Long, week: List<Pair<java.time.LocalDate, Long>>) {
    val ctx = LocalContext.current
    val t = LocalDesign.current.tokens
    var goal by remember { mutableStateOf(BlockStore.goalMin(ctx)) }
    fun set(m: Int) { goal = m; BlockStore.setGoalMin(ctx, m) }
    ThemedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(stringResource(R.string.limit_daily), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            ThemedButton("−", { set((goal - 30).coerceAtLeast(0)) })
            // Hedef aşılınca "✖ kullanılan / hedef" biçimi; renk tek başına ipucu değil.
            val over = goal > 0 && com.odak.app.logic.Pure.limitReached(todayMs, goal)
            Text(
                if (goal == 0) stringResource(R.string.limit_none)
                else (if (over) "✖ " else "") + "${todayMs / 60_000} / " + stringResource(R.string.fmt_min, goal),
                Modifier.padding(horizontal = 8.dp),
                color = if (over) MaterialTheme.colorScheme.error else Color.Unspecified,
                style = MaterialTheme.typography.bodySmall
            )
            ThemedButton("+", { set((goal + 30).coerceAtMost(960)) })
        }
        if (goal > 0) {
            val frac = (todayMs / 60_000f / goal)
            Spacer(Modifier.height(8.dp))
            RoundedBar(frac, height = 10.dp, color = if (frac > 1f) Color(0xFFE53935) else null)
            // Seri: dünden geriye hedefin altında kalan ardışık gün (bugün sayılmaz).
            val streak = com.odak.app.logic.Pure.goalStreak(week.map { it.second }, goal * 60_000L)
            if (streak > 0) {
                Spacer(Modifier.height(6.dp))
                Text("🔥 $streak", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun catEmoji(c: Int): String = when (c) {
    android.content.pm.ApplicationInfo.CATEGORY_SOCIAL -> "💬"
    android.content.pm.ApplicationInfo.CATEGORY_GAME -> "🎮"
    android.content.pm.ApplicationInfo.CATEGORY_VIDEO -> "🎬"
    android.content.pm.ApplicationInfo.CATEGORY_AUDIO -> "🎵"
    android.content.pm.ApplicationInfo.CATEGORY_PRODUCTIVITY -> "💼"
    android.content.pm.ApplicationInfo.CATEGORY_NEWS -> "📰"
    android.content.pm.ApplicationInfo.CATEGORY_IMAGE -> "🖼"
    android.content.pm.ApplicationInfo.CATEGORY_MAPS -> "🗺"
    else -> "•"
}

@Composable
private fun DayNav(day: java.time.LocalDate, week: List<Pair<java.time.LocalDate, Long>>, onPick: (java.time.LocalDate) -> Unit) {
    val today = java.time.LocalDate.now()
    val first = week.firstOrNull()?.first ?: today
    ThemedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            com.odak.app.theme.QuietAction("◀", { if (day > first) onPick(day.minusDays(1)) })
            Text(
                if (day == today) "📅 " + java.time.format.DateTimeFormatter.ofPattern("d MMM").format(day)
                else java.time.format.DateTimeFormatter.ofPattern("d MMM, EEE").format(day),
                style = MaterialTheme.typography.titleMedium
            )
            com.odak.app.theme.QuietAction("▶", { if (day < today) onPick(day.plusDays(1)) })
        }
    }
}


@Composable
private fun SectionTitle(text: String) {
    val t = LocalDesign.current.tokens
    Text(text, style = MaterialTheme.typography.titleSmall, color = t.text)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun WeekChart(week: List<Pair<java.time.LocalDate, Long>>, sel: java.time.LocalDate, onPick: (java.time.LocalDate) -> Unit) {
    if (week.isEmpty()) return
    val last7 = week.takeLast(7)
    val prev = week.take(7).sumOf { it.second }
    val cur = last7.sumOf { it.second }
    val goal = BlockStore.goalMin(LocalContext.current)
    ThemedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            SectionTitle("📈 " + stringResource(R.string.st_week))
            com.odak.app.logic.Pure.pctChange(prev, cur)?.let { pct ->
                Text(
                    (if (pct > 0) "↑ " else "↓ ") + kotlin.math.abs(pct) + "%",
                    color = if (pct > 0) Color(0xFFE53935) else Color(0xFF43A047),
                    style = MaterialTheme.typography.titleSmall
                )
            }
        }
        BarPlot(
            values = last7.map { it.second },
            labels = last7.map { it.first.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.getDefault()).take(3) },
            highlight = last7.indexOfFirst { it.first == sel },
            height = 130.dp, goalMin = goal,
            valueOn = last7.indices.toSet(),
            onPick = { onPick(last7[it].first) }
        )
    }
}

@Composable
private fun HourChart(hours: LongArray) {
    if (hours.all { it == 0L }) return
    val peak = hours.indices.maxByOrNull { hours[it] } ?: 0
    ThemedCard(Modifier.fillMaxWidth()) {
        SectionTitle("⏰ " + "%02d:00".format(peak) + "  ·  " + fmt(hours[peak]))
        BarPlot(
            values = hours.toList(),
            labels = (0..23).map { if (it % 6 == 0 || it == 23) it.toString() else "" },
            highlight = peak, height = 90.dp, gap = 2.dp, valueOn = setOf(peak), nightFrom = 22
        )
    }
}

@Composable
private fun CategoryCard(rows: List<UsageRow>) {
    val groups = rows.groupBy { catEmoji(it.cat) }.mapValues { e -> e.value.sumOf { it.ms } }
        .entries.sortedByDescending { it.value }
    if (groups.size < 2) return
    val t = LocalDesign.current.tokens
    val top = groups.first().value.toFloat()
    ThemedCard(Modifier.fillMaxWidth()) {
        groups.forEach { (emoji, ms) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(emoji, Modifier.width(30.dp), style = MaterialTheme.typography.titleMedium)
                RoundedBar(ms / top, Modifier.weight(1f), 10.dp)
                Text(fmt(ms), Modifier.width(64.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End, color = t.text)
            }
        }
    }
}

@Composable
private fun Donut(rows: List<UsageRow>, total: Long) {
    val other = stringResource(R.string.st_other)
    val slices = com.odak.app.logic.Pure.topSlices(rows.map { it.label to it.ms }, 6)
    if (slices.isEmpty() || total <= 0) return
    ThemedCard(Modifier.fillMaxWidth()) {
        DonutChart(slices, fmt(total), "${rows.size} ✦", other)
    }
}

/** Uygulamanın son 7 günlük kullanımı. */
@Composable
private fun AppWeekBars(pkg: String) {
    val ctx = LocalContext.current
    var vals by remember(pkg) { mutableStateOf<List<Long>?>(null) }
    LaunchedEffect(pkg) {
        vals = withContext(Dispatchers.IO) {
            val z = java.time.ZoneId.systemDefault()
            val today = java.time.LocalDate.now()
            (6 downTo 0).map { back ->
                val d = today.minusDays(back.toLong())
                val s0 = d.atStartOfDay(z).toInstant().toEpochMilli()
                val e0 = minOf(d.plusDays(1).atStartOfDay(z).toInstant().toEpochMilli(), System.currentTimeMillis())
                try { BlockStore.usageRange(ctx, s0, e0)[pkg] ?: 0L } catch (e: Exception) { 0L }
            }
        }
    }
    val v = vals ?: return
    val today = java.time.LocalDate.now()
    Spacer(Modifier.height(10.dp))
    BarPlot(
        values = v,
        labels = v.indices.map { today.minusDays((6 - it).toLong()).dayOfWeek.getDisplayName(java.time.format.TextStyle.NARROW, java.util.Locale.getDefault()) },
        highlight = 6, height = 80.dp, valueOn = v.indices.toSet()
    )
}
