package com.odak.app.schedule

import android.app.TimePickerDialog
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedTextField
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

/** Program: gün seç, o günün saatli listesini gör; satır eklenince vakti gelince bildirim gelir (görev değil, düz liste). */
@Composable
fun ScheduleScreen() {
    val ctx = LocalContext.current
    var items by remember { mutableStateOf(ScheduleStore.load(ctx)) }
    var day by remember { mutableStateOf(LocalDate.now().dayOfWeek) }
    var editing by remember { mutableStateOf<SchedItem?>(null) }
    fun commit(l: List<SchedItem>) { ScheduleStore.save(ctx, l); items = l }
    val names = DayOfWeek.values().map { it.getDisplayName(TextStyle.SHORT, Locale.getDefault()) }

    val ed = editing
    if (ed != null) {
        Editor(ed, names, onCancel = { editing = null }, onDelete = { commit(items.filter { x -> x.id != ed.id }); editing = null }, onSave = { n ->
            val l = if (items.any { it.id == n.id }) items.map { if (it.id == n.id) n else it } else items + n
            commit(l); editing = null
            if (n.days and SchedulePure.bit(day) == 0) day = DayOfWeek.values().first { SchedulePure.runsOn(n, it) }
        })
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemedButton("＋ " + stringResource(R.string.plan_add), {
                editing = SchedItem(java.util.UUID.randomUUID().toString(), 9 * 60, SchedulePure.bit(day), true, "")
            })
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            DayOfWeek.values().forEachIndexed { i, d ->
                com.odak.app.theme.QuietAction((if (day == d) "✔ " else "") + names[i], { day = d })
            }
        }
        Spacer(Modifier.height(8.dp))
        val shown = SchedulePure.forDay(items, day)
        if (shown.isEmpty()) Text(stringResource(R.string.sched_empty), modifier = Modifier.padding(16.dp).alpha(0.7f))
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.id }) { it ->
                ThemedCard(Modifier.fillMaxWidth(), onClick = { editing = it }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(SchedulePure.fmt(it.min), style = MaterialTheme.typography.titleMedium, modifier = Modifier.width(64.dp).alpha(if (it.on) 1f else 0.5f))
                        Column(Modifier.weight(1f)) {
                            Text(it.text, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.alpha(if (it.on) 1f else 0.5f))
                            Text(SchedulePure.daysLabel(it.days, names, stringResource(R.string.sched_every_day)), style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.7f))
                        }
                        com.odak.app.theme.QuietAction(if (it.on) "🔔" else "🔕", { commit(items.map { x -> if (x.id == it.id) x.copy(on = !x.on) else x }) })
                    }
                }
            }
        }
    }
}

@Composable
private fun Editor(start: SchedItem, names: List<String>, onCancel: () -> Unit, onDelete: () -> Unit, onSave: (SchedItem) -> Unit) {
    val ctx = LocalContext.current
    var min by remember { mutableIntStateOf(start.min) }
    var text by remember { mutableStateOf(start.text) }
    var days by remember { mutableIntStateOf(start.days) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onCancel,
        confirmButton = {
            ThemedButton("✔ " + stringResource(R.string.plan_add), {
                val t = SchedulePure.clean(text)
                if (t.isNotEmpty() && days != 0) onSave(start.copy(min = min, text = t, days = days, on = true))
            })
        },
        dismissButton = {
            com.odak.app.theme.QuietAction("✕", onCancel)
        },
        text = {
            Column {
                ThemedButton("⏰ " + SchedulePure.fmt(min), {
                    TimePickerDialog(ctx, { _, h, m -> min = h * 60 + m }, min / 60, min % 60, true).show()
                })
                Spacer(Modifier.height(8.dp))
                ThemedTextField(text, { text = it.take(SchedulePure.MAX_TEXT) }, stringResource(R.string.sched_text), Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DayOfWeek.values().forEachIndexed { i, d ->
                        com.odak.app.theme.QuietAction((if (days and SchedulePure.bit(d) != 0) "✔ " else "") + names[i], { days = SchedulePure.toggleDay(days, d) })
                    }
                }
                if (start.text.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    ThemedButton("🗑", onDelete, Modifier.fillMaxWidth())
                }
            }
        }
    )
}
