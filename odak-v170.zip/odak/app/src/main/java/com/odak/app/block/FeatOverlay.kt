package com.odak.app.block

import android.content.Context
import android.content.Intent

/**
 * Özellik engelinde (ör. DM) hedef uygulamayı kapatmadan üstte açılan uyarı. Uyarı, seçili tasarım stilinin
 * kendi kart ve düğmeleriyle çizilen saydam bir ekrandır ([FeatWarnActivity]); uygulama arkada açık kalır.
 */
object FeatOverlay {
    fun showing() = FeatWarnActivity.open

    /** Uyarıyı açar; zaten açıksa true döner. Açılamazsa false (çağıran Toast'a düşer). */
    fun show(c: Context, feature: String, app: String, limit: Boolean): Boolean {
        if (showing()) return true
        return try {
            com.odak.app.Launch.go(
                c,
                Intent(c, FeatWarnActivity::class.java)
                    .putExtra("feature", feature).putExtra("app", app).putExtra("limit", limit)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            )
        } catch (e: Exception) { false }
    }
}
