package com.odak.app.logic

import org.apache.commons.math3.stat.inference.TTest
import org.apache.commons.math3.stat.interval.WilsonScoreInterval
import kotlin.math.abs

/**
 * Eğitim eleştirmeni (saf mantık). Apache Commons Math (yaygın kullanılan, açık kaynak istatistik kütüphanesi) ile:
 * Wilson güven aralığı, eşleştirilmiş t-testi (motorlar anlamlı biçimde farklı mı?). Ayrıca AUC, şüpheli etiket ve çelişen örnek denetimi.
 */
object CriticPure {
    const val MIN_EXAMPLES = 40

    class Report(
        val n: Int, val auc: Int, val acc: Int, val accLo: Int, val accHi: Int,
        val suspicious: List<String>, val conflicts: Int,
        /** Gelişmiş motor ile yerleşik motor arasındaki p değeri (null: hesaplanamadı). */
        val p: Double?, val advBetter: Boolean
    )

    /** ROC eğrisi altındaki alan (%): rastgele bir olumlu örneğin rastgele bir olumsuzdan yüksek puan alma olasılığı. */
    fun auc(w: DoubleArray, ex: List<LearnPure.Ex>): Int {
        val pos = ex.filter { it.label }.map { LearnPure.predict(w, it) }; val neg = ex.filter { !it.label }.map { LearnPure.predict(w, it) }
        if (pos.isEmpty() || neg.isEmpty()) return 0
        var s = 0.0
        for (a in pos) for (b in neg) s += if (a > b) 1.0 else if (a == b) 0.5 else 0.0
        return (s / (pos.size.toDouble() * neg.size) * 100).toInt()
    }

    /** Modelin etiketle güçle çeliştiği örnekler (olası yanlış tıklama): |p − etiket| ≥ [gap], en çelişenden başlayarak. */
    fun suspicious(w: DoubleArray, ex: List<LearnPure.Ex>, gap: Double = 0.85, max: Int = 3): List<String> =
        ex.map { it to abs(LearnPure.predict(w, it) - (if (it.label) 1.0 else 0.0)) }
            .filter { it.second >= gap }.sortedByDescending { it.second }.map { it.first.entry }.distinct().take(max)

    /** Aynı girdi hem olumlu hem olumsuz etiketlenmiş mi? Kaç farklı girdi. */
    fun conflicts(ex: List<LearnPure.Ex>): Int =
        ex.groupBy { it.entry }.count { (_, v) -> v.any { it.label } && v.any { !it.label } }

    /** Wilson %95 güven aralığı (%): [successes]/[n] için. */
    fun interval(n: Int, successes: Int): Pair<Int, Int> {
        if (n <= 0) return 0 to 0
        val ci = WilsonScoreInterval().createInterval(n, successes.coerceIn(0, n), 0.95)
        return (ci.lowerBound * 100).toInt() to (ci.upperBound * 100 + 0.999).toInt().coerceAtMost(100)
    }

    /** Eşleştirilmiş t-testi p değeri; farklar sabitse veya <2 kat varsa null. */
    fun pairedP(a: DoubleArray, b: DoubleArray): Double? {
        if (a.size < 2 || a.size != b.size) return null
        val d = DoubleArray(a.size) { a[it] - b[it] }
        if (d.all { it == d[0] }) return if (d[0] == 0.0) 1.0 else null
        return try { TTest().pairedTTest(a, b).takeIf { !it.isNaN() } } catch (e: Exception) { null }
    }

    /** Kat başına F1 (0..1): [trainer] her katın eğitim kümesinden ağırlık üretir. */
    fun foldScores(ex: List<LearnPure.Ex>, k: Int, trainer: (List<LearnPure.Ex>) -> DoubleArray): DoubleArray =
        DoubleArray(k) { f ->
            val va = ex.filterIndexed { i, _ -> i % k == f }; val tr = ex.filterIndexed { i, _ -> i % k != f }
            LearnPure.metrics(trainer(tr), va).f1 / 100.0
        }

    fun review(ex: List<LearnPure.Ex>, k: Int = 5): Report? {
        if (ex.size < MIN_EXAMPLES || ex.none { it.label } || ex.all { it.label }) return null
        val w = LearnPure.fit(ex, 80).w
        val acc = LearnPure.metrics(w, ex).acc
        val ci = interval(ex.size, ex.size * acc / 100)
        val a = foldScores(ex, k) { LearnPure.train(it, 30) }
        val b = foldScores(ex, k) { LearnPlus.trainAdam(LearnPlus.weighted(it), 30) }
        val p = pairedP(b, a)
        val better = p != null && p < 0.05 && b.average() > a.average()
        return Report(ex.size, auc(w, ex), acc, ci.first, ci.second, suspicious(w, ex), conflicts(ex), p, better)
    }

    fun fmtP(p: Double?): String = if (p == null) "–" else if (p < 0.001) "<0.001" else String.format(java.util.Locale.US, "%.3f", p)
}
