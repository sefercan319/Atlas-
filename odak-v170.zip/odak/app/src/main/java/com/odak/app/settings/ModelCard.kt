package com.odak.app.settings

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.view.WindowManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.block.LearnStore
import com.odak.app.block.ModelDownloader
import com.odak.app.logic.LearnPure
import com.odak.app.logic.ModelPure
import com.odak.app.theme.Text
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.ThemedTextField

/** Ekranı açık tutma: ayar açıkken uygulama ön plandayken ekran kapanmaz. İzin gerekmez. */
object KeepAwake {
    private fun p(c: android.content.Context) = c.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE)
    fun on(c: android.content.Context) = p(c).getBoolean("keep_awake", false)
    fun set(c: android.content.Context, v: Boolean) = p(c).edit().putBoolean("keep_awake", v).apply()
    fun apply(a: Activity) {
        if (on(a) || ModelDownloader.state == ModelDownloader.RUNNING) a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else a.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}

/** Yapay zekâ modeli indirme + cihazda kural öğrenici eğitimi + ekranı açık tutma. */
@Composable
fun ModelCard() {
    val ctx = LocalContext.current
    var url by remember { mutableStateOf(ModelDownloader.url(ctx)) }
    var token by remember { mutableStateOf(ModelDownloader.token(ctx)) }
    var keep by remember { mutableStateOf(KeepAwake.on(ctx)) }
    var auto by remember { mutableStateOf(LearnStore.auto(ctx)) }
    var n by remember { mutableIntStateOf(LearnStore.count(ctx)) }
    var res by remember { mutableStateOf<Triple<Int, Int, Int>?>(null) }
    var bg by remember { mutableStateOf(LearnStore.bg(ctx)) }
    var scope by remember { mutableIntStateOf(LearnStore.scope(ctx)) }
    var rot by remember { mutableStateOf(LearnStore.rotate(ctx)) }
    var confirmFresh by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var engine by remember { mutableIntStateOf(LearnStore.engine(ctx)) }
    var tools by remember { mutableStateOf(if (LearnStore.rolledBack(ctx)) "" else "") }
    var critic by remember { mutableStateOf("") }
    var tryMsg by remember { mutableStateOf("") }
    val okFmt = stringResource(R.string.ai_try_ok, "{0}")
    val failFmt = stringResource(R.string.ai_try_fail, "{0}")
    LaunchedEffect(Unit) {
        while (true) {
            tick++; n = LearnStore.count(ctx)
            (ctx as? Activity)?.let { KeepAwake.apply(it) }
            kotlinx.coroutines.delay(700)
        }
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.ai_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(stringResource(R.string.ai_keep), Modifier.weight(1f))
            ThemedCheck(keep) { keep = it; KeepAwake.set(ctx, it); (ctx as? Activity)?.let { a -> KeepAwake.apply(a) } }
        }
        Text(stringResource(R.string.ai_keep_hint), style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.7f))

        Spacer(Modifier.height(14.dp))
        ThemedButton("🌐 " + stringResource(R.string.ai_page), {
            com.odak.app.Launch.go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(ModelPure.PAGE)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        Spacer(Modifier.height(6.dp))
        ThemedTextField(url, { url = it.take(2000); ModelDownloader.setUrl(ctx, url) }, stringResource(R.string.ai_url), Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        ThemedTextField(token, { token = it.take(200); ModelDownloader.setToken(ctx, token) }, stringResource(R.string.ai_token), Modifier.fillMaxWidth(), secret = true, textPassword = true)
        Spacer(Modifier.height(6.dp))
        androidx.compose.runtime.key(tick) {
            val st = ModelDownloader.state
            val ready = ModelDownloader.ready(ctx)
            if (st == ModelDownloader.RUNNING) {
                Text(stringResource(R.string.ai_dl_state, ModelPure.fmtSize(ModelDownloader.done), if (ModelDownloader.total > 0) ModelPure.fmtSize(ModelDownloader.total) else "?") + "  %" + ModelPure.percent(ModelDownloader.done, ModelDownloader.total))
                ThemedButton(stringResource(R.string.ai_dl_stop), { ModelDownloader.stop() })
            } else {
                if (st == ModelDownloader.FAIL) Text("✖ " + stringResource(R.string.ai_dl_fail))
                if (ready != null) {
                    Text("✔ " + stringResource(R.string.ai_dl_done, ready.name + " · " + ModelPure.fmtSize(ready.length())))
                    ThemedButton("🧪 " + stringResource(R.string.ai_try), {
                        tryMsg = "…"
                        Thread {
                            val r = com.odak.app.block.ModelRunner.ask(ctx, ModelPure.probePrompt("DM", "Instagram", listOf("direct_tab", "reels_tab", "row_inbox_container")))
                            tryMsg = r.fold({ okFmt.replace("{0}", it.take(200)) }, { failFmt.replace("{0}", it.message ?: "") })
                        }.start()
                    })
                    if (tryMsg.isNotEmpty()) Text(tryMsg, style = MaterialTheme.typography.bodySmall)
                    ThemedButton(stringResource(R.string.ai_dl_del), { ModelDownloader.delete(ctx); tick++ })
                } else {
                    ThemedButton("⬇ " + stringResource(R.string.ai_dl), {
                        ModelDownloader.start(ctx); (ctx as? Activity)?.let { KeepAwake.apply(it) }
                    })
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        Text(stringResource(R.string.ai_learn), style = MaterialTheme.typography.titleSmall)
        Text(stringResource(R.string.ai_learn_n, n))
        res?.let { Text("✔ " + stringResource(R.string.ai_trained2, it.first, it.second, it.third)) }
        if (LearnStore.lastF1(ctx) >= 0) Text(
            stringResource(R.string.ai_quality, LearnStore.lastF1(ctx), LearnStore.lastCv(ctx).coerceAtLeast(0), (LearnStore.threshold(ctx) * 100).toInt()),
            style = MaterialTheme.typography.bodySmall
        )
        if (res == null && LearnStore.lastVal(ctx) >= 0) Text(stringResource(R.string.ai_val, LearnStore.lastVal(ctx)), style = MaterialTheme.typography.bodySmall)
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(stringResource(R.string.ai_auto), Modifier.weight(1f))
            ThemedCheck(auto) { auto = it; LearnStore.setAuto(ctx, it) }
        }
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(stringResource(R.string.ai_bg), Modifier.weight(1f))
            ThemedCheck(bg) { bg = it; LearnStore.setBg(ctx, it); com.odak.app.block.LearnJobService.sync(ctx) }
        }
        Text(stringResource(R.string.ai_bg_hint), style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.7f))
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.ai_engine), style = MaterialTheme.typography.labelLarge)
        androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(LearnPure.ENG_BUILTIN to R.string.ai_eng_builtin, LearnPure.ENG_SMILE to R.string.ai_eng_smile, LearnPure.ENG_BOTH to R.string.ai_eng_both, LearnPure.ENG_ADV to R.string.ai_eng_adv, LearnPure.ENG_ONNX to R.string.ai_eng_onnx).forEach { (id, res) ->
                com.odak.app.theme.QuietAction((if (engine == id) "✔ " else "") + stringResource(res), { engine = id; LearnStore.setEngine(ctx, id) })
            }
        }
        if (engine == LearnPure.ENG_ONNX) Text(stringResource(if (com.odak.app.block.ExtScorer.available(ctx)) R.string.ai_onnx_hint else R.string.ai_onnx_hint), style = MaterialTheme.typography.bodySmall)
        if (engine == LearnPure.ENG_ONNX && com.odak.app.block.ExtScorer.kind(ctx) == "tflite") ThemedButton("🧠 " + stringResource(R.string.ai_tf_btn), {
            tools = "…"
            Thread {
                val r = com.odak.app.block.TfliteRunner.train(ctx, LearnStore.examples(ctx), 5)
                tools = if (r == null) ctx.getString(R.string.ai_tf_fail) else ctx.getString(R.string.ai_tf_ok, r.first, String.format(java.util.Locale.US, "%.4f", r.second))
            }.start()
        })
        ThemedButton("🔍 " + stringResource(R.string.ai_crit), {
            critic = "…"
            Thread {
                val r = com.odak.app.logic.CriticPure.review(LearnStore.examples(ctx))
                critic = if (r == null) ctx.getString(R.string.ai_crit_few) else buildString {
                    append(ctx.getString(R.string.ai_crit_sum, r.auc, r.acc, r.accLo, r.accHi, r.suspicious.size, r.conflicts))
                    append("\n").append(ctx.getString(if (r.advBetter) R.string.ai_crit_better else R.string.ai_crit_same, com.odak.app.logic.CriticPure.fmtP(r.p)))
                    if (r.suspicious.isNotEmpty()) append("\n").append(ctx.getString(R.string.ai_crit_susp, r.suspicious.joinToString(", ")))
                }
            }.start()
        })
        if (critic.isNotEmpty()) Text(critic, style = MaterialTheme.typography.bodySmall)
        androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ThemedButton("⚙ " + stringResource(R.string.ai_tune), {
                tools = "…"
                Thread {
                    val t = LearnStore.autoTune(ctx)
                    tools = if (t == null) ctx.getString(R.string.ai_crit_few) else ctx.getString(R.string.ai_tune_res, t.best.lr.toString(), t.best.l2.toString(), t.f1, t.tried)
                }.start()
            })
            ThemedButton("📈 " + stringResource(R.string.ai_curve), {
                tools = "…"
                Thread {
                    val cv = LearnStore.curve(ctx)
                    tools = if (cv == null) ctx.getString(R.string.ai_curve_few) else ctx.getString(R.string.ai_curve_res, cv.joinToString(" · ")) + "\n" +
                        ctx.getString(if (com.odak.app.logic.LearnTune.verdict(cv) == 1) R.string.ai_curve_more else R.string.ai_curve_sat)
                }.start()
            })
            ThemedButton("↩ " + stringResource(R.string.ai_undo), {
                tools = ctx.getString(if (LearnStore.rollback(ctx)) R.string.ai_undo_ok else R.string.ai_undo_none)
            })
        }
        if (LearnStore.rolledBack(ctx)) Text(stringResource(R.string.ai_rolled), style = MaterialTheme.typography.bodySmall)
        if (tools.isNotEmpty()) Text(tools, style = MaterialTheme.typography.bodySmall)
        Text(stringResource(R.string.ai_scope), style = MaterialTheme.typography.labelLarge)
        androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ModelPure.SCOPES.forEach { p ->
                com.odak.app.theme.QuietAction((if (scope == p) "✔ " else "") + "%" + p, { scope = p; LearnStore.setScope(ctx, p) })
            }
        }
        Text(stringResource(R.string.ai_params, LearnPure.trainable(LearnPure.mask(scope, 0)), LearnPure.DIM), style = MaterialTheme.typography.bodySmall)
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(stringResource(R.string.ai_rotate), Modifier.weight(1f))
            ThemedCheck(rot) { rot = it; LearnStore.setRotate(ctx, it) }
        }
        // Büyük model için ne yapılabilir: seçilen orana göre bellek ihtiyacı ve bu telefonun RAM'i
        val ram = remember {
            val mi = android.app.ActivityManager.MemoryInfo()
            (ctx.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi); mi.totalMem
        }
        val need = ModelPure.trainMemBytes(ModelPure.MODEL_PARAMS, scope)
        Text(
            stringResource(R.string.ai_est, "270M", scope, ModelPure.fmtSize(need)) + " · " +
                stringResource(if (ModelPure.feasibleOnPhone(ModelPure.MODEL_PARAMS, scope, ram)) R.string.ai_est_ok else R.string.ai_est_no, ModelPure.maxFeasiblePct(ModelPure.MODEL_PARAMS, ram)),
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.8f)
        )
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemedButton(stringResource(R.string.ai_train), {
                if (!busy) {
                    busy = true
                    Thread { val r = LearnStore.train(ctx, 80); res = r; busy = false }.start()
                }
            })
            ThemedButton(if (confirmFresh) "⚠ " + stringResource(R.string.ai_fresh_confirm) else stringResource(R.string.ai_fresh), {
                if (!confirmFresh) confirmFresh = true
                else if (!busy) {
                    confirmFresh = false; busy = true
                    Thread { val r = LearnStore.train(ctx, 80, fresh = true); res = r; busy = false }.start()
                }
            })
            if (n > 0) ThemedButton(stringResource(R.string.ai_export), {
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, LearnStore.export(ctx))
                com.odak.app.Launch.go(ctx, Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
        }
        Text(stringResource(R.string.ai_note), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 10.dp).alpha(0.7f))
    }
}
