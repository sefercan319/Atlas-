package com.odak.app.logic

import java.util.Locale

/**
 * Android / Compose'a bağlı olmayan saf mantık. Birim testlerle doğrulanır
 * (app/src/test). Yeni mantık eklerken önce buraya koyup test yaz.
 */
object Pure {
    /** Ekran anlık görüntüsü: görünüm kimlikleri, içerik açıklamaları (desc) ve metinler (text), küçük harf. */
    class Snap(val ids: Set<String>, val descs: Set<String> = emptySet(), val texts: Set<String> = emptySet(), val sel: Set<String> = emptySet())

    private fun hit(snap: Snap, e: String): Boolean = when {
        e.startsWith("desc:") -> e.length > 5 && snap.descs.any { it.contains(e.substring(5).lowercase(Locale.ROOT)) }
        e.startsWith("text:") -> e.length > 5 && snap.texts.any { it.contains(e.substring(5).lowercase(Locale.ROOT)) }
        e.startsWith("sel:") -> e.length > 4 && snap.sel.any { it.contains(e.substring(4).lowercase(Locale.ROOT)) }
        else -> e.isNotEmpty() && snap.ids.any { it.contains(e) }
    }

    /** Kural girdileri: düz = kimlik alt dizgisi, "desc:" / "text:" = açıklama / metin, "sel:" = SEÇİLİ sekme/öğenin etiketi (alt çubukta o an açık sekme). "!app/özellik" istisnadır. */
    fun matches(snap: Snap, rules: Map<String, List<String>>, app: String, feat: String): Boolean {
        val pos = rules["$app/$feat"] ?: return false
        if (pos.none { hit(snap, it) }) return false
        val neg = rules["!$app/$feat"] ?: return true
        return neg.none { hit(snap, it) }
    }

    fun matches(seen: Set<String>, rules: Map<String, List<String>>, app: String, feat: String): Boolean =
        matches(Snap(seen), rules, app, feat)

    /**
     * Kural türetme: olumlu kayıtta tarama sayısının en az yarısında görülen, olumsuz kayıtta
     * (alt dizgi olarak bile) bulunmayan kimlikler; sık görülenden başlayarak en çok [max] tane.
     */
    fun derive(posCount: Map<String, Int>, posScans: Int, neg: Set<String>, max: Int = 4): List<String> {
        if (posScans <= 0) return emptyList()
        return posCount.entries
            .filter { it.value * 2 >= posScans && it.key.length >= 4 && neg.none { n -> n.isNotEmpty() && (n.contains(it.key) || it.key.contains(n)) } }
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(max).map { it.key }
    }

    /**
     * Seçili sekme etiketlerinden kural: olumlu kayıtta tarama sayısının en az yarısında seçili görülen,
     * olumsuz kayıtta hiç seçili görülmeyen etiketler ("sel:etiket"); en çok [max] tane.
     */
    fun deriveSel(posCount: Map<String, Int>, posScans: Int, neg: Set<String>, max: Int = 2): List<String> {
        if (posScans <= 0) return emptyList()
        return posCount.entries
            .filter { it.value * 2 >= posScans && it.key.length in 3..30 && neg.none { n -> n == it.key || n.contains(it.key) || it.key.contains(n) } }
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(max).map { "sel:" + it.key }
    }

    /**
     * Açıklama / metin kuralları ("desc:" / "text:"): olumlu kayıtta tarama sayısının en az yarısında görülen,
     * olumsuz kayıtta bulunmayan, kısa ve sayı olmayan etiketler; en çok [max] tane.
     */
    fun deriveWords(prefix: String, posCount: Map<String, Int>, posScans: Int, neg: Set<String>, max: Int = 2): List<String> {
        if (posScans <= 0) return emptyList()
        return posCount.entries
            .filter {
                it.value * 2 >= posScans && it.key.length in 3..40 && it.key.any { c -> c.isLetter() } &&
                    neg.none { n -> n == it.key || n.contains(it.key) || it.key.contains(n) }
            }
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(max).map { prefix + it.key }
    }

    /** Pasta dilimleri: en büyük n-1 ve kalanı "other" olarak toplanır (anahtar boş). */
    fun topSlices(values: List<Pair<String, Long>>, n: Int): List<Pair<String, Long>> {
        val s = values.filter { it.second > 0 }.sortedByDescending { it.second }
        if (s.size <= n) return s
        val head = s.take(n - 1)
        return head + ("" to s.drop(n - 1).sumOf { it.second })
    }

    /** Önceki döneme göre yüzde değişim; önceki yoksa null. */
    fun pctChange(prev: Long, cur: Long): Int? = if (prev <= 0) null else ((cur - prev) * 100 / prev).toInt()

    /** Sessiz saat: dakika cinsinden; gece yarısını aşan aralık desteklenir, from == to kapalıdır. */
    fun inQuiet(nowMin: Int, from: Int, to: Int): Boolean =
        if (from == to) false else if (from < to) nowMin in from until to else nowMin >= from || nowMin < to

    /** Odak modu süresini uzatır: bitmişse şimdiden, sürüyorsa mevcut bitişten ekler. */
    const val FOCUS_EXTEND_MIN = 10

    /** Uygulama listesi sayfa boyutu: liste 15'er uygulamayla açılır. */
    const val APP_PAGE = 15

    /** "Daha fazla" sonrası görünen sayı: bir sayfa artar, toplamı aşmaz. */
    fun appsNextShown(shown: Int, total: Int): Int = minOf(maxOf(total, 0), maxOf(shown, 0) + APP_PAGE)

    /** "Daha az": bir sayfa geri; tamamı açıksa ilk sayfaya döner. */
    fun appsLessShown(shown: Int, total: Int): Int =
        if (shown >= total) APP_PAGE else maxOf(APP_PAGE, shown - APP_PAGE)

    /** Listede görünen sayı (toplamı aşmaz). */
    fun appsVisible(shown: Int, total: Int): Int = minOf(maxOf(shown, 0), maxOf(total, 0))

    /** Henüz gösterilmeyen uygulama sayısı. */
    fun appsRemaining(shown: Int, total: Int): Int = maxOf(0, total - maxOf(shown, 0))
    fun focusExtend(until: Long, now: Long, addMin: Int): Long = maxOf(until, now) + addMin * 60_000L

    fun fmtTime(min: Int): String = String.format(Locale.ROOT, "%02d:%02d", min / 60, min % 60)

    fun parseTime(s: String): Int? {
        val m = Regex("""^\s*(\d{1,2})[:.](\d{2})\s*$""").matchEntire(s) ?: return null
        val h = m.groupValues[1].toInt()
        val mm = m.groupValues[2].toInt()
        return if (h in 0..23 && mm in 0..59) h * 60 + mm else null
    }

    /** Başlığın başındaki eski emoji etiketini çıkarıp yenisini koyar. */
    fun tagged(title: String, e: String, all: List<String>): String {
        var t = title.trimStart()
        for (x in all) if (t.startsWith(x)) t = t.removePrefix(x).trimStart()
        return "$e $t"
    }

    /** Bugünden (yapılmadıysa dünden) geriye ardışık gün sayısı. Günler "yyyy-MM-dd". */
    fun streak(days: Set<String>, today: java.time.LocalDate): Int {
        var d = if (today.toString() in days) today else today.minusDays(1)
        var n = 0
        while (d.toString() in days) { n++; d = d.minusDays(1) }
        return n
    }

    /** Günlük kullanım süresi uyarı eşiği aşıldı mı ama limit dolmadı mı? */
    fun inWarnWindow(usedMs: Long, limitMin: Int, pct: Int): Boolean {
        val lim = limitMin * 60_000L
        return limitMin > 0 && usedMs >= lim * pct / 100 && usedMs < lim
    }

    /** Gün değişince, "bugün"ü izleyen seçim yeni güne geçer; geçmiş bir gün seçiliyse yerinde kalır. */
    fun followToday(selected: java.time.LocalDate, prevToday: java.time.LocalDate, nowToday: java.time.LocalDate): java.time.LocalDate =
        if (selected == prevToday) nowToday else selected

    /** Açma sayacı: kullanıcı en az [gapMs] uzaklaştıysa yeni açılıştır. */
    fun isFreshOpen(lastSeen: Long, now: Long, gapMs: Long = 30_000L): Boolean = lastSeen <= 0L || now - lastSeen > gapMs
    /** Sınır aşılınca sayaç daha fazla artmaz (limit+1'de durur), böylece "6/5" büyümez. */
    fun nextOpens(opens: Int, limit: Int): Int = if (limit > 0 && opens > limit) opens else opens + 1
    /** limit kez açmaya izin var; limit+1. açılış engellenir. */
    fun openLimitHit(opens: Int, limit: Int): Boolean = limit > 0 && opens > limit

    fun limitReached(usedMs: Long, limitMin: Int): Boolean = limitMin > 0 && usedMs >= limitMin * 60_000L

    private val dayKey = Regex("""^(?:fu|warn|limnote|passn|bc):(\d{4}-\d{2}-\d{2})(?::|$)""")

    /** Günlük sayaç anahtarı (fu/warn/limnote/passn:yyyy-MM-dd[:...]) [keepDays] günden eskiyse true. */
    fun staleDayKey(key: String, today: java.time.LocalDate, keepDays: Int = 14): Boolean {
        val d = dayKey.find(key)?.groupValues?.get(1) ?: return false
        val date = try { java.time.LocalDate.parse(d) } catch (e: Exception) { return true }
        return date.isBefore(today.minusDays(keepDays.toLong()))
    }

    /** Uygulama adı aramayla eşleşiyor mu (boş arama hepsini getirir, büyük/küçük harf duyarsız). */
    /**
     * Arama için sadeleştirme: küçük harf, Türkçe i/ı ve aksan farkı yok sayılır ("ışık" ≈ "isik").
     * Türkçe büyük İ, Unicode'da "i + birleşik nokta" olarak gelir; önce o nokta silinir.
     */
    fun foldForSearch(s: String): String {
        val map = mapOf('ı' to 'i', 'ş' to 's', 'ğ' to 'g', 'ü' to 'u', 'ö' to 'o', 'ç' to 'c', 'â' to 'a', 'î' to 'i', 'û' to 'u')
        return s.lowercase(Locale.ROOT).replace("\u0307", "").map { map[it] ?: it }.joinToString("")
    }

    /** Ad veya paket adında (ör. "com.whatsapp") sorgu geçiyor mu. Boş sorgu her şeyi kabul eder. */
    fun nameMatches(name: String, query: String, pkg: String = ""): Boolean {
        val q = foldForSearch(query.trim())
        return q.isEmpty() || foldForSearch(name).contains(q) || (pkg.isNotEmpty() && foldForSearch(pkg).contains(q))
    }

    // ---------- Ekran süresi ----------
    /** Gece (00:00–04:59) kullanımı, ms. */
    fun nightMs(hourMs: LongArray): Long = (0..4).sumOf { hourMs.getOrElse(it) { 0L } }

    /** Kilit açma başına ortalama kullanım (ms); açma yoksa 0. */
    fun perUnlockMs(totalMs: Long, unlocks: Int): Long = if (unlocks <= 0) 0L else totalMs / unlocks

    /** Değerleri en büyüğe göre 0..1 aralığına getirir (çubuk yükseklikleri). */
    fun barFractions(values: List<Long>): List<Float> {
        val max = values.maxOrNull()?.takeIf { it > 0 } ?: return values.map { 0f }
        return values.map { it.toFloat() / max }
    }

    fun pct(done: Int, total: Int): Int = if (total <= 0) 0 else done * 100 / total

    // ---------- Yapılacaklar ----------
    class SortKey(val done: Boolean, val due: String?, val prio: Int, val title: String)

    /** mode 0 = tarih+öncelik, 1 = öncelik, 2 = A-Z, 3 = tarih. Yapılanlar hep sonda. Sıralı indeksleri döndürür. */
    fun todoOrder(items: List<SortKey>, mode: Int): List<Int> {
        val cmp: Comparator<Int> = when (mode) {
            1 -> compareBy<Int> { items[it].done }.thenByDescending { items[it].prio }.thenBy { items[it].due ?: "9999" }
            2 -> compareBy<Int> { items[it].done }.thenBy { items[it].title.lowercase(Locale.ROOT) }
            3 -> compareBy<Int> { items[it].done }.thenBy { items[it].due ?: "9999" }.thenBy { items[it].title.lowercase(Locale.ROOT) }
            else -> compareBy<Int> { items[it].done }.thenBy { items[it].due ?: "9999" }.thenByDescending { items[it].prio }
        }
        return items.indices.sortedWith(cmp)
    }

    fun isOverdue(due: String?, done: Boolean, today: java.time.LocalDate): Boolean =
        !done && due != null && due < today.toString()

    /** Gecikmiş ve yapılmamışsa bugüne taşınmış tarih; aksi halde aynısı. */
    fun moveOverdue(due: String?, done: Boolean, today: java.time.LocalDate): String? =
        if (isOverdue(due, done, today)) today.toString() else due

    private val quickWords = mapOf(
        "bugün" to 0, "bugun" to 0, "today" to 0, "heute" to 0, "aujourd'hui" to 0, "hoy" to 0,
        "yarın" to 1, "yarin" to 1, "tomorrow" to 1, "morgen" to 1, "demain" to 1, "mañana" to 1
    )

    /** Başta/sonda "bugün/yarın" kelimesini ayıklar: (temiz başlık, gün farkı) ya da (aynı başlık, null). */
    fun parseQuickDue(text: String): Pair<String, Int?> {
        val t = text.trim()
        val parts = t.split(Regex("\\s+"))
        if (parts.size < 2) return t to null
        quickWords[parts.first().lowercase(Locale.ROOT)]?.let { return parts.drop(1).joinToString(" ") to it }
        quickWords[parts.last().lowercase(Locale.ROOT)]?.let { return parts.dropLast(1).joinToString(" ") to it }
        return t to null
    }

    /**
     * Günlük hedefin altında kalan ardışık gün sayısı. [dayTotalsMs] eskiden yeniye sıralıdır ve son
     * eleman bugündür; bugün henüz bitmediği için sayıma girmez. Hedef 0 veya kısıtsızsa seri 0'dır.
     * Eşitlik hedefin altında sayılır; ilk aşan gün seriyi keser.
     */
    fun goalStreak(dayTotalsMs: List<Long>, goalMs: Long): Int {
        if (goalMs <= 0L || dayTotalsMs.size < 2) return 0
        var n = 0
        for (i in dayTotalsMs.size - 2 downTo 0) {
            if (dayTotalsMs[i] > goalMs) break
            n++
        }
        return n
    }

    // ---------- Alışkanlık / su ----------
    /** Son 7 günde (bugün dahil) yapılan günlerin yüzdesi. */
    fun weekRate(days: Set<String>, today: java.time.LocalDate): Int =
        (0..6).count { today.minusDays(it.toLong()).toString() in days } * 100 / 7

    /** Tüm zamanların en uzun ardışık gün serisi. */
    fun bestStreak(days: Set<String>): Int {
        val ds = days.mapNotNull { try { java.time.LocalDate.parse(it) } catch (e: Exception) { null } }.distinct().sorted()
        var best = 0
        var run = 0
        var prev: java.time.LocalDate? = null
        for (d in ds) {
            run = if (prev != null && prev.plusDays(1) == d) run + 1 else 1
            if (run > best) best = run
            prev = d
        }
        return best
    }

    fun waterFraction(glasses: Int, goal: Int): Float = if (goal <= 0) 0f else (glasses.toFloat() / goal).coerceIn(0f, 1f)

    // ---------- Plan ----------
    /** İki etkinlik (başlangıç dk, süre dk) çakışıyor mu? Saatsiz (start < 0) olanlar çakışmaz. */
    fun overlaps(aStart: Int, aDur: Int, bStart: Int, bDur: Int): Boolean =
        aStart >= 0 && bStart >= 0 && aStart < bStart + bDur && bStart < aStart + aDur

    /** Başka bir etkinlikle çakışanların indeksleri. */
    fun conflictIndexes(slots: List<Pair<Int, Int>>): Set<Int> {
        val out = HashSet<Int>()
        for (i in slots.indices) for (j in i + 1 until slots.size)
            if (overlaps(slots[i].first, slots[i].second, slots[j].first, slots[j].second)) { out.add(i); out.add(j) }
        return out
    }

    /** [from, to) içinde en az [minLen] dk süren ilk boş aralığın başlangıcı; yoksa null. */
    fun freeSlot(busy: List<Pair<Int, Int>>, from: Int, to: Int, minLen: Int): Int? {
        var t = from
        for ((s, d) in busy.filter { it.first >= 0 }.sortedBy { it.first }) {
            if (s - t >= minLen && t + minLen <= to) return t
            if (s + d > t) t = s + d
        }
        return if (to - t >= minLen) t else null
    }

    fun totalPlanned(durs: List<Int>): Int = durs.filter { it > 0 }.sum()

    /** "1s 30dk" biçimi. */
    fun fmtDur(min: Int): String = if (min >= 60) "${min / 60}h ${"%02d".format(min % 60)}m" else "${min}m"

    // ---------- Özet ----------
    fun summaryText(title: String, lines: List<String>): String = title + "\n" + lines.joinToString("\n") { "• $it" }

    // ---------- Grafik ekseni ----------
    /** Izgara adımı (dk): en büyük değeri en çok 4 çizgiyle kaplayan yuvarlak adım. */
    fun niceStepMin(maxMs: Long): Int {
        val maxMin = (maxMs / 60_000L).coerceAtLeast(1L)
        for (st in listOf(5, 10, 15, 30, 60, 120, 180, 240, 360, 480)) if ((maxMin + st - 1) / st <= 4) return st
        return 480
    }

    /** Eksen en üst değeri (ms): adımın katına yukarı yuvarlanır, en az 1 adım. */
    fun axisMaxMs(maxMs: Long): Long {
        val st = niceStepMin(maxMs) * 60_000L
        return maxOf(1L, (maxMs + st - 1) / st) * st
    }

    /** Dilim yüzdesi, toplam 0 ise 0. */
    fun slicePct(part: Long, total: Long): Int = if (total <= 0) 0 else (part * 100 / total).toInt()

    // ---------- Yön / düzen ----------
    /** Yatay (landscape) düzen: genişlik yükseklikten büyük ve en az 480dp. */
    fun isLandscape(widthDp: Int, heightDp: Int): Boolean = widthDp > heightDp && widthDp >= 480

    /** Yatayda tek sütun içeriğin azami okunabilir genişliği (dp). */
    const val CONTENT_MAX_DP = 720

    // ---------- Ekran boyutu sınıfları ----------
    enum class WinClass { COMPACT, MEDIUM, EXPANDED }

    /** Genişliğe göre: telefon dik < 600dp, küçük tablet/katlanır/yatay telefon < 840dp, geniş >= 840dp. */
    fun winClass(widthDp: Int): WinClass = when {
        widthDp < 600 -> WinClass.COMPACT
        widthDp < 840 -> WinClass.MEDIUM
        else -> WinClass.EXPANDED
    }

    /** Yan gezinme şeridi: tablet/katlanır genişliği (>= 600dp) ya da yatay telefon. */
    fun useRail(widthDp: Int, heightDp: Int): Boolean = widthDp >= 600 || isLandscape(widthDp, heightDp)

    /** Tek sütun içerik için azami genişlik: çok geniş ekranlarda biraz daha fazla. */
    fun contentMaxDp(widthDp: Int): Int = if (widthDp >= 1000) 880 else CONTENT_MAX_DP

    /** Pomodoro: kayıtlı bitiş zamanı hâlâ geçerli mi? (süreç ölse bile devam eder) */
    fun pomoLeftMs(endMs: Long, now: Long): Long = if (endMs <= 0L) 0L else (endMs - now).coerceAtLeast(0L)

    /** Otomatik arayüz ölçeği: en küçük ekran kenarına (dp) göre; küçük ekranda biraz küçük, tablet/2K'da büyük. */
    fun autoScale(widthDp: Int, heightDp: Int): Float {
        val sw = minOf(widthDp, heightDp)
        return when {
            sw <= 0 -> 1f
            sw < 320 -> 0.9f
            sw < 360 -> 0.95f
            sw < 480 -> 1f
            sw < 600 -> 1.05f
            sw < 720 -> 1.12f
            sw < 840 -> 1.2f
            else -> 1.3f
        }
    }

    /** manual <= 0 → otomatik; aksi halde elle seçilen (0.7–1.6 arası sınırlı). */
    fun effectiveScale(manual: Float, auto: Float): Float =
        if (manual <= 0f) auto else manual.coerceIn(0.7f, 1.6f)

    /** Özel bildirim metni: {anahtar} yer tutucularını doldurur; bilinmeyenler olduğu gibi kalır; en çok 200 karakter. */
    fun fillTpl(tpl: String, vars: Map<String, String>): String {
        // Tek geçiş: bir değerin içindeki {x} yeniden doldurulmaz.
        val r = Regex("""\{([A-Za-z_]+)\}""").replace(tpl.trim()) { m -> vars[m.groupValues[1]] ?: m.value }
        if (r.length <= 200) return r
        val cut = if (Character.isHighSurrogate(r[199])) 199 else 200 // vekil çifti ortadan bölünmesin
        return r.substring(0, cut)
    }

    /** Kullanıcı metni boşsa varsayılanı kullan. */
    fun msgOrDefault(custom: String, def: String, vars: Map<String, String>): String =
        if (custom.isBlank()) def else fillTpl(custom, vars).ifBlank { def }

    /** Sessiz saat + gün seçimi. Gece yarısını aşan aralıkta sabah saatleri bir önceki günün gecesine aittir. dayIdx: 0 = Pazartesi. */
    fun quietActive(nowMin: Int, from: Int, to: Int, dayIdx: Int, mask: Int): Boolean {
        if (!inQuiet(nowMin, from, to)) return false
        val d = if (from > to && nowMin < to) (dayIdx + 6) % 7 else dayIdx
        return (mask shr d) and 1 == 1
    }

    /** Sessiz saat durumu: kapalı, aralık kapalı (başlangıç == bitiş), şu an aktif, ya da beklemede. */
    enum class QuietState { OFF, SAME_TIMES, ACTIVE, IDLE }

    fun quietState(on: Boolean, nowMin: Int, from: Int, to: Int, dayIdx: Int, mask: Int): QuietState = when {
        !on -> QuietState.OFF
        from == to -> QuietState.SAME_TIMES
        quietActive(nowMin, from, to, dayIdx, mask) -> QuietState.ACTIVE
        else -> QuietState.IDLE
    }

    /** Saat ayarını dakika adımıyla kaydırır; 24 saat içinde sarar (ör. 23:50 + 15 = 00:05). */
    fun stepTime(minutes: Int, delta: Int): Int = ((minutes + delta) % 1440 + 1440) % 1440
    const val TIME_STEP_MIN = 15

    /**
     * Bildirim gizleme kararı. Devam eden bildirimler (müzik, arama, ayak izi) iptal edilmez: iptal
     * edilemezler ve kontrol düğmelerini de kaybettirirler. Geçici izin (pass) varsa da gizlenmez.
     */
    fun hideNotification(ongoing: Boolean, blocked: Boolean, passActive: Boolean): Boolean =
        blocked && !ongoing && !passActive

    /**
     * Metinde sorgunun geçtiği başlangıç konumları (örtüşmesiz, soldan sağa). Eşleşme [foldForSearch] ile yapılır,
     * yani Türkçe ı/i ve aksanlar yok sayılır. Büyük İ gibi katlamanın uzunluğu değiştirdiği metinlerde konumlar
     * küçük harfli metin üzerinden hesaplanır (bu durumda aksan toleransı yoktur).
     */
    fun matchStarts(text: String, query: String): List<Int> {
        val q = foldForSearch(query.trim())
        if (q.isEmpty()) return emptyList()
        val folded = foldForSearch(text)
        val exact = folded.length == text.length
        val hay = if (exact) folded else text.lowercase(Locale.ROOT)
        val needle = if (exact) q else query.trim().lowercase(Locale.ROOT)
        val out = ArrayList<Int>()
        var i = hay.indexOf(needle)
        while (i >= 0) {
            out.add(i)
            i = hay.indexOf(needle, i + needle.length)
        }
        return out
    }

    /** Öğrenilen kuralın user_rules.json içindeki anahtarı. */
    fun ruleKey(app: String, feat: String): String = "$app/$feat"

    /** Aynı uygulamanın etkinlikleri arası geçiş (<= gapMs) yeni "açılış" sayılmaz. */
    fun isNewOpen(lastPauseMs: Long?, resumeMs: Long, gapMs: Long = 2000L): Boolean =
        lastPauseMs == null || resumeMs - lastPauseMs > gapMs

    /** Özellik kullanım süresine eklenecek ms: ilk tarama ya da uzun ara (kullanıcı ayrılmış) 0 ekler. */
    fun featDelta(prevMs: Long?, nowMs: Long, capMs: Long = 3000L): Long =
        if (prevMs == null) 0L else (nowMs - prevMs).let { if (it < 0 || it > capMs) 0L else it }

    /** Yedeğe girmeyecek geçici anahtarlar: aktif izin/odak/pomodoro durumu ve eski günlük sayaçlar. */
    fun backupSkip(key: String, today: java.time.LocalDate): Boolean =
        key.startsWith("pass:") || key.startsWith("pomo_") || key == "focus" || staleDayKey(key, today, 0)

    /** Yedekte izin verilen tercih dosyaları (başka dosya içe aktarılamaz). */
    val BACKUP_FILES = listOf("odak_plan", "odak_todo", "odak_habits", "odak_block", "odak_app", "odak_colors", "odak_notes", "odak_sched", "odak_theme")

    fun backupFileAllowed(name: String): Boolean = name in BACKUP_FILES

    /** Metin köşeli parantezli bir JSON dizisi gibi görünüyor mu? (yüzeysel ön kontrol) */
    fun looksLikeJsonArray(s: String): Boolean {
        val t = s.trim()
        return t.length >= 2 && t.first() == '[' && t.last() == ']'
    }

    // ---- Özellik süresi dolunca: uygulamadan atma, ana menüye (ana sayfa sekmesine) götür ----
    const val EXIT_BACK = 0
    const val EXIT_HOME_TAB = 1

    /** Uygulamaların "ana sayfa" sekmesi için bilinen etiketler (8 dil). */
    val HOME_WORDS = listOf("home", "ana sayfa", "anasayfa", "startseite", "accueil", "inicio", "главная", "الرئيسية", "ana səhifə", "əsas səhifə")

    /** Etiket bir ana sayfa sekmesini gösteriyor mu? Tam eşleşme ya da "Home, tab 1 of 5" gibi önek. */
    fun isHomeLabel(label: String): Boolean {
        val t = label.trim().lowercase(Locale.ROOT)
        if (t.isEmpty() || t.length > 40) return false
        return HOME_WORDS.any { t == it || t.startsWith("$it,") || t.startsWith("$it tab") || t.startsWith("$it -") }
    }

    /** Hangi çıkış yapılacak: ayar açıksa ve ana sayfa tıklaması 2 kez denenmediyse ana sekme, yoksa geri. */
    fun featExit(homeOn: Boolean, tries: Int): Int = if (homeOn && tries < 2) EXIT_HOME_TAB else EXIT_BACK
}
