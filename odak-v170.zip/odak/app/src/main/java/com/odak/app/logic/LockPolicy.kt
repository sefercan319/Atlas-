package com.odak.app.logic

/** Uygulama kilidi ayarları: neyin korunduğu, tekrar kilitlenme süresi, şifre kuralları (saf mantık, JVM'de testlenir). */
object LockPolicy {
    const val APP = 1
    const val BLOCK = 2
    const val NOTES = 4
    const val SETTINGS = 8
    const val ALL = APP or BLOCK or NOTES or SETTINGS
    const val DEFAULT_SCOPES = BLOCK or NOTES
    const val DEFAULT_TIMEOUT = 3
    const val FOREVER = -1
    /** Dakika; 0 = her seferinde sor, -1 = uygulama kapanana dek açık kal. */
    val TIMEOUTS = listOf(0, 1, 3, 5, 15, FOREVER)
    val SCOPES = listOf(APP, BLOCK, NOTES, SETTINGS)

    const val PIN_MIN = 4
    const val PIN_MAX = 8
    const val PW_MIN = 4
    const val PW_MAX = 32

    fun has(scopes: Int, scope: Int) = scopes and scope != 0
    fun toggle(scopes: Int, scope: Int) = (scopes xor scope) and ALL
    fun cleanScopes(v: Int) = v and ALL
    fun cleanTimeout(v: Int) = if (v in TIMEOUTS) v else DEFAULT_TIMEOUT

    /** Doğru şifreden sonra açık kalma bitişi (ölçüm saati ms). */
    fun unlockedUntil(nowMs: Long, timeoutMin: Int): Long =
        if (timeoutMin < 0) Long.MAX_VALUE else nowMs + timeoutMin * 60_000L

    fun isLocked(isSet: Boolean, nowMs: Long, until: Long) = isSet && nowMs >= until

    fun needsGate(isSet: Boolean, scopes: Int, scope: Int, nowMs: Long, until: Long) =
        has(scopes, scope) && isLocked(isSet, nowMs, until)

    /** Parmak izi/yüz seçeneği: açık + cihazda kayıtlı + şifre kurulu. */
    fun biometricOffered(enabled: Boolean, available: Boolean, isSet: Boolean) = enabled && available && isSet

    fun filterInput(s: String, text: Boolean): String = if (text) s.take(PW_MAX) else s.filter(Char::isDigit).take(PIN_MAX)

    fun valid(s: String, text: Boolean): Boolean =
        if (text) s.length in PW_MIN..PW_MAX && s.isNotBlank() else s.length in PIN_MIN..PIN_MAX && s.all(Char::isDigit)
}
