package com.odak.app.logic

/** Engelleme kataloğuna eklenen ikinci ek uygulama grubu ("Ad|paket"). Paket adları elle derlendi; yanlış bir paket yalnızca eşleşmez. */
object MoreAppsData2 {
    private const val Q0 = """
Garena Free Fire Lite|com.dts.freefireadv
Pokemon Cafe ReMix|com.LineJapan.PokemonCafeReMix
Monster Hunter Now|com.nianticlabs.monsterhunter
Pikmin Bloom|com.nianticlabs.pikmin
Peridot|com.nianticlabs.peridot
Ingress Prime|com.nianticproject.ingress
Harry Potter Wizards Unite|com.nianticlabs.hpwu
Marvel Future Fight|com.netmarble.mherosgb
Marvel Rivals Mobile|com.netease.marvelrivals
Plarium Play|com.plarium.plariumplay
Mech Arena|com.plarium.mecharena
Castle Clash|com.igg.castleclash
Call of Dragons|com.farlightgames.igame.gp
Game of Sultans|com.dragon.sultan.of.the.rose
Puzzles and Survival|com.im30.ROE.gp
Royal Kingdom|com.dreamgames.royalkingdom
Fishdom|com.playrix.fishdom
Toon Blast|com.peak.toonblast
Toy Blast|com.peak.toyblast
Solitaire Grand Harvest|com.supergame.solitaire
Solitaire Klondike|com.mobilityware.solitaire
FreeCell|com.mobilityware.freecell
Microsoft Solitaire|com.mobilityware.MahjongSolitaire
Microsoft Mahjong|com.microsoft.mahjong
Mahjong Titan|com.kristanix.android.mahjongtitan
Mahjong Solitaire|com.kristanix.android.mahjong
Block Puzzle Jewel|com.puzzlegame.blockpuzzle
1010 Block Puzzle|com.gramgames.tenten
Sudoku.com|com.easybrain.sudoku.android
Jigsaw Puzzles|com.easybrain.jigsaw.puzzles
Nonogram.com|com.easybrain.nonogram
Number Match|com.easybrain.number.puzzle.game
Art Puzzle|com.easybrain.art.puzzle
Word Connect|com.wordgame.words.connect
Word Cookies|com.bitmango.wordcookies
Wordle|com.nytimes.crossword
NYT Games|com.nytimes.games
Words With Friends 2|com.zynga.words2
Zynga Slots|com.zynga.wwf2.free
Farmville 3|com.zynga.farmville3
Farmville 2|com.zynga.FarmVille2CountryEscape
CSR Racing 2|com.naturalmotion.customstreetracer2
Need for Speed Mobile|com.ea.gp.nfsmobile
Traffic Rider|com.skgames.trafficrider
Traffic Racer|com.skgames.trafficracer
Car Parking Multiplayer|com.olzhas.carparking.multyplayer
Car Parking Multiplayer 2|com.olzhas.carparking2
Extreme Car Driving Simulator|com.aim.racing
Real Drift Car Racing|com.rdracing.drift
CarX Drift Racing 2|com.carxtech.carxdr2
CarX Street|com.carxtech.carxstreet
Drive Zone Online|com.driveareagames.drivezone
Dr Driving|com.ansangha.drdriving
Bus Simulator Ultimate|com.zuuks.bus.simulator.ultimate
Truck Simulator Ultimate|com.zuuks.truck.simulator.ultimate
Euro Truck Driver|com.truckers.euro
Truckers of Europe 3|com.wanda.truckersofeurope3
Bus Simulator Indonesia|com.maleo.bussimulatorid
Cargo Simulator 2023|com.pgstudio.cargosimulator
Gangster Vegas|com.nativex.gangstervegas
Grand Theft Auto Vice City|com.rockstargames.gtavc
Grand Theft Auto III|com.rockstargames.gta3
Bully|com.rockstargames.bully
Max Payne Mobile|com.rockstar.maxpayne
Sniper 3D|com.fungames.sniper3d
Hitman Sniper|com.squareenixmontreal.hitmansniperandroid
Hitman Go|com.squareenixmontreal.hitmango
Lara Croft Go|com.squareenixmontreal.laracroftgo
Dead Trigger 2|com.madfingergames.deadtrigger2
Bullet Force|com.Blayze.BulletForce
Pixel Gun 3D|com.ngames.pixelgun3d
Block City Wars|com.blockcitywars
Gun Builder|com.gun.builder
Zombie Catchers|com.vividgames.zombiecatchers
Zombie Frontier 3|com.glu.zf3
Plants vs Zombies 3|com.ea.gp.pvzfree
Plants vs Zombies Heroes|com.ea.game.pvzheroes_row
Bloons TD Battles 2|com.ninjakiwi.bloonstdbattles2
Kingdom Rush|com.ironhidegames.android.kingdomrush
Kingdom Rush Vengeance|com.ironhidegames.android.kingdomrushvengeance
Kingdom Rush Alliance|com.ironhidegames.android.kingdomrushalliance
Archero 2|com.habby.archero2
Survivor io|com.habby.survivorio
Magic Survival|com.ys.magicsurvival
Brotato|com.brotato.mobile
Soul Knight Prequel|com.ChillyRoom.SKPrequel
Dungeon Hunter 6|com.gameloft.android.ANMP.GloftDHHM
Diablo IV Mobile|com.blizzard.diablo4
Valorant Mobile|com.tencent.tmgp.valorant
Honkai Nexus Anima|com.hypergryph.nexus
Arknights Endfield|com.hypergryph.endfield
Girls Frontline 2|com.sunborn.gfl2.global
Summoners War Chronicles|com.com2us.smon.chronicles.global
Lineage 2M|com.ncsoft.lineage2m
Lineage 2 Revolution|com.netmarble.lineage2revgb
Ragnarok M|com.gravity.romg
MapleStory M|com.nexon.maplem.global
Dragon Nest 2 Evolution|com.nexon.dnf2
Seven Knights 2|com.netmarble.sk2
Seven Deadly Sins Grand Cross|com.netmarble.nanagb
Mir4|com.wemade.mir4global
Night Crows|com.wemade.nightcrows
Throne and Liberty Mobile|com.ncsoft.tl
RuneScape|com.jagex.oldscape.android
AFK Journey|com.farlightgames.samo.gp
Dragon Ball Idle|com.global.dragonballidle
Naruto Shippuden Ultimate Ninja Blazing|com.bandainamcoent.narutoutnblazing
One Piece Bounty Rush|com.bandainamcogames.opbrww
One Piece Treasure Cruise|jp.co.bandainamcoent.BNEI0242
Bleach Brave Souls|com.klab.bleach
Saint Seiya Awakening|com.tencent.tmgp.ssawakening
Digimon Rearise|com.bandainamcoent.digimonrearise
Sonic Dash|com.sega.sonicdash
Sonic Forces|com.sega.sonicrunners
Sonic Prime Dash|com.sega.sonicprimedash
Fruit Ninja Classic|com.halfbrick.fruitninjafree
Cut the Rope 2|com.zeptolab.ctr2.f2p.google
Angry Birds Reloaded|com.rovio.angrybirdsreloaded
Angry Birds Friends|com.rovio.angrybirdsfriends
Bad Piggies|com.rovio.BadPiggies
Talking Tom Gold Run|com.outfit7.talkingtomgoldrun
My Talking Tom Friends|com.outfit7.mytalkingtomfriends
My Talking Angela|com.outfit7.mytalkingangelafree
My Talking Angela 2|com.outfit7.mytalkingangela2
Talking Tom Hero Dash|com.outfit7.talkingtomheroesrun
Talking Tom Pool|com.outfit7.talkingtompool
Talking Ben|com.outfit7.talkingben
Talking Tom Cat|com.outfit7.talkingtom
Talking Angela|com.outfit7.talkingangelafree
Talking Hank Adventures|com.outfit7.talkinghankadventure
Zombie Tsunami|com.digidust.elokence.zombietsunami
Alto's Adventure|com.noodlecake.altosadventure
Alto's Odyssey|com.noodlecake.altosodyssey
Monument Valley|com.ustwo.monumentvalley
Monument Valley 2|com.ustwo.monumentvalley2
Geometry Dash Lite|com.robtopx.geometryjumplite
Geometry Dash World|com.robtopx.geometryjumpworld
Geometry Dash SubZero|com.robtopx.geometryjumpsubzero
Dumb Ways to Die|com.metrotrains.dumbways
Doodle Jump|com.lima.doodlejump
Piano Tiles 2|com.cmplay.pt2
Magic Tiles 3|com.amanotes.gamesdk.magictiles3
Beat Blade Dash Dance|com.amanotes.beatblade
Dancing Road|com.amanotes.dancingroad
Beat Street|com.amanotes.beatstreet
Rolling Sky|com.cmplay.RollingSky
Dancing Line|com.cmplay.dancingline
Perfect Piano|com.gamestar.perfectpiano
Real Piano|com.gismart.realpianofree
Real Guitar|com.gismart.guitar
Simply Piano|com.joytunes.simplypiano
Simply Guitar|com.joytunes.simplyguitar
WeSing|com.tencent.wesing
Rhythm Hive|com.superbgames.rhythmhive
Osu Droid|ru.nsu.ccfit.zuev.osuplus
Lost Ark Mobile|com.smilegate.lostark
Dying Light|com.techland.dyinglight
Hades Mobile|com.supergiantgames.hades
Don't Starve Shipwrecked|com.kleientertainment.doNotStarveShipwrecked
Oxygen Not Included Mobile|com.kleientertainment.oni
Papers Please|com.dukope.papersplease
Limbo|com.playdead.limbo.full
Inside|com.playdead.inside
Oceanhorn|com.fdg.oceanhorn
Mini Metro|nz.co.mirrorlab.minimetro
Mini Motorways|com.dinopoloclub.minimotorways
Dinosaur Game|com.google.android.dinosaur
Cookie Run OvenBreak|com.devsisters.gb
Cookie Run Witch's Castle|com.devsisters.crwc
LINE Rangers|com.linecorp.LGRGS
LINE Bubble 2|com.linecorp.LGLB2
LINE Pokopang|com.linecorp.LGPKPG
Disney Dreamlight Valley Mobile|com.gameloft.android.ANMP.GloftDDV
Disney Heroes Battle Mode|com.perblue.disneyheroes
Disney Solitaire|com.superplaystudios.disneysolitaire
Disney Emoji Blitz|com.jamcity.disneyemojiblitz
Star Wars Hunters|com.zynga.starwarshunters
Star Wars Force Arena|com.netmarble.starwarsforce
Jurassic World The Game|com.ludia.jwalive
Jurassic World Alive|com.ludia.jurassicworldalive
Jurassic World Evolution Mobile|com.frontier.jwe
Dragons Rise of Berk|com.ludia.dragons
Dragon City|es.socialpoint.dragoncity
Monster Legends|es.socialpoint.MonsterLegends
Dragon Ball Super Card Game|com.bandainamcoent.dbscardgame
Yu-Gi-Oh Cross Duel|jp.konami.crossduel
Magic The Gathering Arena|com.wizards.mtga
Magic The Gathering Puzzle Quest|com.d3p.magicpuzzlequest
Gwent|com.cdprojektred.gwent
Clash of Kings|com.elex.cok
Clash of Lords 2|com.igg.clashoflords2
Game of War Fire Age|com.machinezone.gow
Mafia City|com.yottagames.mafiawar
War Robots|com.pixonic.wwr
War Robots Frontiers|com.pixonic.wrfrontiers
World of Tanks Blitz|net.wargaming.wot.blitz
World of Warships Blitz|com.wargaming.wowsblitz
World of Tanks Assault|net.wargaming.wotassault
Armored Warfare|com.my.armoredwarfare
Modern Warships|com.ngames.modernwarships
Warships Mobile 2|com.cmgame.warshipsmobile2
Navy Field 2|com.nfm.navyfield2
Battle of Warships|com.ngames.battleofwarships
Idle Miner Tycoon|com.fluffyfairygames.idleminertycoon
Idle Mining Empire|com.idle.mining.empire
AdVenture Capitalist|com.kongregate.mobile.adventurecapitalist.google
Cookie Clicker|org.dashnet.cookieclicker
Egg Inc|com.auxbrain.egginc
Bitlife|com.candywriter.bitlife
Simpsons Tapped Out|com.ea.game.simpsons4_row
Family Guy Quest for Stuff|com.tinyco.familyguy
Sims FreePlay|com.ea.game.sims3_row
Sims 4 Mobile|com.ea.gp.thesims4
Tiny Tower|com.nimblebit.tinytower
Pocket Build|com.pocketbuild.tycoon
Hustle Castle|com.my.hc.rpg.kingdom.simulator
Idle Slayer|com.RuneStudios.IdleSlayer
Cat Game|com.nfm.catgame
Neko Atsume|jp.co.hit_point.nekoatsume
Pou|me.pou.app
My Talking Pet|com.petsim.talkingpet
My Boo|com.tapblaze.myboo
Subway Princess Runner|com.subway.princess.runner
Lily's Garden|com.tripledot.lilysgarden
Merge Magic|com.tapblaze.mergemagic
Merge Gardens|com.futureplay.mergegardens
Merge Fables|com.metacoregames.mergefables
Travel Town|com.magmatic.traveltown
Seaside Escape|com.futureplay.seaside
Match Masters|com.matchmasters.app
Dice Dreams|com.superplaystudios.dicedreams
Monopoly Classic|com.ea.game.monopoly_row
Pet Rescue Saga|com.king.petrescuesaga
Paradise Bay|com.king.paradisebay
Ludo Master|com.ludo.master
Soccer Stars|com.miniclip.soccerstars
Golf Rival|com.miniclip.golfrival
Mini Golf King|com.miniclip.minigolfking
Wormate.io|io.wormate
Snake.io|com.noodlecake.snakeio
Mope.io|io.mopeio
Zombs Royale|io.zombsroyale
Brawlhalla|com.ubisoft.brawlhallaaa
Shadow Fight 2|com.nekki.shadowfight
Shadow Fight 3|com.nekki.shadowfight3
Shadow Fight Arena|com.nekki.sfarena
Mortal Kombat Mobile|com.wb.goog.mkx
Mortal Kombat Onslaught|com.wb.goog.mkonslaught
Injustice 2 Mobile|com.wb.goog.injustice2
Injustice Gods Among Us|com.wb.goog.dcunited
DC Legends|com.wb.goog.dclegends
DC Dual Force|com.wb.goog.dcdualforce
Batman Arkham Underworld|com.wb.goog.batmanarkhamunderworld
Real Boxing 2|com.vividgames.realboxing2
Real Boxing|com.vividgames.realboxing
Boxing Star|com.fiveplay.boxingstar
EA Sports FC Tactical|com.ea.gp.fctactical
PES Club Manager|jp.konami.pesclubmanager
Score Hero 2|com.firsttouchgames.scorehero2
Score Match|com.firsttouchgames.scorematch
Soccer Manager|com.sm.soccermanager
Football Manager Mobile|com.sega.footballmanagermobile
Soccer Super Star|com.ssgamesstudio.soccersuperstar
Real Football|com.gameloft.android.ANMP.GloftR1HM
Hattrick|org.hattrick.app
Madden NFL Mobile|com.ea.game.maddenmobile_row
NBA 2K Mobile|com.t2ksports.nba2k20and
NBA Infinite|com.nbainfinite.android
NBA Basketball Stars|com.fiveplay.nba
NBA Now|com.gamevil.nbanow
MLB 9 Innings|com.com2us.ninepb3d.normal.freefull.google.global.android.common
MLB Tap Sports Baseball|com.glu.mlbtsb
WWE SuperCard|com.cubicgames.wwesupercard
WWE Mayhem|com.reliancebig.wwemayhem
WWE Champions|com.scopely.wwechampions
UFC Mobile|com.ea.gp.ufcmobile
Golf Clash|com.ea.game.golfroyale
Golf Battle|com.golfbattle.android
Wgt Golf|com.topgolf.wgt
Pro Rally|com.proffgames.prorally
Rally Fury|com.codemasters.rallyfury
Ridge Racer Draw And Drift|com.bandainamcoent.ridgeracer
Super Mario Run|com.nintendo.zara
Fire Emblem Heroes|com.nintendo.zaba
Animal Crossing Pocket Camp|com.nintendo.zaca
Dragalia Lost|com.nintendo.zaga
Dr Mario World|com.nintendo.zaha
Pokemon Quest|jp.pokemon.pokemonquest
Pokemon Sleep|jp.pokemon.pokemonsleep
Pokemon Smile|jp.pokemon.pokemonsmile
Instagram Edits|com.instagram.edits
Facebook Creator Studio|com.facebook.creatorstudio
Facebook Gaming|com.facebook.gamingvideo
Facebook Groups|com.facebook.groups
Facebook Pages Manager|com.facebook.pages.app
Facebook Ads Manager|com.facebook.adsmanager
Messenger Kids|com.facebook.talk
Meta Quest|com.oculus.twilight
Meta AI|com.facebook.stella
TikTok Studio|com.zhiliaoapp.musically.studio
TikTok Now|com.zhiliaoapp.musically.now
Bigo Live Lite|sg.bigo.live.lite
Imo Lite|com.imo.android.imoimbeta
Skype Lite|com.skype.m2
Zoom Rooms|us.zoom.zrc
Google Meet|com.google.android.apps.meetings
Cisco Webex|com.cisco.webex.meetings
GoToMeeting|com.gotomeeting
Discord Lite|com.discord.lite
Guilded|gg.guilded.app
Hike|com.bsb.hike
Koo|com.koo.app
Truth Social|com.truthsocial.android
Gab|com.gab.android
Pixelfed|org.pixelfed.app
Tusky|com.keylesspalace.tusky
Fedilab|app.fedilab.nitterizeme
Wizz|com.wizz.app
Lapse|com.lapse.app
Locket Widget|com.locket.widget
Saturn|com.saturn.app
Gas|com.gas.app
NGL|com.nglapp.ngl
Sendit|com.sendit.app
Tellonym|com.tellonym.app
Whisper|sh.whisper
Yik Yak|com.yik.yak
Fizz|com.fizz.app
Amino|com.narvii.amino.master
Substack|com.substack.app
Pinterest Lite|com.pinterest.lite
Snapchat Lite|com.snapchat.android.lite
Youtube Gaming|com.google.android.apps.youtube.gaming
Youtube Vanced|com.vanced.android.youtube
ReVanced|app.revanced.android.youtube
NewPipe|org.schabi.newpipe
LibreTube|com.github.libretube
SkyTube|free.rm.skytube.oss
Twitch Studio|tv.twitch.studio
Twitch Lite|tv.twitch.android.viewer.lite
Trovo Live|com.trovo.app
Bilibili Global|com.bilibili.app.in
Niconico|jp.nicovideo.android
Abema|tv.abema
Funimation|com.funimation
HiDive|com.hidive.android
Muse Asia|com.muse.asia
Vudu|air.com.vudu.air.DownloaderTablet
Roku|com.roku.remote
Emby|com.mb.android
Popcorn Time|org.popcorntime.android
Cinema HD|com.cinemahd.app
MX Player Pro|com.mxtech.videoplayer.pro
Nova Video Player|org.courville.nova
Just Player|com.brouken.player
Infuse|com.firecore.infuse
BSPlayer|com.bsplayer.bspandroid.free
Xvideos|com.xvideos.app
Pornhub|com.pornhub.app
Napster|com.rhapsody.napster
Radio FM|com.radio.fmradio
Musixmatch|com.musixmatch.android.lyrify
Genius|com.genius.android
Bandcamp|com.bandcamp.android
Mixcloud|com.mixcloud.player
Scribd|com.scribd.app.reader0
Pocket FM|com.radioly.pocketfm
Overcast|fm.overcast.overcast
Spotify Podcasters|com.spotify.podcasters
Reddit Lite|com.reddit.frontpage.lite
Apollo for Reddit|com.christianselig.apollo
Slide for Reddit|me.ccrama.redditslide
Narwhal|com.narwhal.app
Hacker News|com.hackernews.app
Digg|com.digg.android
Pulse News|com.alphonso.pulse
Google Discover|com.google.android.googlequicksearchbox
Yahoo News|com.yahoo.mobile.client.android.yahoo
Yahoo Sports|com.yahoo.mobile.client.android.sportacular
Yahoo Fantasy Sports|com.yahoo.mobile.client.android.fantasyfootball
AOL|com.aol.mobile.aolapp
Financial Times|com.ft.news
Wall Street Journal|com.dowjones.wsj
The Economist|com.economist.lamarr
Forbes|com.forbes.android
Business Insider|com.businessinsider.android
Axios|com.axios.android
Politico|com.politico.android
NBC News|com.nbcnews.today
ABC News|com.abc.abcnews
CBS News|com.cbsnews.android
NPR|org.npr.one
USA Today|com.usatoday.android.news
Daily Mail|uk.co.dailymail.android
The Sun|com.thesun.android
The Times UK|com.thetimes.android
Sky News|com.bskyb.skynews.android
Al Jazeera|com.aljazeera.mobile
Al Arabiya|net.alarabiya.android
RT News|com.rt.news
Deutsche Welle|de.dw.android
Euronews|com.euronews.express
France 24|com.france24.android
Le Monde|com.lemonde.androidapp
Der Spiegel|de.spiegel.android
BILD|de.bild.android.app
El Pais|com.elpais.elpais
Marca|com.marca.android
AS|com.as.android
BBC Sport|uk.co.bbc.sport
BBC iPlayer|uk.co.bbc.iplayer
BBC Sounds|com.bbc.sounds
ESPN|com.espn.score_center
ESPN Fantasy|com.espn.fantasy.lm.football
Sky Sports|com.bskyb.sportsandroidapp
BT Sport|com.bt.sport
DAZN|com.dazn
beIN Sports Connect|com.bein.beinsports
FotMob|com.mobilefootie.wc2010
OneFootball|de.motain.iliga
SofaScore|com.sofascore.results
Flashscore|eu.livesport.FlashScore_com
Livescore|com.livescore
365Scores|com.scores365
Forza Football|com.forzafootball
Transfermarkt|com.transfermarkt.app
FPL|com.premierleague.fantasy
Premier League|com.pl.premierleague
Champions League|com.uefa.ucl
UEFA Gaming|com.uefa.gaming
NBA App|com.nbaimd.gametime.nba2011
NFL|com.gotv.nflgamecenter.us.lite
NHL|com.nhl.gc1112.free
MLB At Bat|com.bamnetworks.mobile.android.gameday.atbat
F1 TV|com.formulaone.production
Formula 1|com.softpauer.f1timingapp2014.basic
MotoGP|com.motogp.official
WWE|com.wwe.universe
UFC|com.ufc.fightpass
Peloton|com.onepeloton.callisto
Nike Run Club|com.nike.plusgps
Adidas Running|com.runtastic.android
Adidas Confirmed|com.adidas.confirmed
Zwift|com.zwift.zwiftgame
Komoot|de.komoot.android
AllTrails|com.alltrails.alltrails
Fitbit|com.fitbit.FitbitMobile
Garmin Connect|com.garmin.android.apps.connectmobile
Samsung Health|com.sec.android.app.shealth
Google Fit|com.google.android.apps.fitness
"""
    private const val Q1 = """
Huawei Health|com.huawei.health
Zepp Life|com.xiaomi.hm.health
Mi Fitness|com.xiaomi.wearable
Amazfit|com.huami.watch.hmwatchmanager
Whoop|com.whoop.android
Oura|com.ouraring.oura
MyFitnessPal|com.myfitnesspal.android
Lose It|com.fitnow.loseit
Cronometer|com.cronometer.android
Yazio|com.yazio.android
Fastic|com.fastic.android
Zero Fasting|com.zerofasting.zero
Noom|com.wsl.noom
WW Weight Watchers|com.weightwatchers.mobile
Calm|com.calm.android
Headspace|com.getsomeheadspace.android
Insight Timer|com.spotlightsix.zentimerlite2
Balance Meditation|app.balance
Sleep Cycle|com.northcube.sleepcycle
Sleep As Android|com.urbandroid.sleep
Pillow|co.pillow.app
Flo Period Tracker|org.iggymedia.periodtracker
Clue|com.clue.android
Natural Cycles|com.naturalcycles.cordova
Glow|com.glow.android
Ovia|com.ovuline.pregnancy
What To Expect|com.whattoexpect.app
BabyCenter|com.babycenter.pregnancytracker
Huckleberry|com.huckleberry.baby
Baby Tracker|com.nighp.babytracker_android
Hepsiburada Market|com.hepsiburada.market
Ciceksepeti|com.ciceksepeti.ciceksepeti
Boyner|com.boyner
LC Waikiki|com.lcwaikiki.android
DeFacto|com.defacto.android
Koton|com.koton.mobile
Mavi|com.mavi.android
Flo|com.flo.android
Decathlon Turkiye|com.decathlon.android.tr
Teknosa|com.teknosa.android
MediaMarkt Turkiye|de.mediamarkt.shop.tr
Vatan Bilgisayar|com.vatan.bilgisayar
Gratis|com.gratis.android
Watsons Turkiye|com.watsons.tr
Rossmann Turkiye|com.rossmann.tr
Migros|com.migros.migrosandroid
Migros Hemen|com.migroshemen.app
Macro Online|com.macrocenter.app
BIM|com.bim.android
A101|com.a101.android
SOK|com.sokmarket.android
CarrefourSA|com.carrefoursa.mobile
GetirYemek|com.getir.food
GetirBuyuk|com.getir.big
GetirCarsi|com.getir.carsi
Banabi|com.banabi.android
Fuudy|com.fuudy.android
Yemek Sepeti Mahalle|com.yemeksepeti.mahalle
Trendyol Yemek|com.trendyol.yemek
Domino's Pizza Turkiye|com.dominos.tr
Pizza Hut Turkiye|com.pizzahut.tr
Burger King Turkiye|com.burgerking.tr
McDonald's Turkiye|com.mcdonalds.tr
KFC Turkiye|com.kfc.tr
Popeyes Turkiye|com.popeyes.tr
Starbucks Turkiye|com.starbucks.tr
Little Caesars Turkiye|com.littlecaesars.tr
Papa John's Turkiye|com.papajohns.tr
Midpoint|com.midpoint.android
Kahve Dunyasi|com.kahvedunyasi.android
Is Cep|com.isbank.mobile
Isbank Maximum Mobil|com.maximum.mobile
Halkbank Mobil|com.tmobtech.halkbank
Vakifbank Mobil|com.vakifbank.mobile
ING Mobil|com.ingbanktr.ingmobil
HSBC Turkiye|com.hsbc.hsbcturkey
Odeabank|com.odeabank.mobil
Fibabanka|com.fibabanka.mobile
Albaraka Mobil|com.albarakaturk.mobile
Turkiye Finans Mobil|com.turkiyefinans.mobil
Ziraat Katilim|com.ziraatkatilim.mobil
Vakif Katilim|com.vakifkatilim.mobil
Emlak Katilim|com.emlakkatilim.mobil
Enpara|com.enpara.android
Papara|com.papara.android
Tosla|com.tosla.android
Ininal|com.ininal.android
Fastpay|com.fastpay.android
Hepsipay|com.hepsipay.android
Param|com.param.android
Paratika|com.paratika.android
BKM Express|com.bkm.bkmexpress
Troy|com.troy.android
Misyon Bank|com.misyonbank.android
Colendi|com.colendi.android
Hayat Finans|com.hayatfinans.android
Midas|com.midas.app
Garanti BBVA Yatirim|com.garantiyatirim.mobil
Is Yatirim|com.isyatirim.mobil
Gedik Yatirim|com.gedik.mobil
Matriks Mobil|com.matriks.mobil
Foreks|com.foreks.android
BigPara|com.bigpara.android
Borsa Istanbul|com.borsaistanbul.android
Paratic|com.paratic.android
Binance TR|com.binance.tr
Paribu|com.paribu.app
BtcTurk|com.btcturk.android
Coinbase Wallet|org.toshi
Bybit|com.bybit.app
OKX|com.okinc.okcoin.com
Moomoo|cn.moomoo.trade
Interactive Brokers|atws.app
Trading 212|com.avuscapital.trading212
Western Union|com.westernunion.moneytransferr3app.eu
Remitly|com.remitly.androidapp
Chime|com.onedebit.chime
Afterpay|com.afterpay.android
YNAB|com.youneedabudget.evergreen.android
Splitwise|com.Splitwise.SplitwiseMobile
Google Wallet|com.google.android.apps.walletnfcrel
BHIM|in.org.npci.upiapp
Amazon Alexa|com.amazon.dee.app
Amazon Photos|com.amazon.clouddrive.photos
Amazon Seller|com.amazon.sellermobile.android
Amazon Fresh|com.amazon.fresh
DHgate|com.dhgate.buyermob
Pull&Bear|com.inditex.pullandbear
Bershka|com.inditex.bershka
Stradivarius|com.inditex.stradivarius
Massimo Dutti|com.inditex.massimodutti
Uniqlo|com.uniqlo.global
Nike SNKRS|com.nike.snkrs
IKEA|com.ikea.mobile
Bolt Food|ee.mtakso.food
Rapido|com.rapido.passenger
Yandex Eats|ru.yandex.eda
Yandex Market|ru.beru.android
Sberbank Online|ru.sberbankmobile
Tinkoff|com.idamob.tinkoff.android
Turkcell Platinum|com.turkcell.platinum
Turkcell Hesabim|com.ttech.android.onlineislem
Turkcell TV+|com.turkcell.tvplus
Turkcell Lifebox|tr.com.turkcell.akillidepo
Turkcell Dergilik|com.turkcell.dergilik
Turkcell Gnc|com.turkcell.gnc
Turkcell Yaani|com.turkcell.yaani
Turkcell Superonline|com.superonline.android
Vodafone Yanimda|com.vodafone.selfservis
Vodafone TV|com.vodafone.tv
Vodafone Red Room|com.vodafone.redroom
Vodafone Cuzdan|com.vodafone.cuzdan
Turk Telekom Online Islemler|com.ttnet.oim
TTNET Muzik|com.ttnet.muzik
Tivibu|com.tivibu.android
Tivibu GO|com.tivibu.go
Digiturk Play|com.digiturk.digitukplay
beIN CONNECT|com.digiturk.bein
BluTV|com.blutv.android
Gain|com.gain.android
Puhu TV|com.puhutv.android
Tabii|com.tabii.android
TOD|com.tod.android
TV8|com.tv8.android
TRT Izle|tr.gov.trt.izle
TRT Cocuk|tr.gov.trt.cocuk
TRT Radyo|tr.gov.trt.radyo
TRT Haber|tr.gov.trt.haber
TRT Muzik|tr.gov.trt.muzik
ATV|com.atv.android
Kanal D|com.kanald.android
Show TV|com.showtv.android
Star TV|com.startv.android
FOX Turkiye|com.foxtv.android
NOW TV Turkiye|com.nowtv.tr
TV100|com.tv100.android
Halk TV|com.halktv.android
Sozcu TV|com.sozcutv.android
CNN Turk|com.cnnturk.android
NTV|com.ntv.android
Haberturk|com.haberturk.android
Habertürk TV|com.haberturk.tv
A Haber|com.ahaber.android
A Spor|com.aspor.android
TRT Spor|tr.gov.trt.spor
TRT 1|tr.gov.trt.trt1
Sabah|com.sabah.android
Hurriyet|com.hurriyet.android
Milliyet|com.milliyet.android
Sozcu|com.sozcu.android
Cumhuriyet|com.cumhuriyet.android
Posta|com.posta.android
Takvim|com.takvim.android
Yeni Safak|com.yenisafak.android
Aksam|com.aksam.android
Star Gazete|com.stargazete.android
Haber7|com.haber7.android
Mynet|com.mynet.android
Internet Haber|com.internethaber.android
Son Dakika|com.sondakika.android
Ensonhaber|com.ensonhaber.android
Anadolu Ajansi|tr.com.aa.android
IHA|com.iha.android
DHA|com.dha.android
Hurriyet Emlak|com.hurriyetemlak.android
Zingat|com.zingat.android
Emlakjet|com.emlakjet.android
Hepsiemlak|com.hepsiemlak.android
Arabam|com.arabam.android
Otokoc|com.otokoc.android
Vavacars|com.vavacars.android
Sahibinden Oto|com.sahibinden.oto
Kariyer.net|net.kariyer.android
Yenibiris|com.yenibiris.android
Secretcv|com.secretcv.android
Indeed|com.indeed.android.jobsearch
LinkedIn Jobs|com.linkedin.android.jobs
Glassdoor|com.glassdoor.app
ZipRecruiter|com.ziprecruiter.android
E-Devlet|tr.gov.turkiye.edevlet.kapisi
MHRS|tr.gov.saglik.mhrs
e-Nabiz|tr.gov.saglik.enabiz
HES|tr.gov.saglik.hes
AFAD|tr.gov.afad.android
Kandilli|tr.edu.boun.kandilli
e-Okul|tr.gov.meb.eokul
MEB E-Okul VBS|tr.gov.meb.eokulvbs
MEB EBA|tr.gov.eba.eba
MEBBIS|tr.gov.meb.mebbis
Ogretmen Odasi|tr.gov.meb.ogretmenodasi
Okul Oncesi|tr.gov.meb.okuloncesi
OBS|tr.edu.obs
Anadolu AOF|tr.edu.anadolu.aof
Ataturk Universitesi AUZEF|tr.edu.atauni.auzef
Istanbul Universitesi AUZEF|tr.edu.istanbul.auzef
Sinav Takvimi|tr.gov.osym.takvim
OSYM Ais|tr.gov.osym.ais
YKS|tr.gov.osym.yks
KPSS|tr.gov.osym.kpss
ALES|tr.gov.osym.ales
YDS|tr.gov.osym.yds
Turkiye Diyanet|tr.gov.diyanet.mobil
Diyanet Namaz Vakitleri|tr.gov.diyanet.namazvakti
Diyanet Kuran|tr.gov.diyanet.kuran
Diyanet Takvim|tr.gov.diyanet.takvim
Namaz Vakti|com.namazvakti.android
Ezan Vakti|com.ezanvakti.android
Ezan Vakti Pro|com.ezanvakti.pro
Kuran Oku|com.kuranoku.android
Kuran-i Kerim|com.kurankerim.android
Elif Ba|com.elifba.android
Dua ve Zikir|com.duazikir.android
Zikirmatik|com.zikirmatik.android
Muslim Pro|com.bitsmedia.android.muslimpro
Quran Majeed|com.quranreading.qibla
Athan|com.athan
Salah Time|com.salahtime.android
Hadith Collection|com.hadith.collection
Islam360|com.islam360.android
Dini Takvim|com.dinitakvim.android
Kible Pusulasi|com.kiblepusulasi.android
Qibla Compass|com.qibla.compass
Ramazan Imsakiyesi|com.ramazan.imsakiyesi
Imsakiye|com.imsakiye.android
Mevlid Kandili|com.mevlidkandili.android
Diyanet Cocuk|tr.gov.diyanet.cocuk
Diyanet TV|tr.gov.diyanet.tv
Chrome Beta|com.chrome.beta
Chrome Dev|com.chrome.dev
Chrome Canary|com.chrome.canary
Firefox Beta|org.mozilla.firefox_beta
Firefox Nightly|org.mozilla.fenix
Firefox Klar|org.mozilla.klar
Opera Touch|com.opera.touch
Brave Beta|com.brave.browser_beta
Edge Beta|com.microsoft.emmx.beta
UC Browser Mini|com.uc.browser.en
Orbot|org.torproject.android
Bromite|org.bromite.bromite
Huawei Browser|com.huawei.browser
Startpage|com.startpage.app
Phoenix Browser|com.transsion.phx.browser
CM Browser|com.ksmobile.cb
Yandex Browser Lite|com.yandex.browser.lite
Google Assistant|com.google.android.apps.googleassistant
Google Gemini|com.google.android.apps.bard
Google Lens|com.google.ar.lens
Google Earth|com.google.earth
Google Street View|com.google.android.street
Google Photos|com.google.android.apps.photos
Google Drive|com.google.android.apps.docs
Google Docs|com.google.android.apps.docs.editors.docs
Google Sheets|com.google.android.apps.docs.editors.sheets
Google Slides|com.google.android.apps.docs.editors.slides
Google Keep|com.google.android.keep
Google Calendar|com.google.android.calendar
Google Tasks|com.google.android.apps.tasks
Google Contacts|com.google.android.contacts
Google Phone|com.google.android.dialer
Google Clock|com.google.android.deskclock
Google Calculator|com.google.android.calculator
Google Files|com.google.android.apps.nbu.files
Google One|com.google.android.apps.subscriptions.red
Google Home|com.google.android.apps.chromecast.app
Google Play Games|com.google.android.play.games
Google Play Store|com.android.vending
Google Play Services|com.google.android.gms
Google Forms|com.google.android.apps.forms
Google Sites|com.google.android.apps.sites
Google Fi|com.google.android.apps.tycho
Google Pixel Camera|com.google.android.GoogleCamera
Google Arts and Culture|com.google.android.apps.cultural
Google Family Link|com.google.android.apps.kids.familylink
Google Authenticator|com.google.android.apps.authenticator2
Google Chrome Remote Desktop|com.google.chromeremotedesktop
Google Wear OS|com.google.android.wearable.app
Google TV|com.google.android.videos
Google Stadia|com.google.stadia.android
Google Santa Tracker|com.google.android.apps.santatracker
Google Gboard|com.google.android.inputmethod.latin
Google Pinyin|com.google.android.inputmethod.pinyin
Google Indic Keyboard|com.google.android.apps.inputmethod.hindi
Microsoft Word|com.microsoft.office.word
Microsoft Excel|com.microsoft.office.excel
Microsoft PowerPoint|com.microsoft.office.powerpoint
Microsoft Office|com.microsoft.office.officehubrow
Microsoft OneNote|com.microsoft.office.onenote
Microsoft OneDrive|com.microsoft.skydrive
Microsoft To Do|com.microsoft.todos
Microsoft Planner|com.microsoft.planner
Microsoft SharePoint|com.microsoft.sharepoint
Microsoft Lens|com.microsoft.office.officelens
Microsoft Authenticator|com.azure.authenticator
Microsoft Launcher|com.microsoft.launcher
Microsoft SwiftKey|com.touchtype.swiftkey
Microsoft Copilot|com.microsoft.copilot
Microsoft Loop|com.microsoft.loop
Microsoft Whiteboard|com.microsoft.whiteboard
Microsoft Stream|com.microsoft.stream
Microsoft Yammer|com.yammer.v1
Microsoft Remote Desktop|com.microsoft.rdc.androidx
Microsoft Xbox|com.microsoft.xboxone.smartglass
Xbox Game Pass|com.gamepass
Microsoft Math|com.microsoft.math
Microsoft Clipchamp|com.microsoft.clipchamp
Microsoft Kaizala|com.microsoft.mobile.polymer
Microsoft Intune|com.microsoft.windowsintune.companyportal
Microsoft Defender|com.microsoft.scmx
Notion|notion.id
Evernote|com.evernote
Obsidian|md.obsidian
Joplin|net.cozic.joplin
Simplenote|com.automattic.simplenote
Standard Notes|com.standardnotes
Bear|net.shinyfrog.bear
Zoho Notebook|com.zoho.notebook
Samsung Notes|com.samsung.android.app.notes
Colornote|com.socialnmobile.dictapps.notepad.color.note
Todoist|com.todoist
Any.do|com.anydo
TickTick|com.ticktick.task
Things|com.culturedcode.things
Trello|com.trello
Asana|com.asana.app
Monday|com.monday.monday
ClickUp|co.clickup.app
Jira|com.atlassian.android.jira.core
Confluence|com.atlassian.android.confluence.core
Basecamp|com.basecamp.bc3
Airtable|com.formagrid.airtable
Coda|io.coda.coda
Miro|com.miro.android
Figma|com.figma.mirror
Adobe Express|com.adobe.spark.post
Adobe Acrobat|com.adobe.reader
Adobe Scan|com.adobe.scan.android
Adobe Fresco|com.adobe.fresco
Adobe Illustrator Draw|com.adobe.creativeapps.draw
Adobe Creative Cloud|com.adobe.creativeapps.gather
Prisma|com.neuralprisma
Facetune 2|com.lightricks.facetune
Photoleap|com.lightricks.pixaloop
YouCam Makeup|com.perfectcorp.ycf
Ulike|com.ulike.app
SODA Camera|com.snowcorp.soda.android
Camera360|vStudio.Android.Camera360
Sweet Selfie|com.ufoto.selfie
Ufoto Photo Editor|com.ufotosoft.photoeditor
VN Video Editor|com.frontrow.vlog
GoPro|com.gopro.smarty
Splice|com.videoeditorpro.android
Funimate|com.avcrbt.funimate
Vita|com.vitavideo.app
Mojo|video.mojo
Zoomerang|com.zoomerang.app
Videoshop|com.videoshop.app
Cymera|com.cyworld.camera
Phonto|com.youthhr.Phonto
PicsArt Color|com.picsart.draw
Ibis Paint X|jp.ne.ibis.ibispaintx.app
Procreate Pocket|com.procreate.pocket
Sketchbook|com.adsk.sketchbook
Medibang Paint|com.medibang.android.paint.tablet
Clip Studio Paint|jp.co.celsys.clipstudiopaint
Infinite Painter|com.brakefield.painter
Tayasui Sketches|com.tayasui.sketches
Pixel Studio|com.PixelStudio
Dotpict|jp.cyberagent.dotpict
Pixilart|com.pixilart.android
Aseprite Mobile|com.aseprite.mobile
Photopea|com.photopea.android
Pixlr|com.pixlr.express
Fotor|com.everimaging.photoeffectstudio
Photo Collage Maker|com.photocollage.maker
PicCollage|com.cardinalblue.piccollage.google
Layout from Instagram|com.instagram.layout
Boomerang from Instagram|com.instagram.boomerang
Hyperlapse|com.instagram.hyperlapse
Unfold|com.unfold.app
Storyart|com.storyart.app
Mojo Story|com.mojo.story
Preview App|com.preview.app
Later|com.later.app
Buffer|org.buffer.android
Hootsuite|com.hootsuite.droid.full
Linktree|com.linktree.app
Bitly|com.bitly.app
QR Code Reader|com.scanner.qr
QR Scanner|com.gamma.scan
Barcode Scanner|com.google.zxing.client.android
CamScanner|com.intsig.camscanner
Scanbot|net.doo.snap
Tiny Scanner|com.appxy.tinyscanner
Genius Scan|com.thegrizzlylabs.geniusscannerapp
WPS Office|cn.wps.moffice_eng
Polaris Office|com.infraware.office.link
OfficeSuite|com.mobisystems.office
Docs To Go|com.dataviz.docstogo
Foxit PDF|com.foxit.mobile.pdf.lite
Xodo PDF|com.xodo.pdf.reader
PDF Reader Pro|com.pdfreaderpro.android
PDF Expert|com.pdfexpert.android
ReadEra|org.readera
Moon Reader|com.flyersoft.moonreaderp
FBReader|org.geometerplus.zlibrary.ui.android
Lithium|com.faultexception.reader
Librera|com.foobnix.pdf.reader
Cool Reader|org.coolreader
KOReader|org.koreader.launcher
Dropbox|com.dropbox.android
"""
    private const val Q2 = """
Box|com.box.android
Mega|mega.privacy.android.app
pCloud|com.pcloud.pcloud
Sync.com|com.sync.mobile
Mediafire|com.mediafire.android
WeTransfer|com.wetransfer.app.live
Send Anywhere|com.estmob.android.sendanywhere
Shareit|com.lenovo.anyshare.gps
Xender|cn.xender
Zapya|com.dewmobile.kuaiya.play
Solid Explorer|pl.solidexplorer2
Total Commander|com.ghisler.android.TotalCommander
FX File Explorer|nextapp.fx
ES File Explorer|com.estrongs.android.pop
Mixplorer|com.mixplorer
Amaze File Manager|com.amaze.filemanager
Material Files|me.zhanghai.android.files
X-plore|com.lonelycatgames.Xplore
CX File Explorer|com.cxinventor.file.explorer
File Manager Plus|com.alphainventor.filemanager
Ghost Commander|com.ghostsq.commander
Root Explorer|com.speedsoftware.rootexplorer
ZArchiver|ru.zdevs.zarchiver
RAR|com.rarlab.rar
WinZip|com.winzip.android
7Zipper|org.joa.zipperplus7
B1 Archiver|com.b1.archiver
CCleaner|com.piriform.ccleaner
Avast Cleanup|com.avast.android.cleaner
AVG Cleaner|com.antivirus.cleaner
Clean Master|com.cleanmaster.mguard
Cheetah Mobile|com.cmcm.live
SD Maid|eu.thedarken.sdm
Norton Clean|com.symantec.cleaner
Greenify|com.oasisfeng.greenify
Island|com.oasisfeng.island
Shelter|net.typeblog.shelter
Tasker|net.dinglisch.android.taskerm
Automate|com.llamalab.automate
MacroDroid|com.arlosoft.macrodroid
IFTTT|com.ifttt.ifttt
Zapier|com.zapier.android
Bixby Routines|com.samsung.android.app.routines
Samsung Good Lock|com.samsung.android.goodlock
Nova Launcher|com.teslacoilsw.launcher
Action Launcher|com.actionlauncher.playstore
Lawnchair|app.lawnchair
Niagara Launcher|bitpit.launcher
Smart Launcher|ginlemon.flowerfree
Evie Launcher|is.shortcut
Apex Launcher|com.anddoes.launcher
Poco Launcher|com.mi.android.globallauncher
Hyperos Launcher|com.miui.home
Microsoft Launcher Beta|com.microsoft.launcher.beta
Hola Launcher|com.hola.launcher
Pixel Launcher|com.google.android.apps.nexuslauncher
One UI Home|com.sec.android.app.launcher
Realme Launcher|com.android.launcher
OxygenOS Launcher|net.oneplus.launcher
Oppo Launcher|com.oppo.launcher
Huawei Home|com.huawei.android.launcher
Vivo Launcher|com.bbk.launcher2
Zenui Launcher|com.asus.launcher
Kvaesitso|de.mm20.launcher2.release
Olauncher|app.olauncher
Minimalist Phone|com.slavabarkov.minimalistphone
Before Launcher|com.chimbori.before
Wallpaper Engine|com.wallpaperengine.android
Zedge|net.zedge.android
Walli|com.walli.app
Backdrops|com.backdrops.wallpapers
Muzei|net.nurik.roman.muzei
Pixel Wallpapers|com.google.android.apps.wallpaper
Tapet|com.sharpregion.tapet
Backgrounds HD|com.hd.backgrounds
4D Live Wallpaper|com.wallpaper4d.android
Live Wallpapers HD|com.livewallpapers.hd
Ringtone Maker|com.ringtonemaker.android
Audio Editor|com.audioeditor.android
Lexis Audio Editor|com.pamsys.lexisaudioeditor
WaveEditor|com.waveeditor.android
BandLab|com.bandlab.bandlab
GarageBand|com.apple.GarageBand
FL Studio Mobile|com.imageline.FLM
Soundtrap|com.soundtrap.android
Walk Band|com.gamestar.pianoperfect
Groovepad|com.easybrain.groovepad
Beat Maker Pro|com.beatmaker.pro
Drum Pads 24|com.edjing.drumpads
Edjing Mix|com.edjing.edjingdjturntable
DJ Studio|com.djstudio.android
Cross DJ|com.mixvibes.crossdj
Virtual DJ|com.virtualdj.android
Spotify for Artists|com.spotify.artists
Smart Tools|kr.aboy.tools
Ruler App|com.grymala.ruler
Measure|com.google.android.apps.measure
Bubble Level|com.gamma.level
Compass|com.compass.android
Flashlight|com.devhd.flashlight
Torch|com.torch.android
Sound Meter|com.soundmeter.android
Decibel X|com.skypaw.decibel
Unit Converter|com.unitconverter.android
Currency Converter|com.currencyconverter.android
XE Currency|com.xe.currency
Calculator Plus|com.calculatorplus.android
Mathway|com.mathway.mathway
Symbolab|com.symbolab.symbolablibrary
Desmos|com.desmos.calculator
GeoGebra|org.geogebra.android
Socrative|com.socrative.student
Gauth|com.bytedance.gauth
Question AI|com.questionai.android
Drops|com.languagedrops.drops.scrolling
LingoDeer|com.lingodeer
Speak|com.selabs.speak
Elsa Speak|us.nobarriers.elsa
Rosetta Stone|com.rosettastone.mobile.language
Cake|com.cake.app
Lingq|com.lingq.app
AnkiApp|net.ankiweb.ankiapp
Khan Academy Kids|org.khankids.app
LinkedIn Learning|com.linkedin.android.learning
Codecademy Go|com.ryzac.codecademygo
Sololearn|com.sololearn
Mimo|com.getmimo
Grasshopper|com.area120.grasshopper
Programming Hub|com.freeit.java
Enki|com.enki.app
Blinkist|com.blinkslabs.blinkist.android
Headway|com.headway.books
StoryGraph|com.thestorygraph.app
Wikipedia Beta|org.wikipedia.beta
Wiktionary|org.wiktionary.app
Dictionary.com|com.dictionary
Merriam-Webster|com.merriamwebster
Oxford Dictionary|com.oxfordlearnersdictionaries
Cambridge Dictionary|com.cambridge.dictionary
Tureng|com.tureng.android
Tureng Sozluk|com.tureng.sozluk
DeepL|com.deepl.mobiletranslator
Reverso|com.softissimo.reverso.context
Papago|com.naver.labs.translator
Microsoft Translator|com.microsoft.translator
iTranslate|com.itranslate.translationapp
SayHi|com.sayhi.android
Linguee|com.linguee.android
Collins Dictionary|com.collins.dictionary
TDK Sozluk|tr.gov.tdk.sozluk
Turkce Sozluk|com.turkcesozluk.android
Eksi Sozluk|com.eksisozluk.android
Inci Sozluk|com.incisozluk.android
Uludag Sozluk|com.uludagsozluk.android
Ekşi Şeyler|com.eksiseyler.android
Onedio|com.onedio.android
Webtekno|com.webtekno.android
Donanimhaber|com.donanimhaber.android
Shiftdelete|com.shiftdelete.android
Technopat|com.technopat.android
Chip Online|com.chiponline.android
Log|com.log.android
Merge Dergisi|com.mergedergisi.android
Capital|com.capital.android
Ekonomim|com.ekonomim.android
Dunya Gazetesi|com.dunya.android
Bloomberg HT|com.bloomberght.android
Foreks Haber|com.foreks.haber
Raya|com.raya.app
The League|com.theleague.app
Boo|enterprises.dating.boo
Meetic|com.meetic.app
eHarmony|com.eharmony
Zoosk|com.zoosk.zaa
Elite Singles|com.elitesingles.app
Tantan|com.p1.mobile.putong
Momo|com.immomo.momo
Chatroulette|com.chatroulette.app
Omegle|com.omegle.app
Monkey|com.monkey.app
Holla|com.holla.app
Skout|com.skout.android
MeetMe|com.myyearbook.m
Tagged|com.tagged
Ourtime|com.ourtime.app
Hawaya|com.hawaya.app
Minder|com.minder.app
Bumble BFF|com.bumble.bff
Meetup|com.meetup
Eventbrite|com.eventbrite.attendee
Bilet.com|com.biletcom.android
Biletix|com.biletix.android
Passo|com.passo.android
Passolig|com.passolig.android
Mobilet|com.mobilet.android
Bubilet|com.bubilet.android
Tickettack|com.tickettack.android
Pegasus|com.pegasus.android
AJet|com.ajet.android
SunExpress|com.sunexpress.android
Corendon|com.corendon.android
Enuygun|com.enuygun.android
Biletall|com.biletall.android
Flypgs|com.flypgs.android
Hotels.com|com.hotels.android
Ctrip|ctrip.android.view
Skiplagged|com.skiplagged.app
Cheapflights|com.cheapflights.app
Travelocity|com.travelocity.android
Priceline|com.priceline.android.negotiator
Orbitz|com.orbitz.android
Qatar Airways|com.qatarairways.app
Etihad|com.etihad.mobile
Vueling|com.vueling.app
Southwest|com.southwest.mobile
Cathay Pacific|com.cathaypacific.android
Saudia|com.saudia.app
Flydubai|com.flydubai.android
Air Arabia|com.airarabia.android
Aegean|com.aegeanair.app
Organic Maps|app.organicmaps
OsmAnd|net.osmand.plus
Sygic|com.sygic.aura
TomTom GO|com.tomtom.gplay.navapp
Transit|com.thetransitapp.droid
Istanbulkart|tr.com.ibb.istanbulkart
Mobiett|tr.com.ibb.mobiett
IBB Cepte|tr.gov.ibb.cepte
Ibb Trafik|tr.gov.ibb.trafik
Istanbul Kart Mobil|tr.com.ibb.kartmobil
Metro Istanbul|tr.com.metro.istanbul
Marmaray|tr.gov.tcdd.marmaray
TCDD Bilet|tr.gov.tcdd.bilet
TCDD Tasimacilik|tr.gov.tcdd.tasimacilik
Ankara Cepte|tr.gov.ankara.cepte
EGO Cepte|tr.gov.ankara.ego
Izmir Kart|tr.gov.izmir.kart
Eshot Cepte|tr.gov.izmir.eshot
Bursa Kart|tr.gov.bursa.kart
Antalya Kart|tr.gov.antalya.kart
Konya Kart|tr.gov.konya.kart
BiTaksi|com.bitaksi.android
iTaksi|com.itaksi.android
Martı|com.marti.android
Marti Scooter|com.marti.scooter
Hop|com.hop.scooter
Binbin|com.binbin.scooter
Dott|com.dott.scooter
Tier|com.tier.app
Voi|com.voi.app
Spin|com.spin.app
Zipcar|com.zipcar.android
Turo|com.turo.app
Getaround|com.getaround.app
Flixbus|de.meinfernbus
Omio|com.omio.android
Rome2Rio|com.rome2rio.android
Wanderlog|com.wanderlog.android
TripIt|com.tripit
Ulmon|com.ulmon.android
Maps Offline|com.mapsoffline.android
Fuelio|com.kajda.fuelio
GasBuddy|gbis.gbandroid
Petrol Ofisi|com.petrolofisi.android
Opet|com.opet.android
Shell Turkiye|com.shell.tr
BP Turkiye|com.bp.tr
Total Turkiye|com.total.tr
Aytemiz|com.aytemiz.android
TP Petrol|com.tppetrol.android
Moil|com.moil.android
OtoYol|com.otoyol.android
Hgs|com.hgs.android
OGS|com.ogs.android
KGM|tr.gov.kgm.android
Tasit Net|com.tasitnet.android
Sigorta Net|com.sigortanet.android
Turkiye Sigorta|com.turkiyesigorta.android
Anadolu Sigorta|com.anadolusigorta.android
Allianz Turkiye|com.allianz.tr
Axa Sigorta|com.axa.tr
Mapfre Sigorta|com.mapfre.tr
Aksigorta|com.aksigorta.android
Sompo Sigorta|com.sompo.tr
Hdi Sigorta|com.hdi.tr
Neova|com.neova.android
Ray Sigorta|com.raysigorta.android
Quick Sigorta|com.quicksigorta.android
Bupa Acibadem|com.bupa.tr
Acibadem|com.acibadem.android
Memorial|com.memorial.android
Medicana|com.medicana.android
Liv Hospital|com.livhospital.android
Medipol|com.medipol.android
Florence Nightingale|com.florence.android
Doktor Takvimi|com.doktortakvimi.android
Doktorsitesi|com.doktorsitesi.android
Ilacim|com.ilacim.android
Ilac Rehberi|com.ilacrehberi.android
Eczane Nobet|com.eczanenobet.android
Nobetci Eczane|com.nobetcieczane.android
Medscape|com.medscape.android
WebMD|com.webmd.android
Healthline|com.healthline.android
Mayo Clinic|com.mayoclinic.patient
Teladoc|com.teladoc.members
Doctolib|com.doctolib.android
Practo|com.practo.fabric
MyChart|epic.mychart.android
Zocdoc|com.zocdoc.android
GoodRx|com.goodrx
Drugs.com|com.drugs.android
Epocrates|com.epocrates
UpToDate|com.uptodate.android
Visible Body|com.visiblebody.android
Complete Anatomy|com.completeanatomy.android
Pill Reminder|com.pillreminder.android
Medisafe|com.medisafe.android.client
MyTherapy|eu.smartpatient.mytherapy
Dosecast|com.montunosoftware.dosecast
Blood Pressure|com.bloodpressure.android
Cardiio|com.cardiio.android
Heart Rate Monitor|com.heartrate.android
Welltory|com.welltory.android
Elevate|com.wonder.elevate
Lumosity|com.lumoslabs.lumosity
Peak Brain|com.synaptic.peak
Impulse Brain|com.impulse.brain
Wysa|bot.touchkin
Woebot|com.woebot.app
BetterHelp|com.betterhelp.app
Talkspace|com.talkspace.app
Cerebral|com.cerebral.app
Finch|com.finch.app
Daylio|net.daylio
Reflectly|com.reflectly.app
Moodfit|com.moodfit.app
How We Feel|com.howwefeel.app
Bearable|com.bearable.app
Stoic|com.stoic.app
Shine|com.shine.app
Ten Percent Happier|com.tenpercent.app
Aura|com.aura.app
Waking Up|com.wakingup.app
Meditopia|com.meditopia.android
Atom|com.atom.app
Yogaglo|com.yogaglo.android
Down Dog|com.downdogapp.yoga
Glo|com.glo.app
Daily Yoga|yogaworkout.dailyyoga.go.weightloss.fitness
Asana Rebel|com.asanarebel.app
Fitness Buddy|com.fitnessbuddy.app
Sweatcoin|in.sweatco.app
Stepn|com.stepn.app
Walkr|com.walkr.app
Pacer|cc.pacer.androidapp
Stepz|com.stepz.app
Step Counter|com.stepcounter.android
Home Workout|homeworkout.homeworkouts.noequipment
Leap Fitness|loseweight.weightloss.workout.fitness
Lose Weight App|loseweight.weightloss.simple.fitness
Six Pack in 30 Days|abs.workout.sixpack
Sworkit|com.sworkit.app
Freeletics|com.freeletics.lite
Fitbod|com.fitbod.app
Strong|io.strongapp.strong
Hevy|com.hevy.app
JEFIT|je.fit
StrongLifts|com.stronglifts.app
Gymshark|com.gymshark.app
Planet Fitness|com.pf.app
Anytime Fitness|com.anytime.app
Gold's Gym|com.goldsgym.app
Fitbit Coach|com.fitbit.coach
Apple Fitness|com.apple.fitness
Nike Training Club|com.nike.ntc
Les Mills|com.lesmills.app
Obe Fitness|com.obe.app
Aaptiv|com.aaptiv.android
Beachbody|com.beachbody.app
Centr|com.centr.app
Fiit|com.fiit.app
Tonal|com.tonal.app
Mirror|com.mirror.app
Hydro Coach|com.hydrocoach.android
Water Reminder|com.waterreminder.android
Waterllama|com.waterllama.app
Plant Nanny|com.plantnanny.android
Forest|cc.forestapp
Focus To-Do|com.focus.todo
Flora|com.flora.app
Pomodoro Timer|com.pomodoro.android
Opal|com.opal.app
Freedom|com.freedom.app
Stay Focused|com.stayfocused.app
Digital Wellbeing|com.google.android.apps.wellbeing
ActionDash|com.actiondash.playstore
Screen Time|com.screentime.android
Qustodio|com.qustodio.qustodioapp
Bark|com.bark.app
Norton Family|com.symantec.familysafety
Kidslox|com.kidslox.app
FamiSafe|com.wondershare.famisafe
Net Nanny|com.netnanny.app
Kaspersky Safe Kids|com.kaspersky.safekids
Mobicip|com.mobicip.app
Screen Time Parental Control|com.screentime.parental
Life360|com.life360.android.safetymapd
Find My Device|com.google.android.apps.adm
Find My Kids|org.findmykids.app
Zenly|app.zenly.locator
Glympse|com.glympse.android.glympse
Geozilla|com.geozilla.family
Tile|com.thetileapp.tile
Airtag|com.apple.airtag
Samsung SmartThings|com.samsung.android.oneconnect
SmartThings Find|com.samsung.android.plugin.fme
Mi Home|com.xiaomi.smarthome
Tuya Smart|com.tuya.smart
Smart Life|com.tuya.smartlife
Philips Hue|com.philips.lighting.hue2
Ring|com.ringapp
Arlo|com.arlo.app
Wyze|com.hualai
Eufy Security|com.oceanwing.battery.cam
Nest|com.nest.android
Blink Home Monitor|com.immediasemi.android.blink
Tapo|com.tplink.iot
Kasa Smart|com.tplink.kasa_android
TP-Link Tether|com.tplink.tether
Deco|com.tplink.tpm.deco
Netgear Nighthawk|com.netgear.netgearup
Asus Router|com.asus.aihome
Huawei AI Life|com.huawei.smarthome
Zyxel|com.zyxel.android
Fing|com.overlook.android.fing
WiFi Analyzer|com.farproc.wifi.analyzer
Speedtest|org.zwanoo.android.speedtest
Fast.com|com.netflix.fast
OpenSignal|com.staircase3.opensignal
Wifi Map|io.wifimap.wifimap
Instabridge|com.instabridge.android
Wifi Master Key|com.snda.wifilocating
Wifi Password Show|com.wifipassword.android
Netspot|com.netspot.android
Termux|com.termux
Termux API|com.termux.api
Termux Styling|com.termux.styling
Termux Boot|com.termux.boot
Termux Widget|com.termux.widget
"""
    private const val Q3 = """
Termux Float|com.termux.window
JuiceSSH|com.sonelli.juicessh
ConnectBot|org.connectbot
Termius|com.server.auditor.ssh.client
Blink Shell|com.blinkshell.android
Prompt|com.panic.prompt
Python Interpreter|org.qpython.qpy3
Pydroid 3|ru.iiec.pydroid3
QPython|org.qpython.qpy
Acode|com.foxdebug.acode
Spck Editor|io.spck
Dcoder|com.dcoder.android
Mobile C|com.mobilec.android
Java Compiler|com.javacompiler.android
AIDE|com.aide.ui
Code Editor|com.codeeditor.android
Github|com.github.android
GitLab|com.gitlab.android
Bitbucket|com.bitbucket.android
Stack Overflow|com.stackexchange.stackoverflow
Hacker Keyboard|org.pocketworkstation.pckeyboard
Android Studio Bot|com.google.android.studio
Firebase Console|com.google.firebase.console
Play Console|com.google.android.apps.playconsole
Google Analytics|com.google.android.apps.giant
Google Search Console|com.google.android.apps.search.console
Google Ads|com.google.android.apps.ads.publisher
Google AdSense|com.google.android.apps.adsense
Admob|com.google.android.apps.admob
Google My Business|com.google.android.apps.vega
Google Pay Business|com.google.android.apps.nbu.paisa.merchant
Shopify|com.shopify.mobile
Square|com.squareup
Stripe Dashboard|com.stripe.android.dashboard
Wix|com.wix.android
Wordpress|org.wordpress.android
Blogger|com.google.android.apps.blogger
Squarespace|com.squarespace.android
Weebly|com.weebly.android
Ghost|com.ghost.android
Jetpack|com.jetpack.android
Gravatar|com.gravatar.android
Woocommerce|com.woocommerce.android
Magento|com.magento.android
Prestashop|com.prestashop.android
Ikas|com.ikas.android
Ticimax|com.ticimax.android
Tsoft|com.tsoft.android
Ideasoft|com.ideasoft.android
Parasut|com.parasut.android
Logo Isbasi|com.logo.isbasi
Mikro|com.mikro.android
Luca|com.luca.android
Netsis|com.netsis.android
Zirve|com.zirve.android
Trendyol Satici|com.trendyol.satici
Hepsiburada Satici|com.hepsiburada.satici
N11 Satici|com.n11.satici
Amazon Satici|com.amazon.satici
Sahibinden Magaza|com.sahibinden.magaza
Yemeksepeti Restoran|com.yemeksepeti.restoran
Getir Isletme|com.getir.isletme
NordVPN|com.nordvpn.android
ExpressVPN|com.expressvpn.vpn
Surfshark|com.surfshark.vpnclient.android
ProtonVPN|ch.protonvpn.android
Proton Drive|me.proton.android.drive
Proton Pass|proton.android.pass
Proton Calendar|me.proton.android.calendar
CyberGhost|de.mobileconcepts.cyberghost
Private Internet Access|com.privateinternetaccess.android
Windscribe|com.windscribe.vpn
TunnelBear|com.tunnelbear.android
Hotspot Shield|hotspotshield.android.vpn
Turbo VPN|free.vpn.unblock.proxy.turbovpn
Super VPN|com.jrzheng.supervpnfree
Betternet|com.freevpn.betternet
Hola VPN|org.hola
Psiphon|com.psiphon3
Psiphon Pro|com.psiphon3.subscription
Thunder VPN|com.fast.free.unblock.thunder.vpn
Snap VPN|com.snapvpn.android
VPN Master|com.freevpnintouch
X-VPN|com.xvpn.android
Urban VPN|com.urbanvpn.android
Planet VPN|com.planetvpn.android
Hide.me|com.hideme.android
IPVanish|com.ipvanish.android
Mullvad|net.mullvad.mullvadvpn
Cloudflare Warp|com.cloudflare.onedotonedotonedotone
Wireguard|com.wireguard.android
OpenVPN Connect|net.openvpn.openvpn
OpenVPN for Android|de.blinkt.openvpn
Intra|app.intra
Adguard|com.adguard.android
AdGuard VPN|com.adguard.vpn
Blokada|org.blokada.alarm
NextDNS|io.nextdns.app
DNS Changer|com.dnschanger.android
DNSFast|com.dnsfast.android
Lava DNS|com.lavadns.android
Personal DNS|com.personaldns.android
Private DNS|com.privatedns.android
Netguard|eu.faircode.netguard
RethinkDNS|com.celzero.bravedns
TrackerControl|net.kollnig.missioncontrol
Net Monitor|com.netmonitor.android
Glasswire|com.glasswire.android
Data Monitor|com.datamonitor.android
My Data Manager|com.mydatamanager.android
Datally|com.google.android.apps.datally
Opera Max|com.opera.max.global
Avast Mobile Security|com.avast.android.mobilesecurity
AVG Antivirus|com.antivirus
Kaspersky|com.kms.free
Norton 360|com.symantec.mobilesecurity
McAfee Security|com.wsandroid.suite
Bitdefender|com.bitdefender.security
ESET Mobile Security|com.eset.ems2.gp
Malwarebytes|org.malwarebytes.antimalware
Sophos Intercept|com.sophos.smsec
Trend Micro|com.trendmicro.tmmspersonal
Lookout|com.lookout
Avira Security|com.avira.android
Dr.Web|com.drweb.pro
360 Security|com.qihoo.security
Webroot|com.webroot.security
F-Secure|com.fsecure.ms.dc
Total AV|com.totalav.android
Security Master|com.cleanmaster.security
Lastpass|com.lastpass.lpandroid
1Password|com.onepassword.android
Bitwarden|com.x8bit.bitwarden
Dashlane|com.dashlane
Keeper|com.callpod.android_apps.keeper
Nordpass|com.nordpass.android.app.password.manager
Keepass2Android|keepass2android.keepass2android
KeePassDX|com.kunzisoft.keepass.free
Enpass|io.enpass.app
Aegis Authenticator|com.beemdevelopment.aegis
Authy|com.authy.authy
Duo Mobile|com.duosecurity.duomobile
Twilio Authy|com.twilio.authy
Okta Verify|com.okta.android.auth
2FAS|com.twofasapp
Hiya|com.hiya.app
CallApp|com.callapp.contacts
Mr Number|com.mrnumber.blocker
Call Blocker|com.callblocker.android
Should I Answer|org.mavopl.shouldianswer
Whatscall|com.whatscall.android
Simple Contacts|com.simplemobiletools.contacts.pro
Simple Gallery|com.simplemobiletools.gallery.pro
Simple Calendar|com.simplemobiletools.calendar.pro
Simple Notes|com.simplemobiletools.notes.pro
Simple SMS Messenger|com.simplemobiletools.smsmessenger
Simple Dialer|com.simplemobiletools.dialer
Simple Keyboard|rkr.simplekeyboard.inputmethod
Simple File Manager|com.simplemobiletools.filemanager.pro
Fossify Gallery|org.fossify.gallery
Fossify Messages|org.fossify.messages
Fossify Phone|org.fossify.phone
Fossify Contacts|org.fossify.contacts
Fossify Calendar|org.fossify.calendar
Fossify Notes|org.fossify.notes
Fossify Clock|org.fossify.clock
Fossify Files|org.fossify.filemanager
Fossify Music|org.fossify.musicplayer
Fossify Camera|org.fossify.camera
Fossify Voice Recorder|org.fossify.voicerecorder
Fossify Calculator|org.fossify.math
Fossify Launcher|org.fossify.home
AnySoftKeyboard|com.menny.android.anysoftkeyboard
OpenBoard|org.dslul.openboard.inputmethod.latin
FlorisBoard|dev.patrickgold.florisboard
Fleksy|com.syntellia.fleksy.keyboard
Grammarly|com.grammarly.android.keyboard
Samsung Keyboard|com.samsung.android.honeyboard
Xiaomi Keyboard|com.baidu.input_mi
Baidu Input|com.baidu.input
Sogou Input|com.sohu.inputmethod.sogou
Go Keyboard|com.jb.emoji.gokeyboard
Kika Keyboard|com.qisiemoji.inputmethod
Facemoji|com.simejikeyboard
Typewise|ch.icoaching.typewise
TouchPal|com.cootek.smartinputv5
Ginger Keyboard|com.gingersoftware.android.keyboard.inputmethod
Chrooma|com.chrooma.keyboard
Bobble|com.touchtalent.bobbleapp
Emoji Keyboard|com.emoji.keyboard.touchpal
Samsung Camera|com.sec.android.app.camera
Samsung Gallery|com.sec.android.gallery3d
Samsung Dialer|com.samsung.android.dialer
Samsung Messages|com.samsung.android.messaging
Samsung Contacts|com.samsung.android.app.contacts
Samsung Calendar|com.samsung.android.calendar
Samsung Clock|com.sec.android.app.clockpackage
Samsung Calculator|com.sec.android.app.popupcalculator
Samsung My Files|com.sec.android.app.myfiles
Samsung Voice Recorder|com.sec.android.app.voicenote
Samsung Reminder|com.samsung.android.app.reminder
Samsung Cloud|com.samsung.android.scloud
Samsung Members|com.samsung.android.voc
Samsung Smart Switch|com.sec.android.easyMover
Samsung Free|com.samsung.android.app.spage
Samsung TV Plus|com.samsung.android.tvplus
Samsung Music|com.sec.android.app.music
Samsung Video|com.samsung.android.video
Samsung Game Launcher|com.samsung.android.game.gamehome
Samsung Game Booster|com.samsung.android.game.gametools
Samsung Galaxy Store|com.sec.android.app.samsungapps
Samsung Wearable|com.samsung.android.app.watchmanager
Samsung DeX|com.sec.android.desktopmode.uiservice
Samsung Bixby|com.samsung.android.bixby.agent
Samsung Bixby Vision|com.samsung.android.visionintelligence
Samsung Internet Beta|com.sec.android.app.sbrowser.beta
Samsung Pass|com.samsung.android.samsungpass
Samsung Health Monitor|com.samsung.android.shealthmonitor
Samsung Kids|com.samsung.android.kidsinstaller
Samsung Secure Folder|com.samsung.knox.securefolder
Samsung Device Care|com.samsung.android.lool
Samsung Quick Share|com.samsung.android.app.sharelive
Samsung Wallpaper|com.samsung.android.wallpaper.live
Samsung Themes|com.samsung.android.themestore
Samsung Studio|com.samsung.android.app.sketchbook
Samsung PENUP|com.sec.penup
Samsung Max|com.samsung.max
Samsung Flow|com.samsung.android.galaxycontinuity
Samsung Link Sharing|com.samsung.android.app.simplesharing
Samsung Care|com.samsung.care
Mi Camera|com.android.camera
Mi Gallery|com.miui.gallery
Mi Dialer|com.android.contacts
Mi Messages|com.android.mms
Mi Calendar|com.android.calendar
Mi Clock|com.android.deskclock
Mi Calculator|com.miui.calculator
Mi File Manager|com.mi.android.globalFileexplorer
Mi Music|com.miui.player
Mi Video|com.miui.videoplayer
Mi Cloud|com.miui.cloudservice
Mi Community|com.xiaomi.vipaccount
Mi Store|com.xiaomi.shop
Mi Pay|com.mipay.wallet
Mi Remote|com.duokan.phone.remotecontroller
Mi Security|com.miui.securitycenter
Mi Cleaner|com.miui.cleaner
Mi Notes|com.miui.notes
Mi Recorder|com.android.soundrecorder
Mi Scanner|com.xiaomi.scanner
Mi Weather|com.miui.weather2
Mi Wallpaper|com.android.thememanager
Mi Game Turbo|com.miui.gamebooster
Mi GetApps|com.xiaomi.mipicks
Mi Mover|com.miui.huanji
Mi Share|com.miui.mishare.connectivity
Mi Roam|com.xiaomi.simactivate.service
Mi Video Editor|com.miui.videoeditor
Mi Compass|com.miui.compass
Mi Screen Recorder|com.miui.screenrecorder
Mi Browser Pro|com.mi.globalbrowser.mini
Poco Community|com.mi.global.pocophone
Redmi Wallpaper|com.miui.wallpaper
Huawei AppGallery|com.huawei.appmarket
Huawei Music|com.huawei.music
Huawei Video|com.huawei.himovie
Huawei Mobile Services|com.huawei.hwid
Huawei Cloud|com.huawei.hidisk
Huawei Themes|com.huawei.android.thememanager
Huawei Wallet|com.huawei.wallet
Huawei Camera|com.huawei.camera
Huawei Gallery|com.huawei.photos
Huawei Phone Clone|com.hicloud.android.clone
Huawei Petal Maps|com.huawei.maps.app
Petal Search|com.huawei.search
Petal Mail|com.huawei.email
Oppo Clone Phone|com.coloros.backuprestore
Oppo Game Space|com.coloros.gamespace
Oppo Theme Store|com.heytap.themestore
Oppo App Market|com.oppo.market
Oppo Browser|com.heytap.browser
Oppo Music|com.heytap.music
Oppo Video|com.heytap.yoli
Oppo Health|com.heytap.health
Oppo Cloud|com.heytap.cloud
Oppo Weather|com.coloros.weather
Realme Link|com.realme.link
Realme Community|com.realmecomm.app
Realme Store|com.realme.store
OnePlus Switch|com.oneplus.backuprestore
OnePlus Community|net.oneplus.forums
OnePlus Store|com.oneplus.store
OnePlus Gallery|com.oneplus.gallery
OnePlus Notes|com.oneplus.note
OnePlus Weather|net.oneplus.weather
Vivo Easyshare|com.vivo.easyshare
Vivo Browser|com.vivo.browser
Vivo App Store|com.vivo.appstore
Vivo Game Center|com.vivo.game
Vivo iManager|com.iqoo.secure
Vivo Themes|com.bbk.theme
Vivo Cloud|com.vivo.cloud
Vivo Pay|com.vivo.wallet
Vivo Health|com.vivo.health
Vivo Music|com.android.bbkmusic
Vivo Video|com.vivo.video
Honor Club|com.hihonor.club
Honor Phone Clone|com.hihonor.android.clone
Honor Magic Home|com.hihonor.magichome
Motorola Moto App|com.motorola.moto
Motorola Gallery|com.motorola.motgallery
Motorola Camera|com.motorola.camera3
Motorola Notifications|com.motorola.notification
Motorola Device Help|com.motorola.genie
Motorola Migrate|com.motorola.migrate
Motorola Ready For|com.motorola.mobiledesktop
Nokia Mobile Support|com.hmdglobal.support
Nokia Phone Care|com.hmdglobal.care
Sony Xperia Lounge|com.sonymobile.lounge
Sony Album|com.sonyericsson.album
Sony Music|com.sonyericsson.music
Sony Video|com.sonyericsson.video
Sony Camera Pro|com.sonymobile.cinemapro
Sony Photo Pro|com.sonymobile.photopro
Sony Imaging Edge|jp.co.sony.imagingedgemobile
Sony PlayStation App|com.scee.psxandroid
PlayStation Remote Play|com.playstation.remoteplay
PlayStation Messages|com.playstation.mobilemessenger
Steam Link|com.valvesoftware.steamlink
Steam Chat|com.valvesoftware.android.steam.friendsui
GOG Galaxy|com.gog.galaxy
Ubisoft Connect|com.ubisoft.uplay
EA App|com.ea.app
Origin|com.ea.origin
Battle.net|com.blizzard.bma
Nintendo Switch Online|com.nintendo.znca
Nintendo Switch Parental Controls|com.nintendo.znma
Nvidia GeForce Now|com.nvidia.geforcenow
Nvidia Shield|com.nvidia.shield.remote
Moonlight|com.limelight
Parsec|com.parsec.android
Steam Deck Remote|com.valvesoftware.steamdeck
Logitech G Hub|com.logitech.ghub
Razer Cortex|com.razer.cortex
Razer Nexus|com.razer.nexus
Remote Play Together|com.valve.remoteplay
Discord Overlay|com.discord.overlay
Overwolf|com.overwolf.android
Game Booster|com.gamebooster.android
Game Turbo|com.gameturbo.android
Gamepad Mapper|com.gamepadmapper.android
Panda Gamepad Pro|com.ofphoenix.pandagamepad
Octopus Gamepad|com.octopus.android
Mantis Gamepad|com.mantis.gamepad
Lite Xposed|org.lsposed.manager
Magisk|com.topjohnwu.magisk
KernelSU|me.weishu.kernelsu
Termux Root|com.termux.root
Shizuku|moe.shizuku.privileged.api
Mt Manager|bin.mt.plus
Lucky Patcher|com.chelpus.lackypatch
APKMirror|com.apkmirror.helper.prod
APKPure|com.apkpure.aegon
Aptoide|cm.aptoide.pt
Uptodown|com.uptodown
F-Droid|org.fdroid.fdroid
Droid-ify|com.looker.droidify
Neo Store|com.machiav3lli.fdroid
Aurora Store|com.aurora.store
Aurora Droid|com.aurora.adroid
9Apps|com.mobile.indiapp
GetJar|com.getjar.android
Amazon Appstore|com.amazon.venezia
Mobogenie|com.mobogenie
Happymod|com.happymod.apk
Panda Helper|com.pandahelper.android
Blackmart|org.blackmart.market
Mobile Store|com.mobilestore.android
ACMarket|com.acmarket.android
Tutuapp|com.tutu.app
Vidmate|com.nemo.vidmate
Snaptube|com.snaptube.premium
TubeMate|com.tubemate.android
Videoder|com.videoder.android
Seal|com.junkfood.seal
YTDLnis|com.deniscerri.ytdl
Instander|com.instander.android
Aero Instagram|com.aero.insta
GBWhatsapp|com.gbwhatsapp
FM Whatsapp|com.fmwhatsapp
Whatsapp Plus|com.whatsapp.plus
YoWhatsapp|com.yowhatsapp
OGWhatsapp|com.ogwhatsapp
Nekogram|nekox.messenger
Plus Messenger|org.telegram.plus
Telegraph|org.telegraph.app
Turbo Telegram|org.turbo.telegram
Graph Messenger|ir.ilmili.telegraph
Mobogram|org.mobogram.app
Teligram|org.teligram.app
Vidogram|com.vidogram.app
Anime Wallpaper|com.animewallpaper.android
Gogoanime|com.gogoanime.android
Aniwatch|com.aniwatch.android
9anime|com.nineanime.android
Animeflix|com.animeflix.android
Zoro|com.zoro.android
AniList|com.anilist.android
MyAnimeList|net.myanimelist
Kitsu|com.kitsu.android
Anime Planet|com.animeplanet.android
Tachiyomi|eu.kanade.tachiyomi
Mihon|app.mihon
Komikku|app.komikku
Manga Reader|com.mangareader.android
MangaDex|org.mangadex.app
Mangazone|com.mangazone.android
Manga Plus|jp.co.shueisha.mangaplus
Shonen Jump|com.viz.wsj.android
Comixology|com.iconology.comics
Marvel Unlimited|com.marvel.unlimited
DC Universe Infinite|com.dc.universe
Webcomics|com.webcomics.android
Lezhin|com.lezhin.comics
Toomics|com.toomics.global
Ridi|com.ridi.books
Kakao Webtoon|com.kakao.page
Piccoma|jp.kakao.piccoma
Line Manga|com.linecorp.linemanga
Line Music|jp.linecorp.linemusic.android
Line Camera|jp.naver.linecamera.android
Line Games|com.linecorp.games
Line Shopping|com.linecorp.shopping
Line TV|com.linecorp.linetv
Line Live|jp.naver.linelive
Mercari|com.kouzoh.mercari
Rakuten|jp.co.rakuten.android
Yahoo Japan|jp.co.yahoo.android.yjtop
Twitcasting|jp.co.twitcasting.android
Showroom|jp.co.showroom.android
17 Live|com.machipopo.media17
Pococha|jp.co.pococha.android
Mildom|com.mildom.android
Afreeca TV|com.afreecatv.mobile.sb
Naver Cafe|com.nhn.android.navercafe
Naver Blog|com.nhn.android.blog
Naver Maps|com.nhn.android.nmap
Kakao Map|net.daum.android.map
Kakao T|com.kakao.taxi
Kakao Game|com.kakaogames.gdts
"""
    private const val Q4 = """
Idle Office Tycoon|com.codigames.idleofficetycoon
Idle Supermarket Tycoon|com.codigames.idlesupermarkettycoon
Idle Airport Empire|com.codigames.idleairportempire
Idle Restaurant Tycoon|com.codigames.idlerestauranttycoon
Idle Theme Park|com.codigames.idlethemepark
Hotel Empire Tycoon|com.hotelempire.tycoon
Fast Food Simulator|com.fastfood.simulator
My Cafe|com.mycafe.android
Cooking Fever|com.nordcurrent.canteenhd
Cooking Diary|com.mytona.cookingdiary
Cooking City|com.cookingcity.android
Cooking Madness|com.cookingmadness.android
Restaurant Story|com.restaurantstory.android
Diner Dash|com.dinerdash.android
Papa's Pizzeria|com.flipline.papaspizzeria
Papa's Burgeria|com.flipline.papasburgeria
Papa Louie Pals|com.flipline.papalouiepals
Toca Kitchen 2|com.tocaboca.tocakitchen2
Avatar World|com.pazu.avatarworld
Bluey Let's Play|com.budgestudios.bluey
Peppa Pig World Adventures|com.entertainmentone.peppapig
Paw Patrol Rescue World|com.pawpatrol.rescueworld
Baby Shark World|com.smartstudy.babysharkworld
Pinkfong Baby Shark|com.smartstudy.babyshark
Cocomelon Play|com.cocomelon.play
Kids Songs|com.kidssongs.android
Little Panda Chef|com.sinyee.babybus.chef
BabyBus Kids|com.sinyee.babybus.world
Kiddopia|com.kiddopia.android
ABC Mouse|com.abcmouse.android
Endless Alphabet|com.originatorkids.EndlessAlphabet
Lego Duplo World|com.lego.duplo.world
Lego Tower|com.lego.tower
Lego Star Wars|com.lego.starwars
Lego Hill Climb|com.lego.hillclimb
Lego Builder's Journey|com.lego.builders
Ninjago Tournament|com.lego.ninjago
Barbie Dreamhouse|com.budgestudios.barbiedreamhouse
Barbie Fashion Closet|com.budgestudios.barbiefashion
Hello Kitty Nail Salon|com.hellokitty.nailsalon
Hello Kitty Lunchbox|com.hellokitty.lunchbox
My Little Pony|com.gameloft.android.ANMP.GloftMLHM
Sonic Dash 2|com.sega.sonicdash2
Angry Birds POP|com.rovio.pop
Angry Birds Match|com.rovio.angrybirdsmatch
Angry Birds Epic|com.rovio.angrybirdsepic
Mario Party Mobile|com.nintendo.mario.party
Candy Crush Friends Saga|com.king.candycrushfriends
Alphabetty Saga|com.king.alphabettysaga
Crash Bandicoot On the Run|com.king.crashbandicootonthe
Warcraft Arclight Rumble|com.blizzard.wowrumble.android
Overwatch Mobile|com.blizzard.overwatch
Gears POP|com.microsoft.gearspop
Halo Mobile|com.microsoft.halo
Forza Street|com.microsoft.forzastreet
Forza Horizon Mobile|com.microsoft.forzahorizon
Minecraft Earth|com.mojang.minecraftearth
Minecraft Dungeons|com.mojang.minecraftdungeons
Minecraft Legends|com.mojang.minecraftlegends
Mine Craft Pocket Lite|com.mojang.minecraftpelite
Craftsman Building Craft|com.craftsman.building
Lokicraft|com.lokicraft.android
Master Craft|com.mastercraft.android
Mini World Block Art|com.playmini.miniworld
Block Craft 3D|com.fungames.blockcraft
Crafting and Building|com.crafting.building
Exploration Lite Craft|com.explorationlite.craft
Growtopia|com.rtsoft.growtopia
Pixels|com.pixels.game
Sandbox|com.sandbox.mobile
Avakin Life|com.lockwood.avakinlife
IMVU|com.imvu.mobilecast
Second Life Mobile|com.secondlife.mobile
Zepeto|com.snowcorp.zepeto.group
Bloxburg|com.roblox.bloxburg
Brookhaven Mobile|com.roblox.brookhaven
Adopt Me Mobile|com.roblox.adoptme
Blox Fruits Mobile|com.roblox.bloxfruits
Rec Room|com.recroom.android
VRChat|com.vrchat.mobile
Gorilla Tag Mobile|com.gorillatag.mobile
Roblox Lite|com.roblox.client.lite
Subway Surfers Blast|com.kiloo.subwaysurfersblast
Subway Surfers City|com.kiloo.subwaycity
Temple Run Lite|com.imangi.templerunlite
Skate Space|com.skatespace.android
Tony Hawk Skate Jam|com.tonyhawk.skatejam
Skater Boy|com.skaterboy.android
Skate City|com.snowman.skatecity
Touchgrind Skate 2|com.illusionlabs.touchgrind2
Mad Skills Motocross 3|com.turbogames.madskills3
Trial Xtreme 4|com.deemedya.trialxtreme4
Moto X3M|com.motox3m.game
Bike Race Free|com.bikerace.free
Bike Stunt Master|com.bikestunt.master
Tricky Bike|com.trickybike.android
Stickman Hook|com.madbox.stickmanhook
Stickman Legends|com.stickman.legends
Stickman Party|com.stickman.party
Stick War Legacy|com.maxgames.stickwar
Stick Fight|com.stickfight.mobile
Draw Climber|com.draw.climber
Draw Joust|com.draw.joust
Brain Out|com.eyewind.brainout
Brain Test|com.unicostudio.braintest
Brain Test 2|com.unicostudio.braintest2
Brain Test 3|com.unicostudio.braintest3
Tricky Test|com.trickytest.android
Mind Games|com.mindgames.android
IQ Test|com.iqtest.android
Riddle Me This|com.riddleme.android
Find Differences|com.finddifferences.android
Hidden Objects|com.hiddenobjects.android
June's Journey|com.wooga.junes_journey
Seekers Notes|com.mismc.seekersnotes
Criminal Case|com.pretty.criminalcase
Criminal Case Mysteries|com.pretty.criminalcasemysteries
Hidden City|com.g5e.hiddencity
Mystery Case Files|com.g5e.mysterycasefiles
Escape Room|com.escaperoom.android
Escape Game|com.escapegame.android
Can You Escape|com.canyouescape.android
Room Escape|com.roomescape.android
The Room|com.fireproofstudios.theroom
The Room Two|com.fireproofstudios.theroom2
The Room Three|com.fireproofstudios.theroom3
The Witness|com.thekla.thewitness
Machinarium|air.net.machinarium.Machinarium.GP
Samorost|com.amanita.samorost
Botanicula|com.amanita.botanicula
Sword of Fargoal|com.swordoffargoal.android
Dungeon Keeper|com.ea.game.dungeonkeeper_row
Hero Wars|com.nexters.herowars
Hero Wars Alliance|com.nexters.herowarsalliance
Puzzle and Dragons|jp.gungho.padEN
Puzzle Quest 3|com.d3p.puzzlequest3
Marvel Puzzle Quest|com.demiurge.marvelpuzzlequest
Tiny Tower Vegas|com.nimblebit.tinytowervegas
Bit City|com.nimblebit.bitcity
Pocket Planes|com.nimblebit.pocketplanes
Pocket Trains|com.nimblebit.pockettrains
Airline Commander|com.airlinecommander.android
Airline Manager|com.airlinemanager.android
Flight Simulator|com.flightsim.android
Infinite Flight|com.infiniteflight.android
Real Flight Simulator|com.realflightsim.android
Microsoft Flight Mobile|com.microsoft.flightsim
RFS Real Flight|com.rortos.rfs
Turboprop Flight Sim|com.turboprop.flightsim
Airport City|com.gameinsight.airport
Airport Simulator|com.airportsim.android
Plane Crazy|com.planecrazy.android
Ships Simulator|com.shipsim.android
Ship Simulator|com.shipsimulator.android
Fishing Clash|com.ten.fishing
Fishing Planet|com.fishingplanet.android
Fishing Strike|com.fishingstrike.android
Fish Feed Grow|com.fishfeedgrow.android
Feed and Grow Fish|com.feedandgrowfish.android
Hungry Shark World|com.ubisoft.hungrysharkworld
Ice Scream|com.keplerians.icescream
Granny|com.dvloper.granny
Granny Chapter Two|com.dvloper.grannychapter2
Slendrina|com.dvloper.slendrina
Evil Nun|com.keplerians.evilnun
Horror Escape|com.horrorescape.android
Five Nights at Freddy's|com.scottgames.fnaf
Five Nights at Freddy's 2|com.scottgames.fnaf2
Five Nights at Freddy's 3|com.scottgames.fnaf3
Five Nights at Freddy's 4|com.scottgames.fnaf4
FNAF Sister Location|com.scottgames.fnafsl
FNAF World|com.scottgames.fnafworld
Poppy Playtime|com.mobgames.poppyplaytime
Garten of Banban|com.euphoriagames.banban
Baldi's Basics|com.mystman12.baldi
Doors Mobile|com.doors.mobile
The Backrooms|com.backrooms.mobile
Granny Horror|com.grannyhorror.android
Dead by Daylight Mobile|com.behaviour.dbd
Identity V|com.netease.dwrg
Project Winter|com.projectwinter.mobile
Werewolf Online|com.werewolfonline.android
Mafia|com.mafia.android
Town of Salem|com.townofsalem.android
Spyfall|com.spyfall.android
Skribbl|com.skribbl.android
Gartic Phone|com.garticphone.android
Draw Something|com.zynga.drawsomething
Pictionary|com.pictionary.android
Charades|com.charades.android
Heads Up|com.wb.headsup
Psych|com.psych.android
Trivia Crack 2|com.etermax.triviacrack2
Quiz Planet|com.quizplanet.android
QuizUp|com.quizup.android
Who Wants to Be a Millionaire|com.wwtbam.android
Kim Milyoner Olmak Ister|com.kmo.android
Bilgi Yarismasi|com.bilgiyarismasi.android
Kelime Oyunu|com.kelimeoyunu.android
Kelimelik|com.kelimelik.android
Kelime Avi|com.kelimeavi.android
Kelime Bahcesi|com.kelimebahcesi.android
Kelime Bulmaca|com.kelimebulmaca.android
Bulmaca|com.bulmaca.android
Capraz Bulmaca|com.caprazbulmaca.android
101 Okey|com.okey101.android
Okey Plus|com.okeyplus.android
Okey Live|com.okeylive.android
Batak Online|com.batakonline.android
Tavla Online|com.tavlaonline.android
Tavla Plus|com.tavlaplus.android
Pisti Online|com.pistionline.android
King Online|com.kingonline.android
Pişti Plus|com.pistiplus.android
Dama Online|com.damaonline.android
Satranc|com.satranc.android
Chess Free|com.chessfree.android
Chess Tactics Pro|com.chesstacticspro.android
Magnus Trainer|com.magnustrainer.android
Chess Royale|com.chessroyale.android
Backgammon Live|com.backgammonlive.android
Backgammon Galaxy|com.backgammongalaxy.android
Poker Texas Holdem|com.pokertexas.android
Texas HoldEm Poker|com.texasholdem.android
Governor of Poker|com.governorofpoker.android
Poker Stars|com.pokerstars.android
GG Poker|com.ggpoker.android
Blackjack 21|com.blackjack21.android
Jackpot Party|com.jackpotparty.android
Bingo Blitz|com.buffalo_studios.newbingo
Bingo Bash|com.bingobash.android
Bingo Holiday|com.bingoholiday.android
Lotto|com.lotto.android
Sans Topu|com.sanstopu.android
Milli Piyango|com.millipiyango.android
Iddaa|com.iddaa.android
Nesine|com.nesine.android
Misli|com.misli.android
Bilyoner|com.bilyoner.android
Tuttur|com.tuttur.android
Oley|com.oley.android
Birebin|com.birebin.android
Betboo|com.betboo.android
Bet365|com.bet365.android
1xBet|com.xbet.android
Betway|com.betway.android
Melbet|com.melbet.android
Mostbet|com.mostbet.android
Pinbahis|com.pinbahis.android
Sportsbet|com.sportsbet.android
Draftkings|com.draftkings.sportsbook
FanDuel|com.fanduel.sportsbook
Stake|com.stake.android
"""
    val ALL: List<String> = listOf(Q0, Q1, Q2, Q3, Q4).flatMap { it.lines() }
}
