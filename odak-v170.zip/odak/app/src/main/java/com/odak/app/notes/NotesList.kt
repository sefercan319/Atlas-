package com.odak.app.notes

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import com.odak.app.R
import com.odak.app.block.Pin
import com.odak.app.block.PinGate
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedTextField

/** Not listesi: arama, klasörler, çöp kutusu, sabitleme. Bir nota dokunulunca düzenleyici açılır. */
@Composable
fun NotesList(onEditorChange: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    var notes by remember { mutableStateOf(NoteStore.loadAll(ctx)) }
    var query by remember { mutableStateOf("") }
    var colorFilter by remember { mutableIntStateOf(0) }
    var folder by remember { mutableStateOf<String?>(null) }
    var trash by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(false) } // sırala / renk süz paneli; kapalıyken liste sade kalır
    // Sıralama tercihi; uygulama kapanıp açılınca korunur.
    val prefs = remember { ctx.getSharedPreferences("odak_notes", android.content.Context.MODE_PRIVATE) }
    var sort by remember { mutableIntStateOf(NotePure.sortMode(prefs.getInt("sort", NotePure.SORT_UPDATED))) }
    var editing by remember { mutableStateOf<Note?>(null) }
    var gate by remember { mutableStateOf<Note?>(null) }
    val needPin = stringResource(R.string.notes_need_pin)

    fun refresh() { notes = NoteStore.loadAll(ctx) }
    fun open(n: Note?) { editing = n; onEditorChange(n != null) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val pdfErr = stringResource(R.string.notes_pdf_err)
    val pdfLauncher = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val name = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { NoteMedia.importPdf(ctx, uri) }
            if (name == null) Toast.makeText(ctx, pdfErr, Toast.LENGTH_SHORT).show()
            else { val t = System.currentTimeMillis(); open(Note(created = t, updated = t, folder = folder ?: "", pdf = name, title = "PDF")); trash = false }
        }
    }

    val g = gate
    if (g != null) {
        PinGate(stringResource(R.string.notes_locked)) { gate = null; open(g) }
        return
    }
    val ed = editing
    if (ed != null) {
        NoteEditor(ed, onSave = { NoteStore.save(ctx, it) }, onTrash = { NoteStore.trash(ctx, it); refresh(); open(null) }, onBack = { refresh(); open(null) })
        return
    }

    val now = System.currentTimeMillis()
    val used = NotePure.colorsUsed(notes)
    // Süzülen renk artık hiçbir notta yoksa süzgeç kendiliğinden kalkar (boş liste + silinecek çip kalmasın).
    val activeColor = NotePure.activeColor(used, colorFilter)
    val shown = NotePure.sorted(NotePure.byColor(NotePure.visible(notes, folder, trash, query), activeColor), sort)
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            ThemedButton("＋ " + stringResource(R.string.notes_new), {
                open(Note(created = now, updated = now, folder = folder ?: ""))
                trash = false
            })
            com.odak.app.theme.QuietAction("📄 PDF", { pdfLauncher.launch(arrayOf("application/pdf")) })
            com.odak.app.theme.QuietAction((if (panel) "✔ " else "") + "⇅" + (if (activeColor != 0) " ●" else ""), { panel = !panel })
            if (trash) com.odak.app.theme.QuietAction("🗑 " + stringResource(R.string.notes_empty_trash), { NoteStore.emptyTrash(ctx); refresh() })
        }
        Spacer(Modifier.height(8.dp))
        ThemedTextField(query, { query = it }, stringResource(R.string.notes_search), Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            com.odak.app.theme.QuietAction((if (!trash && folder == null) "✔ " else "") + stringResource(R.string.notes_all), { trash = false; folder = null })
            com.odak.app.theme.QuietAction((if (!trash && folder == "") "✔ " else "") + stringResource(R.string.notes_no_folder), { trash = false; folder = "" })
            for (f in NotePure.folders(notes)) com.odak.app.theme.QuietAction((if (!trash && folder == f) "✔ " else "") + "📁 " + f, { trash = false; folder = f })
            com.odak.app.theme.QuietAction((if (trash) "✔ " else "") + "🗑 " + stringResource(R.string.notes_trash), { trash = true })
        }
        if (panel) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    NotePure.SORT_UPDATED to R.string.notes_sort_updated,
                    NotePure.SORT_CREATED to R.string.notes_sort_created,
                    NotePure.SORT_ALPHA to R.string.notes_sort_alpha
                ).forEach { (mode, label) ->
                    com.odak.app.theme.QuietAction((if (sort == mode) "✔ " else "") + stringResource(label), {
                        sort = mode
                        prefs.edit().putInt("sort", mode).apply()
                    })
                }
            }
            if (used.isNotEmpty() && !trash) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    for (c in used) Box(
                        Modifier.size(26.dp).clip(CircleShape).background(Color(c))
                            .border(if (activeColor == c) 3.dp else 1.dp, MaterialTheme.colorScheme.primary, CircleShape)
                            .clickable { colorFilter = if (activeColor == c) 0 else c }
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        if (trash) Text(stringResource(R.string.notes_trash_info), style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.7f))
        if (shown.isEmpty()) {
            com.odak.app.theme.EmptyState("📝", stringResource(R.string.notes_empty), if (!trash) stringResource(R.string.notes_empty_hint) else null)
        }
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.id }) { n ->
                ThemedCard(Modifier.fillMaxWidth(), onClick = {
                    if (!trash) {
                        if (n.locked) {
                            if (!Pin.isSet(ctx)) Toast.makeText(ctx, needPin, Toast.LENGTH_SHORT).show()
                            else if (Pin.needs(ctx, com.odak.app.logic.LockPolicy.NOTES)) gate = n else open(n)
                        } else open(n)
                    }
                }) {
                    Row(Modifier.fillMaxWidth()) {
                        if (n.color != 0) Box(Modifier.width(6.dp).fillMaxHeight().background(Color(n.color)))
                        Column(Modifier.weight(1f).padding(start = if (n.color != 0) 8.dp else 0.dp)) {
                            val t = NotePure.displayTitle(n)
                            Text(
                                (if (n.pinned) "📌 " else "") + (if (n.locked) "🔒 " else "") + t,
                                style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            if (!n.locked) {
                                val prev = n.body.lines().filter { it.isNotBlank() }.drop(if (n.title.isBlank()) 1 else 0).take(2).joinToString("\n")
                                if (prev.isNotEmpty()) Text(prev, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.alpha(0.8f))
                            }
                            val (d, tot) = NotePure.checkCounts(n.body)
                            val info = listOfNotNull(
                                if (n.strokes.isNotEmpty()) "✍" else null,
                                if (n.pdf.isNotEmpty()) "📄" else null,
                                if (n.images.isNotEmpty()) "🖼${n.images.size}" else null,
                                if (n.audios.isNotEmpty()) "🎙${n.audios.size}" else null,
                                if (tot > 0) "☑ $d/$tot" else null,
                                if (n.folder.isNotBlank()) "📁 ${n.folder}" else null
                            ).joinToString("  ")
                            if (info.isNotEmpty()) Text(info, style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.7f))
                        }
                    }
                    if (trash) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemedButton(stringResource(R.string.notes_restore), { NoteStore.restore(ctx, n); refresh() })
                            Text("${NotePure.daysLeft(n, now)}", style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.7f))
                        }
                    }
                }
            }
        }
    }
}
