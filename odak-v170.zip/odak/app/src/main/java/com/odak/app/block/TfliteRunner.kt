package com.odak.app.block

import android.content.Context
import com.odak.app.logic.LearnPure
import com.odak.app.logic.ModelPure
import org.tensorflow.lite.Interpreter
import java.io.File

/**
 * TensorFlow Lite (Google LiteRT) — çıkarım ve CİHAZDA EĞİTİM (imzalar: train / infer / save / restore).
 * Sözleşme (tools/export_tflite_train.py): train(x[B,144], y[B,2]) → loss; infer(x[B,144]) → output[B,2].
 */
object TfliteRunner {
    private var interp: Interpreter? = null
    private var path: String? = null
    private fun ckpt(c: Context) = File(c.filesDir, "tflite_ckpt.bin")

    @Synchronized fun release() { try { interp?.close() } catch (t: Throwable) { }; interp = null; path = null }

    @Synchronized private fun open(c: Context): Interpreter? {
        val f = ModelDownloader.find(c, ".tflite") ?: return null
        if (interp != null && path == f.path) return interp
        release()
        return try {
            Interpreter(f).also { i ->
                interp = i; path = f.path
                if (ckpt(c).exists()) try { i.runSignature(mapOf<String, Any>("checkpoint_path" to ckpt(c).path), HashMap<String, Any>(), "restore") } catch (t: Throwable) { }
            }
        } catch (t: Throwable) { null }
    }

    @Synchronized fun prob(c: Context, x: DoubleArray): Double? = try {
        val i = open(c)
        if (i == null) null else {
            val input = arrayOf(FloatArray(x.size) { x[it].toFloat() })
            val out = Array(1) { FloatArray(2) }
            try { i.runSignature(mapOf<String, Any>("x" to input), mutableMapOf<String, Any>("output" to out), "infer") }
            catch (e: Throwable) { i.run(input, out) }
            ModelPure.pickProbability(out[0])
        }
    } catch (t: Throwable) { null }

    /** Örneklerle cihazda eğitir ([epochs] tur, [batch] yığın); (yapılan adım, son kayıp) ya da null (model/imza yok). Sonra save imzasıyla kaydeder. */
    @Synchronized fun train(c: Context, ex: List<LearnPure.Ex>, epochs: Int = 5, batch: Int = 16): Pair<Int, Float>? = try {
        val i = open(c)
        if (i == null || ex.isEmpty()) null else {
            var steps = 0; var last = 0f
            repeat(epochs) {
                for (r in ModelPure.batches(ex.size, batch)) {
                    val xs = Array(r.count()) { k -> val e = ex[r.first + k]; FloatArray(LearnPure.DIM) { j -> LearnPure.features(e.entry, e.ratio, e.inNeg, e.name, e.conflict)[j].toFloat() } }
                    val ys = Array(r.count()) { k -> ModelPure.oneHot(ex[r.first + k].label) }
                    val loss = FloatArray(1)
                    i.runSignature(mapOf<String, Any>("x" to xs, "y" to ys), mutableMapOf<String, Any>("loss" to loss), "train")
                    last = loss[0]; steps++
                }
            }
            try { i.runSignature(mapOf<String, Any>("checkpoint_path" to ckpt(c).path), HashMap<String, Any>(), "save") } catch (t: Throwable) { }
            steps to last
        }
    } catch (t: Throwable) { null }

    fun clear(c: Context) { release(); try { ckpt(c).delete() } catch (e: Exception) { } }
}
