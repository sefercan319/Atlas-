package com.odak.app.block

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.odak.app.logic.Pure
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Kuralı telefonda öğretme: bölümde ve dışında 20 sn kayıt, sonra ayırt edici kimlik türetme. */
object RuleLab {
    const val SECONDS = 20
    var app by mutableStateOf("")
    var feat by mutableStateOf("")
    var mode by mutableStateOf("")          // "", "pos", "neg"
    var endAt = 0L
    var posScans by mutableIntStateOf(0)
    var negScans by mutableIntStateOf(0)
    private val posCount = HashMap<String, Int>()
    private val neg = HashSet<String>()
    private val posSel = HashMap<String, Int>()
    private val negSel = HashSet<String>()
    private val posDesc = HashMap<String, Int>()
    private val negDesc = HashSet<String>()
    private val posTxt = HashMap<String, Int>()
    private val negTxt = HashSet<String>()

    /** Kullanıcının listeden seçtiği kural girdileri (boşsa otomatik türetilen kullanılır). */
    val picked = androidx.compose.runtime.mutableStateListOf<String>()

    private fun pref(m: Map<String, Int>, p: String) = m.mapKeys { p + it.key }
    private fun prefS(m: Set<String>, p: String) = m.map { p + it }.toSet()

    /** Olumlu kayıttaki tüm adaylar; seçmek için gösterilir. */
    fun candidates(conflicts: Set<String> = emptySet()): List<com.odak.app.logic.UserFeatPure.Cand> = com.odak.app.logic.UserFeatPure.candidates(
        pref(posCount, "") + pref(posSel, "sel:") + pref(posDesc, "desc:") + pref(posTxt, "text:"),
        posScans, neg + prefS(negSel, "sel:") + prefS(negDesc, "desc:") + prefS(negTxt, "text:"), conflicts = conflicts
    )

    fun toggle(e: String) { if (!picked.remove(e)) picked.add(e) }
    /** Kaydedilecekler: seçim varsa o, yoksa otomatik türetilen. */
    fun toSave(): List<String> = if (picked.isNotEmpty()) picked.toList() else preview()

    fun start(a: String, f: String) { if (a != app || f != feat) reset(); app = a; feat = f }
    fun reset() { picked.clear(); mode = ""; posScans = 0; negScans = 0; posCount.clear(); neg.clear(); posSel.clear(); negSel.clear(); posDesc.clear(); negDesc.clear(); posTxt.clear(); negTxt.clear() }
    fun record(m: String) { mode = m; endAt = System.currentTimeMillis() + SECONDS * 1000L }
    fun recording(now: Long = System.currentTimeMillis()) = mode.isNotEmpty() && now < endAt
    fun wants(appId: String) = recording() && appId == app

    /** Servis her taramada çağırır. */
    fun feed(ids: Set<String>, sel: Set<String> = emptySet(), descs: Set<String> = emptySet(), texts: Set<String> = emptySet()) {
        if (!recording()) { mode = ""; return }
        if (mode == "pos") {
            posScans++
            ids.forEach { posCount[it] = (posCount[it] ?: 0) + 1 }
            sel.forEach { posSel[it] = (posSel[it] ?: 0) + 1 }
            descs.forEach { posDesc[it] = (posDesc[it] ?: 0) + 1 }
            texts.forEach { posTxt[it] = (posTxt[it] ?: 0) + 1 }
        } else { negScans++; neg.addAll(ids); negSel.addAll(sel); negDesc.addAll(descs); negTxt.addAll(texts) }
    }

    /** Kimlik kuralları + (varsa) seçili sekme etiketi kuralları; dilden bağımsız kimlik yoksa sekme etiketi yedek olur. */
    fun preview(): List<String> = Pure.derive(posCount, posScans, neg) + Pure.deriveSel(posSel, posScans, negSel) +
        Pure.deriveWords("desc:", posDesc, posScans, negDesc) + Pure.deriveWords("text:", posTxt, posScans, negTxt)

    private fun rulesFile(c: Context) = File(c.filesDir, "user_rules.json")
    private fun readAll(c: Context): JSONObject =
        try { JSONObject(com.odak.app.logic.SafeFile.read(rulesFile(c)) { validJson(it) } ?: "{}") } catch (e: Exception) { JSONObject() }

    /** Bu bölüm için kayıtlı kural girdileri (gösterim için). */
    fun saved(c: Context, app: String, feat: String): List<String> {
        val a = readAll(c).optJSONArray(Pure.ruleKey(app, feat)) ?: return emptyList()
        return List(a.length()) { a.optString(it, "") }.filter { it.isNotBlank() }
    }

    /** Girdileri mevcut kurala EKLER (eskiler kaybolmaz); eklenen toplam girdi sayısını döndürür. */
    fun addEntries(c: Context, app: String, feat: String, entries: List<String>): Int {
        val add = entries.filter { it.isNotBlank() }
        if (add.isEmpty()) return 0
        val o = readAll(c)
        val merged = com.odak.app.logic.UserFeatPure.merge(saved(c, app, feat), add)
        o.put(Pure.ruleKey(app, feat), JSONArray(merged))
        com.odak.app.logic.SafeFile.write(rulesFile(c), o.toString())
        return merged.size
    }

    /** Elle kural: tür (id/text/desc/sel) + değer; geçerliyse eklenir. */
    fun addManual(c: Context, app: String, feat: String, type: String, value: String): Boolean {
        val e = com.odak.app.logic.UserFeatPure.manualEntry(type, value) ?: return false
        return addEntries(c, app, feat, listOf(e)) > 0
    }

    /** Bu bölüm için daha önce kaydedilmiş kimlik sayısı (0 = kayıtlı kural yok). */
    fun savedCount(c: Context, app: String, feat: String): Int = try {
        val o = JSONObject(com.odak.app.logic.SafeFile.read(File(c.filesDir, "user_rules.json")) { validJson(it) } ?: return 0)
        o.optJSONArray(Pure.ruleKey(app, feat))?.length() ?: 0
    } catch (e: Exception) { 0 }

    fun validJson(s: String): Boolean = try { JSONObject(s); true } catch (e: Exception) { false }

    /** Kayıtlı kuralı siler; silindiyse true. Engellemeyi gevşettiği için çağıran tarafta onay gerekir. */
    fun removeSaved(c: Context, app: String, feat: String): Boolean {
        val f = File(c.filesDir, "user_rules.json")
        val o = try { JSONObject(com.odak.app.logic.SafeFile.read(f) { validJson(it) } ?: return false) } catch (e: Exception) { return false }
        val key = Pure.ruleKey(app, feat)
        if (!o.has(key)) return false
        o.remove(key)
        com.odak.app.logic.SafeFile.write(f, o.toString())
        return true
    }

    /** Türetilen kuralı user_rules.json'a yazar; kaç girdi yazıldığını döndürür. */
    fun make(c: Context): Int {
        val r = toSave()
        if (r.isEmpty()) return 0
        try {
            val fn = BlockCatalog.apps.firstOrNull { it.id == app }?.features?.firstOrNull { it.id == feat }?.text.orEmpty()
            LearnStore.record(c, candidates(LearnStore.otherEntries(c, app, feat)), r, fn)
        } catch (e: Exception) { }
        val n = addEntries(c, app, feat, r)
        reset()
        return n
    }
}
