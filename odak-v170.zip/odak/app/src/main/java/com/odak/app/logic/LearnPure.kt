package com.odak.app.logic

import java.util.Random
import kotlin.math.exp

/**
 * Cihazda eğitilen küçük "kural öğrenici" (lojistik regresyon). Kullanıcının listeden seçtiklerinden öğrenir:
 * hangi tür/etiket/kelime ayırt edici kural olur. Gerçekten eğitilir; dış model gerekmez. Android'e bağlı değil.
 */
object LearnPure {
    const val BASE = 16
    const val WORDS = 64     // kelime torbası
    const val GRAMS = 64     // harf üçlüleri: yazım/dil farkına dayanıklı
    const val DIM = BASE + WORDS + GRAMS
    const val MIN_EXAMPLES = 20

    class Ex(val entry: String, val ratio: Double, val inNeg: Boolean, val name: Boolean, val label: Boolean, val conflict: Boolean = false, val weight: Double = 1.0)

    fun typeOf(e: String): Int = when {
        e.startsWith("sel:") -> 2; e.startsWith("desc:") -> 3; e.startsWith("text:") -> 4; else -> 1
    }

    private fun bucket(w: String, n: Int): Int = (w.hashCode() and 0x7fffffff) % n

    private val GENERIC = listOf("container", "root", "content", "layout", "frame", "toolbar", "status", "navigation_bar", "decor", "action_bar", "scroll", "recycler", "viewpager", "pager", "wrapper", "parent", "holder", "background", "divider", "spacer", "progress", "loading")

    /** Her ekranda bulunan genel yapı kimliği mi (container, root, toolbar...)? Bunlar ayırt edici değildir. */
    fun generic(entry: String): Boolean {
        val b = (if (typeOf(entry) == 1) entry else entry.substringAfter(':')).lowercase()
        return GENERIC.any { b.contains(it) }
    }

    fun features(entry: String, ratio: Double, inNeg: Boolean, name: Boolean, conflict: Boolean = false): DoubleArray {
        val x = DoubleArray(DIM)
        val body = if (typeOf(entry) == 1) entry else entry.substringAfter(':')
        x[0] = 1.0
        x[typeOf(entry)] = 1.0
        x[5] = ratio.coerceIn(0.0, 1.0)
        x[6] = if (inNeg) 1.0 else 0.0
        x[7] = minOf(body.length, 40) / 40.0
        x[8] = if (name) 1.0 else 0.0
        x[9] = if (body.any { it.isDigit() }) 1.0 else 0.0
        x[10] = if (body.trim().contains(' ')) 1.0 else 0.0
        x[11] = if (body.firstOrNull()?.isUpperCase() == true) 1.0 else 0.0
        x[12] = if (generic(entry)) 1.0 else 0.0
        x[13] = if (conflict) 1.0 else 0.0
        x[14] = if (body.isNotEmpty() && body.count { it.isDigit() } * 10 > body.length * 3) 1.0 else 0.0   // sayı ağırlıklı: kararsız
        x[15] = if (inNeg) 0.0 else ratio.coerceIn(0.0, 1.0)
        Regex("[\\p{L}]{3,}").findAll(body.lowercase()).forEach { m ->
            val w = m.value
            x[BASE + bucket(w, WORDS)] = 1.0
            for (i in 0..w.length - 3) x[BASE + WORDS + bucket(w.substring(i, i + 3), GRAMS)] = 1.0
        }
        return x
    }

    fun sigmoid(z: Double): Double = 1.0 / (1.0 + exp(-z.coerceIn(-30.0, 30.0)))

    fun predict(w: DoubleArray, x: DoubleArray): Double { var z = 0.0; for (i in x.indices) z += w[i] * x[i]; return sigmoid(z) }

    fun predict(w: DoubleArray, e: Ex) = predict(w, features(e.entry, e.ratio, e.inNeg, e.name, e.conflict))

    /** Kararlı (tohumlu) SGD; olumlu örnekler 2 kat ağırlıklı. Başlangıç ağırlığı [start] verilirse oradan sürer. */
    /** Sınıf dengeleme: olumlu örneklerin ağırlığı = olumsuz/olumlu oranı (1..6 arası), olumlu azsa daha çok önemsenir. */
    fun posWeight(ex: List<Ex>): Double {
        val p = ex.count { it.label }; val n = ex.size - p
        return if (p == 0 || n == 0) 2.0 else (n.toDouble() / p).coerceIn(1.0, 6.0)
    }

    /** Katmanlı bölme: her sınıftan her 5. örnek doğrulamaya gider (az olumlu olsa bile doğrulamada olumlu bulunur). */
    fun split(ex: List<Ex>): Pair<List<Ex>, List<Ex>> {
        val va = ArrayList<Ex>(); val tr = ArrayList<Ex>()
        var ip = 0; var ineg = 0
        for (e in ex) {
            val k = if (e.label) ip++ else ineg++
            if (k % 5 == 4) va.add(e) else tr.add(e)
        }
        return Pair(tr, va)
    }

    fun train(ex: List<Ex>, epochs: Int = 40, start: DoubleArray? = null, epoch0: Int = 0, mask: BooleanArray? = null, l2: Double = 0.001): DoubleArray {
        val w = start?.copyOf() ?: DoubleArray(DIM)
        if (ex.isEmpty()) return w
        val xs = ex.map { features(it.entry, it.ratio, it.inNeg, it.name, it.conflict) }
        val idx = ex.indices.toMutableList()
        val rnd = Random(7L + epoch0)
        val pw = posWeight(ex)
        for (ep in 0 until epochs) {
            val lr = 0.3 / (1.0 + (epoch0 + ep) * 0.1)
            idx.shuffle(rnd)
            for (i in idx) {
                val y = if (ex[i].label) 1.0 else 0.0
                val g = (predict(w, xs[i]) - y) * (if (ex[i].label) pw else 1.0) * ex[i].weight
                for (j in 0 until DIM) if (mask == null || mask[j]) w[j] -= lr * (g * xs[i][j] + l2 * w[j])
            }
        }
        return w
    }

    class Fit(val w: DoubleArray, val trainAcc: Int, val valAcc: Int, val epochs: Int, val valN: Int)

    private fun logLoss(w: DoubleArray, ex: List<Ex>): Double =
        ex.sumOf { val p = predict(w, it).coerceIn(1e-6, 1 - 1e-6); -(if (it.label) Math.log(p) else Math.log(1 - p)) } / ex.size

    /**
     * Daha iyi eğitim: her 5. örnek doğrulama için ayrılır (25+ örnekte), her tur sonunda doğrulama kaybı ölçülür,
     * [patience] tur iyileşme olmazsa durur ve en iyi ağırlıklar tutulur (aşırı ezberlemeyi önler). Önceki ağırlıktan sürebilir.
     */
    fun fit(ex: List<Ex>, maxEpochs: Int = 80, start: DoubleArray? = null, patience: Int = 6, mask: BooleanArray? = null): Fit {
        val useVal = ex.size >= 25
        val sp = if (useVal) split(ex) else null
        val va = sp?.second ?: emptyList()
        val tr = sp?.first ?: ex
        var w = start?.copyOf() ?: DoubleArray(DIM)
        if (tr.isEmpty()) return Fit(w, 0, 0, 0, 0)
        var best = w.copyOf(); var bestLoss = if (useVal) logLoss(w, va) else Double.MAX_VALUE; var stale = 0; var done = 0
        for (ep in 0 until maxEpochs) {
            w = train(tr, 1, w, ep, mask)
            done = ep + 1
            if (!useVal) { best = w; continue }
            val l = logLoss(w, va)
            if (l < bestLoss - 1e-4) { bestLoss = l; best = w.copyOf(); stale = 0 } else if (++stale >= patience) break
        }
        return Fit(best, accuracy(best, tr), if (useVal) accuracy(best, va) else accuracy(best, tr), done, va.size)
    }

    /**
     * Parametre kapsamı: ağırlıkların yüzde [pct]'i eğitilir, kalanı dondurulur. Seçim [seed]'e bağlı kararlıdır;
     * [seed] her turda değişirse (dönüşümlü) zamanla tüm parametreler eğitilmiş olur. %100 = tam eğitim (maske yok).
     */
    fun mask(pct: Int, seed: Int, dim: Int = DIM): BooleanArray? {
        if (pct >= 100) return null
        val p = pct.coerceIn(1, 99)
        // Kimlik sırasından bağımsız dağılım için karıştırma: her seed için sabit permütasyon, ilk p% eğitilir.
        val order = (0 until dim).toMutableList().also { it.shuffle(Random(1000L + seed)) }
        val k = maxOf(1, dim * p / 100)
        return BooleanArray(dim).also { m -> order.take(k).forEach { m[it] = true } }
    }

    fun trainable(mask: BooleanArray?, dim: Int = DIM) = mask?.count { it } ?: dim

    /** Arka plan işi: yalnızca eğitimden sonra yeni örnek geldiyse eğit. */
    fun needsTrain(count: Int, trainedN: Int) = count > trainedN

    fun accuracy(w: DoubleArray, ex: List<Ex>): Int =
        if (ex.isEmpty()) 0 else (ex.count { (predict(w, it) >= 0.5) == it.label } * 100 / ex.size)

    /** Yeterli örnek varsa; olumsuzda görülmeyen, başka özelliğin kuralı olmayan ve olasılığı ≥ [min] olan en çok [max] aday. */
    fun pick(w: DoubleArray?, n: Int, cands: List<UserFeatPure.Cand>, suggested: Set<String>, min: Double = 0.7, max: Int = 3): List<String> {
        if (w == null || n < MIN_EXAMPLES) return emptyList()
        return cands.filter { !it.inNeg && !it.conflict }
            .map { it to score(w, it, it.entry in suggested) }
            .filter { it.second >= min }.sortedByDescending { it.second }.take(max).map { it.first.entry }
    }

    const val ENG_BUILTIN = 0; const val ENG_SMILE = 1; const val ENG_BOTH = 2; const val ENG_ADV = 3; const val ENG_ONNX = 4

    /** Motor seçimine göre olasılık: yerleşik, Smile ya da ikisinin ortalaması (Smile yoksa yerleşiğe düşer). */
    fun blend(engine: Int, builtin: Double, smile: Double?): Double = when {
        smile == null -> builtin
        engine == ENG_SMILE -> smile
        engine == ENG_BOTH || engine == ENG_ADV -> (builtin + smile) / 2
        else -> builtin
    }

    /** İçe aktarılan ONNX modeli varsa yerleşik ile ortalaması; yoksa yerleşik. */
    fun blendOnnx(builtin: Double, onnx: Double?): Double = if (onnx == null) builtin else (builtin + onnx) / 2

    fun pickBy(n: Int, cands: List<UserFeatPure.Cand>, min: Double = 0.7, max: Int = 3, scorer: (UserFeatPure.Cand) -> Double): List<String> {
        if (n < MIN_EXAMPLES) return emptyList()
        return cands.filter { !it.inNeg && !it.conflict }.map { it to scorer(it) }
            .filter { it.second >= min }.sortedByDescending { it.second }.take(max).map { it.first.entry }
    }

    fun score(w: DoubleArray, c: UserFeatPure.Cand, name: Boolean): Double = predict(w, features(c.entry, c.ratio, c.inNeg, name, c.conflict))

    /** Adayın kısa nedenleri (simge): 🎯 ada uyuyor · 📌 sık görülüyor · ⚠ dışarıda da var · ⛔ başka özelliğin kuralı · 💤 genel öğe. */
    fun tags(c: UserFeatPure.Cand, name: Boolean): String = buildString {
        if (name) append("🎯")
        if (c.ratio >= 0.9 && !c.inNeg) append("📌")
        if (c.inNeg) append("⚠")
        if (c.conflict) append("⛔")
        if (generic(c.entry)) append("💤")
    }

    class Metrics(val precision: Int, val recall: Int, val f1: Int, val acc: Int)

    fun metrics(w: DoubleArray, ex: List<Ex>, thr: Double = 0.5): Metrics {
        if (ex.isEmpty()) return Metrics(0, 0, 0, 0)
        var tp = 0; var fp = 0; var fn = 0; var ok = 0
        for (e in ex) { val pr = predict(w, e) >= thr; if (pr && e.label) tp++ else if (pr) fp++ else if (e.label) fn++; if (pr == e.label) ok++ }
        val p = if (tp + fp == 0) 0.0 else tp.toDouble() / (tp + fp); val r = if (tp + fn == 0) 0.0 else tp.toDouble() / (tp + fn)
        val f = if (p + r == 0.0) 0.0 else 2 * p * r / (p + r)
        return Metrics((p * 100).toInt(), (r * 100).toInt(), (f * 100).toInt(), ok * 100 / ex.size)
    }

    /** F1'i en çok yapan karar eşiği (0.5–0.9 arası; yeterli örnek yoksa 0.7). Eşit olursa yüksek eşik: yanlış engelleme daha pahalı. */
    fun bestThreshold(w: DoubleArray, ex: List<Ex>): Double {
        if (ex.size < 10) return 0.7
        var best = 0.7; var bf = -1
        var t = 0.5
        while (t <= 0.901) { val f = metrics(w, ex, t).f1; if (f >= bf) { bf = f; best = t }; t += 0.05 }
        return Math.round(best * 100) / 100.0
    }

    /** k katlı çapraz doğrulama (örnek i, i%k katına girer): ortalama başarı. Az veride (<[k]*4) null. */
    fun crossVal(ex: List<Ex>, k: Int = 5, epochs: Int = 40): Metrics? {
        if (ex.size < k * 4) return null
        var f1 = 0; var acc = 0; var pr = 0; var rc = 0
        for (f in 0 until k) {
            val va = ex.filterIndexed { i, _ -> i % k == f }; val tr = ex.filterIndexed { i, _ -> i % k != f }
            val m = metrics(train(tr, epochs), va)
            f1 += m.f1; acc += m.acc; pr += m.precision; rc += m.recall
        }
        return Metrics(pr / k, rc / k, f1 / k, acc / k)
    }

    fun encodeW(w: DoubleArray) = w.joinToString(",") { String.format(java.util.Locale.US, "%.5f", it) }
    fun decodeW(s: String): DoubleArray? = try {
        s.trim().split(',').map { it.toDouble() }.toDoubleArray().takeIf { it.size == DIM }
    } catch (e: Exception) { null }

    fun encode(e: Ex): String = (listOf(e.entry.replace(Regex("[\\t\\r\\n]"), " "), String.format(java.util.Locale.US, "%.3f", e.ratio), if (e.inNeg) "1" else "0", if (e.name) "1" else "0", if (e.label) "1" else "0", if (e.conflict) "1" else "0") + (if (e.weight == 1.0) emptyList() else listOf(String.format(java.util.Locale.US, "%.3f", e.weight)))).joinToString("\t")
    fun decode(l: String): Ex? {
        val p = l.split('\t')
        if (p.size !in 5..7) return null   // 5 alan: eski kayıt (çatışma yok); 7. alan: örnek ağırlığı
        return Ex(p[0], p[1].toDoubleOrNull() ?: return null, p[2] == "1", p[3] == "1", p[4] == "1", p.size >= 6 && p[5] == "1", if (p.size == 7) (p[6].toDoubleOrNull() ?: 1.0).coerceIn(0.05, 5.0) else 1.0)
    }

    /** Dışa aktarma: bir satır bir JSON nesnesi. */
    fun toJsonl(ex: List<Ex>): String = ex.joinToString("\n") {
        val s = it.entry.replace("\\", "\\\\").replace("\"", "\\\"").replace(Regex("[\\u0000-\\u001f]"), " ")
        "{\"entry\":\"$s\",\"ratio\":${String.format(java.util.Locale.US, "%.3f", it.ratio)},\"in_negative\":${it.inNeg},\"name_match\":${it.name},\"conflict\":${it.conflict},\"label\":${it.label}}"
    }
}
