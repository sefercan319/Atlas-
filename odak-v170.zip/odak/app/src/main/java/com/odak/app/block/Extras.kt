package com.odak.app.block

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.sp
import com.odak.app.theme.plainClick
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import com.odak.app.R
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.ThemedTextField
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private class Cand(val pkg: String, val label: String)

private fun launchables(c: Context): List<Cand> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { Cand(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .distinctBy { it.pkg }
        .filter { !BlockCatalog.protectedPkg(c, it.pkg) && BlockCatalog.byPackage(it.pkg) == null }
        .sortedBy { it.label.lowercase() }
}

/** Yüklü uygulamalardan birini engellenecekler listesine ekletir. */
@Composable
fun CustomAppPicker(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var all by remember { mutableStateOf<List<Cand>>(emptyList()) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { all = withContext(Dispatchers.IO) { launchables(ctx) } }
    val shown = all.filter { com.odak.app.logic.Pure.nameMatches(it.label, q, it.pkg) }
    var lim by remember(q) { mutableStateOf(com.odak.app.logic.Pure.APP_PAGE) }
    AlertDialog(
        onDismissRequest = onDone,
        confirmButton = {},
        dismissButton = { com.odak.app.theme.QuietAction("✕", onDone) },
        title = { Text(stringResource(R.string.custom_app_pick)) },
        text = {
            Column {
                ThemedTextField(q, { q = it }, "🔍", Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                if (all.isNotEmpty() && shown.isEmpty()) {
                    Text(stringResource(R.string.custom_app_none), style = MaterialTheme.typography.bodySmall)
                }
                LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(shown.take(com.odak.app.logic.Pure.appsVisible(lim, shown.size)), key = { it.pkg }) { a ->
                        // Aynı adlı uygulamaları ayırmak için paket adı da gösterilir.
                        ThemedButton(a.label + "\n" + a.pkg, {
                            BlockCatalog.addCustom(ctx, a.pkg, a.label)
                            onDone()
                        }, Modifier.fillMaxWidth())
                    }
                    item {
                        val rem = com.odak.app.logic.Pure.appsRemaining(lim, shown.size)
                        if (rem > 0) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemedButton(stringResource(R.string.blk_more, rem), { lim = com.odak.app.logic.Pure.appsNextShown(lim, shown.size) })
                            com.odak.app.theme.QuietAction(stringResource(R.string.blk_all), { lim = shown.size })
                        }
                    }
                }
            }
        }
    )
}

/** Engelli uygulamaların bildirimlerini gizleme anahtarı + izin düğmesi. */
@Composable
fun NotifHideCard() {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(BlockStore.notifHide(ctx)) }
    var granted by remember { mutableStateOf(false) }
    var guide by remember { mutableStateOf(false) }
    if (guide) PermGrantNow(com.odak.app.logic.PermKind.NOTIF) { guide = false }
    LaunchedEffect(on) {
        while (true) {
            granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
            kotlinx.coroutines.delay(2000)
        }
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        androidx.compose.foundation.layout.Row(
            Modifier.fillMaxWidth(),
            Arrangement.SpaceBetween,
            androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(stringResource(R.string.notif_hide), Modifier.weight(1f))
            ThemedCheck(on && granted) { v ->
                if (v && !granted) {
                    guide = true
                } else {
                    on = v
                    BlockStore.setNotifHide(ctx, v)
                }
            }
        }
        if (!granted) {
            Spacer(Modifier.height(8.dp))
            ThemedButton(stringResource(R.string.block_grant), {
                on = true
                BlockStore.setNotifHide(ctx, true)
                guide = true
            })
        }
    }
}

/** Uyarı ve bildirim ayarları: eşik, bildirim, ek süre, özel mesajlar. */
@Composable
fun AlertsCard() {
    val ctx = LocalContext.current
    var warn by remember { mutableStateOf(BlockStore.warnOn(ctx)) }
    var pct by remember { mutableStateOf(BlockStore.warnPct(ctx)) }
    var note by remember { mutableStateOf(BlockStore.limitNoteOn(ctx)) }
    var strict by remember { mutableStateOf(BlockStore.strictLimit(ctx)) }
    var featHome by remember { mutableStateOf(BlockStore.featHome(ctx)) }
    var nmsg by remember { mutableStateOf(BlockStore.noteMsg(ctx)) }
    @Composable
    fun row(label: String, v: Boolean, f: (Boolean) -> Unit) {
        androidx.compose.foundation.layout.Row(
            Modifier.fillMaxWidth().padding(vertical = 4.dp),
            Arrangement.SpaceBetween,
            androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(label, Modifier.weight(1f))
            ThemedCheck(v, f)
        }
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text("🔔", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
        row(stringResource(R.string.alert_warn_on), warn) { warn = it; BlockStore.setWarnOn(ctx, it) }
        if (warn) {
            val opts = listOf(50, 70, 80, 90)
            androidx.compose.foundation.layout.Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.alert_pct), Modifier.weight(1f))
                opts.forEach { o ->
                    com.odak.app.theme.QuietAction(if (pct == o) "✔ $o%" else "$o%", { pct = o; BlockStore.setWarnPct(ctx, o) })
                }
            }
        }
        row(stringResource(R.string.alert_limit_on), note) { note = it; BlockStore.setLimitNoteOn(ctx, it) }
        row(stringResource(R.string.alert_strict), strict) { strict = it; BlockStore.setStrictLimit(ctx, it) }
        row(stringResource(R.string.alert_feat_home), featHome) { featHome = it; BlockStore.setFeatHome(ctx, it) }
        Spacer(Modifier.height(8.dp))
        ThemedTextField(nmsg, { nmsg = it.take(120); BlockStore.setNoteMsg(ctx, nmsg) }, stringResource(R.string.alert_note_msg), Modifier.fillMaxWidth())
    }
}

private val ScrColors = listOf(
    0xFF111111, 0xFFB71C1C, 0xFFE65100, 0xFFF9A825, 0xFF1B5E20,
    0xFF006064, 0xFF0D47A1, 0xFF4A148C, 0xFFAD1457, 0xFFFFFFFF
)

/** Özelleştirilebilir uyarı ekranları (engel ve süre doldu) + canlı önizleme. */
@Composable
fun ScreensCard() {
    val ctx = LocalContext.current
    for (kind in listOf("blk", "lim", "ftr")) {
        var icon by remember { mutableStateOf(BlockStore.scr(ctx, kind, "icon")) }
        var title by remember { mutableStateOf(BlockStore.scr(ctx, kind, "title")) }
        var msg by remember { mutableStateOf(BlockStore.scr(ctx, kind, "msg")) }
        var bg by remember { mutableStateOf(BlockStore.scr(ctx, kind, "bg")) }
        var size by remember { mutableStateOf(BlockStore.scr(ctx, kind, "size")) }
        val bgc = bg.toLongOrNull()?.let { androidx.compose.ui.graphics.Color(it) }
        var photoRev by remember { mutableStateOf(0) }
        val pick = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) { ScrPhoto.save(ctx, kind, uri); photoRev++ }
        }
        val photo = remember(photoRev) { ScrPhoto.bitmap(ctx, kind)?.asImageBitmap() }
        ThemedCard(Modifier.fillMaxWidth()) {
            Text(
                stringResource(when (kind) { "blk" -> R.string.scr_blk; "ftr" -> R.string.scr_ftr; else -> R.string.scr_lim }),
                style = androidx.compose.material3.MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
            // önizleme
            val tk = com.odak.app.theme.LocalDesign.current.tokens
            val fg = if (bgc == null) tk.text
            else if (bgc.luminance() > 0.5f) androidx.compose.ui.graphics.Color(0xFF111111)
            else androidx.compose.ui.graphics.Color.White
            val k = when (size) { "0" -> 0.75f; "2" -> 1.35f; else -> 1f }
            androidx.compose.foundation.layout.Box(
                Modifier.fillMaxWidth().height(150.dp)
                    .background(bgc ?: tk.background, androidx.compose.foundation.shape.RoundedCornerShape(10.dp)),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                    if (photo != null) androidx.compose.foundation.Image(photo, null, Modifier.height(48.dp))
                    Text(icon.ifBlank { "⛔" }, fontSize = (34 * k).sp, color = fg)
                    Text(
                        title.ifBlank { if (kind == "ftr") stringResource(R.string.ftr_blocked, "DM") else stringResource(if (kind == "lim") R.string.limit_reached_title else R.string.block_app_msg) },
                        fontSize = (16 * k).sp, color = fg
                    )
                    Text(msg.ifBlank { stringResource(R.string.motiv_1) }, fontSize = (12 * k).sp, color = fg.copy(alpha = 0.8f), maxLines = 2)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemedButton("🖼 " + stringResource(R.string.scr_photo), { pick.launch("image/*") })
                if (photo != null) com.odak.app.theme.QuietAction("✕ " + stringResource(R.string.scr_photo_clear), { ScrPhoto.clear(ctx, kind); photoRev++ })
            }
            Spacer(Modifier.height(6.dp))
            ThemedTextField(icon, { icon = it.take(4); BlockStore.setScr(ctx, kind, "icon", icon) }, stringResource(R.string.scr_icon_hint), Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            ThemedTextField(title, { title = it.take(40); BlockStore.setScr(ctx, kind, "title", title) }, stringResource(R.string.scr_title_hint), Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            ThemedTextField(msg, { msg = it.take(120); BlockStore.setScr(ctx, kind, "msg", msg) }, stringResource(R.string.alert_block_msg), Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            androidx.compose.foundation.layout.FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                androidx.compose.foundation.layout.Box(
                    Modifier.size(30.dp)
                        .border(1.dp, tk.text.copy(alpha = 0.5f), androidx.compose.foundation.shape.CircleShape)
                        .plainClick { bg = ""; BlockStore.setScr(ctx, kind, "bg", "") },
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) { Text(if (bg.isEmpty()) "✓" else "∅", fontSize = 14.sp) }
                ScrColors.forEach { c ->
                    androidx.compose.foundation.layout.Box(
                        Modifier.size(30.dp)
                            .background(androidx.compose.ui.graphics.Color(c), androidx.compose.foundation.shape.CircleShape)
                            .border(1.dp, Color(0x55888888), androidx.compose.foundation.shape.CircleShape)
                            .plainClick { bg = c.toString(); BlockStore.setScr(ctx, kind, "bg", bg) },
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        if (bg == c.toString()) Text(
                            "✓", fontSize = 15.sp,
                            color = if (androidx.compose.ui.graphics.Color(c).luminance() > 0.5f) Color.Black else Color.White
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("A−", "A", "A+").forEachIndexed { i, l ->
                    val v = i.toString()
                    val on = size == v || (size.isEmpty() && i == 1)
                    com.odak.app.theme.QuietAction(if (on) "✔ $l" else l, { size = v; BlockStore.setScr(ctx, kind, "size", v) })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

/** Kural Laboratuvarı: bölümde ve dışında kayıt alıp ayırt edici kimlikleri türetir. */
@Composable
fun RuleLabDialog(appId: String, featId: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var saved by remember { mutableStateOf(-1) }
    var savedN by remember { mutableStateOf(RuleLab.savedCount(ctx, appId, featId)) }
    var confirmDel by remember { mutableStateOf(false) }
    var mType by remember { mutableStateOf("text") }
    var mVal by remember { mutableStateOf("") }
    var mMsg by remember { mutableStateOf(false) }
    var listRev by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        RuleLab.start(appId, featId)
        while (true) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(500) }
    }
    val rec = RuleLab.recording(now)
    val ids = if (rec) emptyList() else RuleLab.preview()
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(stringResource(R.string.rl_title)) },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(R.string.rl_help))
                if (rec) Text(
                    stringResource(R.string.rl_rec) + " " + ((RuleLab.endAt - now) / 1000 + 1) + " s"
                )
                ThemedButton("1 · " + stringResource(R.string.rl_pos) + "  (${RuleLab.posScans})", {
                    saved = -1; RuleLab.record("pos")
                })
                ThemedButton("2 · " + stringResource(R.string.rl_neg) + "  (${RuleLab.negScans})", {
                    saved = -1; RuleLab.record("neg")
                })
                if (!rec && RuleLab.posScans > 0) {
                    Text(stringResource(R.string.rl_pick), style = MaterialTheme.typography.labelLarge)
                    val featName = remember(appId, featId) { BlockCatalog.apps.firstOrNull { it.id == appId }?.features?.firstOrNull { it.id == featId }?.text.orEmpty() }
                    val others = remember(appId, featId) { LearnStore.otherEntries(ctx, appId, featId) }
                    val cands = RuleLab.candidates(others)
                    val sug = com.odak.app.logic.UserFeatPure.suggest(cands, featName).toSet()
                    androidx.compose.runtime.LaunchedEffect(RuleLab.posScans, rec) {
                        if (RuleLab.picked.isEmpty()) {
                            RuleLab.picked.addAll((sug.toList() + LearnStore.pick(ctx, cands, featName)).distinct().take(5))
                        }
                    }
                    val scr = remember(RuleLab.posScans, rec) { LearnStore.scorer(ctx) }
                    val cfd = remember(RuleLab.posScans, rec) { LearnStore.confer(ctx) }
                    val nEx = remember(RuleLab.posScans, rec) { LearnStore.count(ctx) }
                    val shown = cands.map { c ->
                        c to (scr?.let { (it(c, c.entry in sug) * 100).toInt() })
                    }
                        .sortedWith(compareBy<Pair<com.odak.app.logic.UserFeatPure.Cand, Int?>> { it.first.inNeg || it.first.conflict }.thenByDescending { it.second ?: 0 })
                    val unc = remember(RuleLab.posScans, rec) { if (scr == null) emptySet() else com.odak.app.logic.LearnPlus.uncertain(cands, 1) { scr(it, it.entry in sug) } }
                    shown.forEach { (c, sc) ->
                        val on = c.entry in RuleLab.picked
                        val tg = (if (c.entry in unc) "❓" else "") + com.odak.app.logic.LearnPure.tags(c, c.entry in sug) + (cfd?.invoke(c, c.entry in sug)?.let { com.odak.app.logic.LearnConf.symbol(it.level) } ?: "")
                        com.odak.app.theme.QuietAction((if (on) "✔ " else "") + tg + (if (tg.isEmpty()) "" else " ") + c.entry + (sc?.let { " · %$it" + (cfd?.invoke(c, c.entry in sug)?.let { k -> " ±" + com.odak.app.logic.LearnConf.plusMinus(k) } ?: "") } ?: ""), { RuleLab.toggle(c.entry) })
                    }
                    if (cands.isNotEmpty()) Text(stringResource(R.string.rl_legend) + "\n" + stringResource(R.string.rl_conf) + if (unc.isNotEmpty()) "\n" + stringResource(R.string.rl_unc) else "", style = MaterialTheme.typography.bodySmall)
                    val lw = remember(RuleLab.posScans, rec) { LearnStore.weights(ctx) }
                    val whyTop = remember(RuleLab.picked.size, lw) { RuleLab.picked.firstOrNull()?.let { pe -> cands.firstOrNull { it.entry == pe } }?.let { pc -> lw?.let { com.odak.app.logic.LearnPlus.explain(it, pc, pc.entry in sug) } }.orEmpty() }
                    if (whyTop.isNotEmpty()) Text(stringResource(R.string.rl_why, whyTop), style = MaterialTheme.typography.bodySmall)
                    if (cands.isNotEmpty() && ModelRunner.available(ctx)) {
                        var askMsg by remember { androidx.compose.runtime.mutableStateOf("") }
                        val thinking = stringResource(R.string.rl_ask_busy); val none = stringResource(R.string.rl_ask_none)
                        com.odak.app.theme.QuietAction("🤖 " + stringResource(R.string.rl_ask), {
                            askMsg = thinking
                            val pool = cands.filter { !it.inNeg && !it.conflict }.map { it.entry }
                            Thread {
                                val got = ModelRunner.rank(ctx, featName, appId, pool)
                                got.forEach { if (it !in RuleLab.picked) RuleLab.toggle(it) }
                                askMsg = if (got.isEmpty()) none else ""
                            }.start()
                        })
                        if (askMsg.isNotEmpty()) Text(askMsg, style = MaterialTheme.typography.bodySmall)
                    }
                    if (RuleLab.picked.isEmpty() && ids.isNotEmpty()) Text(stringResource(R.string.rl_auto) + "\n" + ids.joinToString("\n"), style = MaterialTheme.typography.bodySmall)
                }
                if (saved > 0) Text("✅ " + stringResource(R.string.rl_done))
                Text(stringResource(R.string.rl_manual), style = MaterialTheme.typography.labelLarge)
                Text(stringResource(R.string.rl_hint_manual), style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("id" to R.string.rl_t_id, "text" to R.string.rl_t_text, "desc" to R.string.rl_t_desc, "sel" to R.string.rl_t_sel).forEach { (k, r) ->
                        com.odak.app.theme.QuietAction((if (mType == k) "✔ " else "") + stringResource(r), { mType = k })
                    }
                }
                com.odak.app.theme.ThemedTextField(mVal, { mVal = it.replace("\n", " ").take(60); mMsg = false }, stringResource(R.string.rl_value), Modifier.fillMaxWidth())
                ThemedButton(stringResource(R.string.rl_add), {
                    if (RuleLab.addManual(ctx, appId, featId, mType, mVal)) {
                        mVal = ""; mMsg = true; savedN = RuleLab.savedCount(ctx, appId, featId); listRev++
                    }
                })
                if (mMsg) Text("✅ " + stringResource(R.string.rl_added))
                androidx.compose.runtime.key(listRev, saved) {
                    val sv = RuleLab.saved(ctx, appId, featId)
                    if (sv.isNotEmpty()) {
                        Text(stringResource(R.string.rl_saved_list), style = MaterialTheme.typography.labelLarge)
                        Text(sv.joinToString("\n"), style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (savedN > 0) {
                    Text(stringResource(R.string.rl_saved_n, savedN), style = MaterialTheme.typography.bodySmall)
                    // Kural silmek engellemeyi zayıflatır. Bu yüzden yalnızca bölüm engelli değilken
                    // silinebilir (engel kapatma akışındaki bekleme süresi atlanmaz) ve iki adımlı onay ister.
                    if (!BlockStore.isFeatureBlocked(ctx, appId, featId)) {
                        ThemedButton(if (confirmDel) "⚠ " + stringResource(R.string.rl_del_confirm) else stringResource(R.string.rl_del), {
                            if (!confirmDel) confirmDel = true
                            else {
                                RuleLab.removeSaved(ctx, appId, featId)
                                savedN = 0; confirmDel = false
                            }
                        })
                    }
                }
                val uf = java.io.File(ctx.filesDir, "user_rules.json")
                if (uf.exists()) ThemedButton("📤 " + stringResource(R.string.rl_share), {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, uf.readText())
                    com.odak.app.Launch.go(ctx, Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                })
            }
        },
        confirmButton = {
            ThemedButton(stringResource(R.string.rl_make), {
                if (!rec && (ids.isNotEmpty() || RuleLab.picked.isNotEmpty())) {
                    saved = RuleLab.make(ctx)
                    savedN = RuleLab.savedCount(ctx, appId, featId)
                    confirmDel = false
                }
            })
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                com.odak.app.theme.QuietAction(stringResource(R.string.rl_reset), { RuleLab.reset(); saved = -1 })
                com.odak.app.theme.QuietAction("✕", onClose)
            }
        }
    )
}


/** Özellik ekle: kendi adını ver, istersen hazır şablon seç; sonra kuralı laboratuvarla öğret ya da elle gir. */
@Composable
fun AddFeatDialog(appId: String, onClose: (String?) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var tpl by remember { mutableStateOf<String?>(null) }
    var dup by remember { mutableStateOf(false) }
    val tplNames = listOf(
        "short" to stringResource(R.string.tpl_short), "stories" to stringResource(R.string.tpl_stories),
        "live" to stringResource(R.string.tpl_live), "msg" to stringResource(R.string.tpl_msg),
        "explore" to stringResource(R.string.tpl_explore), "shop" to stringResource(R.string.tpl_shop),
        "comments" to stringResource(R.string.tpl_comments), "feed" to stringResource(R.string.tpl_feed),
        "games" to stringResource(R.string.tpl_games)
    )
    AlertDialog(
        onDismissRequest = { onClose(null) },
        title = { Text(stringResource(R.string.uf_add)) },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                com.odak.app.theme.ThemedTextField(name, { name = it.replace("\n", " ").take(com.odak.app.logic.UserFeatPure.MAX_NAME); dup = false }, stringResource(R.string.uf_name), Modifier.fillMaxWidth())
                Text(stringResource(R.string.uf_tpl), style = MaterialTheme.typography.labelLarge)
                tplNames.forEach { (k, n) ->
                    com.odak.app.theme.QuietAction((if (tpl == k) "✔ " else "") + n, {
                        tpl = if (tpl == k) null else k
                        if (name.isBlank() && tpl != null) name = n
                    })
                }
                if (dup) Text(stringResource(R.string.uf_exists))
            }
        },
        confirmButton = {
            ThemedButton(stringResource(R.string.uf_create), {
                val id = UserFeats.add(ctx, appId, name, tpl)
                if (id == null) dup = name.isNotBlank() else onClose(id)
            })
        },
        dismissButton = { com.odak.app.theme.QuietAction("✕", { onClose(null) }) }
    )
}
