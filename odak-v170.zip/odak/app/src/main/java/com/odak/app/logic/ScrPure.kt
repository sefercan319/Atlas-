package com.odak.app.logic

/** Uyarı ekranı metinleri ve renk kararı (Android'e bağlı değil). */
object ScrPure {
    /** {feature} ve {app} yer tutucularını doldurur; bilinmeyen yer tutucu olduğu gibi kalır. */
    fun fill(t: String, feature: String, app: String): String = t.replace("{feature}", feature).replace("{app}", app)

    /** ARGB rengin algısal parlaklığı açık mı (üstüne koyu yazı gerekir)? */
    fun isLight(argb: Int): Boolean {
        val r = (argb shr 16) and 0xFF; val g = (argb shr 8) and 0xFF; val b = argb and 0xFF
        return (0.299 * r + 0.587 * g + 0.114 * b) > 140
    }

    /** Yazı ölçeği: "0" küçük, "2" büyük, diğer normal. */
    fun scale(size: String): Float = when (size) { "0" -> 0.75f; "2" -> 1.35f; else -> 1f }

    /** Aynı etkin özellik için üst üste uyarı açılmasın: son uyarıdan [gap] ms geçmeden açılmaz. */
    fun mayShow(now: Long, last: Long, gap: Long = 2500L): Boolean = now - last >= gap
}
