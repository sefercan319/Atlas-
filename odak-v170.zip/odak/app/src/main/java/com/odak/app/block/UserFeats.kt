package com.odak.app.block

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import com.odak.app.logic.UserFeatPure

/** Kullanıcının uygulamalara eklediği özellikler (bilinmeyen/özel uygulamalar dahil). */
object UserFeats {
    private val map = mutableStateMapOf<String, List<Feat>>()
    private var all: List<UserFeatPure.UF> = emptyList()

    private fun cp(c: Context) = c.getSharedPreferences("odak_block", Context.MODE_PRIVATE)

    fun of(app: String): List<Feat> = map[app] ?: emptyList()

    fun load(c: Context) {
        all = try { UserFeatPure.parse(cp(c).getString("user_feats", "") ?: "") } catch (e: Exception) { emptyList() }
        rebuild()
    }

    private fun rebuild() {
        map.clear()
        all.groupBy { it.app }.forEach { (a, l) -> map[a] = l.map { Feat(it.id, text = it.name) } }
    }

    private fun save(c: Context) = cp(c).edit().putString("user_feats", UserFeatPure.serialize(all)).apply()

    /** Özellik ekler; şablon verilmişse hazır kuralları da yazar. Eklenen özelliğin kimliği ya da (aynı ad varsa) null. */
    fun add(c: Context, app: String, rawName: String, template: String? = null): String? {
        val name = UserFeatPure.cleanName(rawName)
        if (name.isEmpty() || UserFeatPure.exists(all, app, name)) return null
        val id = UserFeatPure.id(name)
        all = all + UserFeatPure.UF(app, id, name)
        save(c); rebuild()
        if (template != null) RuleLab.addEntries(c, app, id, UserFeatPure.templateRules(template))
        return id
    }

    /** Özelliği, kurallarını ve ayarlarını siler. */
    fun remove(c: Context, app: String, id: String) {
        all = all.filterNot { it.app == app && it.id == id }
        save(c); rebuild()
        RuleLab.removeSaved(c, app, id)
        BlockStore.setFeatureBlocked(c, app, id, false)
        BlockStore.setFeatLimit(c, app, id, 0)
    }

    fun removeAll(c: Context, app: String) {
        all.filter { it.app == app }.forEach { remove(c, app, it.id) }
    }
}
