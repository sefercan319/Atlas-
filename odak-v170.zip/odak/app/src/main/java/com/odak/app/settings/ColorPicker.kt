package com.odak.app.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ColorMath
import com.odak.app.theme.Text
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedTextField
import com.odak.app.theme.plainClick

/** 24 renkli palet (3 satır × 8) + "Özel renk" düğmesi. */
@Composable
fun SwatchPalette(current: Color, onPick: (Color) -> Unit) {
    var custom by remember { mutableStateOf(false) }
    ColorMath.PALETTE.chunked(8).forEach { row ->
        Row(Modifier.padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            row.forEach { argb ->
                val c = Color(argb)
                Box(
                    Modifier.size(30.dp).background(c, CircleShape)
                        .border(if (argb == current.toArgb()) 3.dp else 1.dp, if (argb == current.toArgb()) Color.White else Color(0x55808080), CircleShape)
                        .plainClick { onPick(c) }
                )
            }
        }
    }
    Spacer(Modifier.height(4.dp))
    ThemedButton("🎨 " + stringResource(R.string.colors_custom), { custom = true })
    if (custom) CustomColorDialog(current, { custom = false }) { onPick(it); custom = false }
}

@Composable
private fun CustomColorDialog(initial: Color, onDismiss: () -> Unit, onPick: (Color) -> Unit) {
    val (h0, s0, v0) = remember { ColorMath.toHsv(initial.toArgb()) }
    var h by remember { mutableStateOf(h0) }
    var s by remember { mutableStateOf(s0) }
    var v by remember { mutableStateOf(v0) }
    var hex by remember { mutableStateOf(ColorMath.toHex(initial.toArgb())) }
    val argb = ColorMath.hsv(h, s, v)
    fun fromSliders(nh: Float, ns: Float, nv: Float) { h = nh; s = ns; v = nv; hex = ColorMath.toHex(ColorMath.hsv(nh, ns, nv)) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { ThemedButton(stringResource(R.string.pin_ok), { onPick(Color(argb)) }) },
        dismissButton = { com.odak.app.theme.QuietAction("✕", onDismiss) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.fillMaxWidth().height(44.dp).background(Color(argb), RoundedCornerShape(10.dp)).border(1.dp, Color(0x55808080), RoundedCornerShape(10.dp)))
                Slider(h, { fromSliders(it, s, v) }, valueRange = 0f..360f)
                Slider(s, { fromSliders(h, it, v) }, valueRange = 0f..1f)
                Slider(v, { fromSliders(h, s, it) }, valueRange = 0f..1f)
                ThemedTextField(hex, {
                    hex = it.take(7)
                    ColorMath.parseHex(it)?.let { p -> val (nh, ns, nv) = ColorMath.toHsv(p); h = nh; s = ns; v = nv }
                }, "#RRGGBB", Modifier.fillMaxWidth())
            }
        }
    )
}
