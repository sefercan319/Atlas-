package com.odak.app.block

import android.content.Context
import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedHeader
import com.odak.app.theme.ThemedTextField

object Pin {
    private fun prefs(c: Context) = c.getSharedPreferences("odak_pin", Context.MODE_PRIVATE)
    private var unlockedUntil = 0L

    fun isSet(c: Context) = prefs(c).contains("h")

    /** Yeni PIN'i sürüm 2 (PBKDF2) ile saklar. */
    private fun store(c: Context, pin: String) {
        val salt = com.odak.app.logic.PinHash.newSalt()
        prefs(c).edit()
            .putString("s", salt)
            .putString("h", com.odak.app.logic.PinHash.pbkdf2(pin, salt))
            .putInt("v", com.odak.app.logic.PinHash.VERSION)
            .apply()
    }

    fun set(c: Context, pin: String) {
        store(c, pin)
        unlock(c)
    }

    // ---- Ayarlar (neyi korusun, ne zaman tekrar kilitlensin, şifre türü) ----
    fun scopes(c: Context) = com.odak.app.logic.LockPolicy.cleanScopes(prefs(c).getInt("scopes", com.odak.app.logic.LockPolicy.DEFAULT_SCOPES))
    fun setScopes(c: Context, v: Int) = prefs(c).edit().putInt("scopes", com.odak.app.logic.LockPolicy.cleanScopes(v)).apply()
    fun timeout(c: Context) = com.odak.app.logic.LockPolicy.cleanTimeout(prefs(c).getInt("timeout", com.odak.app.logic.LockPolicy.DEFAULT_TIMEOUT))
    fun setTimeout(c: Context, v: Int) = prefs(c).edit().putInt("timeout", com.odak.app.logic.LockPolicy.cleanTimeout(v)).apply()
    /** true: parola (harf/rakam); false: yalnız rakam PIN. */
    fun isText(c: Context) = prefs(c).getBoolean("text", false)
    fun secure(c: Context) = isSet(c) && prefs(c).getBoolean("secure", false)
    fun setSecure(c: Context, v: Boolean) = prefs(c).edit().putBoolean("secure", v).apply()
    fun bio(c: Context) = isSet(c) && prefs(c).getBoolean("bio", false)
    fun setBio(c: Context, v: Boolean) = prefs(c).edit().putBoolean("bio", v).apply()

    /** Yeni şifre, tür ile birlikte saklanır; ayarlar korunur. */
    fun setWithType(c: Context, pw: String, text: Boolean) {
        prefs(c).edit().putBoolean("text", text).apply()
        set(c, pw)
    }

    private fun failPrefs(c: Context) = c.getSharedPreferences("odak_pinfail", Context.MODE_PRIVATE)

    /** Deneme sınırından kalan bekleme (ms); 0 = deneme yapılabilir. */
    fun lockRemainingMs(c: Context): Long {
        val f = failPrefs(c)
        return com.odak.app.logic.PinLimiter.remainingMs(f.getInt("n", 0), f.getLong("t", 0L), System.currentTimeMillis())
    }

    private fun recordFail(c: Context) {
        val f = failPrefs(c)
        f.edit().putInt("n", f.getInt("n", 0) + 1).putLong("t", System.currentTimeMillis()).commit()
    }

    fun check(c: Context, pin: String): Boolean {
        if (lockRemainingMs(c) > 0) return false // kilitliyken doğru PIN bile denenmez
        val p = prefs(c)
        val s = p.getString("s", null) ?: return false
        val stored = p.getString("h", null) ?: return false
        val ver = p.getInt("v", 1)
        if (!com.odak.app.logic.PinHash.verify(pin, s, stored, ver)) { recordFail(c); return false }
        failPrefs(c).edit().clear().apply()
        // Doğru PIN eski özetle saklanmışsa, aynı girişte güçlü özete yükselt.
        if (com.odak.app.logic.PinHash.needsUpgrade(ver)) store(c, pin)
        return true
    }

    fun clear(c: Context) { prefs(c).edit().clear().apply(); failPrefs(c).edit().clear().apply() }

    /** Doğru şifreden sonra ayarlanan süre kadar açık kalır. */
    fun unlock(c: Context) {
        unlockedUntil = com.odak.app.logic.LockPolicy.unlockedUntil(SystemClock.elapsedRealtime(), timeout(c))
    }

    fun locked(c: Context) = com.odak.app.logic.LockPolicy.isLocked(isSet(c), SystemClock.elapsedRealtime(), unlockedUntil)

    /** Ekran görüntüsü ve son uygulamalar önizlemesini engelle (ayar açıksa). */
    fun applySecure(a: android.app.Activity) {
        val f = android.view.WindowManager.LayoutParams.FLAG_SECURE
        if (secure(a)) a.window.setFlags(f, f) else a.window.clearFlags(f)
    }

    /** Bu bölüm korunuyor ve şu an kilitli mi? */
    fun needs(c: Context, scope: Int) =
        com.odak.app.logic.LockPolicy.needsGate(isSet(c), scopes(c), scope, SystemClock.elapsedRealtime(), unlockedUntil)
}

@Composable
fun PinGate(title: String, onUnlocked: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val text = Pin.isText(ctx)
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var lockSec by remember { mutableStateOf(((Pin.lockRemainingMs(ctx) + 999) / 1000).toInt()) }
    androidx.compose.runtime.LaunchedEffect(lockSec) {
        if (lockSec > 0) { kotlinx.coroutines.delay(1000); lockSec = ((Pin.lockRemainingMs(ctx) + 999) / 1000).toInt() }
    }
    val bioOn = com.odak.app.logic.LockPolicy.biometricOffered(Pin.bio(ctx), Bio.available(ctx), Pin.isSet(ctx))
    val bioTitle = stringResource(R.string.bio_title)
    val bioCancel = stringResource(R.string.bio_cancel)
    val forgotT = stringResource(R.string.pin_forgot_title)
    val canReset = Bio.resetAvailable(ctx)
    val bioGo = { Bio.prompt(ctx, bioTitle, bioCancel) { Pin.unlock(ctx); onUnlocked() } }
    androidx.compose.runtime.LaunchedEffect(Unit) { if (bioOn) bioGo() }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { Bio.cancel() } }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ThemedHeader(title)
        Spacer(Modifier.height(12.dp))
        ThemedTextField(
            value = pin,
            onValueChange = { pin = com.odak.app.logic.LockPolicy.filterInput(it, text); wrong = false },
            placeholder = stringResource(if (text) R.string.lock_enter else R.string.pin_enter),
            modifier = Modifier.fillMaxWidth(),
            secret = true,
            textPassword = text
        )
        if (lockSec > 0) Text(stringResource(R.string.pin_locked, lockSec), color = com.odak.app.theme.errorColor())
        else if (wrong) Text(stringResource(R.string.pin_wrong), color = com.odak.app.theme.errorColor())
        Spacer(Modifier.height(12.dp))
        ThemedButton(stringResource(R.string.pin_ok), {
            if (Pin.check(ctx, pin)) {
                Pin.unlock(ctx)
                onUnlocked()
            } else {
                wrong = true
                lockSec = ((Pin.lockRemainingMs(ctx) + 999) / 1000).toInt()
            }
        })
        if (canReset) {
            Spacer(Modifier.height(8.dp))
            com.odak.app.theme.QuietAction(stringResource(R.string.pin_forgot), {
                Bio.promptReset(ctx, forgotT) { Pin.clear(ctx); onUnlocked() }
            })
        }
        if (bioOn) {
            Spacer(Modifier.height(8.dp))
            com.odak.app.theme.QuietAction(stringResource(R.string.bio_use), { bioGo() })
        }
    }
}

/** Bölüm koruması: kilitliyse şifre ister, değilse içeriği gösterir. */
@Composable
fun LockGate(scope: Int, title: String, content: @Composable () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var locked by remember { mutableStateOf(Pin.needs(ctx, scope)) }
    if (locked) PinGate(title) { locked = false } else content()
}
