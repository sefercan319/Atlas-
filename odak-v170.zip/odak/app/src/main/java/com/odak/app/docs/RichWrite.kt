package com.odak.app.docs

/** Zengin sayfa → DOCX gövdesi, RTF gövdesi, ODT gövdesi. Biçim (kalın, renk, hizalama, girinti, tablo çizgisi/gölge/birleştirme, sayfa boyutu) korunur. */
object RichWrite {
    private fun x(s: String) = DocConvert.xml(s)

    // ---------------- DOCX ----------------
    private fun wBd(tag: String, d: Bd?): String =
        if (d == null || d.w <= 0) "<w:$tag w:val=\"nil\"/>" else "<w:$tag w:val=\"single\" w:sz=\"${d.w.coerceIn(2, 96)}\" w:space=\"0\" w:color=\"${d.color}\"/>"

    private fun wRpr(r: RRun): String {
        val sb = StringBuilder()
        r.font?.let { f -> val n = x(f); sb.append("<w:rFonts w:ascii=\"$n\" w:hAnsi=\"$n\" w:cs=\"$n\"/>") }
        if (r.b) sb.append("<w:b/>")
        if (r.i) sb.append("<w:i/>")
        if (r.s) sb.append("<w:strike/>")
        Rich.hex(r.color)?.let { sb.append("<w:color w:val=\"$it\"/>") }
        if (r.sz > 0) sb.append("<w:sz w:val=\"${r.sz}\"/><w:szCs w:val=\"${r.sz}\"/>")
        if (r.u) sb.append("<w:u w:val=\"single\"/>")
        Rich.hex(r.hl)?.let { sb.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"$it\"/>") }
        if (r.sup > 0) sb.append("<w:vertAlign w:val=\"superscript\"/>") else if (r.sup < 0) sb.append("<w:vertAlign w:val=\"subscript\"/>")
        return if (sb.isEmpty()) "" else "<w:rPr>$sb</w:rPr>"
    }

    /** DOCX'e gömülecek resimler: media/ dosyaları ve document.xml.rels satırları. */
    class DocxMedia {
        val files = ArrayList<Pair<String, ByteArray>>()
        val rels = StringBuilder()
        var n = 0
        fun add(img: RImg): String {
            n++
            val name = "image$n.${img.ext}"
            files.add("word/media/$name" to img.data)
            rels.append("<Relationship Id=\"rIdImg$n\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/$name\"/>")
            return "rIdImg$n"
        }
    }

    private fun wDrawing(img: RImg, m: DocxMedia): String {
        val id = m.add(img)
        val cx = img.w.toLong() * 635; val cy = img.h.toLong() * 635
        val n = m.n
        return "<w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"$cx\" cy=\"$cy\"/><wp:docPr id=\"$n\" name=\"Picture $n\"/>" +
            "<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\"><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
            "<pic:pic xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:nvPicPr><pic:cNvPr id=\"$n\" name=\"image$n\"/><pic:cNvPicPr/></pic:nvPicPr>" +
            "<pic:blipFill><a:blip r:embed=\"$id\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
            "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>"
    }

    private fun wRun(r: RRun, m: DocxMedia?): String {
        if (r.img != null) return if (m != null) wDrawing(r.img, m) else ""
        val rpr = wRpr(r)
        val sb = StringBuilder()
        val parts = Regex("[\n\t]|[^\n\t]+").findAll(r.text).map { it.value }
        for (p in parts) when (p) {
            "\n" -> sb.append("<w:r>$rpr<w:br/></w:r>")
            "\t" -> sb.append("<w:r>$rpr<w:tab/></w:r>")
            else -> sb.append("<w:r>$rpr<w:t xml:space=\"preserve\">").append(x(p)).append("</w:t></w:r>")
        }
        return sb.toString()
    }

    fun wPara(p: RPara, m: DocxMedia? = null): String {
        val ppr = StringBuilder()
        if (p.head > 0) ppr.append("<w:keepNext/>")
        if (p.pageBreak) ppr.append("<w:pageBreakBefore/>")
        if (p.top != null || p.bottom != null) {
            ppr.append("<w:pBdr>")
            if (p.top != null) ppr.append(wBd("top", p.top).replace("w:space=\"0\"", "w:space=\"1\""))
            if (p.bottom != null) ppr.append(wBd("bottom", p.bottom).replace("w:space=\"0\"", "w:space=\"1\""))
            ppr.append("</w:pBdr>")
        }
        Rich.hex(p.fill)?.let { ppr.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"$it\"/>") }
        if (p.before >= 0 || p.after >= 0 || p.line > 0) {
            ppr.append("<w:spacing")
            if (p.before >= 0) ppr.append(" w:before=\"${p.before}\"")
            if (p.after >= 0) ppr.append(" w:after=\"${p.after}\"")
            if (p.line > 0) ppr.append(" w:line=\"${p.line}\" w:lineRule=\"auto\"")
            ppr.append("/>")
        }
        if (p.left != 0 || p.first != 0) {
            ppr.append("<w:ind w:left=\"${maxOf(p.left, 0)}\"")
            if (p.first < 0) ppr.append(" w:hanging=\"${-p.first}\"") else if (p.first > 0) ppr.append(" w:firstLine=\"${p.first}\"")
            ppr.append("/>")
        }
        when (p.align) { "center" -> ppr.append("<w:jc w:val=\"center\"/>"); "right" -> ppr.append("<w:jc w:val=\"right\"/>"); "justify" -> ppr.append("<w:jc w:val=\"both\"/>") }
        if (p.head > 0) ppr.append("<w:outlineLvl w:val=\"${p.head - 1}\"/>")
        val sb = StringBuilder("<w:p>")
        if (ppr.isNotEmpty()) sb.append("<w:pPr>").append(ppr).append("</w:pPr>")
        if (p.marker.isNotEmpty()) sb.append("<w:r><w:t xml:space=\"preserve\">").append(x(p.marker)).append("</w:t></w:r><w:r><w:tab/></w:r>")
        for (r in p.runs) if (r.text.isNotEmpty() || r.img != null) sb.append(wRun(r, m))
        return sb.append("</w:p>").toString()
    }

    private fun colWidths(t: RTable, textW: Int): List<Int> {
        val n = Rich.tableCols(t).coerceAtLeast(1)
        if (t.cols.size == n && t.cols.all { it > 0 }) return t.cols
        return List(n) { textW / n }
    }

    fun wTable(t: RTable, rp: RichPage, m: DocxMedia? = null): String {
        val textW = (rp.setup.w - rp.setup.left - rp.setup.right).coerceAtLeast(2000)
        val cols = colWidths(t, textW)
        val starts = Rich.gridStarts(t)
        val sb = StringBuilder("<w:tbl><w:tblPr><w:tblW w:w=\"${cols.sum()}\" w:type=\"dxa\"/><w:tblLayout w:type=\"fixed\"/></w:tblPr><w:tblGrid>")
        for (c in cols) sb.append("<w:gridCol w:w=\"$c\"/>")
        sb.append("</w:tblGrid>")
        t.rows.forEachIndexed { r, row ->
            sb.append("<w:tr>")
            row.forEachIndexed { k, c ->
                val s0 = starts[r][k]
                val w = (s0 until (s0 + c.span)).sumOf { cols.getOrElse(it) { 0 } }.takeIf { it > 0 } ?: 1000
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"$w\" w:type=\"dxa\"/>")
                if (c.span > 1) sb.append("<w:gridSpan w:val=\"${c.span}\"/>")
                if (c.vMerge == 1) sb.append("<w:vMerge w:val=\"restart\"/>") else if (c.vMerge == 2) sb.append("<w:vMerge/>")
                sb.append("<w:tcBorders>").append(wBd("top", c.bt)).append(wBd("left", c.bl)).append(wBd("bottom", c.bb)).append(wBd("right", c.br)).append("</w:tcBorders>")
                Rich.hex(c.fill)?.let { sb.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"$it\"/>") }
                when (c.valign) { "center" -> sb.append("<w:vAlign w:val=\"center\"/>"); "bottom" -> sb.append("<w:vAlign w:val=\"bottom\"/>") }
                sb.append("</w:tcPr>")
                if (c.paras.isEmpty()) sb.append("<w:p/>") else for (p in c.paras) sb.append(wPara(p, m))
                sb.append("</w:tc>")
            }
            sb.append("</w:tr>")
        }
        return sb.append("</w:tbl>").toString()
    }

    fun wBody(rp: RichPage, m: DocxMedia? = null): String {
        val sb = StringBuilder()
        var prevTable = false
        for (b in rp.blocks) {
            when (b) {
                is RPara -> { sb.append(wPara(b, m)); prevTable = false }
                is RTable -> { if (prevTable) sb.append("<w:p/>"); sb.append(wTable(b, rp, m)); prevTable = true }
                is RBox -> {}
            }
        }
        if (prevTable || rp.blocks.isEmpty()) sb.append("<w:p/>")
        return sb.toString()
    }

    fun wSect(s: PageSetup, hdr: String? = null, ftr: String? = null): String =
        "<w:sectPr>" + (if (hdr != null) "<w:headerReference w:type=\"default\" r:id=\"$hdr\"/>" else "") + (if (ftr != null) "<w:footerReference w:type=\"default\" r:id=\"$ftr\"/>" else "") + "<w:pgSz w:w=\"${s.w}\" w:h=\"${s.h}\"" + (if (s.landscape) " w:orient=\"landscape\"" else "") +
            "/><w:pgMar w:top=\"${s.top}\" w:right=\"${s.right}\" w:bottom=\"${s.bottom}\" w:left=\"${s.left}\" w:header=\"709\" w:footer=\"709\" w:gutter=\"0\"/></w:sectPr>"

    // ---------------- RTF ----------------
    class RtfCtx {
        val fonts = LinkedHashMap<String, Int>()
        val colors = LinkedHashMap<String, Int>()
        fun font(n: String?): Int = if (n == null) 0 else fonts.getOrPut(n) { fonts.size + 1 }
        fun color(c: String?): Int { val h = Rich.hex(c) ?: return 0; return colors.getOrPut(h) { colors.size + 1 } }
        fun header(defFont: String): String {
            val sb = StringBuilder("{\\fonttbl{\\f0\\fswiss ").append(DocConvert.rtf(defFont)).append(";}")
            for ((n, i) in fonts) sb.append("{\\f").append(i).append("\\fnil ").append(DocConvert.rtf(n)).append(";}")
            sb.append("}{\\colortbl;")
            for ((h, _) in colors) sb.append("\\red").append(h.substring(0, 2).toInt(16)).append("\\green").append(h.substring(2, 4).toInt(16)).append("\\blue").append(h.substring(4, 6).toInt(16)).append(';')
            return sb.append("}").toString()
        }
    }

    private fun rBd(side: String, d: Bd?): String =
        if (d == null || d.w <= 0) "\\$side\\brdrnil" else "\\$side\\brdrs\\brdrw${(d.w * 20 / 8).coerceIn(5, 75)}"

    private fun rImg(im0: RImg): String {
        // GIF: RTF'te yok; çevirici varsa PNG'ye çevrilir
        val im = if (im0.mime == "image/gif") (try { RImg.converter?.invoke(im0.data) } catch (e: Exception) { null })?.takeIf { RImg.mimeOf("", it) == "image/png" }?.let { RImg(it, "image/png", im0.w, im0.h) } ?: im0 else im0
        val kind = when (im.mime) { "image/png" -> "\\pngblip"; "image/jpeg" -> "\\jpegblip"; else -> return "[image]" }
        val px = RImg.pixelSize(im.data)
        val sb = StringBuilder("{\\pict").append(kind).append("\\picwgoal").append(im.w).append("\\pichgoal").append(im.h)
        if (px != null) sb.append("\\picw").append(px.first).append("\\pich").append(px.second)
        sb.append('\n')
        val hex = "0123456789abcdef"
        for ((i, b) in im.data.withIndex()) { sb.append(hex[(b.toInt() shr 4) and 15]).append(hex[b.toInt() and 15]); if (i % 40 == 39) sb.append('\n') }
        return sb.append("}").toString()
    }

    private fun rRun(r: RRun, c: RtfCtx, rp: RichPage): String {
        r.img?.let { return rImg(it) }
        val f = StringBuilder()
        if (r.font != null && r.font != rp.defFont) f.append("\\f").append(c.font(r.font))
        if (r.b) f.append("\\b"); if (r.i) f.append("\\i"); if (r.u) f.append("\\ul"); if (r.s) f.append("\\strike")
        if (r.sup > 0) f.append("\\super") else if (r.sup < 0) f.append("\\sub")
        if (r.sz > 0) f.append("\\fs").append(r.sz)
        val cf = c.color(r.color); if (cf > 0) f.append("\\cf").append(cf)
        val hl = c.color(r.hl); if (hl > 0) f.append("\\highlight").append(hl)
        val txt = DocConvert.rtf(r.text)
        if (f.isEmpty()) return txt
        return "{" + f + " " + txt + "}"
    }

    fun rPara(p: RPara, c: RtfCtx, rp: RichPage, inTable: Boolean = false): String {
        val sb = StringBuilder(if (inTable) "\\pard\\intbl" else "\\pard")
        if (p.pageBreak) sb.append("\\pagebb")
        when (p.align) { "center" -> sb.append("\\qc"); "right" -> sb.append("\\qr"); "justify" -> sb.append("\\qj") }
        if (p.left != 0) sb.append("\\li").append(maxOf(p.left, 0))
        if (p.first != 0) sb.append("\\fi").append(p.first)
        if (p.before >= 0) sb.append("\\sb").append(p.before)
        if (p.after >= 0) sb.append("\\sa").append(p.after)
        if (p.line > 0) sb.append("\\sl").append(p.line).append("\\slmult1")
        if (p.top != null) sb.append("\\brdrt\\brdrs\\brdrw10")
        if (p.bottom != null) sb.append("\\brdrb\\brdrs\\brdrw10")
        val sh = c.color(p.fill); if (sh > 0) sb.append("\\cbpat").append(sh)
        sb.append(' ')
        if (p.head > 0) sb.append("\\keepn ")
        if (p.marker.isNotEmpty()) sb.append(DocConvert.rtf(p.marker)).append("\\tab ")
        for (r in p.runs) if (r.text.isNotEmpty() || r.img != null) sb.append(rRun(r, c, rp))
        return sb.toString()
    }

    fun rBody(rp: RichPage, c: RtfCtx): String {
        val sb = StringBuilder()
        val textW = (rp.setup.w - rp.setup.left - rp.setup.right).coerceAtLeast(2000)
        for (b in rp.blocks) when (b) {
            is RPara -> sb.append(rPara(b, c, rp)).append("\\par\n")
            is RBox -> {}
            is RTable -> {
                val cols = colWidths(b, textW)
                val starts = Rich.gridStarts(b)
                b.rows.forEachIndexed { r, row ->
                    sb.append("\\trowd\\trgaph108")
                    row.forEachIndexed { k, cell ->
                        val s0 = starts[r][k]
                        val endX = (0 until (s0 + cell.span)).sumOf { cols.getOrElse(it) { 0 } }
                        if (cell.vMerge == 1) sb.append("\\clvmgf") else if (cell.vMerge == 2) sb.append("\\clvmrg")
                        sb.append(rBd("clbrdrt", cell.bt)).append(rBd("clbrdrl", cell.bl)).append(rBd("clbrdrb", cell.bb)).append(rBd("clbrdrr", cell.br))
                        val sh = c.color(cell.fill); if (sh > 0) sb.append("\\clcbpat").append(sh)
                        when (cell.valign) { "center" -> sb.append("\\clvertalc"); "bottom" -> sb.append("\\clvertalb") }
                        sb.append("\\cellx").append(endX)
                    }
                    for (cell in row) {
                        if (cell.paras.isEmpty()) sb.append("\\pard\\intbl ")
                        else cell.paras.forEachIndexed { i, p -> if (i > 0) sb.append("\\par "); sb.append(rPara(p, c, rp, true)) }
                        sb.append("\\cell ")
                    }
                    sb.append("\\row\n")
                }
                sb.append("\\pard\\par\n")
            }
        }
        return sb.toString()
    }

    fun rPage(s: PageSetup): String =
        "\\paperw${s.w}\\paperh${s.h}" + (if (s.landscape) "\\landscape" else "") + "\\margl${s.left}\\margr${s.right}\\margt${s.top}\\margb${s.bottom}"

    // ---------------- ODT ----------------
    class OdtCtx {
        val styles = StringBuilder()
        val pics = ArrayList<Pair<String, ByteArray>>()
        private val cache = HashMap<String, String>()
        private var n = 0
        fun style(key: String, build: (String) -> String): String =
            cache.getOrPut(key) { val name = "A${++n}"; styles.append(build(name)); name }
    }

    private fun cm(twips: Int) = String.format(java.util.Locale.US, "%.3fcm", twips * 2.54 / 1440.0)
    private fun oBd(d: Bd?): String = if (d == null || d.w <= 0) "none" else "${String.format(java.util.Locale.US, "%.2f", maxOf(d.w / 8.0, 0.5))}pt solid #${d.color}"

    private fun spanStyle(r: RRun, o: OdtCtx, rp: RichPage): String? {
        val a = StringBuilder()
        if (r.b) a.append(" fo:font-weight=\"bold\"")
        if (r.i) a.append(" fo:font-style=\"italic\"")
        if (r.u) a.append(" style:text-underline-style=\"solid\" style:text-underline-width=\"auto\" style:text-underline-color=\"font-color\"")
        if (r.s) a.append(" style:text-line-through-style=\"solid\"")
        Rich.hex(r.color)?.let { a.append(" fo:color=\"#$it\"") }
        Rich.hex(r.hl)?.let { a.append(" fo:background-color=\"#$it\"") }
        if (r.sz > 0 && r.sz != rp.defSz) a.append(" fo:font-size=\"${r.sz / 2.0}pt\"")
        r.font?.let { f -> if (f != rp.defFont) a.append(" fo:font-family=\"${x(f)}\"") }
        if (r.sup > 0) a.append(" style:text-position=\"super 58%\"") else if (r.sup < 0) a.append(" style:text-position=\"sub 58%\"")
        if (a.isEmpty()) return null
        val key = "T" + a
        return o.style(key) { nm -> "<style:style style:name=\"$nm\" style:family=\"text\"><style:text-properties$a/></style:style>" }
    }

    private fun odfRunText(s: String): String {
        val sb = StringBuilder()
        for (m in Regex("[\n\t]|[^\n\t]+").findAll(s)) when (val v = m.value) {
            "\n" -> sb.append("<text:line-break/>")
            "\t" -> sb.append("<text:tab/>")
            else -> sb.append(x(v).replace(Regex(" {2,}")) { "<text:s text:c=\"${it.value.length}\"/>" }.let { t -> if (t.startsWith(" ")) "<text:s/>" + t.substring(1) else t })
        }
        return sb.toString()
    }

    fun oPara(p: RPara, o: OdtCtx, rp: RichPage): String {
        val a = StringBuilder()
        when (p.align) { "center" -> a.append(" fo:text-align=\"center\""); "right" -> a.append(" fo:text-align=\"end\""); "justify" -> a.append(" fo:text-align=\"justify\"") }
        if (p.left != 0) a.append(" fo:margin-left=\"${cm(maxOf(p.left, 0))}\"")
        if (p.first != 0) a.append(" fo:text-indent=\"${cm(p.first)}\"")
        val before = if (p.before >= 0) p.before else 0
        val after = if (p.after >= 0) p.after else rp.defAfter
        a.append(" fo:margin-top=\"${cm(before)}\" fo:margin-bottom=\"${cm(after)}\"")
        val line = if (p.line > 0) p.line else rp.defLine
        if (line > 0) a.append(" fo:line-height=\"${line * 100 / 240}%\"")
        if (p.top != null) a.append(" fo:border-top=\"${oBd(p.top)}\"")
        if (p.bottom != null) a.append(" fo:border-bottom=\"${oBd(p.bottom)}\"")
        Rich.hex(p.fill)?.let { a.append(" fo:background-color=\"#$it\"") }
        if (p.pageBreak) a.append(" fo:break-before=\"page\"")
        val ps = o.style("P$a") { nm -> "<style:style style:name=\"$nm\" style:family=\"paragraph\"><style:paragraph-properties$a/></style:style>" }
        val open = if (p.head in 1..6) "<text:h text:style-name=\"$ps\" text:outline-level=\"${p.head}\">" else "<text:p text:style-name=\"$ps\">"
        val close = if (p.head in 1..6) "</text:h>" else "</text:p>"
        val sb = StringBuilder(open)
        if (p.marker.isNotEmpty()) sb.append(x(p.marker)).append("<text:tab/>")
        for (r in p.runs) {
            r.img?.let { im ->
                val nm = "Pictures/img${o.pics.size + 1}.${im.ext}"
                o.pics.add(nm to im.data)
                sb.append("<draw:frame draw:name=\"Image${o.pics.size}\" text:anchor-type=\"as-char\" svg:width=\"${cm(im.w)}\" svg:height=\"${cm(im.h)}\"><draw:image xlink:href=\"$nm\" xlink:type=\"simple\" xlink:show=\"embed\" xlink:actuate=\"onLoad\"/></draw:frame>")
                return@let
            }
            if (r.text.isEmpty()) continue
            val sn = spanStyle(r, o, rp)
            val body = odfRunText(r.text)
            if (sn == null) sb.append(body) else sb.append("<text:span text:style-name=\"$sn\">").append(body).append("</text:span>")
        }
        return sb.append(close).toString()
    }

    fun oTable(t: RTable, o: OdtCtx, rp: RichPage, num: Int): String {
        val textW = (rp.setup.w - rp.setup.left - rp.setup.right).coerceAtLeast(2000)
        val cols = colWidths(t, textW)
        val starts = Rich.gridStarts(t)
        val tbl = o.style("TBL${cols.sum()}") { nm -> "<style:style style:name=\"$nm\" style:family=\"table\"><style:table-properties style:width=\"${cm(cols.sum())}\" table:align=\"left\"/></style:style>" }
        val sb = StringBuilder("<table:table table:name=\"Tablo$num\" table:style-name=\"$tbl\">")
        cols.forEachIndexed { i, w ->
            val cs = o.style("COL$w") { nm -> "<style:style style:name=\"$nm\" style:family=\"table-column\"><style:table-column-properties style:column-width=\"${cm(w)}\"/></style:style>" }
            sb.append("<table:table-column table:style-name=\"$cs\"/>")
        }
        t.rows.forEachIndexed { r, row ->
            sb.append("<table:table-row>")
            row.forEachIndexed { k, c ->
                if (c.vMerge == 2) {
                    repeat(c.span) { sb.append("<table:covered-table-cell/>") }
                    return@forEachIndexed
                }
                val a = StringBuilder(" fo:padding=\"0.1cm\"")
                a.append(" fo:border-top=\"${oBd(c.bt)}\" fo:border-left=\"${oBd(c.bl)}\" fo:border-bottom=\"${oBd(c.bb)}\" fo:border-right=\"${oBd(c.br)}\"")
                Rich.hex(c.fill)?.let { a.append(" fo:background-color=\"#$it\"") }
                when (c.valign) { "center" -> a.append(" style:vertical-align=\"middle\""); "bottom" -> a.append(" style:vertical-align=\"bottom\"") }
                val cs = o.style("CELL$a") { nm -> "<style:style style:name=\"$nm\" style:family=\"table-cell\"><style:table-cell-properties$a/></style:style>" }
                val rs = Rich.rowSpan(t, starts, r, k)
                sb.append("<table:table-cell table:style-name=\"$cs\" office:value-type=\"string\"")
                if (c.span > 1) sb.append(" table:number-columns-spanned=\"${c.span}\"")
                if (rs > 1) sb.append(" table:number-rows-spanned=\"$rs\"")
                sb.append(">")
                if (c.paras.isEmpty()) sb.append("<text:p/>") else for (p in c.paras) sb.append(oPara(p, o, rp))
                sb.append("</table:table-cell>")
                repeat(c.span - 1) { sb.append("<table:covered-table-cell/>") }
            }
            sb.append("</table:table-row>")
        }
        return sb.append("</table:table>").toString()
    }

    fun oBody(rp: RichPage, o: OdtCtx, tableNo: Int): String {
        val sb = StringBuilder()
        var n = tableNo
        for (b in rp.blocks) sb.append(when (b) { is RPara -> oPara(b, o, rp); is RTable -> oTable(b, o, rp, ++n); is RBox -> "" })
        return sb.toString()
    }

    fun oDefaults(rp: RichPage): String =
        "<office:styles><style:default-style style:family=\"paragraph\"><style:text-properties fo:font-family=\"${x(rp.defFont ?: "Calibri")}\" fo:font-size=\"${rp.defSz / 2.0}pt\"/></style:default-style></office:styles>"

    fun oPageLayout(s: PageSetup): String =
        "<style:page-layout style:name=\"pm1\"><style:page-layout-properties fo:page-width=\"${cm(s.w)}\" fo:page-height=\"${cm(s.h)}\" " +
            "style:print-orientation=\"${if (s.landscape) "landscape" else "portrait"}\" fo:margin-top=\"${cm(s.top)}\" fo:margin-bottom=\"${cm(s.bottom)}\" " +
            "fo:margin-left=\"${cm(s.left)}\" fo:margin-right=\"${cm(s.right)}\"/></style:page-layout>"
}
