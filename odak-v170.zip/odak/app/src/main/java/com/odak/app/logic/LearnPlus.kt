package com.odak.app.logic

import java.util.Random
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Gelişmiş öğrenme katmanı (saf mantık): Adam iyileştirici, yeni örneklere daha çok ağırlık (yenilik),
 * Platt kalibrasyonu (puan = gerçek olasılık), "neden" açıklaması ve en çok öğreten adayı seçme (aktif öğrenme).
 */
object LearnPlus {
    /** Yenilik ağırlığı: en yeni örnek 1.0, en eski [floor]. Eski kullanıcı tercihleri unutulmaz ama yenisi baskın olur. */
    fun recency(i: Int, n: Int, floor: Double = 0.4): Double = if (n <= 1) 1.0 else floor + (1.0 - floor) * i / (n - 1)

    fun weighted(ex: List<LearnPure.Ex>): List<LearnPure.Ex> = ex.mapIndexed { i, e ->
        if (e.weight != 1.0) e else LearnPure.Ex(e.entry, e.ratio, e.inNeg, e.name, e.label, e.conflict, recency(i, ex.size))
    }

    /** Adam ile eğitim (mini yığın yok; tek örnek). [mask] varsa yalnız işaretli ağırlıklar güncellenir. */
    fun trainAdam(ex: List<LearnPure.Ex>, epochs: Int = 40, start: DoubleArray? = null, epoch0: Int = 0, mask: BooleanArray? = null, l2: Double = 0.001, lr: Double = 0.05): DoubleArray {
        val dim = LearnPure.DIM
        val w = start?.copyOf() ?: DoubleArray(dim)
        if (ex.isEmpty()) return w
        val xs = ex.map { LearnPure.features(it.entry, it.ratio, it.inNeg, it.name, it.conflict) }
        val pw = LearnPure.posWeight(ex)
        val m = DoubleArray(dim); val v = DoubleArray(dim)
        val idx = ex.indices.toMutableList(); val rnd = Random(11L + epoch0)
        var step = 0
        val b1 = 0.9; val b2 = 0.999
        for (ep in 0 until epochs) {
            idx.shuffle(rnd)
            for (i in idx) {
                step++
                val y = if (ex[i].label) 1.0 else 0.0
                val gl = (LearnPure.predict(w, xs[i]) - y) * (if (ex[i].label) pw else 1.0) * ex[i].weight
                for (j in 0 until dim) {
                    if (mask != null && !mask[j]) continue
                    val g = gl * xs[i][j] + l2 * w[j]
                    m[j] = b1 * m[j] + (1 - b1) * g
                    v[j] = b2 * v[j] + (1 - b2) * g * g
                    val mh = m[j] / (1 - Math.pow(b1, step.toDouble())); val vh = v[j] / (1 - Math.pow(b2, step.toDouble()))
                    w[j] -= lr * mh / (sqrt(vh) + 1e-8)
                }
            }
        }
        return w
    }

    class Calib(val a: Double, val b: Double) {
        fun apply(p: Double): Double {
            val q = p.coerceIn(1e-6, 1 - 1e-6)
            return LearnPure.sigmoid(a * ln(q / (1 - q)) + b)
        }
        fun encode() = String.format(java.util.Locale.US, "%.4f,%.4f", a, b)
        companion object {
            val NONE = Calib(1.0, 0.0)
            fun decode(s: String?): Calib = try { s!!.split(',').let { Calib(it[0].toDouble(), it[1].toDouble()) } } catch (e: Exception) { NONE }
        }
    }

    /** Platt kalibrasyonu: doğrulama örneklerinde p → sigmoid(a·logit(p)+b) (az örnekte kalibrasyon yok). */
    fun calibrate(w: DoubleArray, ex: List<LearnPure.Ex>, steps: Int = 300): Calib {
        if (ex.size < 20 || ex.none { it.label } || ex.all { it.label }) return Calib.NONE
        val z = ex.map { val p = LearnPure.predict(w, it).coerceIn(1e-6, 1 - 1e-6); ln(p / (1 - p)) }
        val y = ex.map { if (it.label) 1.0 else 0.0 }
        var a = 1.0; var b = 0.0
        for (s in 0 until steps) {
            var ga = 0.0; var gb = 0.0
            for (i in z.indices) { val e = LearnPure.sigmoid(a * z[i] + b) - y[i]; ga += e * z[i]; gb += e }
            a -= 0.05 * ga / z.size; b -= 0.05 * gb / z.size
        }
        return Calib(a.coerceIn(0.1, 5.0), b.coerceIn(-3.0, 3.0))
    }

    /** Beklenen kalibrasyon hatası (ECE, %): düşük = puanlar güvenilir. 5 kutu. */
    fun ece(w: DoubleArray, ex: List<LearnPure.Ex>, cal: Calib = Calib.NONE): Int {
        if (ex.isEmpty()) return 0
        val bins = Array(5) { ArrayList<Pair<Double, Boolean>>() }
        for (e in ex) { val p = cal.apply(LearnPure.predict(w, e)); bins[minOf(4, (p * 5).toInt())].add(p to e.label) }
        var tot = 0.0
        for (b in bins) if (b.isNotEmpty()) tot += abs(b.sumOf { it.first } / b.size - b.count { it.second }.toDouble() / b.size) * b.size
        return (tot / ex.size * 100).toInt()
    }

    /** En çok etki eden en fazla [k] neden, simge olarak (dile bağlı değil): 🎯 ada uyuyor · 📌 sık · ⚠ başka yerde de var · ⛔ çatışma · 💤 genel · 🔤 kelime/harf · 🔢 sayılı. */
    fun explain(w: DoubleArray, c: UserFeatPure.Cand, name: Boolean, k: Int = 3): String {
        val x = LearnPure.features(c.entry, c.ratio, c.inNeg, name, c.conflict)
        val parts = ArrayList<Pair<String, Double>>()
        fun add(sym: String, vararg idx: Int) { val v = idx.sumOf { w[it] * x[it] }; if (abs(v) > 0.05) parts.add(sym to v) }
        add("🎯", 8); add("📌", 5, 15); add("⚠", 6); add("⛔", 13); add("💤", 12); add("🔢", 9, 14)
        val lex = (LearnPure.BASE until LearnPure.DIM).sumOf { w[it] * x[it] }
        if (abs(lex) > 0.05) parts.add("🔤" to lex)
        return parts.sortedByDescending { abs(it.second) }.take(k).joinToString("") { (if (it.second >= 0) "" else "−") + it.first }
    }

    /** Aktif öğrenme: puanı 0.5'e en yakın [k] aday (modelin en kararsız olduğu) — kullanıcı bunlara karar verirse en çok öğrenilir. */
    fun uncertain(cands: List<UserFeatPure.Cand>, k: Int = 1, scorer: (UserFeatPure.Cand) -> Double): Set<String> =
        cands.filter { !it.inNeg && !it.conflict }.sortedBy { abs(scorer(it) - 0.5) }.take(k).map { it.entry }.toSet()
}
