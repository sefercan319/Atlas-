package com.odak.app.logic

/** Engelleme kataloğuna üçüncü ek uygulama grubu ("Ad|paket"): yapay zekâ, bölgesel sosyal/video/alışveriş/finans, oyunlar, manga/anime, kripto vb. Eşleşmeyen paket yalnızca eşleşmez; tekrarlar çalışma anında elenir. */
object MoreAppsData3 {
    private const val R0 = """
ChatGPT|com.openai.chatgpt
Claude|com.anthropic.claude
Perplexity|ai.perplexity.app.android
Grok|ai.x.grok
DeepSeek|com.deepseek.chat
Snapchat Spectacles|com.snap.spectacles
Twitter Spaces|com.twitter.spaces
BlueSky Social|app.bsky.android
Spill|app.spill.android
Lemon8 Lite|com.bd.nproject.lite
Instagram Threads Lite|com.instagram.barcelona.lite
Douyin Lite|com.ss.android.ugc.aweme.lite
RedNote|com.xingin.xhs.intl
QQ Lite|com.tencent.qqlite
Soul|cn.soulapp.android
Tandem|net.tandem
Wakie|com.wakie.android
Fizz|com.fizzapp.android
Houzz|com.houzz.app
Habitica|com.habitrpg.android.habitica
Tasty|com.buzzfeed.tasty
Yummly|com.yummly.android
Cookpad|com.mufumbo.android.recipe.search
Nefis Yemek Tarifleri|com.nefisyemektarifleri.android
Okko|ru.more.play
Ivi|ru.ivi.client
Likee Lite|video.like.lite
TopBuzz|com.ss.android.article.master
Dailyhunt|com.eterno
Airtel Xstream|tv.accedo.airtel.wynk
Hungama|com.hungama.myplay.activity
Netflix Kids|com.netflix.kids
TOD|tr.com.tod
Disney Plus Hotstar|com.disney.disneyplus.hotstar
TV 360|tr.com.turktelekom.tv360
Tabii|tr.gov.trt.tabii
Digitürk Play|com.digiturk.digiturkplay
S Sport Plus|com.ssport.plus
Exxen TV|com.exxen.tv
Mubi Go|com.mubi.go
Facebook Watch|com.facebook.watch
Instagram Reels|com.instagram.reels
Threads Beta|com.instagram.barcelona.beta
Musical.ly|com.zhiliaoapp.musically.go.lite
Hay Day Pop|com.supercell.hayday.pop
Mo.co|com.supercell.moco
Diamond Diaries|com.king.diamonddiaries
Toon Blast|com.peakgames.toonblast
Toy Blast|com.dreamgames.toyblast
Gardenscapes Lite|com.playrix.gardenscapes.lite
Dragonscapes|com.playrix.dragonscapes
Puzzles & Survival|com.yottagames.survival
Rise of Empires|com.zloong.eu.roe
Game of Sultans|com.gamegos.sultans
War and Order|com.camelgames.superking
Art of War 3|com.vitaminfire.artofwar3
Throne Rush|com.plarium.thronerush
Hero Wars Alliance|com.nexters.herowars.alliance
Fishing Clash|com.ten.fishingclash
Hunting Clash|com.ten.huntingclash
Golf Clash|com.playdemic.golf.android
Mini Militia|com.appsomniacs.da2
Hungry Shark World|com.fgol.HungrySharkWorld
Car Simulator 2|com.oppanagames.carsimulator2
Euro Truck Driver|com.truck.driver.euro
Real Gangster Crime|com.gangster.crime.vegas
Grand Gangsters|com.gameloft.android.ANMP.GloftGGHM
Gangstar Vegas|com.gameloft.android.ANMP.GloftGTHM
Order & Chaos 2|com.gameloft.android.ANMP.GloftOCHM
Gun Strike|com.fungames.gunstrike
Bottle Shooting Game|com.fungames.bottleshooting
Zombie Catchers|com.ironhidegames.android.zombiecatchers
Iron Marines|com.ironhidegames.android.ironmarines
Plants vs Zombies|com.popcap.pvz_row
Madden NFL Mobile|com.ea.gp.maddennfl25
FIFA Mobile|com.ea.gp.fifamobile.old
Battlefield Mobile|com.ea.gp.battlefieldmobile
Candy Crush All Stars|com.king.candycrushallstars
War Thunder Mobile|com.gaijingames.wtm
Warframe|com.digitalextremes.warframe
Rocket League Sideswipe|com.vividgames.realracing
Brawlhalla|com.bluemammoth.brawlhalla
Smash Legends|com.line.smashlegends
Dragon Quest Walk|com.square_enix.dqwalk
Final Fantasy Brave Exvius|com.square_enix.android_googleplay.FFBEWW
Pokemon Cafe ReMix|jp.pokemon.pokemoncafemix
Monster Strike|jp.co.mixi.monsterstrike
Puzzle & Dragons|jp.gungho.pad
Uma Musume|com.cygames.umamusume
Granblue Fantasy|jp.co.cygames.granbluefantasy
Princess Connect Re Dive|com.crunchyroll.princessconnect
Punishing Gray Raven|com.kurogame.gplay.punishing.grayraven.en
Genshin Impact Cloud|com.mihoyo.cloudgames.genshin
Tears of Themis|com.miHoYo.tot.global
Ragnarok M Eternal Love|com.gravity.romeinternational.aos
MU Origin|com.webzen.muorigin.google
Mir4|com.wemadeconnect.mir4global
Albion Online|com.albiononline
Old School RuneScape|com.jagex.oldscape
Toca Life World|com.tocaboca.tocalifeworld.free
Avakin Life|com.lockwoodpublishing.avakinlife
IMVU|com.imvu.android
Episode|com.pixelberry.episode
Choices|com.pixelberry.choices
Chapters|com.crazylabs.chapters
Love and Deepspace|com.papegames.lysora
Infinity Nikki|com.papegames.infinitynikki
Shining Nikki|com.papegames.nikki
Love Nikki|com.elex.nikki
Dress Up Time Princess|com.nikki.timeprincess
Covet Fashion|com.covetfashion.android
Design Home|com.crowdstar.covethome
Homescapes Lite|com.playrix.homescapes.lite
House Flip|com.gamejam.houseflip
Rail Rush|com.miniclip.railrush
Talking Tom Hero Dash|com.outfit7.talkingtomheroesdash
Om Nom Run|com.zeptolab.omnomrun
Fruit Merge|com.fruitmerge.android
Wordle|com.nytimes.crosswords
Microsoft Solitaire|com.microsoft.microsoftsolitairecollection
Klondike Solitaire|com.klondike.solitaire
Mahjong Titan|com.mobilityware.mahjongtitan
Mahjong Solitaire|com.mahjong.solitaire
Okey Plus|com.zynga.okey
Okey Live|com.okey.live
Uno|com.mattel163.uno
Phase 10|com.mattel163.phase10
Skip-Bo|com.mattel163.skipbo
Words With Friends|com.zynga.words3
Preguntados|com.etermax.preguntados.pro
QuizUp|com.quizup.core
Bilgi Yarışması|com.bilgi.yarisma
Kelime Oyunu|com.kelime.oyunu
Kelime Bulmaca|com.kelime.bulmaca
Valorant Mobile|com.riotgames.valorant.mobile
League of Legends Wild Rift|com.riotgames.league.wildrift.gp
Warcraft Rumble|com.blizzard.warcraftrumble
Diablo Immortal Mobile|com.blizzard.diablo.immortal.mobile
Marvel Snap Mobile|com.nvsgames.snap.mobile
WWE SuperCard|com.cmgames.wwe
WWE Mayhem|com.reliancegames.wwemayhem
Shadow Fight 4|com.nekki.shadowfight4
Mortal Online|com.mortal.online
Into the Dead 2|com.pikpok.dr2.free
Last Shelter Survival|com.More.Fun.Games.Last.Shelter
Pixel Gun 3D|com.pixel.gun3d
Block City Wars|com.blockcity.wars
Crafting and Building|com.crafting.and.building
Survivalcraft|com.candywriter.survivalcraft
Poppy Playtime|com.mobilegames.poppyplaytime
Hello Neighbor|com.tinybuildgames.helloneighbor
Hidden Objects|com.hidden.objects
Spot the Difference|com.spot.difference
Find Differences|com.find.differences
Dingdong Stickers|com.dingdong.stickers
Sticker.ly|com.snowcorp.stickerly.android
Lensa|com.prisma.android
VN Video Editor|com.vnapp.vn
Likee Studio|video.like.studio
WeSing|com.tencent.karaoke
Piano Tiles|com.cmplay.tiles2_cn
Guitar Hero Mobile|com.guitarhero.mobile
Radio Garden|com.jonathanpuckey.radiogarden
Radyo Dinle|com.radyo.dinle
Fizy|com.turkcell.gncplay
Spotify Podcasts|com.spotify.podcasts
Overcast|com.overcast.android
Wattpad Webnovel|com.wattpad.webnovel
GoodNovel|com.newreading.goodreels
GoodShort|com.newreading.goodshort
ReelShort|video.reelshort.android
DramaBox|com.storymatrix.drama
FlexTV|com.flextv.livestream
NetShort|com.netshort.abroad
Kuaikan|com.kuaikan.comic
Tencent Comics|com.qq.ac.android
Pocket Comics|com.kakao.page.global
Crunchyroll Manga|com.crunchyroll.manga
Funimation|com.funimation.funimationnow
AnimeLab|com.animelab.android
Trakt|tv.trakt.trakt
JustWatch|com.justwatch.justwatch
IMDb|com.imdb.mobile
Rotten Tomatoes|com.rottentomatoes.android
Fandango|com.fandango
Cinemark|com.cinemark.cinemark
AMC Theatres|com.amc.amcsite
Ticketmaster|com.ticketmaster.mobile.android.na
StubHub|com.stubhub
Bandsintown|com.bandsintown
Apollo|com.apollo.reddit
Narwhal|com.narwhal.reddit
Boost|com.boost.reddit
Joey for Reddit|o.o.joey
RedReader|org.quantumbadger.redreader
Reddit is Fun|com.andrewshu.android.reddit
Lemmy|com.lemmy.app
Voyager|app.vger.voyager
Jerboa|com.jerboa
Fedilab|app.fedilab.fedilab
Megalodon|org.joinmastodon.android.megalodon
Primal|net.primal.android
Amethyst|com.vitorpamplona.amethyst
Farcaster Warpcast|com.farcaster.mobile
Telegram FOSS|org.telegram.messenger.beta
Turbo Telegram|org.telegram.messenger.turbo
Rubika|ir.resaneh1.iptv
Eitaa|ir.eitaa.messenger
Bale|ir.nasim
iGap|net.iGap
Shad|ir.medu.shad
Mattermost|com.mattermost.rn
Rocket Chat|chat.rocket.android
Zulip|com.zulipmobile
Matrix FluffyChat|chat.fluffy.fluffychat
Jami|cx.ring
Linphone|org.linphone
TeamSpeak|com.teamspeak.ts3client
Skype Lite|com.skype.lite
Skype for Business|com.microsoft.office.lync15
BlueJeans|com.bluejeansnet.Base
Jitsi Meet|org.jitsi.meet
Google Duo|com.google.android.apps.tachyon.duo
FaceTime Web|com.facetime.web
Houseparty Lite|com.herzick.houseparty.lite
IMO HD|com.imo.android.imoimhd
Textra|com.textra
Pulse SMS|xyz.klinker.messenger
Chomp SMS|com.delicious_ltd.chomp
Xiaomi Messages|com.xiaomi.mms
Bitmoji|com.bitstrips.imoji
Giphy|com.giphy.messenger
Tenor GIF|com.riffsy.FBMGIFApp
Wombo Dream|com.womboai.wombodream
Wombo|com.womboai.wombo
Patreon|com.patreon.android
Telegram Channels|org.telegram.channels
Weverse Shop|co.benx.weverse.shop
Mnet Plus|com.mnet.plus
Spoon|com.spooncast
Chzzk|com.naver.chzzk
SOOP|kr.co.soop
Everytime|com.everytime.v2
Coupang Play|com.coupang.play
Wavve|kr.co.captv.pooqV2
Gmarket|com.ebay.kr.gmarket
11st|com.elevenst
Yahoo Auctions|jp.co.yahoo.android.yauction
Yahoo Shopping|jp.co.yahoo.android.shopping
U-NEXT|jp.unext.mediaplayer
TVer|jp.hamitv.hamiand1
Hulu Japan|jp.happyon.android
Showroom|jp.dena.showroom
Pococha|jp.dena.pococha
Mirrativ|com.mirrativ.android
Fanbox|jp.pxv.fanbox
Pixiv Sketch|jp.pxv.sketch
Booth|jp.pxv.booth
Ameba|jp.ameba.android
Habbo|com.sulake.habbo.android
Animal Jam|com.wildworks.animaljam
Prodigy|com.prodigygame.prodigy
Kongregate|com.kongregate.mobile
Steam Mobile|com.valvesoftware.android.steam.community.old
Xbox Cloud Gaming|com.microsoft.xcloud
Luna|com.amazon.luna
Shadow PC|com.blade.shadow.android
Twitch Drops|tv.twitch.drops
Medal|tv.medal.android
Streamlabs|com.streamlabs.android
Kick Streaming|com.kick.streaming
Trovo|com.trovo.live
Mixer|com.microsoft.mixer
Periscope|tv.periscope.android
Uplive|com.asiainno.uplive
MICO|com.mico
Yalla|com.yalla.live
Yalla Ludo|com.yalla.ludo
Tango Live|com.sgiggle.tango.live
Poppo Live|com.poppo.live
Kwai Lite|com.kwai.video.lite
Kwai Go|com.kwai.video.go
Snack Video Lite|com.kwai.bulldog.lite
Nimo TV|com.huya.nimo
Huya|com.duowan.kiwi
Douyu|air.tv.douyu.android
Bilibili HD|tv.danmaku.bilibilihd
Bilibili Global|com.bstar.intl
iQIYI China|com.qiyi.video
Migu|com.cmcc.cmvideo
Ele.me|me.ele
WeChat Pay|com.tencent.wechat.pay
Didi|com.sdu.didi.psnger
Fliggy|com.taobao.trip
Shopee Malaysia|com.shopee.my
Shopee Thailand|com.shopee.th
Shopee Vietnam|com.shopee.vn
Shopee Philippines|com.shopee.ph
Shopee Brazil|com.shopee.br
Traveloka|com.traveloka.android
"""
    private const val R1 = """
Tiket.com|com.tiket.gits
ShopeePay|com.shopeepay.id
Zalo Pay|vn.com.vng.zalopay
MoMo|com.mservice.momotransfer
Sendo|vn.sendo
Lazada Lite|com.lazada.android.lite
Carousell|com.thecarousell.Carousell
Kaskus|com.kaskus.android
Instagram Go|com.instagram.go
Facebook Go|com.facebook.go
Likee Go|video.like.go
Tiktok Go|com.zhiliaoapp.musically.go.go
Vidio|com.vidio.android
Viu Indonesia|com.vuclip.viu.id
Shahid|net.mbc.shahid
OSN Streaming|com.osn.go
Anghami Plus|com.anghami.plus
Spotify Free|com.spotify.music.free
Telegram Arabic|org.telegram.messenger.ar
Snapchat Arabic|com.snapchat.android.ar
Noon|com.noon.buyerapp
Namshi|com.namshi.android
HungerStation|com.hungerstation.android.web
Jahez|com.jahez.android
Mrsool|com.mrsool
Jumia|com.jumia.android
OLX Brasil|com.olx.olx
Mercado Livre|com.mercadolibre.br
Americanas|br.com.lojasamericanas
Kwai Brasil|com.kwai.video.br
Globoplay|com.globo.globotv
Star Plus|com.disney.starplus
Paramount Brasil|com.cbs.brasil
Vivo Play|br.com.vivo.play
Pluto TV Latino|tv.pluto.latino
Vix|com.univision.vix
TikTok Mexico|com.zhiliaoapp.musically.mx
Rappi|com.grability.rappi
iFood|br.com.brainweb.ifood
Didi Food|com.xiaojukeji.didifood
Cornershop|com.cornershopapp
Uber Lite|com.ubercab.uberlite
Nubank|com.nu.production
PicPay|com.picpay
Inter|br.com.intermedium
BtcTurk|com.btcturk
Uniswap|com.uniswap.mobile
OpenSea|io.opensea
Axie Infinity|com.axie.infinity
Pi Network|com.blockchainvault
Hamster Kombat|com.hamster.kombat
TON Wallet|org.toncoin.wallet
Tonkeeper|com.ton_keeper
Wallet in Telegram|org.telegram.wallet
Trading 212|com.TradingTwoOneTwo
Payoneer|com.payoneer.android
İş Cep|com.softtech.isbankasi
Halkbank|com.halkbank.mobil
QNB|com.qnbfinansbank.mobil
Bip Meet|com.turkcell.bip.meet
Turkcell|com.turkcell.android
Türk Telekom|tr.com.turktelekom.online
Pttcell|tr.gov.ptt.pttcell
Hayat Eve Sığar|tr.gov.saglik.hayatevesigar
Sahibinden Emlak|com.sahibinden.emlak
Hepsiemlak|com.hepsiemlak
Emlakjet|com.emlakjet
Zingat|com.zingat
Arabam|com.arabam
Otoplus|com.otoplus
Letgo TR|com.letgo.tr
Çiçeksepeti|com.ciceksepeti
Teknosa|com.teknosa
MediaMarkt TR|com.mediamarkt.tr
Vatan Bilgisayar|com.vatanbilgisayar
İtopya|com.itopya
Koçtaş|com.koctas
LC Waikiki|com.lcwaikiki
Defacto|com.defacto
Koton|com.koton
Morhipo|com.morhipo
Migros|com.migros.android
ŞOK|com.sok.app
CarrefourSA|com.carrefoursa
Getir Büyük|com.getirbuyuk
Obilet|com.obilet
Enuygun|com.enuygun
Jolly Tur|com.jollytur
Etstur|com.etstur
Tatilbudur|com.tatilbudur
Turna|com.turna
Pegasus|com.pegasus.mobile
SunExpress|com.sunexpress
Couchsurfing|com.couchsurfing.mobile.android
FlixBus|de.flixbus
Omio|com.goeuro.rosie
Transit|com.stationdm.detroit
Windy|co.windyapp.android
Weather|com.google.android.apps.weather
AccuWeather|com.accuweather.android
The Weather Channel|com.weather.Weather
Yahoo Weather|com.yahoo.mobile.client.android.weather
Flightradar24|com.flightradar24free
FlightAware|com.flightaware.android.liveFlightTracker
MarineTraffic|com.marinetraffic.android
Zillow|com.zillow.android.zillowmap
Redfin|com.redfin.android
Realtor|com.move.realtor
Trulia|com.trulia.android
Rightmove|uk.co.rightmove.android
Idealista|com.idealista.android
Immobilienscout24|de.is24.android
Otto|de.otto.shop
Lidl Plus|com.lidl.eci.lidlplus
Ikea|com.ikea.kompis
Temu Lite|com.einnovation.temu.lite
Vinted Lite|fr.vinted.lite
Bol|com.bol.shop
Allegro Lite|pl.allegro.lite
Sbermarket|ru.instamart
Yandex Market|ru.yandex.market
Delivery Club|ru.deliveryclub
VTB|ru.vtb24.mobilebanking.android
Alfa-Bank|ru.alfabank.mobile.android
Gosuslugi|ru.rostel
VK Music|com.vk.vkmusic
VK Play|com.vk.play
"""
    val ALL: List<String> = listOf(R0, R1).flatMap { it.lines() }
}
