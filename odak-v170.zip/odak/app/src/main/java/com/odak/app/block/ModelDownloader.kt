package com.odak.app.block

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue
import com.odak.app.logic.ModelPure
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Yapay zekâ model dosyasını indirir (kaldığı yerden devam eder). Dosya filesDir/models/ altında saklanır. */
object ModelDownloader {
    const val IDLE = 0; const val RUNNING = 1; const val DONE = 2; const val FAIL = 3
    var state by mutableIntStateOf(IDLE)
    var done by mutableLongStateOf(0L)
    var total by mutableLongStateOf(0L)
    @Volatile private var stop = false

    private fun prefs(c: Context) = c.getSharedPreferences("odak_app", Context.MODE_PRIVATE)
    fun url(c: Context) = prefs(c).getString("model_url", "") ?: ""
    fun setUrl(c: Context, v: String) = prefs(c).edit().putString("model_url", v.trim()).apply()
    fun token(c: Context) = prefs(c).getString("model_token", "") ?: ""
    fun setToken(c: Context, v: String) = prefs(c).edit().putString("model_token", v.trim()).apply()
    fun dir(c: Context) = File(c.filesDir, "models")

    /** İndirilmiş model dosyası (varsa). */
    fun ready(c: Context): File? = try { dir(c).listFiles { f -> f.isFile && !f.name.endsWith(".part") }?.maxByOrNull { it.lastModified() } } catch (e: Exception) { null }

    /** Belirli uzantılı en yeni indirilmiş dosya (ör. ".litertlm", ".onnx"). */
    fun find(c: Context, ext: String): File? = try { dir(c).listFiles { f -> f.isFile && f.name.lowercase().endsWith(ext) }?.maxByOrNull { it.lastModified() } } catch (e: Exception) { null }

    fun delete(c: Context) { ModelRunner.release(); ExtScorer.release(); try { dir(c).listFiles()?.forEach { it.delete() } } catch (e: Exception) { }; state = IDLE; done = 0; total = 0 }

    fun stop() { stop = true }

    fun start(c: Context) {
        val u = url(c)
        if (state == RUNNING || !ModelPure.urlOk(u)) { if (!ModelPure.urlOk(u)) state = FAIL; return }
        val app = c.applicationContext
        stop = false; state = RUNNING
        Thread {
            state = try { if (run(app, u, token(app))) DONE else IDLE } catch (e: Exception) { FAIL } catch (e: OutOfMemoryError) { FAIL }
        }.start()
    }

    private fun run(c: Context, u: String, token: String): Boolean {
        dir(c).mkdirs()
        val name = ModelPure.fileName(u)
        val part = File(dir(c), "$name.part")
        val out = File(dir(c), name)
        val origHost = ModelPure.host(u)
        var cur = u.trim()
        var start = if (part.exists()) part.length() else 0L
        var conn: HttpURLConnection? = null
        for (hop in 0..5) {
            val h = URL(cur).openConnection() as HttpURLConnection
            h.instanceFollowRedirects = false
            h.connectTimeout = 20000; h.readTimeout = 30000
            if (ModelPure.sendAuth(origHost, ModelPure.host(cur), token)) h.setRequestProperty("Authorization", "Bearer $token")
            if (start > 0) h.setRequestProperty("Range", "bytes=$start-")
            val code = h.responseCode
            if (code in 300..399) {
                val loc = h.getHeaderField("Location")?.let { try { URL(URL(cur), it).toString() } catch (e: Exception) { null } }
                h.disconnect()
                if (!ModelPure.redirectOk(loc)) throw java.io.IOException("redirect")
                cur = loc!!; continue
            }
            if (code == 416) { h.disconnect(); part.delete(); start = 0; continue }   // kısmi dosya geçersiz: baştan
            if (code != 200 && code != 206) { h.disconnect(); throw java.io.IOException("http $code") }
            conn = h
            if (code == 200) start = 0   // sunucu devamı desteklemiyor
            break
        }
        val h = conn ?: throw java.io.IOException("hops")
        total = start + h.contentLengthLong.coerceAtLeast(0)
        if (total > 0 && !ModelPure.enoughSpace(c.filesDir.usableSpace, total - start)) { h.disconnect(); throw java.io.IOException("space") }
        done = start
        h.inputStream.use { inp ->
            java.io.FileOutputStream(part, start > 0).use { os ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    if (stop) return false
                    val n = inp.read(buf)
                    if (n < 0) break
                    os.write(buf, 0, n); done += n
                }
            }
        }
        h.disconnect()
        if (total > 0 && part.length() != total) throw java.io.IOException("size")
        out.delete()
        if (!part.renameTo(out)) throw java.io.IOException("rename")
        return true
    }
}
