package com.odak.app.docs

import android.graphics.Bitmap

/** BMP/WebP/TIFF/EMF/WMF/SVG/HEIF/AVIF → PNG (içeriğe bakarak); belge okuyucular bunu [RImg.converter] ile kullanır. */
object ImageConv {
    private fun ext(k: String) = when (k) { "heif" -> "heic"; "tiff" -> "tif"; else -> k }

    fun toPng(d: ByteArray, maxSide: Int = 2048): ByteArray? {
        val k = ImgSniff.kind(d)
        if (!ImgSniff.needsConversion(k) && k != "gif") return null
        val bm = decodeSampled(SingleMedia(d), "img." + ext(k), maxSide) ?: return null
        return try {
            val bo = java.io.ByteArrayOutputStream()
            bm.compress(Bitmap.CompressFormat.PNG, 100, bo)
            bo.toByteArray()
        } finally { bm.recycle() }
    }

    fun install() { RImg.converter = { toPng(it) } }
}
