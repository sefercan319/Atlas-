package com.odak.app.docs

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/**
 * Zengin sayfayı (biçimli paragraflar + tablolar) PDF tuvaline çizer: kalın/italik/renk/boyut, hizalama, girinti, liste imi,
 * paragraf kenarlığı/gölgesi, tablo çizgileri/gölge/birleştirme, sayfa boyutu ve kenar boşlukları.
 * startPage: önceki sayfayı bitirip verilen boyutta (punto) yeni sayfa açar ve tuvalini döndürür.
 */
internal class RichPdfPainter(private val startPage: (Float, Float) -> Canvas) {
    var canvas: Canvas? = null
        private set
    var y = 0f
    private var anchors: java.util.IdentityHashMap<RPara, MutableList<RTable>> = java.util.IdentityHashMap()
    private fun drawAnchored(p: RPara, lineTop: Float) {
        val l = anchors.remove(p) ?: return
        for (t in l) { val a = t.at ?: continue; val ty = (Anchors.top(lineTop, a[1], a[3], ph) * 20f).toInt(); box(t.asBox(a[0], ty, a[2], a[3]) ?: RBox(a[0], ty, a[2], a[3], listOf(RTable(t.rows, t.cols)))) }
    }
    private var lastParaTop = 0f   // son paragrafın üstü: paragrafa göre konumlu kutular buna göre çizilir
        private set
    private var pw = 595f
    private var ph = 842f
    private var mt = 56f
    private var mb = 56f
    private var ml = 56f
    private var mr = 56f
    private var rp = RichPage(emptyList())
    private var fixed = false   // kutu içinde: sayfa taşması yeni sayfa açmaz
    private val paints = HashMap<String, Paint>()

    private class Piece(val text: String, val paint: Paint, val w: Float, val shift: Float, val tab: Boolean = false, val bmp: Bitmap? = null, val ih: Float = 0f)
    private class Line(val pieces: ArrayList<Piece> = ArrayList(), var w: Float = 0f, var asc: Float = 0f, var desc: Float = 0f, var h: Float = 0f)

    fun draw(page: RichPage) {
        rp = page
        val s = page.setup
        pw = s.w / 20f; ph = s.h / 20f; mt = s.top / 20f; mb = s.bottom / 20f; ml = s.left / 20f; mr = s.right / 20f
        newPage()
        val (flow, anchored) = Anchors.split(page.blocks)
        anchors = anchored
        for (b in flow) when (b) {
            is RPara -> para(b)
            is RTable -> { val a = b.at; if (a != null) { val ty = if (a.size > 4 && a[4] == 1) (lastParaTop * 20f).toInt() + a[1] else a[1]; box(b.asBox(a[0], ty, a[2], a[3]) ?: RBox(a[0], ty, a[2], a[3], listOf(RTable(b.rows, b.cols)))) } else table(b) }
            is RBox -> box(b)
        }
    }

    private fun newPage() {
        val c = startPage(pw, ph)
        canvas = c; y = mt
        rp.bg?.let { hx -> try { c.drawColor(Color.parseColor("#" + hx)) } catch (e: IllegalArgumentException) {} }
        val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9f; color = Color.DKGRAY; typeface = Typeface.SANS_SERIF }
        rp.header.firstOrNull()?.let { c.drawText(rp.header.joinToString("  ") { it.plain.trim() }.take(160), ml, maxOf(16f, mt / 2f), hp) }
        rp.footer.firstOrNull()?.let { c.drawText(rp.footer.joinToString("  ") { it.plain.trim() }.take(160), ml, ph - maxOf(10f, mb / 2f), hp) }
    }
    private fun ensure(h: Float) { if (fixed) return; if (canvas == null || (y + h > ph - mb && y > mt + 1f)) newPage() }

    private fun paintFor(r: RRun?): Paint {
        val sz = (if (r != null && r.sz > 0) r.sz else rp.defSz) / 2f
        val key = "${r?.b}|${r?.i}|${r?.u}|${r?.s}|${r?.color}|$sz|${r?.font}|${r?.sup}"
        return paints.getOrPut(key) {
            val fam = FontMap.family(r?.font ?: rp.defFont)
            val style = (if (r?.b == true) Typeface.BOLD else 0) or (if (r?.i == true) Typeface.ITALIC else 0)
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = if (r != null && r.sup != 0) sz * 0.65f else sz
                val emb = RichFonts.typeface(r?.font ?: rp.defFont, r?.b == true, r?.i == true)
                typeface = emb ?: Typeface.create(Typeface.create(fam, Typeface.NORMAL), style)
                if (emb != null) FontMap.asset(r?.font ?: rp.defFont)?.let { f -> val (fb, fi) = FontMap.synth(f, r?.b == true, r?.i == true); isFakeBoldText = fb; if (fi) textSkewX = -0.25f }
                color = Rich.hex(r?.color)?.let { Color.parseColor("#$it") } ?: Color.BLACK
                isUnderlineText = r?.u == true
                isStrikeThruText = r?.s == true
            }
        }
    }

    private fun layout(p: RPara, avail: Float): List<Line> {
        val lines = ArrayList<Line>()
        var cur = Line()
        val first = p.first / 20f
        fun width(): Float = avail - (if (lines.isEmpty()) maxOf(first, 0f) else 0f).coerceAtLeast(0f)
        fun end() {
            if (cur.pieces.isEmpty()) { val pt = paintFor(null); cur.asc = -pt.fontMetrics.ascent; cur.desc = pt.fontMetrics.descent }
            val mult = (if (p.line > 0) p.line else rp.defLine).let { if (it > 0) it / 240f else 1.0f }
            cur.h = (cur.asc + cur.desc) * mult
            lines.add(cur); cur = Line()
        }
        fun add(piece: Piece) {
            val fm = piece.paint.fontMetrics
            cur.pieces.add(piece); cur.w += piece.w
            cur.asc = maxOf(cur.asc, -fm.ascent); cur.desc = maxOf(cur.desc, fm.descent)
        }
        val tok = Regex("\n|\t|[ ]+|[^ \n\t]+")
        for (r in FontFallback.expand(p.runs, rp.defFont)) {
            val im = r.img
            if (im != null) {
                val bmp = try { BitmapFactory.decodeByteArray(im.data, 0, im.data.size) } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }
                if (bmp != null) {
                    val maxW = width()
                    var w = im.w / 20f; var h = im.h / 20f
                    if (w > maxW) { h = h * maxW / w; w = maxW }
                    if (cur.w + w > maxW && cur.pieces.isNotEmpty()) end()
                    val pt0 = paintFor(null)
                    cur.pieces.add(Piece("", pt0, w, 0f, false, bmp, h)); cur.w += w
                    cur.asc = maxOf(cur.asc, h); cur.desc = maxOf(cur.desc, pt0.fontMetrics.descent)
                }
                continue
            }
            val pt = paintFor(r)
            val shift = if (r.sup > 0) -pt.textSize * 0.45f else if (r.sup < 0) pt.textSize * 0.2f else 0f
            for (m in tok.findAll(r.text)) {
                val t = m.value
                when {
                    t == "\n" -> end()
                    t == "\t" -> { val nx = (Math.floor((cur.w / 36f).toDouble()).toFloat() + 1f) * 36f; add(Piece("", pt, nx - cur.w, 0f, true)) }
                    t[0] == ' ' -> if (cur.pieces.isNotEmpty()) add(Piece(t, pt, pt.measureText(t), shift))
                    else -> {
                        var w = pt.measureText(t)
                        if (cur.w + w > width() && cur.pieces.isNotEmpty()) end()
                        if (w > width()) {
                            var piece = StringBuilder()
                            for (ch in t) {
                                if (piece.isNotEmpty() && cur.w + pt.measureText(piece.toString() + ch) > width()) { add(Piece(piece.toString(), pt, pt.measureText(piece.toString()), shift)); end(); piece = StringBuilder() }
                                piece.append(ch)
                            }
                            if (piece.isNotEmpty()) add(Piece(piece.toString(), pt, pt.measureText(piece.toString()), shift))
                        } else add(Piece(t, pt, w, shift))
                    }
                }
            }
        }
        end()
        return lines
    }

    private fun drawLine(c: Canvas, ln: Line, x: Float, avail: Float, top: Float, align0: String, indent: Float, last: Boolean = true, rtl: Boolean = false) {
        val align = if (rtl && align0 == "") "right" else align0
        val base = top + (ln.h - ln.asc - ln.desc) + ln.asc
        var px = x + indent
        val room = avail - indent
        px += when (align) { "center" -> (room - ln.w) / 2f; "right" -> room - ln.w; else -> 0f }
        // İki yana yaslama: son satır hariç, artan boşluk sözcük aralarına paylaştırılır.
        var extra = 0f
        if (align == "justify" && !last) {
            val gaps = ln.pieces.count { !it.tab && it.bmp == null && it.text.isNotEmpty() && it.text[0] == ' ' }
            if (gaps > 0 && room > ln.w) extra = (room - ln.w) / gaps
        }
        val order = RtlText.visualOrder(ln.pieces.map { if (it.bmp != null || it.tab) "" else it.text }, rtl)
        for (oi in order) {
            val pc = ln.pieces[oi]
            val bm = pc.bmp
            if (bm != null) c.drawBitmap(bm, null, RectF(px, base - pc.ih, px + pc.w, base), null)
            else if (!pc.tab && pc.text.isNotEmpty()) c.drawText(pc.text, px, base + pc.shift, pc.paint)
            px += pc.w
            if (extra > 0f && !pc.tab && pc.bmp == null && pc.text.isNotEmpty() && pc.text[0] == ' ') px += extra
        }
    }

    private fun fillPaint(hex: String?): Paint? = Rich.hex(hex)?.let { h -> Paint().apply { color = Color.parseColor("#$h"); style = Paint.Style.FILL } }
    private fun linePaint(b: Bd): Paint = Paint().apply { color = Color.parseColor("#" + b.color); strokeWidth = maxOf(b.w / 8f, 0.5f); style = Paint.Style.STROKE }

    private fun para(p: RPara) {
        if (p.pageBreak && y > mt + 1f && !fixed) newPage()
        val left = ml + maxOf(p.left, 0) / 20f
        val avail = (pw - mr) - left
        y += (if (p.before >= 0) p.before else 0) / 20f
        lastParaTop = y
        val lines = layout(p, avail)
        val fill = fillPaint(p.fill)
        val first = p.first / 20f
        lines.forEachIndexed { i, ln ->
            ensure(ln.h)
            if (i == 0) drawAnchored(p, y)   // kutu paragrafın başladığı sayfada çizilir
            val c = canvas!!
            if (fill != null) c.drawRect(left, y, left + avail, y + ln.h, fill)
            if (i == 0 && p.top != null) c.drawLine(left, y, left + avail, y, linePaint(p.top))
            if (i == 0 && p.marker.isNotEmpty()) {
                val mp = paintFor(p.runs.firstOrNull())
                c.drawText(p.marker, left + minOf(first, 0f), y + ln.asc, mp)
            }
            drawLine(c, ln, left, avail, y, p.align, if (i == 0) maxOf(first, 0f) else 0f, i == lines.size - 1, RtlText.isRtl(p.plain))
            y += ln.h
            if (i == lines.size - 1 && p.bottom != null) c.drawLine(left, y, left + avail, y, linePaint(p.bottom))
        }
        drawAnchored(p, y)   // satırsız paragraf
        y += (if (p.after >= 0) p.after else rp.defAfter) / 20f
    }

    /** Mutlak konumlu kutu: dolgu/kenarlık, içerik kutu sınırlarına kırpılır; akışı (y) etkilemez. */
    /** Kutunun geometrisini çizer: elips, yuvarlak köşe, çokgen (üçgen, ok, yıldız…) ya da dikdörtgen. */
    private fun drawShape(c: Canvas, r: RectF, b: RBox, p: Paint) {
        val poly = ShapeGeom.poly(b.prst)
        val cr = ShapeGeom.corner(b.prst)
        when {
            b.round || ShapeGeom.isEllipse(b.prst) -> c.drawOval(r, p)
            poly != null -> {
                val path = android.graphics.Path()
                var i = 0
                while (i < poly.size) {
                    val px = r.left + poly[i] * r.width(); val py = r.top + poly[i + 1] * r.height()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                    i += 2
                }
                path.close(); c.drawPath(path, p)
            }
            cr > 0f -> { val rad = cr * minOf(r.width(), r.height()); c.drawRoundRect(r, rad, rad, p) }
            else -> c.drawRect(r, p)
        }
    }

    private fun box(b: RBox) {
        val c = canvas ?: return
        val x = b.x / 20f; val top = b.y / 20f; val w = b.w / 20f; val h = b.h / 20f
        if (w <= 1f || h <= 1f) return
        val rect = RectF(x, top, x + w, top + h)
        val rotated = b.rot != 0f || b.flipH || b.flipV
        if (rotated) { c.save(); if (b.rot != 0f) c.rotate(b.rot, x + w / 2f, top + h / 2f); if (b.flipH || b.flipV) c.scale(if (b.flipH) -1f else 1f, if (b.flipV) -1f else 1f, x + w / 2f, top + h / 2f) }
        Rich.hex(b.shadow)?.let { sc ->
            val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#$sc"); alpha = (b.shadowAlpha * 255 / 100).coerceIn(0, 255) }
            val sr = RectF(rect); sr.offset(b.shadowDx / 20f, b.shadowDy / 20f)
            drawShape(c, sr, b, sp)
        }
        if (b.grad.size >= 2 && b.grad.all { Rich.hex(it) != null }) {
            val a = Math.toRadians(b.gradAng.toDouble()); val dx = Math.cos(a).toFloat(); val dy = Math.sin(a).toFloat()
            val cxm = x + w / 2f; val cym = top + h / 2f; val half = (Math.abs(dx) * w + Math.abs(dy) * h) / 2f
            val colors = b.grad.map { Color.parseColor("#${Rich.hex(it)}") }.toIntArray()
            val pos = if (b.gradPos.size == b.grad.size && b.gradPos.zipWithNext().all { (p, q) -> q >= p }) b.gradPos.toFloatArray() else null
            val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = if (b.radial) android.graphics.RadialGradient(cxm, cym, maxOf(w, h) / 2f, colors, pos, android.graphics.Shader.TileMode.CLAMP)
                else android.graphics.LinearGradient(cxm - dx * half, cym - dy * half, cxm + dx * half, cym + dy * half, colors, pos, android.graphics.Shader.TileMode.CLAMP)
            }
            drawShape(c, rect, b, gp)
        } else if (b.pie.isNotEmpty()) {
            var start = -90f
            for ((f, col) in b.pie) {
                val sw = f * 360f
                val pp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#${Rich.hex(col) ?: "888888"}") }
                c.drawArc(rect, start, sw + 0.3f, true, pp); start += sw
            }
        } else fillPaint(b.fill)?.let { drawShape(c, rect, b, it) }
        val cr = b.crop
        val picData = (b.blocks.firstOrNull() as? RPara)?.runs?.firstOrNull()?.img
        if (cr != null && picData != null) {
            val bmp = try { BitmapFactory.decodeByteArray(picData.data, 0, picData.data.size) } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }
            if (bmp != null) {
                val src = android.graphics.Rect((bmp.width * cr[0] / 100000), (bmp.height * cr[1] / 100000), bmp.width - (bmp.width * cr[2] / 100000), bmp.height - (bmp.height * cr[3] / 100000))
                if (src.width() > 0 && src.height() > 0) c.drawBitmap(bmp, src, rect, Paint(Paint.FILTER_BITMAP_FLAG))
            }
            b.border?.let { drawShape(c, rect, b, linePaint(it)) }
            if (rotated) c.restore()
            return
        }
        b.border?.let { drawShape(c, rect, b, linePaint(it)) }
        val sMl = ml; val sMr = mr; val sY = y; val sFixed = fixed
        val ins = b.inset / 20f
        ml = x + ins; mr = pw - (x + w) + ins
        // içerik yüksekliği (yalnız paragraflar ölçülür) → dikey hizalama
        var content = 0f
        for (q in b.blocks) if (q is RPara) {
            val av = (pw - mr) - (ml + maxOf(q.left, 0) / 20f)
            content += (if (q.before >= 0) q.before else 0) / 20f + layout(q, av.coerceAtLeast(10f)).sumOf { it.h.toDouble() }.toFloat() + (if (q.after >= 0) q.after else rp.defAfter) / 20f
        }
        val free = (h - 2 * ins - content).coerceAtLeast(0f)
        y = top + ins + when (b.valign) { "center" -> free / 2f; "bottom" -> free; else -> 0f }
        fixed = true
        c.save()
        c.clipRect(rect)
        for (q in b.blocks) when (q) { is RPara -> para(q); is RTable -> table(q); is RBox -> box(q) }
        c.restore()
        ml = sMl; mr = sMr; y = sY; fixed = sFixed
        if (rotated) c.restore()
    }

    private fun table(t: RTable) {
        val n = Rich.tableCols(t).coerceAtLeast(1)
        val textW = pw - ml - mr
        val raw = if (t.cols.size == n && t.cols.all { it > 0 }) t.cols.map { it / 20f } else List(n) { textW / n }
        val scale = if (raw.sum() > textW) textW / raw.sum() else 1f
        val cw = raw.map { it * scale }
        val starts = Rich.gridStarts(t)
        val pad = 4f
        fun colX(i: Int): Float { var x = ml; for (k in 0 until minOf(i, cw.size)) x += cw[k]; return x }
        fun spanW(s: Int, span: Int): Float { var w = 0f; for (k in s until minOf(s + span, cw.size)) w += cw[k]; return w }
        // satır yükseklikleri
        val cellLines = ArrayList<List<List<Pair<RPara, List<Line>>>>>()
        val heights = FloatArray(t.rows.size) { 14f }
        t.rows.forEachIndexed { r, row ->
            val perCell = ArrayList<List<Pair<RPara, List<Line>>>>()
            row.forEachIndexed { k, cell ->
                val w = spanW(starts[r][k], cell.span) - 2 * pad
                val ls = cell.paras.map { it to layout(it, w.coerceAtLeast(10f)) }
                perCell.add(ls)
                if (cell.vMerge != 2) {
                    val h = ls.sumOf { (p, l) -> l.sumOf { it.h.toDouble() } + ((if (p.after >= 0) p.after else 0) / 20f) }.toFloat() + 2 * pad
                    val rs = Rich.rowSpan(t, starts, r, k).coerceAtLeast(1)
                    heights[r] = maxOf(heights[r], h / rs)
                }
            }
            cellLines.add(perCell)
        }
        t.rows.forEachIndexed { r, row ->
            ensure(heights[r])
            val c = canvas!!
            row.forEachIndexed { k, cell ->
                if (cell.vMerge == 2) return@forEachIndexed
                val x = colX(starts[r][k]); val w = spanW(starts[r][k], cell.span)
                val rs = Rich.rowSpan(t, starts, r, k).coerceAtLeast(1)
                var h = 0f
                for (q in r until minOf(r + rs, t.rows.size)) h += heights[q]
                fillPaint(cell.fill)?.let { c.drawRect(x, y, x + w, y + h, it) }
                cell.bt?.let { c.drawLine(x, y, x + w, y, linePaint(it)) }
                cell.bb?.let { c.drawLine(x, y + h, x + w, y + h, linePaint(it)) }
                cell.bl?.let { c.drawLine(x, y, x, y + h, linePaint(it)) }
                cell.br?.let { c.drawLine(x + w, y, x + w, y + h, linePaint(it)) }
                var ty = y + pad
                for ((p, ls) in cellLines[r][k]) {
                    val px = x + pad + maxOf(p.left, 0) / 20f
                    val av = w - 2 * pad - maxOf(p.left, 0) / 20f
                    ls.forEachIndexed { i, ln ->
                        if (i == 0 && p.marker.isNotEmpty()) c.drawText(p.marker, px + minOf(p.first / 20f, 0f), ty + ln.asc, paintFor(p.runs.firstOrNull()))
                        drawLine(c, ln, px, av, ty, p.align, if (i == 0) maxOf(p.first / 20f, 0f) else 0f, i == ls.size - 1, RtlText.isRtl(p.plain))
                        ty += ln.h
                    }
                    ty += (if (p.after >= 0) p.after else 0) / 20f
                }
            }
            y += heights[r]
        }
        y += 8f
    }
}
