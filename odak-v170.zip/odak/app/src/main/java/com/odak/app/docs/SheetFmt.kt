package com.odak.app.docs

/** XLSX/ODS çıktısı için hücre değerleri + biçimleri (renk, kalın, italik, altı/üstü çizili, dolgu, hizalama). Zengin sayfa varsa biçim korunur. */
object SheetFmt {
    const val MAX_ROWS = 3000
    const val MAX_COLS = 60

    class Fmt(val color: String?, val b: Boolean, val i: Boolean, val u: Boolean, val s: Boolean, val fill: String?, val align: String) {
        val key: String get() = "$color|$b|$i|$u|$s|$fill|$align"
    }
    class Grid(val rows: List<List<String>>, val fmts: List<List<Fmt?>>)

    private fun fmtOf(paras: List<RPara>, cellFill: String?): Fmt? {
        val p = paras.firstOrNull { q -> q.runs.any { it.text.isNotBlank() } } ?: paras.firstOrNull()
        val r = p?.runs?.firstOrNull { it.text.isNotBlank() }
        val col = Rich.hex(r?.color)?.takeIf { it != "000000" }
        val fill = (Rich.hex(cellFill) ?: Rich.hex(p?.fill))?.takeIf { it != "FFFFFF" }
        val al = when (p?.align) { "center" -> "center"; "right" -> "right"; else -> "" }
        val f = Fmt(col, r?.b == true, r?.i == true, r?.u == true, r?.s == true, fill, al)
        return if (col == null && !f.b && !f.i && !f.u && !f.s && fill == null && al.isEmpty()) null else f
    }

    private fun text(paras: List<RPara>) = paras.joinToString(" ") { it.plain.trim() }.trim()

    /** Zengin sayfadan satırlar (belge sırasıyla); boşsa null. */
    private fun fromRich(rp: RichPage): Grid? {
        val rows = ArrayList<List<String>>(); val fm = ArrayList<List<Fmt?>>()
        for (b in rp.blocks) {
            if (rows.size >= MAX_ROWS) break
            when (b) {
                is RPara -> { val t = b.plain.trim(); if (t.isNotEmpty()) { rows.add(listOf(t)); fm.add(listOf(fmtOf(listOf(b), null))) } }
                is RTable -> for (r in b.rows) {
                    if (rows.size >= MAX_ROWS) break
                    val vals = ArrayList<String>(); val fs = ArrayList<Fmt?>()
                    for (c in r) {
                        if (vals.size >= MAX_COLS) break
                        vals.add(if (c.vMerge == 2) "" else text(c.paras)); fs.add(fmtOf(c.paras, c.fill))
                        repeat((c.span - 1).coerceAtLeast(0)) { if (vals.size < MAX_COLS) { vals.add(""); fs.add(fs.last()) } }
                    }
                    rows.add(vals); fm.add(fs)
                }
                else -> { }
            }
        }
        return if (rows.isEmpty()) null else Grid(rows, fm)
    }

    fun grid(p: DocPage): Grid {
        p.rich?.let { r -> fromRich(Rich.flat(r))?.let { return it } }
        val rows = (p.paragraphs.map { listOf(it) } + (p.table ?: emptyList())).take(MAX_ROWS).map { it.take(MAX_COLS) }
        return Grid(rows, rows.map { r -> r.map { null } })
    }
}
