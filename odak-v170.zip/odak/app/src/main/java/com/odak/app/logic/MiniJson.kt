package com.odak.app.logic

/** Küçük, bağımsız JSON okuyucu/yazıcı (org.json'a bağlı değil; birim testlenir). Nesne = LinkedHashMap, dizi = List. */
object MiniJson {
    private const val MAX_DEPTH = 24

    /** Bozuk girdide null döner. */
    fun parse(s: String): Any? = try {
        val p = P(s)
        p.ws()
        val v = p.value(0)
        p.ws()
        if (p.i == s.length) v else null
    } catch (e: Exception) { null }

    private class P(val s: String) {
        var i = 0
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun value(d: Int): Any? {
            if (d > MAX_DEPTH) throw IllegalStateException("deep")
            ws()
            return when (val c = s[i]) {
                '{' -> obj(d)
                '[' -> arr(d)
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) num() else throw IllegalStateException("bad")
            }
        }
        fun lit(w: String, v: Any?): Any? { if (!s.startsWith(w, i)) throw IllegalStateException("bad"); i += w.length; return v }
        fun num(): Double { val st = i; while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++; return s.substring(st, i).toDouble() }
        fun str(): String {
            i++
            val sb = StringBuilder()
            while (true) {
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> when (val e = s[i++]) {
                        'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r')
                        'b' -> sb.append('\b'); 'f' -> sb.append('\u000C')
                        'u' -> { sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                        '"', '\\', '/' -> sb.append(e)
                        else -> throw IllegalStateException("esc")
                    }
                    else -> sb.append(c)
                }
            }
        }
        fun arr(d: Int): List<Any?> {
            i++
            val out = ArrayList<Any?>()
            ws()
            if (s[i] == ']') { i++; return out }
            while (true) {
                out.add(value(d + 1)); ws()
                when (s[i++]) { ',' -> continue; ']' -> return out; else -> throw IllegalStateException("arr") }
            }
        }
        fun obj(d: Int): Map<String, Any?> {
            i++
            val out = LinkedHashMap<String, Any?>()
            ws()
            if (s[i] == '}') { i++; return out }
            while (true) {
                ws()
                if (s[i] != '"') throw IllegalStateException("key")
                val k = str(); ws()
                if (s[i++] != ':') throw IllegalStateException("colon")
                out[k] = value(d + 1); ws()
                when (s[i++]) { ',' -> continue; '}' -> return out; else -> throw IllegalStateException("obj") }
            }
        }
    }

    fun quote(s: String): String {
        val sb = StringBuilder("\"")
        for (c in s) when {
            c == '"' -> sb.append("\\\""); c == '\\' -> sb.append("\\\\")
            c == '\n' -> sb.append("\\n"); c == '\r' -> sb.append("\\r"); c == '\t' -> sb.append("\\t")
            c < ' ' -> sb.append("\\u%04x".format(c.code))
            else -> sb.append(c)
        }
        return sb.append('"').toString()
    }

    /** "anahtar": ["a","b"] sözlüğü (kural dosyası biçimi). */
    fun writeRules(m: Map<String, List<String>>): String =
        m.entries.joinToString(",\n", "{\n", "\n}") { (k, v) -> "  " + quote(k) + ": [" + v.joinToString(", ") { quote(it) } + "]" }
}
