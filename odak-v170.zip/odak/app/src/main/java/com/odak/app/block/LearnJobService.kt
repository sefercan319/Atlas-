package com.odak.app.block

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context

/** Şarjdayken ve pil düşük değilken, yeni örnek varsa öğreniciyi arka planda yavaş yavaş eğitir (ekran açık kalması gerekmez). */
class LearnJobService : JobService() {
    override fun onStartJob(p: JobParameters): Boolean {
        Thread {
            try { if (LearnStore.bg(this) && LearnStore.needsTrain(this)) LearnStore.train(this, 60) } catch (e: Exception) { }
            jobFinished(p, false)
        }.start()
        return true
    }

    override fun onStopJob(p: JobParameters) = true

    companion object {
        private const val ID = 4711
        fun schedule(c: Context) {
            try {
                val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
                if (js.getPendingJob(ID) != null) return
                js.schedule(
                    JobInfo.Builder(ID, ComponentName(c, LearnJobService::class.java))
                        .setRequiresCharging(true).setRequiresBatteryNotLow(true)
                        .setPeriodic(6L * 60 * 60 * 1000).setPersisted(true).build()
                )
            } catch (e: Exception) { }
        }
        fun cancel(c: Context) { try { (c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler).cancel(ID) } catch (e: Exception) { } }
        fun sync(c: Context) { if (LearnStore.bg(c)) schedule(c) else cancel(c) }
    }
}
