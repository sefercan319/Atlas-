package com.odak.app.docs

/** Resim biçimini dosya adına değil içeriğe bakarak tanır (saf mantık; çevirme Android tarafında). */
object ImgSniff {
    fun kind(d: ByteArray): String {
        fun s(o: Int, t: String) = d.size >= o + t.length && t.indices.all { d[o + it] == t[it].code.toByte() }
        fun u32le(o: Int) = if (d.size >= o + 4) (d[o].toInt() and 255) or ((d[o + 1].toInt() and 255) shl 8) or ((d[o + 2].toInt() and 255) shl 16) or ((d[o + 3].toInt() and 255) shl 24) else 0
        if (d.size < 4) return "none"
        if (d.size >= 8 && d[0] == 0x89.toByte() && s(1, "PNG")) return "png"
        if (d[0] == 0xFF.toByte() && d[1] == 0xD8.toByte()) return "jpeg"
        if (s(0, "GIF8")) return "gif"
        if (s(0, "BM") && d.size > 14) return "bmp"
        if (s(0, "RIFF") && s(8, "WEBP")) return "webp"
        if (s(0, "II*") && d[3].toInt() == 0 || s(0, "MM") && d[2].toInt() == 0 && d[3].toInt() == 42) return "tiff"
        if (d.size > 44 && u32le(0) == 1 && s(40, " EMF")) return "emf"
        if (d.size > 22 && u32le(0) == 0x9AC6CDD7.toInt()) return "wmf"
        if (d.size > 18 && (d[0].toInt() == 1 || d[0].toInt() == 2) && d[1].toInt() == 0 && d[2].toInt() == 9 && d[3].toInt() == 0) return "wmf"
        if (d.size > 12 && s(4, "ftyp")) {
            val brand = String(d, 8, 4, Charsets.ISO_8859_1)
            if (brand.startsWith("avi")) return "avif"
            if (brand.startsWith("he") || brand.startsWith("mif") || brand.startsWith("msf")) return "heif"
        }
        // SVG: BOM/boşluk sonrası "<" ve ilk 2 KB içinde <svg ya da gzip (svgz)
        if (d[0] == 0x1F.toByte() && d[1] == 0x8B.toByte()) return "svgz"
        val head = String(d, 0, minOf(d.size, 2048), Charsets.UTF_8)
        val t = head.trimStart('﻿', ' ', '\n', '\r', '\t')
        if (t.startsWith("<") && Regex("<svg[\\s>]", RegexOption.IGNORE_CASE).containsMatchIn(t)) return "svg"
        return "none"
    }

    /** PNG/JPEG/GIF dışında, dönüştürülebilecek biçim mi. */
    fun needsConversion(k: String) = k in setOf("bmp", "webp", "tiff", "emf", "wmf", "svg", "svgz", "heif", "avif")
}
