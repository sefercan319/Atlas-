package com.odak.app.theme

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.odak.app.theme.Text

/** İkincil eylem: çerçevesiz, sönük metin. Ana eylem ThemedButton ile öne çıkar, bu ise arka planda kalır. */
@Composable
fun QuietAction(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, selected: Boolean = text.startsWith("✔")) {
    val t = LocalDesign.current.tokens
    // Sönük metin de okunur kalmalı: zeminde en az 4.5:1 kontrast sağlayan en küçük opaklık.
    val bg = t.background.toArgb()
    val dim = Contrast.alphaFor(t.text.toArgb(), bg, 0.7).toFloat()
    val on = Color(Contrast.readable(t.primary.toArgb(), bg))
    Box(
        modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (selected) on else t.text.copy(alpha = dim),
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

/** Ekranlar arası ortak ölçüler (dp): liste aralığı ve yan boşluk her sekmede aynı. */
object Space {
    const val SCREEN_SIDE = 16
    const val LIST_GAP = 12
    const val CARD_PAD = 16
}
