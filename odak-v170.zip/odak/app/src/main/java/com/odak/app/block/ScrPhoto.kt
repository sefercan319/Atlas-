package com.odak.app.block

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** Uyarı ekranı fotoğrafı: seçilen resim küçültülüp uygulama klasörüne kopyalanır (galeriden bağımsız kalır). */
object ScrPhoto {
    fun file(c: Context, kind: String) = File(c.filesDir, "scr_$kind.png")
    fun has(c: Context, kind: String) = file(c, kind).exists()
    fun bitmap(c: Context, kind: String): Bitmap? = try { if (has(c, kind)) BitmapFactory.decodeFile(file(c, kind).path) else null } catch (e: Exception) { null }
    fun clear(c: Context, kind: String) { try { file(c, kind).delete() } catch (e: Exception) { } }

    /** Her görsel türü: PNG/JPEG/GIF doğrudan, WebP/BMP/TIFF/HEIF/AVIF/SVG/EMF/WMF dönüştürücüyle PNG'ye. 70 MB üstü reddedilir. */
    fun save(c: Context, kind: String, uri: Uri): Boolean = try {
        val raw = c.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        if (raw == null || raw.isEmpty() || raw.size > com.odak.app.logic.ModelPure.PHOTO_MAX) false else {
            val data = com.odak.app.docs.RImg.make("", raw)?.first ?: raw
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, o)
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / s > 1440) s *= 2
            val bm = BitmapFactory.decodeByteArray(data, 0, data.size, BitmapFactory.Options().apply { inSampleSize = s })
            if (bm == null) false else {
                val k = 720f / maxOf(bm.width, bm.height)
                val out = if (k < 1f) Bitmap.createScaledBitmap(bm, (bm.width * k).toInt().coerceAtLeast(1), (bm.height * k).toInt().coerceAtLeast(1), true) else bm
                file(c, kind).outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                true
            }
        }
    } catch (e: Exception) { false } catch (e: OutOfMemoryError) { false }
}
