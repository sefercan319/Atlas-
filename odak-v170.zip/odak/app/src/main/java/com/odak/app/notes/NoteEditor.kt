package com.odak.app.notes

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke as DStroke
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.odak.app.R
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedTextField
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val NOTE_COLORS = listOf(0, 0xFFFFF59D.toInt(), 0xFFA5D6A7.toInt(), 0xFF90CAF9.toInt(), 0xFFF48FB1.toInt(), 0xFFCE93D8.toInt())
/** 0 = tema metin rengi. */
private val INK_COLORS = listOf(0, 0xFFE53935.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFFB8C00.toInt(), 0xFF8E24AA.toInt())
private val WIDTHS = listOf(2f, 4f, 8f)
private const val TOOL_ERASER = 3
private const val TOOL_HAND = 4
private const val TOOL_IMAGE = 5

private fun DrawScope.drawPaper(type: Int, color: Color, h: Float) {
    val step = size.width * 0.06f
    val w = size.width
    when (type) {
        1 -> { var y = step * 1.5f; while (y < h) { drawLine(color, Offset(0f, y), Offset(w, y), 1.5f); y += step } }
        2 -> {
            var y = step; while (y < h) { drawLine(color, Offset(0f, y), Offset(w, y), 1f); y += step }
            var x = step; while (x < w) { drawLine(color, Offset(x, 0f), Offset(x, h), 1f); x += step }
        }
        3 -> { var y = step; while (y < h) { var x = step; while (x < w) { drawCircle(color, 2f, Offset(x, y)); x += step }; y += step } }
    }
}

/** yOff: bu tuvalin sayfa üstü (genişlik biriminde); PDF sayfalarında sayfanın üstü, düz notta 0. Kalem basıncı varsa parça parça kalınlık değişir. */
private fun DrawScope.drawStroke(s: Stroke, inkDefault: Color, yOff: Float) {
    if (s.pts.isEmpty()) return
    val col = (if (s.color == 0) inkDefault else Color(s.color)).copy(alpha = NotePure.strokeAlpha(s.tool))
    val wpx = NotePure.effWidth(s.tool, s.width) * size.width / 1000f
    val w = size.width
    if (s.pts.size == 1) {
        drawCircle(col, NotePure.pressW(wpx, s.pts[0].p) / 2f, Offset(s.pts[0].x * w, (s.pts[0].y - yOff) * w)); return
    }
    val pressured = s.tool != NotePure.TOOL_HIGHLIGHT && s.pts.any { it.p < 0.999f }
    if (pressured) {
        for (i in 1 until s.pts.size) {
            val a = s.pts[i - 1]; val b = s.pts[i]
            drawLine(col, Offset(a.x * w, (a.y - yOff) * w), Offset(b.x * w, (b.y - yOff) * w), NotePure.pressW(wpx, (a.p + b.p) / 2f), StrokeCap.Round)
        }
    } else {
        val p = Path()
        p.moveTo(s.pts[0].x * w, (s.pts[0].y - yOff) * w)
        for (i in 1 until s.pts.size) p.lineTo(s.pts[i].x * w, (s.pts[i].y - yOff) * w)
        drawPath(p, col, style = DStroke(width = wpx, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/**
 * Not düzenleyici: metin + yapılacaklar + el yazısı (kalem basıncı destekli), resim, ses kaydı,
 * PDF üstüne yazma, kâğıt türü, renk, klasör, PIN kilidi, resim/PDF olarak paylaşma.
 */
@Composable
fun NoteEditor(initial: Note, onSave: (Note) -> Unit, onTrash: (Note) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tk = LocalDesign.current.tokens
    val isPdf = initial.pdf.isNotEmpty()
    var title by remember { mutableStateOf(initial.title) }
    var body by remember { mutableStateOf(initial.body) }
    var strokes by remember { mutableStateOf(initial.strokes) }
    var images by remember { mutableStateOf(initial.images) }
    var audios by remember { mutableStateOf(initial.audios) }
    var paper by remember { mutableStateOf(initial.paper) }
    var color by remember { mutableStateOf(initial.color) }
    var pinned by remember { mutableStateOf(initial.pinned) }
    var folder by remember { mutableStateOf(initial.folder) }
    var locked by remember { mutableStateOf(initial.locked) }
    var mode by remember { mutableStateOf(if (isPdf || (initial.strokes.isNotEmpty() && initial.body.isBlank())) 1 else 0) }
    var tool by remember { mutableStateOf(NotePure.TOOL_PEN) } // 0 kalem 1 fosforlu 2 kurşun 3 silgi 4 kaydır 5 resim taşı
    var ink by remember { mutableStateOf(0) }
    var wIdx by remember { mutableStateOf(1) }
    var more by remember { mutableStateOf(false) }
    var live by remember { mutableStateOf<List<Pt>>(emptyList()) }
    var erased by remember { mutableStateOf(false) }
    var selImg by remember { mutableStateOf(-1) }
    val hist = remember { NotePure.History<List<Stroke>>() }
    val bmps = remember { mutableStateMapOf<String, ImageBitmap>() }
    val needPin = stringResource(R.string.notes_need_pin)
    val msgDenied = stringResource(R.string.notes_rec_denied)
    val msgImgErr = stringResource(R.string.notes_image_err)
    val msgShareErr = stringResource(R.string.notes_share_err)
    val msgPdfErr = stringResource(R.string.notes_pdf_err)

    // ---- ses
    val recorder = remember { NoteRecorder(ctx) }
    val player = remember { NotePlayer(ctx) }
    var recording by remember { mutableStateOf(false) }
    var recMs by remember { mutableStateOf(0L) }
    var playing by remember { mutableStateOf<String?>(null) }

    // ---- PDF
    var aspects by remember { mutableStateOf<List<Float>>(emptyList()) }
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var pfd by remember { mutableStateOf<ParcelFileDescriptor?>(null) }
    var pdfFailed by remember { mutableStateOf(false) }
    val tops = remember(aspects) { NotePure.pdfTops(aspects) }

    fun current() = initial.copy(
        title = title, body = body, strokes = strokes, images = images, audios = audios, paper = paper, color = color, pinned = pinned,
        folder = NotePure.cleanFolder(folder), locked = locked, updated = System.currentTimeMillis()
    )
    val empty = title.isBlank() && body.isBlank() && strokes.isEmpty() && images.isEmpty() && audios.isEmpty() && !isPdf
    // Yeni ve hâlâ boş not kaydedilmez; var olan not boşaltıldıysa boş hâliyle kaydedilir.
    val skipSave = empty && initial.title.isBlank() && initial.body.isBlank() && initial.strokes.isEmpty() && initial.images.isEmpty() && initial.audios.isEmpty()
    // Otomatik kaydet
    LaunchedEffect(title, body, strokes, images, audios, paper, color, pinned, folder, locked) {
        delay(500)
        if (!skipSave) onSave(current())
    }

    DisposableEffect(initial.pdf) {
        if (isPdf) {
            try {
                val f = NoteMedia.file(ctx, "pdf", initial.pdf)!!
                val d = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                val r = PdfRenderer(d)
                pfd = d; renderer = r
                aspects = List(r.pageCount) { i -> r.openPage(i).use { it.height.toFloat() / it.width } }
            } catch (e: Exception) { pdfFailed = true; Toast.makeText(ctx, msgPdfErr, Toast.LENGTH_SHORT).show() }
        }
        onDispose {
            try { renderer?.close() } catch (e: Exception) { }
            try { pfd?.close() } catch (e: Exception) { }
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            player.stop()
            if (recorder.active()) { recorder.stop()?.let { onSave(current().copy(audios = audios + it)) } }
        }
    }
    LaunchedEffect(images.map { it.file }) {
        for (i in images) if (i.file !in bmps) {
            val b = withContext(Dispatchers.IO) { NoteMedia.loadImage(ctx, i.file)?.asImageBitmap() }
            if (b != null) bmps[i.file] = b
        }
    }
    LaunchedEffect(recording) {
        while (recording) {
            recMs = recorder.elapsedMs()
            if (recMs > 3_600_000L) { recorder.stop()?.let { audios = audios + it }; recording = false }
            delay(500)
        }
    }

    fun startRec() {
        player.stop(); playing = null
        if (recorder.start(initial.id)) { recording = true; recMs = 0L } else Toast.makeText(ctx, msgDenied, Toast.LENGTH_SHORT).show()
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRec() else Toast.makeText(ctx, msgDenied, Toast.LENGTH_SHORT).show()
    }
    val imgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val y = if (strokes.isEmpty() && images.isEmpty()) 0.1f else maxOf(NotePure.maxY(strokes), images.maxOfOrNull { NotePure.imgBottom(it) } ?: 0f) + 0.05f
            val img = withContext(Dispatchers.IO) { NoteMedia.importImage(ctx, uri, initial.id, y) }
            if (img == null) Toast.makeText(ctx, msgImgErr, Toast.LENGTH_SHORT).show()
            else { images = images + img; selImg = images.size - 1; mode = 1; tool = TOOL_IMAGE }
        }
    }

    fun eraseAt(p: Pt) {
        val after = NotePure.eraseAt(strokes, p.x, p.y, 0.02f)
        if (after.size != strokes.size) { if (!erased) hist.push(strokes); erased = true; strokes = after }
    }

    /** Parmak/kalem hareketi. yOff: bu tuvalin sayfa üstü, wPx: tuval genişliği (px). Kalemle (stylus) gelen basınç kaydedilir. */
    fun inkInput(yOff: Float, wPx: Float): Modifier = Modifier.pointerInput(tool, ink, wIdx, wPx, yOff) {
        if (tool == TOOL_HAND) return@pointerInput
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            val stylus = down.type == PointerType.Stylus
            fun pt(c: PointerInputChange) = Pt(c.position.x / wPx, c.position.y / wPx + yOff, if (stylus) c.pressure.coerceIn(0f, 1f) else 1f)
            val p0 = pt(down)
            erased = false
            when (tool) {
                TOOL_ERASER -> eraseAt(p0)
                TOOL_IMAGE -> selImg = NotePure.imgAt(images, p0.x, p0.y)
                else -> live = listOf(p0)
            }
            down.consume()
            var last = p0
            drag(down.id) { ch ->
                val p = pt(ch)
                when (tool) {
                    TOOL_ERASER -> eraseAt(p)
                    TOOL_IMAGE -> if (selImg in images.indices) {
                        val k = selImg
                        images = images.toMutableList().also { it[k] = NotePure.moveImg(it[k], p.x - last.x, p.y - last.y) }
                    }
                    else -> live = live + p
                }
                last = p
                ch.consume()
            }
            if (tool != TOOL_ERASER && tool != TOOL_IMAGE && live.isNotEmpty()) {
                hist.push(strokes)
                strokes = strokes + Stroke(tool, ink, WIDTHS[wIdx], NotePure.simplify(live, 0.002f))
            }
            live = emptyList()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            com.odak.app.theme.QuietAction("←", { if (!skipSave) onSave(current()); onBack() })
            if (!isPdf) com.odak.app.theme.QuietAction((if (mode == 0) "✔ " else "") + "⌨ " + stringResource(R.string.notes_mode_text), { mode = 0 })
            com.odak.app.theme.QuietAction((if (mode == 1) "✔ " else "") + "✍ " + stringResource(R.string.notes_mode_draw), { mode = 1 })
            com.odak.app.theme.QuietAction(if (pinned) "📌" else "📍", { pinned = !pinned })
            com.odak.app.theme.QuietAction("⋯", { more = !more })
        }
        Spacer(Modifier.height(6.dp))
        ThemedTextField(title, { title = it.take(120) }, stringResource(R.string.notes_title_hint), Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))

        if (more) {
            ThemedCard(Modifier.fillMaxWidth()) {
                if (!isPdf) {
                    Text(stringResource(R.string.notes_paper), style = MaterialTheme.typography.labelMedium)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val names = listOf(R.string.notes_paper_plain, R.string.notes_paper_lined, R.string.notes_paper_grid, R.string.notes_paper_dots)
                        names.forEachIndexed { i, r -> com.odak.app.theme.QuietAction((if (paper == i) "✔ " else "") + stringResource(r), { paper = i }) }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(stringResource(R.string.notes_color), style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (c in NOTE_COLORS) Box(
                            Modifier.size(30.dp).clip(CircleShape).background(if (c == 0) tk.text.copy(alpha = 0.15f) else Color(c))
                                .border(if (color == c) 3.dp else 1.dp, tk.primary, CircleShape).clickable { color = c }
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                }
                ThemedTextField(folder, { folder = it.replace('\n', ' ').take(30) }, "📁 " + stringResource(R.string.notes_folder), Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!isPdf) com.odak.app.theme.QuietAction("☑ " + stringResource(R.string.notes_checklist), { body = NotePure.addCheckLine(body); mode = 0 })
                    if (!isPdf) com.odak.app.theme.QuietAction("🖼 " + stringResource(R.string.notes_add_image), { imgLauncher.launch("image/*") })
                    com.odak.app.theme.QuietAction((if (locked) "🔓 " else "🔒 ") + stringResource(if (locked) R.string.notes_unlock else R.string.notes_lock), {
                        if (!locked && !com.odak.app.block.Pin.isSet(ctx)) Toast.makeText(ctx, needPin, Toast.LENGTH_SHORT).show()
                        else locked = !locked
                    })
                    com.odak.app.theme.QuietAction("↗ " + stringResource(R.string.notes_share), {
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, NotePure.exportText(current()))
                        com.odak.app.Launch.go(ctx, Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    })
                    if (isPdf) com.odak.app.theme.QuietAction("📄 " + stringResource(R.string.notes_share_pdf), {
                        scope.launch { val ok = withContext(Dispatchers.IO) { NoteMedia.sharePdf(ctx, current()) }; if (!ok) Toast.makeText(ctx, msgShareErr, Toast.LENGTH_SHORT).show() }
                    }) else com.odak.app.theme.QuietAction("🖼 " + stringResource(R.string.notes_share_image), {
                        scope.launch { val ok = withContext(Dispatchers.IO) { NoteMedia.sharePng(ctx, current()) }; if (!ok) Toast.makeText(ctx, msgShareErr, Toast.LENGTH_SHORT).show() }
                    })
                    com.odak.app.theme.QuietAction("🧹 " + stringResource(R.string.notes_clear_draw), { hist.push(strokes); strokes = emptyList() })
                    com.odak.app.theme.QuietAction("🗑 " + stringResource(R.string.notes_delete), { onTrash(current()) })
                }
                // ---- Ses kayıtları
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.notes_audio_title), style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!recording) ThemedButton("🎙 " + stringResource(R.string.notes_rec_start), {
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRec()
                        else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) else ThemedButton("⏹ " + stringResource(R.string.notes_rec_stop) + "  " + NotePure.fmtDur(recMs), {
                        recorder.stop()?.let { audios = audios + it }; recording = false
                    })
                }
                audios.forEachIndexed { idx, a ->
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val isPlaying = playing == a.file
                        ThemedButton((if (isPlaying) "⏹ " else "▶ ") + NotePure.fmtDur(a.durMs), {
                            if (isPlaying) { player.stop(); playing = null }
                            else if (player.play(a.file) { playing = null }) playing = a.file
                        })
                        ThemedButton("🗑", {
                            if (playing == a.file) { player.stop(); playing = null }
                            NoteMedia.file(ctx, "audio", a.file)?.delete()
                            audios = audios.filterIndexed { i, _ -> i != idx }
                        })
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }

        if (!isPdf && body.isNotBlank()) Text(
            NotePure.wordCount(body).toString() + " · " + NotePure.readMinutes(body) + " " + stringResource(R.string.notes_read_min),
            style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.6f)
        )
        val tint = if (color != 0 && !isPdf) Color(color).copy(alpha = 0.22f) else Color.Transparent
        if (mode == 0 && !isPdf) {
            val scroll = rememberScrollState()
            Column(Modifier.fillMaxSize().verticalScroll(scroll).background(tint)) {
                // Yapılacaklar satırları: dokununca işaretlenir
                val lines = body.split('\n')
                lines.forEachIndexed { i, l ->
                    if (l.startsWith("[ ] ") || l.startsWith("[x] ")) {
                        val done = l.startsWith("[x] ")
                        Row(Modifier.fillMaxWidth().clickable { body = NotePure.toggleCheck(body, i) }.padding(vertical = 4.dp)) {
                            Text(if (done) "☑ " else "☐ ", color = tk.primary)
                            Text(l.substring(4), color = tk.text, modifier = Modifier.alpha(if (done) 0.5f else 1f))
                        }
                    }
                }
                BasicTextField(
                    value = body, onValueChange = { body = NotePure.enterInList(body, it).take(100_000) },
                    textStyle = TextStyle(color = tk.text, fontSize = 16.sp),
                    cursorBrush = SolidColor(tk.primary),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 320.dp).padding(8.dp),
                    decorationBox = { inner ->
                        if (body.isEmpty()) Text(stringResource(R.string.notes_body_hint), color = tk.text.copy(alpha = 0.4f))
                        inner()
                    }
                )
            }
        } else {
            // Çizim araç çubuğu
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val tools = listOf("🖊" to NotePure.TOOL_PEN, "🖍" to NotePure.TOOL_HIGHLIGHT, "✏" to NotePure.TOOL_PENCIL, "⌫" to TOOL_ERASER, "✋" to TOOL_HAND, "✥" to TOOL_IMAGE)
                for ((ic, t) in tools) if (t != TOOL_IMAGE || !isPdf) com.odak.app.theme.QuietAction((if (tool == t) "✔" else "") + ic, { tool = t })
                com.odak.app.theme.QuietAction("↶", { hist.undo(strokes)?.let { strokes = it } })
                com.odak.app.theme.QuietAction("↷", { hist.redo(strokes)?.let { strokes = it } })
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (c in INK_COLORS) Box(
                    Modifier.size(28.dp).clip(CircleShape).background(if (c == 0) tk.text else Color(c))
                        .border(if (ink == c) 3.dp else 1.dp, tk.primary, CircleShape).clickable { ink = c }
                )
                WIDTHS.forEachIndexed { i, _ -> com.odak.app.theme.QuietAction((if (wIdx == i) "✔" else "") + "●".repeat(i + 1), { wIdx = i }) }
            }
            if (tool == TOOL_IMAGE && selImg in images.indices) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    com.odak.app.theme.QuietAction("＋ " + stringResource(R.string.notes_image_big), { val k = selImg; images = images.toMutableList().also { it[k] = NotePure.scaleImg(it[k], 1.15f) } })
                    com.odak.app.theme.QuietAction("－ " + stringResource(R.string.notes_image_small), { val k = selImg; images = images.toMutableList().also { it[k] = NotePure.scaleImg(it[k], 1f / 1.15f) } })
                    com.odak.app.theme.QuietAction("🗑 " + stringResource(R.string.notes_image_del), {
                        val k = selImg
                        NoteMedia.file(ctx, "img", images[k].file)?.delete()
                        images = images.filterIndexed { i, _ -> i != k }; selImg = -1
                    })
                }
            }
            Spacer(Modifier.height(4.dp))

            if (isPdf) {
                val r = renderer
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val wPx = with(LocalDensity.current) { maxWidth.toPx() }
                    if (r == null || pdfFailed) Text(stringResource(R.string.notes_pdf_err), modifier = Modifier.padding(16.dp))
                    else LazyColumn(Modifier.fillMaxSize(), userScrollEnabled = tool == TOOL_HAND, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        itemsIndexed(aspects) { i, asp ->
                            val top = tops[i]
                            var bmp by remember(i, wPx) { mutableStateOf<ImageBitmap?>(null) }
                            LaunchedEffect(i, wPx) {
                                bmp = withContext(Dispatchers.IO) { NoteMedia.renderPdfPage(r, i, minOf(wPx.toInt(), 1400))?.asImageBitmap() }
                            }
                            Box(Modifier.fillMaxWidth().height(maxWidth * asp).background(Color.White)) {
                                bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds) }
                                Canvas(Modifier.fillMaxSize().then(inkInput(top, wPx))) {
                                    for (s in NotePure.strokesOfPage(tops, strokes, i)) drawStroke(s, Color.Black, top)
                                    if (live.isNotEmpty() && NotePure.pdfPageAt(tops, live[0].y) == i) drawStroke(Stroke(tool, ink, WIDTHS[wIdx], live), Color.Black, top)
                                }
                            }
                        }
                    }
                }
            } else {
                val scroll = rememberScrollState()
                BoxWithConstraints(Modifier.fillMaxSize().verticalScroll(scroll, enabled = tool == TOOL_HAND).background(tint)) {
                    val wPx = with(LocalDensity.current) { maxWidth.toPx() }
                    val ph = NotePure.pageHeight(strokes, images)
                    val hDp = maxWidth * ph
                    val lineCol = tk.text.copy(alpha = 0.15f)
                    Canvas(Modifier.fillMaxWidth().height(hDp).then(inkInput(0f, wPx))) {
                        drawPaper(paper, lineCol, size.height)
                        for ((k, im) in images.withIndex()) {
                            val b = bmps[im.file] ?: continue
                            val off = IntOffset((im.x * size.width).toInt(), (im.y * size.width).toInt())
                            val sz = IntSize((im.w * size.width).toInt().coerceAtLeast(1), (im.w * im.a * size.width).toInt().coerceAtLeast(1))
                            drawImage(b, dstOffset = off, dstSize = sz)
                            if (k == selImg && tool == TOOL_IMAGE) drawRect(tk.primary, Offset(off.x.toFloat(), off.y.toFloat()), Size(sz.width.toFloat(), sz.height.toFloat()), style = DStroke(width = 4f))
                        }
                        for (s in strokes) drawStroke(s, tk.text, 0f)
                        if (live.isNotEmpty()) drawStroke(Stroke(tool, ink, WIDTHS[wIdx], live), tk.text, 0f)
                    }
                }
            }
        }
    }
}
