package com.odak.app.docs

/** DrawingML hazır şekil adlarından (prst) saf geometri: PDF ve HTML aynı noktaları kullanır. */
object ShapeGeom {
    private val P: Map<String, FloatArray> = mapOf(
        "triangle" to f(.5f, 0f, 1f, 1f, 0f, 1f),
        "rtTriangle" to f(0f, 0f, 0f, 1f, 1f, 1f),
        "diamond" to f(.5f, 0f, 1f, .5f, .5f, 1f, 0f, .5f),
        "parallelogram" to f(.25f, 0f, 1f, 0f, .75f, 1f, 0f, 1f),
        "trapezoid" to f(.2f, 0f, .8f, 0f, 1f, 1f, 0f, 1f),
        "pentagon" to f(.5f, 0f, 1f, .38f, .81f, 1f, .19f, 1f, 0f, .38f),
        "hexagon" to f(.25f, 0f, .75f, 0f, 1f, .5f, .75f, 1f, .25f, 1f, 0f, .5f),
        "octagon" to f(.29f, 0f, .71f, 0f, 1f, .29f, 1f, .71f, .71f, 1f, .29f, 1f, 0f, .71f, 0f, .29f),
        "rightArrow" to f(0f, .3f, .6f, .3f, .6f, 0f, 1f, .5f, .6f, 1f, .6f, .7f, 0f, .7f),
        "leftArrow" to f(1f, .3f, .4f, .3f, .4f, 0f, 0f, .5f, .4f, 1f, .4f, .7f, 1f, .7f),
        "upArrow" to f(.3f, 1f, .3f, .4f, 0f, .4f, .5f, 0f, 1f, .4f, .7f, .4f, .7f, 1f),
        "downArrow" to f(.3f, 0f, .3f, .6f, 0f, .6f, .5f, 1f, 1f, .6f, .7f, .6f, .7f, 0f),
        "chevron" to f(0f, 0f, .7f, 0f, 1f, .5f, .7f, 1f, 0f, 1f, .3f, .5f),
        "homePlate" to f(0f, 0f, .75f, 0f, 1f, .5f, .75f, 1f, 0f, 1f),
        "plus" to f(.33f, 0f, .67f, 0f, .67f, .33f, 1f, .33f, 1f, .67f, .67f, .67f, .67f, 1f, .33f, 1f, .33f, .67f, 0f, .67f, 0f, .33f, .33f, .33f),
        "star5" to f(.5f, 0f, .62f, .36f, 1f, .38f, .69f, .6f, .81f, 1f, .5f, .77f, .19f, 1f, .31f, .6f, 0f, .38f, .38f, .36f)
    )
    private fun f(vararg v: Float) = v

    private val ALIAS = mapOf(
        "flowChartDecision" to "diamond", "flowChartMerge" to "triangle", "flowChartExtract" to "triangle",
        "mathPlus" to "plus", "cross" to "plus", "flowChartPreparation" to "hexagon",
        "bentArrow" to "rightArrow", "notchedRightArrow" to "rightArrow", "stripedRightArrow" to "rightArrow",
        "star4" to "star5", "star6" to "star5", "star8" to "star5"
    )

    private fun key(prst: String) = ALIAS[prst] ?: prst

    /** Birim kare içinde köşe noktaları (x0,y0,x1,y1,…) ya da null (dikdörtgen/elips/yuvarlak köşe). */
    fun poly(prst: String): FloatArray? = P[key(prst)]

    fun isEllipse(prst: String) = prst == "ellipse" || prst == "flowChartConnector"

    /** Yuvarlak köşe yarıçapı (kısa kenarın oranı), yoksa 0. */
    fun corner(prst: String): Float = when (prst) {
        "roundRect", "flowChartAlternateProcess" -> 0.1667f
        "flowChartTerminator" -> 0.5f
        else -> 0f
    }

    /** CSS clip-path: polygon(...) ya da null. */
    fun clipPath(prst: String): String? = poly(prst)?.let { p ->
        val sb = StringBuilder("polygon(")
        var i = 0
        while (i < p.size) {
            if (i > 0) sb.append(',')
            sb.append(String.format(java.util.Locale.US, "%.1f%% %.1f%%", p[i] * 100f, p[i + 1] * 100f))
            i += 2
        }
        sb.append(')').toString()
    }
}
