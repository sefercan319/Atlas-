package com.odak.app.block

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import com.odak.app.R

class OdakAccessibilityService : AccessibilityService() {
    private var lastScan = 0L
    private var lastApp = 0L
    private var rulesStamp = 0L
    private var pendingHits: Set<String> = emptySet()
    private var pendingAt = 0L
    private var lastToast = 0L
    private val usageCache = HashMap<String, Pair<Long, Long>>() // app -> (zaman, ms)
    private val lastFeat = HashMap<String, Long>()
    private var homeTries = 0
    private val lastSeenApp = HashMap<String, Long>()
    private var rules: Map<String, List<String>> = emptyMap()

    override fun onServiceConnected() {
        // Kullanıcının eklediği ve eşitlenen uygulamalar yalnız ekran açılınca yükleniyordu; servis kendi başına yeniden başlayınca engel çalışmıyordu.
        try { BlockCatalog.loadCustom(this); BlockCatalog.loadSynced(this) } catch (x: Exception) { com.odak.app.CrashReport.write(applicationContext, "a11y-load", x) }
        rules = BlockStore.rules(this)
        BlockStore.pruneOld(this)
    }

    private fun blockApp(now: Long, app: BlockApp, pkg: String, focus: Boolean = false, limit: Boolean = false, opens: Boolean = false) {
        if (now - lastApp < 1500) return
        lastApp = now
        BlockStore.incBlocked(this)
        performGlobalAction(GLOBAL_ACTION_HOME)
        com.odak.app.Launch.go(this,
            Intent(this, BlockActivity::class.java)
                .putExtra("app", app.id).putExtra("pkg", pkg).putExtra("focus", focus).putExtra("limit", limit).putExtra("opens", opens)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    /** Bir olay işlenirken çıkan hata servisi öldürmesin (öldürürse engelleme sessizce kapanır): rapora yazılır, sonraki olayla devam edilir. */
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        try { handle(e) } catch (x: Exception) { com.odak.app.CrashReport.write(applicationContext, "a11y", x) }
    }

    private fun handle(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        val app = BlockCatalog.byPackage(pkg) ?: return
        val now = SystemClock.uptimeMillis()

        if (BlockStore.focusActive(this)) {
            blockApp(now, app, pkg, true)
            return
        }

        val passed = BlockStore.passActive(this, app.id)

        if (!passed && BlockStore.isAppBlocked(this, app.id)) {
            blockApp(now, app, pkg)
            return
        }

        if (!passed && BlockStore.appQuiet(this, app.id) && BlockStore.quietNow(this)) {
            blockApp(now, app, pkg)
            return
        }

        // Günlük açma sınırı: 30 sn'den uzun aradan sonraki giriş yeni açılış sayılır
        val openLim = BlockStore.openLimit(this, app.id)
        if (openLim > 0) {
            val isNew = com.odak.app.logic.Pure.isFreshOpen(lastSeenApp[app.id] ?: 0L, now)
            lastSeenApp[app.id] = now
            if (!passed) {
                val n = if (isNew) BlockStore.registerOpen(this, app.id, openLim) else BlockStore.opensToday(this, app.id)
                if (com.odak.app.logic.Pure.openLimitHit(n, openLim)) {
                    blockApp(now, app, pkg, limit = true, opens = true)
                    return
                }
            }
        }

        // Uygulama günlük süre sınırı
        val limit = BlockStore.appLimit(this, app.id)
        if ((!passed || BlockStore.strictLimit(this)) && limit > 0 && BlockStore.usageAccess(this)) {
            val c: Pair<Long, Long> = usageCache[app.id]?.takeIf { now - it.first <= 5000 }
                ?: (now to BlockStore.appUsedMs(this, app)).also { usageCache[app.id] = it }
            val limMs = limit * 60_000L
            if (BlockStore.warnOn(this) && com.odak.app.logic.Pure.inWarnWindow(c.second, limit, BlockStore.warnPct(this)) &&
                BlockStore.warnOnce(this, app.id)
            ) {
                val rest = ((limMs - c.second) / 60_000L).toInt() + 1
                val custom = BlockStore.noteMsg(this)
                com.odak.app.notify.Reminders.note(
                    this, app.id.hashCode(), getString(R.string.warn_title),
                    com.odak.app.notify.Msgs.text(
                        this, "warn",
                        app.name + " · " + (custom.ifBlank { getString(R.string.fmt_min, rest) }),
                        mapOf("app" to app.name, "min" to rest.toString())
                    )
                )
            }
            if (com.odak.app.logic.Pure.limitReached(c.second, limit)) {
                if (BlockStore.limitNoteOn(this) && BlockStore.limitNoteOnce(this, app.id)) {
                    val custom = BlockStore.noteMsg(this)
                    com.odak.app.notify.Reminders.note(
                        this, app.id.hashCode() + 1, getString(R.string.limit_reached_title),
                        com.odak.app.notify.Msgs.text(
                            this, "limit", app.name + (if (custom.isBlank()) "" else " · $custom"),
                            mapOf("app" to app.name)
                        )
                    )
                }
                blockApp(now, app, pkg, limit = true)
                return
            }
        }

        if (now - lastScan < 350) return
        lastScan = now
        val active = app.features.filter {
            BlockStore.isFeatureBlocked(this, app.id, it.id) || BlockStore.featLimit(this, app.id, it.id) > 0
        }
        val learn = BlockStore.learnOn(this)
        if (active.isEmpty() && !learn && !RuleLab.wants(app.id)) return
        val root = rootInActiveWindow ?: return
        val snap = collectSnap(root)
        val seen = snap.ids
        if (RuleLab.wants(app.id)) RuleLab.feed(seen, snap.sel, snap.descs, snap.texts)
        if (learn) BlockStore.recordIds(this, pkg, seen)
        val stamp = BlockStore.rulesStamp(this)
        if (stamp != rulesStamp) {
            rulesStamp = stamp
            rules = BlockStore.rules(this)
        }
        val hitNow = HashSet<String>()
        // Eski eşleşme (3 sn'den eski) geçersiz: kullanıcı ayrılıp dönmüş olabilir
        val prevPending = if (now - pendingAt <= 3000) pendingHits else emptySet()
        pendingAt = now
        for (f in active) {
            if (!com.odak.app.logic.Pure.matches(snap, rules, app.id, f.id)) continue
            val key = "${app.id}/${f.id}"
            hitNow.add(key)
            // Yanlış pozitifi azaltmak için art arda iki taramada eşleşme şart
            if (key !in prevPending) { pendingHits = hitNow; continue }
            var stop = BlockStore.isFeatureBlocked(this, app.id, f.id)
            val fl = BlockStore.featLimit(this, app.id, f.id)
            if (!stop && fl > 0) {
                val add = com.odak.app.logic.Pure.featDelta(lastFeat[key], now)
                lastFeat[key] = now
                if (add > 0) BlockStore.addFeatUsed(this, app.id, f.id, add)
                stop = BlockStore.featUsedMs(this, app.id, f.id) >= fl * 60_000L
            }
            if (stop) {
                val exit = com.odak.app.logic.Pure.featExit(BlockStore.featHome(this), homeTries)
                homeTries++
                if (exit != com.odak.app.logic.Pure.EXIT_HOME_TAB || !clickHomeTab(root)) performGlobalAction(GLOBAL_ACTION_BACK)
                if (now - lastToast > 2500) {
                    lastToast = now
                    BlockStore.incBlocked(this)
                    val fname = f.res?.let { getString(it) } ?: f.text.orEmpty()
                    if (!FeatOverlay.show(this, fname, app.name, !BlockStore.isFeatureBlocked(this, app.id, f.id)))
                        Toast.makeText(this, com.odak.app.notify.Msgs.text(this, "toast", getString(R.string.block_msg)), Toast.LENGTH_SHORT).show()
                }
                pendingHits = hitNow
                return
            }
        }
        if (hitNow.isEmpty()) homeTries = 0
        pendingHits = hitNow
    }

    /** Uygulamanın "ana sayfa" sekmesini bulup tıklar; bulunamazsa false (çağıran geri tuşuna düşer). */
    private fun clickHomeTab(root: AccessibilityNodeInfo): Boolean {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var count = 0
        while (stack.isNotEmpty() && count < 900) {
            val n = stack.removeLast()
            count++
            val label = n.contentDescription?.toString() ?: n.text?.toString() ?: ""
            if (com.odak.app.logic.Pure.isHomeLabel(label)) {
                var t: AccessibilityNodeInfo? = n
                var hops = 0
                while (t != null && !t.isClickable && hops < 4) { t = t.parent; hops++ }
                if (t != null && t.isClickable && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return false
    }

    /** Seçili (açık) sekmenin etiketleri: düğümün kendisi ve en çok 3 seviye altındaki açıklama/metinler. */
    private fun collectSelected(n: AccessibilityNodeInfo, out: MutableSet<String>) {
        val q = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        q.add(n to 0)
        var count = 0
        while (q.isNotEmpty() && count < 16) {
            val (x, d) = q.removeFirst()
            count++
            x.contentDescription?.toString()?.take(60)?.lowercase()?.let { if (it.isNotBlank()) out.add(it) }
            x.text?.toString()?.take(60)?.lowercase()?.let { if (it.isNotBlank()) out.add(it) }
            if (d < 3) for (i in 0 until x.childCount) x.getChild(i)?.let { q.add(it to d + 1) }
        }
    }

    /** Ekrandaki görünüm kimliklerini (id/...) topla; sınırlı düğüm sayısı. */
    private fun collectSnap(root: AccessibilityNodeInfo): com.odak.app.logic.Pure.Snap {
        val out = HashSet<String>()
        val descs = HashSet<String>()
        val texts = HashSet<String>()
        val sel = HashSet<String>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var count = 0
        while (stack.isNotEmpty() && count < 900) {
            val n = stack.removeLast()
            count++
            n.viewIdResourceName?.let { out.add(it.substringAfter(":id/")) }
            n.contentDescription?.toString()?.take(80)?.lowercase()?.let { if (it.isNotBlank()) descs.add(it) }
            n.text?.toString()?.take(80)?.lowercase()?.let { if (it.isNotBlank()) texts.add(it) }
            if (n.isSelected) collectSelected(n, sel)
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return com.odak.app.logic.Pure.Snap(out, descs, texts, sel)
    }

    override fun onInterrupt() {}
}
