package com.odak.app.block

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.odak.app.R
import com.odak.app.logic.ScrPure
import com.odak.app.theme.ColorPrefs
import com.odak.app.theme.Design
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.Text
import com.odak.app.theme.ThemePrefs
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.plainClick
import com.odak.app.theme.tokensFor
import com.odak.app.theme.typographyFor

/** Özellik engeli uyarısı: saydam ekran, ortada seçili tasarım stilinin kartı ve düğmesi. Arkadaki uygulama kapanmaz. */
class FeatWarnActivity : ComponentActivity() {
    companion object { @Volatile var open = false }

    private var feature by mutableStateOf("")
    private var app by mutableStateOf("")
    private var limit by mutableStateOf(false)

    private fun read(i: Intent?) {
        feature = i?.getStringExtra("feature").orEmpty()
        app = i?.getStringExtra("app").orEmpty()
        limit = i?.getBooleanExtra("limit", false) ?: false
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); read(intent) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ColorPrefs.init(applicationContext)
        com.odak.app.theme.UiScale.init(applicationContext)
        read(intent)
        open = true
        val style = ThemePrefs.load(this)
        val t = tokensFor(style)
        setContent {
            com.odak.app.theme.ProvideUiScale {
                CompositionLocalProvider(
                    LocalDesign provides Design(style),
                    com.odak.app.theme.LocalInverted provides com.odak.app.theme.ThemeMode.shouldInvert(style, com.odak.app.theme.ThemeMode.load(this@FeatWarnActivity))
                ) {
                    MaterialTheme(typography = typographyFor(style)) {
                        val me = this@FeatWarnActivity
                        val bgc = BlockStore.scr(me, "ftr", "bg").toLongOrNull()?.let { Color(it) }
                        val fg = if (bgc == null) t.text else if (bgc.luminance() > 0.5f) Color(0xFF111111) else Color.White
                        val k = ScrPure.scale(BlockStore.scr(me, "ftr", "size"))
                        val photo = remember { ScrPhoto.bitmap(me, "ftr")?.asImageBitmap() }
                        val title = ScrPure.fill(
                            BlockStore.scr(me, "ftr", "title").ifBlank { stringResource(if (limit) R.string.ftr_limit else R.string.ftr_blocked, feature) },
                            feature, app
                        )
                        val msg = ScrPure.fill(BlockStore.scr(me, "ftr", "msg"), feature, app)
                        LaunchedEffect(Unit) { kotlinx.coroutines.delay(15_000); finish() }
                        Box(
                            Modifier.fillMaxSize().background(Color(0x99000000)).plainClick { },
                            contentAlignment = Alignment.Center
                        ) {
                            val body: @Composable () -> Unit = {
                                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                    if (photo != null) {
                                        Image(photo, null, Modifier.heightIn(max = 170.dp).padding(bottom = 12.dp))
                                    }
                                    Text(BlockStore.scr(me, "ftr", "icon").ifBlank { "⛔" }, color = fg, fontSize = (42 * k).sp)
                                    Text(
                                        title, color = fg, fontSize = (22 * k).sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(top = 12.dp)
                                    )
                                    if (msg.isNotBlank()) Text(
                                        msg, color = fg.copy(alpha = 0.85f), fontSize = (16 * k).sp, textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(top = 8.dp)
                                    )
                                    Spacer(Modifier.height(20.dp))
                                    ThemedButton(stringResource(R.string.pin_ok), { finish() })
                                }
                            }
                            val w = Modifier.padding(24.dp).fillMaxWidth().widthIn(max = 380.dp)
                            if (bgc != null) Box(w.background(bgc, RoundedCornerShape(24.dp)).padding(24.dp)) { body() }
                            else ThemedCard(w) { body() }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() { open = false; super.onDestroy() }
}
