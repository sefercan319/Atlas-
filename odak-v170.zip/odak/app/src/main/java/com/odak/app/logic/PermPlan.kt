package com.odak.app.logic

/** İzin ekranları: hangi ayar sayfası açılır, hangi izin hangi özellik için gerekir (saf mantık). */
enum class PermKind { ACC, USAGE, NOTIF, BATT }

enum class PermStep { PAGE, APP_INFO }

object PermPlan {
    /** true: uygulamaya özel "ayrıntı" sayfası var (kullanıcı listede aramaz). */
    fun hasDetailPage(kind: PermKind, sdk: Int) = when (kind) {
        PermKind.ACC -> sdk >= 34
        PermKind.NOTIF -> sdk >= 30
        PermKind.USAGE -> true // paket verisiyle doğrudan uygulama satırı
        PermKind.BATT -> true  // doğrudan onay penceresi
    }

    /** Kısıtlı ayar (yan yüklenen uygulama) engeli yalnızca Erişilebilirlik ve Bildirim erişiminde olur. */
    fun mayBeRestricted(kind: PermKind, sdk: Int) = sdk >= 33 && (kind == PermKind.ACC || kind == PermKind.NOTIF)

    /** İlk açılacak yer: kısıtlıysa önce Uygulama bilgisi (⋮ → Kısıtlı ayarlara izin ver), değilse doğrudan izin sayfası. */
    fun firstStep(kind: PermKind, sdk: Int, restricted: Boolean) =
        if (restricted && mayBeRestricted(kind, sdk)) PermStep.APP_INFO else PermStep.PAGE

    /** Adım metinlerinin kaynak anahtarları. */
    fun stepKey(kind: PermKind, detail: Boolean) = when (kind) {
        PermKind.ACC -> if (detail) "pg_acc_steps_d" else "pg_acc_steps"
        PermKind.USAGE -> "pg_usage_steps"
        PermKind.NOTIF -> if (detail) "pg_notif_steps_d" else "pg_notif_steps"
        PermKind.BATT -> "pg_batt_steps"
    }
}

/** Bir özelliğin ihtiyaç duyduğu izinler: (izin, zorunlu mu). */
object PermNeeds {
    val BLOCK = listOf(PermKind.ACC to true, PermKind.USAGE to false, PermKind.BATT to false)
    val NOTIF_HIDE = listOf(PermKind.NOTIF to true)
    val SCREEN_TIME = listOf(PermKind.USAGE to true)

    fun missing(needs: List<Pair<PermKind, Boolean>>, granted: Set<PermKind>) = needs.filter { it.first !in granted }
    fun requiredMissing(needs: List<Pair<PermKind, Boolean>>, granted: Set<PermKind>) = missing(needs, granted).filter { it.second }
}
