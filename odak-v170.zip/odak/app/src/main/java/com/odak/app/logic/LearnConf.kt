package com.odak.app.logic

import java.util.Random
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Çok katmanlı güven yapısı (saf mantık). Tek bir olasılık yerine dört işaret birleşir:
 *  1) kalibre olasılık, 2) motorlar arası uyum (yerleşik ↔ Smile), 3) bootstrap kararlılığı (torbalama: aynı verinin
 *  yeniden örneklenmiş K kopyasıyla eğitilen modellerin sapması), 4) kanıt desteği (benzer kaç eğitim örneği var).
 * Sonuç 🟢/🟡/🔴 seviyedir; otomatik seçim yalnız 🟢'de yapılır.
 */
object LearnConf {
    const val K = 8
    const val HIGH = 2; const val MID = 1; const val LOW = 0

    class Conf(val p: Double, val std: Double, val spread: Double, val support: Int, val score: Double, val level: Int)

    /** Torbalama: örnekler iadeli yeniden örneklenir, her kopya ayrı eğitilir. Tohumlu → tekrarlanabilir. */
    fun bootstrap(ex: List<LearnPure.Ex>, k: Int = K, epochs: Int = 20): List<DoubleArray> {
        if (ex.size < LearnPure.MIN_EXAMPLES) return emptyList()
        return (0 until k).map { i ->
            val r = Random(900L + i)
            val sample = List(ex.size) { ex[r.nextInt(ex.size)] }
            LearnPure.train(sample, epochs, null, i)
        }
    }

    /** Torba ortalaması ve standart sapması (belirsizlik). */
    fun bag(boots: List<DoubleArray>, x: DoubleArray): Pair<Double, Double> {
        if (boots.isEmpty()) return 0.5 to 0.0
        val ps = boots.map { LearnPure.predict(it, x) }
        val m = ps.average()
        return m to sqrt(ps.sumOf { (it - m) * (it - m) } / ps.size)
    }

    /** Aday için eğitim kümesinde "benzer" örnek sayısı (aynı girdi ya da en az 2 ortak kelime/harf üçlüsü). */
    class Support(ex: List<LearnPure.Ex>) {
        private val entries = ex.map { it.entry }
        private val lex: List<Set<Int>> = ex.map { lexical(LearnPure.features(it.entry, it.ratio, it.inNeg, it.name, it.conflict)) }
        fun count(entry: String, x: DoubleArray): Int {
            val l = lexical(x)
            var n = 0
            for (i in lex.indices) if (entries[i] == entry || lex[i].count { it in l } >= 2) n++
            return n
        }
        private fun lexical(x: DoubleArray): Set<Int> { val s = HashSet<Int>(); for (j in LearnPure.BASE until LearnPure.DIM) if (x[j] > 0) s.add(j); return s }
    }

    fun supportFactor(n: Int): Double = when { n <= 0 -> 0.6; n < 3 -> 0.8; n < 8 -> 0.95; else -> 1.0 }

    fun levelOf(score: Double): Int = if (score >= 0.7) HIGH else if (score >= 0.45) MID else LOW

    /**
     * [p] kalibre/karışık olasılık, [boots] torbalar, [other] diğer motorun olasılığı (yoksa null), [support] benzer örnek sayısı.
     * Uyumsuzluk ve kararsızlık puanı düşürür; az kanıt da düşürür.
     */
    fun assess(p: Double, boots: List<DoubleArray>, x: DoubleArray, other: Double?, support: Int): Conf {
        val std = bag(boots, x).second
        val spread = if (other == null) 0.0 else abs(p - other)
        val agree = 1.0 - minOf(1.0, spread * 2)
        val stable = 1.0 - minOf(0.5, std * 2)
        val score = (p * agree * stable * supportFactor(support)).coerceIn(0.0, 1.0)
        return Conf(p, std, spread, support, score, levelOf(score))
    }

    /** %90 belirsizlik yarıçapı (yüzde puan): 1.64·std. */
    fun plusMinus(c: Conf): Int = (1.64 * c.std * 100 + 0.5).toInt()

    fun symbol(level: Int) = when (level) { HIGH -> "🟢"; MID -> "🟡"; else -> "🔴" }

    fun encodeBoots(b: List<DoubleArray>) = b.joinToString("\n") { LearnPure.encodeW(it) }
    fun decodeBoots(s: String?): List<DoubleArray> = s?.lines()?.mapNotNull { LearnPure.decodeW(it) } ?: emptyList()
}
