package com.odak.app.block

import android.content.Context
import com.odak.app.logic.LearnPure
import smile.classification.LogisticRegression
import java.io.File
import java.io.ObjectInputStream
import java.io.ObjectOutputStream

/** Açık kaynak Smile (haifengl/smile) kütüphanesiyle ikinci sınıflandırıcı: aynı özelliklerle lojistik regresyon. */
object SmileTrainer {
    private fun f(c: Context) = File(c.filesDir, "learn_smile.bin")
    @Volatile private var cached: LogisticRegression? = null

    @Synchronized fun fit(c: Context, ex: List<LearnPure.Ex>): Boolean = try {
        if (ex.count { it.label } == 0 || ex.all { it.label }) false else {
            val x = Array(ex.size) { LearnPure.features(ex[it].entry, ex[it].ratio, ex[it].inNeg, ex[it].name, ex[it].conflict) }
            val y = IntArray(ex.size) { if (ex[it].label) 1 else 0 }
            val m = LogisticRegression.fit(x, y)
            ObjectOutputStream(f(c).outputStream()).use { it.writeObject(m) }
            cached = m; true
        }
    } catch (t: Throwable) { false }

    @Synchronized private fun model(c: Context): LogisticRegression? {
        cached?.let { return it }
        return try { if (f(c).exists()) ObjectInputStream(f(c).inputStream()).use { it.readObject() as LogisticRegression }.also { cached = it } else null } catch (t: Throwable) { null }
    }

    /** Olumlu olasılık; model yoksa/hata varsa null. */
    fun prob(c: Context, x: DoubleArray): Double? = try {
        model(c)?.let { m -> val post = DoubleArray(2); m.predict(x, post); post[1] }
    } catch (t: Throwable) { null }

    fun clear(c: Context) { cached = null; try { f(c).delete() } catch (e: Exception) { } }
}
