package com.odak.app.docs

/**
 * Biçim koruyan (zengin) belge modeli. Saf Kotlin, Android'e bağımlı değil.
 * Uzunluklar twips (1/20 punto), yazı boyutu yarım punto (sz=24 → 12 pt). 0 / -1 = "belirtilmemiş".
 */
class RRun(
    val text: String,
    val b: Boolean = false, val i: Boolean = false, val u: Boolean = false, val s: Boolean = false,
    val color: String? = null, val hl: String? = null,
    val sz: Int = 0, val font: String? = null, val sup: Int = 0, val href: String? = null,
    val img: RImg? = null
)

/** Satır içi resim: ham bayt (png/jpeg/gif), boyut twips. */
class RImg(val data: ByteArray, val mime: String, val w: Int, val h: Int) {
    val ext: String get() = when (mime) { "image/jpeg" -> "jpg"; "image/gif" -> "gif"; else -> "png" }
    companion object {
        /** Android tarafının kurduğu çevirici: BMP/WebP/TIFF/EMF/WMF/SVG/HEIF baytlarını PNG'ye çevirir; çözemezse null. */
        @Volatile var converter: ((ByteArray) -> ByteArray?)? = null

        /** Dosyadan çıkan ham resmi gömülebilir (PNG/JPEG/GIF) hale getirir; çevrilemezse null. */
        fun make(name: String, data: ByteArray): Pair<ByteArray, String>? {
            mimeOf(name, data)?.let { return data to it }
            if (!ImgSniff.needsConversion(ImgSniff.kind(data))) return null
            val png = try { converter?.invoke(data) } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null } ?: return null
            return if (png.size > 8 && mimeOf("", png) != null) png to mimeOf("", png)!! else null
        }

        fun mimeOf(name: String, data: ByteArray): String? {
            if (data.size >= 8 && data[0] == 0x89.toByte() && data[1] == 'P'.code.toByte()) return "image/png"
            if (data.size >= 3 && data[0] == 0xFF.toByte() && data[1] == 0xD8.toByte()) return "image/jpeg"
            if (data.size >= 4 && data[0] == 'G'.code.toByte() && data[1] == 'I'.code.toByte() && data[2] == 'F'.code.toByte()) return "image/gif"
            return null
        }
        /** PNG/GIF/JPEG başlığından piksel boyutu (bulunamazsa null). */
        fun pixelSize(d: ByteArray): Pair<Int, Int>? {
            fun u16(i: Int) = ((d[i].toInt() and 255) shl 8) or (d[i + 1].toInt() and 255)
            fun u32(i: Int) = (u16(i) shl 16) or u16(i + 2)
            if (d.size > 24 && d[0] == 0x89.toByte() && d[1] == 'P'.code.toByte()) return u32(16) to u32(20)
            if (d.size > 10 && d[0] == 'G'.code.toByte()) return ((d[6].toInt() and 255) or ((d[7].toInt() and 255) shl 8)) to ((d[8].toInt() and 255) or ((d[9].toInt() and 255) shl 8))
            if (d.size > 4 && d[0] == 0xFF.toByte() && d[1] == 0xD8.toByte()) {
                var i = 2
                while (i + 9 < d.size) {
                    if (d[i] != 0xFF.toByte()) { i++; continue }
                    val m = d[i + 1].toInt() and 255
                    if (m in 0xC0..0xCF && m != 0xC4 && m != 0xC8 && m != 0xCC) return u16(i + 7) to u16(i + 5)
                    i += 2 + u16(i + 2)
                }
            }
            return null
        }
    }
}

/** Tek kenarlık: kalınlık 1/8 punto, renk RRGGBB. */
class Bd(val w: Int, val color: String)

sealed class RBlock

class RPara(
    val runs: List<RRun>,
    val align: String = "",          // "", "center", "right", "justify"
    val head: Int = 0,               // 0 = gövde, 1..6 başlık
    val marker: String = "",         // liste imi ("•", "1.")
    val left: Int = 0, val first: Int = 0,   // sol girinti, ilk satır (negatif = asılı)
    val before: Int = -1, val after: Int = -1, val line: Int = 0,  // 240'ta bir satır
    val top: Bd? = null, val bottom: Bd? = null,
    val fill: String? = null,
    val pageBreak: Boolean = false
) : RBlock() {
    val plain: String get() = runs.joinToString("") { it.text }
}

class RCell(
    val paras: List<RPara>,
    val span: Int = 1, val vMerge: Int = 0,   // vMerge: 0 yok, 1 başlangıç, 2 devam
    val fill: String? = null,
    val bt: Bd? = null, val bl: Bd? = null, val bb: Bd? = null, val br: Bd? = null,
    val width: Int = 0, val valign: String = ""
)

class RTable(val rows: List<List<RCell>>, val cols: List<Int>, val float: String = "", val floatTop: Int = 0) : RBlock() {
    /** Sayfaya göre sabit konum (x, y, genişlik, yükseklik; twips): PDF'te o sayfada o yere çizilir, akışı etkilemez; HTML'de [float] kullanılır. */
    var at: IntArray? = null
    /** DrawingML hazır şekil adı ("ellipse", "roundRect"…); boşsa dikdörtgen. Yalnız DOCX şekillerinde dolu. */
    var prst: String = ""

    /** Şekilli tek hücreli tablo → konumlu kutu (PDF'te geometri doğru çizilsin); şekil değilse null. */
    fun asBox(x: Int, y: Int, w: Int, h: Int): RBox? {
        val c = rows.singleOrNull()?.singleOrNull() ?: return null
        if (prst.isEmpty() && c.bt == null && c.fill == null) return null
        return RBox(x, y, w, h, c.paras, c.fill, c.bt, c.valign, ShapeGeom.isEllipse(prst), 80, prst = prst)
    }
}   // float: "left"/"right" (metin kutusu, yalnız HTML)

/**
 * Sayfada mutlak konumlu kutu (slayt şekli/metin kutusu): x, y, w, h twips (sayfanın sol-üstünden); içinde paragraf/tablo.
 * HTML ve PDF konumunda çizer; DOCX/RTF/ODT/e-kitap yazarken [Rich.flat] ile içeriği akışa açılır.
 */
class RBox(
    val x: Int, val y: Int, val w: Int, val h: Int,
    val blocks: List<RBlock>,
    val fill: String? = null, val border: Bd? = null,
    val valign: String = "",          // "", "center", "bottom"
    val round: Boolean = false,       // elips
    val inset: Int = 0,               // iç boşluk (twips), her kenar
    val rot: Float = 0f,              // döndürme (derece, saat yönü)
    val grad: List<String> = emptyList(), // gradyan durak renkleri (≥2 ise dolgu yerine)
    val gradAng: Float = 0f,          // OOXML açısı (derece; 0 = soldan sağa, 90 = yukarıdan aşağı)
    val shadow: String? = null,       // dış gölge rengi
    val crop: IntArray? = null,       // resim kırpma l,t,r,b (yüzde ×1000; 10000 = %10)
    val flipH: Boolean = false, val flipV: Boolean = false,   // yalnız metinsiz kutularda (şekil/resim)
    val radial: Boolean = false,      // gradyan dairesel (merkezden)
    val shadowDx: Int = 60, val shadowDy: Int = 60, val shadowBlur: Int = 80, val shadowAlpha: Int = 45,  // twips / yüzde
    val pie: List<Pair<Float, String>> = emptyList(),   // pasta dilimleri (kesir, renk); saat 12'den başlar
    val gradPos: List<Float> = emptyList(),   // gradyan durak konumları (0..1); boşsa eşit aralık
    val prst: String = ""             // hazır şekil adı ("roundRect", "triangle"…); boşsa dikdörtgen/elips
) : RBlock()

class PageSetup(val w: Int = 11906, val h: Int = 16838, val top: Int = 1440, val right: Int = 1440, val bottom: Int = 1440, val left: Int = 1440) {
    val landscape: Boolean get() = w > h
}

class RichPage(
    val blocks: List<RBlock>,
    val setup: PageSetup = PageSetup(),
    val defSz: Int = 22, val defFont: String? = null,
    val defAfter: Int = 0, val defLine: Int = 0,
    val header: List<RPara> = emptyList(), val footer: List<RPara> = emptyList(),
    /** Sayfa/slayt arka plan rengi (RRGGBB), yoksa null. */
    val bg: String? = null
)

object Rich {
    private val HEX = Regex("[0-9A-Fa-f]{6}")
    fun hex(c: String?): String? = c?.trim()?.removePrefix("#")?.takeIf { HEX.matches(it) }?.uppercase()

    fun pt(twips: Int): String {
        val v = twips / 20.0
        return if (v == Math.floor(v)) v.toInt().toString() else String.format(java.util.Locale.US, "%.1f", v)
    }

    /** Bir tablodaki hücrenin kapladığı ızgara sütun başlangıçları (satır, hücre → sütun). */
    fun gridStarts(t: RTable): List<IntArray> = t.rows.map { r ->
        var c = 0
        IntArray(r.size) { k -> val s = c; c += r[k].span.coerceAtLeast(1); s }
    }

    /** Hücrenin dikey birleşme yüksekliği (başlangıç hücresi için), diğerleri için 0. */
    fun rowSpan(t: RTable, starts: List<IntArray>, r: Int, k: Int): Int {
        val cell = t.rows[r][k]
        if (cell.vMerge == 2) return 0
        if (cell.vMerge != 1) return 1
        val col = starts[r][k]
        var n = 1
        var rr = r + 1
        while (rr < t.rows.size) {
            val idx = starts[rr].indexOf(col)
            if (idx < 0 || t.rows[rr][idx].vMerge != 2) break
            n++; rr++
        }
        return n
    }

    /** Kutuları (RBox) kendi içeriğiyle değiştirir; kutu yoksa aynı sayfayı döndürür. */
    fun flat(rp: RichPage): RichPage {
        if (rp.blocks.none { it is RBox }) return rp
        fun fl(l: List<RBlock>): List<RBlock> = l.flatMap { b -> if (b is RBox) fl(b.blocks) else listOf(b) }
        val top = if (rp.blocks.all { it is RBox }) rp.blocks.sortedWith(compareBy({ (it as RBox).y / 800 }, { (it as RBox).x })) else rp.blocks
        return RichPage(fl(top), rp.setup, rp.defSz, rp.defFont, rp.defAfter, rp.defLine, rp.header, rp.footer, rp.bg)
    }

    fun tableCols(t: RTable): Int = maxOf(t.cols.size, t.rows.maxOfOrNull { r -> r.sumOf { it.span.coerceAtLeast(1) } } ?: 0)

    /** Düz metin karşılığı: paragraflar; tablo satırları "a │ b". */
    fun plain(rp: RichPage): List<String> {
        val out = ArrayList<String>()
        for (b in rp.blocks) when (b) {
            is RPara -> { val t = b.plain.trim(); if (t.isNotEmpty()) out.add(if (b.marker.isNotEmpty()) b.marker + " " + t else t) }
            is RTable -> for (r in b.rows) {
                val line = r.filter { it.vMerge != 2 }.joinToString(" │ ") { c -> c.paras.joinToString(" ") { it.plain.trim() }.trim() }
                if (r.any { c -> c.paras.any { it.plain.isNotBlank() } }) out.add(line)
            }
            is RBox -> out.addAll(plain(RichPage(b.blocks)))
        }
        return out
    }

    /** Sayfada biçim (kalın, renk, tablo çizgisi vb.) var mı — "Tam görünüm" önerisi için. */
    fun hasFormatting(rp: RichPage): Boolean = rp.blocks.any { b ->
        when (b) {
            is RTable, is RBox -> true
            is RPara -> b.head > 0 || b.align.isNotEmpty() || b.marker.isNotEmpty() || b.runs.any { it.b || it.i || it.u || it.color != null || it.sz > 0 || it.img != null }
        }
    }
}

/** Zengin sayfa → HTML (CSS ile). Tam görünüm ve HTML dönüştürme bunu kullanır. */
object RichHtml {
    const val CSS = "body{margin:0;background:#eceff1;font-family:Calibri,Arial,sans-serif;color:#000}" +
        ".pg{box-sizing:border-box;margin:10px auto;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.25);overflow-wrap:anywhere}" +
        "p,h1,h2,h3,h4,h5,h6{margin:0;font-size:inherit;font-weight:inherit}" +
        "table{border-collapse:collapse;table-layout:fixed}td{vertical-align:top;padding:2pt 5.4pt;overflow-wrap:anywhere}" +
        ".pg.sl{container-type:inline-size;position:relative;width:100%;padding:0!important;overflow:hidden}.t{display:inline-block;width:36pt}.m{display:inline-block;text-indent:0}" +
        "@media(max-width:700px){.pg{padding:12px!important;max-width:none!important;margin:6px 0}}" +
        "@media print{body{background:#fff}.pg{box-shadow:none;margin:0}}"

    private fun e(s: String) = DocConvert.xml(s)

    private fun runCss(r: RRun, rp: RichPage): String {
        val sb = StringBuilder()
        if (r.b) sb.append("font-weight:bold;")
        if (r.i) sb.append("font-style:italic;")
        if (r.u || r.s) sb.append("text-decoration:").append(listOfNotNull(if (r.u) "underline" else null, if (r.s) "line-through" else null).joinToString(" ")).append(';')
        Rich.hex(r.color)?.let { sb.append("color:#").append(it).append(';') }
        Rich.hex(r.hl)?.let { sb.append("background:#").append(it).append(';') }
        if (r.sz > 0 && r.sz != rp.defSz) sb.append("font-size:").append(r.sz / 2.0).append("pt;")
        r.font?.let { f -> if (f != rp.defFont) sb.append("font-family:'").append(f.filter { it.isLetterOrDigit() || it == ' ' || it == '-' }).append("',sans-serif;") }
        if (r.sup > 0) sb.append("vertical-align:super;font-size:smaller;") else if (r.sup < 0) sb.append("vertical-align:sub;font-size:smaller;")
        return sb.toString()
    }

    private fun text(s: String): String = e(s).replace("\n", "<br>").replace("\t", "<span class=t></span>")

    private fun bd(d: Bd?): String = if (d == null || d.w <= 0) "none" else "${maxOf(d.w / 8.0, 0.5)}pt solid #${d.color}"

    /** Resim adresi üreticisi: varsayılan data: adresi; EPUB gibi çıktılar kendi dosya adını verir. */
    fun dataUri(im: RImg): String = "data:" + im.mime + ";base64," + java.util.Base64.getEncoder().encodeToString(im.data)

    fun para(p: RPara, rp: RichPage, imgSrc: (RImg) -> String = ::dataUri): String {
        val st = StringBuilder()
        when (p.align) { "center" -> st.append("text-align:center;"); "right" -> st.append("text-align:right;"); "justify" -> st.append("text-align:justify;") }
        if (p.left != 0) st.append("margin-left:").append(Rich.pt(p.left)).append("pt;")
        if (p.first != 0) st.append("text-indent:").append(Rich.pt(p.first)).append("pt;")
        val before = if (p.before >= 0) p.before else 0
        val after = if (p.after >= 0) p.after else rp.defAfter
        if (before > 0) st.append("margin-top:").append(Rich.pt(before)).append("pt;")
        if (after > 0) st.append("margin-bottom:").append(Rich.pt(after)).append("pt;")
        val line = if (p.line > 0) p.line else rp.defLine
        if (line > 0) st.append("line-height:").append(String.format(java.util.Locale.US, "%.2f", line / 240.0)).append(";")
        if (p.top != null) st.append("border-top:").append(bd(p.top)).append(';')
        if (p.bottom != null) st.append("border-bottom:").append(bd(p.bottom)).append(';')
        Rich.hex(p.fill)?.let { st.append("background:#").append(it).append(';') }
        if (p.pageBreak) st.append("break-before:page;")
        val tag = if (p.head in 1..6) "h${p.head}" else "p"
        val sb = StringBuilder("<").append(tag)
        if (RtlText.isRtl(p.plain)) sb.append(" dir=\"rtl\"")
        if (st.isNotEmpty()) sb.append(" style=\"").append(st).append('"')
        sb.append('>')
        if (p.marker.isNotEmpty()) {
            val hang = if (p.first < 0) " style=\"min-width:${Rich.pt(-p.first)}pt\"" else ""
            sb.append("<span class=m").append(hang).append('>').append(e(p.marker)).append(if (p.first >= 0) "&nbsp;" else "").append("</span>")
        }
        var any = false
        for (r in FontFallback.expand(p.runs, rp.defFont)) {
            r.img?.let { im ->
                any = true
                sb.append("<img src=\"").append(e(imgSrc(im)))
                    .append("\" alt=\"\" style=\"width:").append(Rich.pt(im.w)).append("pt;max-width:100%;height:auto\">")
                return@let
            }
            if (r.text.isEmpty()) continue
            any = true
            val css = runCss(r, rp)
            val inner = text(r.text)
            val safe = r.href?.takeIf { it.startsWith("http://") || it.startsWith("https://") || it.startsWith("mailto:") }
            val body = if (safe != null) "<a href=\"${e(safe)}\">$inner</a>" else inner
            if (css.isEmpty()) sb.append(body) else sb.append("<span style=\"").append(css).append("\">").append(body).append("</span>")
        }
        if (!any && p.marker.isEmpty()) sb.append("&nbsp;")
        return sb.append("</").append(tag).append(">\n").toString()
    }

    fun table(t: RTable, rp: RichPage, imgSrc: (RImg) -> String = ::dataUri): String {
        val starts = Rich.gridStarts(t)
        val n = Rich.tableCols(t)
        val colsPt = t.cols.takeIf { it.size == n && it.all { w -> w > 0 } }
        val total = colsPt?.sum() ?: 0
        val sb = StringBuilder("<table style=\"")
        if (t.float.isNotEmpty() && total > 0) sb.append("width:").append(Rich.pt(total)).append("pt;max-width:50%;float:").append(if (t.float == "right") "right" else "left")
            .append(";margin:").append(Rich.pt(t.floatTop.coerceIn(0, 6000))).append("pt ").append(if (t.float == "right") "0 6px 12px" else "12px 6px 0")
        else { sb.append("width:100%"); if (total > 0) sb.append(";max-width:").append(Rich.pt(total)).append("pt") }
        sb.append("\">")
        if (colsPt != null) {
            sb.append("<colgroup>")
            for (w in colsPt) sb.append("<col style=\"width:").append(String.format(java.util.Locale.US, "%.2f", w * 100.0 / total)).append("%\">")
            sb.append("</colgroup>")
        }
        t.rows.forEachIndexed { r, row ->
            sb.append("<tr>")
            row.forEachIndexed { k, c ->
                if (c.vMerge == 2) return@forEachIndexed
                val rs = Rich.rowSpan(t, starts, r, k)
                sb.append("<td")
                if (c.span > 1) sb.append(" colspan=").append(c.span)
                if (rs > 1) sb.append(" rowspan=").append(rs)
                val st = StringBuilder()
                st.append("border-top:").append(bd(c.bt)).append(";border-left:").append(bd(c.bl))
                    .append(";border-bottom:").append(bd(c.bb)).append(";border-right:").append(bd(c.br)).append(';')
                Rich.hex(c.fill)?.let { st.append("background:#").append(it).append(';') }
                when (c.valign) { "center" -> st.append("vertical-align:middle;"); "bottom" -> st.append("vertical-align:bottom;") }
                sb.append(" style=\"").append(st).append("\">")
                if (c.paras.isEmpty()) sb.append("&nbsp;") else for (p in c.paras) sb.append(para(p, rp, imgSrc))
                sb.append("</td>")
            }
            sb.append("</tr>\n")
        }
        return sb.append("</table>\n").toString()
    }

    /** Tek sayfanın gövdesi (sayfa kutusu ile). */
    fun page(rp: RichPage): String {
        if (rp.blocks.any { it is RBox }) return slide(rp)
        val s = rp.setup
        val sb = StringBuilder("<div class=pg style=\"max-width:")
        sb.append(Rich.pt(s.w)).append("pt;padding:").append(Rich.pt(s.top)).append("pt ").append(Rich.pt(s.right)).append("pt ")
            .append(Rich.pt(s.bottom)).append("pt ").append(Rich.pt(s.left)).append("pt;font-size:").append(rp.defSz / 2.0).append("pt")
        rp.bg?.let { sb.append(";background:#").append(it) }
        rp.defFont?.let { sb.append(";font-family:'").append(it.filter { c -> c.isLetterOrDigit() || c == ' ' || c == '-' }).append("',Arial,sans-serif") }
        sb.append("\">\n")
        if (rp.header.isNotEmpty()) { sb.append("<div class=hf style=\"border-bottom:1px solid #bbb;margin-bottom:8pt;opacity:.75\">"); for (h in rp.header) sb.append(para(h, rp)); sb.append("</div>\n") }
        for (b in rp.blocks) sb.append(when (b) { is RPara -> para(b, rp); is RTable -> table(b, rp); is RBox -> box(b, rp) })
        if (rp.footer.isNotEmpty()) { sb.append("<div class=hf style=\"border-top:1px solid #bbb;margin-top:8pt;opacity:.75\">"); for (h in rp.footer) sb.append(para(h, rp)); sb.append("</div>\n") }
        return sb.append("</div>\n").toString()
    }

    private fun pc(v: Int, total: Double) = String.format(java.util.Locale.US, "%.3f%%", v * 100.0 / total)

    private fun box(b: RBox, rp: RichPage): String {
        val W = rp.setup.w.toDouble(); val H = rp.setup.h.toDouble()
        val sb = StringBuilder("<div style=\"position:absolute;left:").append(pc(b.x, W)).append(";top:").append(pc(b.y, H))
            .append(";width:").append(pc(b.w, W)).append(";height:").append(pc(b.h, H))
            .append(";box-sizing:border-box;overflow:hidden;display:flex;flex-direction:column;justify-content:")
            .append(when (b.valign) { "center" -> "center"; "bottom" -> "flex-end"; else -> "flex-start" })
        if (b.inset > 0) sb.append(";padding:").append(Rich.pt(b.inset)).append("pt")
        if (b.grad.size >= 2 && b.grad.all { Rich.hex(it) != null }) {
            if (b.radial) sb.append(";background:radial-gradient(circle at center") else sb.append(";background:linear-gradient(").append(String.format(java.util.Locale.US, "%.1f", b.gradAng + 90f)).append("deg")
            b.grad.forEachIndexed { gi, g -> sb.append(",#").append(Rich.hex(g)); b.gradPos.getOrNull(gi)?.takeIf { b.gradPos.size == b.grad.size }?.let { sb.append(String.format(java.util.Locale.US, " %.2f%%", it * 100.0)) } }
            sb.append(")")
        } else if (b.pie.isNotEmpty()) {
            sb.append(";background:conic-gradient(")
            var acc = 0.0
            b.pie.forEachIndexed { i, (f, c) -> val nx = acc + f * 100.0; if (i > 0) sb.append(','); sb.append('#').append(Rich.hex(c) ?: "888888").append(String.format(java.util.Locale.US, " %.3f%% %.3f%%", acc, nx)); acc = nx }
            sb.append(")")
        } else Rich.hex(b.fill)?.let { sb.append(";background:#").append(it) }
        if (b.rot != 0f || b.flipH || b.flipV) {
            sb.append(";transform:")
            if (b.rot != 0f) sb.append("rotate(").append(String.format(java.util.Locale.US, "%.1f", b.rot)).append("deg)")
            if (b.flipH || b.flipV) sb.append(" scale(").append(if (b.flipH) "-1" else "1").append(',').append(if (b.flipV) "-1" else "1").append(")")
        }
        Rich.hex(b.shadow)?.let {
            sb.append(";box-shadow:").append(Rich.pt(b.shadowDx)).append("pt ").append(Rich.pt(b.shadowDy)).append("pt ").append(Rich.pt(b.shadowBlur)).append("pt rgba(")
                .append(Integer.parseInt(it.substring(0, 2), 16)).append(',').append(Integer.parseInt(it.substring(2, 4), 16)).append(',').append(Integer.parseInt(it.substring(4, 6), 16)).append(',').append(String.format(java.util.Locale.US, "%.2f", b.shadowAlpha / 100.0)).append(")")
        }
        b.border?.let { sb.append(";border:").append(maxOf(1, it.w / 6)).append("px solid #").append(it.color) }
        if (b.round) sb.append(";border-radius:50%")
        else ShapeGeom.corner(b.prst).takeIf { it > 0f }?.let { sb.append(";border-radius:").append(String.format(java.util.Locale.US, "%.1f", it * 100f)).append('%') }
        ShapeGeom.clipPath(b.prst)?.let { sb.append(";clip-path:").append(it) }
        sb.append("\">")
        val cr = b.crop
        val pic = (b.blocks.firstOrNull() as? RPara)?.runs?.firstOrNull()?.img
        if (cr != null && pic != null) {
            val f = { v: Int -> String.format(java.util.Locale.US, "%.3f%%", v / 1000.0) }
            sb.append("<img src=\"").append(e(dataUri(pic))).append("\" style=\"width:100%;height:100%;object-fit:fill;object-view-box:inset(")
                .append(f(cr[1])).append(' ').append(f(cr[2])).append(' ').append(f(cr[3])).append(' ').append(f(cr[0])).append(")\">")
        } else for (x in b.blocks) sb.append(when (x) { is RPara -> para(x, rp); is RTable -> table(x, rp); is RBox -> box(x, rp) })
        return sb.append("</div>").toString()
    }

    /** Slayt sayfası: kutular yüzde ile konumlanır, punto birimleri sayfa genişliğine oranlı (cqw) olur; telefonda orantılı küçülür. */
    private fun slide(rp: RichPage): String {
        val s = rp.setup
        val wpt = s.w / 20.0
        val inner = StringBuilder()
        for (b in rp.blocks) if (b is RBox) inner.append(box(b, rp))
        val scaled = Regex("(-?[0-9]+(?:\\.[0-9]+)?)pt").replace(inner.toString()) { m -> String.format(java.util.Locale.US, "%.4fcqw", m.groupValues[1].toDouble() / wpt * 100.0) }
        val bg = Rich.hex(rp.bg) ?: "FFFFFF"
        val font = rp.defFont?.let { ";font-family:'" + it.filter { c -> c.isLetterOrDigit() || c == ' ' || c == '-' } + "',Arial,sans-serif" } ?: ""
        return "<div class=\"pg sl\" style=\"max-width:" + Rich.pt(s.w) + "pt;aspect-ratio:" + s.w + "/" + s.h + ";background:#" + bg + "\"><div style=\"position:absolute;left:0;top:0;right:0;bottom:0;font-size:" +
            String.format(java.util.Locale.US, "%.4f", rp.defSz / 2.0 / wpt * 100.0) + "cqw" + font + "\">" + scaled + "</div></div>\n"
    }

    /** Tam HTML belgesi (tek ya da çok sayfa). */
    fun document(title: String, pages: List<RichPage>, embedFonts: Boolean = false): String {
        val sb = StringBuilder("<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>")
        sb.append(e(title)).append("</title><style>").append(if (embedFonts) FontMap.fontFaceCss() else "").append(CSS).append("</style></head><body>\n")
        for (p in pages) sb.append(page(p))
        return sb.append("</body></html>\n").toString()
    }
}
