package com.odak.app.block

import android.content.Context
import com.odak.app.logic.ModelPure
import org.pytorch.IValue
import org.pytorch.LiteModuleLoader
import org.pytorch.Module
import org.pytorch.Tensor
import org.pytorch.executorch.EValue
import org.pytorch.executorch.Module as EtModule
import org.pytorch.executorch.Tensor as EtTensor

/** PyTorch Mobile (.ptl) ve ExecuTorch (.pte) ile içe aktarılan sınıflandırıcı: girdi [1,144] float, çıktı [1,2] (ya da [1,1]). */
object TorchRunner {
    private var torch: Module? = null; private var torchPath: String? = null
    private var et: EtModule? = null; private var etPath: String? = null

    @Synchronized fun release() { torch = null; torchPath = null; try { et?.destroy() } catch (t: Throwable) { }; et = null; etPath = null }

    @Synchronized fun probTorch(c: Context, x: DoubleArray): Double? = try {
        val f = ModelDownloader.find(c, ".ptl")
        if (f == null) null else {
            if (torch == null || torchPath != f.path) { torch = LiteModuleLoader.load(f.path); torchPath = f.path }
            val t = Tensor.fromBlob(FloatArray(x.size) { x[it].toFloat() }, longArrayOf(1, x.size.toLong()))
            ModelPure.pickProbability(torch!!.forward(IValue.from(t)).toTensor().dataAsFloatArray)
        }
    } catch (t: Throwable) { torch = null; null }

    @Synchronized fun probExecutorch(c: Context, x: DoubleArray): Double? = try {
        val f = ModelDownloader.find(c, ".pte")
        if (f == null) null else {
            if (et == null || etPath != f.path) { et = EtModule.load(f.path); etPath = f.path }
            val t = EtTensor.fromBlob(FloatArray(x.size) { x[it].toFloat() }, longArrayOf(1, x.size.toLong()))
            ModelPure.pickProbability(et!!.forward(EValue.from(t))[0].toTensor().dataAsFloatArray)
        }
    } catch (t: Throwable) { et = null; null }
}
