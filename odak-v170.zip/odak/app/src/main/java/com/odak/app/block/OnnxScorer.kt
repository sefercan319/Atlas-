package com.odak.app.block

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import com.odak.app.logic.ModelPure

/**
 * ONNX Runtime (Microsoft, açık kaynak) ile içe aktarılan sınıflandırıcıyı çalıştırır. Model bilgisayarda/Colab'da
 * (tools/train_onnx.py: scikit-learn → ONNX) uygulamanın dışa aktardığı eğitim verisiyle eğitilir; girdi LearnPure.features (144 boyut).
 */
object OnnxScorer {
    private var session: OrtSession? = null
    private var path: String? = null

    fun available(c: Context): Boolean = ModelDownloader.find(c, ".onnx") != null

    @Synchronized fun release() { try { session?.close() } catch (t: Throwable) { }; session = null; path = null }

    @Synchronized private fun open(c: Context): OrtSession? {
        val f = ModelDownloader.find(c, ".onnx") ?: return null
        if (session != null && path == f.path) return session
        release()
        return try { OrtEnvironment.getEnvironment().createSession(f.path, OrtSession.SessionOptions()).also { session = it; path = f.path } } catch (t: Throwable) { null }
    }

    /** Olumlu olasılık; model yoksa/okunamazsa null. */
    @Synchronized fun prob(c: Context, x: DoubleArray): Double? = try {
        val s = open(c)
        if (s == null) null else {
            val env = OrtEnvironment.getEnvironment()
            OnnxTensor.createTensor(env, arrayOf(FloatArray(x.size) { x[it].toFloat() })).use { t ->
                s.run(mapOf(s.inputNames.first() to t)).use { r ->
                    var out: Double? = null
                    for (e in r) {
                        val v = e.value.value
                        val arr = when (v) { is FloatArray -> v; is Array<*> -> v.firstOrNull() as? FloatArray; else -> null }
                        if (arr != null) { out = ModelPure.pickProbability(arr); if (out != null) break }
                    }
                    out
                }
            }
        }
    } catch (t: Throwable) { release(); null }
}
