package com.odak.app.docs

import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler

/**
 * PPTX slaytı → konumlu kutulardan oluşan biçimli sayfa ([RBox]): şekil/metin kutusu/resim/tablo kendi konumunda, düzen (layout) ve
 * ana slayttan (master) miras alınan yer tutucu konumu, madde imi, yazı boyutu/rengi/tipi, arka plan, süs şekilleri, tema renkleri
 * (lumMod/lumOff/tint/shade) ve tablo stilleri (tableStyles.xml + yaygın yerleşik "Medium Style 2" stilleri).
 * Gradyan yalnız ilk durak rengiyle, grup dönüşümü tek seviye, gölge/yansıma/3B/grafik yoktur.
 */
object RichPptx {
    private const val EMU = 635L

    // ---------------- renk yardımcıları ----------------
    internal fun hsl(hex: String): DoubleArray {
        val r = hex.substring(0, 2).toInt(16) / 255.0; val g = hex.substring(2, 4).toInt(16) / 255.0; val b = hex.substring(4, 6).toInt(16) / 255.0
        val mx = maxOf(r, g, b); val mn = minOf(r, g, b); val l = (mx + mn) / 2
        if (mx == mn) return doubleArrayOf(0.0, 0.0, l)
        val d = mx - mn; val s = if (l > 0.5) d / (2 - mx - mn) else d / (mx + mn)
        val h = when (mx) { r -> (g - b) / d + (if (g < b) 6 else 0); g -> (b - r) / d + 2; else -> (r - g) / d + 4 } / 6
        return doubleArrayOf(h, s, l)
    }
    internal fun fromHsl(h: Double, s: Double, l: Double): String {
        fun f(p: Double, q: Double, t0: Double): Double { var t = t0; if (t < 0) t += 1.0; if (t > 1) t -= 1.0
            return when { t < 1.0 / 6 -> p + (q - p) * 6 * t; t < 0.5 -> q; t < 2.0 / 3 -> p + (q - p) * (2.0 / 3 - t) * 6; else -> p } }
        val r: Double; val g: Double; val b: Double
        if (s == 0.0) { r = l; g = l; b = l } else {
            val q = if (l < 0.5) l * (1 + s) else l + s - l * s; val p = 2 * l - q
            r = f(p, q, h + 1.0 / 3); g = f(p, q, h); b = f(p, q, h - 1.0 / 3)
        }
        return "%02X%02X%02X".format((r * 255).toInt().coerceIn(0, 255), (g * 255).toInt().coerceIn(0, 255), (b * 255).toInt().coerceIn(0, 255))
    }
    internal fun lumMod(hex: String, v: Double): String { val x = hsl(hex); return fromHsl(x[0], x[1], (x[2] * v).coerceIn(0.0, 1.0)) }
    internal fun lumOff(hex: String, v: Double): String { val x = hsl(hex); return fromHsl(x[0], x[1], (x[2] + v).coerceIn(0.0, 1.0)) }
    internal fun tint(hex: String, v: Double): String = (0..2).joinToString("") { "%02X".format((hex.substring(it * 2, it * 2 + 2).toInt(16) * v + 255 * (1 - v)).toInt().coerceIn(0, 255)) }
    internal fun shade(hex: String, v: Double): String = (0..2).joinToString("") { "%02X".format((hex.substring(it * 2, it * 2 + 2).toInt(16) * v).toInt().coerceIn(0, 255)) }

    private val PRST = mapOf("black" to "000000", "white" to "FFFFFF", "red" to "FF0000", "green" to "008000", "blue" to "0000FF", "yellow" to "FFFF00", "gray" to "808080", "grey" to "808080", "orange" to "FFA500")

    fun theme(xml: ByteArray?): Map<String, String> {
        val m = HashMap<String, String>()
        if (xml == null) return m
        var cur: String? = null
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) {
                    "a:dk1", "a:lt1", "a:dk2", "a:lt2", "a:accent1", "a:accent2", "a:accent3", "a:accent4", "a:accent5", "a:accent6", "a:hlink", "a:folHlink" -> cur = q.removePrefix("a:")
                    "a:srgbClr" -> cur?.let { m[it] = Rich.hex(a?.getValue("val")) ?: "000000" }
                    "a:sysClr" -> cur?.let { m[it] = Rich.hex(a?.getValue("lastClr")) ?: "000000" }
                }
            }
            override fun endElement(u: String?, l: String?, q: String) { if (q.startsWith("a:") && q.removePrefix("a:") == cur) cur = null }
        })
        return m
    }

    fun slideSize(xml: ByteArray?): Pair<Int, Int> {
        var w = 19200; var h = 10800
        if (xml != null) DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                if (q == "p:sldSz") {
                    val cx = a?.getValue("cx")?.toLongOrNull(); val cy = a?.getValue("cy")?.toLongOrNull()
                    if (cx != null && cy != null && cx > 0 && cy > 0) { w = (cx / EMU).toInt().coerceIn(2000, 60000); h = (cy / EMU).toInt().coerceIn(2000, 60000) }
                }
            }
        })
        return w to h
    }

    // ---------------- ham model ----------------
    internal class Lvl(
        var marL: Int? = null, var indent: Int? = null, var algn: String? = null, var bullet: String? = null, var buFont: String? = null,
        var sz: Int? = null, var b: Boolean? = null, var i: Boolean? = null, var u: Boolean? = null, var s: Boolean? = null,
        var color: String? = null, var font: String? = null, var spcBef: Int? = null, var spcAft: Int? = null, var lnPct: Int? = null, var sup: Int? = null
    ) {
        fun over(o: Lvl?) {
            if (o == null) return
            o.marL?.let { marL = it }; o.indent?.let { indent = it }; o.algn?.let { algn = it }; o.bullet?.let { bullet = it }; o.buFont?.let { buFont = it }
            o.sz?.let { sz = it }; o.b?.let { b = it }; o.i?.let { i = it }; o.u?.let { u = it }; o.s?.let { s = it }; o.color?.let { color = it }; o.font?.let { font = it }
            o.spcBef?.let { spcBef = it }; o.spcAft?.let { spcAft = it }; o.lnPct?.let { lnPct = it }; o.sup?.let { sup = it }
        }
    }
    internal class RawRun(val text: String, val p: Lvl)
    internal class RawPara(val lvl: Int, val p: Lvl, val runs: List<RawRun>)
    internal class RawCell { val paras = ArrayList<RawPara>(); var span = 1; var rowSpan = 1; var hMerge = false; var vMerge = false; var fill: String? = null }
    internal class RawTbl { val cols = ArrayList<Int>(); val rows = ArrayList<List<RawCell>>(); var first = false; var band = false; var firstCol = false; var last = false; var styleId = "" }
    internal class Shape(val kind: String) {
        var phType: String? = null; var phIdx: String? = null
        var x = -1L; var y = -1L; var cx = -1L; var cy = -1L
        var fill: String? = null; var lineColor: String? = null; var lineW = 0L; var noLine = false; var prst = ""
        var anchor = ""; var lIns = -1L; var tIns = -1L; var rIns = -1L; var bIns = -1L; var scale = 100000
        val lst = Array(9) { Lvl() }
        val paras = ArrayList<RawPara>()
        var picRId: String? = null; var tbl: RawTbl? = null
        var styleFont: String? = null; var hasStyle = false; var txBox = false
        var gradPos = ArrayList<Float>(); var flipH = false; var flipV = false; var radial = false; var shBlur = 50800L; var shDist = 38100L; var shDir = 2700000L; var shAlpha = 45
        var rot = 0f; var grad = ArrayList<String>(); var gradAng = 0f; var shadow: String? = null; var crop: IntArray? = null; var chartRId: String? = null
    }
    internal class Grp { var rot = 0f; var ox = 0L; var oy = 0L; var cx = 1L; var cy = 1L; var chOx = 0L; var chOy = 0L; var chCx = 1L; var chCy = 1L }
    internal class Part {
        val shapes = ArrayList<Shape>(); var bg: String? = null; var showMaster = true
        val styles = Array(3) { Array(9) { Lvl() } }   // title, body, other
    }
    internal class TSec { var fill: String? = null; var color: String? = null; var bold: Boolean? = null }
    internal class TStyle { val sec = HashMap<String, TSec>() }

    internal fun tableStyles(xml: ByteArray?, theme: Map<String, String>): Map<String, TStyle> {
        val out = HashMap<String, TStyle>()
        if (xml == null) return out
        var cur: TStyle? = null; var sec: TSec? = null; var secName = ""; var inFill = false; var inTx = false
        val stack = ArrayList<String>()
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                stack.add(q)
                when (q) {
                    "a:tblStyle" -> { cur = TStyle(); a?.getValue("styleId")?.let { out[it] = cur!! } }
                    "a:wholeTbl", "a:band1H", "a:band2H", "a:firstRow", "a:lastRow", "a:firstCol", "a:lastCol" -> { sec = TSec(); secName = q.removePrefix("a:"); cur?.sec?.put(secName, sec!!) }
                    "a:fill" -> inFill = true
                    "a:tcTxStyle" -> { inTx = true; if (a?.getValue("b") == "on") sec?.bold = true }
                    "a:srgbClr", "a:schemeClr" -> {
                        val par = stack.getOrNull(stack.size - 2)
                        val base = if (q == "a:srgbClr") Rich.hex(a?.getValue("val")) else a?.getValue("val")?.let { schemeName(it) }?.let { theme[it] }
                        if (base != null && par == "a:solidFill" && inFill) sec?.fill = base
                        else if (base != null && inTx && (par == "a:tcTxStyle" || par == "a:fontRef")) sec?.color = base
                    }
                    "a:lumMod" -> if (inFill) sec?.fill = sec?.fill?.let { lumMod(it, (a?.getValue("val")?.toDoubleOrNull() ?: 100000.0) / 100000) }
                    "a:lumOff" -> if (inFill) sec?.fill = sec?.fill?.let { lumOff(it, (a?.getValue("val")?.toDoubleOrNull() ?: 0.0) / 100000) }
                    "a:tint" -> if (inFill) sec?.fill = sec?.fill?.let { tint(it, (a?.getValue("val")?.toDoubleOrNull() ?: 100000.0) / 100000) }
                    "a:shade" -> if (inFill) sec?.fill = sec?.fill?.let { shade(it, (a?.getValue("val")?.toDoubleOrNull() ?: 100000.0) / 100000) }
                }
            }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) { "a:fill" -> inFill = false; "a:tcTxStyle" -> inTx = false; "a:tblStyle" -> cur = null }
                if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
            }
        })
        return out
    }

    private val ACCENT_IDS = mapOf(
        "{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}" to "accent1", "{21E4AEA4-8DFA-4A89-87EB-49C32662AFE0}" to "accent2", "{F5AB1C69-6EDB-4FF4-983F-18BD219EF322}" to "accent3",
        "{00A15C55-8517-42AA-B614-E9B94910E393}" to "accent4", "{7DF18680-E054-41AD-8BC1-D1AEF772440D}" to "accent5", "{93296810-A885-4BE3-A3E7-6D5BEEA58F35}" to "accent6"
    )

    /** Tanımı dosyada olmayan yaygın yerleşik tablo stili ("Orta Stil 2 – Vurgu n"). */
    internal fun builtinStyle(id: String, theme: Map<String, String>): TStyle? {
        val acc = ACCENT_IDS[id.uppercase()] ?: return null
        val c = theme[acc] ?: return null
        val st = TStyle()
        st.sec["wholeTbl"] = TSec().also { it.fill = tint(c, 0.2); it.color = theme["dk1"] ?: "000000" }
        st.sec["band1H"] = TSec().also { it.fill = tint(c, 0.4) }
        st.sec["firstRow"] = TSec().also { it.fill = c; it.color = theme["lt1"] ?: "FFFFFF"; it.bold = true }
        st.sec["lastRow"] = TSec().also { it.fill = c; it.color = theme["lt1"] ?: "FFFFFF"; it.bold = true }
        st.sec["firstCol"] = TSec().also { it.fill = c; it.color = theme["lt1"] ?: "FFFFFF"; it.bold = true }
        return st
    }

    internal fun schemeName(v: String): String? = when (v) {
        "tx1", "dk1" -> "dk1"; "bg1", "lt1" -> "lt1"; "tx2", "dk2" -> "dk2"; "bg2", "lt2" -> "lt2"
        "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hlink", "folHlink" -> v
        else -> null
    }

    // ---------------- parça (slayt/düzen/ana slayt) okuyucu ----------------
    internal fun parsePart(xml: ByteArray, theme: Map<String, String>): Part {
        val part = Part()
        val stack = ArrayList<String>()
        var sh: Shape? = null
        val groups = ArrayList<Grp>()
        var inBg = false; var inLn = false; var gsCount = 0
        var lstTarget: Array<Lvl>? = null; var curLvl: Lvl? = null; var paraDirect = Lvl(); var paraLvl = 0
        var runTarget: Lvl = Lvl(); var runLvl = Lvl()
        var inP = false; var inR = false; var inT = false
        val runs = ArrayList<RawRun>(); val rText = StringBuilder()
        var tbl: RawTbl? = null; var tcur: RawCell? = null; var trow = ArrayList<RawCell>()
        var colorTarget = 0; var curColor: String? = null; var spcOwner = ""
        var styleSel = -1; var inTblId = false; val tblId = StringBuilder()

        fun setColor(c: String?) {
            if (c == null) return
            when (colorTarget) {
                1 -> curLvl?.color = c
                2 -> runTarget.color = c
                3 -> sh?.fill = c
                4 -> tcur?.fill = c
                5 -> part.bg = c
                6 -> sh?.lineColor = c
                7 -> sh?.styleFont = c
                8 -> sh?.let { if (it.grad.isNotEmpty()) { it.grad[it.grad.size - 1] = c; if (it.grad.size == 1) it.fill = c } }
                9 -> sh?.shadow = c
            }
        }
        fun readPPr(a: Attributes?, l: Lvl) {
            a?.getValue("marL")?.toIntOrNull()?.let { l.marL = it }; a?.getValue("indent")?.toIntOrNull()?.let { l.indent = it }; a?.getValue("algn")?.let { l.algn = it }
        }
        fun readRPr(a: Attributes?, l: Lvl) {
            a?.getValue("sz")?.toIntOrNull()?.let { l.sz = it }
            a?.getValue("b")?.let { l.b = it == "1" || it == "true" }; a?.getValue("i")?.let { l.i = it == "1" || it == "true" }
            a?.getValue("u")?.let { l.u = it != "none" }; a?.getValue("strike")?.let { l.s = it != "noStrike" }
            a?.getValue("baseline")?.toIntOrNull()?.let { l.sup = if (it > 0) 1 else if (it < 0) -1 else 0 }
        }

        fun finishShape() {
            val s = sh ?: return
            if (s.x >= 0) for (g in groups.asReversed()) {
                s.x = g.ox + (s.x - g.chOx) * g.cx / g.chCx.coerceAtLeast(1); s.y = g.oy + (s.y - g.chOy) * g.cy / g.chCy.coerceAtLeast(1)
                if (s.cx >= 0) { s.cx = s.cx * g.cx / g.chCx.coerceAtLeast(1); s.cy = s.cy * g.cy / g.chCy.coerceAtLeast(1) }
                if (g.rot != 0f && s.cx >= 0) {
                    val a = Math.toRadians(g.rot.toDouble())
                    val gcx = g.ox + g.cx / 2.0; val gcy = g.oy + g.cy / 2.0
                    val px = s.x + s.cx / 2.0 - gcx; val py = s.y + s.cy / 2.0 - gcy
                    val nx = gcx + px * Math.cos(a) - py * Math.sin(a); val ny = gcy + px * Math.sin(a) + py * Math.cos(a)
                    s.x = (nx - s.cx / 2.0).toLong(); s.y = (ny - s.cy / 2.0).toLong(); s.rot += g.rot
                }
            }
            if (part.shapes.size < 1500) part.shapes.add(s)
            sh = null
        }

        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                stack.add(q)
                val n = stack.size - 1
                when (q) {
                    "p:sld", "p:sldLayout" -> if (a?.getValue("showMasterSp") == "0") part.showMaster = false
                    "p:grpSp" -> if (groups.size < 12) groups.add(Grp())
                    "a:xfrm", "p:xfrm" -> {
                        val rv = a?.getValue("rot")?.toLongOrNull()?.let { (it / 60000.0).toFloat() }
                        if (stack.getOrNull(n - 1) == "p:grpSpPr") { if (rv != null) groups.lastOrNull()?.rot = rv }
                        else if (sh != null) { if (rv != null) sh!!.rot = rv; sh!!.flipH = a?.getValue("flipH") == "1"; sh!!.flipV = a?.getValue("flipV") == "1" }
                    }
                    "a:path" -> if (stack.getOrNull(n - 1) == "a:gradFill") sh?.radial = true
                    "a:outerShdw" -> sh?.let { it.shBlur = a?.getValue("blurRad")?.toLongOrNull() ?: 0L; it.shDist = a?.getValue("dist")?.toLongOrNull() ?: 0L; it.shDir = a?.getValue("dir")?.toLongOrNull() ?: 0L }
                    "a:alpha" -> if (colorTarget == 9) sh?.shAlpha = ((a?.getValue("val")?.toIntOrNull() ?: 45000) / 1000).coerceIn(0, 100)
                    "a:srcRect" -> sh?.let { it.crop = intArrayOf(a?.getValue("l")?.toIntOrNull() ?: 0, a?.getValue("t")?.toIntOrNull() ?: 0, a?.getValue("r")?.toIntOrNull() ?: 0, a?.getValue("b")?.toIntOrNull() ?: 0).takeIf { c -> c.any { v -> v != 0 } && c[0] + c[2] < 100000 && c[1] + c[3] < 100000 } }
                    "c:chart" -> sh?.chartRId = a?.getValue("r:id")
                    "a:lin" -> sh?.gradAng = (a?.getValue("ang")?.toLongOrNull() ?: 0L) / 60000f
                    "p:sp", "p:pic", "p:graphicFrame", "p:cxnSp" -> if (sh == null) { sh = Shape(when (q) { "p:pic" -> "pic"; "p:graphicFrame" -> "frame"; "p:cxnSp" -> "cxn"; else -> "sp" }) }
                    "p:style" -> sh?.hasStyle = true
                    "p:cNvSpPr" -> if (a?.getValue("txBox") == "1") sh?.txBox = true
                    "p:ph" -> sh?.let { it.phType = a?.getValue("type") ?: ""; it.phIdx = a?.getValue("idx") }
                    "p:bg" -> inBg = true
                    "a:off" -> {
                        val par = stack.getOrNull(n - 1); val x = a?.getValue("x")?.toLongOrNull() ?: 0; val y = a?.getValue("y")?.toLongOrNull() ?: 0
                        if (par == "a:xfrm" && stack.getOrNull(n - 2) == "p:grpSpPr") { groups.lastOrNull()?.let { it.ox = x; it.oy = y } } else if (sh != null && tbl == null) { sh!!.x = x; sh!!.y = y }
                    }
                    "a:ext" -> {
                        val par = stack.getOrNull(n - 1); val cx = a?.getValue("cx")?.toLongOrNull() ?: 0; val cy = a?.getValue("cy")?.toLongOrNull() ?: 0
                        if (par == "a:xfrm" && stack.getOrNull(n - 2) == "p:grpSpPr") { groups.lastOrNull()?.let { it.cx = cx; it.cy = cy } } else if (sh != null && tbl == null && (par == "a:xfrm" || par == "p:xfrm")) { sh!!.cx = cx; sh!!.cy = cy }
                    }
                    "a:chOff" -> groups.lastOrNull()?.let { it.chOx = a?.getValue("x")?.toLongOrNull() ?: 0; it.chOy = a?.getValue("y")?.toLongOrNull() ?: 0 }
                    "a:chExt" -> groups.lastOrNull()?.let { it.chCx = a?.getValue("cx")?.toLongOrNull() ?: 1; it.chCy = a?.getValue("cy")?.toLongOrNull() ?: 1 }
                    "a:prstGeom" -> sh?.prst = a?.getValue("prst") ?: ""
                    "a:ln" -> if (stack.getOrNull(n - 1) == "p:spPr") { inLn = true; sh?.lineW = a?.getValue("w")?.toLongOrNull() ?: 12700L }
                    "a:noFill" -> { if (inLn) sh?.noLine = true }
                    "a:gradFill" -> gsCount = 0
                    "a:gs" -> { gsCount++; if (sh != null && tbl == null && stack.getOrNull(n - 2) == "a:gradFill" && stack.getOrNull(n - 3) == "p:spPr" && (sh?.grad?.size ?: 0) < 8) { sh?.grad?.add("FFFFFF"); sh?.gradPos?.add(((a?.getValue("pos")?.toIntOrNull() ?: 0) / 100000f).coerceIn(0f, 1f)) } }
                    "a:bodyPr" -> sh?.let { s ->
                        s.anchor = a?.getValue("anchor") ?: ""
                        a?.getValue("lIns")?.toLongOrNull()?.let { s.lIns = it }; a?.getValue("tIns")?.toLongOrNull()?.let { s.tIns = it }
                        a?.getValue("rIns")?.toLongOrNull()?.let { s.rIns = it }; a?.getValue("bIns")?.toLongOrNull()?.let { s.bIns = it }
                    }
                    "a:normAutofit" -> sh?.scale = a?.getValue("fontScale")?.toIntOrNull() ?: 100000
                    "p:titleStyle" -> { styleSel = 0; lstTarget = part.styles[0] }
                    "p:bodyStyle" -> { styleSel = 1; lstTarget = part.styles[1] }
                    "p:otherStyle" -> { styleSel = 2; lstTarget = part.styles[2] }
                    "a:lstStyle" -> sh?.let { lstTarget = it.lst }
                    "a:lvl1pPr", "a:lvl2pPr", "a:lvl3pPr", "a:lvl4pPr", "a:lvl5pPr", "a:lvl6pPr", "a:lvl7pPr", "a:lvl8pPr", "a:lvl9pPr" -> lstTarget?.let { t ->
                        curLvl = t[q[5] - '1']; readPPr(a, curLvl!!)
                    }
                    "a:p" -> { inP = true; runs.clear(); paraDirect = Lvl(); paraLvl = 0; curLvl = paraDirect }
                    "a:pPr" -> if (inP) { curLvl = paraDirect; readPPr(a, paraDirect); paraLvl = (a?.getValue("lvl")?.toIntOrNull() ?: 0).coerceIn(0, 8) }
                    "a:buChar" -> curLvl?.bullet = a?.getValue("char")?.take(1) ?: "•"
                    "a:buAutoNum" -> curLvl?.bullet = "auto"
                    "a:buNone" -> curLvl?.bullet = "none"
                    "a:buFont" -> curLvl?.buFont = a?.getValue("typeface")
                    "a:spcBef", "a:spcAft", "a:lnSpc" -> spcOwner = q
                    "a:spcPts" -> { val v = a?.getValue("val")?.toIntOrNull(); if (v != null) { if (spcOwner == "a:spcBef") curLvl?.spcBef = v / 5 else if (spcOwner == "a:spcAft") curLvl?.spcAft = v / 5 } }
                    "a:spcPct" -> if (spcOwner == "a:lnSpc") curLvl?.lnPct = ((a?.getValue("val")?.toIntOrNull() ?: 100000) * 240L / 100000).toInt()
                    "a:defRPr" -> { curLvl?.let { runTarget = it; readRPr(a, it) } }
                    "a:r", "a:fld" -> { inR = true; runLvl = Lvl(); runTarget = runLvl; rText.setLength(0) }
                    "a:rPr" -> if (inR) { runTarget = runLvl; readRPr(a, runLvl) }
                    "a:endParaRPr" -> runTarget = Lvl()
                    "a:latin" -> { val f = a?.getValue("typeface")?.takeIf { !it.startsWith("+") }; if (f != null) runTarget.font = f }
                    "a:t" -> if (inR) inT = true
                    "a:br" -> if (inP) runs.add(RawRun("\n", Lvl()))
                    "a:blip" -> sh?.picRId = a?.getValue("r:embed")
                    "a:tbl" -> { tbl = RawTbl() }
                    "a:tblPr" -> tbl?.let { t -> t.first = a?.getValue("firstRow") == "1"; t.band = a?.getValue("bandRow") == "1"; t.firstCol = a?.getValue("firstCol") == "1"; t.last = a?.getValue("lastRow") == "1" }
                    "a:tableStyleId" -> { inTblId = true; tblId.setLength(0) }
                    "a:gridCol" -> tbl?.cols?.add(((a?.getValue("w")?.toLongOrNull() ?: 914400L) / EMU).toInt().coerceAtLeast(300))
                    "a:tr" -> trow = ArrayList()
                    "a:tc" -> if (tbl != null) tcur = RawCell().also { c ->
                        c.span = (a?.getValue("gridSpan")?.toIntOrNull() ?: 1).coerceIn(1, 30); c.rowSpan = (a?.getValue("rowSpan")?.toIntOrNull() ?: 1).coerceIn(1, 100)
                        c.hMerge = a?.getValue("hMerge") == "1"; c.vMerge = a?.getValue("vMerge") == "1"
                    }
                    "a:srgbClr", "a:schemeClr", "a:sysClr", "a:prstClr" -> {
                        val par = stack.getOrNull(n - 1)
                        val owner = when (par) {
                            "a:solidFill" -> stack.getOrNull(n - 2)
                            "a:gs" -> if (sh != null && tbl == null && stack.getOrNull(n - 4) == "p:spPr") "grad" else if (gsCount == 1) stack.getOrNull(n - 4) else null
                            "a:outerShdw" -> "a:outerShdw"
                            "p:bgRef" -> "p:bgPr"
                            "a:fontRef" -> "a:fontRef"
                            else -> null
                        }
                        colorTarget = when (owner) {
                            "a:defRPr" -> 1; "a:rPr" -> 2
                            "p:spPr" -> if (sh != null && tbl == null) 3 else 0
                            "a:tcPr" -> 4; "p:bgPr" -> 5; "a:ln" -> 6; "a:fontRef" -> 7; "grad" -> 8; "a:outerShdw" -> 9
                            else -> 0
                        }
                        curColor = when (q) {
                            "a:srgbClr" -> Rich.hex(a?.getValue("val"))
                            "a:schemeClr" -> schemeName(a?.getValue("val") ?: "")?.let { theme[it] }
                            "a:sysClr" -> Rich.hex(a?.getValue("lastClr"))
                            else -> PRST[a?.getValue("val") ?: ""]
                        }
                        if (colorTarget > 0) setColor(curColor)
                    }
                    "a:lumMod" -> if (colorTarget > 0) { curColor = curColor?.let { lumMod(it, (a?.getValue("val")?.toDoubleOrNull() ?: 100000.0) / 100000) }; setColor(curColor) }
                    "a:lumOff" -> if (colorTarget > 0) { curColor = curColor?.let { lumOff(it, (a?.getValue("val")?.toDoubleOrNull() ?: 0.0) / 100000) }; setColor(curColor) }
                    "a:tint" -> if (colorTarget > 0) { curColor = curColor?.let { tint(it, (a?.getValue("val")?.toDoubleOrNull() ?: 100000.0) / 100000) }; setColor(curColor) }
                    "a:shade" -> if (colorTarget > 0) { curColor = curColor?.let { shade(it, (a?.getValue("val")?.toDoubleOrNull() ?: 100000.0) / 100000) }; setColor(curColor) }
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inT) rText.append(ch, s, len); if (inTblId) tblId.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) {
                    "a:t" -> inT = false
                    "a:tableStyleId" -> { inTblId = false; tbl?.styleId = tblId.toString().trim() }
                    "a:r", "a:fld" -> { inR = false; if (rText.isNotEmpty() || true) runs.add(RawRun(rText.toString(), runLvl)); rText.setLength(0) }
                    "a:p" -> {
                        inP = false
                        val rp = RawPara(paraLvl, paraDirect, ArrayList(runs))
                        if (tcur != null) tcur!!.paras.add(rp) else sh?.paras?.add(rp)
                        runs.clear(); curLvl = null
                    }
                    "a:tc" -> { tcur?.let { trow.add(it) }; tcur = null }
                    "a:tr" -> { tbl?.rows?.add(trow); trow = ArrayList() }
                    "a:tbl" -> { sh?.tbl = tbl; tbl = null }
                    "a:ln" -> inLn = false
                    "a:lstStyle" -> { if (styleSel < 0) lstTarget = null }
                    "p:titleStyle", "p:bodyStyle", "p:otherStyle" -> { styleSel = -1; lstTarget = null }
                    "p:bg" -> inBg = false
                    "p:sp", "p:pic", "p:graphicFrame", "p:cxnSp" -> finishShape()
                    "p:grpSp" -> { if (groups.isNotEmpty()) groups.removeAt(groups.size - 1) }
                }
                if (q == "a:srgbClr" || q == "a:schemeClr" || q == "a:sysClr" || q == "a:prstClr" || q == "a:solidFill" || q == "a:gs") colorTarget = 0
                if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
            }
        })
        return part
    }

    // ---------------- birleştirme ----------------
    private fun normType(t: String?): String = when (t) { "ctrTitle", "title" -> "title"; null, "", "subTitle", "body", "obj" -> "body"; else -> t }

    private fun match(ph: Shape, s: Shape): Boolean {
        if (ph.phType == null) return false
        if (s.phIdx != null && ph.phIdx != null && s.phIdx == ph.phIdx) return true
        return normType(ph.phType) == normType(s.phType) && (s.phIdx == null || ph.phIdx == null || normType(s.phType) == "title")
    }

    private fun bulletChar(c: String, font: String?): String {
        val f = (font ?: "").lowercase()
        if (f.contains("wingdings") || f.contains("symbol")) return when (c) { "§" -> "▪"; "Ø" -> "➢"; "ü" -> "✓"; "v" -> "❖"; "q" -> "❑"; "l" -> "●"; "n" -> "■"; "·" -> "•"; else -> "•" }
        val code = c[0].code
        return if (code < 0x20 || code in 0xE000..0xF8FF) "•" else c
    }

    /** Tek slayt için tüm yapıtaşları. */
    class Deck(private val e: Map<String, ByteArray>) {
        private val theme = try { theme(e["ppt/theme/theme1.xml"]) } catch (x: Exception) { emptyMap() }
        private val size = try { slideSize(e["ppt/presentation.xml"]) } catch (x: Exception) { 19200 to 10800 }
        private val tstyles = try { tableStyles(e["ppt/tableStyles.xml"], theme) } catch (x: Exception) { emptyMap() }
        private val parts = HashMap<String, Part?>()
        private var imgBytes = 0L

        private fun rels(partPath: String): List<Triple<String, String, String>> {
            val dir = partPath.substringBeforeLast('/', "") + "/"
            val x = e[dir + "_rels/" + partPath.substringAfterLast('/') + ".rels"] ?: return emptyList()
            val out = ArrayList<Triple<String, String, String>>()
            DocParse.sax(x, object : DefaultHandler() {
                override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                    if (q == "Relationship" && a?.getValue("TargetMode") != "External") {
                        val id = a?.getValue("Id") ?: return; val t = a.getValue("Target") ?: return
                        out.add(Triple(id, (a.getValue("Type") ?: "").substringAfterLast('/'), DocVisual.resolve(dir, t)))
                    }
                }
            })
            return out
        }

        private fun part(path: String?): Part? {
            if (path == null) return null
            return parts.getOrPut(path) { e[path]?.let { try { parsePart(it, theme) } catch (x: Exception) { null } } }
        }

        fun page(slidePath: String, notes: List<String>): RichPage? {
            val sl = part(slidePath) ?: return null
            val srels = rels(slidePath)
            val layoutPath = srels.firstOrNull { it.second == "slideLayout" }?.third
            val layout = part(layoutPath)
            val masterPath = layoutPath?.let { rels(it).firstOrNull { r -> r.second == "slideMaster" }?.third }
            val master = part(masterPath)
            val boxes = ArrayList<RBlock>()
            val bg = sl.bg ?: layout?.bg ?: master?.bg
            // süs şekilleri (ana slayt, sonra düzen): yer tutucu olmayanlar
            if (sl.showMaster && layout?.showMaster != false) master?.let { m -> for (s in m.shapes) if (s.phType == null) build(s, m, null, null, masterPath!!, null, boxes) }
            if (sl.showMaster) layout?.let { l -> for (s in l.shapes) if (s.phType == null) build(s, master, null, null, layoutPath!!, null, boxes) }
            for (s in sl.shapes) {
                val lph = if (s.phType != null) layout?.shapes?.firstOrNull { match(it, s) } else null
                val mph = if (s.phType != null) master?.shapes?.firstOrNull { match(it, s) } else null
                build(s, master, lph, mph, slidePath, layout, boxes)
            }
            val ns = notes.filter { it.isNotBlank() }
            if (ns.isNotEmpty()) boxes.add(RBox(540, size.second + 100, size.first - 1080, 1200, ns.map { RPara(listOf(RRun("📝 $it", i = true, sz = 20, color = "666666")), after = 40) }))
            if (boxes.isEmpty()) return null
            return RichPage(boxes, PageSetup(size.first, size.second, 0, 0, 0, 0), 36, null, 0, 0, bg = bg ?: "FFFFFF")
        }

        private fun paraOf(rp: RawPara, s: Shape, master: Part?, lph: Shape?, mph: Shape?, counter: IntArray): RPara {
            val nt = if (s.phType != null) normType(s.phType) else "other"
            val set = master?.styles?.get(when (nt) { "title" -> 0; "body" -> 1; else -> 2 })
            val eff = Lvl()
            s.styleFont?.let { eff.color = it }
            if (s.hasStyle && !s.txBox && s.phType == null && s.kind == "sp") eff.algn = "ctr"
            eff.over(set?.get(rp.lvl)); eff.over(mph?.lst?.get(rp.lvl)); eff.over(lph?.lst?.get(rp.lvl)); eff.over(s.lst[rp.lvl]); eff.over(rp.p)
            val defSz = if (nt == "title") 4400 else 1800
            val scale = s.scale / 100000.0
            val runs = ArrayList<RRun>()
            for (r in rp.runs) {
                val re = Lvl(); re.over(eff); re.over(r.p)
                val szHalf = (((re.sz ?: defSz) / 50.0) * scale).toInt().coerceIn(8, 400)
                val fx = SymbolFonts.fix(r.text, re.font?.takeIf { f -> !f.startsWith("+") })
                runs.add(RRun(fx.first, re.b == true, re.i == true, re.u == true, re.s == true, re.color ?: theme["dk1"], null, szHalf, fx.second, re.sup ?: 0))
            }
            var marker = ""
            val bl = eff.bullet
            if (bl == "auto") { counter[0]++; marker = "${counter[0]}." } else { counter[0] = 0; if (bl != null && bl != "none") marker = bulletChar(bl, eff.buFont) }
            val marL = ((eff.marL ?: 0) / EMU).toInt(); val ind = ((eff.indent ?: 0) / EMU).toInt()
            val left = if (marker.isNotEmpty()) maxOf(marL, 360) else marL
            val first = if (marker.isNotEmpty()) (if (ind < 0) ind else -360) else maxOf(ind, 0)
            val al = when (eff.algn) { "ctr" -> "center"; "r" -> "right"; "just" -> "justify"; else -> "" }
            return RPara(runs, al, if (nt == "title") 1 else 0, marker, left, first, eff.spcBef ?: 0, eff.spcAft ?: 0, eff.lnPct ?: 0)
        }

        private fun table(t: RawTbl): RTable? {
            if (t.rows.isEmpty()) return null
            val style = tstyles[t.styleId] ?: builtinStyle(t.styleId, theme)
            val builtin = tstyles[t.styleId] == null && style != null
            val n = t.rows.maxOf { r -> r.filter { !it.hMerge }.sumOf { it.span } }.coerceAtLeast(1)
            val cols = (0 until n).map { t.cols.getOrNull(it) ?: 2000 }
            val bd = Bd(6, if (builtin || style != null) "FFFFFF" else "BFBFBF")
            val rows = ArrayList<List<RCell>>()
            t.rows.forEachIndexed { ri, r ->
                val out = ArrayList<RCell>()
                val dataIdx = ri - (if (t.first) 1 else 0)
                val rowSec = when {
                    t.first && ri == 0 -> style?.sec?.get("firstRow")
                    t.last && ri == t.rows.size - 1 -> style?.sec?.get("lastRow")
                    t.band && dataIdx >= 0 -> style?.sec?.get(if (dataIdx % 2 == 0) "band1H" else "band2H")
                    else -> null
                }
                var ci = 0
                for (c in r) {
                    if (c.hMerge) { ci++; continue }
                    val colSec = if (t.firstCol && ci == 0) style?.sec?.get("firstCol") else null
                    val whole = style?.sec?.get("wholeTbl")
                    val fill = c.fill ?: colSec?.fill ?: rowSec?.fill ?: whole?.fill
                    val txColor = colSec?.color ?: rowSec?.color ?: whole?.color
                    val bold = colSec?.bold ?: rowSec?.bold
                    val paras = c.paras.map { rp ->
                        val rr = rp.runs.map { run ->
                            val re = Lvl(); re.over(run.p)
                            SymbolFonts.fix(run.text, re.font).let { fx -> RRun(fx.first, re.b ?: (bold == true), re.i == true, re.u == true, re.s == true, re.color ?: txColor ?: theme["dk1"], null, ((re.sz ?: 1800) / 50).coerceIn(8, 400), fx.second, 0) }
                        }
                        val al = when (rp.p.algn) { "ctr" -> "center"; "r" -> "right"; "just" -> "justify"; else -> "" }
                        RPara(rr, al, 0, "", 0, 0, 0, 0, 0)
                    }.ifEmpty { listOf(RPara(emptyList(), after = 0)) }
                    out.add(if (c.vMerge) RCell(emptyList(), c.span, 2, fill, bd, bd, bd, bd) else RCell(paras, c.span, if (c.rowSpan > 1) 1 else 0, fill, bd, bd, bd, bd))
                    ci += c.span
                }
                val s = out.sumOf { it.span }
                rows.add(if (s < n) out + RCell(listOf(RPara(emptyList(), after = 0)), n - s) else out)
            }
            return RTable(rows, cols)
        }

        private fun shDx(s: Shape) = (s.shDist * Math.cos(Math.toRadians(s.shDir / 60000.0)) / EMU).toInt()
        private fun shDy(s: Shape) = (s.shDist * Math.sin(Math.toRadians(s.shDir / 60000.0)) / EMU).toInt()

        private fun build(s: Shape, master: Part?, lph: Shape?, mph: Shape?, relsOwner: String, layout: Part?, out: MutableList<RBlock>) {
            var x = s.x; var y = s.y; var cx = s.cx; var cy = s.cy
            if (x < 0) { val g = lph?.takeIf { it.x >= 0 } ?: mph; if (g != null && g.x >= 0) { x = g.x; y = g.y; cx = g.cx; cy = g.cy } }
            if (s.kind == "frame" && s.tbl != null && x >= 0 && (cx <= 0 || cy <= 0)) { cx = s.tbl!!.cols.sumOf { it.toLong() } * EMU; cy = s.tbl!!.rows.size * 370000L }
            if (x < 0 || cx <= 0 || cy <= 0) { if (s.kind != "sp" || s.paras.isEmpty()) return; if (x < 0) { x = 457200; y = 457200; cx = size.first * EMU - 914400; cy = 1000000 } }
            val bx = (x / EMU).toInt(); val by = (y / EMU).toInt(); val bw = (cx / EMU).toInt(); val bh = (cy / EMU).toInt()
            when (s.kind) {
                "pic" -> {
                    val made = s.picRId?.let { id -> rels(relsOwner).firstOrNull { it.first == id }?.third }?.let { e[it] }?.let { RImg.make("", it) }
                    val data = made?.first; val mime = made?.second
                    if (data != null && mime != null && imgBytes + data.size <= 24L * 1024 * 1024) {
                        imgBytes += data.size
                        out.add(RBox(bx, by, bw, bh, listOf(RPara(listOf(RRun("", img = RImg(data, mime, bw.coerceAtLeast(100), bh.coerceAtLeast(100)))), before = 0, after = 0)), rot = s.rot, shadow = s.shadow, crop = s.crop, flipH = s.flipH, flipV = s.flipV, shadowDx = shDx(s), shadowDy = shDy(s), shadowBlur = (s.shBlur / EMU).toInt(), shadowAlpha = s.shAlpha))
                    }
                }
                "frame" -> {
                    s.tbl?.let { t -> table(t)?.let { out.add(RBox(bx, by, bw, bh, listOf(it))) } }
                    s.chartRId?.let { id ->
                        val cx0 = rels(relsOwner).firstOrNull { it.first == id }?.third?.let { e[it] }
                        if (cx0 != null) out.addAll(RichChart.render(cx0, bx, by, bw, bh, theme))
                    }
                }
                "cxn" -> {
                    val c = s.lineColor ?: return
                    val th = maxOf(((s.lineW / EMU).toInt()), 10)
                    out.add(RBox(bx, by, maxOf(bw, th), maxOf(bh, th), emptyList(), fill = c))
                }
                else -> {
                    if (s.phType != null && s.paras.none { p -> p.runs.any { it.text.isNotBlank() } }) return
                    val counter = IntArray(1)
                    val paras = s.paras.map { paraOf(it, s, master, lph, mph, counter) }.filter { it.runs.isNotEmpty() || it.marker.isNotEmpty() }
                    val border = if (!s.noLine && s.lineColor != null) Bd(maxOf(2, (s.lineW / 1588L).toInt()), s.lineColor!!) else null
                    if (paras.isEmpty() && s.fill == null && border == null && s.grad.size < 2) return
                    val bodyIns = s.lIns.takeIf { it >= 0 } ?: 91440L
                    val anchor = (s.anchor.takeIf { it.isNotEmpty() } ?: lph?.anchor?.takeIf { it.isNotEmpty() } ?: mph?.anchor ?: "")
                    out.add(RBox(bx, by, bw, bh, paras, s.fill, border, when (anchor) { "ctr" -> "center"; "b" -> "bottom"; else -> "" }, ShapeGeom.isEllipse(s.prst), (bodyIns / EMU).toInt(),
                        rot = s.rot, grad = if (s.grad.size >= 2) s.grad.toList() else emptyList(), gradPos = if (s.grad.size >= 2) s.gradPos.toList() else emptyList(), gradAng = s.gradAng, shadow = s.shadow,
                        flipH = s.flipH && paras.isEmpty(), flipV = s.flipV && paras.isEmpty(), radial = s.radial, shadowDx = shDx(s), shadowDy = shDy(s), shadowBlur = (s.shBlur / EMU).toInt(), shadowAlpha = s.shAlpha, prst = s.prst))
                }
            }
        }
    }

    /** Eski giriş: tek slaytı kendi başına (yalnız slayt dosyası) okur. */
    fun slide(xml: ByteArray, e: Map<String, ByteArray>, path: String, notes: List<String>): RichPage? =
        Deck(e + (path to xml)).page(path, notes)
}
