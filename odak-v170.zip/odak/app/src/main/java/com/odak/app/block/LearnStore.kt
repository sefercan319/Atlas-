package com.odak.app.block

import android.content.Context
import com.odak.app.logic.LearnConf
import com.odak.app.logic.LearnPlus
import com.odak.app.logic.LearnTune
import com.odak.app.logic.LearnPure
import com.odak.app.logic.UserFeatPure
import java.io.File

/** Kural öğrenicinin cihazdaki verisi: örnekler (learn_examples.tsv) ve ağırlıklar (learn_w.txt). */
object LearnStore {
    private const val MAX = 5000
    private fun exF(c: Context) = File(c.filesDir, "learn_examples.tsv")
    private fun wF(c: Context) = File(c.filesDir, "learn_w.txt")
    private fun kF(c: Context) = File(c.filesDir, "learn_ckpt.txt")
    private fun bF(c: Context) = File(c.filesDir, "learn_boot.txt")
    private fun prefs(c: Context) = c.getSharedPreferences("odak_app", Context.MODE_PRIVATE)

    fun auto(c: Context) = prefs(c).getBoolean("learn_auto", true)
    fun setAuto(c: Context, v: Boolean) = prefs(c).edit().putBoolean("learn_auto", v).apply()

    @Synchronized fun examples(c: Context): List<LearnPure.Ex> =
        try { if (exF(c).exists()) exF(c).readLines().mapNotNull { LearnPure.decode(it) } else emptyList() } catch (e: Exception) { emptyList() }

    fun count(c: Context) = examples(c).size

    @Synchronized fun weights(c: Context): DoubleArray? =
        try { if (wF(c).exists()) LearnPure.decodeW(wF(c).readText()) else null } catch (e: Exception) { null }

    /** Kural kaydedilince: seçilenler olumlu, listede gösterilen diğerleri olumsuz örnek olur. */
    @Synchronized fun record(c: Context, cands: List<UserFeatPure.Cand>, picked: List<String>, featName: String) {
        if (picked.isEmpty() || cands.isEmpty()) return
        val sug = UserFeatPure.suggest(cands, featName).toSet()
        val add = cands.map { LearnPure.Ex(it.entry, it.ratio, it.inNeg, it.entry in sug, it.entry in picked, it.conflict) }
        val all = (examples(c) + add).takeLast(MAX)
        try { exF(c).writeText(all.joinToString("\n") { LearnPure.encode(it) }) } catch (e: Exception) { return }
        if (auto(c)) train(c, 20)
    }

    fun scope(c: Context) = prefs(c).getInt("learn_scope", 100)
    fun setScope(c: Context, v: Int) = prefs(c).edit().putInt("learn_scope", v).apply()
    fun rotate(c: Context) = prefs(c).getBoolean("learn_rotate", true)
    fun setRotate(c: Context, v: Boolean) = prefs(c).edit().putBoolean("learn_rotate", v).apply()
    fun round(c: Context) = prefs(c).getInt("learn_round", 0)

    fun bg(c: Context) = prefs(c).getBoolean("learn_bg", true)
    fun setBg(c: Context, v: Boolean) = prefs(c).edit().putBoolean("learn_bg", v).apply()
    fun trainedN(c: Context) = prefs(c).getInt("learn_trained_n", 0)
    fun lastTrainable(c: Context) = prefs(c).getInt("learn_trainable", LearnPure.DIM)
    fun threshold(c: Context) = prefs(c).getFloat("learn_thr", 0.7f).toDouble()
    fun lastF1(c: Context) = prefs(c).getInt("learn_f1", -1)
    fun lastCv(c: Context) = prefs(c).getInt("learn_cv", -1)

    /** Aynı uygulamanın DİĞER özelliklerinin kural girdileri: aday bunlardan biriyse başka özelliğe aittir (çatışma). */
    fun otherEntries(c: Context, app: String, feat: String): Set<String> = try {
        BlockStore.rules(c).filterKeys { it.startsWith("$app/") && it != "$app/$feat" }.values.flatten().toSet()
    } catch (e: Exception) { emptySet() }

    /** Adayın öğrenici puanı (%); yeterli örnek/ağırlık yoksa null. */
    fun score(c: Context, cand: UserFeatPure.Cand, featName: String, sug: Set<String>): Int? {
        val sc = scorer(c) ?: return null
        return (sc(cand, cand.entry in sug) * 100).toInt()
    }

    fun engine(c: Context) = prefs(c).getInt("learn_engine", LearnPure.ENG_BOTH)
    fun setEngine(c: Context, v: Int) = prefs(c).edit().putInt("learn_engine", v).apply()

    /** Seçili motora göre aday puanlayıcı (0..1); yeterli örnek/ağırlık yoksa null. Dosyalar bir kez okunur. */
    fun scorer(c: Context): ((UserFeatPure.Cand, Boolean) -> Double)? {
        val w = weights(c) ?: return null
        if (count(c) < LearnPure.MIN_EXAMPLES) return null
        val eng = engine(c)
        val cal = LearnPlus.Calib.decode(prefs(c).getString("learn_cal", null))
        return { cand, name ->
            val pb = cal.apply(LearnPure.score(w, cand, name))
            val x = LearnPure.features(cand.entry, cand.ratio, cand.inNeg, name, cand.conflict)
            if (eng == LearnPure.ENG_ONNX) LearnPure.blendOnnx(pb, ExtScorer.prob(c, x))
            else LearnPure.blend(eng, pb, if (eng == LearnPure.ENG_BUILTIN) null else SmileTrainer.prob(c, x))
        }
    }

    fun boots(c: Context): List<DoubleArray> = try { if (bF(c).exists()) LearnConf.decodeBoots(bF(c).readText()) else emptyList() } catch (e: Exception) { emptyList() }

    /** Çok katmanlı güven: olasılık + motor uyumu + torba kararlılığı + kanıt desteği. Yeterli örnek yoksa null. */
    fun confer(c: Context): ((UserFeatPure.Cand, Boolean) -> LearnConf.Conf)? {
        val sc = scorer(c) ?: return null
        val w = weights(c) ?: return null
        val bt = boots(c); val sup = LearnConf.Support(examples(c)); val eng = engine(c)
        val cal = LearnPlus.Calib.decode(prefs(c).getString("learn_cal", null))
        return { cand, name ->
            val x = LearnPure.features(cand.entry, cand.ratio, cand.inNeg, name, cand.conflict)
            val p = sc(cand, name)
            val other = if (eng == LearnPure.ENG_BUILTIN) null else if (eng == LearnPure.ENG_ONNX) ExtScorer.prob(c, x) else SmileTrainer.prob(c, x)?.let { cal.apply(LearnPure.score(w, cand, name)) }
            LearnConf.assess(p, bt, x, other, sup.count(cand.entry, x))
        }
    }

    fun lr(c: Context) = prefs(c).getFloat("learn_lr", 0.05f).toDouble()
    fun l2(c: Context) = prefs(c).getFloat("learn_l2", 0.001f).toDouble()
    fun rolledBack(c: Context) = prefs(c).getBoolean("learn_rolled", false)

    /** Çapraz doğrulamalı ızgara araması; en iyi öğrenme hızı/düzenlileştirme kaydedilir (Gelişmiş motor kullanır). */
    fun autoTune(c: Context): LearnTune.Tuned? = LearnTune.tune(examples(c))?.also {
        prefs(c).edit().putFloat("learn_lr", it.best.lr.toFloat()).putFloat("learn_l2", it.best.l2.toFloat()).apply()
    }
    fun curve(c: Context): List<Int>? = LearnTune.curve(examples(c))

    fun ckpts(c: Context): List<LearnTune.Ckpt> = try { if (kF(c).exists()) kF(c).readLines().mapNotNull { LearnTune.decode(it) } else emptyList() } catch (e: Exception) { emptyList() }
    private fun saveCkpts(c: Context, l: List<LearnTune.Ckpt>) { try { kF(c).writeText(l.joinToString("\n") { LearnTune.encode(it) }) } catch (e: Exception) { } }

    /** Son sürümü atıp bir önceki kontrol noktasını yükler; yoksa false. */
    @Synchronized fun rollback(c: Context): Boolean {
        val l = ckpts(c)
        if (l.size < 2) return false
        val prev = l[l.size - 2]
        try { wF(c).writeText(LearnPure.encodeW(prev.w)) } catch (e: Exception) { return false }
        saveCkpts(c, l.dropLast(1))
        prefs(c).edit().putInt("learn_f1", prev.f1).putBoolean("learn_rolled", false).apply()
        return true
    }

    fun lastEce(c: Context) = prefs(c).getInt("learn_ece", -1)
    fun lastVal(c: Context) = prefs(c).getInt("learn_val", -1)
    fun needsTrain(c: Context) = LearnPure.needsTrain(count(c), trainedN(c))

    /** Eğitir (kaldığı ağırlıktan sürer, doğrulamalı + erken durdurmalı); (örnek sayısı, doğrulama doğruluğu %, tur) döner. */
    @Synchronized fun train(c: Context, epochs: Int = 40, fresh: Boolean = false): Triple<Int, Int, Int> {
        val ex = examples(c)
        if (ex.isEmpty()) return Triple(0, 0, 0)
        // Kapsam: ağırlıkların %scope'u eğitilir; dönüşümlüyse her turda farklı küme (zamanla hepsi). fresh = komple baştan.
        val mask = LearnPure.mask(if (fresh) 100 else scope(c), if (rotate(c)) round(c) else 0)
        val adv = engine(c) == LearnPure.ENG_ADV
        val f = if (adv) {
            // Gelişmiş: yeni örnekler daha ağırlıklı + Adam; her turda 20+ örnekte doğrulama bölmesiyle erken durdurma
            val wex = LearnPlus.weighted(ex)
            var w = if (fresh) null else weights(c)
            val sp = if (wex.size >= 25) LearnPure.split(wex) else Pair(wex, emptyList())
            var best = w; var bestLoss = Double.MAX_VALUE; var stale = 0; var done = 0
            for (ep in 0 until maxOf(epochs, 20)) {
                w = LearnPlus.trainAdam(sp.first, 1, w, ep + round(c), mask, l2(c), lr(c))
                done = ep + 1
                if (sp.second.isEmpty()) { best = w; continue }
                val l = sp.second.sumOf { val p = LearnPure.predict(w!!, it).coerceIn(1e-6, 1 - 1e-6); -(if (it.label) Math.log(p) else Math.log(1 - p)) } / sp.second.size
                if (l < bestLoss - 1e-4) { bestLoss = l; best = w!!.copyOf(); stale = 0 } else if (++stale >= 6) break
            }
            val bw = best ?: DoubleArray(LearnPure.DIM)
            val va = if (sp.second.isEmpty()) sp.first else sp.second
            LearnPure.Fit(bw, LearnPure.accuracy(bw, sp.first), LearnPure.accuracy(bw, va), done, sp.second.size)
        } else LearnPure.fit(ex, epochs, if (fresh) null else weights(c), mask = mask)
        val cal = if (adv) LearnPlus.calibrate(f.w, LearnPure.split(ex).second.ifEmpty { ex }) else LearnPlus.Calib.NONE
        prefs(c).edit().putString("learn_cal", cal.encode()).putInt("learn_ece", LearnPlus.ece(f.w, ex, cal)).apply()
        val thr = LearnPure.bestThreshold(f.w, ex)
        val m = LearnPure.metrics(f.w, ex, thr)
        val cv = if (ex.size <= 2000) LearnPure.crossVal(ex, 5, 30) else null
        prefs(c).edit().putInt("learn_round", round(c) + 1).putInt("learn_trainable", LearnPure.trainable(mask))
            .putFloat("learn_thr", thr.toFloat()).putInt("learn_f1", m.f1).putInt("learn_cv", cv?.f1 ?: -1).apply()
        // Sürüm kontrolü: yeni eğitim son sürümden belirgin kötüyse eskisi korunur (komple baştan eğitimde sınır yok)
        val last = ckpts(c).lastOrNull()
        val roll = !fresh && LearnTune.rollbackNeeded(m.f1, last)
        prefs(c).edit().putBoolean("learn_rolled", roll).apply()
        if (!roll) {
            try { wF(c).writeText(LearnPure.encodeW(f.w)) } catch (e: Exception) { }
            saveCkpts(c, LearnTune.push(ckpts(c), LearnTune.Ckpt(System.currentTimeMillis(), m.f1, f.w)))
        }
        if (engine(c) != LearnPure.ENG_BUILTIN) SmileTrainer.fit(c, ex)
        // İçe aktarılan TFLite modeli eğitilebilirse (train imzası) örneklerle cihazda da eğitilir
        if (engine(c) == LearnPure.ENG_ONNX && ExtScorer.kind(c) == "tflite" && ex.size <= 2500) TfliteRunner.train(c, ex, 3)
        // Torbalama: güven (kararlılık) için K yeniden örneklenmiş kopya; çok büyük veride atlanır
        try { if (ex.size <= 2500) bF(c).writeText(LearnConf.encodeBoots(LearnConf.bootstrap(ex))) } catch (e: Exception) { }
        prefs(c).edit().putInt("learn_trained_n", ex.size).putInt("learn_val", f.valAcc).apply()
        return Triple(ex.size, f.valAcc, f.epochs)
    }

    fun pick(c: Context, cands: List<UserFeatPure.Cand>, featName: String): List<String> =
        confer(c).let { cf ->
            val sug = UserFeatPure.suggest(cands, featName).toSet()
            // Otomatik seçim yalnız 🟢 (yüksek güven) adaylarda
            if (cf == null) emptyList() else LearnPure.pickBy(count(c), cands, threshold(c)) { val k = cf(it, it.entry in sug); if (k.level == LearnConf.HIGH) k.p else 0.0 }
        }

    /** İlk satır eğitim planı ("_plan": kapsam %, dönüşüm, tur), sonra örnekler: bilgisayarda aynı kapsamla eğitmek için. */
    fun export(c: Context): String =
        "{\"_plan\":{\"scope_pct\":${scope(c)},\"rotate\":${rotate(c)},\"round\":${round(c)},\"base_params\":${com.odak.app.logic.ModelPure.MODEL_PARAMS}}}\n" + LearnPure.toJsonl(examples(c))
}
