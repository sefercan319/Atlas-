package com.odak.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import com.odak.app.theme.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.core.view.WindowCompat
import com.odak.app.block.BlockScreen
import com.odak.app.block.ScreenTimeScreen
import com.odak.app.plan.PlanScreen
import com.odak.app.settings.GuideScreen
import com.odak.app.settings.SettingsScreen
import com.odak.app.todo.TodoScreen
import com.odak.app.theme.readableOn
import com.odak.app.theme.ClickSound
import com.odak.app.theme.ColorPrefs
import androidx.compose.ui.graphics.toArgb
import com.odak.app.theme.Design
import com.odak.app.theme.DesignStyle
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.ThemePrefs
import com.odak.app.theme.modeInvert
import com.odak.app.theme.ThemedBackground
import com.odak.app.theme.ThemedNavBar
import com.odak.app.theme.pageTransition
import com.odak.app.theme.tokensFor
import com.odak.app.theme.typographyFor

/** Uygulama ön plana her gelişinde artar; kilit süresi dolduysa şifre yeniden istenir. */
object LockSignal {
    var tick by mutableIntStateOf(0)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReport.resetAppearanceIfLooping(applicationContext) // art arda çökme: görünüm ayarları varsayılana
        enableEdgeToEdge()
        ClickSound.init(applicationContext)
        ColorPrefs.init(applicationContext)
        com.odak.app.theme.UiScale.init(applicationContext)
        ClickSound.enabled = getSharedPreferences("odak_app", MODE_PRIVATE).getBoolean("sound", true)
        ClickSound.haptic = getSharedPreferences("odak_app", MODE_PRIVATE).getBoolean("haptic", true)
        Thread {
            com.odak.app.logic.SafeCall.orNull {
                com.odak.app.block.BlockStore.pruneOld(applicationContext)
                com.odak.app.block.SyncRunner.autoIfDue(applicationContext)
                com.odak.app.notify.Reminders.rescheduleAll(applicationContext)
                com.odak.app.block.LearnJobService.sync(applicationContext)
            }
        }.start()
        setContent {
            OdakApp()
        }
    }

    override fun onStart() {
        super.onStart()
        LockSignal.tick++
    }

    override fun onResume() {
        super.onResume()
        com.odak.app.block.Pin.applySecure(this)
        com.odak.app.settings.KeepAwake.apply(this)
    }
}

@Composable
fun OdakApp() {
    val context = LocalContext.current
    var crash by remember { mutableStateOf(CrashReport.read(context)) }
    crash?.let { rep ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { CrashReport.clear(context); crash = null },
            text = { androidx.compose.material3.Text(stringResource(R.string.crash_msg)) },
            confirmButton = {
                androidx.compose.material3.TextButton({
                    val send = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain").putExtra(android.content.Intent.EXTRA_TEXT, rep)
                    com.odak.app.Launch.go(context, android.content.Intent.createChooser(send, null).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                    CrashReport.clear(context); crash = null
                }) { androidx.compose.material3.Text(stringResource(R.string.learn_share)) }
            },
            dismissButton = { androidx.compose.material3.TextButton({ CrashReport.clear(context); crash = null }) { androidx.compose.material3.Text("✕") } }
        )
    }
    var style by remember { mutableStateOf(ThemePrefs.load(context)) }
    var mode by remember { mutableStateOf(com.odak.app.theme.ThemeMode.load(context)) }
    val inv = com.odak.app.theme.ThemeMode.shouldInvert(style, mode)
    var fscale by remember {
        mutableStateOf(
            context.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE).getFloat("fscale", 1f)
        )
    }
    var guide by remember {
        mutableStateOf(
            !context.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE)
                .getBoolean("guide_seen", false)
        )
    }
    val navPrefs = remember { context.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE) }
    var selected by rememberSaveable { mutableStateOf(com.odak.app.settings.NavMemory.restore(navPrefs.getInt(com.odak.app.settings.NavMemory.KEY, 0), 5)) }
    LaunchedEffect(selected) { navPrefs.edit().putInt(com.odak.app.settings.NavMemory.KEY, selected).apply() }
    // Not editörü açıkken alt çubuk gizlenir (tam ekran yazma alanı).
    var hideBar by remember { mutableStateOf(false) }
    // Uygulama kilidi: şifre açıksa ve "Tüm uygulama" seçiliyse, süre dolunca (ya da arka plandan dönünce) yeniden sorulur.
    var appLocked by remember { mutableStateOf(com.odak.app.block.Pin.needs(context, com.odak.app.logic.LockPolicy.APP)) }
    val startTick = LockSignal.tick
    LaunchedEffect(startTick) {
        if (com.odak.app.block.Pin.needs(context, com.odak.app.logic.LockPolicy.APP)) appLocked = true
    }

    val tabRes = listOf(
        R.string.tab_plan,
        R.string.tab_todo_s,
        R.string.tab_block,
        R.string.notes_title,
        R.string.tab_more
    )
    val labels = tabRes.map { stringResource(it) }

    val tokens = tokensFor(style)
    val colors = lightColorScheme(
        primary = tokens.primary,
        secondary = tokens.accent,
        background = tokens.background,
        surface = tokens.surface,
        onPrimary = tokens.surface.readableOn(tokens.primary),
        onBackground = tokens.text,
        onSurface = tokens.text
    )

    val view = LocalView.current
    SideEffect {
        val window = (view.context as Activity).window
        val controller = WindowCompat.getInsetsController(window, view)
        val light = (style == DesignStyle.FRUTIGER_AERO ||
            style == DesignStyle.MINIMAL ||
            style == DesignStyle.WINDOWS11 ||
            style == DesignStyle.SKEUOMORPHISM ||
            style == DesignStyle.NEUMORPHISM ||
            style == DesignStyle.Y2K ||
            style == DesignStyle.CLAYMORPHISM ||
            style == DesignStyle.NEOCLASSICAL).let { l -> ColorPrefs.backgroundOf(style)?.let { com.odak.app.theme.Contrast.luminance(it.toArgb()) >= 0.35 } ?: l } != inv
        controller.isAppearanceLightStatusBars = light
        controller.isAppearanceLightNavigationBars = light
    }

    val dens = LocalDensity.current
    com.odak.app.theme.ProvideUiScale {
    CompositionLocalProvider(
        LocalDesign provides Design(style),
        com.odak.app.theme.LocalInverted provides inv,
        LocalDensity provides Density(LocalDensity.current.density, dens.fontScale * fscale)
    ) {
        MaterialTheme(colorScheme = colors, typography = typographyFor(style)) {
            if (appLocked) ThemedBackground(Modifier.fillMaxSize().modeInvert(inv)) {
                com.odak.app.block.PinGate(stringResource(R.string.pin_title)) { appLocked = false }
            } else if (guide) ThemedBackground(Modifier.fillMaxSize().modeInvert(inv)) {
                GuideScreen {
                    context.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE)
                        .edit().putBoolean("guide_seen", true).apply()
                    guide = false
                }
            } else ThemedBackground(Modifier.fillMaxSize().modeInvert(inv)) {
                val land = com.odak.app.theme.rememberLandscape()
                Scaffold(
                    containerColor = Color.Transparent,
                    bottomBar = {
                        if (!land && !hideBar) ThemedNavBar(
                            labels = labels,
                            icons = listOf("📅", "☑", "⛔", "📝", "☰"),
                            selected = selected,
                            onSelect = { selected = it; hideBar = false }
                        )
                    }
                ) { padding ->
                    Row(Modifier.fillMaxSize().padding(padding)) {
                    if (land && !hideBar) com.odak.app.theme.ThemedSideRail(
                        labels = labels,
                        icons = listOf("📅", "☑", "⛔", "📝", "☰"),
                        selected = selected,
                        onSelect = { selected = it }
                    )
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        AnimatedContent(
                            targetState = selected,
                            transitionSpec = { pageTransition(style) },
                            label = "page"
                        ) { page ->
                            val narrow = land && (page in 1..4)
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                            Box(
                                if (narrow) Modifier.widthIn(max = com.odak.app.logic.Pure.contentMaxDp(androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp).dp).fillMaxSize()
                                else Modifier.fillMaxSize()
                            ) {
                            when (page) {
                                0 -> PlanScreen()
                                1 -> TodoScreen()
                                2 -> BlockScreen()
                                3 -> com.odak.app.notes.NotesHub(embedded = true, onEditorChange = { hideBar = it })
                                4 -> com.odak.app.block.LockGate(com.odak.app.logic.LockPolicy.SETTINGS, stringResource(R.string.pin_title)) { com.odak.app.settings.MoreScreen(
                                    screenTime = { ScreenTimeScreen() },
                                    settings = {
                                        SettingsScreen(style, fscale, mode, {
                                            mode = it
                                            com.odak.app.theme.ThemeMode.save(context, it)
                                        }, {
                                            fscale = it
                                            context.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE)
                                                .edit().putFloat("fscale", it).apply()
                                        }) { chosen ->
                                            style = chosen
                                            ThemePrefs.save(context, chosen)
                                        }
                                    }
                                ) }
                                else -> Box(
                                    Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(labels.getOrElse(page) { "" })
                                }
                            }
                            }
                            }
                        }
                    }
                    }
                }
            }
        }
    }
    }
}
