package com.odak.app.logic

import java.util.Locale

/** Model indirme ve görsel sınırı yardımcıları (Android'e bağlı değil). */
object ModelPure {
    const val PHOTO_MAX = 70L * 1024 * 1024
    const val PAGE = "https://huggingface.co/google/functiongemma-270m-it"

    /** Yalnız https ve makul uzunlukta adres. */
    fun urlOk(u: String): Boolean {
        val t = u.trim()
        if (t.length > 2000 || !t.lowercase(Locale.ROOT).startsWith("https://")) return false
        val host = t.substring(8).substringBefore('/').substringBefore('?').substringBefore('#')
        return host.length >= 3 && host.contains('.') && t.none { it.isWhitespace() }
    }

    fun host(u: String): String = u.trim().substring(minOf(8, u.trim().length)).substringBefore('/').substringBefore('?').substringBefore('#').substringBefore(':').lowercase(Locale.ROOT)

    /** Adresten güvenli dosya adı. */
    fun fileName(u: String): String {
        val n = u.trim().substringBefore('?').substringBefore('#').substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
        return if (n.length < 3 || !n.contains('.')) "model.bin" else n
    }

    fun percent(done: Long, total: Long): Int = if (total <= 0) 0 else (done * 100 / total).toInt().coerceIn(0, 100)

    fun fmtSize(b: Long): String = when {
        b >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024 * 1024))
        b >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024))
        b >= 1L shl 10 -> (b shr 10).toString() + " KB"
        else -> "$b B"
    }

    /** Anahtar yalnızca ilk adrese gider; yönlendirmedeki başka sunucuya (CDN) gönderilmez. */
    fun sendAuth(origHost: String, hopHost: String, token: String): Boolean = token.isNotBlank() && origHost.equals(hopHost, true)

    /** Yönlendirme yalnızca https'e izinli. */
    fun redirectOk(loc: String?): Boolean = loc != null && loc.lowercase(Locale.ROOT).startsWith("https://")

    fun enoughSpace(usable: Long, need: Long): Boolean = usable > need + 100L * 1024 * 1024

    /** İndirilecek temel modelin (FunctionGemma 270M) parametre sayısı. */
    const val MODEL_PARAMS = 270_000_000L
    val SCOPES = listOf(2, 5, 10, 25, 50, 100)

    fun trainableParams(total: Long, pct: Int): Long = total * pct.coerceIn(0, 100) / 100

    /**
     * Büyük modeli eğitmek için yaklaşık bellek: eğitilen parametre başına 16 bayt (fp32 ağırlık + gradyan + Adam m,v),
     * dondurulan başına 2 bayt (fp16). Etkinleştirme belleği hariç; gerçek ihtiyaç daha yüksektir.
     */
    fun trainMemBytes(total: Long, pct: Int): Long {
        val t = trainableParams(total, pct)
        return t * 16 + (total - t) * 2
    }

    /** Telefonun RAM'inin en çok %40'ı eğitime ayrılabilir kabul edilir. */
    fun feasibleOnPhone(total: Long, pct: Int, ramBytes: Long): Boolean = ramBytes > 0 && trainMemBytes(total, pct) <= ramBytes * 4 / 10

    /** Uygun olan en büyük oran (yoksa 0): telefonda neyin yapılabildiğini gösterir. */
    fun maxFeasiblePct(total: Long, ramBytes: Long): Int = SCOPES.filter { feasibleOnPhone(total, it, ramBytes) }.maxOrNull() ?: 0

    // LiteRT-LM (açık kaynak, Google) çalışma zamanı: .litertlm dosyaları
    const val RUNTIME_DEP = "com.google.ai.edge.litertlm:litertlm-android"
    fun runnable(fileName: String) = fileName.lowercase().endsWith(".litertlm")
    fun probePrompt(feature: String, app: String, entries: List<String>): String =
        "Uygulama: $app\nÖzellik: $feature\nAdaylar:\n" + entries.take(12).mapIndexed { i, e -> "${i + 1}. $e" }.joinToString("\n") +
            "\nBu özelliği en iyi hangi adaylar tanımlar? Yalnız numaraları virgülle yaz."
    fun parsePicks(reply: String, n: Int): List<Int> =
        Regex("\\d+").findAll(reply).mapNotNull { it.value.toIntOrNull() }.filter { it in 1..n }.distinct().map { it - 1 }.take(3).toList()

    fun onnx(fileName: String) = fileName.lowercase().endsWith(".onnx")

    /** ONNX sınıflandırıcı çıktısından olumlu olasılık: [p0,p1] (toplam≈1 değilse softmax), [p] (aralık dışıysa sigmoid), diğerleri null. */
    fun pickProbability(out: FloatArray): Double? = when {
        out.size == 2 -> { val a = out[0].toDouble(); val b = out[1].toDouble()
            if (a in 0.0..1.0 && b in 0.0..1.0 && Math.abs(a + b - 1.0) < 0.02) b else { val m = maxOf(a, b); val ea = Math.exp(a - m); val eb = Math.exp(b - m); eb / (ea + eb) } }
        out.size == 1 -> out[0].toDouble().let { if (it in 0.0..1.0) it else 1.0 / (1.0 + Math.exp(-it.coerceIn(-30.0, 30.0))) }
        else -> null
    }

    /** Harici sınıflandırıcı çalışma zamanları: dosya uzantısına göre. */
    val EXT_KINDS = mapOf(".onnx" to "onnx", ".tflite" to "tflite", ".ptl" to "torch", ".pte" to "executorch")
    fun kind(fileName: String): String? = EXT_KINDS.entries.firstOrNull { fileName.lowercase().endsWith(it.key) }?.value

    /** Sınıflandırıcıya girdi için one-hot etiket ([olumsuz, olumlu]). */
    fun oneHot(label: Boolean): FloatArray = if (label) floatArrayOf(0f, 1f) else floatArrayOf(1f, 0f)

    /** Eğitim yığınları: örnek sırası sabit, son yığın kısa olabilir. */
    fun batches(n: Int, size: Int): List<IntRange> = if (n <= 0 || size <= 0) emptyList() else (0 until n step size).map { it until minOf(n, it + size) }
}
