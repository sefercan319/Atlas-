package com.odak.app.block

import android.content.Context
import android.content.ContextWrapper
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal

/** Telefonda kayıtlı parmak izi / yüz ile doğrulama (platform BiometricPrompt, ek bağımlılık yok). */
object Bio {
    private const val AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK

    fun findActivity(c: Context?): android.app.Activity? {
        var x = c
        while (x is ContextWrapper) { if (x is android.app.Activity) return x; x = x.baseContext }
        return null
    }

    /** Cihazda en az bir parmak izi/yüz kayıtlı mı. */
    fun available(c: Context): Boolean = try {
        val m = c.getSystemService(BiometricManager::class.java)
        m != null && m.canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS
    } catch (e: Exception) { false }

    private var current: CancellationSignal? = null

    private fun fresh(): CancellationSignal { cancel(); return CancellationSignal().also { current = it } }

    /** Açık doğrulama penceresi varsa kapatır (ekran kapanınca/ayrılınca sızmasın). */
    fun cancel() { try { current?.cancel() } catch (e: Exception) { }; current = null }

    /** Başarılıysa [onOk]; iptal/hata sessizce şifreye düşer. */
    fun prompt(c: Context, title: String, cancel: String, onOk: () -> Unit) {
        val a = findActivity(c) ?: return
        try {
            val cb = object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) { onOk() }
            }
            BiometricPrompt.Builder(a)
                .setTitle(title)
                .setAllowedAuthenticators(AUTH)
                .setNegativeButton(cancel, a.mainExecutor) { _, _ -> }
                .build()
                .authenticate(fresh(), a.mainExecutor, cb)
        } catch (e: Exception) { }
    }

    /** Şifre sıfırlama: telefonun kendi kilidi (parmak izi, yüz, telefon PIN/deseni) ile doğrular. */
    fun promptReset(c: Context, title: String, onOk: () -> Unit) {
        val a = findActivity(c) ?: return
        try {
            val cb = object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) { onOk() }
            }
            BiometricPrompt.Builder(a)
                .setTitle(title)
                .setAllowedAuthenticators(RESET_AUTH)
                .build()
                .authenticate(fresh(), a.mainExecutor, cb)
        } catch (e: Exception) { }
    }

    /** Telefonda herhangi bir ekran kilidi/biyometrik var mı (sıfırlama için). */
    fun resetAvailable(c: Context): Boolean = try {
        val m = c.getSystemService(BiometricManager::class.java)
        m != null && m.canAuthenticate(RESET_AUTH) == BiometricManager.BIOMETRIC_SUCCESS
    } catch (e: Exception) { false }

    private const val RESET_AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
}
