package com.odak.app.logic

import java.util.Locale

/**
 * Kullanıcının kendi tanımladığı özellikler (ör. bilinmeyen bir uygulamada "Keşfet") ve elle kural girişi.
 * Android'e bağlı değil; birim testlerle doğrulanır.
 */
object UserFeatPure {
    class UF(val app: String, val id: String, val name: String)

    const val MAX_NAME = 28
    const val MAX_RULES = 24

    /** Kimlik: "u:" + ada bağlı kısa slug; aynı ad aynı kimliği verir. */
    fun id(name: String): String {
        val s = name.trim().lowercase(Locale.ROOT)
            .map { if (it.isLetterOrDigit()) it else '_' }.joinToString("")
            .replace(Regex("_+"), "_").trim('_').take(24)
        return "u:" + s.ifEmpty { "f" + Math.abs(name.hashCode()) }
    }

    fun cleanName(raw: String): String = raw.replace(Regex("[\\r\\n\\t|]+"), " ").trim().take(MAX_NAME)

    fun serialize(list: List<UF>): String = list.joinToString("\n") { it.app + "\t" + it.id + "\t" + it.name }

    fun parse(s: String): List<UF> = s.lines().mapNotNull {
        val p = it.split('\t')
        if (p.size >= 3 && p[0].isNotBlank() && p[1].startsWith("u:") && p[2].isNotBlank()) UF(p[0], p[1], p[2]) else null
    }.distinctBy { it.app + "/" + it.id }

    /** Aynı uygulamada aynı adı iki kez eklemeyi engeller. */
    fun exists(list: List<UF>, app: String, name: String): Boolean {
        val id = id(name)
        return list.any { it.app == app && it.id == id }
    }

    /** Hazır şablonlar: "seçili sekme" (sel:) ağırlıklı, çok dilli. Kullanıcı sonra laboratuvarla inceltebilir. */
    val TEMPLATES: Map<String, List<String>> = linkedMapOf(
        "short" to listOf("sel:reels", "sel:shorts", "sel:clips", "sel:kısa video", "sel:short video", "sel:videos", "sel:kurzvideos", "desc:reels", "desc:shorts"),
        "stories" to listOf("sel:stories", "sel:story", "sel:hikâyeler", "sel:hikayeler", "sel:geschichten", "sel:historias", "sel:истории", "desc:story"),
        "live" to listOf("sel:live", "sel:canlı", "sel:direct", "sel:en vivo", "sel:прямой", "desc:live now", "text:live now"),
        "msg" to listOf("sel:messages", "sel:mesajlar", "sel:chats", "sel:sohbetler", "sel:inbox", "sel:nachrichten", "sel:mensajes", "sel:сообщения"),
        "explore" to listOf("sel:explore", "sel:keşfet", "sel:discover", "sel:search", "sel:ara", "sel:entdecken", "sel:explorar", "sel:обзор"),
        "shop" to listOf("sel:shop", "sel:shopping", "sel:mağaza", "sel:alışveriş", "sel:marketplace", "sel:store", "sel:tienda", "sel:boutique"),
        "comments" to listOf("desc:comments", "text:comments", "text:yorumlar", "desc:yorumlar", "text:kommentare", "text:comentarios", "text:комментарии"),
        "feed" to listOf("sel:home", "sel:ana sayfa", "sel:feed", "sel:startseite", "sel:inicio", "sel:accueil", "sel:главная"),
        "games" to listOf("sel:games", "sel:oyunlar", "sel:play", "sel:spiele", "sel:juegos", "sel:jeux", "sel:игры")
    )

    fun templateRules(key: String): List<String> = TEMPLATES[key] ?: emptyList()

    /** Elle girilen kural: tür (id/text/desc/sel) + değer → kural girdisi; geçersizse null. Kimlik büyük/küçük harfe duyarlı, diğerleri küçük harfe çevrilir. */
    fun manualEntry(type: String, value: String): String? {
        val v = value.trim()
        if (v.length < 2 || v.length > 60 || v.any { it == '\n' || it == '\r' }) return null
        return when (type) {
            "id" -> if (v.contains(' ') || v.contains(':')) null else v
            "text", "desc", "sel" -> "$type:" + v.lowercase(Locale.ROOT)
            else -> null
        }
    }

    /** Eski + yeni kural girdileri: tekrarsız, en çok [MAX_RULES]; eskiler kaybolmaz. */
    fun merge(old: List<String>, add: List<String>): List<String> = (old + add).filter { it.isNotBlank() }.distinct().take(MAX_RULES)

    class Cand(val entry: String, val inNeg: Boolean, val ratio: Double = 0.0, val conflict: Boolean = false)

    /**
     * Kayıtta görülen (tarama sayısının en az yarısında) tüm kural adayları; "dışarıda da görüldü" olanlar işaretli ve sonda.
     * Anahtarlar önekli gelir: düz kimlik, "sel:", "desc:", "text:". Tek kayıt (olumsuz kayıt olmadan) da yeter.
     */
    fun candidates(pos: Map<String, Int>, scans: Int, neg: Set<String>, max: Int = 40, conflicts: Set<String> = emptySet()): List<Cand> {
        if (scans <= 0) return emptyList()
        fun body(e: String) = e.substringAfter(':', e)
        return pos.entries
            .filter { it.value * 2 >= scans }
            .filter { val b = body(it.key); b.length in 3..40 && (!it.key.contains(':') || b.any { c -> c.isLetter() }) }
            .map { e -> Cand(e.key, neg.any { n -> n == e.key || (body(n).isNotEmpty() && body(n) == body(e.key)) }, e.value.toDouble() / scans, e.key in conflicts) to e.value }
            .sortedWith(compareBy<Pair<Cand, Int>> { it.first.inNeg || it.first.conflict }.thenByDescending { it.second }.thenBy { it.first.entry })
            .take(max).map { it.first }
    }

    /**
     * Özellik adına göre otomatik seçim: adayın değeri ada eşitse/içeriyorsa ya da adı içeren bir şablonun eşanlamlısıysa seçilir
     * (ör. "Keşfet" → sel:keşfet, sel:explore). Kayıt dışında da görülenler (inNeg) seçilmez.
     */
    fun suggest(cands: List<Cand>, featName: String): List<String> {
        val n = featName.trim().lowercase(Locale.ROOT)
        if (n.length < 3) return emptyList()
        val words = HashSet<String>().apply {
            add(n)
            for (rules in TEMPLATES.values) {
                val bodies = rules.map { it.substringAfter(':') }
                if (bodies.any { it == n || (it.length >= 4 && (n.contains(it) || it.contains(n))) }) addAll(bodies)
            }
        }
        return cands.filter { !it.inNeg }.map { it.entry }.filter { e ->
            val b = e.substringAfter(':', e).lowercase(Locale.ROOT)
            words.any { w -> b == w || (w.length >= 4 && b.contains(w)) }
        }.take(4)
    }
}
