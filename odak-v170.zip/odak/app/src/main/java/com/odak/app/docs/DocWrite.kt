package com.odak.app.docs

import java.io.ByteArrayOutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Dönüştürme hedefleri. PDF ve PNG_ZIP Android tarafında (DocPdf) üretilir; diğerleri bu dosyada saf Kotlin ile. */
enum class ConvTarget(val ext: String, val mime: String) {
    TXT("txt", "text/plain"),
    MD("md", "text/markdown"),
    HTML("html", "text/html"),
    CSV("csv", "text/csv"),
    RTF("rtf", "application/rtf"),
    DOCX("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    XLSX("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    PPTX("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    ODT("odt", "application/vnd.oasis.opendocument.text"),
    ODS("ods", "application/vnd.oasis.opendocument.spreadsheet"),
    ODP("odp", "application/vnd.oasis.opendocument.presentation"),
    PDF("pdf", "application/pdf"),
    /** Yalnızca PDF kaynağı için: her sayfa bir PNG, hepsi zip içinde. */
    EPUB("epub", "application/epub+zip"),
    FB2("fb2", "application/x-fictionbook+xml"),
    PNG_ZIP("zip", "application/zip"),
    /** Yalnızca resim dosyaları için: tek PNG. */
    PNG("png", "image/png")
}

/** Dönüştürme planlama yardımcıları (Android'e bağımlı değil). */
object DocConvert {
    private val sameAs = mapOf(
        DocKind.DOCX to ConvTarget.DOCX, DocKind.XLSX to ConvTarget.XLSX, DocKind.PPTX to ConvTarget.PPTX,
        DocKind.ODT to ConvTarget.ODT, DocKind.ODS to ConvTarget.ODS, DocKind.ODP to ConvTarget.ODP, DocKind.RTF to ConvTarget.RTF,
        DocKind.CSV to ConvTarget.CSV, DocKind.MARKDOWN to ConvTarget.MD, DocKind.EPUB to ConvTarget.EPUB, DocKind.FB2 to ConvTarget.FB2
    )

    /**
     * Kaynak türüne göre seçilebilir hedefler. PDF'den metin çıkarılamaz (yalnızca sayfa resimleri); Google/çözülemeyen
     * dosyalarda hedef yoktur. Boş belge (hiç sayfa yok) de dönüştürülemez; PDF bunun dışındadır.
     */
    /** Resim dosyaları: metin/tablo biçimleri anlamsız; sayfa ve slayt biçimleri anlamlı. */
    val IMAGE_TARGETS = listOf(ConvTarget.PNG, ConvTarget.PDF, ConvTarget.DOCX, ConvTarget.ODT, ConvTarget.RTF, ConvTarget.HTML, ConvTarget.EPUB, ConvTarget.PPTX, ConvTarget.ODP)

    fun targetsFor(kind: DocKind, hasContent: Boolean): List<ConvTarget> {
        if (kind == DocKind.PDF) return ConvTarget.values().filter { it != ConvTarget.PDF && it != ConvTarget.PNG }
        if (kind == DocKind.GOOGLE || kind == DocKind.OPAQUE || kind == DocKind.UNKNOWN || !hasContent) return emptyList()
        if (kind == DocKind.IMAGE) return IMAGE_TARGETS
        return ConvTarget.values().filter { it != ConvTarget.PNG_ZIP && it != ConvTarget.PNG && it != sameAs[kind] }
    }

    /** Kaynak adından çıktı adı: uzantıyı değiştirir, tehlikeli karakterleri temizler. */
    fun outName(src: String, t: ConvTarget): String {
        val base = src.substringBeforeLast('.', src).replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().trim('.').take(80)
        return (if (base.isEmpty()) "belge" else base) + "." + t.ext
    }

    /** XML 1.0'da geçersiz karakterleri atar ve & < > " karakterlerini kaçırır. */
    fun xml(s: String): String {
        val sb = StringBuilder(s.length + 8)
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch == '\t' || ch == '\n' || ch == '\r' -> sb.append(ch)
                ch.code < 0x20 -> {}
                Character.isHighSurrogate(ch) -> if (i + 1 < s.length && Character.isLowSurrogate(s[i + 1])) { sb.append(ch).append(s[i + 1]); i++ }
                Character.isLowSurrogate(ch) -> {}
                ch.code == 0xFFFE || ch.code == 0xFFFF -> {}
                else -> sb.append(ch)
            }
            i++
        }
        return sb.toString()
    }

    /** Excel sayfa adı: [ ] : * ? / \ yok, en çok 31 karakter, boş değil, tekrar yok (büyük/küçük harfe duyarsız). */
    fun sheetName(title: String, index: Int, used: Set<String>): String {
        var base = title.replace(Regex("[\\[\\]:*?/\\\\]"), " ").trim().trim('\'').take(31)
        if (base.isEmpty()) base = "Sayfa$index"
        var n = base; var k = 2
        while (used.any { it.equals(n, ignoreCase = true) }) { val suf = " ($k)"; n = base.take(31 - suf.length) + suf; k++ }
        return n
    }

    /** Düz sayı mı (başında gereksiz sıfır yok, 15 haneye kadar)? XLSX/ODS'de sayısal hücre olarak yazılır. */
    fun isPlainNumber(s: String): Boolean = Regex("-?(0|[1-9][0-9]{0,14})(\\.[0-9]{1,10})?").matches(s)

    fun colName(i: Int): String { var n = i + 1; val sb = StringBuilder(); while (n > 0) { val r = (n - 1) % 26; sb.insert(0, ('A' + r)); n = (n - 1) / 26 }; return sb.toString() }

    fun csvCell(s: String): String {
        val t = s.replace("\r\n", "\n").replace('\r', '\n')
        return if (t.any { it == ',' || it == '"' || it == '\n' } || t.startsWith(" ") || t.endsWith(" ")) "\"" + t.replace("\"", "\"\"") + "\"" else t
    }

    fun rtf(s: String): String {
        val sb = StringBuilder()
        for (ch in s) when {
            ch == '\\' -> sb.append("\\\\")
            ch == '{' -> sb.append("\\{")
            ch == '}' -> sb.append("\\}")
            ch == '\n' -> sb.append("\\line ")
            ch == '\r' -> {}
            ch == '\t' -> sb.append("\\tab ")
            ch.code < 0x20 -> {}
            ch.code < 0x80 -> sb.append(ch)
            else -> sb.append("\\u").append(ch.code.toShort().toInt()).append('?')
        }
        return sb.toString()
    }

    /**
     * Metni en çok maxW genişliğe sığacak satırlara böler (PDF için). measure: bir dizgenin genişliği.
     * Satır sonları korunur; sığmayan uzun sözcük karakter karakter bölünür. Boş metin tek boş satır verir.
     */
    fun wrap(text: String, maxW: Float, measure: (String) -> Float): List<String> {
        val out = ArrayList<String>()
        for (raw in text.replace("\r\n", "\n").replace('\r', '\n').split('\n')) {
            if (raw.isBlank()) { out.add(""); continue }
            var cur = StringBuilder()
            for (word in raw.split(' ')) {
                val cand = if (cur.isEmpty()) word else "$cur $word"
                if (measure(cand) <= maxW) { cur = StringBuilder(cand); continue }
                if (cur.isNotEmpty()) { out.add(cur.toString()); cur = StringBuilder() }
                if (measure(word) <= maxW) { cur.append(word); continue }
                var piece = StringBuilder()
                for (ch in word) {
                    if (piece.isNotEmpty() && measure(piece.toString() + ch) > maxW) { out.add(piece.toString()); piece = StringBuilder() }
                    piece.append(ch)
                }
                cur = piece
            }
            out.add(cur.toString())
        }
        return out
    }

    fun mdCell(s: String): String = s.replace("\r", " ").replace("\n", " ").replace("|", "\\|")

    /** Sayfanın başlığı gösterilsin mi: çok sayfalı belgede ya da tablo sayfasında. */
    fun showTitle(doc: Doc, p: DocPage): Boolean = p.title.isNotBlank() && (doc.pages.size > 1 || p.table != null)

    /** Tablo satırlarını en geniş satıra göre doldurur (en çok 60 sütun). */
    fun padRows(rows: List<List<String>>): List<List<String>> {
        val w = (rows.maxOfOrNull { it.size } ?: 0).coerceAtMost(60)
        return rows.map { r -> List(w) { r.getOrElse(it) { "" } } }
    }
}

object DocWrite {
    private const val XMLH = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"

    /** PDF/PNG_ZIP için null (Android tarafı üretir). Sayfası olmayan belge boş bir çıktı verir. */
    fun write(doc: Doc, t: ConvTarget, title: String = ""): ByteArray? = when (t) {
        ConvTarget.TXT -> txt(doc).toByteArray(Charsets.UTF_8)
        ConvTarget.MD -> md(doc).toByteArray(Charsets.UTF_8)
        ConvTarget.HTML -> html(doc).toByteArray(Charsets.UTF_8)
        ConvTarget.CSV -> byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + csv(doc).toByteArray(Charsets.UTF_8)
        ConvTarget.RTF -> rtf(doc).toByteArray(Charsets.ISO_8859_1)
        ConvTarget.DOCX -> docx(doc)
        ConvTarget.XLSX -> xlsx(doc)
        ConvTarget.PPTX -> pptx(doc)
        ConvTarget.ODT -> odt(doc)
        ConvTarget.ODS -> ods(doc)
        ConvTarget.ODP -> odp(doc)
        ConvTarget.EPUB -> EbookWrite.epub(doc, title)
        ConvTarget.FB2 -> EbookWrite.fb2(doc, title)
        ConvTarget.PNG -> ImageDoc.png(doc)
        ConvTarget.PDF, ConvTarget.PNG_ZIP -> null
    }

    internal fun zipBytes(entries: List<Pair<String, ByteArray>>, mimetype: String? = null): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            if (mimetype != null) {
                val b = mimetype.toByteArray(Charsets.UTF_8)
                val e = ZipEntry("mimetype"); e.method = ZipEntry.STORED; e.size = b.size.toLong(); e.compressedSize = b.size.toLong()
                val crc = CRC32(); crc.update(b); e.crc = crc.value
                z.putNextEntry(e); z.write(b); z.closeEntry()
            }
            for ((n, c) in entries) { z.putNextEntry(ZipEntry(n)); z.write(c); z.closeEntry() }
        }
        return bo.toByteArray()
    }

    private fun zip(entries: List<Pair<String, String>>, mimetype: String? = null): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            if (mimetype != null) {
                val b = mimetype.toByteArray(Charsets.UTF_8)
                val e = ZipEntry("mimetype"); e.method = ZipEntry.STORED; e.size = b.size.toLong(); e.compressedSize = b.size.toLong()
                val crc = CRC32(); crc.update(b); e.crc = crc.value
                z.putNextEntry(e); z.write(b); z.closeEntry()
            }
            for ((n, c) in entries) { z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        }
        return bo.toByteArray()
    }

    // ---------------- Metin biçimleri ----------------
    fun txt(doc: Doc): String {
        val out = ArrayList<String>()
        doc.pages.forEachIndexed { i, p ->
            if (i > 0) out.add("")
            if (DocConvert.showTitle(doc, p)) out.add(p.title)
            out.addAll(p.paragraphs)
            p.table?.forEach { out.add(it.joinToString("\t")) }
        }
        return out.joinToString("\n")
    }

    fun md(doc: Doc): String {
        val sb = StringBuilder()
        doc.pages.forEachIndexed { i, p ->
            if (i > 0) sb.append('\n')
            if (DocConvert.showTitle(doc, p)) sb.append("## ").append(p.title.replace('\n', ' ')).append("\n\n")
            for (t in p.paragraphs) sb.append(t.replace("\n", "  \n")).append("\n\n")
            val rows = p.table?.let { DocConvert.padRows(it) }
            if (!rows.isNullOrEmpty() && rows[0].isNotEmpty()) {
                sb.append("| ").append(rows[0].joinToString(" | ") { DocConvert.mdCell(it) }).append(" |\n")
                sb.append("|").append(" --- |".repeat(rows[0].size)).append('\n')
                for (r in rows.drop(1)) sb.append("| ").append(r.joinToString(" | ") { DocConvert.mdCell(it) }).append(" |\n")
                sb.append('\n')
            }
        }
        return sb.toString().trimEnd() + "\n"
    }

    fun html(doc: Doc): String {
        val rich = doc.pages.any { it.rich != null }
        val sb = StringBuilder("<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>")
        sb.append(DocConvert.xml(doc.pages.firstOrNull()?.title ?: "")).append("</title>")
        sb.append("<style>")
        if (rich) sb.append(FontMap.inlineFontCss(doc.pages.mapNotNull { it.rich })).append(RichHtml.CSS).append(".pl{max-width:900px;margin:10px auto;padding:12px 16px;background:#fff}td,th{border:1px solid #999;padding:4px 8px}.pg td{border:0}")
        else sb.append("body{font-family:sans-serif;max-width:900px;margin:1em auto;padding:0 1em}table{border-collapse:collapse}td,th{border:1px solid #999;padding:4px 8px}")
        sb.append("</style></head><body>\n")
        for (p in doc.pages) {
            p.rich?.let { sb.append(RichHtml.page(it)); return@let }
            if (p.rich != null) continue
            if (rich) sb.append("<div class=pl>\n")
            if (DocConvert.showTitle(doc, p)) sb.append("<h2>").append(DocConvert.xml(p.title)).append("</h2>\n")
            for (t in p.paragraphs) sb.append("<p>").append(DocConvert.xml(t).replace("\n", "<br>")).append("</p>\n")
            p.table?.let { rows ->
                sb.append("<table>\n")
                for (r in DocConvert.padRows(rows)) { sb.append("<tr>"); for (c in r) sb.append("<td>").append(DocConvert.xml(c).replace("\n", "<br>")).append("</td>"); sb.append("</tr>\n") }
                sb.append("</table>\n")
            }
            if (rich) sb.append("</div>\n")
        }
        return sb.append("</body></html>\n").toString()
    }

    fun csv(doc: Doc): String {
        val blocks = ArrayList<String>()
        for (p in doc.pages) {
            val lines = ArrayList<String>()
            if (doc.pages.size > 1 && p.title.isNotBlank()) lines.add(DocConvert.csvCell(p.title))
            for (t in p.paragraphs) lines.add(DocConvert.csvCell(t))
            p.table?.let { for (r in it) lines.add(r.joinToString(",") { c -> DocConvert.csvCell(c) }) }
            if (lines.isNotEmpty()) blocks.add(lines.joinToString("\r\n"))
        }
        return blocks.joinToString("\r\n\r\n") + (if (blocks.isEmpty()) "" else "\r\n")
    }

    fun rtf(doc: Doc): String {
        val ctx = RichWrite.RtfCtx()
        val firstRich = doc.pages.firstNotNullOfOrNull { it.rich }
        val sb = StringBuilder()
        doc.pages.forEachIndexed { i, p ->
            if (i > 0) sb.append("\\page\n")
            if (p.rich != null) { sb.append(RichWrite.rBody(Rich.flat(p.rich), ctx)); return@forEachIndexed }
            if (DocConvert.showTitle(doc, p)) sb.append("\\pard\\b\\fs32 ").append(DocConvert.rtf(p.title)).append("\\b0\\fs22\\par\n")
            for (t in p.paragraphs) sb.append("\\pard ").append(DocConvert.rtf(t)).append("\\par\n")
            p.table?.let { rows ->
                val r2 = DocConvert.padRows(rows)
                val cols = r2.firstOrNull()?.size ?: 0
                if (cols > 0) {
                    val w = 9000 / cols
                    for (r in r2) {
                        sb.append("\\trowd\\trgaph108")
                        for (c in 1..cols) sb.append("\\clbrdrt\\brdrs\\clbrdrl\\brdrs\\clbrdrb\\brdrs\\clbrdrr\\brdrs\\cellx").append(c * w)
                        for (c in r) sb.append("\\pard\\intbl ").append(DocConvert.rtf(c)).append("\\cell")
                        sb.append("\\row\n")
                    }
                    sb.append("\\pard\\par\n")
                }
            }
        }
        val hf = firstRich?.let { r ->
            (if (r.header.isNotEmpty()) "{\\header " + r.header.joinToString("\\par ") { RichWrite.rPara(it, ctx, r) } + "\\par}\n" else "") +
                (if (r.footer.isNotEmpty()) "{\\footer " + r.footer.joinToString("\\par ") { RichWrite.rPara(it, ctx, r) } + "\\par}\n" else "")
        } ?: ""
        val head = "{\\rtf1\\ansi\\ansicpg1254\\deff0\\uc1" + ctx.header(firstRich?.defFont ?: "Calibri") +
            "\\viewkind4" + (firstRich?.let { RichWrite.rPage(it.setup) } ?: "") + "\\fs" + (firstRich?.defSz ?: 22) + "\n" + hf
        return head + sb.append("}").toString()
    }

    // ---------------- DOCX ----------------
    private const val WNS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val RNS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"

    private fun wPara(t: String, bold: Boolean = false, size: Int = 0): String {
        val rpr = if (bold || size > 0) "<w:rPr>" + (if (bold) "<w:b/>" else "") + (if (size > 0) "<w:sz w:val=\"$size\"/>" else "") + "</w:rPr>" else ""
        val parts = DocConvert.xml(t).split("\n")
        val runs = parts.mapIndexed { i, s -> "<w:r>$rpr" + (if (i > 0) "<w:br/>" else "") + "<w:t xml:space=\"preserve\">$s</w:t></w:r>" }.joinToString("")
        return "<w:p>" + (if (bold) "<w:pPr><w:keepNext/></w:pPr>" else "") + runs + "</w:p>"
    }

    fun docx(doc: Doc): ByteArray {
        val media = RichWrite.DocxMedia()
        val firstRich = doc.pages.firstNotNullOfOrNull { it.rich }
        val sb = StringBuilder(XMLH).append("<w:document xmlns:w=\"$WNS\" xmlns:r=\"$RNS\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\"><w:body>")
        doc.pages.forEachIndexed { i, p ->
            if (i > 0) sb.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
            if (p.rich != null) { sb.append(RichWrite.wBody(Rich.flat(p.rich), media)); return@forEachIndexed }
            if (DocConvert.showTitle(doc, p)) sb.append(wPara(p.title, bold = true, size = 32))
            for (t in p.paragraphs) sb.append(wPara(t))
            p.table?.let { rows ->
                val r2 = DocConvert.padRows(rows)
                val cols = r2.firstOrNull()?.size ?: 0
                if (cols > 0) {
                    val w = 9000 / cols
                    sb.append("<w:tbl><w:tblPr><w:tblBorders>")
                    for (b in listOf("top", "left", "bottom", "right", "insideH", "insideV")) sb.append("<w:$b w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"999999\"/>")
                    sb.append("</w:tblBorders></w:tblPr><w:tblGrid>")
                    repeat(cols) { sb.append("<w:gridCol w:w=\"$w\"/>") }
                    sb.append("</w:tblGrid>")
                    for (r in r2) {
                        sb.append("<w:tr>")
                        for (c in r) sb.append("<w:tc><w:tcPr><w:tcW w:w=\"$w\" w:type=\"dxa\"/></w:tcPr>").append(wPara(c)).append("</w:tc>")
                        sb.append("</w:tr>")
                    }
                    sb.append("</w:tbl><w:p/>")
                }
            }
        }
        if (doc.pages.isEmpty()) sb.append("<w:p/>")
        val extra = ArrayList<Pair<String, ByteArray>>()
        val rels = StringBuilder(media.rels)
        val ct = StringBuilder()
        var hRid: String? = null; var fRid: String? = null
        if (firstRich != null && firstRich.header.isNotEmpty()) {
            hRid = "rIdHdr"
            extra.add("word/header1.xml" to (XMLH + "<w:hdr xmlns:w=\"$WNS\" xmlns:r=\"$RNS\">" + firstRich.header.joinToString("") { RichWrite.wPara(it, null) } + "</w:hdr>").toByteArray())
            rels.append("<Relationship Id=\"rIdHdr\" Type=\"$RNS/header\" Target=\"header1.xml\"/>")
            ct.append("<Override PartName=\"/word/header1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml\"/>")
        }
        if (firstRich != null && firstRich.footer.isNotEmpty()) {
            fRid = "rIdFtr"
            extra.add("word/footer1.xml" to (XMLH + "<w:ftr xmlns:w=\"$WNS\" xmlns:r=\"$RNS\">" + firstRich.footer.joinToString("") { RichWrite.wPara(it, null) } + "</w:ftr>").toByteArray())
            rels.append("<Relationship Id=\"rIdFtr\" Type=\"$RNS/footer\" Target=\"footer1.xml\"/>")
            ct.append("<Override PartName=\"/word/footer1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml\"/>")
        }
        sb.append(if (firstRich != null) RichWrite.wSect(firstRich.setup, hRid, fRid) else "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"709\" w:footer=\"709\" w:gutter=\"0\"/></w:sectPr>").append("</w:body></w:document>")
        val imgDefaults = (if (media.files.any { it.first.endsWith(".png") }) "<Default Extension=\"png\" ContentType=\"image/png\"/>" else "") +
            (if (media.files.any { it.first.endsWith(".jpg") }) "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" else "") +
            (if (media.files.any { it.first.endsWith(".gif") }) "<Default Extension=\"gif\" ContentType=\"image/gif\"/>" else "")
        return zipBytes(listOf(
            "[Content_Types].xml" to (XMLH + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>$imgDefaults<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>$ct</Types>").toByteArray(),
            "_rels/.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/officeDocument\" Target=\"word/document.xml\"/></Relationships>").toByteArray(),
            "word/document.xml" to sb.toString().toByteArray()
        ) + (if (rels.isNotEmpty()) listOf("word/_rels/document.xml.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\">$rels</Relationships>").toByteArray()) else emptyList()) + extra + media.files)
    }

    // ---------------- XLSX ----------------
    /** Her sayfa bir çalışma sayfasıdır: önce paragraflar (A sütunu), ardından tablo. */
    private fun sheetRows(p: DocPage): List<List<String>> = p.paragraphs.map { listOf(it) } + (p.table ?: emptyList())

    fun xlsx(doc: Doc): ByteArray {
        val pages = if (doc.pages.isEmpty()) listOf(DocPage("", emptyList())) else doc.pages
        val used = LinkedHashSet<String>()
        val names = pages.mapIndexed { i, p -> DocConvert.sheetName(p.title, i + 1, used).also { used.add(it) } }
        val ct = StringBuilder(XMLH + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
        val wb = StringBuilder(XMLH + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"$RNS\"><sheets>")
        val rels = StringBuilder(XMLH + "<Relationships xmlns=\"$PKG_REL\">")
        val files = ArrayList<Pair<String, String>>()
        val xf = XlsxStyles()
        pages.forEachIndexed { i, p ->
            val n = i + 1
            ct.append("<Override PartName=\"/xl/worksheets/sheet$n.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
            wb.append("<sheet name=\"${DocConvert.xml(names[i])}\" sheetId=\"$n\" r:id=\"rId$n\"/>")
            rels.append("<Relationship Id=\"rId$n\" Type=\"$RNS/worksheet\" Target=\"worksheets/sheet$n.xml\"/>")
            val sd = StringBuilder(XMLH + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
            val g = SheetFmt.grid(p)
            g.rows.forEachIndexed { ri, row ->
                sd.append("<row r=\"${ri + 1}\">")
                row.forEachIndexed { ci, v ->
                    val f = g.fmts[ri].getOrNull(ci)
                    if (v.isEmpty() && f == null) return@forEachIndexed
                    val ref = DocConvert.colName(ci) + (ri + 1)
                    val st = if (f == null) "" else " s=\"${xf.index(f)}\""
                    if (v.isEmpty()) sd.append("<c r=\"$ref\"$st/>")
                    else if (DocConvert.isPlainNumber(v)) sd.append("<c r=\"$ref\"$st><v>$v</v></c>")
                    else sd.append("<c r=\"$ref\"$st t=\"inlineStr\"><is><t xml:space=\"preserve\">${DocConvert.xml(v)}</t></is></c>")
                }
                sd.append("</row>")
            }
            sd.append("</sheetData></worksheet>")
            files.add("xl/worksheets/sheet$n.xml" to sd.toString())
        }
        ct.append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>"); wb.append("</sheets></workbook>")
        rels.append("<Relationship Id=\"rIdSt\" Type=\"$RNS/styles\" Target=\"styles.xml\"/></Relationships>")
        return zip(listOf(
            "[Content_Types].xml" to ct.toString(),
            "_rels/.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"),
            "xl/workbook.xml" to wb.toString(),
            "xl/_rels/workbook.xml.rels" to rels.toString(),
            "xl/styles.xml" to xf.xml()
        ) + files)
    }

    /** XLSX stil tablosu: her farklı biçim için yazı tipi + dolgu + hücre biçimi. 0 = varsayılan. */
    internal class XlsxStyles {
        private val fonts = arrayListOf("<font><sz val=\"11\"/><name val=\"Calibri\"/></font>")
        private val fills = arrayListOf("<fill><patternFill patternType=\"none\"/></fill>", "<fill><patternFill patternType=\"gray125\"/></fill>")
        private val xfs = arrayListOf("<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>")
        private val seen = HashMap<String, Int>()
        fun index(f: SheetFmt.Fmt): Int = seen.getOrPut(f.key) {
            val fo = "<font>" + (if (f.b) "<b/>" else "") + (if (f.i) "<i/>" else "") + (if (f.s) "<strike/>" else "") + (if (f.u) "<u/>" else "") +
                "<sz val=\"11\"/>" + (f.color?.let { "<color rgb=\"FF$it\"/>" } ?: "") + "<name val=\"Calibri\"/></font>"
            var fi = fonts.indexOf(fo); if (fi < 0) { fonts.add(fo); fi = fonts.size - 1 }
            var fl = 0
            if (f.fill != null) {
                val fx = "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF${f.fill}\"/><bgColor indexed=\"64\"/></patternFill></fill>"
                fl = fills.indexOf(fx); if (fl < 0) { fills.add(fx); fl = fills.size - 1 }
            }
            xfs.add("<xf numFmtId=\"0\" fontId=\"$fi\" fillId=\"$fl\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"" + (if (fl > 0) " applyFill=\"1\"" else "") +
                (if (f.align.isNotEmpty()) " applyAlignment=\"1\"><alignment horizontal=\"${f.align}\"/></xf>" else "/>"))
            xfs.size - 1
        }
        fun xml(): String = XMLH + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<fonts count=\"${fonts.size}\">${fonts.joinToString("")}</fonts><fills count=\"${fills.size}\">${fills.joinToString("")}</fills>" +
            "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"${xfs.size}\">${xfs.joinToString("")}</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>"
    }

    // ---------------- PPTX ----------------
    private const val ANS = "http://schemas.openxmlformats.org/drawingml/2006/main"
    private const val PNS = "http://schemas.openxmlformats.org/presentationml/2006/main"
    const val SLIDE_LINES = 16

    /** Sayfada konumlu şekil (twips, sayfanın sol-üstünden): dolgu, çizgi, geometri, döndürme, metin ve/veya resim. */
    /** DrawingML şekil adı → ODF özel şekil türü. */
    internal fun odfShapeType(prst: String) = when (prst) {
        "ellipse", "flowChartConnector" -> "ellipse"; "roundRect" -> "round-rectangle"; "triangle" -> "isosceles-triangle"
        "diamond", "flowChartDecision" -> "diamond"; "rtTriangle" -> "right-triangle"; "parallelogram" -> "parallelogram"
        "trapezoid" -> "trapezoid"; "hexagon" -> "hexagon"; "octagon" -> "octagon"; "rightArrow" -> "right-arrow"
        "leftArrow" -> "left-arrow"; "upArrow" -> "up-arrow"; "downArrow" -> "down-arrow"; "chevron" -> "chevron"
        "homePlate" -> "pentagon"; "plus", "mathPlus", "cross" -> "cross"; "star5" -> "star5"; "pentagon" -> "regular-pentagon"
        else -> "rectangle"
    }

    /** Konum özniteliği: dönük şekilde LibreOffice biçimi (saat yönünün tersi radyan + dönmüş sol-üst köşe), yoksa svg:x/y. */
    internal fun odfPos(x: Double, y: Double, w: Double, h: Double, rotDeg: Double): String {
        fun cm(v: Double) = String.format(java.util.Locale.US, "%.3fcm", v)
        val r = ((rotDeg % 360.0) + 360.0) % 360.0
        if (r < 0.01 || r > 359.99) return "svg:x=\"${cm(x)}\" svg:y=\"${cm(y)}\""
        val th = Math.toRadians(r)
        val cx = x + w / 2; val cy = y + h / 2; val dx = -w / 2; val dy = -h / 2
        val px = cx + dx * Math.cos(th) - dy * Math.sin(th); val py = cy + dx * Math.sin(th) + dy * Math.cos(th)
        return "draw:transform=\"rotate (${String.format(java.util.Locale.US, "%.5f", -th)}) translate (${cm(px)} ${cm(py)})\""
    }

    class Shape(
        val x: Int, val y: Int, val w: Int, val h: Int, val fill: String?, val line: Bd?, val prst: String, val rot: Float,
        val valign: String, val inset: Int, val paras: List<RPara>, val img: RImg?
    )

    /** Slayt içeriği: başlık + satırlar. [paras] (varsa) satırların biçimli karşılığı; [image] resim slaydı; [shapes] şekil slaydı (pw × ph = kaynak sayfa, twips). */
    class Slide(
        val title: String, val lines: List<String>, val paras: List<RPara?> = emptyList(), val image: RImg? = null,
        val shapes: List<Shape> = emptyList(), val pw: Int = 0, val ph: Int = 0, val defSz: Int = 22
    )

    private val PRST_OK = Regex("[A-Za-z0-9]{3,30}")

    private fun boxParas(blocks: List<RBlock>): List<RPara> = blocks.flatMap { b ->
        when (b) {
            is RPara -> listOf(b)
            is RTable -> b.rows.map { r -> RPara(listOf(RRun(r.filter { it.vMerge != 2 }.joinToString("  |  ") { c -> c.paras.joinToString(" ") { q -> q.plain.trim() }.trim() }))) }.filter { it.plain.isNotBlank() }
            else -> emptyList()
        }
    }

    /** Konumlu kutuları/şekilleri [out]'a, akış içeriğini [rest]'e ayırır. */
    internal fun collectShapes(blocks: List<RBlock>, out: MutableList<Shape>, rest: MutableList<RBlock>, topOff: Int) {
        for (b in blocks) when (b) {
            is RBox -> {
                val ps = boxParas(b.blocks.filter { it !is RBox })
                val img = ps.firstNotNullOfOrNull { p -> p.runs.firstNotNullOfOrNull { it.img } }
                val text = ps.filter { p -> p.runs.any { it.img == null && it.text.isNotBlank() } }
                    .map { p -> if (p.runs.any { it.img != null }) RPara(p.runs.filter { it.img == null }, p.align, p.head, p.marker) else p }
                out.add(Shape(b.x, b.y, b.w, b.h, b.fill ?: b.grad.firstOrNull() ?: b.pie.firstOrNull()?.second, b.border, if (b.round || b.pie.isNotEmpty()) "ellipse" else b.prst.ifEmpty { "rect" }, b.rot, b.valign, b.inset, text, img))
                collectShapes(b.blocks.filter { it is RBox }, out, rest, topOff)
            }
            is RTable -> {
                val a = b.at
                if (a != null && b.rows.size == 1 && b.rows[0].size == 1) {
                    val c = b.rows[0][0]
                    val bd = c.bt ?: c.bl ?: c.bb ?: c.br
                    out.add(Shape(a[0], a[1] + (if (a.size > 4 && a[4] == 1) topOff else 0), a[2], a[3], Rich.hex(c.fill), bd?.takeIf { it.w > 0 },
                        b.prst.takeIf { PRST_OK.matches(it) } ?: "rect", 0f, c.valign, 0, c.paras.filter { it.plain.isNotBlank() }, null))
                } else rest.add(b)
            }
            else -> rest.add(b)
        }
    }

    private fun blockImages(blocks: List<RBlock>): List<RImg> = blocks.flatMap { b ->
        when (b) {
            is RPara -> b.runs.mapNotNull { it.img }
            is RTable -> b.rows.flatMap { r -> r.flatMap { c -> c.paras.flatMap { q -> q.runs.mapNotNull { it.img } } } }
            else -> emptyList()
        }
    }

    fun slides(doc: Doc): List<Slide> {
        val out = ArrayList<Slide>()
        for (p in doc.pages) {
            val lines = ArrayList<String>()
            val paras = ArrayList<RPara?>()
            val shapes = ArrayList<Shape>()
            val src = p.rich
            val rp = if (src != null) {
                val rest = ArrayList<RBlock>()
                collectShapes(src.blocks, shapes, rest, src.setup.top)
                RichPage(rest, src.setup, src.defSz, src.defFont, src.defAfter, src.defLine, src.header, src.footer, src.bg)
            } else null
            if (rp != null) {
                for (bl in rp.blocks) when (bl) {
                    is RPara -> { val t = bl.plain.trim(); if (t.isNotEmpty()) { lines.add(if (bl.marker.isNotEmpty()) bl.marker + " " + t else t); paras.add(bl) } }
                    is RTable -> for (r in bl.rows) {
                        val line = r.filter { it.vMerge != 2 }.joinToString("  |  ") { c -> c.paras.joinToString(" ") { it.plain.trim() }.trim() }
                        if (line.replace("|", "").isNotBlank()) { lines.add(line); paras.add(null) }
                    }
                    else -> { }
                }
            } else {
                lines.addAll(p.paragraphs); lines.forEach { _ -> paras.add(null) }
                p.table?.forEach { r -> lines.add(r.joinToString("  |  ")); paras.add(null) }
            }
            val imgs = if (rp != null) blockImages(rp.blocks) else emptyList()
            if (lines.isNotEmpty() || (imgs.isEmpty() && shapes.isEmpty())) {
                val idx = if (lines.isEmpty()) listOf(emptyList()) else lines.indices.toList().chunked(SLIDE_LINES)
                idx.forEachIndexed { i, c -> out.add(Slide(if (i == 0) p.title else p.title + " (" + (i + 1) + ")", c.map { lines[it] }, c.map { paras[it] })) }
            }
            imgs.forEach { out.add(Slide(p.title, emptyList(), emptyList(), it)) }
            if (shapes.isNotEmpty()) out.add(Slide("", emptyList(), emptyList(), null, shapes, src!!.setup.w, src.setup.h, src.defSz))
        }
        return out
    }

    private const val EMU_W = 12192000
    private const val EMU_H = 6858000

    /** Kaynak sayfayı (twips) slayda sığdıran ölçek ve ortalama kayması (EMU). */
    internal fun slideFit(pw: Int, ph: Int): DoubleArray {
        val w = (if (pw > 0) pw else 19200).toDouble() * 635; val h = (if (ph > 0) ph else 10800).toDouble() * 635
        val sc = minOf(EMU_W / w, EMU_H / h)
        return doubleArrayOf(sc, (EMU_W - w * sc) / 2, (EMU_H - h * sc) / 2)
    }

    private fun shapeRun(text: String, szHalf: Int, sc: Double, r: RRun?): String {
        val sz = (szHalf * 50 * sc).toInt().coerceIn(600, 7200)
        return aRun(text, sz, r, false)
    }

    private fun shapePara(p: RPara, defSz: Int, sc: Double): String {
        val runs = p.runs.filter { it.text.isNotEmpty() }
        val al = when (p.align) { "center" -> "ctr"; "right" -> "r"; "justify" -> "just"; else -> "l" }
        return "<a:p><a:pPr algn=\"$al\"/>" + (if (p.marker.isNotEmpty()) shapeRun(p.marker + " ", defSz, sc, null) else "") +
            runs.joinToString("") { shapeRun(it.text, if (it.sz > 0) it.sz else defSz, sc, it) } + "</a:p>"
    }

    /** Bir şekli p:sp (+ resimse p:pic) olarak yazar. [pic]: resim ilişki kimliği. */
    private fun pptxShape(id: Int, sh: Shape, fit: DoubleArray, defSz: Int, pic: String?): String {
        val sc = fit[0]
        val x = (fit[1] + sh.x * 635.0 * sc).toLong(); val y = (fit[2] + sh.y * 635.0 * sc).toLong()
        val w = (sh.w * 635.0 * sc).toLong().coerceAtLeast(1); val h = (sh.h * 635.0 * sc).toLong().coerceAtLeast(1)
        val rot = if (sh.rot != 0f) " rot=\"${(((sh.rot % 360f) + 360f) % 360f * 60000).toLong()}\"" else ""
        val xf = "<a:xfrm$rot><a:off x=\"$x\" y=\"$y\"/><a:ext cx=\"$w\" cy=\"$h\"/></a:xfrm>"
        val sb = StringBuilder()
        if (pic != null) sb.append("<p:pic><p:nvPicPr><p:cNvPr id=\"$id\" name=\"Picture $id\"/><p:cNvPicPr><a:picLocks noChangeAspect=\"1\"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed=\"$pic\"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr>$xf<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr></p:pic>")
        val fill = Rich.hex(sh.fill)
        if (fill != null || sh.line != null || sh.paras.isNotEmpty()) {
            val geom = if (PRST_OK.matches(sh.prst)) sh.prst else "rect"
            val fx = if (fill != null) "<a:solidFill><a:srgbClr val=\"$fill\"/></a:solidFill>" else "<a:noFill/>"
            val ln = sh.line?.let { "<a:ln w=\"${(it.w * 1587L).coerceIn(3175L, 152400L)}\"><a:solidFill><a:srgbClr val=\"${Rich.hex(it.color) ?: "000000"}\"/></a:solidFill></a:ln>" } ?: "<a:ln><a:noFill/></a:ln>"
            val ins = (if (sh.inset > 0) sh.inset * 635L * sc else 45720.0 * sc).toLong()
            val anchor = when (sh.valign) { "center" -> "ctr"; "bottom" -> "b"; else -> "t" }
            val body = if (sh.paras.isEmpty()) "<a:p><a:endParaRPr lang=\"tr-TR\"/></a:p>" else sh.paras.take(200).joinToString("") { shapePara(it, defSz, sc) }
            sb.append("<p:sp><p:nvSpPr><p:cNvPr id=\"${id + 1}\" name=\"Shape $id\"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr>$xf<a:prstGeom prst=\"$geom\"><a:avLst/></a:prstGeom>$fx$ln</p:spPr>" +
                "<p:txBody><a:bodyPr wrap=\"square\" lIns=\"$ins\" tIns=\"$ins\" rIns=\"$ins\" bIns=\"$ins\" rtlCol=\"0\" anchor=\"$anchor\"><a:noAutofit/></a:bodyPr><a:lstStyle/>$body</p:txBody></p:sp>")
        }
        return sb.toString()
    }

    /** Slayt resmi: kalan alana (EMU) oranı koruyarak sığar, ortalanır. */
    internal fun fitEmu(im: RImg, boxX: Int, boxY: Int, boxW: Int, boxH: Int): IntArray {
        val ar = im.w.toDouble().coerceAtLeast(1.0) / im.h.toDouble().coerceAtLeast(1.0)
        var w = boxW.toDouble(); var h = w / ar
        if (h > boxH) { h = boxH.toDouble(); w = h * ar }
        return intArrayOf(boxX + ((boxW - w) / 2).toInt(), boxY + ((boxH - h) / 2).toInt(), w.toInt(), h.toInt())
    }

    private fun aRun(text: String, sz: Int, r: RRun?, bold: Boolean): String {
        val b = bold || r?.b == true
        val fill = Rich.hex(r?.color)?.let { "<a:solidFill><a:srgbClr val=\"$it\"/></a:solidFill>" } ?: ""
        val hl = Rich.hex(r?.hl)?.let { "<a:highlight><a:srgbClr val=\"$it\"/></a:highlight>" } ?: ""
        return "<a:r><a:rPr lang=\"tr-TR\" sz=\"$sz\"" + (if (b) " b=\"1\"" else "") + (if (r?.i == true) " i=\"1\"" else "") +
            (if (r?.u == true) " u=\"sng\"" else "") + (if (r?.s == true) " strike=\"sngStrike\"" else "") + " dirty=\"0\">$fill$hl</a:rPr><a:t>${DocConvert.xml(text)}</a:t></a:r>"
    }

    /** Bir slayt satırı: biçimli paragraf varsa çalıştırmaları (renk/kalın/italik/altı çizili) korunur. */
    private fun aPara(text: String, p: RPara?, sz: Int, bold: Boolean): String {
        val runs = p?.runs?.filter { it.text.isNotEmpty() }.orEmpty()
        if (p == null || runs.isEmpty()) return "<a:p>" + aRun(text, sz, null, bold) + "</a:p>"
        val al = when (p.align) { "center" -> "ctr"; "right" -> "r"; "justify" -> "just"; else -> "" }
        return "<a:p>" + (if (al.isNotEmpty()) "<a:pPr algn=\"$al\"/>" else "") +
            (if (p.marker.isNotEmpty()) aRun(p.marker + " ", sz, null, false) else "") + runs.joinToString("") { aRun(it.text, sz, it, bold) } + "</a:p>"
    }

    private fun aTextBox(id: Int, name: String, x: Int, y: Int, cx: Int, cy: Int, paras: List<String>, sz: Int, bold: Boolean, rich: List<RPara?> = emptyList()): String {
        val body = if (paras.isEmpty()) "<a:p><a:endParaRPr lang=\"tr-TR\"/></a:p>" else paras.mapIndexed { i, t -> aPara(t, rich.getOrNull(i), sz, bold) }.joinToString("")
        return "<p:sp><p:nvSpPr><p:cNvPr id=\"$id\" name=\"$name\"/><p:cNvSpPr txBox=\"1\"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"$x\" y=\"$y\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr wrap=\"square\" rtlCol=\"0\"><a:normAutofit/></a:bodyPr><a:lstStyle/>$body</p:txBody></p:sp>"
    }

    private fun theme(): String {
        fun acc(n: Int, c: String) = "<a:accent$n><a:srgbClr val=\"$c\"/></a:accent$n>"
        val fill = "<a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>"
        return XMLH + "<a:theme xmlns:a=\"$ANS\" name=\"Atlas\"><a:themeElements><a:clrScheme name=\"Atlas\">" +
            "<a:dk1><a:sysClr val=\"windowText\" lastClr=\"000000\"/></a:dk1><a:lt1><a:sysClr val=\"window\" lastClr=\"FFFFFF\"/></a:lt1>" +
            "<a:dk2><a:srgbClr val=\"44546A\"/></a:dk2><a:lt2><a:srgbClr val=\"E7E6E6\"/></a:lt2>" +
            acc(1, "4472C4") + acc(2, "ED7D31") + acc(3, "A5A5A5") + acc(4, "FFC000") + acc(5, "5B9BD5") + acc(6, "70AD47") +
            "<a:hlink><a:srgbClr val=\"0563C1\"/></a:hlink><a:folHlink><a:srgbClr val=\"954F72\"/></a:folHlink></a:clrScheme>" +
            "<a:fontScheme name=\"Atlas\"><a:majorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:majorFont><a:minorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:minorFont></a:fontScheme>" +
            "<a:fmtScheme name=\"Atlas\"><a:fillStyleLst>$fill$fill$fill</a:fillStyleLst>" +
            "<a:lnStyleLst><a:ln w=\"6350\">$fill</a:ln><a:ln w=\"12700\">$fill</a:ln><a:ln w=\"19050\">$fill</a:ln></a:lnStyleLst>" +
            "<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>" +
            "<a:bgFillStyleLst>$fill$fill$fill</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>"
    }

    fun pptx(doc: Doc): ByteArray {
        val sl = slides(doc).ifEmpty { listOf(Slide("", emptyList())) }
        val ct = StringBuilder(XMLH + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"png\" ContentType=\"image/png\"/><Default Extension=\"jpg\" ContentType=\"image/jpeg\"/><Default Extension=\"gif\" ContentType=\"image/gif\"/>" +
            "<Override PartName=\"/ppt/presentation.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml\"/>" +
            "<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml\"/>" +
            "<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>" +
            "<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>")
        val ids = StringBuilder(); val prels = StringBuilder(XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/slideMaster\" Target=\"slideMasters/slideMaster1.xml\"/><Relationship Id=\"rId2\" Type=\"$RNS/theme\" Target=\"theme/theme1.xml\"/>")
        val files = ArrayList<Pair<String, String>>()
        val media = ArrayList<Pair<String, ByteArray>>()
        sl.forEachIndexed { i, s ->
            val n = i + 1
            ct.append("<Override PartName=\"/ppt/slides/slide$n.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>")
            ids.append("<p:sldId id=\"${256 + i}\" r:id=\"rId${n + 2}\"/>")
            prels.append("<Relationship Id=\"rId${n + 2}\" Type=\"$RNS/slide\" Target=\"slides/slide$n.xml\"/>")
            val n2 = s.lines.size
            val sz = when { n2 <= 6 -> 2400; n2 <= 10 -> 2000; else -> 1600 }
            var srel = ""
            val x = StringBuilder(XMLH + "<p:sld xmlns:a=\"$ANS\" xmlns:r=\"$RNS\" xmlns:p=\"$PNS\"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>")
            if (s.shapes.isEmpty()) x.append(aTextBox(2, "Title", 609600, 304800, 10972800, 914400, if (s.title.isBlank()) emptyList() else listOf(s.title), 3200, true))
            if (s.shapes.isNotEmpty()) {
                val fit = slideFit(s.pw, s.ph)
                var rid = 1; var sid = 10
                for (sh in s.shapes.take(400)) {
                    var pic: String? = null
                    if (sh.img != null) {
                        rid++; pic = "rId$rid"
                        media.add("ppt/media/image${media.size + 1}.${sh.img.ext}" to sh.img.data)
                        srel += "<Relationship Id=\"$pic\" Type=\"$RNS/image\" Target=\"../${media.last().first.substringAfter("ppt/")}\"/>"
                    }
                    x.append(pptxShape(sid, sh, fit, s.defSz, pic)); sid += 2
                }
            } else if (s.image != null) {
                val im = s.image
                val r = fitEmu(im, 609600, if (s.title.isBlank()) 304800 else 1371600, 10972800, if (s.title.isBlank()) 6248400 else 5181600)
                media.add("ppt/media/image${media.size + 1}.${im.ext}" to im.data)
                val mn = media.last().first.substringAfter("ppt/")
                srel = "<Relationship Id=\"rId2\" Type=\"$RNS/image\" Target=\"../$mn\"/>"
                x.append("<p:pic><p:nvPicPr><p:cNvPr id=\"4\" name=\"Picture ${media.size}\"/><p:cNvPicPr><a:picLocks noChangeAspect=\"1\"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed=\"rId2\"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x=\"${r[0]}\" y=\"${r[1]}\"/><a:ext cx=\"${r[2]}\" cy=\"${r[3]}\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr></p:pic>")
            } else x.append(aTextBox(3, "Body", 609600, 1371600, 10972800, 5029200, s.lines, sz, false, s.paras))
            x.append("</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>")
            files.add("ppt/slides/slide$n.xml" to x.toString())
            files.add("ppt/slides/_rels/slide$n.xml.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/>$srel</Relationships>"))
        }
        ct.append("</Types>"); prels.append("</Relationships>")
        val grp = "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>"
        return (listOf(
            "[Content_Types].xml" to ct.toString(),
            "_rels/.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/officeDocument\" Target=\"ppt/presentation.xml\"/></Relationships>"),
            "ppt/presentation.xml" to (XMLH + "<p:presentation xmlns:a=\"$ANS\" xmlns:r=\"$RNS\" xmlns:p=\"$PNS\"><p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst><p:sldIdLst>$ids</p:sldIdLst><p:sldSz cx=\"12192000\" cy=\"6858000\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>"),
            "ppt/_rels/presentation.xml.rels" to prels.toString(),
            "ppt/slideMasters/slideMaster1.xml" to (XMLH + "<p:sldMaster xmlns:a=\"$ANS\" xmlns:r=\"$RNS\" xmlns:p=\"$PNS\"><p:cSld><p:bg><p:bgRef idx=\"1001\"><a:schemeClr val=\"bg1\"/></p:bgRef></p:bg><p:spTree>$grp</p:spTree></p:cSld><p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/><p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/></p:sldLayoutIdLst></p:sldMaster>"),
            "ppt/slideMasters/_rels/slideMaster1.xml.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/><Relationship Id=\"rId2\" Type=\"$RNS/theme\" Target=\"../theme/theme1.xml\"/></Relationships>"),
            "ppt/slideLayouts/slideLayout1.xml" to (XMLH + "<p:sldLayout xmlns:a=\"$ANS\" xmlns:r=\"$RNS\" xmlns:p=\"$PNS\" type=\"blank\" preserve=\"1\"><p:cSld name=\"Blank\"><p:spTree>$grp</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>"),
            "ppt/slideLayouts/_rels/slideLayout1.xml.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/slideMaster\" Target=\"../slideMasters/slideMaster1.xml\"/></Relationships>"),
            "ppt/theme/theme1.xml" to theme()
        ) + files).map { it.first to it.second.toByteArray(Charsets.UTF_8) }.let { zipBytes(it + media) }
    }

    // ---------------- ODF ----------------
    private const val ONS = "xmlns:office=\"urn:oasis:names:tc:opendocument:xmlns:office:1.0\" xmlns:text=\"urn:oasis:names:tc:opendocument:xmlns:text:1.0\" xmlns:table=\"urn:oasis:names:tc:opendocument:xmlns:table:1.0\" xmlns:draw=\"urn:oasis:names:tc:opendocument:xmlns:drawing:1.0\" xmlns:svg=\"urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0\" xmlns:fo=\"urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0\" xmlns:style=\"urn:oasis:names:tc:opendocument:xmlns:style:1.0\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" office:version=\"1.2\""

    /** ODF metni: çoklu boşluk → text:s, sekme → text:tab, satır sonu → text:line-break. */
    fun odfText(s: String): String {
        val x = DocConvert.xml(s)
        val sb = StringBuilder()
        var i = 0
        while (i < x.length) {
            val c = x[i]
            when {
                c == ' ' -> { var j = i; while (j < x.length && x[j] == ' ') j++; val n = j - i
                    if (n == 1 && i > 0) sb.append(' ') else sb.append(if (i > 0) " " else "").append(if (n - (if (i > 0) 1 else 0) > 0) "<text:s text:c=\"${n - (if (i > 0) 1 else 0)}\"/>" else ""); i = j; continue }
                c == '\t' -> sb.append("<text:tab/>")
                c == '\n' -> sb.append("<text:line-break/>")
                c == '\r' -> {}
                else -> sb.append(c)
            }
            i++
        }
        return sb.toString()
    }

    private fun odfPack(mime: String, body: String, auto: String = "", styles: String? = null, pics: List<Pair<String, ByteArray>> = emptyList()): ByteArray = zipBytes((listOf(
        "content.xml" to (XMLH + "<office:document-content $ONS>" + (if (auto.isNotEmpty()) "<office:automatic-styles>$auto</office:automatic-styles>" else "") + "<office:body>$body</office:body></office:document-content>"),
        "META-INF/manifest.xml" to (XMLH + "<manifest:manifest xmlns:manifest=\"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0\" manifest:version=\"1.2\"><manifest:file-entry manifest:full-path=\"/\" manifest:media-type=\"$mime\"/><manifest:file-entry manifest:full-path=\"content.xml\" manifest:media-type=\"text/xml\"/>" +
            (if (styles != null) "<manifest:file-entry manifest:full-path=\"styles.xml\" manifest:media-type=\"text/xml\"/>" else "") +
            pics.joinToString("") { "<manifest:file-entry manifest:full-path=\"${it.first}\" manifest:media-type=\"image/${if (it.first.endsWith(".jpg")) "jpeg" else it.first.substringAfterLast('.')}\"/>" } + "</manifest:manifest>")
    ) + (if (styles != null) listOf("styles.xml" to styles) else emptyList())).map { it.first to it.second.toByteArray(Charsets.UTF_8) } + pics, mimetype = mime)

    fun odt(doc: Doc): ByteArray {
        val sb = StringBuilder("<office:text>")
        var tn = 0
        val oc = RichWrite.OdtCtx()
        val firstRich = doc.pages.firstNotNullOfOrNull { it.rich }
        for (p in doc.pages) {
            if (p.rich != null) { sb.append(RichWrite.oBody(Rich.flat(p.rich), oc, tn)); tn += Rich.flat(p.rich).blocks.count { it is RTable }; continue }
            if (DocConvert.showTitle(doc, p)) sb.append("<text:h text:outline-level=\"1\">").append(odfText(p.title)).append("</text:h>")
            for (t in p.paragraphs) sb.append("<text:p>").append(odfText(t)).append("</text:p>")
            p.table?.let { rows ->
                val r2 = DocConvert.padRows(rows)
                val cols = r2.firstOrNull()?.size ?: 0
                if (cols > 0) {
                    tn++
                    sb.append("<table:table table:name=\"Tablo$tn\"><table:table-column table:number-columns-repeated=\"$cols\"/>")
                    for (r in r2) { sb.append("<table:table-row>"); for (c in r) sb.append("<table:table-cell office:value-type=\"string\"><text:p>").append(odfText(c)).append("</text:p></table:table-cell>"); sb.append("</table:table-row>") }
                    sb.append("</table:table>")
                }
            }
        }
        sb.append("</office:text>")
        val hdr = firstRich?.header?.joinToString("") { RichWrite.oPara(it, oc, firstRich) } ?: ""
        val ftr = firstRich?.footer?.joinToString("") { RichWrite.oPara(it, oc, firstRich) } ?: ""
        val styles = firstRich?.let {
            XMLH + "<office:document-styles $ONS>" + RichWrite.oDefaults(it) + "<office:automatic-styles>" + RichWrite.oPageLayout(it.setup) + oc.styles +
                "</office:automatic-styles><office:master-styles><style:master-page style:name=\"Standard\" style:page-layout-name=\"pm1\">" +
                (if (hdr.isNotEmpty()) "<style:header>$hdr</style:header>" else "") + (if (ftr.isNotEmpty()) "<style:footer>$ftr</style:footer>" else "") +
                "</style:master-page></office:master-styles></office:document-styles>"
        }
        return odfPack("application/vnd.oasis.opendocument.text", sb.toString(), oc.styles.toString(), styles, oc.pics)
    }

    fun ods(doc: Doc): ByteArray {
        val pages = if (doc.pages.isEmpty()) listOf(DocPage("", emptyList())) else doc.pages
        val used = LinkedHashSet<String>()
        val sb = StringBuilder("<office:spreadsheet>")
        val auto = StringBuilder(); val styles = HashMap<String, String>()
        fun style(f: SheetFmt.Fmt): String = styles.getOrPut(f.key) {
            val n = "ce" + (styles.size + 1)
            auto.append("<style:style style:name=\"$n\" style:family=\"table-cell\">")
            if (f.fill != null) auto.append("<style:table-cell-properties fo:background-color=\"#${f.fill}\"/>")
            auto.append("<style:text-properties" + (if (f.color != null) " fo:color=\"#${f.color}\"" else "") + (if (f.b) " fo:font-weight=\"bold\"" else "") +
                (if (f.i) " fo:font-style=\"italic\"" else "") + (if (f.u) " style:text-underline-style=\"solid\" style:text-underline-width=\"auto\" style:text-underline-color=\"font-color\"" else "") +
                (if (f.s) " style:text-line-through-style=\"solid\"" else "") + "/>")
            if (f.align.isNotEmpty()) auto.append("<style:paragraph-properties fo:text-align=\"${if (f.align == "right") "end" else "center"}\"/>")
            auto.append("</style:style>")
            n
        }
        pages.forEachIndexed { i, p ->
            val name = DocConvert.sheetName(p.title, i + 1, used).also { used.add(it) }
            val g = SheetFmt.grid(p)
            val rows = DocConvert.padRows(g.rows.ifEmpty { listOf(listOf("")) })
            val cols = rows.maxOf { it.size }.coerceAtLeast(1)
            sb.append("<table:table table:name=\"${DocConvert.xml(name)}\"><table:table-column table:number-columns-repeated=\"$cols\"/>")
            rows.forEachIndexed { ri, r ->
                sb.append("<table:table-row>")
                for ((ci, c) in r.ifEmpty { listOf("") }.withIndex()) {
                    val f = g.fmts.getOrNull(ri)?.getOrNull(ci)
                    val st = if (f == null) "" else " table:style-name=\"${style(f)}\""
                    if (c.isEmpty()) sb.append("<table:table-cell$st/>")
                    else if (DocConvert.isPlainNumber(c)) sb.append("<table:table-cell$st office:value-type=\"float\" office:value=\"$c\"><text:p>$c</text:p></table:table-cell>")
                    else sb.append("<table:table-cell$st office:value-type=\"string\"><text:p>").append(odfText(c)).append("</text:p></table:table-cell>")
                }
                sb.append("</table:table-row>")
            }
            sb.append("</table:table>")
        }
        sb.append("</office:spreadsheet>")
        return odfPack("application/vnd.oasis.opendocument.spreadsheet", sb.toString(), auto.toString())
    }

    fun odp(doc: Doc): ByteArray {
        val sl = slides(doc).ifEmpty { listOf(Slide("", emptyList())) }
        val sb = StringBuilder("<office:presentation>")
        val auto = StringBuilder(); val spans = HashMap<String, String>(); val pics = ArrayList<Pair<String, ByteArray>>()
        fun span(r: RRun, pt: Double = 0.0): String? {
            val col = Rich.hex(r.color)
            if (col == null && !r.b && !r.i && !r.u && !r.s && pt <= 0.0) return null
            val key = "$col|${r.b}|${r.i}|${r.u}|${r.s}|$pt"
            return spans.getOrPut(key) {
                val n = "AT" + (spans.size + 1)
                auto.append("<style:style style:name=\"$n\" style:family=\"text\"><style:text-properties" + (if (col != null) " fo:color=\"#$col\"" else "") +
                    (if (pt > 0.0) " fo:font-size=\"${String.format(java.util.Locale.US, "%.1f", pt)}pt\"" else "") +
                    (if (r.b) " fo:font-weight=\"bold\"" else "") + (if (r.i) " fo:font-style=\"italic\"" else "") +
                    (if (r.u) " style:text-underline-style=\"solid\" style:text-underline-width=\"auto\" style:text-underline-color=\"font-color\"" else "") +
                    (if (r.s) " style:text-line-through-style=\"solid\"" else "") + "/></style:style>")
                n
            }
        }
        fun cm(emu: Int) = String.format(java.util.Locale.US, "%.2fcm", emu / 360000.0)
        fun cmD(v: Double) = String.format(java.util.Locale.US, "%.3fcm", v)
        val grs = HashMap<String, String>()
        fun grStyle(sh: Shape, vcm: Double): String = grs.getOrPut("${sh.fill}|${sh.line?.w}|${sh.line?.color}|${sh.valign}") {
            val n = "gr" + (grs.size + 1)
            val fill = Rich.hex(sh.fill); val lc = sh.line?.let { Rich.hex(it.color) ?: "000000" }
            auto.append("<style:style style:name=\"$n\" style:family=\"graphic\"><style:graphic-properties draw:fill=\"${if (fill != null) "solid" else "none"}\"" +
                (if (fill != null) " draw:fill-color=\"#$fill\"" else "") + " draw:stroke=\"${if (lc != null) "solid" else "none"}\"" +
                (if (lc != null) " svg:stroke-color=\"#$lc\" svg:stroke-width=\"${cmD(((sh.line?.w ?: 8) / 8.0) * 0.0353 * vcm)}\"" else "") +
                " draw:textarea-vertical-align=\"${when (sh.valign) { "center" -> "middle"; "bottom" -> "bottom"; else -> "top" }}\" draw:textarea-horizontal-align=\"left\" fo:padding-top=\"0.1cm\" fo:padding-left=\"0.1cm\" fo:padding-right=\"0.1cm\" fo:padding-bottom=\"0.1cm\"/></style:style>")
            n
        }
        sl.forEachIndexed { i, s ->
            sb.append("<draw:page draw:name=\"page${i + 1}\">")
            if (s.shapes.isNotEmpty()) {
                // Varsayılan ODP sayfası 28 × 15,75 cm: kaynak sayfa oranı korunarak sığdırılır.
                val sw = (if (s.pw > 0) s.pw else 19200) / 567.0; val shh = (if (s.ph > 0) s.ph else 10800) / 567.0
                val k = minOf(28.0 / sw, 15.75 / shh); val ox = (28.0 - sw * k) / 2; val oy = (15.75 - shh * k) / 2
                for (sh in s.shapes.take(400)) {
                    val x = ox + sh.x / 567.0 * k; val y = oy + sh.y / 567.0 * k; val w = (sh.w / 567.0 * k).coerceAtLeast(0.01); val h = (sh.h / 567.0 * k).coerceAtLeast(0.01)
                    if (sh.img != null) {
                        val nm = "Pictures/shape${pics.size + 1}.${sh.img.ext}"; pics.add(nm to sh.img.data)
                        sb.append("<draw:frame svg:x=\"${cmD(x)}\" svg:y=\"${cmD(y)}\" svg:width=\"${cmD(w)}\" svg:height=\"${cmD(h)}\"><draw:image xlink:href=\"$nm\" xlink:type=\"simple\" xlink:show=\"embed\" xlink:actuate=\"onLoad\"/></draw:frame>")
                    }
                    if (Rich.hex(sh.fill) == null && sh.line == null && sh.paras.isEmpty()) continue
                    val type = odfShapeType(sh.prst)
                    sb.append("<draw:custom-shape draw:style-name=\"${grStyle(sh, k)}\" ${odfPos(x, y, w, h, sh.rot.toDouble())} svg:width=\"${cmD(w)}\" svg:height=\"${cmD(h)}\">")
                    if (sh.paras.isEmpty()) sb.append("<text:p/>")
                    for (p in sh.paras.take(200)) {
                        sb.append("<text:p>")
                        if (p.marker.isNotEmpty()) sb.append(odfText(p.marker + " "))
                        for (r in p.runs.filter { it.text.isNotEmpty() }) {
                            val pt = ((if (r.sz > 0) r.sz else s.defSz) / 2.0 * k).coerceIn(5.0, 96.0)
                            sb.append("<text:span text:style-name=\"${span(r, pt)}\">").append(odfText(r.text)).append("</text:span>")
                        }
                        sb.append("</text:p>")
                    }
                    sb.append("<draw:enhanced-geometry svg:viewBox=\"0 0 21600 21600\" draw:type=\"$type\"/></draw:custom-shape>")
                }
                sb.append("</draw:page>")
                return@forEachIndexed
            }
            sb.append("<draw:frame svg:x=\"1.5cm\" svg:y=\"1cm\" svg:width=\"22cm\" svg:height=\"2.5cm\"><draw:text-box><text:p>").append(odfText(s.title)).append("</text:p></draw:text-box></draw:frame>")
            if (s.image != null) {
                val im = s.image
                val r = fitEmu(im, 540000, 1440000, 7920000, 4320000)
                val nm = "Pictures/slide${pics.size + 1}.${im.ext}"
                pics.add(nm to im.data)
                sb.append("<draw:frame svg:x=\"${cm(r[0])}\" svg:y=\"${cm(r[1])}\" svg:width=\"${cm(r[2])}\" svg:height=\"${cm(r[3])}\"><draw:image xlink:href=\"$nm\" xlink:type=\"simple\" xlink:show=\"embed\" xlink:actuate=\"onLoad\"/></draw:frame></draw:page>")
                return@forEachIndexed
            }
            sb.append("<draw:frame svg:x=\"1.5cm\" svg:y=\"4cm\" svg:width=\"22cm\" svg:height=\"12cm\"><draw:text-box>")
            s.lines.forEachIndexed { k, l ->
                val p = s.paras.getOrNull(k)
                val runs = p?.runs?.filter { it.text.isNotEmpty() }.orEmpty()
                if (p == null || runs.isEmpty()) sb.append("<text:p>").append(odfText(l)).append("</text:p>")
                else {
                    sb.append("<text:p>")
                    if (p.marker.isNotEmpty()) sb.append(odfText(p.marker + " "))
                    for (r in runs) { val st = span(r); if (st == null) sb.append(odfText(r.text)) else sb.append("<text:span text:style-name=\"$st\">").append(odfText(r.text)).append("</text:span>") }
                    sb.append("</text:p>")
                }
            }
            if (s.lines.isEmpty()) sb.append("<text:p/>")
            sb.append("</draw:text-box></draw:frame></draw:page>")
        }
        sb.append("</office:presentation>")
        return odfPack("application/vnd.oasis.opendocument.presentation", sb.toString(), auto.toString(), null, pics)
    }
}
