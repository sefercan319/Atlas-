#!/usr/bin/env python3
"""Atlas için cihazda EĞİTİLEBİLİR TFLite modeli üretir (TensorFlow Lite on-device training deseni).

Kullanım (Colab):  !pip -q install tensorflow
                   !python export_tflite_train.py atlas_train.tflite
Üretilen model imzaları: train(x[B,144], y[B,2]) -> loss · infer(x[B,144]) -> output[B,2] · save/restore(checkpoint_path).
Uygulama: dosyayı Model kartı bağlantısından indir, motor "İçe aktarılan model" seç; "TFLite eğitimi" düğmesi örneklerle eğitir.
"""
import sys
import tensorflow as tf

DIM = 144


class AtlasModel(tf.Module):
    def __init__(self):
        self.model = tf.keras.Sequential([
            tf.keras.layers.Input(shape=(DIM,)),
            tf.keras.layers.Dense(32, activation="relu"),
            tf.keras.layers.Dense(2, activation="softmax"),
        ])
        self.model.compile(optimizer=tf.keras.optimizers.SGD(0.05), loss=tf.keras.losses.CategoricalCrossentropy())

    @tf.function(input_signature=[tf.TensorSpec([None, DIM], tf.float32), tf.TensorSpec([None, 2], tf.float32)])
    def train(self, x, y):
        with tf.GradientTape() as tape:
            loss = self.model.loss(y, self.model(x))
        grads = tape.gradient(loss, self.model.trainable_variables)
        self.model.optimizer.apply_gradients(zip(grads, self.model.trainable_variables))
        return {"loss": loss}

    @tf.function(input_signature=[tf.TensorSpec([None, DIM], tf.float32)])
    def infer(self, x):
        return {"output": self.model(x)}

    @tf.function(input_signature=[tf.TensorSpec(shape=[], dtype=tf.string)])
    def save(self, checkpoint_path):
        names = [v.name for v in self.model.weights]
        tf.raw_ops.Save(filename=checkpoint_path, tensor_names=names, data=[v.read_value() for v in self.model.weights], name="save")
        return {"checkpoint_path": checkpoint_path}

    @tf.function(input_signature=[tf.TensorSpec(shape=[], dtype=tf.string)])
    def restore(self, checkpoint_path):
        restored = {}
        for v in self.model.weights:
            r = tf.raw_ops.Restore(file_pattern=checkpoint_path, tensor_name=v.name, dt=v.dtype, name="restore")
            v.assign(r)
            restored[v.name] = r
        return restored


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "atlas_train.tflite"
    m = AtlasModel()
    sigs = {"train": m.train.get_concrete_function(), "infer": m.infer.get_concrete_function(),
            "save": m.save.get_concrete_function(), "restore": m.restore.get_concrete_function()}
    tf.saved_model.save(m, "atlas_saved", signatures=sigs)
    conv = tf.lite.TFLiteConverter.from_saved_model("atlas_saved")
    conv.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS, tf.lite.OpsSet.SELECT_TF_OPS]
    conv.experimental_enable_resource_variables = True
    open(out, "wb").write(conv.convert())
    print("yazıldı:", out)


if __name__ == "__main__":
    main()
