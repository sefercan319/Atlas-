#!/usr/bin/env python3
"""Atlas için PyTorch Mobile (.ptl) ve ExecuTorch (.pte) sınıflandırıcı dışa aktarır. Girdi [1,144] float, çıktı [1,2] olasılık.

Kullanım (Colab):  !pip -q install torch executorch
                   !python export_pytorch.py atlas      →  atlas.ptl ve atlas.pte
Kendi eğittiğin modeli kullanmak için Net'i değiştir (girdi 144, çıktı 2 kalsın).
"""
import sys
import torch
from torch import nn

DIM = 144


class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.f = nn.Sequential(nn.Linear(DIM, 32), nn.ReLU(), nn.Linear(32, 2))

    def forward(self, x):
        return torch.softmax(self.f(x), dim=-1)


def main():
    base = sys.argv[1] if len(sys.argv) > 1 else "atlas"
    net = Net().eval()
    ex = torch.zeros(1, DIM)
    from torch.utils.mobile_optimizer import optimize_for_mobile
    optimize_for_mobile(torch.jit.trace(net, ex))._save_for_lite_interpreter(base + ".ptl")
    try:
        from executorch.exir import to_edge
        et = to_edge(torch.export.export(net, (ex,))).to_executorch()
        open(base + ".pte", "wb").write(et.buffer)
    except Exception as e:  # ExecuTorch sürümü farklıysa .ptl yine de üretilir
        print("ExecuTorch dışa aktarma atlandı:", e)
    print("yazıldı:", base + ".ptl", base + ".pte")


if __name__ == "__main__":
    main()
