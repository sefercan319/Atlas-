#!/usr/bin/env python3
"""Atlas kural öğrenicisi için bilgisayarda/Colab'da ONNX sınıflandırıcı eğitir.

Kullanım (Colab'da):  !pip -q install scikit-learn skl2onnx onnxruntime numpy
                      !python train_onnx.py atlas_egitim.jsonl atlas.onnx [lr|gbt]
Uygulamada: Model kartı → "Eğitim verisini paylaş (JSONL)" ile dosyayı al, burada çalıştır,
üretilen .onnx dosyasını bir bağlantıya koyup Model kartından indir, motor olarak "ONNX" seç.

Özellikler uygulamadaki LearnPure.features ile birebir aynıdır (144 boyut: 16 temel + 64 kelime + 64 harf üçlüsü).
"""
import json, re, sys
import numpy as np

BASE, WORDS, GRAMS = 16, 64, 64
DIM = BASE + WORDS + GRAMS
GENERIC = ["container", "root", "content", "layout", "frame", "toolbar", "status", "navigation_bar", "decor", "action_bar",
           "scroll", "recycler", "viewpager", "pager", "wrapper", "parent", "holder", "background", "divider", "spacer", "progress", "loading"]


def jhash(s):  # Java String.hashCode (UTF-16 kod birimleri üzerinden, 32 bit)
    h = 0
    for cu in _utf16_units(s):
        h = (31 * h + cu) & 0xFFFFFFFF
    return h


def _utf16_units(text):
    b = text.encode("utf-16-le", "surrogatepass")
    return [b[i] | (b[i + 1] << 8) for i in range(0, len(b), 2)]


def bucket(w, n):
    return (jhash(w) & 0x7FFFFFFF) % n


def type_of(e):
    return 2 if e.startswith("sel:") else 3 if e.startswith("desc:") else 4 if e.startswith("text:") else 1


def body_of(e):
    return e if type_of(e) == 1 else e.split(":", 1)[1]


def features(e, ratio, in_neg, name, conflict):
    x = np.zeros(DIM, dtype=np.float32)
    body = body_of(e)
    low = body.lower()
    x[0] = 1.0
    x[type_of(e)] = 1.0
    x[5] = min(max(ratio, 0.0), 1.0)
    x[6] = 1.0 if in_neg else 0.0
    x[7] = min(len(body), 40) / 40.0
    x[8] = 1.0 if name else 0.0
    x[9] = 1.0 if any(c.isdigit() for c in body) else 0.0
    x[10] = 1.0 if " " in body.strip() else 0.0
    x[11] = 1.0 if body[:1].isupper() else 0.0
    x[12] = 1.0 if any(g in low for g in GENERIC) else 0.0
    x[13] = 1.0 if conflict else 0.0
    x[14] = 1.0 if body and sum(c.isdigit() for c in body) * 10 > len(body) * 3 else 0.0
    x[15] = 0.0 if in_neg else x[5]
    for m in re.finditer(r"[^\W\d_]{3,}", low):
        w = m.group(0)
        x[BASE + bucket(w, WORDS)] = 1.0
        for i in range(len(w) - 2):
            x[BASE + WORDS + bucket(w[i:i + 3], GRAMS)] = 1.0
    return x


def load(path):
    X, y, sw = [], [], []
    with open(path, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            if "_plan" in d:
                continue
            X.append(features(d["entry"], d["ratio"], d["in_negative"], d["name_match"], d["conflict"]))
            y.append(1 if d["label"] else 0)
            sw.append(float(d.get("weight", 1.0)))
    return np.stack(X), np.array(y), np.array(sw)


def main():
    src, dst = sys.argv[1], sys.argv[2]
    kind = sys.argv[3] if len(sys.argv) > 3 else "gbt"
    from sklearn.ensemble import GradientBoostingClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import f1_score
    from sklearn.model_selection import train_test_split
    from skl2onnx import convert_sklearn
    from skl2onnx.common.data_types import FloatTensorType
    X, y, sw = load(src)
    if len(y) < 40 or y.min() == y.max():
        sys.exit("En az 40 örnek ve her iki sınıf gerekir.")
    Xtr, Xva, ytr, yva, wtr, _ = train_test_split(X, y, sw, test_size=0.2, stratify=y, random_state=7)
    model = GradientBoostingClassifier(n_estimators=120, max_depth=3, random_state=7) if kind == "gbt" else LogisticRegression(max_iter=2000, class_weight="balanced")
    model.fit(Xtr, ytr, sample_weight=wtr)
    print("doğrulama F1:", round(f1_score(yva, model.predict(Xva)), 3))
    model.fit(X, y, sample_weight=sw)
    onx = convert_sklearn(model, initial_types=[("input", FloatTensorType([None, DIM]))], options={id(model): {"zipmap": False}}, target_opset=13)
    with open(dst, "wb") as f:
        f.write(onx.SerializeToString())
    print("yazıldı:", dst)


if __name__ == "__main__":
    main()
