package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.time.LocalDate

/** v0.48: tam yedek (v2). */
class BackupTest {
    private val today = LocalDate.of(2026, 10, 25)
    private fun src(rel: String) = File(TestFiles.code, "com/odak/app/$rel").readText()

    @Test fun skipsActivePassAndFocus() {
        assertTrue(Pure.backupSkip("pass:instagram", today))
        assertTrue(Pure.backupSkip("focus", today))
        assertTrue(Pure.backupSkip("pomo_end", today))
        assertTrue(Pure.backupSkip("pomo_phase", today))
    }
    @Test fun skipsOldDailyCounters() {
        assertTrue(Pure.backupSkip("fu:2026-01-01:app:feat", today))
        assertTrue(Pure.backupSkip("bc:2026-10-24", today))
    }
    @Test fun keepsTodayCountersAndSettings() {
        assertFalse(Pure.backupSkip("bc:2026-10-25", today))
        assertFalse(Pure.backupSkip("alim:youtube", today))
        assertFalse(Pure.backupSkip("app:instagram", today))
        assertFalse(Pure.backupSkip("msg:warn", today))
        assertFalse(Pure.backupSkip("ui_scale", today))
        assertFalse(Pure.backupSkip("focus_note", today))
    }
    @Test fun onlyKnownFilesAllowed() {
        for (f in Pure.BACKUP_FILES) assertTrue(f, Pure.backupFileAllowed(f))
        assertFalse(Pure.backupFileAllowed("odak_secret"))
        assertFalse(Pure.backupFileAllowed(""))
        assertFalse(Pure.backupFileAllowed("../odak_app"))
    }
    @Test fun backupFilesCoverAllStores() {
        assertEquals(7, Pure.BACKUP_FILES.size)
        assertTrue("odak_block" in Pure.BACKUP_FILES && "odak_colors" in Pure.BACKUP_FILES)
    }
    @Test fun jsonArrayPrecheck() {
        assertTrue(Pure.looksLikeJsonArray("[]"))
        assertTrue(Pure.looksLikeJsonArray("  [1,2] "))
        assertFalse(Pure.looksLikeJsonArray("{}"))
        assertFalse(Pure.looksLikeJsonArray(""))
        assertFalse(Pure.looksLikeJsonArray("["))
        assertFalse(Pure.looksLikeJsonArray("hello"))
    }
    @Test fun everyStoreFileNameIsInBackupList() {
        val names = Regex("""getSharedPreferences\("(odak_[a-z]+)"""").findAll(
            TestFiles.kotlinSources().joinToString("\n") { it.readText() }
        ).map { it.groupValues[1] }.toSet()
        val missing = names - Pure.BACKUP_FILES.toSet() - setOf("odak_pin") // PIN bilerek yedeklenmez
        assertTrue("Yedekte olmayan tercih dosyası: $missing", missing.isEmpty())
    }
    @Test fun pinIsNeverBackedUp() {
        assertFalse(Pure.backupFileAllowed("odak_pin"))
    }
    @Test fun importValidatesBeforeWriting() {
        val t = src("settings/Backup.kt")
        assertTrue(t.indexOf("ops.add(") in 0 until t.indexOf("editors.values.forEach"))
        assertTrue(t.contains("backupFileAllowed"))
        assertTrue(t.contains("looksLikeJsonArray"))
    }
    @Test fun backupCardUsesBackupObjectAndCatchesErrors() {
        val t = src("settings/MoreCards.kt")
        assertTrue(t.contains("Backup.export(ctx)") && t.contains("Backup.import(ctx, text)"))
        assertTrue(t.contains("catch (e: Exception)"))
    }
}
