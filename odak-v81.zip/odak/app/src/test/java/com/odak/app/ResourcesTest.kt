package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Çeviri dosyaları, kodda kullanılan metinler ve manifest tutarlılığı. */
class ResourcesTest {
    private val files = TestFiles.stringFiles()
    private val base = TestFiles.parseStrings(files["values"]!!)
    private val placeholder = Regex("""%(\d+\$)?[sdf]""")

    @Test fun allLanguageFoldersExist() {
        val need = listOf("values", "values-tr", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az")
        assertTrue("Eksik dil klasörü", files.keys.containsAll(need))
    }

    @Test fun everyLanguageHasSameKeys() {
        for ((name, f) in files) {
            val keys = TestFiles.parseStrings(f).keys
            assertTrue("$name eksik: ${base.keys - keys}", (base.keys - keys).isEmpty())
            assertTrue("$name fazla: ${keys - base.keys}", (keys - base.keys).isEmpty())
        }
    }

    @Test fun noEmptyTranslations() {
        for ((name, f) in files) {
            val empty = TestFiles.parseStrings(f).filterValues { it.isBlank() }.keys
            assertTrue("$name boş: $empty", empty.isEmpty())
        }
    }

    @Test fun placeholdersMatchTheDefaultLanguage() {
        for ((name, f) in files) {
            for ((k, v) in TestFiles.parseStrings(f)) {
                val want = placeholder.findAll(base[k] ?: continue).map { it.value }.sorted().toList()
                val got = placeholder.findAll(v).map { it.value }.sorted().toList()
                assertEquals("$name/$k yer tutucuları farklı", want, got)
            }
        }
    }

    @Test fun everyStringUsedInCodeIsDefined() {
        val used = TestFiles.kotlinSources().flatMap { f ->
            Regex("""R\.string\.([a-zA-Z0-9_]+)""").findAll(f.readText()).map { it.groupValues[1] }.toList()
        }.toSet()
        val missing = used - base.keys
        assertTrue("Kodda kullanılıp tanımlanmamış metinler: $missing", missing.isEmpty())
    }

    @Test fun localesConfigListsEveryLanguage() {
        val cfg = File(TestFiles.res, "xml/locales_config.xml").readText()
        for (l in listOf("tr", "en", "de", "fr", "es", "ar", "ru", "az")) {
            assertTrue("locales_config'te $l yok", cfg.contains("\"$l\""))
        }
    }

    @Test fun manifestClassesExist() {
        val manifest = File(TestFiles.main, "AndroidManifest.xml").readText()
        val names = Regex("""android:name="\.([A-Za-z0-9_.]+)"""").findAll(manifest).map { it.groupValues[1] }.toList()
        assertTrue(names.isNotEmpty())
        for (n in names) {
            val cls = n.substringAfterLast('.')
            val found = TestFiles.kotlinSources().any { f -> Regex("""class\s+$cls\b""").containsMatchIn(f.readText()) }
            assertTrue("Manifest'te olup kodda olmayan sınıf: $n", found)
        }
    }

    @Test fun everySoundResourceExistsForEveryDesign() {
        val styles = Regex("""\("[^"]*", "([a-z0-9_]+)"\)""").findAll(
            File(TestFiles.code, "com/odak/app/theme/DesignStyle.kt").readText().substringBefore("data class DesignTokens")
        ).map { it.groupValues[1] }.toList()
        assertTrue(styles.size >= 6)
        val raw = File(TestFiles.res, "raw").list()!!.toSet()
        for (s in styles) for (k in listOf("tap", "success", "delete", "notify")) {
            assertTrue("Ses yok: snd_${s}_$k.wav", "snd_${s}_$k.wav" in raw)
        }
    }

    @Test fun versionCodeIsPositive() {
        val g = File(TestFiles.main.parentFile.parentFile, "build.gradle.kts").readText()
        val code = Regex("""versionCode = (\d+)""").find(g)!!.groupValues[1].toInt()
        assertTrue(code > 0)
    }
}
