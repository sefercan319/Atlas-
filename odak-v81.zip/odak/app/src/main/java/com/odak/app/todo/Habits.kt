package com.odak.app.todo

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.plan.DeleteMark
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.SoundKind
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.ThemedTextField
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.UUID

class Habit(val id: String, val name: String, val days: Set<String>) {
    /** Bugünden (yapılmadıysa dünden) geriye ardışık gün sayısı. */
    fun streak(today: LocalDate): Int = com.odak.app.logic.Pure.streak(days, today)
}

object HabitStore {
    private fun p(c: Context) = c.getSharedPreferences("odak_habits", Context.MODE_PRIVATE)

    fun load(c: Context): List<Habit> = try {
        val a = JSONArray(p(c).getString("items", "[]"))
        (0 until a.length()).mapNotNull { i -> try {
            val o = a.getJSONObject(i)
            val da = o.optJSONArray("days") ?: JSONArray()
            Habit(o.getString("id"), o.getString("name"), List(da.length()) { da.optString(it) }.filter { it.isNotEmpty() }.toSet())
        } catch (e: Exception) { null } }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(c: Context, l: List<Habit>) {
        val a = JSONArray()
        l.forEach { h ->
            a.put(JSONObject().put("id", h.id).put("name", h.name).put("days", JSONArray(h.days.sorted().takeLast(400))))
        }
        p(c).edit().putString("items", a.toString()).apply()
    }
}

/** Günlük alışkanlık takibi: bugün işaretle, seriyi (🔥) gör. */
@Composable
fun HabitCard() {
    val ctx = LocalContext.current
    val t = LocalDesign.current.tokens
    var list by remember { mutableStateOf(HabitStore.load(ctx)) }
    var name by remember { mutableStateOf("") }
    val today = LocalDate.now()
    fun put(l: List<Habit>) { list = l; HabitStore.save(ctx, l) }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text("🔥", style = MaterialTheme.typography.titleMedium)
        list.forEach { h ->
            val doneToday = today.toString() in h.days
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                ThemedCheck(doneToday) { c ->
                    put(list.map {
                        if (it.id == h.id) Habit(it.id, it.name, if (c) it.days + today.toString() else it.days - today.toString())
                        else it
                    })
                }
                Spacer(Modifier.width(10.dp))
                Text(h.name, Modifier.weight(1f), color = t.text)
                val s = h.streak(today)
                if (s > 0) Text("🔥 $s  ", color = t.text.copy(alpha = 0.8f))
                Text(
                    stringResource(R.string.habit_rate, com.odak.app.logic.Pure.weekRate(h.days, today)) +
                        "  ★" + com.odak.app.logic.Pure.bestStreak(h.days) + "  ",
                    color = t.text.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall
                )
                DeleteMark(t.text.copy(alpha = 0.5f)) { put(list.filter { it.id != h.id }) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            ThemedTextField(name, { name = it.take(40) }, stringResource(R.string.habit_hint), Modifier.weight(1f))
            Spacer(Modifier.width(6.dp))
            ThemedButton("+", {
                val n = name.trim()
                if (n.isNotEmpty()) {
                    put(list + Habit(UUID.randomUUID().toString(), n, emptySet()))
                    name = ""
                }
            }, sound = SoundKind.SUCCESS)
        }
    }
}


/** Günlük su sayacı: bardak sayısı, hedef 8. */
object WaterStore {
    private fun p(c: Context) = c.getSharedPreferences("odak_habits", Context.MODE_PRIVATE)
    fun get(c: Context, d: LocalDate = LocalDate.now()) = p(c).getInt("water:$d", 0)
    fun set(c: Context, n: Int, d: LocalDate = LocalDate.now()) {
        p(c).edit().putInt("water:$d", n.coerceIn(0, 30)).apply()
    }
    const val GOAL = 8
}

@Composable
fun WaterCard() {
    val ctx = LocalContext.current
    val t = LocalDesign.current.tokens
    var n by remember { mutableStateOf(WaterStore.get(ctx)) }
    ThemedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("💧 " + stringResource(R.string.water_title), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.water_count, n, WaterStore.GOAL), style = MaterialTheme.typography.bodySmall)
            }
            ThemedButton("−", { n = (n - 1).coerceAtLeast(0); WaterStore.set(ctx, n) })
            Spacer(Modifier.width(6.dp))
            ThemedButton("+", { n += 1; WaterStore.set(ctx, n) }, sound = SoundKind.SUCCESS)
        }
        Spacer(Modifier.height(6.dp))
        androidx.compose.foundation.layout.Box(
            Modifier.fillMaxWidth().height(6.dp).background(t.text.copy(alpha = 0.12f))
        ) {
            androidx.compose.foundation.layout.Box(
                Modifier.fillMaxWidth(com.odak.app.logic.Pure.waterFraction(n, WaterStore.GOAL)).height(6.dp).background(t.primary)
            )
        }
    }
}

