package com.odak.app.todo

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.odak.app.notify.Reminders
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import kotlinx.coroutines.delay

/** Pomodoro: 25 dk odak, 5 dk mola. Süre bitince bildirim gelir. */
@Composable
fun PomodoroCard() {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE) }
    // Faz ve bitiş zamanı kalıcıdır: uygulama kapansa/süreç ölse bile sayaç doğru devam eder.
    var phase by remember { mutableStateOf(sp.getInt("pomo_phase", 0)) } // 0 odak, 1 mola
    var endMs by remember { mutableStateOf(sp.getLong("pomo_end", 0L)) }
    LaunchedEffect(phase, endMs) { sp.edit().putInt("pomo_phase", phase).putLong("pomo_end", endMs).apply() }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    val total = if (phase == 0) 25 else 5

    LaunchedEffect(endMs) {
        while (endMs > 0L) {
            now = System.currentTimeMillis()
            if (now >= endMs) {
                phase = 1 - phase
                endMs = 0L
                break
            }
            delay(500)
        }
    }

    val leftSec = if (endMs > 0L) (com.odak.app.logic.Pure.pomoLeftMs(endMs, now) / 1000).toInt() else total * 60
    ThemedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(
                (if (phase == 0) "🍅 " else "☕ ") + "%02d:%02d".format(leftSec / 60, leftSec % 60),
                style = MaterialTheme.typography.headlineMedium
            )
            if (endMs > 0L) {
                ThemedButton("⏹", {
                    Reminders.cancelId(ctx, "pomodoro")
                    endMs = 0L
                })
            } else {
                ThemedButton("▶", {
                    val end = System.currentTimeMillis() + total * 60_000L
                    now = System.currentTimeMillis()
                    endMs = end
                    Reminders.scheduleAt(ctx, "pomodoro", if (phase == 0) "🍅" else "☕", com.odak.app.notify.Msgs.text(ctx, "pomo", "✓"), end)
                })
            }
        }
    }
}
