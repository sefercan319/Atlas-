package com.odak.app.docs

import java.io.ByteArrayOutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Dönüştürme hedefleri. PDF ve PNG_ZIP Android tarafında (DocPdf) üretilir; diğerleri bu dosyada saf Kotlin ile. */
enum class ConvTarget(val ext: String, val mime: String) {
    TXT("txt", "text/plain"),
    MD("md", "text/markdown"),
    HTML("html", "text/html"),
    CSV("csv", "text/csv"),
    RTF("rtf", "application/rtf"),
    DOCX("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    XLSX("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    PPTX("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    ODT("odt", "application/vnd.oasis.opendocument.text"),
    ODS("ods", "application/vnd.oasis.opendocument.spreadsheet"),
    ODP("odp", "application/vnd.oasis.opendocument.presentation"),
    PDF("pdf", "application/pdf"),
    /** Yalnızca PDF kaynağı için: her sayfa bir PNG, hepsi zip içinde. */
    PNG_ZIP("zip", "application/zip")
}

/** Dönüştürme planlama yardımcıları (Android'e bağımlı değil). */
object DocConvert {
    private val sameAs = mapOf(
        DocKind.DOCX to ConvTarget.DOCX, DocKind.XLSX to ConvTarget.XLSX, DocKind.PPTX to ConvTarget.PPTX,
        DocKind.ODT to ConvTarget.ODT, DocKind.ODS to ConvTarget.ODS, DocKind.ODP to ConvTarget.ODP, DocKind.RTF to ConvTarget.RTF
    )

    /**
     * Kaynak türüne göre seçilebilir hedefler. PDF'den metin çıkarılamaz (yalnızca sayfa resimleri); Google/çözülemeyen
     * dosyalarda hedef yoktur. Boş belge (hiç sayfa yok) de dönüştürülemez; PDF bunun dışındadır.
     */
    fun targetsFor(kind: DocKind, hasContent: Boolean): List<ConvTarget> {
        if (kind == DocKind.PDF) return ConvTarget.values().filter { it != ConvTarget.PDF }
        if (kind == DocKind.GOOGLE || kind == DocKind.OPAQUE || kind == DocKind.UNKNOWN || !hasContent) return emptyList()
        return ConvTarget.values().filter { it != ConvTarget.PNG_ZIP && it != sameAs[kind] }
    }

    /** Kaynak adından çıktı adı: uzantıyı değiştirir, tehlikeli karakterleri temizler. */
    fun outName(src: String, t: ConvTarget): String {
        val base = src.substringBeforeLast('.', src).replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().trim('.').take(80)
        return (if (base.isEmpty()) "belge" else base) + "." + t.ext
    }

    /** XML 1.0'da geçersiz karakterleri atar ve & < > " karakterlerini kaçırır. */
    fun xml(s: String): String {
        val sb = StringBuilder(s.length + 8)
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch == '\t' || ch == '\n' || ch == '\r' -> sb.append(ch)
                ch.code < 0x20 -> {}
                Character.isHighSurrogate(ch) -> if (i + 1 < s.length && Character.isLowSurrogate(s[i + 1])) { sb.append(ch).append(s[i + 1]); i++ }
                Character.isLowSurrogate(ch) -> {}
                ch.code == 0xFFFE || ch.code == 0xFFFF -> {}
                else -> sb.append(ch)
            }
            i++
        }
        return sb.toString()
    }

    /** Excel sayfa adı: [ ] : * ? / \ yok, en çok 31 karakter, boş değil, tekrar yok (büyük/küçük harfe duyarsız). */
    fun sheetName(title: String, index: Int, used: Set<String>): String {
        var base = title.replace(Regex("[\\[\\]:*?/\\\\]"), " ").trim().trim('\'').take(31)
        if (base.isEmpty()) base = "Sayfa$index"
        var n = base; var k = 2
        while (used.any { it.equals(n, ignoreCase = true) }) { val suf = " ($k)"; n = base.take(31 - suf.length) + suf; k++ }
        return n
    }

    /** Düz sayı mı (başında gereksiz sıfır yok, 15 haneye kadar)? XLSX/ODS'de sayısal hücre olarak yazılır. */
    fun isPlainNumber(s: String): Boolean = Regex("-?(0|[1-9][0-9]{0,14})(\\.[0-9]{1,10})?").matches(s)

    fun colName(i: Int): String { var n = i + 1; val sb = StringBuilder(); while (n > 0) { val r = (n - 1) % 26; sb.insert(0, ('A' + r)); n = (n - 1) / 26 }; return sb.toString() }

    fun csvCell(s: String): String {
        val t = s.replace("\r\n", "\n").replace('\r', '\n')
        return if (t.any { it == ',' || it == '"' || it == '\n' } || t.startsWith(" ") || t.endsWith(" ")) "\"" + t.replace("\"", "\"\"") + "\"" else t
    }

    fun rtf(s: String): String {
        val sb = StringBuilder()
        for (ch in s) when {
            ch == '\\' -> sb.append("\\\\")
            ch == '{' -> sb.append("\\{")
            ch == '}' -> sb.append("\\}")
            ch == '\n' -> sb.append("\\line ")
            ch == '\r' -> {}
            ch == '\t' -> sb.append("\\tab ")
            ch.code < 0x20 -> {}
            ch.code < 0x80 -> sb.append(ch)
            else -> sb.append("\\u").append(ch.code.toShort().toInt()).append('?')
        }
        return sb.toString()
    }

    /**
     * Metni en çok maxW genişliğe sığacak satırlara böler (PDF için). measure: bir dizgenin genişliği.
     * Satır sonları korunur; sığmayan uzun sözcük karakter karakter bölünür. Boş metin tek boş satır verir.
     */
    fun wrap(text: String, maxW: Float, measure: (String) -> Float): List<String> {
        val out = ArrayList<String>()
        for (raw in text.replace("\r\n", "\n").replace('\r', '\n').split('\n')) {
            if (raw.isBlank()) { out.add(""); continue }
            var cur = StringBuilder()
            for (word in raw.split(' ')) {
                val cand = if (cur.isEmpty()) word else "$cur $word"
                if (measure(cand) <= maxW) { cur = StringBuilder(cand); continue }
                if (cur.isNotEmpty()) { out.add(cur.toString()); cur = StringBuilder() }
                if (measure(word) <= maxW) { cur.append(word); continue }
                var piece = StringBuilder()
                for (ch in word) {
                    if (piece.isNotEmpty() && measure(piece.toString() + ch) > maxW) { out.add(piece.toString()); piece = StringBuilder() }
                    piece.append(ch)
                }
                cur = piece
            }
            out.add(cur.toString())
        }
        return out
    }

    fun mdCell(s: String): String = s.replace("\r", " ").replace("\n", " ").replace("|", "\\|")

    /** Sayfanın başlığı gösterilsin mi: çok sayfalı belgede ya da tablo sayfasında. */
    fun showTitle(doc: Doc, p: DocPage): Boolean = p.title.isNotBlank() && (doc.pages.size > 1 || p.table != null)

    /** Tablo satırlarını en geniş satıra göre doldurur (en çok 60 sütun). */
    fun padRows(rows: List<List<String>>): List<List<String>> {
        val w = (rows.maxOfOrNull { it.size } ?: 0).coerceAtMost(60)
        return rows.map { r -> List(w) { r.getOrElse(it) { "" } } }
    }
}

object DocWrite {
    private const val XMLH = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"

    /** PDF/PNG_ZIP için null (Android tarafı üretir). Sayfası olmayan belge boş bir çıktı verir. */
    fun write(doc: Doc, t: ConvTarget): ByteArray? = when (t) {
        ConvTarget.TXT -> txt(doc).toByteArray(Charsets.UTF_8)
        ConvTarget.MD -> md(doc).toByteArray(Charsets.UTF_8)
        ConvTarget.HTML -> html(doc).toByteArray(Charsets.UTF_8)
        ConvTarget.CSV -> byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + csv(doc).toByteArray(Charsets.UTF_8)
        ConvTarget.RTF -> rtf(doc).toByteArray(Charsets.ISO_8859_1)
        ConvTarget.DOCX -> docx(doc)
        ConvTarget.XLSX -> xlsx(doc)
        ConvTarget.PPTX -> pptx(doc)
        ConvTarget.ODT -> odt(doc)
        ConvTarget.ODS -> ods(doc)
        ConvTarget.ODP -> odp(doc)
        ConvTarget.PDF, ConvTarget.PNG_ZIP -> null
    }

    private fun zip(entries: List<Pair<String, String>>, mimetype: String? = null): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            if (mimetype != null) {
                val b = mimetype.toByteArray(Charsets.UTF_8)
                val e = ZipEntry("mimetype"); e.method = ZipEntry.STORED; e.size = b.size.toLong(); e.compressedSize = b.size.toLong()
                val crc = CRC32(); crc.update(b); e.crc = crc.value
                z.putNextEntry(e); z.write(b); z.closeEntry()
            }
            for ((n, c) in entries) { z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        }
        return bo.toByteArray()
    }

    // ---------------- Metin biçimleri ----------------
    fun txt(doc: Doc): String {
        val out = ArrayList<String>()
        doc.pages.forEachIndexed { i, p ->
            if (i > 0) out.add("")
            if (DocConvert.showTitle(doc, p)) out.add(p.title)
            out.addAll(p.paragraphs)
            p.table?.forEach { out.add(it.joinToString("\t")) }
        }
        return out.joinToString("\n")
    }

    fun md(doc: Doc): String {
        val sb = StringBuilder()
        doc.pages.forEachIndexed { i, p ->
            if (i > 0) sb.append('\n')
            if (DocConvert.showTitle(doc, p)) sb.append("## ").append(p.title.replace('\n', ' ')).append("\n\n")
            for (t in p.paragraphs) sb.append(t.replace("\n", "  \n")).append("\n\n")
            val rows = p.table?.let { DocConvert.padRows(it) }
            if (!rows.isNullOrEmpty() && rows[0].isNotEmpty()) {
                sb.append("| ").append(rows[0].joinToString(" | ") { DocConvert.mdCell(it) }).append(" |\n")
                sb.append("|").append(" --- |".repeat(rows[0].size)).append('\n')
                for (r in rows.drop(1)) sb.append("| ").append(r.joinToString(" | ") { DocConvert.mdCell(it) }).append(" |\n")
                sb.append('\n')
            }
        }
        return sb.toString().trimEnd() + "\n"
    }

    fun html(doc: Doc): String {
        val sb = StringBuilder("<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><title>")
        sb.append(DocConvert.xml(doc.pages.firstOrNull()?.title ?: "")).append("</title>")
        sb.append("<style>body{font-family:sans-serif;max-width:900px;margin:1em auto;padding:0 1em}table{border-collapse:collapse}td,th{border:1px solid #999;padding:4px 8px}</style></head><body>\n")
        for (p in doc.pages) {
            if (DocConvert.showTitle(doc, p)) sb.append("<h2>").append(DocConvert.xml(p.title)).append("</h2>\n")
            for (t in p.paragraphs) sb.append("<p>").append(DocConvert.xml(t).replace("\n", "<br>")).append("</p>\n")
            p.table?.let { rows ->
                sb.append("<table>\n")
                for (r in DocConvert.padRows(rows)) { sb.append("<tr>"); for (c in r) sb.append("<td>").append(DocConvert.xml(c).replace("\n", "<br>")).append("</td>"); sb.append("</tr>\n") }
                sb.append("</table>\n")
            }
        }
        return sb.append("</body></html>\n").toString()
    }

    fun csv(doc: Doc): String {
        val blocks = ArrayList<String>()
        for (p in doc.pages) {
            val lines = ArrayList<String>()
            if (doc.pages.size > 1 && p.title.isNotBlank()) lines.add(DocConvert.csvCell(p.title))
            for (t in p.paragraphs) lines.add(DocConvert.csvCell(t))
            p.table?.let { for (r in it) lines.add(r.joinToString(",") { c -> DocConvert.csvCell(c) }) }
            if (lines.isNotEmpty()) blocks.add(lines.joinToString("\r\n"))
        }
        return blocks.joinToString("\r\n\r\n") + (if (blocks.isEmpty()) "" else "\r\n")
    }

    fun rtf(doc: Doc): String {
        val sb = StringBuilder("{\\rtf1\\ansi\\ansicpg1254\\deff0\\uc1{\\fonttbl{\\f0\\fswiss Calibri;}}\\viewkind4\n")
        doc.pages.forEachIndexed { i, p ->
            if (i > 0) sb.append("\\page\n")
            if (DocConvert.showTitle(doc, p)) sb.append("\\pard\\b\\fs32 ").append(DocConvert.rtf(p.title)).append("\\b0\\fs22\\par\n")
            for (t in p.paragraphs) sb.append("\\pard ").append(DocConvert.rtf(t)).append("\\par\n")
            p.table?.let { rows ->
                val r2 = DocConvert.padRows(rows)
                val cols = r2.firstOrNull()?.size ?: 0
                if (cols > 0) {
                    val w = 9000 / cols
                    for (r in r2) {
                        sb.append("\\trowd\\trgaph108")
                        for (c in 1..cols) sb.append("\\clbrdrt\\brdrs\\clbrdrl\\brdrs\\clbrdrb\\brdrs\\clbrdrr\\brdrs\\cellx").append(c * w)
                        for (c in r) sb.append("\\pard\\intbl ").append(DocConvert.rtf(c)).append("\\cell")
                        sb.append("\\row\n")
                    }
                    sb.append("\\pard\\par\n")
                }
            }
        }
        return sb.append("}").toString()
    }

    // ---------------- DOCX ----------------
    private const val WNS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val RNS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"

    private fun wPara(t: String, bold: Boolean = false, size: Int = 0): String {
        val rpr = if (bold || size > 0) "<w:rPr>" + (if (bold) "<w:b/>" else "") + (if (size > 0) "<w:sz w:val=\"$size\"/>" else "") + "</w:rPr>" else ""
        val parts = DocConvert.xml(t).split("\n")
        val runs = parts.mapIndexed { i, s -> "<w:r>$rpr" + (if (i > 0) "<w:br/>" else "") + "<w:t xml:space=\"preserve\">$s</w:t></w:r>" }.joinToString("")
        return "<w:p>" + (if (bold) "<w:pPr><w:keepNext/></w:pPr>" else "") + runs + "</w:p>"
    }

    fun docx(doc: Doc): ByteArray {
        val sb = StringBuilder(XMLH).append("<w:document xmlns:w=\"$WNS\"><w:body>")
        doc.pages.forEachIndexed { i, p ->
            if (i > 0) sb.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
            if (DocConvert.showTitle(doc, p)) sb.append(wPara(p.title, bold = true, size = 32))
            for (t in p.paragraphs) sb.append(wPara(t))
            p.table?.let { rows ->
                val r2 = DocConvert.padRows(rows)
                val cols = r2.firstOrNull()?.size ?: 0
                if (cols > 0) {
                    val w = 9000 / cols
                    sb.append("<w:tbl><w:tblPr><w:tblBorders>")
                    for (b in listOf("top", "left", "bottom", "right", "insideH", "insideV")) sb.append("<w:$b w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"999999\"/>")
                    sb.append("</w:tblBorders></w:tblPr><w:tblGrid>")
                    repeat(cols) { sb.append("<w:gridCol w:w=\"$w\"/>") }
                    sb.append("</w:tblGrid>")
                    for (r in r2) {
                        sb.append("<w:tr>")
                        for (c in r) sb.append("<w:tc><w:tcPr><w:tcW w:w=\"$w\" w:type=\"dxa\"/></w:tcPr>").append(wPara(c)).append("</w:tc>")
                        sb.append("</w:tr>")
                    }
                    sb.append("</w:tbl><w:p/>")
                }
            }
        }
        if (doc.pages.isEmpty()) sb.append("<w:p/>")
        sb.append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"709\" w:footer=\"709\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>")
        return zip(listOf(
            "[Content_Types].xml" to (XMLH + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>"),
            "_rels/.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/officeDocument\" Target=\"word/document.xml\"/></Relationships>"),
            "word/document.xml" to sb.toString()
        ))
    }

    // ---------------- XLSX ----------------
    /** Her sayfa bir çalışma sayfasıdır: önce paragraflar (A sütunu), ardından tablo. */
    private fun sheetRows(p: DocPage): List<List<String>> = p.paragraphs.map { listOf(it) } + (p.table ?: emptyList())

    fun xlsx(doc: Doc): ByteArray {
        val pages = if (doc.pages.isEmpty()) listOf(DocPage("", emptyList())) else doc.pages
        val used = LinkedHashSet<String>()
        val names = pages.mapIndexed { i, p -> DocConvert.sheetName(p.title, i + 1, used).also { used.add(it) } }
        val ct = StringBuilder(XMLH + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
        val wb = StringBuilder(XMLH + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"$RNS\"><sheets>")
        val rels = StringBuilder(XMLH + "<Relationships xmlns=\"$PKG_REL\">")
        val files = ArrayList<Pair<String, String>>()
        pages.forEachIndexed { i, p ->
            val n = i + 1
            ct.append("<Override PartName=\"/xl/worksheets/sheet$n.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
            wb.append("<sheet name=\"${DocConvert.xml(names[i])}\" sheetId=\"$n\" r:id=\"rId$n\"/>")
            rels.append("<Relationship Id=\"rId$n\" Type=\"$RNS/worksheet\" Target=\"worksheets/sheet$n.xml\"/>")
            val sd = StringBuilder(XMLH + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
            sheetRows(p).take(3000).forEachIndexed { ri, row ->
                sd.append("<row r=\"${ri + 1}\">")
                row.take(60).forEachIndexed { ci, v ->
                    if (v.isEmpty()) return@forEachIndexed
                    val ref = DocConvert.colName(ci) + (ri + 1)
                    if (DocConvert.isPlainNumber(v)) sd.append("<c r=\"$ref\"><v>$v</v></c>")
                    else sd.append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${DocConvert.xml(v)}</t></is></c>")
                }
                sd.append("</row>")
            }
            sd.append("</sheetData></worksheet>")
            files.add("xl/worksheets/sheet$n.xml" to sd.toString())
        }
        ct.append("</Types>"); wb.append("</sheets></workbook>"); rels.append("</Relationships>")
        return zip(listOf(
            "[Content_Types].xml" to ct.toString(),
            "_rels/.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"),
            "xl/workbook.xml" to wb.toString(),
            "xl/_rels/workbook.xml.rels" to rels.toString()
        ) + files)
    }

    // ---------------- PPTX ----------------
    private const val ANS = "http://schemas.openxmlformats.org/drawingml/2006/main"
    private const val PNS = "http://schemas.openxmlformats.org/presentationml/2006/main"
    const val SLIDE_LINES = 16

    /** Slayt içeriği: başlık + satırlar. Uzun sayfalar SLIDE_LINES satırda bölünür ("(2)" ile devam eder). */
    class Slide(val title: String, val lines: List<String>)

    fun slides(doc: Doc): List<Slide> {
        val out = ArrayList<Slide>()
        for (p in doc.pages) {
            val lines = ArrayList<String>()
            lines.addAll(p.paragraphs)
            p.table?.forEach { r -> lines.add(r.joinToString("  |  ")) }
            val chunks = if (lines.isEmpty()) listOf(emptyList()) else lines.chunked(SLIDE_LINES)
            chunks.forEachIndexed { i, c -> out.add(Slide(if (i == 0) p.title else p.title + " (" + (i + 1) + ")", c)) }
        }
        return out
    }

    private fun aTextBox(id: Int, name: String, x: Int, y: Int, cx: Int, cy: Int, paras: List<String>, sz: Int, bold: Boolean): String {
        val body = if (paras.isEmpty()) "<a:p><a:endParaRPr lang=\"tr-TR\"/></a:p>" else paras.joinToString("") {
            "<a:p><a:r><a:rPr lang=\"tr-TR\" sz=\"$sz\"" + (if (bold) " b=\"1\"" else "") + " dirty=\"0\"/><a:t>${DocConvert.xml(it)}</a:t></a:r></a:p>"
        }
        return "<p:sp><p:nvSpPr><p:cNvPr id=\"$id\" name=\"$name\"/><p:cNvSpPr txBox=\"1\"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"$x\" y=\"$y\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr wrap=\"square\" rtlCol=\"0\"><a:normAutofit/></a:bodyPr><a:lstStyle/>$body</p:txBody></p:sp>"
    }

    private fun theme(): String {
        fun acc(n: Int, c: String) = "<a:accent$n><a:srgbClr val=\"$c\"/></a:accent$n>"
        val fill = "<a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>"
        return XMLH + "<a:theme xmlns:a=\"$ANS\" name=\"Atlas\"><a:themeElements><a:clrScheme name=\"Atlas\">" +
            "<a:dk1><a:sysClr val=\"windowText\" lastClr=\"000000\"/></a:dk1><a:lt1><a:sysClr val=\"window\" lastClr=\"FFFFFF\"/></a:lt1>" +
            "<a:dk2><a:srgbClr val=\"44546A\"/></a:dk2><a:lt2><a:srgbClr val=\"E7E6E6\"/></a:lt2>" +
            acc(1, "4472C4") + acc(2, "ED7D31") + acc(3, "A5A5A5") + acc(4, "FFC000") + acc(5, "5B9BD5") + acc(6, "70AD47") +
            "<a:hlink><a:srgbClr val=\"0563C1\"/></a:hlink><a:folHlink><a:srgbClr val=\"954F72\"/></a:folHlink></a:clrScheme>" +
            "<a:fontScheme name=\"Atlas\"><a:majorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:majorFont><a:minorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:minorFont></a:fontScheme>" +
            "<a:fmtScheme name=\"Atlas\"><a:fillStyleLst>$fill$fill$fill</a:fillStyleLst>" +
            "<a:lnStyleLst><a:ln w=\"6350\">$fill</a:ln><a:ln w=\"12700\">$fill</a:ln><a:ln w=\"19050\">$fill</a:ln></a:lnStyleLst>" +
            "<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>" +
            "<a:bgFillStyleLst>$fill$fill$fill</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>"
    }

    fun pptx(doc: Doc): ByteArray {
        val sl = slides(doc).ifEmpty { listOf(Slide("", emptyList())) }
        val ct = StringBuilder(XMLH + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/ppt/presentation.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml\"/>" +
            "<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml\"/>" +
            "<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>" +
            "<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>")
        val ids = StringBuilder(); val prels = StringBuilder(XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/slideMaster\" Target=\"slideMasters/slideMaster1.xml\"/><Relationship Id=\"rId2\" Type=\"$RNS/theme\" Target=\"theme/theme1.xml\"/>")
        val files = ArrayList<Pair<String, String>>()
        sl.forEachIndexed { i, s ->
            val n = i + 1
            ct.append("<Override PartName=\"/ppt/slides/slide$n.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>")
            ids.append("<p:sldId id=\"${256 + i}\" r:id=\"rId${n + 2}\"/>")
            prels.append("<Relationship Id=\"rId${n + 2}\" Type=\"$RNS/slide\" Target=\"slides/slide$n.xml\"/>")
            val n2 = s.lines.size
            val sz = when { n2 <= 6 -> 2400; n2 <= 10 -> 2000; else -> 1600 }
            val x = StringBuilder(XMLH + "<p:sld xmlns:a=\"$ANS\" xmlns:r=\"$RNS\" xmlns:p=\"$PNS\"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>")
            x.append(aTextBox(2, "Title", 609600, 304800, 10972800, 914400, if (s.title.isBlank()) emptyList() else listOf(s.title), 3200, true))
            x.append(aTextBox(3, "Body", 609600, 1371600, 10972800, 5029200, s.lines, sz, false))
            x.append("</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>")
            files.add("ppt/slides/slide$n.xml" to x.toString())
            files.add("ppt/slides/_rels/slide$n.xml.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/></Relationships>"))
        }
        ct.append("</Types>"); prels.append("</Relationships>")
        val grp = "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>"
        return zip(listOf(
            "[Content_Types].xml" to ct.toString(),
            "_rels/.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/officeDocument\" Target=\"ppt/presentation.xml\"/></Relationships>"),
            "ppt/presentation.xml" to (XMLH + "<p:presentation xmlns:a=\"$ANS\" xmlns:r=\"$RNS\" xmlns:p=\"$PNS\"><p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst><p:sldIdLst>$ids</p:sldIdLst><p:sldSz cx=\"12192000\" cy=\"6858000\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>"),
            "ppt/_rels/presentation.xml.rels" to prels.toString(),
            "ppt/slideMasters/slideMaster1.xml" to (XMLH + "<p:sldMaster xmlns:a=\"$ANS\" xmlns:r=\"$RNS\" xmlns:p=\"$PNS\"><p:cSld><p:bg><p:bgRef idx=\"1001\"><a:schemeClr val=\"bg1\"/></p:bgRef></p:bg><p:spTree>$grp</p:spTree></p:cSld><p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/><p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/></p:sldLayoutIdLst></p:sldMaster>"),
            "ppt/slideMasters/_rels/slideMaster1.xml.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/><Relationship Id=\"rId2\" Type=\"$RNS/theme\" Target=\"../theme/theme1.xml\"/></Relationships>"),
            "ppt/slideLayouts/slideLayout1.xml" to (XMLH + "<p:sldLayout xmlns:a=\"$ANS\" xmlns:r=\"$RNS\" xmlns:p=\"$PNS\" type=\"blank\" preserve=\"1\"><p:cSld name=\"Blank\"><p:spTree>$grp</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>"),
            "ppt/slideLayouts/_rels/slideLayout1.xml.rels" to (XMLH + "<Relationships xmlns=\"$PKG_REL\"><Relationship Id=\"rId1\" Type=\"$RNS/slideMaster\" Target=\"../slideMasters/slideMaster1.xml\"/></Relationships>"),
            "ppt/theme/theme1.xml" to theme()
        ) + files)
    }

    // ---------------- ODF ----------------
    private const val ONS = "xmlns:office=\"urn:oasis:names:tc:opendocument:xmlns:office:1.0\" xmlns:text=\"urn:oasis:names:tc:opendocument:xmlns:text:1.0\" xmlns:table=\"urn:oasis:names:tc:opendocument:xmlns:table:1.0\" xmlns:draw=\"urn:oasis:names:tc:opendocument:xmlns:drawing:1.0\" xmlns:svg=\"urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0\" xmlns:fo=\"urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0\" office:version=\"1.2\""

    /** ODF metni: çoklu boşluk → text:s, sekme → text:tab, satır sonu → text:line-break. */
    fun odfText(s: String): String {
        val x = DocConvert.xml(s)
        val sb = StringBuilder()
        var i = 0
        while (i < x.length) {
            val c = x[i]
            when {
                c == ' ' -> { var j = i; while (j < x.length && x[j] == ' ') j++; val n = j - i
                    if (n == 1 && i > 0) sb.append(' ') else sb.append(if (i > 0) " " else "").append(if (n - (if (i > 0) 1 else 0) > 0) "<text:s text:c=\"${n - (if (i > 0) 1 else 0)}\"/>" else ""); i = j; continue }
                c == '\t' -> sb.append("<text:tab/>")
                c == '\n' -> sb.append("<text:line-break/>")
                c == '\r' -> {}
                else -> sb.append(c)
            }
            i++
        }
        return sb.toString()
    }

    private fun odfPack(mime: String, body: String): ByteArray = zip(listOf(
        "content.xml" to (XMLH + "<office:document-content $ONS><office:body>$body</office:body></office:document-content>"),
        "META-INF/manifest.xml" to (XMLH + "<manifest:manifest xmlns:manifest=\"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0\" manifest:version=\"1.2\"><manifest:file-entry manifest:full-path=\"/\" manifest:media-type=\"$mime\"/><manifest:file-entry manifest:full-path=\"content.xml\" manifest:media-type=\"text/xml\"/></manifest:manifest>")
    ), mimetype = mime)

    fun odt(doc: Doc): ByteArray {
        val sb = StringBuilder("<office:text>")
        var tn = 0
        for (p in doc.pages) {
            if (DocConvert.showTitle(doc, p)) sb.append("<text:h text:outline-level=\"1\">").append(odfText(p.title)).append("</text:h>")
            for (t in p.paragraphs) sb.append("<text:p>").append(odfText(t)).append("</text:p>")
            p.table?.let { rows ->
                val r2 = DocConvert.padRows(rows)
                val cols = r2.firstOrNull()?.size ?: 0
                if (cols > 0) {
                    tn++
                    sb.append("<table:table table:name=\"Tablo$tn\"><table:table-column table:number-columns-repeated=\"$cols\"/>")
                    for (r in r2) { sb.append("<table:table-row>"); for (c in r) sb.append("<table:table-cell office:value-type=\"string\"><text:p>").append(odfText(c)).append("</text:p></table:table-cell>"); sb.append("</table:table-row>") }
                    sb.append("</table:table>")
                }
            }
        }
        sb.append("</office:text>")
        return odfPack("application/vnd.oasis.opendocument.text", sb.toString())
    }

    fun ods(doc: Doc): ByteArray {
        val pages = if (doc.pages.isEmpty()) listOf(DocPage("", emptyList())) else doc.pages
        val used = LinkedHashSet<String>()
        val sb = StringBuilder("<office:spreadsheet>")
        pages.forEachIndexed { i, p ->
            val name = DocConvert.sheetName(p.title, i + 1, used).also { used.add(it) }
            val rows = DocConvert.padRows(sheetRows(p).take(3000).ifEmpty { listOf(listOf("")) })
            val cols = rows.maxOf { it.size }.coerceAtLeast(1)
            sb.append("<table:table table:name=\"${DocConvert.xml(name)}\"><table:table-column table:number-columns-repeated=\"$cols\"/>")
            for (r in rows) {
                sb.append("<table:table-row>")
                for (c in r.ifEmpty { listOf("") }) {
                    if (c.isEmpty()) sb.append("<table:table-cell/>")
                    else if (DocConvert.isPlainNumber(c)) sb.append("<table:table-cell office:value-type=\"float\" office:value=\"$c\"><text:p>$c</text:p></table:table-cell>")
                    else sb.append("<table:table-cell office:value-type=\"string\"><text:p>").append(odfText(c)).append("</text:p></table:table-cell>")
                }
                sb.append("</table:table-row>")
            }
            sb.append("</table:table>")
        }
        sb.append("</office:spreadsheet>")
        return odfPack("application/vnd.oasis.opendocument.spreadsheet", sb.toString())
    }

    fun odp(doc: Doc): ByteArray {
        val sl = slides(doc).ifEmpty { listOf(Slide("", emptyList())) }
        val sb = StringBuilder("<office:presentation>")
        sl.forEachIndexed { i, s ->
            sb.append("<draw:page draw:name=\"page${i + 1}\">")
            sb.append("<draw:frame svg:x=\"1.5cm\" svg:y=\"1cm\" svg:width=\"22cm\" svg:height=\"2.5cm\"><draw:text-box><text:p>").append(odfText(s.title)).append("</text:p></draw:text-box></draw:frame>")
            sb.append("<draw:frame svg:x=\"1.5cm\" svg:y=\"4cm\" svg:width=\"22cm\" svg:height=\"12cm\"><draw:text-box>")
            for (l in s.lines) sb.append("<text:p>").append(odfText(l)).append("</text:p>")
            if (s.lines.isEmpty()) sb.append("<text:p/>")
            sb.append("</draw:text-box></draw:frame></draw:page>")
        }
        sb.append("</office:presentation>")
        return odfPack("application/vnd.oasis.opendocument.presentation", sb.toString())
    }
}
