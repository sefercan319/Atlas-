package com.odak.app.block

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.ThemedHeader
import com.odak.app.theme.plainClick
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun BlockScreen() {
    val ctx = LocalContext.current
    var locked by remember { mutableStateOf(Pin.locked(ctx)) }
    if (locked) PinGate(stringResource(R.string.pin_title)) { locked = false } else BlockContent()
}

@Composable
private fun BlockContent() {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(BlockStore.a11yEnabled(ctx)) }
    var tick by remember { mutableIntStateOf(0) }
    var used by remember { mutableStateOf(emptyMap<String, Long>()) }
    var cooldown by remember { mutableStateOf<(() -> Unit)?>(null) }
    var picker by remember { mutableStateOf(false) }
    var lab by remember { mutableStateOf<Pair<String, String>?>(null) }
    lab?.let { RuleLabDialog(it.first, it.second) { lab = null; tick++ } }
    var appQ by remember { mutableStateOf("") }
    var onlyActive by rememberSaveable { mutableStateOf(false) }
    val PAGE = 20
    var shown by remember(appQ, onlyActive) { mutableIntStateOf(PAGE) }
    val allApps = BlockCatalog.apps
    val filtered = remember(appQ, tick, allApps.size, onlyActive) {
        allApps.filter { com.odak.app.logic.Pure.nameMatches(it.name, appQ) && (!onlyActive || BlockStore.isActiveApp(ctx, it)) }
    }
    LaunchedEffect(Unit) { BlockCatalog.loadCustom(ctx) }
    if (picker) CustomAppPicker { picker = false; tick++ }
    cooldown?.let { act -> CooldownDialog({ act(); cooldown = null }, { cooldown = null }) }

    LaunchedEffect(Unit) {
        while (true) {
            enabled = BlockStore.a11yEnabled(ctx)
            if (BlockStore.usageAccess(ctx)) used = withContext(Dispatchers.IO) { BlockStore.usageToday(ctx) }
            tick++
            delay(2000)
        }
    }
    val openSettings = {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(16.dp))
            ThemedHeader(stringResource(R.string.tab_block))
        }
        item {
            com.odak.app.theme.ThemedTextField(appQ, { appQ = it }, "🔍 " + stringResource(R.string.app_search), Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            ThemedButton((if (onlyActive) "✔ " else "") + stringResource(R.string.blk_only_active), { onlyActive = !onlyActive })
        }
        if (!enabled) {
            item {
                ThemedCard(Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.block_perm_needed))
                    Spacer(Modifier.height(10.dp))
                    ThemedButton(stringResource(R.string.block_grant), openSettings)
                }
            }
        }
        item {
            val until = BlockStore.focusUntil(ctx)
            val left = ((until - System.currentTimeMillis()) / 60_000L).toInt() + 1
            ThemedCard(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.focus_title), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                if (BlockStore.focusActive(ctx)) {
                    Text(stringResource(R.string.focus_left) + ": " + stringResource(R.string.fmt_min, left))
                    val endAt = java.time.Instant.ofEpochMilli(until).atZone(java.time.ZoneId.systemDefault()).toLocalTime()
                    Text(
                        stringResource(R.string.focus_ends) + ": " + "%02d:%02d".format(endAt.hour, endAt.minute),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ThemedButton("+" + stringResource(R.string.fmt_min, com.odak.app.logic.Pure.FOCUS_EXTEND_MIN) + " " + stringResource(R.string.focus_extend), {
                            val ext = com.odak.app.logic.Pure.focusExtend(until, System.currentTimeMillis(), com.odak.app.logic.Pure.FOCUS_EXTEND_MIN)
                            BlockStore.setFocusUntil(ctx, ext)
                            com.odak.app.notify.Reminders.scheduleAt(ctx, "focus_end", ctx.getString(R.string.focus_done_title), com.odak.app.notify.Msgs.text(ctx, "focus", ""), ext)
                            tick++
                        })
                        ThemedButton(stringResource(R.string.focus_stop), {
                            BlockStore.setFocusUntil(ctx, 0L)
                            com.odak.app.notify.Reminders.cancelId(ctx, "focus_end")
                            tick++
                        })
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(25, 45, 60).forEach { m ->
                            ThemedButton("▶ " + stringResource(R.string.fmt_min, m), {
                                if (!enabled) openSettings()
                                else {
                                    val until2 = System.currentTimeMillis() + m * 60_000L
                                    BlockStore.setFocusUntil(ctx, until2)
                                    com.odak.app.notify.Reminders.scheduleAt(ctx, "focus_end", ctx.getString(R.string.focus_done_title), com.odak.app.notify.Msgs.text(ctx, "focus", ""), until2)
                                    tick++
                                }
                            })
                        }
                    }
                }
            }
        }
        item {
            Text(
                stringResource(R.string.blk_today, BlockStore.blockedToday(ctx).also { tick }),
                style = MaterialTheme.typography.bodySmall
            )
        }
        item { AlertsCard() }
        item { ScreensCard() }
        item { NotifHideCard() }
        item { LearnCard(tick) { tick++ } }
        item {
            val q = BlockStore.quietOn(ctx)
            ThemedCard(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.quiet_title), style = MaterialTheme.typography.titleMedium)
                ToggleRow(stringResource(R.string.quiet_apply), enabled && q) {
                    if (!enabled) openSettings() else { BlockStore.setQuietOn(ctx, it); tick++ }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween) {
                    val mask = BlockStore.quietDays(ctx)
                    for (i in 0..6) {
                        val on = (mask shr i) and 1 == 1
                        val tk = com.odak.app.theme.LocalDesign.current.tokens
                        androidx.compose.foundation.layout.Box(
                            Modifier.size(34.dp)
                                .background(if (on) tk.primary else tk.text.copy(alpha = 0.12f), androidx.compose.foundation.shape.CircleShape)
                                .plainClick { BlockStore.setQuietDays(ctx, mask xor (1 shl i)); tick++ },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                java.time.DayOfWeek.of(i + 1).getDisplayName(java.time.format.TextStyle.NARROW, java.util.Locale.getDefault()),
                                color = if (on) tk.surface else tk.text
                            )
                        }
                    }
                }
                run {
                    val now = java.time.LocalTime.now().let { it.hour * 60 + it.minute }
                    val st = com.odak.app.logic.Pure.quietState(
                        BlockStore.quietOn(ctx), now, BlockStore.quietFrom(ctx), BlockStore.quietTo(ctx),
                        java.time.LocalDate.now().dayOfWeek.value - 1, BlockStore.quietDays(ctx)
                    )
                    Text(
                        stringResource(
                            when (st) {
                                com.odak.app.logic.Pure.QuietState.ACTIVE -> R.string.quiet_state_active
                                com.odak.app.logic.Pure.QuietState.SAME_TIMES -> R.string.quiet_state_same
                                else -> R.string.quiet_state_idle
                            }
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (st == com.odak.app.logic.Pure.QuietState.SAME_TIMES) MaterialTheme.colorScheme.error else Color.Unspecified
                    )
                }
                TimeStep(BlockStore.quietFrom(ctx)) { BlockStore.setQuietFrom(ctx, it); tick++ }
                TimeStep(BlockStore.quietTo(ctx)) { BlockStore.setQuietTo(ctx, it); tick++ }
            }
        }
        itemsIndexed(filtered.take(shown), key = { _, a -> a.id }) { idx, app ->
            // Listenin sonuna gelince sıradaki 20 uygulama yüklenir
            if (idx == shown - 1 && shown < filtered.size) LaunchedEffect(shown, appQ, onlyActive) { shown += PAGE }
            var open by rememberSaveable(app.id) { mutableStateOf(false) }
            val rev = tick // tercih değişince yeniden okumak için
            val whole = BlockStore.isAppBlocked(ctx, app.id)
            ThemedCard(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().plainClick { open = !open }.padding(vertical = 4.dp),
                    Arrangement.SpaceBetween,
                    Alignment.CenterVertically
                ) {
                    Text(
                        (if (whole) "⛔ " else "") + app.name,
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.titleMedium
                    )
                    val ms = app.packages.sumOf { used[it] ?: 0L }
                    if (ms >= 60_000) Text("${ms / 60_000}m  ", style = MaterialTheme.typography.bodySmall)
                    Text(if (open) "▾" else "▸")
                }
                Spacer(Modifier.height(6.dp))
                ToggleRow(stringResource(R.string.block_whole), enabled && whole) {
                    if (!enabled) openSettings()
                    else if (!it && whole) cooldown = { BlockStore.setAppBlocked(ctx, app.id, false); tick++ }
                    else {
                        BlockStore.setAppBlocked(ctx, app.id, it)
                        tick++
                    }
                }
                if (open) ToggleRow(stringResource(R.string.quiet_apply), enabled && BlockStore.appQuiet(ctx, app.id)) {
                    if (!enabled) openSettings() else { BlockStore.setAppQuiet(ctx, app.id, it); tick++ }
                }
                if (open) LimitRow(
                    stringResource(R.string.limit_daily),
                    BlockStore.appLimit(ctx, app.id),
                    usedMin = (app.packages.sumOf { used[it] ?: 0L } / 60_000).toInt()
                ) { BlockStore.setAppLimit(ctx, app.id, it); tick++ }
                if (open && app.id.startsWith("c:")) {
                    Spacer(Modifier.height(6.dp))
                    ThemedButton("🗑", { BlockCatalog.removeCustom(ctx, app.id); tick++ })
                }
                if (open) app.features.forEach { f ->
                    val label = f.res?.let { stringResource(it) } ?: f.text.orEmpty()
                    val on = enabled && BlockStore.isFeatureBlocked(ctx, app.id, f.id)
                    ToggleRow(label, on, Modifier.alpha(if (whole) 0.45f else 1f)) {
                        if (!enabled) openSettings()
                        else if (!it && on) cooldown = { BlockStore.setFeatureBlocked(ctx, app.id, f.id, false); tick++ }
                        else {
                            BlockStore.setFeatureBlocked(ctx, app.id, f.id, it)
                            tick++
                        }
                    }
                    ThemedButton("🎯 " + stringResource(R.string.rl_title), { lab = app.id to f.id })
                    LimitRow(
                        stringResource(R.string.limit_daily),
                        BlockStore.featLimit(ctx, app.id, f.id),
                        Modifier.padding(start = 12.dp),
                        usedMin = (BlockStore.featUsedMs(ctx, app.id, f.id) / 60_000).toInt()
                    ) { BlockStore.setFeatLimit(ctx, app.id, f.id, it); tick++ }
                }
            }
        }
        item { ThemedButton("➕ " + stringResource(R.string.custom_app_add), { picker = true }) }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    modifier: Modifier = Modifier,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier.fillMaxWidth().padding(vertical = 6.dp),
        Arrangement.SpaceBetween,
        Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f))
        ThemedCheck(checked, onChange)
    }
}

/** − 5 dk + ; 0 = sınırsız. */
@Composable
private fun LimitRow(
    label: String,
    minutes: Int,
    modifier: Modifier = Modifier,
    usedMin: Int = 0,
    onChange: (Int) -> Unit
) {
    Row(
        modifier.fillMaxWidth().padding(bottom = 4.dp),
        Arrangement.SpaceBetween,
        Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
        ThemedButton("−", { onChange((minutes - 5).coerceAtLeast(0)) })
        // Sınıra ulaşınca metin kırmızılaşır ve ✖ işareti eklenir (renge tek başına bağlı kalmamak için).
        val reached = minutes > 0 && com.odak.app.logic.Pure.limitReached(usedMin * 60_000L, minutes)
        Text(
            if (minutes == 0) stringResource(R.string.limit_none)
            else (if (reached) "✖ " else "") + "$usedMin / " + stringResource(R.string.fmt_min, minutes),
            Modifier.padding(horizontal = 8.dp),
            color = if (reached) MaterialTheme.colorScheme.error else Color.Unspecified,
            style = MaterialTheme.typography.bodySmall
        )
        ThemedButton("+", { onChange((minutes + 5).coerceAtMost(600)) })
    }
}

/** − 30 dk + */
@Composable
private fun TimeStep(minutes: Int, onChange: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        Arrangement.SpaceBetween,
        Alignment.CenterVertically
    ) {
        ThemedButton("−", { onChange(com.odak.app.logic.Pure.stepTime(minutes, -com.odak.app.logic.Pure.TIME_STEP_MIN)) })
        Text(com.odak.app.plan.fmtTime(minutes), style = MaterialTheme.typography.titleMedium)
        ThemedButton("+", { onChange(com.odak.app.logic.Pure.stepTime(minutes, com.odak.app.logic.Pure.TIME_STEP_MIN)) })
    }
}

@Composable
private fun LearnCard(rev: Int, onChange: () -> Unit) {
    val ctx = LocalContext.current
    val import = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() }
            if (text != null) BlockStore.importRules(ctx, text)
        }
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        ToggleRow(stringResource(R.string.learn_title), BlockStore.learnOn(ctx)) {
            BlockStore.setLearnOn(ctx, it)
            onChange()
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ThemedButton(stringResource(R.string.learn_share), {
                val send = Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, BlockStore.seenText(ctx).lines().takeLast(600).joinToString("\n"))
                ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
            ThemedButton(stringResource(R.string.learn_clear), { BlockStore.clearSeen(ctx); onChange() })
        }
        Spacer(Modifier.height(6.dp))
        ThemedButton(stringResource(R.string.rules_import), { import.launch(arrayOf("application/json", "*/*")) })
    }
}

/** Engeli kapatmadan önce 10 sn bekleme: dürtüyle kapatmayı zorlaştırır. */
@Composable
private fun CooldownDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    var left by remember { mutableIntStateOf(10) }
    LaunchedEffect(Unit) {
        while (left > 0) {
            delay(1000)
            left--
        }
    }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            if (left == 0) ThemedButton(stringResource(R.string.pin_ok), onConfirm) else Text("$left")
        },
        dismissButton = { ThemedButton("✕", onDismiss) },
        text = { Text(stringResource(R.string.motiv_1)) }
    )
}
