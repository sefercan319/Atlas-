package com.odak.app.theme

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.graphics.Color

/** Tasarım başına kullanıcı renkleri. Durum tabanlı: değişince arayüz kendini yeniler. */
object ColorPrefs {
    private const val PREFS = "odak_colors"
    private val primary = mutableStateMapOf<String, Int>()
    private val accent = mutableStateMapOf<String, Int>()

    fun init(c: Context) {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        for (s in DesignStyle.entries) {
            if (p.contains("${s.key}:p")) primary[s.key] = p.getInt("${s.key}:p", 0)
            if (p.contains("${s.key}:a")) accent[s.key] = p.getInt("${s.key}:a", 0)
        }
    }

    fun primaryOf(s: DesignStyle): Color? = primary[s.key]?.let { Color(it) }
    fun accentOf(s: DesignStyle): Color? = accent[s.key]?.let { Color(it) }

    fun setPrimary(c: Context, s: DesignStyle, argb: Int) {
        primary[s.key] = argb
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("${s.key}:p", argb).apply()
    }

    fun setAccent(c: Context, s: DesignStyle, argb: Int) {
        accent[s.key] = argb
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("${s.key}:a", argb).apply()
    }

    fun reset(c: Context, s: DesignStyle) {
        primary.remove(s.key)
        accent.remove(s.key)
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove("${s.key}:p").remove("${s.key}:a").apply()
    }
}
