package com.odak.app.theme

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Tasarımın küçük, canlı önizlemesi: gerçek bileşenler, dokununca kendi animasyonu ve sesi. */
@Composable
fun ThemePreview(style: DesignStyle, modifier: Modifier = Modifier) {
    val design = Design(style)
    val t = design.tokens
    CompositionLocalProvider(LocalDesign provides design) {
        MaterialTheme(typography = typographyFor(style)) {
            Box(modifier.height(150.dp).clip(RoundedCornerShape(12.dp))) {
                ThemedBackground(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemedCard(Modifier.fillMaxWidth()) {
                            var on by remember { mutableStateOf(true) }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ThemedCheck(on) { on = it }
                                Spacer(Modifier.width(10.dp))
                                Text("08:30  ${style.label}", color = t.text, fontSize = 13.sp)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemedButton("OK", {}, sound = SoundKind.SUCCESS)
                            ThemedButton("＋", {})
                            ThemedButton("🗑", {}, sound = SoundKind.DELETE)
                        }
                    }
                }
            }
        }
    }
}
