package com.odak.app.docs

import android.content.ActivityNotFoundException
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ClickSound
import com.odak.app.theme.ColorPrefs
import com.odak.app.theme.Design
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.ThemePrefs
import com.odak.app.theme.ThemedBackground
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedTextField
import com.odak.app.theme.UiScale
import com.odak.app.theme.modeInvert
import com.odak.app.theme.tokensFor
import com.odak.app.theme.typographyFor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

/** Belge okuyucu: PDF (PdfRenderer) ve DocParse ile çözülen biçimler. */
class DocActivity : ComponentActivity() {
    private var incoming by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ClickSound.init(applicationContext)
        ColorPrefs.init(applicationContext)
        UiScale.init(applicationContext)
        ClickSound.enabled = getSharedPreferences("odak_app", MODE_PRIVATE).getBoolean("sound", true)
        ClickSound.haptic = getSharedPreferences("odak_app", MODE_PRIVATE).getBoolean("haptic", true)
        incoming = intent?.data
        val style = ThemePrefs.load(this)
        setContent {
            com.odak.app.theme.ProvideUiScale {
                CompositionLocalProvider(LocalDesign provides Design(style)) {
                    MaterialTheme(typography = typographyFor(style)) {
                        ThemedBackground(
                            Modifier.fillMaxSize().modeInvert(
                                com.odak.app.theme.ThemeMode.shouldInvert(style, com.odak.app.theme.ThemeMode.load(this@DocActivity))
                            )
                        ) {
                            DocScreen(incoming)
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        incoming = intent.data
    }
}

private sealed class DocState {
    object None : DocState()
    object Busy : DocState()
    class Err(val res: Int) : DocState()
    class Text(val name: String, val uri: Uri, val doc: Doc, val media: MediaSource? = null) : DocState() {
        fun close() { try { media?.close() } catch (e: Exception) { } }
    }
    /** 256 MB üstü düz metin: pencere pencere okunur. */
    class Big(val name: String, val uri: Uri, val size: Long, val pfd: ParcelFileDescriptor) : DocState() {
        fun close() { try { pfd.close() } catch (e: Exception) { } }
    }
    class Pdf(val name: String, val uri: Uri, val renderer: PdfRenderer, val pfd: ParcelFileDescriptor) : DocState() {
        fun close() {
            try { renderer.close() } catch (e: Exception) { }
            try { pfd.close() } catch (e: Exception) { }
        }
    }
}

private fun queryName(cr: ContentResolver, uri: Uri): String? = try {
    cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    }
} catch (e: Exception) {
    null
}

private fun readCapped(cr: ContentResolver, uri: Uri): ByteArray? {
    val input = cr.openInputStream(uri) ?: return null
    input.use { s ->
        val bo = java.io.ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        var total = 0
        while (true) {
            val r = s.read(buf)
            if (r < 0) break
            total += r
            if (total > DocParse.MAX_BYTES) return null
            bo.write(buf, 0, r)
        }
        return bo.toByteArray()
    }
}

/** Bu boyuttan büyük dosyalar bellekte tutulmaz; dosya olarak açılıp parça parça okunur. */
private const val BIG_AT = 32L * 1024 * 1024

/** Büyük dosya: önce /proc/self/fd üzerinden doğrudan (kopyasız) açılır; olmazsa cache'e akıtılır (yer yoksa açılamaz).
 *  Resimler için ZipFile oturum boyunca açık tutulur (tembel okuma). */
private fun loadBig(ctx: Context, uri: Uri, name: String, size: Long): Pair<Doc, MediaSource?> {
    val cr = ctx.contentResolver
    fun needsMedia(d: Doc) = d.pages.any { it.visuals?.images?.isNotEmpty() == true }
    try {
        cr.openFileDescriptor(uri, "r")?.use { pfd ->
            val f = File("/proc/self/fd/" + pfd.fd)
            if (f.canRead()) {
                val d = DocParse.parseFile(name, f)
                if (d.pages.isNotEmpty() || d.kind == DocKind.UNKNOWN && size > DocParse.MAX_BYTES) {
                    val m = if (needsMedia(d)) try { FileMedia(f) } catch (e: Exception) { null } else null
                    return d to m
                }
            }
        }
    } catch (e: Exception) { }
    val dir = File(ctx.cacheDir, "bigdoc").also { it.mkdirs() }
    dir.listFiles()?.forEach { it.delete() }
    if (dir.usableSpace < size + 64L * 1024 * 1024) return Doc(DocKind.UNKNOWN, emptyList()) to null
    val tmp = File(dir, "src.bin")
    return try {
        cr.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
        val d = DocParse.parseFile(name, tmp)
        val m = if (needsMedia(d)) try { FileMedia(tmp) { tmp.delete() } } catch (e: Exception) { null } else null
        if (m == null) tmp.delete()
        d to m
    } catch (e: Exception) {
        tmp.delete()
        Doc(DocKind.UNKNOWN, emptyList()) to null
    }
}

private fun loadDoc(ctx: Context, uri: Uri): DocState {
    val cr = ctx.contentResolver
    val name = queryName(cr, uri) ?: uri.lastPathSegment ?: "document"
    return try {
        val head = ByteArray(16)
        val n = cr.openInputStream(uri)?.use { it.read(head) } ?: return DocState.Err(R.string.doc_error)
        val kind = DocParse.detect(name, head.copyOf(maxOf(n, 0)))
        if (kind == DocKind.PDF) {
            val pfd = cr.openFileDescriptor(uri, "r") ?: return DocState.Err(R.string.doc_error)
            try {
                DocState.Pdf(name, uri, PdfRenderer(pfd), pfd)
            } catch (e: Exception) {
                try { pfd.close() } catch (x: Exception) { }
                DocState.Err(R.string.doc_pdf_error)
            }
        } else {
            val size = try { cr.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L } catch (e: Exception) { -1L }
            if (size > DocParse.MAX_BYTES && kind == DocKind.TEXT) {
                val pfd = cr.openFileDescriptor(uri, "r") ?: return DocState.Err(R.string.doc_error)
                return DocState.Big(name, uri, size, pfd)
            }
            if (size > BIG_AT) {
                val (d, m) = loadBig(ctx, uri, name, size)
                if (d.kind == DocKind.UNKNOWN && d.pages.isEmpty()) return DocState.Err(R.string.doc_toobig)
                return DocState.Text(name, uri, d, m)
            }
            val bytes = readCapped(cr, uri) ?: return DocState.Err(R.string.doc_toobig)
            val doc = DocParse.parse(name, bytes)
            val m = if (doc.pages.any { it.visuals?.images?.isNotEmpty() == true }) BytesMedia(bytes) else null
            DocState.Text(name, uri, doc, m)
        }
    } catch (e: Exception) {
        DocState.Err(R.string.doc_error)
    }
}

private fun loadRecents(ctx: Context): List<Pair<String, String>> = try {
    val a = JSONArray(ctx.getSharedPreferences("odak_app", Context.MODE_PRIVATE).getString("doc_recent", "[]"))
    (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getString("u") to o.getString("n") } }
} catch (e: Exception) {
    emptyList()
}

private fun saveRecents(ctx: Context, list: List<Pair<String, String>>) {
    val a = JSONArray()
    list.forEach { a.put(JSONObject().put("u", it.first).put("n", it.second)) }
    ctx.getSharedPreferences("odak_app", Context.MODE_PRIVATE).edit().putString("doc_recent", a.toString()).apply()
}

private fun openExternal(ctx: Context, uri: Uri, name: String) {
    val ext = DocParse.extOf(name)
    val mime = ctx.contentResolver.getType(uri)
        ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    try {
        ctx.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                name
            )
        )
    } catch (e: ActivityNotFoundException) {
    } catch (e: Exception) {
    }
}

@Composable
private fun DocScreen(incoming: Uri?) {
    val ctx = LocalContext.current
    val tk = LocalDesign.current.tokens
    var uri by remember { mutableStateOf<Uri?>(null) }
    var state by remember { mutableStateOf<DocState>(DocState.None) }
    var recents by remember { mutableStateOf(loadRecents(ctx)) }
    var query by remember { mutableStateOf("") }
    var zoom by remember { mutableStateOf(1f) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val persisted = try {
                ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); true
            } catch (e: Exception) { false }
            uri = u
            if (persisted) {
                val nm = queryName(ctx.contentResolver, u) ?: u.lastPathSegment ?: "document"
                recents = DocParse.addRecent(recents, u.toString() to nm)
                saveRecents(ctx, recents)
            }
        }
    }
    LaunchedEffect(incoming) { if (incoming != null) uri = incoming }
    LaunchedEffect(uri) {
        val u = uri ?: return@LaunchedEffect
        state = DocState.Busy
        query = ""
        zoom = 1f
        state = withContext(Dispatchers.IO) { loadDoc(ctx, u) }
    }
    val cur = state
    DisposableEffect(cur) { onDispose { (cur as? DocState.Pdf)?.close(); (cur as? DocState.Text)?.close(); (cur as? DocState.Big)?.close() } }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("📄 " + stringResource(R.string.doc_title), color = tk.text, style = MaterialTheme.typography.titleLarge)
            ThemedButton("📂 " + stringResource(R.string.doc_open), { picker.launch(arrayOf("*/*")) })
        }
        Spacer(Modifier.height(8.dp))
        when (cur) {
            is DocState.None -> {
                Text(stringResource(R.string.doc_hint), color = tk.text, style = MaterialTheme.typography.bodyMedium)
                if (recents.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text(stringResource(R.string.doc_recent), color = tk.text, style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(recents) { (u, n) ->
                            ThemedCard(Modifier.fillMaxWidth(), onClick = { uri = Uri.parse(u) }) {
                                Text(n, color = tk.text, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                            }
                        }
                    }
                }
            }
            is DocState.Busy -> Text("…", color = tk.text)
            is DocState.Err -> Text(stringResource(cur.res), color = tk.text, style = MaterialTheme.typography.bodyMedium)
            is DocState.Pdf -> PdfView(cur, zoom, { zoom = it })
            is DocState.Text -> TextView(cur, query, { query = it })
            is DocState.Big -> BigTextView(cur)
        }
    }
}

/** Dosya kaydetme penceresi: (önerilen ad, MIME) alır, seçilen adresi döner. */
private class SaveAs : ActivityResultContract<Pair<String, String>, Uri?>() {
    override fun createIntent(context: Context, input: Pair<String, String>): Intent =
        Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(input.second).putExtra(Intent.EXTRA_TITLE, input.first)
    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        if (resultCode == android.app.Activity.RESULT_OK) intent?.data else null
}

/** Dönüştür düğmesi: hedef biçimi seç → arka planda üret → "Farklı kaydet" penceresiyle kaydet. */
@Composable
private fun ConvertBar(name: String, kind: DocKind, doc: Doc?, renderer: PdfRenderer?, uri: Uri? = null) {
    val ctx = LocalContext.current
    val tk = LocalDesign.current.tokens
    val scope = rememberCoroutineScope()
    var open by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<File?>(null) }
    val targets = remember(kind, doc, renderer) { DocConvert.targetsFor(kind, (doc?.pages?.isNotEmpty() == true) || renderer != null) }
    val done = stringResource(R.string.conv_done)
    val fail = stringResource(R.string.conv_fail)
    val nopick = stringResource(R.string.conv_nopick)
    val scanned = stringResource(R.string.conv_scanned)
    fun toast(m: String) = android.widget.Toast.makeText(ctx, m, android.widget.Toast.LENGTH_SHORT).show()
    val saver = rememberLauncherForActivityResult(SaveAs()) { u ->
        val f = pending
        pending = null
        if (u == null || f == null) { f?.delete(); toast(nopick) }
        else scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try { ctx.contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } } != null } catch (e: Exception) { false }
            }
            f.delete()
            toast(if (ok) done else fail)
        }
    }
    fun convert(t: ConvTarget) {
        scope.launch {
            busy = true
            var noText = false
            val f = withContext(Dispatchers.IO) {
                try {
                    val dir = File(ctx.cacheDir, "convert").also { it.mkdirs() }
                    dir.listFiles()?.forEach { it.delete() }
                    val out = File(dir, "out." + t.ext)
                    var ok = true
                    if (t == ConvTarget.PNG_ZIP && renderer != null) DocPdf.pdfToPngZip(renderer, out)
                    else {
                        val d = doc ?: if (renderer != null && uri != null) DocPdf.extractText(ctx, uri) else null
                        if (d != null && d.pages.isEmpty()) { noText = true; ok = false }
                        else if (d == null) ok = false
                        else if (t == ConvTarget.PDF) DocPdf.write(d, out)
                        else out.writeBytes(DocWrite.write(d, t) ?: ByteArray(0))
                    }
                    if (ok && out.length() > 0) out else null
                } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }
            }
            busy = false
            if (f == null) toast(if (noText) scanned else fail) else { pending = f; saver.launch(DocConvert.outName(name, t) to t.mime) }
        }
    }
    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(6.dp), Alignment.CenterVertically) {
        ThemedButton("🔄 " + stringResource(R.string.conv_btn), { open = !open })
        if (busy) Text(stringResource(R.string.conv_busy), color = tk.text, style = MaterialTheme.typography.bodySmall)
    }
    if (open) {
        Spacer(Modifier.height(6.dp))
        ThemedCard(Modifier.fillMaxWidth()) {
            if (targets.isEmpty()) Text(stringResource(R.string.conv_none), color = tk.text, style = MaterialTheme.typography.bodyMedium)
            else {
                Text(stringResource(R.string.conv_pick), color = tk.text, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (t in targets) ThemedButton(if (t == ConvTarget.PNG_ZIP) "PNG" else t.ext.uppercase(), { if (!busy) convert(t) })
                }
                Spacer(Modifier.height(6.dp))
                Text(stringResource(if (kind == DocKind.PDF) R.string.conv_pdf_note else R.string.conv_note), color = tk.text, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun PdfView(s: DocState.Pdf, zoom: Float, onZoom: (Float) -> Unit) {
    val ctx = LocalContext.current
    val tk = LocalDesign.current.tokens
    val hs = rememberScrollState()
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(s.name, color = tk.text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f), maxLines = 1)
        ThemedButton("−", { onZoom((zoom - 0.5f).coerceAtLeast(1f)) })
        Spacer(Modifier.width(6.dp))
        ThemedButton("+", { onZoom((zoom + 0.5f).coerceAtMost(3f)) })
        Spacer(Modifier.width(6.dp))
        ThemedButton("↗", { openExternal(ctx, s.uri, s.name) })
    }
    Spacer(Modifier.height(6.dp))
    ConvertBar(s.name, DocKind.PDF, null, s.renderer, s.uri)
    val count = s.renderer.pageCount
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val dens = LocalDensity.current.density
        val widthDp = maxWidth * zoom
        val widthPx = (maxWidth.value * dens * zoom).toInt().coerceIn(200, 2400)
        Box(Modifier.fillMaxSize().horizontalScroll(hs)) {
            LazyColumn(Modifier.width(widthDp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(count) { i -> PdfPageView(s.renderer, i, widthPx, widthDp) }
            }
        }
    }
}

@Composable
private fun PdfPageView(r: PdfRenderer, index: Int, widthPx: Int, widthDp: androidx.compose.ui.unit.Dp) {
    var bmp by remember(index, widthPx) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(index, widthPx) {
        bmp = withContext(Dispatchers.IO) {
            try {
                synchronized(r) {
                    val page = r.openPage(index)
                    try {
                        val w = widthPx
                        val h = (w.toLong() * page.height / maxOf(1, page.width)).toInt().coerceIn(1, 4000)
                        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        b.eraseColor(AColor.WHITE)
                        page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        b
                    } finally {
                        page.close()
                    }
                }
            } catch (e: Exception) {
                null
            }
        }
    }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), contentDescription = null, modifier = Modifier.width(widthDp))
    else Box(Modifier.width(widthDp).height(widthDp * 1.4f))
}

@Composable
private fun TextView(s: DocState.Text, query: String, onQuery: (String) -> Unit) {
    val ctx = LocalContext.current
    val tk = LocalDesign.current.tokens
    val doc = s.doc
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(s.name, color = tk.text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f), maxLines = 1)
        ThemedButton("↗ " + stringResource(R.string.doc_external), { openExternal(ctx, s.uri, s.name) })
    }
    Spacer(Modifier.height(6.dp))
    if (doc.kind != DocKind.GOOGLE) ConvertBar(s.name, doc.kind, doc, null)
    if (doc.kind == DocKind.GOOGLE) {
        Text(stringResource(R.string.doc_google), color = tk.text, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        val link = doc.link
        if (link != null) ThemedButton(stringResource(R.string.doc_open_link), {
            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) } catch (e: Exception) { }
        }) else Text(stringResource(R.string.doc_cant), color = tk.text)
        return
    }
    val lines = remember(doc, query) {
        DocParse.flatten(doc, query) { p, idx ->
            when (doc.kind) {
                DocKind.PPTX, DocKind.ODP -> ctx.getString(R.string.doc_slide, p.title.toIntOrNull() ?: (idx + 1))
                DocKind.LEGACY -> p.title.toIntOrNull()?.let { ctx.getString(R.string.doc_slide, it) } ?: p.title
                DocKind.VSDX, DocKind.ODG -> ctx.getString(R.string.doc_page, p.title.toIntOrNull() ?: (idx + 1))
                else -> p.title
            }
        }
    }
    if (doc.pages.isEmpty() || (query.isBlank() && lines.isEmpty())) {
        Text(
            stringResource(if (doc.kind == DocKind.OPAQUE || doc.kind == DocKind.UNKNOWN) R.string.doc_cant else R.string.doc_empty),
            color = tk.text, style = MaterialTheme.typography.bodyMedium
        )
        return
    }
    if (doc.approx) {
        Text(stringResource(R.string.doc_approx), color = tk.text, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(6.dp))
    }
    ThemedTextField(query, onQuery, stringResource(R.string.doc_search), Modifier.fillMaxWidth())
    if (query.isNotBlank()) {
        // Eşleşen paragraf ve tablo satırı sayısı; sorgu Türkçe harf toleranslı aranır.
        val hits = lines.count { it.kind == 1 || it.kind == 2 }
        Text(stringResource(R.string.doc_hits, hits), color = tk.text, style = MaterialTheme.typography.bodySmall)
    }
    Spacer(Modifier.height(8.dp))
    val hs = rememberScrollState()
    SelectionContainer {
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(lines) { _, l ->
                when (l.kind) {
                    0 -> Text(l.text, color = tk.primary, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 10.dp))
                    1 -> Text(highlight(l.text, query), color = tk.text, style = MaterialTheme.typography.bodyMedium)
                    3 -> ImageBlock(s.media, l.img ?: "")
                    4 -> l.chart?.let { ChartBlock(it) }
                    5 -> l.dia?.let { DiagramBlock(it) }
                    else -> Row(Modifier.horizontalScroll(hs)) {
                        l.cells.forEach { c ->
                            Box(Modifier.width(120.dp).border(1.dp, tk.text.copy(alpha = 0.25f)).padding(4.dp)) {
                                Text(c, color = tk.text, style = MaterialTheme.typography.bodySmall, maxLines = 4)
                            }
                        }
                    }
                }
            }
        }
    }
}


/** Sorgu geçen yerleri açık sarı zeminle işaretler; yazı rengi koyu tutulur (iki temada da okunur). */
private fun highlight(text: String, query: String): androidx.compose.ui.text.AnnotatedString {
    val starts = com.odak.app.logic.Pure.matchStarts(text, query)
    if (starts.isEmpty()) return androidx.compose.ui.text.AnnotatedString(text)
    val len = query.trim().length
    return androidx.compose.ui.text.buildAnnotatedString {
        append(text)
        for (st in starts) {
            val end = minOf(text.length, st + len)
            if (st in 0 until end) addStyle(
                androidx.compose.ui.text.SpanStyle(background = Color(0xFFFFE082), color = Color(0xFF111111)), st, end
            )
        }
    }
}

/** 256 MB üstü düz metin: 1 MB'lık pencereler, sürgü ile konum, ileri/geri ve dosya içinde arama. */
@Composable
private fun BigTextView(s: DocState.Big) {
    val ctx = LocalContext.current
    val tk = LocalDesign.current.tokens
    val scope = rememberCoroutineScope()
    val ch = remember(s) { java.io.FileInputStream(s.pfd.fileDescriptor).channel }
    var win by remember(s) { mutableStateOf<BigText.Win?>(null) }
    var busy by remember(s) { mutableStateOf(false) }
    var q by remember(s) { mutableStateOf("") }
    var slider by remember(s) { mutableStateOf(0f) }
    var last by remember(s) { mutableStateOf(-1L) }
    var enc by remember(s) { mutableStateOf(BigText.UTF8) }
    val notFound = stringResource(R.string.doc_big_nf)
    fun go(pos: Long, exact: Boolean = false) {
        if (busy) return
        scope.launch {
            busy = true
            val w = withContext(Dispatchers.IO) { try { BigText.window(ch, s.size, pos, exact, BigText.WINDOW, enc) } catch (e: Exception) { null } }
            if (w != null) { win = w; slider = if (s.size > 0) w.start.toFloat() / s.size else 0f }
            busy = false
        }
    }
    fun find() {
        if (busy || q.isBlank()) return
        scope.launch {
            busy = true
            val from = if (last >= 0) last + 1 else (win?.start ?: 0L)
            val at = withContext(Dispatchers.IO) { try { BigText.find(ch, s.size, from, q.trim(), enc) } catch (e: Exception) { -1L } }
            busy = false
            if (at >= 0) { last = at; go(maxOf(0L, at - 2000)) }
            else { last = -1; android.widget.Toast.makeText(ctx, notFound, android.widget.Toast.LENGTH_SHORT).show() }
        }
    }
    LaunchedEffect(s) {
        enc = withContext(Dispatchers.IO) { try { BigText.detect(ch, s.size) } catch (e: Exception) { BigText.UTF8 } }
        go(0L, true)
    }
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(s.name, color = tk.text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f), maxLines = 1)
        ThemedButton("↗ " + stringResource(R.string.doc_external), { openExternal(ctx, s.uri, s.name) })
    }
    Text(stringResource(R.string.doc_bigtext), color = tk.text.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(6.dp))
    val w = win
    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(6.dp), Alignment.CenterVertically) {
        ThemedButton("◀", { w?.let { go(BigText.prevStart(it.start)) } })
        androidx.compose.material3.Slider(slider, { slider = it }, Modifier.weight(1f), onValueChangeFinished = { go(BigText.posOf(slider, s.size)) })
        ThemedButton("▶", { w?.let { if (!it.eof) go(it.end, true) } })
    }
    Text("${BigText.percent(w?.start ?: 0L, s.size)}%  ·  ${(s.size / (1024 * 1024))} MB  ·  ${(w?.enc ?: enc).label}" + if (busy) "  …" else "", color = tk.text, style = MaterialTheme.typography.bodySmall)
    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(6.dp), Alignment.CenterVertically) {
        ThemedTextField(q, { q = it; last = -1 }, stringResource(R.string.doc_search), Modifier.weight(1f))
        ThemedButton("🔍", { find() })
    }
    Spacer(Modifier.height(6.dp))
    if (w != null) SelectionContainer {
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(w.lines) { _, l -> Text(l.ifEmpty { " " }, color = tk.text, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}
