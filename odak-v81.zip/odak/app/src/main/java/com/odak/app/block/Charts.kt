package com.odak.app.block

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.sp
import com.odak.app.logic.Pure
import com.odak.app.theme.LocalDesign

/** Tasarımın köşe yarıçapına uyan çubuk şekli (Minimal'de köşesiz kalır). */
@Composable
fun barShape(top: Boolean = true): RoundedCornerShape {
    val r = minOf(LocalDesign.current.tokens.radius / 2, 8.dp)
    return if (top) RoundedCornerShape(topStart = r, topEnd = r) else RoundedCornerShape(r)
}

@Composable
fun barBrush(selected: Boolean = true): Brush {
    val t = LocalDesign.current.tokens
    val a = if (selected) 1f else 0.55f
    return Brush.verticalGradient(listOf(t.accent.copy(alpha = a), t.primary.copy(alpha = a)))
}

/** Yatay yuvarlak ilerleme çubuğu (gradyanlı). */
@Composable
fun RoundedBar(frac: Float, modifier: Modifier = Modifier, height: Dp = 8.dp, color: Color? = null) {
    val t = LocalDesign.current.tokens
    val sh = barShape(false)
    Box(modifier.fillMaxWidth().height(height).clip(sh).background(t.text.copy(alpha = 0.12f))) {
        Box(
            Modifier.fillMaxWidth(frac.coerceIn(0.02f, 1f)).fillMaxHeight().clip(sh)
                .background(if (color != null) Brush.horizontalGradient(listOf(color, color)) else Brush.horizontalGradient(listOf(t.primary, t.accent)))
        )
    }
}

/**
 * Izgaralı, eksen etiketli çubuk grafik. values: ms. labels: alt etiketler (boş olabilir).
 * highlight: vurgulanan çubuk (seçili gün / en yoğun saat). goalMin > 0 ise hedef çizgisi.
 */
@Composable
fun BarPlot(
    values: List<Long>,
    labels: List<String>,
    highlight: Int,
    height: Dp = 120.dp,
    goalMin: Int = 0,
    gap: Dp = 6.dp,
    valueOn: Set<Int> = setOf(highlight),
    nightFrom: Int = -1,
    onPick: ((Int) -> Unit)? = null
) {
    val t = LocalDesign.current.tokens
    val maxV = maxOf(values.maxOrNull() ?: 0L, goalMin * 60_000L)
    val axis = Pure.axisMaxMs(maxV)
    val step = Pure.niceStepMin(maxV) * 60_000L
    val levels = (axis / step).toInt()
    val grid = t.text.copy(alpha = 0.14f)
    Column {
        Box(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp)) {
            // ızgara + eksen etiketleri
            for (i in 0..levels) {
                Row(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth().height(12.dp)
                        .offset(y = 6.dp - height * (i.toFloat() / levels)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (i == 0) "" else Pure.fmtDur((i * step / 60_000L).toInt()),
                        Modifier.width(34.dp), fontSize = 9.sp, color = t.text.copy(alpha = 0.55f), maxLines = 1
                    )
                    Box(Modifier.weight(1f).height(1.dp).background(grid))
                }
            }
            if (goalMin > 0) {
                Box(
                    Modifier.align(Alignment.BottomStart).padding(start = 34.dp).fillMaxWidth().height(2.dp)
                        .offset(y = 1.dp - height * (goalMin * 60_000f / axis))
                        .background(Color(0xFFE53935).copy(alpha = 0.8f))
                )
            }
            // çubuklar
            Row(
                Modifier.align(Alignment.BottomStart).padding(start = 34.dp).fillMaxWidth().height(height),
                horizontalArrangement = Arrangement.spacedBy(gap), verticalAlignment = Alignment.Bottom
            ) {
                values.forEachIndexed { i, v ->
                    val hl = i == highlight
                    val night = nightFrom >= 0 && (i < 7 || i >= nightFrom)
                    Column(
                        Modifier.weight(1f).fillMaxHeight()
                            .then(if (onPick != null) Modifier.clickable { onPick(i) } else Modifier),
                        verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (i in valueOn && v > 0) Text(
                            Pure.fmtDur((v / 60_000L).toInt()), fontSize = 10.sp, maxLines = 1,
                            color = t.text, textAlign = TextAlign.Center,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                        Box(
                            Modifier.fillMaxWidth(if (values.size > 12) 0.8f else 0.62f)
                                .height((height * (v.toFloat() / axis)).coerceAtLeast(if (v > 0) 3.dp else 1.dp))
                                .clip(barShape())
                                .background(
                                    if (night) Brush.verticalGradient(listOf(t.accent.copy(alpha = 0.55f), t.accent.copy(alpha = 0.85f)))
                                    else barBrush(hl || highlight < 0)
                                )
                        )
                    }
                }
            }
        }
        // alt etiketler
        Row(Modifier.fillMaxWidth().padding(start = 34.dp), horizontalArrangement = Arrangement.spacedBy(gap)) {
            labels.forEachIndexed { i, l ->
                Text(
                    l, Modifier.weight(1f), fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center,
                    color = t.text.copy(alpha = if (i == highlight) 1f else 0.6f),
                    fontWeight = if (i == highlight) androidx.compose.ui.text.font.FontWeight.Bold else null
                )
            }
        }
    }
}

private val sliceCols = listOf(
    Color(0xFF4285F4), Color(0xFFEA4335), Color(0xFFFBBC05), Color(0xFF34A853), Color(0xFF9C27B0), Color(0xFF9E9E9E)
)

/** Halka grafik + yüzdeli açıklama. slices: (ad, ms); ad boşsa "Diğer". */
@Composable
fun DonutChart(slices: List<Pair<String, Long>>, centerTop: String, centerBottom: String, other: String) {
    val t = LocalDesign.current.tokens
    val total = slices.sumOf { it.second }
    if (total <= 0) return
    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Box(Modifier.size(132.dp), contentAlignment = Alignment.Center) {
            androidx.compose.foundation.Canvas(Modifier.size(132.dp)) {
                val w = 24.dp.toPx()
                var start = -90f
                // arka halka
                drawArc(
                    t.text.copy(alpha = 0.08f), 0f, 360f, false,
                    androidx.compose.ui.geometry.Offset(w / 2, w / 2),
                    androidx.compose.ui.geometry.Size(size.width - w, size.height - w),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(w)
                )
                slices.forEachIndexed { i, (_, ms) ->
                    val sweep = 360f * ms / total
                    drawArc(
                        sliceCols[i % sliceCols.size], start + 1f, (sweep - 2f).coerceAtLeast(1f), false,
                        androidx.compose.ui.geometry.Offset(w / 2, w / 2),
                        androidx.compose.ui.geometry.Size(size.width - w, size.height - w),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(w)
                    )
                    start += sweep
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(centerTop, style = MaterialTheme.typography.titleMedium, color = t.text)
                Text(centerBottom, fontSize = 10.sp, color = t.text.copy(alpha = 0.6f))
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            slices.forEachIndexed { i, (name, ms) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(sliceCols[i % sliceCols.size]))
                    Spacer(Modifier.width(8.dp))
                    Text(name.ifEmpty { other }, Modifier.weight(1f), fontSize = 13.sp, maxLines = 1, color = t.text)
                    Text(
                        "${Pure.slicePct(ms, total)}%", fontSize = 12.sp, color = t.text.copy(alpha = 0.65f)
                    )
                }
            }
        }
    }
}
