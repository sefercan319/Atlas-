package com.odak.app.docs

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import com.odak.app.notes.NoteMedia
import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Android'e bağlı dönüştürmeler: belge → PDF (PdfDocument ile) ve PDF → sayfa resimleri (PNG zip). */
object DocPdf {
    private const val MAX_LINES = 20000

    /** PDF'teki yazıyı sayfa sayfa çıkarır (pdfbox-android). Dosya önce cache'e akıtılır, pdfbox geçici dosya kullanır; boyut sınırı yoktur. Yazı yoksa (taranmış PDF) sayfalar boş gelir. */
    fun extractText(ctx: Context, uri: Uri): Doc {
        PDFBoxResourceLoader.init(ctx.applicationContext)
        val tmp = File(File(ctx.cacheDir, "convert").also { it.mkdirs() }, "src.pdf")
        try {
            ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            PDDocument.load(tmp, MemoryUsageSetting.setupTempFileOnly()).use { d ->
                val st = PDFTextStripper()
                val pages = ArrayList<DocPage>()
                var total = 0
                for (n in 1..d.numberOfPages) {
                    st.startPage = n; st.endPage = n
                    val lines = st.getText(d).replace("\r\n", "\n").split('\n').map { it.trim() }.filter { it.isNotEmpty() }
                    if (total + lines.size > MAX_LINES) break
                    total += lines.size
                    pages.add(DocPage("Sayfa $n", lines, null))
                }
                return Doc(DocKind.PDF, if (pages.any { it.paragraphs.isNotEmpty() }) pages else emptyList())
            }
        } finally { tmp.delete() }
    }

    private const val PW = 595
    private const val PH = 842
    private const val M = 40f

    /** Belgeyi A4 sayfalara yazar. Kaynakta birden çok sayfa/slayt/sayfa sekmesi varsa her biri yeni PDF sayfasında başlar. Dönüş: sayfa sayısı. */
    fun write(doc: Doc, out: File): Int {
        val pdf = PdfDocument()
        var pageNo = 0
        var page: PdfDocument.Page? = null
        var cv: Canvas? = null
        var y = 0f
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = Color.BLACK }
        val head = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; isFakeBoldText = true; color = Color.BLACK }
        val line = Paint().apply { color = 0xFF999999.toInt(); strokeWidth = 0.7f; style = Paint.Style.STROKE }

        fun newPage() {
            page?.let { pdf.finishPage(it) }
            pageNo++
            val p = pdf.startPage(PdfDocument.PageInfo.Builder(PW, PH, pageNo).create())
            page = p; cv = p.canvas; y = M
        }
        fun ensure(h: Float) { if (cv == null || y + h > PH - M) newPage() }
        fun text(t: String, paint: Paint, lead: Float) {
            for (l in DocConvert.wrap(t, PW - 2 * M, { paint.measureText(it) })) {
                ensure(lead)
                cv!!.drawText(l, M, y + paint.textSize, paint)
                y += lead
            }
        }

        doc.pages.forEachIndexed { i, p ->
            if (i > 0 || cv == null) newPage()
            if (DocConvert.showTitle(doc, p)) { text(p.title, head, 22f); y += 4f }
            for (t in p.paragraphs) { text(t, body, 15f); y += 3f }
            val rows = p.table?.let { DocConvert.padRows(it) }
            if (!rows.isNullOrEmpty() && rows[0].isNotEmpty()) {
                val cols = rows[0].size
                val tp = Paint(body).apply { textSize = if (cols > 8) 7f else if (cols > 5) 9f else 11f }
                val cw = (PW - 2 * M) / cols
                for (r in rows) {
                    val cells = r.map { DocConvert.wrap(it, cw - 6f, { s -> tp.measureText(s) }) }
                    val lead = tp.textSize + 4f
                    val h = (cells.maxOf { it.size }.coerceAtMost(12)) * lead + 4f
                    ensure(h)
                    r.indices.forEach { c ->
                        val x = M + c * cw
                        cv!!.drawRect(x, y, x + cw, y + h, line)
                        cells[c].take(12).forEachIndexed { k, l -> cv!!.drawText(l, x + 3f, y + 2f + tp.textSize + k * lead, tp) }
                    }
                    y += h
                }
                y += 8f
            }
        }
        if (cv == null) newPage()
        page?.let { pdf.finishPage(it) }
        out.outputStream().use { pdf.writeTo(it) }
        pdf.close()
        return pageNo
    }

    /** PDF'in her sayfasını PNG yapıp zip'e koyar (sayfa-001.png …). Dönüş: yazılan sayfa sayısı. */
    fun pdfToPngZip(renderer: PdfRenderer, out: File, widthPx: Int = 1240): Int {
        var n = 0
        ZipOutputStream(out.outputStream()).use { z ->
            for (i in 0 until renderer.pageCount) {
                val bmp: Bitmap = NoteMedia.renderPdfPage(renderer, i, widthPx) ?: continue
                z.putNextEntry(ZipEntry("sayfa-%03d.png".format(i + 1)))
                bmp.compress(Bitmap.CompressFormat.PNG, 100, z)
                z.closeEntry()
                bmp.recycle()
                n++
            }
        }
        return n
    }
}
