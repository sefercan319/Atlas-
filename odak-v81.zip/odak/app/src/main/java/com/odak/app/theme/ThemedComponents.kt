package com.odak.app.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Çizimi paylaşılan yeni tasarımlar (onay kutusu gibi ortak şekil mantığı için). */
private val NewLookStyles = setOf(
    DesignStyle.SKEUOMORPHISM, DesignStyle.NEUMORPHISM, DesignStyle.GLASSMORPHISM,
    DesignStyle.Y2K, DesignStyle.AURORA, DesignStyle.CLAYMORPHISM, DesignStyle.DARK,
    DesignStyle.COSMIC, DesignStyle.SCIFI_HUD, DesignStyle.CYBER_INDUSTRIAL, DesignStyle.NEOCLASSICAL
)

/** Kil tasarımında metin rengi olarak kullanılan koyu mercan (≥4.5:1). */
val ClayInk = Color(0xFFB8352B)

private fun Modifier.hairline(color: Color, top: Boolean): Modifier = drawBehind {
    val y = if (top) 0f else size.height
    drawLine(color, Offset(0f, y), Offset(size.width, y), 2f)
}

@Composable
private fun neonGlow(): Float {
    val tr = rememberInfiniteTransition(label = "neon")
    val v by tr.animateFloat(
        initialValue = 6f,
        targetValue = 16f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "glow"
    )
    return v
}

/** Tasarıma özel arka plan. */
@Composable
fun ThemedBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val d = LocalDesign.current
    val t = d.tokens
    val base = when (d.style) {
        DesignStyle.FUTURISTIC, DesignStyle.TERMINAL ->
            Modifier.background(Brush.verticalGradient(listOf(Color(0xFF05050A), Color(0xFF101030))))
        DesignStyle.FRUTIGER_AERO ->
            Modifier.background(
                Brush.verticalGradient(listOf(Color(0xFF3FA9F5), Color(0xFF87CEEB), Color(0xFFCFF5B0)))
            )
        DesignStyle.MINIMAL -> Modifier.background(t.background)
        DesignStyle.WINDOWS11 ->
            Modifier.background(Brush.verticalGradient(listOf(Color(0xFFEAF1FB), Color(0xFFF3F3F3))))
        DesignStyle.NEON ->
            Modifier.background(Brush.radialGradient(listOf(Color(0xFF2A0B5E), t.background), radius = 1400f))
        DesignStyle.SKEUOMORPHISM -> Modifier.skeuoDesk(t.background)
        DesignStyle.NEUMORPHISM -> Modifier.background(t.background)
        DesignStyle.GLASSMORPHISM -> Modifier.background(t.background)
        DesignStyle.Y2K ->
            Modifier.background(Brush.linearGradient(listOf(Color(0xFFBFF3FF), Color(0xFFD9C8FF), Color(0xFFFFC2EA))))
        DesignStyle.AURORA, DesignStyle.CLAYMORPHISM, DesignStyle.DARK,
        DesignStyle.COSMIC, DesignStyle.SCIFI_HUD, DesignStyle.CYBER_INDUSTRIAL -> Modifier.background(t.background)
        DesignStyle.NEOCLASSICAL -> Modifier.neoMarble()
    }
    val grid = if ((d.style == DesignStyle.FUTURISTIC || d.style == DesignStyle.TERMINAL)) {
        Modifier.drawBehind {
            val step = 36.dp.toPx()
            val c = Color(0x1400E5FF)
            var x = 0f
            while (x < size.width) {
                drawLine(c, Offset(x, 0f), Offset(x, size.height), 1f); x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(c, Offset(0f, y), Offset(size.width, y), 1f); y += step
            }
        }
    } else Modifier
    Box(modifier.then(base).then(grid)) {
        if (d.style == DesignStyle.GLASSMORPHISM) GlassOrbs(Modifier.matchParentSize())
        if (d.style == DesignStyle.AURORA) AuroraBackdrop(Modifier.matchParentSize())
        if (d.style == DesignStyle.Y2K) Y2kSparkles(Modifier.matchParentSize())
        if (d.style == DesignStyle.COSMIC) CosmicBackdrop(Modifier.matchParentSize())
        if (d.style == DesignStyle.SCIFI_HUD) HudBackdrop(Modifier.matchParentSize())
        if (d.style == DesignStyle.CYBER_INDUSTRIAL) CyberBackdrop(Modifier.matchParentSize())
        content()
    }
}

/** Tasarıma özel kart. */
@Composable
fun ThemedCard(
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val d = LocalDesign.current
    val t = d.tokens
    val style = d.style
    val shape = cardShape(style)
    val neuDepth by animateFloatAsState(if (selected && style == DesignStyle.NEUMORPHISM) 1f else 0f, tween(160), label = "neuCard")
    val elevated = when (style) {
        DesignStyle.NEON -> Modifier.shadow(
            if (selected) 18.dp else 8.dp, shape, ambientColor = t.accent, spotColor = t.accent
        )
        DesignStyle.WINDOWS11 -> Modifier.shadow(2.dp, shape)
        else -> Modifier
    }
    val fill = when (style) {
        DesignStyle.FRUTIGER_AERO ->
            Modifier.shadow(4.dp, shape, ambientColor = Color(0xFF0054E3), spotColor = Color(0xFF0054E3))
                .aeroGlass(shape, Color(0xFFD2EEFF))
        DesignStyle.MINIMAL ->
            Modifier.hairline(t.accent.copy(alpha = if (selected) 1f else 0.4f), top = false)
        DesignStyle.SKEUOMORPHISM ->
            Modifier.skeuoSurface(
                shape, t.surface, lerp(t.surface, Color(0xFFB59C70), 0.22f),
                grain = Grain.PAPER, elevation = 5.dp, stitch = t.primary.copy(alpha = 0.40f), gloss = false
            )
        DesignStyle.NEUMORPHISM -> Modifier.neuSurface(shape, t.surface, depth = neuDepth)
        DesignStyle.GLASSMORPHISM ->
            Modifier.glassPanel(shape, Color.White, alpha = if (selected) 0.26f else 0.16f)
        DesignStyle.Y2K ->
            Modifier.shadow(5.dp, shape, ambientColor = Color(0xFF7B5FD0), spotColor = Color(0xFF7B5FD0))
                .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFEFE6FF))), shape)
                .holoBorder(shape)
        DesignStyle.AURORA -> Modifier.auroraPanel(shape, if (selected) 1f else 0.3f)
        DesignStyle.CLAYMORPHISM ->
            Modifier.claySurface(shape, if (selected) lerp(t.surface, Color(0xFFB8A6FF), 0.5f) else t.surface)
        DesignStyle.DARK -> Modifier.background(darkElevation(if (selected) 3 else 1), shape)
        DesignStyle.COSMIC -> Modifier.cosmicPanel(shape, if (selected) 1f else 0.3f)
        DesignStyle.SCIFI_HUD -> Modifier.hudPanel(if (selected) HudCyan else HudAmber, if (selected) 1f else 0f)
        DesignStyle.CYBER_INDUSTRIAL -> Modifier.steelPlate(shape, SteelPlate, if (selected) 1f else 0f)
        DesignStyle.NEOCLASSICAL -> Modifier.neoFrame(NeoGold, true, t.surface)
        else -> Modifier.background(t.surface, shape)
    }
    val borderColor = when (style) {
        DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> if (selected) t.primary else t.primary.copy(alpha = 0.45f)
        DesignStyle.FRUTIGER_AERO -> Color.White
        DesignStyle.MINIMAL -> Color.Transparent
        DesignStyle.WINDOWS11 -> if (selected) t.primary else Color(0x1F000000)
        DesignStyle.NEON -> t.accent
        DesignStyle.SKEUOMORPHISM -> if (selected) t.accent else Color.Transparent
        DesignStyle.NEUMORPHISM -> Color.Transparent
        DesignStyle.GLASSMORPHISM -> if (selected) t.primary else Color.Transparent
        DesignStyle.Y2K -> if (selected) Y2kPink else Color.Transparent
        DesignStyle.AURORA, DesignStyle.CLAYMORPHISM -> Color.Transparent
        DesignStyle.DARK -> if (selected) t.primary else Color(0x14FFFFFF)
        DesignStyle.COSMIC, DesignStyle.SCIFI_HUD, DesignStyle.NEOCLASSICAL -> Color.Transparent
        DesignStyle.CYBER_INDUSTRIAL -> if (selected) HazardYellow else Color.Transparent
    }
    val borderWidth = when (style) {
        DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> 1.dp
        DesignStyle.FRUTIGER_AERO -> 1.5.dp
        DesignStyle.MINIMAL -> 0.dp
        DesignStyle.WINDOWS11 -> 1.dp
        DesignStyle.NEON -> 1.5.dp
        DesignStyle.SKEUOMORPHISM -> if (selected) 2.dp else 0.dp
        DesignStyle.NEUMORPHISM -> 0.dp
        DesignStyle.GLASSMORPHISM -> if (selected) 1.5.dp else 0.dp
        DesignStyle.Y2K -> if (selected) 2.dp else 0.dp
        DesignStyle.AURORA, DesignStyle.CLAYMORPHISM -> 0.dp
        DesignStyle.DARK -> 1.dp
        DesignStyle.COSMIC, DesignStyle.SCIFI_HUD, DesignStyle.NEOCLASSICAL -> 0.dp
        DesignStyle.CYBER_INDUSTRIAL -> if (selected) 2.dp else 0.dp
    }
    var m = modifier.then(elevated).then(fill)
    if (borderWidth > 0.dp) m = m.border(borderWidth, borderColor, shape)
    if (onClick != null) m = m.clip(shape).clickable(onClick = onClick)
    Column(m.padding(14.dp), content = content)
}

/** Tasarıma özel buton: şekil, dolgu, basma animasyonu ve ses. */
@Composable
fun ThemedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    sound: SoundKind = SoundKind.TAP
) {
    val d = LocalDesign.current
    val t = d.tokens
    val style = d.style
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val fx = rememberPress(style, interaction)
    val glow = if (style == DesignStyle.NEON) neonGlow() else 0f
    val shape = buttonShape(style)

    val look = when (style) {
        DesignStyle.TERMINAL ->
            Modifier.background(
                if (pressed) Brush.verticalGradient(listOf(t.primary, t.primary))
                else Brush.verticalGradient(listOf(t.primary.copy(alpha = 0.16f), t.primary.copy(alpha = 0.04f))),
                shape
            ).border(1.dp, t.primary, shape)
        DesignStyle.FUTURISTIC ->
            Modifier.shadow(6.dp, shape, ambientColor = t.primary, spotColor = t.primary)
                .background(
                    Brush.verticalGradient(listOf(t.primary.copy(alpha = 0.30f), t.primary.copy(alpha = 0.06f))), shape
                )
                .drawBehind {
                    drawRect(t.primary.copy(alpha = 0.9f), size = Size(size.width, 1.5.dp.toPx()))
                }
                .border(1.dp, t.primary.copy(alpha = if (pressed) 1f else 0.7f), shape)
        DesignStyle.FRUTIGER_AERO ->
            Modifier.shadow(4.dp, shape, ambientColor = Color(0xFF0A5AD8), spotColor = Color(0xFF0A5AD8))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xCC8FD6FF), Color(0xB32B8FF2), Color(0xB30A55D6), Color(0xCC3FB4FF))
                    ),
                    shape
                )
                .drawBehind {
                    // üst cam parlaması
                    val inset = 2.dp.toPx()
                    drawRoundRect(
                        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.50f), Color.White.copy(alpha = 0.06f))),
                        topLeft = Offset(inset, inset),
                        size = Size(size.width - inset * 2, size.height * 0.5f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx())
                    )
                    // alt ışıma
                    drawOval(
                        Brush.radialGradient(
                            listOf(Color(0x66BFF3FF), Color.Transparent),
                            center = Offset(size.width / 2f, size.height),
                            radius = size.width * 0.45f
                        ),
                        topLeft = Offset(size.width * 0.1f, size.height * 0.55f),
                        size = Size(size.width * 0.8f, size.height * 0.45f)
                    )
                }
                .border(1.dp, Brush.verticalGradient(listOf(Color.White, Color(0x99FFFFFF))), shape)
        DesignStyle.MINIMAL ->
            Modifier.shadow(3.dp, shape, ambientColor = Color(0x44000000), spotColor = Color(0x44000000))
                .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFEDEDED))), shape)
                .border(1.dp, Color(0xFF111111), shape)
        DesignStyle.WINDOWS11 ->
            Modifier.shadow(3.dp, shape)
                .background(
                    Brush.verticalGradient(
                        listOf(androidx.compose.ui.graphics.lerp(t.primary, Color.White, 0.14f), t.primary)
                    ),
                    shape
                )
                .border(1.dp, Color.White.copy(alpha = 0.25f), shape)
        DesignStyle.NEON ->
            Modifier.shadow(glow.dp, shape, ambientColor = t.primary, spotColor = t.primary)
                .background(
                    Brush.verticalGradient(listOf(t.primary.copy(alpha = 0.32f), t.primary.copy(alpha = 0.06f))), shape
                )
                .drawBehind {
                    drawRect(Color.White.copy(alpha = 0.35f), Offset(6.dp.toPx(), 2.dp.toPx()), Size(size.width - 12.dp.toPx(), 1.dp.toPx()))
                }
                .border(2.dp, t.primary, shape)
        // Deri düğme: dikişli, dokulu, basınca içe gömülür.
        DesignStyle.SKEUOMORPHISM ->
            Modifier.skeuoSurface(
                shape, lerp(t.primary, Color.White, 0.12f), lerp(t.primary, Color.Black, 0.25f),
                pressed = fx.prog.value, grain = Grain.LEATHER, elevation = 5.dp, stitch = Color(0x66FFF3D6)
            )
        // Kabarık düğme: basınca inset'e geçer.
        DesignStyle.NEUMORPHISM ->
            Modifier.neuSurface(shape, t.surface, depth = fx.prog.value, dist = 5.dp, blur = 10.dp)
        // Cam düğme: tint'li panel; ışık süpürmesi pressOverlay'de.
        DesignStyle.GLASSMORPHISM ->
            Modifier.glassPanel(shape, t.primary, alpha = 0.20f + 0.08f * fx.prog.value.coerceIn(0f, 1f))
        // Jel hap: basınca parlama sönükleşir, gölge küçülür; balon efekti pressOuter/pressOverlay'de.
        DesignStyle.Y2K ->
            Modifier.y2kGel(shape, Color(0xFF8FE8FF), Color(0xFF2A5BFF), Color(0xFF1B3FD0), if (pressed) 1f else 0f)
        DesignStyle.AURORA -> Modifier.auroraButton(shape, fx.prog.value)
        // Kil düğme: basınca gölge ofsetleri yarıya iner (gömülür).
        DesignStyle.CLAYMORPHISM ->
            Modifier.claySurface(shape, t.primary, depth = 1f - 0.5f * fx.prog.value.coerceIn(0f, 1f), offset = 6.dp, blur = 16.dp)
        DesignStyle.DARK -> Modifier.background(t.primary, shape)
        DesignStyle.COSMIC -> Modifier.cosmicButton(shape, fx.prog.value)
        DesignStyle.SCIFI_HUD -> Modifier.hudPanel(HudAmber, fx.prog.value.coerceIn(0f, 1f), grid = false)
        DesignStyle.CYBER_INDUSTRIAL -> Modifier.yellowPlate(shape, fx.prog.value)
        DesignStyle.NEOCLASSICAL -> Modifier.neoFrame(NeoGold, false, null)
    }
    val textColor = when (style) {
        DesignStyle.TERMINAL -> if (pressed) t.background else t.primary
        DesignStyle.FUTURISTIC -> t.primary
        DesignStyle.FRUTIGER_AERO -> Color.White
        DesignStyle.MINIMAL -> t.primary
        DesignStyle.WINDOWS11 -> Color.White
        DesignStyle.NEON -> t.primary
        DesignStyle.SKEUOMORPHISM -> Color(0xFFFFF3D6)
        DesignStyle.NEUMORPHISM -> t.primary
        DesignStyle.GLASSMORPHISM -> t.text
        DesignStyle.Y2K -> Color.White
        DesignStyle.AURORA -> Color(0xFF06122B)
        DesignStyle.CLAYMORPHISM -> t.text
        DesignStyle.DARK -> Color(0xFF0B1B33)
        DesignStyle.COSMIC -> CosmicVoid
        DesignStyle.SCIFI_HUD -> HudAmber
        DesignStyle.CYBER_INDUSTRIAL -> Color(0xFF111111)
        DesignStyle.NEOCLASSICAL -> t.primary
    }
    val label = when {
        style == DesignStyle.TERMINAL -> "[ " + text.lowercase(java.util.Locale.getDefault()) + " ]"
        style == DesignStyle.FUTURISTIC || style == DesignStyle.NEON || style == DesignStyle.CYBER_INDUSTRIAL ||
            style == DesignStyle.NEOCLASSICAL -> text.uppercase(java.util.Locale.getDefault())
        style == DesignStyle.SCIFI_HUD -> "▸ " + text.uppercase(java.util.Locale.getDefault())
        else -> text
    }

    Box(
        modifier
            .pressOuter(fx)
            .defaultMinSize(minHeight = 40.dp)
            .then(look)
            .pressOverlay(fx, if (style == DesignStyle.WINDOWS11 || style == DesignStyle.GLASSMORPHISM) Color.White else t.primary, shape)
            .clickable(interactionSource = interaction, indication = null) {
                ClickSound.play(style, sound)
                if (ClickSound.haptic) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = textColor,
            fontWeight = when (style) {
                DesignStyle.MINIMAL -> FontWeight.Light
                DesignStyle.Y2K, DesignStyle.AURORA -> FontWeight.Bold
                DesignStyle.CLAYMORPHISM -> FontWeight.ExtraBold
                DesignStyle.DARK -> FontWeight.Medium
                DesignStyle.CYBER_INDUSTRIAL -> FontWeight.Black
                DesignStyle.COSMIC -> FontWeight.Bold
                else -> FontWeight.SemiBold
            },
            letterSpacing = if ((style == DesignStyle.FUTURISTIC || style == DesignStyle.TERMINAL) || style == DesignStyle.NEON ||
                style == DesignStyle.SCIFI_HUD) 2.sp
            else if (style == DesignStyle.NEOCLASSICAL || style == DesignStyle.CYBER_INDUSTRIAL) 3.sp else 0.sp,
            textDecoration = null,
            style = if (style == DesignStyle.FRUTIGER_AERO)
                LocalTextStyle.current.copy(shadow = Shadow(Color(0x99003388), Offset(0f, 2f), 4f))
            else if (style == DesignStyle.SKEUOMORPHISM)
                LocalTextStyle.current.copy(shadow = Shadow(Color(0xCC000000), Offset(0f, -1.5f), 1f))
            else if (style == DesignStyle.Y2K)
                LocalTextStyle.current.copy(shadow = Shadow(Color(0xFF0A2A99), Offset(0f, 1.5f), 2f))
            else LocalTextStyle.current,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
        )
    }
}

/** Tasarıma özel onay kutusu. */
@Composable
fun ThemedCheck(checked: Boolean, onChange: (Boolean) -> Unit) {
    val d = LocalDesign.current
    val t = d.tokens
    val style = d.style
    val shape = checkShape(style)
    val haptic = LocalHapticFeedback.current
    val ckInteraction = remember { MutableInteractionSource() }
    val ckFx = rememberPress(style, ckInteraction)
    val fill by animateColorAsState(
        if (checked) t.primary else Color.Transparent,
        tween(fadeMs(style)),
        label = "chk"
    )
    val s by animateFloatAsState(
        if (checked) 1f else 0.92f,
        motion(style),
        label = "chkScale"
    )
    val borderColor = if (style == DesignStyle.MINIMAL) t.text else t.primary
    val neuCheck by animateFloatAsState(if (checked) 1f else 0f, tween(160), label = "neuChk")
    val newStyle = style in NewLookStyles
    val glow = if (checked && style == DesignStyle.NEON) {
        Modifier.shadow(8.dp, shape, ambientColor = t.primary, spotColor = t.primary)
    } else Modifier
    Box(
        Modifier
            .size(28.dp)
            .pressOuter(ckFx)
            .scale(s)
            .then(glow)
            .then(
                if (newStyle) { when (style) {
                    // Krom kutu: işaretlenince yeşil gösterge ışığı.
                    DesignStyle.SKEUOMORPHISM -> Modifier.skeuoSurface(
                        shape,
                        if (checked) Color(0xFF9BE07A) else Color(0xFFFFFFFF),
                        if (checked) Color(0xFF3A8A2A) else Color(0xFFB9B2A4),
                        pressed = ckFx.prog.value, grain = Grain.METAL, elevation = 2.dp
                    )
                    DesignStyle.NEUMORPHISM ->
                        Modifier.neuSurface(shape, t.surface, depth = neuCheck, dist = 3.dp, blur = 6.dp)
                    DesignStyle.GLASSMORPHISM -> Modifier.glassPanel(
                        shape, if (checked) t.primary else Color.White,
                        alpha = if (checked) 0.45f else 0.14f, shadow = false
                    )
                    // Jel boncuk: işaretlenince pembe.
                    DesignStyle.Y2K -> Modifier.y2kGel(
                        shape,
                        if (checked) Color(0xFFFFB3E0) else Color.White,
                        if (checked) Y2kPink else Color(0xFF9FE7FF),
                        if (checked) Color(0xFFC0106F) else Color(0xFF3D7BFF)
                    )
                    DesignStyle.AURORA ->
                        if (checked) Modifier.auroraButton(shape, 1f) else Modifier.auroraPanel(shape, 0f)
                    // Kil: kapalıyken çukur, açıkken nane yeşili kabarık.
                    DesignStyle.CLAYMORPHISM ->
                        if (checked) Modifier.claySurface(shape, Color(0xFF7DD4A8), 0.6f, 4.dp, 8.dp)
                        else Modifier.clayWell(shape, t.background)
                    DesignStyle.DARK -> Modifier.background(if (checked) t.primary else Color.Transparent, shape)
                        .border(2.dp, if (checked) t.primary else Color(0xFF8A8A8A), shape)
                    DesignStyle.COSMIC -> Modifier.cosmicPlanet(checked)
                    DesignStyle.SCIFI_HUD -> Modifier.hudPanel(if (checked) HudCyan else HudAmber, if (checked) 1f else 0f, grid = false)
                    DesignStyle.CYBER_INDUSTRIAL ->
                        if (checked) Modifier.yellowPlate(shape, 0f) else Modifier.steelPlate(shape, SteelDark, 1f, rivets = false)
                    DesignStyle.NEOCLASSICAL -> Modifier.goldCoin(checked, ckFx.prog.value)
                    else -> Modifier
                } }
                else if (style == DesignStyle.FRUTIGER_AERO)
                    Modifier.shadow(4.dp, shape, ambientColor = Color(0xFF0A55D8), spotColor = Color(0xFF0A55D8))
                        .aeroGlass(shape, if (checked) Color(0xFF3FBF3A) else Color(0xFFBFE4FF), strong = checked)
                        .border(1.dp, Color.White, shape)
                else Modifier.background(fill, shape)
                    .border(if (style == DesignStyle.MINIMAL) 1.dp else 2.dp, borderColor, shape)
            )
            .pressOverlay(ckFx, t.primary, shape)
            .clickable(interactionSource = ckInteraction, indication = null) {
                val next = !checked
                if (ClickSound.haptic) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                ClickSound.play(style, if (next) SoundKind.SUCCESS else SoundKind.TAP)
                onChange(next)
            },
        contentAlignment = Alignment.Center
    ) {
        if (checked) Text(
            "✓",
            color = when (style) {
                DesignStyle.FRUTIGER_AERO, DesignStyle.SKEUOMORPHISM -> Color.White
                DesignStyle.NEUMORPHISM -> t.primary
                DesignStyle.GLASSMORPHISM -> t.text
                DesignStyle.Y2K -> Color.White
                DesignStyle.AURORA -> Color(0xFF06122B)
                DesignStyle.CLAYMORPHISM -> t.text
                DesignStyle.DARK -> Color(0xFF0B1B33)
                DesignStyle.COSMIC -> CosmicVoid
                DesignStyle.SCIFI_HUD -> HudCyan
                DesignStyle.CYBER_INDUSTRIAL -> Color(0xFF111111)
                DesignStyle.NEOCLASSICAL -> Color(0xFF3A2A06)
                else -> t.surface.copy(alpha = 1f)
            },
            fontSize = 16.sp, fontWeight = FontWeight.Bold
        )
    }
}

/** Tasarıma özel sekme çubuğu. */
@Composable
fun ThemedTabBar(
    labels: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    bottom: Boolean = true,
    fontSize: TextUnit = 11.sp
) {
    val d = LocalDesign.current
    val t = d.tokens
    val style = d.style
    val pill = RoundedCornerShape(16.dp)
    val container = when (style) {
        DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> Modifier.background(t.surface).hairline(t.primary.copy(alpha = 0.5f), bottom)
        DesignStyle.FRUTIGER_AERO ->
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                .shadow(8.dp, pill, ambientColor = Color(0xFF0054E3), spotColor = Color(0xFF0054E3))
                .background(Brush.verticalGradient(listOf(Color(0xF2FFFFFF), Color(0xB3DDF1FF))), pill)
                .border(1.dp, Color.White, pill)
        DesignStyle.MINIMAL -> Modifier.hairline(t.accent.copy(alpha = 0.4f), bottom)
        DesignStyle.WINDOWS11 -> Modifier.background(t.surface).hairline(Color(0x1F000000), bottom)
        DesignStyle.NEON ->
            Modifier.background(t.background.copy(alpha = 0.92f)).hairline(t.accent, bottom)
        DesignStyle.SKEUOMORPHISM ->
            Modifier.skeuoSurface(
                RoundedCornerShape(0.dp), Color(0xFF8A5A33), Color(0xFF5E3A1E),
                grain = Grain.LEATHER, elevation = 6.dp, stitch = Color(0x66FFF3D6), gloss = false
            )
        DesignStyle.NEUMORPHISM ->
            Modifier.padding(horizontal = 12.dp, vertical = 10.dp).neuSurface(pill, t.surface, 0f, 4.dp, 10.dp)
        DesignStyle.GLASSMORPHISM ->
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp).glassPanel(pill, Color.White, 0.16f)
        DesignStyle.Y2K ->
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                .y2kGel(pill, Color.White, Color(0xFFE3E9F8), Color(0xFFB9C4DE))
        DesignStyle.AURORA ->
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp).auroraPanel(pill, 0.4f)
        DesignStyle.CLAYMORPHISM ->
            Modifier.padding(horizontal = 12.dp, vertical = 10.dp).claySurface(pill, Color.White, 1f, 6.dp, 16.dp)
        DesignStyle.DARK -> Modifier.background(darkElevation(1)).hairline(Color(0x14FFFFFF), bottom)
        DesignStyle.COSMIC ->
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp).cosmicPanel(RoundedCornerShape(50), 0.5f)
        DesignStyle.SCIFI_HUD -> Modifier.background(Color(0xE604090F)).hairline(HudAmber.copy(alpha = 0.6f), bottom)
        DesignStyle.CYBER_INDUSTRIAL -> Modifier.steelPlate(RectangleShape, SteelDark, 0f, rivets = false)
        DesignStyle.NEOCLASSICAL -> Modifier.background(t.surface).hairline(NeoGold, bottom)
    }
    val insets = if (bottom) Modifier.navigationBarsPadding() else Modifier
    val floating = style == DesignStyle.FRUTIGER_AERO || style == DesignStyle.NEUMORPHISM ||
        style == DesignStyle.GLASSMORPHISM || style == DesignStyle.Y2K || style == DesignStyle.AURORA ||
        style == DesignStyle.CLAYMORPHISM || style == DesignStyle.COSMIC
    val shell = if (floating) insets.then(container) else container.then(insets)

    Row(modifier.fillMaxWidth().then(shell).padding(horizontal = 4.dp)) {
        labels.forEachIndexed { i, label ->
            TabItem(label, i == selected, fontSize, Modifier.weight(1f)) {
                ClickSound.play(style, SoundKind.TAP)
                onSelect(i)
            }
        }
    }
}

@Composable
private fun TabItem(
    label: String,
    selected: Boolean,
    fontSize: TextUnit,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val d = LocalDesign.current
    val t = d.tokens
    val style = d.style
    val interaction = remember { MutableInteractionSource() }
    val selColor = when (style) {
        DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> t.primary
        DesignStyle.FRUTIGER_AERO -> t.primary
        DesignStyle.MINIMAL -> t.text
        DesignStyle.WINDOWS11 -> t.text
        DesignStyle.NEON -> t.accent
        DesignStyle.SKEUOMORPHISM -> Color(0xFFFFE9A8)
        DesignStyle.NEUMORPHISM -> t.primary
        DesignStyle.GLASSMORPHISM -> t.primary
        DesignStyle.Y2K -> t.accent
        DesignStyle.AURORA -> t.primary
        DesignStyle.CLAYMORPHISM -> ClayInk
        DesignStyle.DARK -> t.primary
        DesignStyle.COSMIC, DesignStyle.SCIFI_HUD, DesignStyle.NEOCLASSICAL -> t.primary
        DesignStyle.CYBER_INDUSTRIAL -> Color(0xFF111111)
    }
    val idle = if (style == DesignStyle.SKEUOMORPHISM) Color(0xFFFFF3D6).copy(alpha = 0.72f)
    else t.text.copy(alpha = if (style == DesignStyle.MINIMAL) 0.4f else 0.65f)
    val color by animateColorAsState(
        if (selected) selColor else idle,
        tween(fadeMs(style)),
        label = "tabColor"
    )
    val itemShape = when (style) {
        DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> CutCornerShape(8.dp)
        DesignStyle.FRUTIGER_AERO -> RoundedCornerShape(12.dp)
        DesignStyle.WINDOWS11 -> RoundedCornerShape(6.dp)
        DesignStyle.SKEUOMORPHISM -> RoundedCornerShape(6.dp)
        DesignStyle.NEUMORPHISM, DesignStyle.GLASSMORPHISM -> RoundedCornerShape(12.dp)
        DesignStyle.Y2K, DesignStyle.AURORA, DesignStyle.CLAYMORPHISM -> RoundedCornerShape(12.dp)
        DesignStyle.DARK -> RoundedCornerShape(16.dp)
        DesignStyle.COSMIC -> RoundedCornerShape(50)
        DesignStyle.CYBER_INDUSTRIAL -> CutCornerShape(4.dp)
        else -> RoundedCornerShape(0.dp)
    }
    val bg = when {
        !selected -> Modifier
        (style == DesignStyle.FUTURISTIC || style == DesignStyle.TERMINAL) ->
            Modifier.background(t.primary.copy(alpha = 0.14f), itemShape)
                .border(1.dp, t.primary.copy(alpha = 0.7f), itemShape)
        style == DesignStyle.FRUTIGER_AERO ->
            Modifier.background(Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFBFE4FF))), itemShape)
                .border(1.dp, Color.White, itemShape)
        style == DesignStyle.WINDOWS11 -> Modifier.background(Color(0x0F000000), itemShape)
        style == DesignStyle.SKEUOMORPHISM ->
            Modifier.skeuoSurface(itemShape, Color(0xFF3E2512), Color(0xFF55331A), pressed = 1f, elevation = 0.dp, gloss = false)
        style == DesignStyle.NEUMORPHISM -> Modifier.neuSurface(itemShape, t.surface, 1f, 3.dp, 6.dp)
        style == DesignStyle.GLASSMORPHISM -> Modifier.glassPanel(itemShape, t.primary, 0.22f, shadow = false)
        style == DesignStyle.Y2K ->
            Modifier.y2kGel(itemShape, Color.White, Color(0xFFCFE0FF), Color(0xFF9FB5F0))
        style == DesignStyle.AURORA -> Modifier.auroraPanel(itemShape, 0.6f)
        style == DesignStyle.CLAYMORPHISM -> Modifier.clayWell(itemShape, t.background)
        style == DesignStyle.DARK -> Modifier.background(Color(0x228AB4F8), itemShape)
        style == DesignStyle.COSMIC -> Modifier.background(CosmicLavender.copy(alpha = 0.16f), itemShape)
        style == DesignStyle.SCIFI_HUD -> Modifier.hudPanel(HudAmber, 1f, grid = false)
        style == DesignStyle.CYBER_INDUSTRIAL -> Modifier.yellowPlate(itemShape, 1f)
        style == DesignStyle.NEOCLASSICAL -> Modifier.hairline(NeoGold, top = false)
        else -> Modifier
    }
    val textStyle = if (style == DesignStyle.NEON && selected) {
        LocalTextStyle.current.copy(shadow = Shadow(t.accent, blurRadius = 16f))
    } else LocalTextStyle.current
    val shown = if ((style == DesignStyle.FUTURISTIC || style == DesignStyle.TERMINAL) || style == DesignStyle.NEON ||
        style == DesignStyle.SCIFI_HUD || style == DesignStyle.CYBER_INDUSTRIAL || style == DesignStyle.NEOCLASSICAL) {
        label.uppercase(java.util.Locale.getDefault())
    } else label

    Box(
        modifier
            .padding(2.dp)
            .then(bg)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                shown,
                color = color,
                style = textStyle,
                fontSize = fontSize,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (selected && style == DesignStyle.MINIMAL) {
                Box(Modifier.padding(top = 4.dp).size(4.dp).background(color, CircleShape))
            }
            if (selected && style == DesignStyle.WINDOWS11) {
                Box(
                    Modifier.padding(top = 4.dp).width(16.dp).height(3.dp)
                        .background(t.primary, RoundedCornerShape(2.dp))
                )
            }
            if (selected && style == DesignStyle.NEON) {
                Box(
                    Modifier.padding(top = 4.dp).width(24.dp).height(2.dp)
                        .shadow(6.dp, ambientColor = t.accent, spotColor = t.accent)
                        .background(t.accent)
                )
            }
        }
    }
}

@Composable
fun ThemedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    secret: Boolean = false
) {
    val d = LocalDesign.current
    val t = d.tokens
    OutlinedTextField(
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = if (secret) KeyboardOptions(keyboardType = KeyboardType.NumberPassword) else KeyboardOptions.Default,
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder) },
        singleLine = true,
        shape = buttonShape(d.style),
        modifier = when (d.style) {
            DesignStyle.NEUMORPHISM -> modifier.neuSurface(buttonShape(d.style), t.surface, depth = 1f, dist = 3.dp, blur = 6.dp)
            DesignStyle.CLAYMORPHISM -> modifier.clayWell(buttonShape(d.style), t.background)
            else -> modifier
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = t.text,
            unfocusedTextColor = t.text,
            cursorColor = t.primary,
            focusedBorderColor = t.primary,
            unfocusedBorderColor = when (d.style) {
                DesignStyle.FRUTIGER_AERO -> Color.White
                DesignStyle.NEUMORPHISM -> Color.Transparent
                DesignStyle.GLASSMORPHISM -> Color.White.copy(alpha = 0.45f)
                DesignStyle.SKEUOMORPHISM -> Color(0xFF8A6A44)
                DesignStyle.Y2K -> Color.White
                DesignStyle.AURORA -> AuroraMint.copy(alpha = 0.4f)
                DesignStyle.CLAYMORPHISM -> Color.Transparent
                DesignStyle.DARK -> Color(0xFF5F5F5F)
                DesignStyle.COSMIC -> CosmicLavender.copy(alpha = 0.5f)
                DesignStyle.SCIFI_HUD -> HudAmber.copy(alpha = 0.5f)
                DesignStyle.CYBER_INDUSTRIAL -> Color(0xFF8A8F96)
                DesignStyle.NEOCLASSICAL -> NeoGold
                else -> t.text.copy(alpha = 0.35f)
            },
            focusedPlaceholderColor = t.text.copy(alpha = 0.5f),
            unfocusedPlaceholderColor = t.text.copy(alpha = 0.5f),
            focusedContainerColor = when (d.style) {
                DesignStyle.FRUTIGER_AERO -> Color(0xB3FFFFFF)
                DesignStyle.NEUMORPHISM -> Color.Transparent
                DesignStyle.GLASSMORPHISM -> Color.White.copy(alpha = 0.18f)
                DesignStyle.SKEUOMORPHISM -> Color(0xFFFFFAEB)
                DesignStyle.Y2K -> Color.White
                DesignStyle.CLAYMORPHISM -> Color.Transparent
                else -> t.surface
            },
            unfocusedContainerColor = when (d.style) {
                DesignStyle.FRUTIGER_AERO -> Color(0x80FFFFFF)
                DesignStyle.NEUMORPHISM -> Color.Transparent
                DesignStyle.GLASSMORPHISM -> Color.White.copy(alpha = 0.12f)
                DesignStyle.SKEUOMORPHISM -> Color(0xFFFFFAEB)
                DesignStyle.Y2K -> Color.White
                DesignStyle.CLAYMORPHISM -> Color.Transparent
                else -> t.surface
            }
        )
    )
}
