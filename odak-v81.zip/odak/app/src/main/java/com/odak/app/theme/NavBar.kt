package com.odak.app.theme

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val AeroIconColors = listOf(
    Color(0xFF7FC6FF) to Color(0xFF1C78E6),
    Color(0xFF9AF26A) to Color(0xFF2FA52A),
    Color(0xFFFFD27A) to Color(0xFFEE8A10),
    Color(0xFFD9A0FF) to Color(0xFF8A3FD0),
    Color(0xFFCFD8E0) to Color(0xFF7D8B99)
)

private val NeonIcons = listOf("◈", "☑", "◔", "⛔", "⚙")

/** Alt gezinme çubuğu. Her tasarımda ayrı yapı: köşeli menü, dock, yazı, görev çubuğu, neon çubuk. */
@Composable
fun ThemedNavBar(
    labels: List<String>,
    icons: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val d = LocalDesign.current
    val t = d.tokens
    val style = d.style
    val pick: (Int) -> Unit = {
        ClickSound.play(style, SoundKind.TAP)
        onSelect(it)
    }
    when (style) {
        DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> Row(
            modifier
                .fillMaxWidth()
                .background(t.surface)
                .hairlineTop(t.primary.copy(alpha = 0.5f))
                .navigationBarsPadding()
        ) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                val up = l.uppercase(Locale.getDefault())
                Text(
                    if (on) "[$up]" else up,
                    fontSize = 8.sp,
                    letterSpacing = 0.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                    textAlign = TextAlign.Center,
                    color = if (on) t.primary else Color(0xFF5B7A90),
                    style = if (on) LocalTextStyle.current.copy(shadow = Shadow(t.primary, blurRadius = 16f))
                    else LocalTextStyle.current,
                    modifier = Modifier.weight(1f).plainClick { pick(i) }.padding(vertical = 22.dp)
                )
            }
        }
        DesignStyle.FRUTIGER_AERO -> {
            val shape = RoundedCornerShape(24.dp)
            Box(modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 30.dp, vertical = 12.dp)) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .shadow(8.dp, shape, ambientColor = Color(0xFF0054E3), spotColor = Color(0xFF0054E3))
                        .clip(shape)
                        .background(Brush.verticalGradient(listOf(Color(0xE6FFFFFF), Color(0xB3DDF1FF))))
                        .border(1.5.dp, Color.White, shape)
                        .padding(horizontal = 6.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    icons.forEachIndexed { i, ic ->
                        val on = i == selected
                        val s by animateFloatAsState(if (on) 1.12f else 1f, motion(style), label = "dock")
                        val (c1, c2) = AeroIconColors[i % AeroIconColors.size]
                        val ish = RoundedCornerShape(14.dp)
                        Box(
                            Modifier
                                .offset(y = if (on) (-6).dp else 0.dp)
                                .scale(s)
                                .size(46.dp)
                                .background(Brush.verticalGradient(listOf(c1, c2)), ish)
                                .border(1.dp, Color.White, ish)
                                .plainClick { pick(i) },
                            contentAlignment = Alignment.Center
                        ) { Text(ic, fontSize = 22.sp) }
                    }
                }
            }
        }
        DesignStyle.MINIMAL -> Row(
            modifier
                .fillMaxWidth()
                .hairlineTop(Color(0x66888888), 1f)
                .navigationBarsPadding()
                .padding(vertical = 16.dp)
        ) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Column(
                    Modifier.weight(1f).plainClick { pick(i) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        l.lowercase(Locale.getDefault()),
                        fontSize = 11.sp,
                        letterSpacing = 1.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = if (on) t.text else Color(0xFFA8A8A8)
                    )
                    if (on) {
                        Box(Modifier.padding(top = 6.dp).size(4.dp).background(t.text, CircleShape))
                    }
                }
            }
        }
        DesignStyle.WINDOWS11 -> Row(
            modifier
                .fillMaxWidth()
                .background(Color(0xE6F3F3F3))
                .hairlineTop(Color(0x1F000000), 1f)
                .navigationBarsPadding()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            icons.forEachIndexed { i, ic ->
                val on = i == selected
                Box(
                    Modifier
                        .padding(horizontal = 4.dp)
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .then(if (on) Modifier.background(Color(0xBFFFFFFF)) else Modifier)
                        .plainClick { pick(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(ic, fontSize = 20.sp)
                    Box(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 3.dp)
                            .width(if (on) 14.dp else 5.dp)
                            .height(3.dp)
                            .background(if (on) t.primary else Color(0xFF888888), RoundedCornerShape(2.dp))
                    )
                }
            }
        }
        DesignStyle.NEON -> Row(
            modifier
                .fillMaxWidth()
                .background(t.background.copy(alpha = 0.94f))
                .hairlineTop(t.accent, 4f)
                .navigationBarsPadding()
                .padding(vertical = 10.dp)
        ) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                val c = if (on) t.accent else Color(0xFF6A7AA8)
                val glow = if (on) LocalTextStyle.current.copy(shadow = Shadow(t.accent, blurRadius = 18f))
                else LocalTextStyle.current
                Column(
                    Modifier.weight(1f).plainClick { pick(i) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(NeonIcons[i % NeonIcons.size], fontSize = 20.sp, color = c, style = glow)
                    Text(
                        l.uppercase(Locale.getDefault()),
                        fontSize = 8.sp,
                        letterSpacing = 1.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Clip,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        color = c,
                        style = glow
                    )
                }
            }
        }
        // Deri çubuk üstünde pirinç düğmeler; seçili olan basılı (gömülü) durur.
        DesignStyle.SKEUOMORPHISM -> Row(
            modifier
                .fillMaxWidth()
                .skeuoSurface(
                    RectangleShape, Color(0xFF8A5A33), Color(0xFF4F3019),
                    grain = Grain.LEATHER, elevation = 8.dp, stitch = Color(0x66FFF3D6), gloss = false
                )
                .navigationBarsPadding()
                .padding(horizontal = 6.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            icons.forEachIndexed { i, ic ->
                val on = i == selected
                val down by animateFloatAsState(if (on) 1f else 0f, motion(style), label = "skNav")
                Column(
                    Modifier.weight(1f).plainClick { pick(i) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.size(44.dp).skeuoSurface(
                            CircleShape, Color(0xFFE6C06A), Color(0xFF9A6F1E),
                            pressed = down, grain = Grain.METAL, elevation = 4.dp
                        ),
                        contentAlignment = Alignment.Center
                    ) { Text(ic, fontSize = 20.sp) }
                    Text(
                        labels.getOrElse(i) { "" },
                        fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (on) Color(0xFFFFE9A8) else Color(0xFFFFF3D6).copy(alpha = 0.72f),
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }
        }
        // Kabarık yüzen çubuk; seçili simge içe basılır ve vurgu rengini alır.
        DesignStyle.NEUMORPHISM -> Box(
            modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .neuSurface(RoundedCornerShape(28.dp), t.surface, 0f, 6.dp, 14.dp)
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                icons.forEachIndexed { i, ic ->
                    val on = i == selected
                    val dep by animateFloatAsState(if (on) 1f else 0f, tween(160), label = "neuNav")
                    Box(
                        Modifier.size(46.dp).neuSurface(CircleShape, t.surface, dep, 4.dp, 8.dp).plainClick { pick(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(ic, fontSize = 20.sp, color = if (on) t.primary else t.text.copy(alpha = 0.75f))
                    }
                }
            }
        }
        // Yüzen cam hap; seçili öğe renkli cam kapsül olur ve hafif büyür.
        DesignStyle.GLASSMORPHISM -> Box(
            modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .glassPanel(RoundedCornerShape(28.dp), Color.White, 0.16f)
                    .padding(horizontal = 6.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                icons.forEachIndexed { i, ic ->
                    val on = i == selected
                    val sc by animateFloatAsState(if (on) 1.1f else 1f, motion(style), label = "glNav")
                    Column(
                        Modifier
                            .weight(1f)
                            .scale(sc)
                            .plainClick { pick(i) }
                            .then(if (on) Modifier.glassPanel(RoundedCornerShape(18.dp), t.primary, 0.24f, shadow = false) else Modifier)
                            .padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(ic, fontSize = 20.sp)
                        Text(
                            labels.getOrElse(i) { "" },
                            fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (on) t.primary else t.text.copy(alpha = 0.78f)
                        )
                    }
                }
            }
        }
        // Jel balon dock: seçili olan pembe, büyük ve yaylı zıplar.
        DesignStyle.Y2K -> Box(
            modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .y2kGel(RoundedCornerShape(30.dp), Color.White, Color(0xFFE3E9F8), Color(0xFFB9C4DE))
                    .padding(horizontal = 6.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                icons.forEachIndexed { i, ic ->
                    val on = i == selected
                    val s by animateFloatAsState(if (on) 1.22f else 1f, motion(style), label = "y2kNav")
                    Box(
                        Modifier
                            .offset(y = if (on) (-4).dp else 0.dp)
                            .scale(s)
                            .size(42.dp)
                            .then(
                                if (on) Modifier.y2kGel(CircleShape, Color(0xFFFFB3E0), Y2kPink, Color(0xFFC0106F))
                                else Modifier.y2kGel(CircleShape, Color.White, Color(0xFF9FE7FF), Color(0xFF3D7BFF))
                            )
                            .plainClick { pick(i) },
                        contentAlignment = Alignment.Center
                    ) { Text(ic, fontSize = 19.sp) }
                }
            }
        }
        // Işık çizgili koyu çubuk; seçili sekme nane parıltısı + degrade alt çizgi.
        DesignStyle.AURORA -> Row(
            modifier
                .fillMaxWidth()
                .background(Color(0xE6070B1F))
                .hairlineTop(AuroraMint.copy(alpha = 0.35f), 1f)
                .navigationBarsPadding()
                .padding(vertical = 8.dp)
        ) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                val c = if (on) t.primary else Color(0xFF9DB0D8)
                Column(
                    Modifier.weight(1f).plainClick { pick(i) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        icons.getOrElse(i) { "•" }, fontSize = 20.sp, color = c,
                        style = if (on) LocalTextStyle.current.copy(shadow = Shadow(t.primary, blurRadius = 18f)) else LocalTextStyle.current
                    )
                    Text(l, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = c)
                    Box(
                        Modifier.padding(top = 4.dp).width(if (on) 26.dp else 0.dp).height(2.dp)
                            .background(Brush.horizontalGradient(listOf(AuroraMint, AuroraViolet)))
                    )
                }
            }
        }
        // Beyaz kil hap; seçili simge mercan kil top olur.
        DesignStyle.CLAYMORPHISM -> Box(
            modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .claySurface(RoundedCornerShape(30.dp), Color.White, 1f, 6.dp, 16.dp)
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                icons.forEachIndexed { i, ic ->
                    val on = i == selected
                    val s by animateFloatAsState(if (on) 1.1f else 1f, motion(style), label = "clNav")
                    Box(
                        Modifier
                            .scale(s)
                            .size(44.dp)
                            .then(if (on) Modifier.claySurface(CircleShape, t.primary, 1f, 4.dp, 10.dp) else Modifier)
                            .plainClick { pick(i) },
                        contentAlignment = Alignment.Center
                    ) { Text(ic, fontSize = 20.sp, color = t.text) }
                }
            }
        }
        // Material 3: seçili simgenin arkasında hap gösterge.
        DesignStyle.DARK -> Row(
            modifier
                .fillMaxWidth()
                .background(darkElevation(2))
                .navigationBarsPadding()
                .padding(vertical = 8.dp)
        ) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Column(
                    Modifier.weight(1f).plainClick { pick(i) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.width(56.dp).height(28.dp)
                            .background(if (on) Color(0x338AB4F8) else Color.Transparent, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text(icons.getOrElse(i) { "•" }, fontSize = 17.sp, color = if (on) t.accent else Color(0xFF9A9A9A)) }
                    Text(
                        l, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (on) t.text else Color(0xFF9A9A9A),
                        fontWeight = if (on) FontWeight.Medium else FontWeight.Normal,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }
        }
        // Cosmic: yüzen hap; seçili öğe gezegen gibi parlar.
        DesignStyle.COSMIC -> Box(modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 10.dp)) {
            Row(
                Modifier.fillMaxWidth().cosmicPanel(RoundedCornerShape(50), 0.6f).padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically
            ) {
                icons.forEachIndexed { i, ic ->
                    val on = i == selected
                    val s by animateFloatAsState(if (on) 1.25f else 1f, motion(style), label = "cosmicNav")
                    Box(
                        Modifier.size(44.dp).scale(s)
                            .background(if (on) CosmicLavender.copy(alpha = 0.22f) else Color.Transparent, CircleShape)
                            .plainClick { pick(i) },
                        contentAlignment = Alignment.Center
                    ) { Text(ic, fontSize = 20.sp, color = if (on) CosmicGold else t.text.copy(alpha = 0.7f)) }
                }
            }
        }
        // HUD: ince şerit, seçili sekme üstünde amber çubuk ve parantez; etiketler telemetri gibi.
        DesignStyle.SCIFI_HUD -> Row(
            modifier.fillMaxWidth().background(Color(0xF204090F))
                .hairlineTop(HudAmber.copy(alpha = 0.6f)).navigationBarsPadding()
        ) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Column(
                    Modifier.weight(1f).plainClick { pick(i) }
                        .then(if (on) Modifier.hudPanel(HudAmber, 1f, grid = false) else Modifier)
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(icons.getOrElse(i) { "•" }, fontSize = 18.sp, color = if (on) HudAmber else HudCyan.copy(alpha = 0.6f))
                    Text(
                        l.uppercase(Locale.getDefault()), fontSize = 8.sp, letterSpacing = 1.sp, maxLines = 1,
                        overflow = TextOverflow.Clip, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        color = if (on) HudAmber else HudCyan.copy(alpha = 0.7f)
                    )
                }
            }
        }
        // Cyber-Industrial: çelik panel, seçili sekme sarı plaka; üstte uyarı şeridi.
        DesignStyle.CYBER_INDUSTRIAL -> Column(modifier.fillMaxWidth().navigationBarsPadding()) {
            Box(Modifier.fillMaxWidth().height(5.dp).drawBehind {
                hazardStripes(androidx.compose.ui.geometry.Offset.Zero, size, 6.dp.toPx())
            })
            Row(Modifier.fillMaxWidth().steelPlate(RectangleShape, SteelDark, 0f, rivets = false).padding(horizontal = 4.dp, vertical = 6.dp)) {
                labels.forEachIndexed { i, l ->
                    val on = i == selected
                    Column(
                        Modifier.weight(1f).padding(horizontal = 2.dp)
                            .then(if (on) Modifier.yellowPlate(CutCornerShape(4.dp), 0f) else Modifier)
                            .plainClick { pick(i) }.padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(icons.getOrElse(i) { "•" }, fontSize = 18.sp, color = if (on) Color(0xFF111111) else t.text.copy(alpha = 0.75f))
                        Text(
                            l.uppercase(Locale.getDefault()), fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp,
                            maxLines = 1, overflow = TextOverflow.Clip,
                            color = if (on) Color(0xFF111111) else t.text.copy(alpha = 0.75f)
                        )
                    }
                }
            }
        }
        // Neoklasik: mermer şerit, altın ince çizgi, seçili öğe altında altın nokta; serif küçük başlıklar.
        DesignStyle.NEOCLASSICAL -> Row(
            modifier.fillMaxWidth().background(t.surface).hairlineTop(NeoGold).navigationBarsPadding().padding(vertical = 8.dp)
        ) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Column(Modifier.weight(1f).plainClick { pick(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(icons.getOrElse(i) { "•" }, fontSize = 18.sp, color = if (on) t.primary else t.text.copy(alpha = 0.55f))
                    Text(
                        l.uppercase(Locale.getDefault()), fontSize = 8.sp, letterSpacing = 1.5.sp, maxLines = 1,
                        overflow = TextOverflow.Clip, fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
                        color = if (on) t.primary else t.text.copy(alpha = 0.6f)
                    )
                    Box(Modifier.padding(top = 3.dp).size(5.dp).background(if (on) NeoGold else Color.Transparent, CircleShape))
                }
            }
        }
    }
}


/** Yatay (landscape) ekranda sol kenarda dikey gezinme şeridi; tasarıma göre vurgu biçimi. */
@Composable
fun ThemedSideRail(
    labels: List<String>,
    icons: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val d = LocalDesign.current
    val t = d.tokens
    val style = d.style
    val shape = RoundedCornerShape(minOf(t.radius, 14.dp))
    val edge = when (style) {
        DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> t.primary.copy(alpha = 0.5f)
        DesignStyle.NEON -> t.accent
        DesignStyle.MINIMAL -> t.text.copy(alpha = 0.25f)
        else -> t.text.copy(alpha = 0.12f)
    }
    Column(
        modifier.fillMaxHeight().width(84.dp)
            .verticalScroll(androidx.compose.foundation.rememberScrollState())
            .background(if (style == DesignStyle.FRUTIGER_AERO) Color.White.copy(alpha = 0.55f) else t.surface.copy(alpha = 0.92f))
            .drawBehind { drawLine(edge, androidx.compose.ui.geometry.Offset(size.width, 0f), androidx.compose.ui.geometry.Offset(size.width, size.height), 2f) }
            .padding(vertical = 8.dp, horizontal = 6.dp),
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        labels.forEachIndexed { i, label ->
            val on = i == selected
            Column(
                Modifier.fillMaxWidth().clip(shape)
                    .background(if (on) t.primary.copy(alpha = if (style == DesignStyle.MINIMAL) 1f else 0.22f) else Color.Transparent)
                    .then(if (on && (style == DesignStyle.NEON || style == DesignStyle.FUTURISTIC || style == DesignStyle.TERMINAL))
                        Modifier.border(1.dp, t.primary, shape) else Modifier)
                    .plainClick { ClickSound.play(style, SoundKind.TAP); onSelect(i) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    icons.getOrElse(i) { "•" }, fontSize = 20.sp,
                    color = if (on && style == DesignStyle.MINIMAL) t.surface else t.text
                )
                Text(
                    if (style == DesignStyle.TERMINAL) "> " + label.lowercase(Locale.getDefault()) else label,
                    fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                    color = if (on) (if (style == DesignStyle.MINIMAL) t.surface else t.primary) else t.text.copy(alpha = 0.7f),
                    fontWeight = if (on) FontWeight.Bold else null
                )
            }
        }
    }
}
