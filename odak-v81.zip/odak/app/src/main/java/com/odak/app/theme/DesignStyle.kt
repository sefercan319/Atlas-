package com.odak.app.theme

import android.content.Context
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

enum class DesignStyle(val label: String, val key: String) {
    FUTURISTIC("Futuristik", "futuristic"),
    FRUTIGER_AERO("Frutiger Aero", "frutiger_aero"),
    MINIMAL("Minimal", "minimal"),
    WINDOWS11("Modern", "windows11"),
    NEON("Neon", "neon"),
    TERMINAL("Terminal", "terminal"),
    SKEUOMORPHISM("Skeuomorphism", "skeuomorphism"),
    NEUMORPHISM("Neumorphism", "neumorphism"),
    GLASSMORPHISM("Glassmorphism", "glassmorphism"),
    Y2K("Y2K", "y2k"),
    AURORA("Aurora UI", "aurora"),
    CLAYMORPHISM("Claymorphism", "claymorphism"),
    DARK("Dark Mode", "dark_mode"),
    COSMIC("Cosmic Dark", "cosmic"),
    SCIFI_HUD("Sci-Fi HUD", "scifi_hud"),
    CYBER_INDUSTRIAL("Cyber-Industrial", "cyber_industrial"),
    NEOCLASSICAL("Neoclassical", "neoclassical")
}

data class DesignTokens(
    val background: Color,
    val surface: Color,
    val primary: Color,
    val accent: Color,
    val text: Color,
    val radius: Dp
)

fun tokensFor(style: DesignStyle): DesignTokens {
    val b = baseTokens(style)
    return b.copy(
        primary = ColorPrefs.primaryOf(style) ?: b.primary,
        accent = ColorPrefs.accentOf(style) ?: b.accent
    )
}

private fun baseTokens(style: DesignStyle): DesignTokens = when (style) {
    // Geçici palet: Futuristik renkleri henüz verilmedi.
    DesignStyle.FUTURISTIC -> DesignTokens(
        background = Color(0xFF0A0A0F),
        surface = Color(0xFF14141F),
        primary = Color(0xFF00E5FF),
        accent = Color(0xFF7C4DFF),
        text = Color(0xFFE0F7FF),
        radius = 4.dp
    )
    DesignStyle.FRUTIGER_AERO -> DesignTokens(
        background = Color(0xFF87CEEB),
        surface = Color(0xB3FFFFFF),
        primary = Color(0xFF0054E3),
        accent = Color(0xFF7CFC00),
        text = Color(0xFF0B2540),
        radius = 20.dp
    )
    DesignStyle.MINIMAL -> DesignTokens(
        background = Color(0xFFFAFAFA),
        surface = Color(0xFFFFFFFF),
        primary = Color(0xFF111111),
        accent = Color(0xFF888888),
        text = Color(0xFF111111),
        radius = 0.dp
    )
    DesignStyle.WINDOWS11 -> DesignTokens(
        background = Color(0xFFF3F3F3),
        surface = Color(0xFFFFFFFF),
        primary = Color(0xFF0067C0),
        accent = Color(0xFF0078D4),
        text = Color(0xFF1A1A1A),
        radius = 8.dp
    )
    DesignStyle.TERMINAL -> DesignTokens(
        background = Color(0xFF020B04),
        surface = Color(0xFF07160A),
        primary = Color(0xFF33FF66),
        accent = Color(0xFFFFB000),
        text = Color(0xFFB8FFC8),
        radius = 0.dp
    )
    DesignStyle.NEON -> DesignTokens(
        background = Color(0xFF01012B),
        surface = Color(0xFF0B0B3B),
        primary = Color(0xFFFF2A6D),
        accent = Color(0xFF05D9E8),
        text = Color(0xFFD1F7FF),
        radius = 12.dp
    )
    // Kenevir/kraft kâğıt zemin, deri-pirinç kontroller; metin koyu kahve (≥7:1).
    DesignStyle.SKEUOMORPHISM -> DesignTokens(
        background = Color(0xFFD8C9AC),
        surface = Color(0xFFF6EDD9),
        primary = Color(0xFF7A3E1D),
        accent = Color(0xFFB8892E),
        text = Color(0xFF2B1D12),
        radius = 10.dp
    )
    // Tek renk yüzey (#E0E5EC); çift gölge ışık kaynağını verir. Vurgu yalnız etkileşimli öğelerde.
    DesignStyle.NEUMORPHISM -> DesignTokens(
        background = Color(0xFFE0E5EC),
        surface = Color(0xFFE0E5EC),
        primary = Color(0xFF2F49D1),
        accent = Color(0xFF4B5A7A),
        text = Color(0xFF2D3748),
        radius = 20.dp
    )
    // Canlı gradyan üstünde buzlu cam paneller; beyaz metin.
    DesignStyle.GLASSMORPHISM -> DesignTokens(
        background = Color(0xFF14083F),
        surface = Color(0x29FFFFFF),
        primary = Color(0xFF7DF9FF),
        accent = Color(0xFFFF9BD2),
        text = Color(0xFFF5F7FF),
        radius = 24.dp
    )
    // Milenyum: aqua-lavanta-pembe zemin, elektrik mavisi jel düğmeler, lacivert metin.
    DesignStyle.Y2K -> DesignTokens(
        background = Color(0xFFD9C8FF),
        surface = Color(0xFFF4EEFF),
        primary = Color(0xFF1F46D6),
        accent = Color(0xFFC0106F),
        text = Color(0xFF1B1F4B),
        radius = 22.dp
    )
    // Kutup ışığı: gece mavisi zemin, nane ve mor ışık.
    DesignStyle.AURORA -> DesignTokens(
        background = Color(0xFF070B1F),
        surface = Color(0xFF0D1636),
        primary = Color(0xFF5EEAD4),
        accent = Color(0xFFA78BFA),
        text = Color(0xFFEAF2FF),
        radius = 20.dp
    )
    // Oyun hamuru: pastel zemin, mercan eylem rengi, koyu mor-gri metin.
    DesignStyle.CLAYMORPHISM -> DesignTokens(
        background = Color(0xFFF7F5FB),
        surface = Color(0xFFEDE6FF),
        primary = Color(0xFFFF7A6B),
        accent = Color(0xFF5B3FD6),
        text = Color(0xFF2E2A3F),
        radius = 26.dp
    )
    // Koyu mod: #121212 zemin, yükseldikçe açılan yüzey, ~%20 soluk vurgu, %90 beyaz metin.
    DesignStyle.DARK -> DesignTokens(
        background = Color(0xFF121212),
        surface = Color(0xFF1E1E1E),
        primary = Color(0xFF8AB4F8),
        accent = Color(0xFFA8C7FA),
        text = Color(0xFFE6E6E6),
        radius = 12.dp
    )
    // Derin uzay: mor-siyah zemin, lavanta vurgu, yıldız altını ikincil.
    DesignStyle.COSMIC -> DesignTokens(
        background = Color(0xFF05020F),
        surface = Color(0xFF120A2B),
        primary = Color(0xFFB4A7FF),
        accent = Color(0xFFFFC857),
        text = Color(0xFFEDE9FF),
        radius = 18.dp
    )
    // Başlık üstü ekran: mavi-siyah zemin, amber ana okuma, camgöbeği ikincil.
    DesignStyle.SCIFI_HUD -> DesignTokens(
        background = Color(0xFF04090F),
        surface = Color(0xFF08161F),
        primary = Color(0xFFFFB020),
        accent = Color(0xFF4DD8FF),
        text = Color(0xFFE8F6FF),
        radius = 2.dp
    )
    // Endüstriyel: isli çelik, uyarı sarısı, turuncu ikincil.
    DesignStyle.CYBER_INDUSTRIAL -> DesignTokens(
        background = Color(0xFF16181B),
        surface = Color(0xFF23272C),
        primary = Color(0xFFFFC400),
        accent = Color(0xFFFF7A3D),
        text = Color(0xFFE9E6DF),
        radius = 2.dp
    )
    // Lüks klasik: fildişi/mermer, koyu altın yazı, mürekkep metin. Parlak altın yalnız süsleme.
    DesignStyle.NEOCLASSICAL -> DesignTokens(
        background = Color(0xFFF3EEE3),
        surface = Color(0xFFFBF8F0),
        primary = Color(0xFF6F5210),
        accent = Color(0xFF5B4A2B),
        text = Color(0xFF1F1B16),
        radius = 2.dp
    )
}

data class Design(val style: DesignStyle) {
    val tokens: DesignTokens get() = tokensFor(style)
}

val LocalDesign = compositionLocalOf { Design(DesignStyle.MINIMAL) }

object ThemePrefs {
    private const val PREFS = "odak_theme"
    private const val KEY = "style"

    fun load(context: Context): DesignStyle {
        val name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        return DesignStyle.entries.firstOrNull { it.name == name } ?: DesignStyle.MINIMAL
    }

    fun save(context: Context, style: DesignStyle) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, style.name).apply()
    }
}
