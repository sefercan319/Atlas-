package com.odak.app.todo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class Sub(val t: String, val d: Boolean)

/** prio: 0 düşük, 1 orta, 2 yüksek. cat: 0 yok, 1 🏠, 2 💼, 3 🎓, 4 ❤. */
data class TodoItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val done: Boolean = false,
    val prio: Int = 1,
    /** ISO tarih (yyyy-MM-dd) veya null. */
    val due: String? = null,
    val cat: Int = 0,
    val subs: List<Sub> = emptyList(),
    /** Her gün yenilenen görev. */
    val rep: Boolean = false
)

object TodoStore {
    private const val PREFS = "odak_todo"
    private const val KEY = "items"

    fun load(c: Context): List<TodoItem> {
        val raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).mapNotNull { i -> try {
                val o = a.getJSONObject(i)
                val sa = o.optJSONArray("subs")
                TodoItem(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    done = o.optBoolean("done", false),
                    prio = o.optInt("prio", 1),
                    due = if (o.has("due")) o.getString("due") else null,
                    cat = o.optInt("cat", 0),
                    rep = o.optBoolean("rep", false),
                    subs = if (sa == null) emptyList() else List(sa.length()) { j ->
                        sa.getJSONObject(j).let { Sub(it.getString("t"), it.optBoolean("d", false)) }
                    }
                )
            } catch (e: Exception) { null } }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(c: Context, items: List<TodoItem>) {
        val a = JSONArray()
        items.forEach { it0 ->
            val o = JSONObject().put("id", it0.id).put("title", it0.title).put("done", it0.done)
                .put("prio", it0.prio).put("cat", it0.cat).put("rep", it0.rep)
            it0.due?.let { d -> o.put("due", d) }
            val sa = JSONArray()
            it0.subs.forEach { s -> sa.put(JSONObject().put("t", s.t).put("d", s.d)) }
            o.put("subs", sa)
            a.put(o)
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }
}
