package com.odak.app.plan

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.odak.app.theme.plainClick
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.time.format.TextStyle as JTextStyle

private const val H0 = 8
private const val H1 = 20

@Composable
private fun DayNumber(n: Int, today: Boolean, skin: GridSkin) {
    val ring = skin.numberStyle == NumStyle.RING
    val m = Modifier
        .padding(top = 2.dp)
        .size(26.dp)
        .then(if (today && !ring) Modifier.background(skin.todayAccent, CircleShape) else Modifier)
        .then(if (today && ring) Modifier.border(1.dp, skin.todayAccent, CircleShape) else Modifier)
    Box(m, contentAlignment = Alignment.Center) {
        Text(
            n.toString(),
            fontSize = 13.sp,
            color = if (today && !ring) skin.todayOnAccent else skin.dayNum
        )
    }
}

@Composable
private fun EventBlock(p: PlanItem, ev: EvColor, skin: GridSkin, modifier: Modifier) {
    val shape = skin.eventShape
    var m = modifier
        .alpha(if (p.done) 0.45f else 1f)
        .clip(shape)
        .background(ev.bg, shape)
    if (!skin.leftBar) m = m.border(skin.eventBorderW, ev.border, shape)
    Row(m) {
        if (skin.leftBar) {
            Box(Modifier.width(3.dp).fillMaxHeight().background(ev.border))
        }
        Text(
            if (skin.eventUpper) p.title.uppercase(Locale.getDefault()) else p.title,
            fontSize = 8.5.sp,
            color = ev.text,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textDecoration = if (p.done) TextDecoration.LineThrough else null,
            modifier = Modifier.padding(horizontal = 3.dp, vertical = 2.dp)
        )
    }
}

/** Haftalık saat çizelgesi: gün sütunları x saat satırları. */
@Composable
fun WeekGrid(
    items: List<PlanItem>,
    weekStart: LocalDate,
    today: LocalDate,
    skin: GridSkin,
    modifier: Modifier = Modifier,
    hourHeight: Dp = 38.dp,
    onPickDay: (LocalDate) -> Unit
) {
    val gutter = 34.dp
    val hours = H1 - H0
    val locale = Locale.getDefault()
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth()) {
            Spacer(Modifier.width(gutter))
            for (i in 0..6) {
                val d = weekStart.plusDays(i.toLong())
                val isToday = d == today
                Column(
                    Modifier.weight(1f).plainClick { onPickDay(d) }.padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        d.dayOfWeek.getDisplayName(JTextStyle.NARROW, locale),
                        fontSize = 10.sp,
                        color = if (isToday) skin.todayAccent else skin.dayLabel
                    )
                    DayNumber(d.dayOfMonth, isToday, skin)
                }
            }
        }
        BoxWithConstraints(Modifier.fillMaxWidth().height(hourHeight * hours)) {
            val colW = (maxWidth - gutter) / 7
            val ti = ChronoUnit.DAYS.between(weekStart, today).toInt()
            if (ti in 0..6) {
                Box(
                    Modifier
                        .offset(x = gutter + colW * ti)
                        .width(colW)
                        .fillMaxHeight()
                        .background(skin.todayColBg)
                )
            }
            Canvas(Modifier.fillMaxSize()) {
                val g = gutter.toPx()
                val hh = hourHeight.toPx()
                val cw = (size.width - g) / 7f
                val sw = 1.dp.toPx()
                for (h in 0..hours) {
                    drawLine(skin.line, Offset(g, h * hh), Offset(size.width, h * hh), sw)
                }
                for (c in 0..7) {
                    drawLine(skin.line, Offset(g + c * cw, 0f), Offset(g + c * cw, size.height), sw)
                }
            }
            for (h in 0..hours step 2) {
                Text(
                    String.format(Locale.ROOT, "%02d", H0 + h),
                    fontSize = 9.sp,
                    color = skin.hourLabel,
                    textAlign = TextAlign.End,
                    modifier = Modifier.offset(y = hourHeight * h - 6.dp).width(gutter - 6.dp)
                )
            }
            items.forEach { p ->
                if (!p.hasTime) return@forEach
                val di = ChronoUnit.DAYS.between(weekStart, p.date).toInt()
                if (di !in 0..6) return@forEach
                val startH = (p.startMin / 60f).coerceIn(H0.toFloat(), H1 - 0.5f)
                val top = hourHeight * (startH - H0)
                val h = (hourHeight * (p.durMin / 60f)).coerceAtLeast(18.dp)
                EventBlock(
                    p,
                    evOf(skin, p),
                    skin,
                    Modifier
                        .offset(x = gutter + colW * di + 1.dp, y = top)
                        .width(colW - 2.dp)
                        .height(h - 2.dp)
                        .plainClick { onPickDay(p.date) }
                )
            }
        }
    }
}

@Composable
private fun MonthCell(
    d: LocalDate,
    inMonth: Boolean,
    isToday: Boolean,
    list: List<PlanItem>,
    skin: GridSkin,
    marks: Marks,
    height: Dp,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val shape = skin.cellShape
    val bg = if (isToday) skin.todayCellBg else skin.cellBg
    var m = modifier
        .height(height)
        .alpha(if (inMonth) 1f else skin.otherAlpha)
        .clip(shape)
        .background(bg, shape)
    if (skin.cellBorderW > 0.dp) {
        val bc = if (isToday && skin.numberStyle == NumStyle.PLAIN) skin.todayAccent else skin.cellBorder
        m = m.border(skin.cellBorderW, bc, shape)
    }
    Box(m.plainClick(onClick).padding(4.dp)) {
        val ring = skin.numberStyle == NumStyle.RING && isToday
        val filled = skin.numberStyle == NumStyle.FILLED && isToday
        val numMod = Modifier
            .align(if (skin.centerNumber) Alignment.TopCenter else Alignment.TopStart)
            .then(if (ring || filled) Modifier.size(22.dp) else Modifier)
            .then(if (filled) Modifier.background(skin.todayAccent, CircleShape) else Modifier)
            .then(if (ring) Modifier.border(1.dp, skin.todayAccent, CircleShape) else Modifier)
        Box(numMod, contentAlignment = Alignment.Center) {
            Text(
                d.dayOfMonth.toString(),
                fontSize = 12.sp,
                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                color = when {
                    filled -> skin.todayOnAccent
                    isToday -> skin.todayCellText
                    else -> skin.dayNum
                }
            )
        }
        val shown = list.sortedBy { it.startMin }.take(3)
        if (shown.isNotEmpty()) {
            when (marks) {
                Marks.BARS -> Column(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    shown.forEach {
                        Box(
                            Modifier.fillMaxWidth().height(4.dp)
                                .background(markOf(skin, it))
                        )
                    }
                }
                Marks.ORBS -> Row(
                    Modifier.align(Alignment.BottomStart),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    shown.forEach {
                        Box(
                            Modifier.size(8.dp)
                                .background(markOf(skin, it), CircleShape)
                                .border(1.dp, Color.White, CircleShape)
                        )
                    }
                }
                Marks.DOTS -> Row(
                    Modifier.align(Alignment.BottomCenter),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    shown.forEach {
                        Box(Modifier.size(3.dp).background(markOf(skin, it), CircleShape))
                    }
                }
                Marks.GLOW -> Row(
                    Modifier.align(Alignment.BottomStart),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    shown.forEach {
                        val c = if (isToday) Color.White else markOf(skin, it)
                        Box(
                            Modifier.size(6.dp)
                                .shadow(6.dp, CircleShape, ambientColor = c, spotColor = c)
                                .background(c, CircleShape)
                        )
                    }
                }
                Marks.CHIPS -> Column(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    shown.take(2).forEach {
                        val ev = evOf(skin, it)
                        Row(
                            Modifier.fillMaxWidth().height(12.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(ev.bg)
                        ) {
                            Box(Modifier.width(2.dp).fillMaxHeight().background(ev.border))
                            Text(
                                it.title,
                                fontSize = 8.sp,
                                color = ev.text,
                                maxLines = 1,
                                overflow = TextOverflow.Clip,
                                modifier = Modifier.padding(start = 3.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Aylık takvim ızgarası. */
@Composable
fun MonthGrid(
    items: List<PlanItem>,
    month: YearMonth,
    today: LocalDate,
    selected: LocalDate?,
    skin: GridSkin,
    modifier: Modifier = Modifier,
    cellHeight: Dp = 62.dp,
    marks: Marks = skin.marks,
    onPickDay: (LocalDate) -> Unit
) {
    val locale = Locale.getDefault()
    val first = month.atDay(1)
    val offset = first.dayOfWeek.value - 1
    val gridStart = first.minusDays(offset.toLong())
    val rows = (offset + month.lengthOfMonth() + 6) / 7
    val byDate = items.groupBy { it.date }
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth()) {
            for (i in 1..7) {
                Text(
                    DayOfWeek.of(i).getDisplayName(JTextStyle.SHORT, locale),
                    fontSize = 10.sp,
                    color = skin.dayLabel,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    modifier = Modifier.weight(1f).padding(vertical = 4.dp)
                )
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0..6) {
                    val d = gridStart.plusDays((r * 7 + c).toLong())
                    MonthCell(
                        d = d,
                        inMonth = d.month == month.month,
                        isToday = d == today || d == selected,
                        list = byDate[d].orEmpty(),
                        skin = skin,
                        marks = marks,
                        height = cellHeight,
                        modifier = Modifier.weight(1f).padding(1.5.dp)
                    ) { onPickDay(d) }
                }
            }
        }
    }
}

/** Seçili özel renk varsa ondan türetilmiş etkinlik rengi, yoksa temanın rengi. */
fun evOf(skin: GridSkin, p: PlanItem): EvColor {
    val c = customColor(p) ?: return skin.events[colorIndex(p)]
    val dark = skin.dayNum.luminance() > 0.6f
    return EvColor(
        c.copy(alpha = 0.28f), c,
        androidx.compose.ui.graphics.lerp(c, if (dark) Color.White else Color.Black, if (dark) 0.65f else 0.45f)
    )
}

fun markOf(skin: GridSkin, p: PlanItem): Color = customColor(p) ?: skin.markColors[colorIndex(p)]
