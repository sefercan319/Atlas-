package com.odak.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.core.view.WindowCompat
import com.odak.app.block.BlockScreen
import com.odak.app.block.ScreenTimeScreen
import com.odak.app.plan.PlanScreen
import com.odak.app.settings.GuideScreen
import com.odak.app.settings.SettingsScreen
import com.odak.app.todo.TodoScreen
import com.odak.app.theme.ClickSound
import com.odak.app.theme.ColorPrefs
import com.odak.app.theme.Design
import com.odak.app.theme.DesignStyle
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.ThemePrefs
import com.odak.app.theme.modeInvert
import com.odak.app.theme.ThemedBackground
import com.odak.app.theme.ThemedNavBar
import com.odak.app.theme.pageTransition
import com.odak.app.theme.tokensFor
import com.odak.app.theme.typographyFor

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ClickSound.init(applicationContext)
        ColorPrefs.init(applicationContext)
        com.odak.app.theme.UiScale.init(applicationContext)
        ClickSound.enabled = getSharedPreferences("odak_app", MODE_PRIVATE).getBoolean("sound", true)
        ClickSound.haptic = getSharedPreferences("odak_app", MODE_PRIVATE).getBoolean("haptic", true)
        Thread {
            try {
                com.odak.app.block.BlockStore.pruneOld(applicationContext)
                com.odak.app.notify.Reminders.rescheduleAll(applicationContext)
            } catch (e: Exception) { }
        }.start()
        setContent {
            OdakApp()
        }
    }
}

@Composable
fun OdakApp() {
    val context = LocalContext.current
    var style by remember { mutableStateOf(ThemePrefs.load(context)) }
    var mode by remember { mutableStateOf(com.odak.app.theme.ThemeMode.load(context)) }
    val inv = com.odak.app.theme.ThemeMode.shouldInvert(style, mode)
    var fscale by remember {
        mutableStateOf(
            context.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE).getFloat("fscale", 1f)
        )
    }
    var guide by remember {
        mutableStateOf(
            !context.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE)
                .getBoolean("guide_seen", false)
        )
    }
    var selected by rememberSaveable { mutableStateOf(0) }

    val tabRes = listOf(
        R.string.tab_plan,
        R.string.tab_todo,
        R.string.tab_screen_time,
        R.string.tab_block,
        R.string.tab_settings
    )
    val labels = tabRes.map { stringResource(it) }

    val tokens = tokensFor(style)
    val colors = lightColorScheme(
        primary = tokens.primary,
        secondary = tokens.accent,
        background = tokens.background,
        surface = tokens.surface,
        onPrimary = tokens.surface,
        onBackground = tokens.text,
        onSurface = tokens.text
    )

    val view = LocalView.current
    SideEffect {
        val window = (view.context as Activity).window
        val controller = WindowCompat.getInsetsController(window, view)
        val light = (style == DesignStyle.FRUTIGER_AERO ||
            style == DesignStyle.MINIMAL ||
            style == DesignStyle.WINDOWS11 ||
            style == DesignStyle.SKEUOMORPHISM ||
            style == DesignStyle.NEUMORPHISM ||
            style == DesignStyle.Y2K ||
            style == DesignStyle.CLAYMORPHISM ||
            style == DesignStyle.NEOCLASSICAL) != inv
        controller.isAppearanceLightStatusBars = light
        controller.isAppearanceLightNavigationBars = light
    }

    val dens = LocalDensity.current
    com.odak.app.theme.ProvideUiScale {
    CompositionLocalProvider(
        LocalDesign provides Design(style),
        LocalDensity provides Density(LocalDensity.current.density, dens.fontScale * fscale)
    ) {
        MaterialTheme(colorScheme = colors, typography = typographyFor(style)) {
            if (guide) ThemedBackground(Modifier.fillMaxSize().modeInvert(inv)) {
                GuideScreen {
                    context.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE)
                        .edit().putBoolean("guide_seen", true).apply()
                    guide = false
                }
            } else ThemedBackground(Modifier.fillMaxSize().modeInvert(inv)) {
                val land = com.odak.app.theme.rememberLandscape()
                Scaffold(
                    containerColor = Color.Transparent,
                    bottomBar = {
                        if (!land) ThemedNavBar(
                            labels = labels,
                            icons = listOf("📅", "☑", "⏱", "⛔", "⚙"),
                            selected = selected,
                            onSelect = { selected = it }
                        )
                    }
                ) { padding ->
                    Row(Modifier.fillMaxSize().padding(padding)) {
                    if (land) com.odak.app.theme.ThemedSideRail(
                        labels = labels,
                        icons = listOf("📅", "☑", "⏱", "⛔", "⚙"),
                        selected = selected,
                        onSelect = { selected = it }
                    )
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        AnimatedContent(
                            targetState = selected,
                            transitionSpec = { pageTransition(style) },
                            label = "page"
                        ) { page ->
                            val narrow = land && (page == 1 || page == 3 || page == 4)
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                            Box(
                                if (narrow) Modifier.widthIn(max = com.odak.app.logic.Pure.contentMaxDp(androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp).dp).fillMaxSize()
                                else Modifier.fillMaxSize()
                            ) {
                            when (page) {
                                0 -> PlanScreen()
                                1 -> TodoScreen()
                                2 -> ScreenTimeScreen()
                                3 -> BlockScreen()
                                4 -> SettingsScreen(style, fscale, mode, {
                                    mode = it
                                    com.odak.app.theme.ThemeMode.save(context, it)
                                }, {
                                    fscale = it
                                    context.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE)
                                        .edit().putFloat("fscale", it).apply()
                                }) { chosen ->
                                    style = chosen
                                    ThemePrefs.save(context, chosen)
                                }
                                else -> Box(
                                    Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(labels[page])
                                }
                            }
                            }
                            }
                        }
                    }
                    }
                }
            }
        }
    }
    }
}
