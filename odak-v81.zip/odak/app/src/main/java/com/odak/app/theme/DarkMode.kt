package com.odak.app.theme

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas

/** Görünüm modu: 0 sistem, 1 açık, 2 koyu. Tasarımın renkleri ters çevrilip tonu korunur. */
object ThemeMode {
    private const val PREFS = "odak_app"
    private const val KEY = "theme_mode"

    fun load(c: Context): Int = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY, 0)
    fun save(c: Context, m: Int) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY, m).apply()

    fun naturallyDark(s: DesignStyle) =
        s == DesignStyle.FUTURISTIC || s == DesignStyle.NEON || s == DesignStyle.TERMINAL ||
            s == DesignStyle.GLASSMORPHISM || s == DesignStyle.AURORA || s == DesignStyle.DARK ||
            s == DesignStyle.COSMIC || s == DesignStyle.SCIFI_HUD || s == DesignStyle.CYBER_INDUSTRIAL

    /** Tasarımın kendi parlaklığı istenen moda uymuyorsa true. */
    @Composable
    fun shouldInvert(style: DesignStyle, mode: Int): Boolean {
        // 0 = tasarımın kendi görünümü; 1 açık; 2 koyu.
        if (mode == 0) return false
        return naturallyDark(style) != (mode == 2)
    }
}

// invert(1) + hue-rotate(180): açık <-> koyu, renk tonu aynı kalır.
private val invertMatrix = ColorMatrix(
    floatArrayOf(
        0.574f, -1.430f, -0.144f, 0f, 255f,
        -0.426f, -0.430f, -0.144f, 0f, 255f,
        -0.426f, -1.430f, 0.856f, 0f, 255f,
        0f, 0f, 0f, 1f, 0f
    )
)

fun Modifier.modeInvert(on: Boolean): Modifier =
    if (!on) this else this.drawWithContent {
        drawIntoCanvas { canvas ->
            val paint = Paint().apply { colorFilter = ColorFilter.colorMatrix(invertMatrix) }
            canvas.saveLayer(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height), paint)
            drawContent()
            canvas.restore()
        }
    }
