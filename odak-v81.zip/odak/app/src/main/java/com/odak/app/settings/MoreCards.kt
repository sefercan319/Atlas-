package com.odak.app.settings

import android.app.LocaleManager
import android.content.Context
import android.os.LocaleList
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.notify.Reminders
import com.odak.app.theme.ClickSound
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import org.json.JSONObject

/** Ses açık/kapalı. */
@Composable
fun SoundCard() {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(ClickSound.enabled) }
    ThemedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(stringResource(R.string.sound_label), style = MaterialTheme.typography.titleMedium)
            ThemedCheck(on) {
                on = it
                ClickSound.enabled = it
                ctx.getSharedPreferences("odak_app", Context.MODE_PRIVATE).edit().putBoolean("sound", it).apply()
            }
        }
        var hap by remember { mutableStateOf(ClickSound.haptic) }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("📳", style = MaterialTheme.typography.titleMedium)
            ThemedCheck(hap) {
                hap = it
                ClickSound.haptic = it
                ctx.getSharedPreferences("odak_app", Context.MODE_PRIVATE).edit().putBoolean("haptic", it).apply()
            }
        }
    }
}

private val Langs = listOf(
    "tr" to "Türkçe", "en" to "English", "de" to "Deutsch", "fr" to "Français",
    "es" to "Español", "ar" to "العربية", "ru" to "Русский", "az" to "Azərbaycanca"
)

/** Uygulama dili (Android 13+ uygulama başına dil). */
@Composable
fun LanguageCard() {
    val ctx = LocalContext.current
    fun set(tag: String) {
        val lm = ctx.getSystemService(LocaleManager::class.java)
        lm.applicationLocales = if (tag.isEmpty()) LocaleList.getEmptyLocaleList() else LocaleList.forLanguageTags(tag)
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.lang_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        val all = listOf("" to stringResource(R.string.lang_auto)) + Langs
        all.chunked(3).forEach { rowItems ->
            Row(Modifier.padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                rowItems.forEach { (tag, name) -> ThemedButton(name, { set(tag) }) }
            }
        }
    }
}

/** Plan + yapılacaklar yedeği (JSON dosyası). */
@Composable
fun SummaryCard() {
    val ctx = LocalContext.current
    ThemedCard(Modifier.fillMaxWidth()) {
        ThemedButton("📊 " + stringResource(R.string.sum_share), {
            val week = (0..6).map { java.time.LocalDate.now().minusDays(it.toLong()) }.toSet()
            val plans = com.odak.app.plan.PlanStore.load(ctx).filter { it.date in week }
            val todos = com.odak.app.todo.TodoStore.load(ctx)
            val lines = mutableListOf(
                ctx.getString(R.string.tab_plan) + ": " + plans.count { it.done } + "/" + plans.size,
                ctx.getString(R.string.tab_todo) + ": " + todos.count { it.done } + "/" + todos.size
            )
            if (com.odak.app.block.BlockStore.usageAccess(ctx)) {
                val pm = ctx.packageManager
                val end = System.currentTimeMillis()
                val ms = try {
                    com.odak.app.block.BlockStore.usageRange(ctx, end - 7L * 86_400_000L, end)
                        .filter { it.key != ctx.packageName && pm.getLaunchIntentForPackage(it.key) != null }.values.sum()
                } catch (e: Exception) { 0L }
                lines.add(ctx.getString(R.string.tab_screen_time) + ": " + com.odak.app.logic.Pure.fmtDur((ms / 60_000).toInt()))
            }
            val text = com.odak.app.logic.Pure.summaryText(ctx.getString(R.string.sum_title), lines)
            val send = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain")
                .putExtra(android.content.Intent.EXTRA_TEXT, text)
            ctx.startActivity(
                android.content.Intent.createChooser(send, null).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        })
    }
}

@Composable
fun BackupCard() {
    val ctx = LocalContext.current
    var done by remember { mutableStateOf(false) }
    var tried by remember { mutableStateOf(false) }

    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            tried = true
            done = try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(Backup.export(ctx).toByteArray()) } != null
            } catch (e: Exception) {
                false
            }
        }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            tried = true
            done = try {
                val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() }
                if (text != null && Backup.import(ctx, text)) {
                    Reminders.rescheduleAll(ctx)
                    true
                } else false
            } catch (e: Exception) {
                false
            }
        }
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.backup_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ThemedButton(stringResource(R.string.backup_export), { done = false; tried = false; export.launch("odak-yedek.json") })
            ThemedButton(stringResource(R.string.backup_import), { done = false; tried = false; import.launch(arrayOf("application/json", "*/*")) })
        }
        if (done) Text("✓ " + stringResource(R.string.backup_done)) else if (tried) Text("✗")
    }
}

@Composable
fun LeadCard() {
    val ctx = LocalContext.current
    var lead by remember { mutableStateOf(Reminders.leadMin(ctx)) }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.lead_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(0, 5, 10, 30).forEach { m ->
                val label = if (m == 0) "0" else stringResource(R.string.fmt_min, m)
                ThemedButton((if (m == lead) "✔ " else "") + label, {
                    lead = m
                    Reminders.setLeadMin(ctx, m)
                    Reminders.rescheduleAll(ctx)
                })
            }
        }
    }
}

@Composable
fun DailyCard() {
    val ctx = LocalContext.current
    var m by remember { mutableStateOf(Reminders.dailyOn(ctx, 0)) }
    var e by remember { mutableStateOf(Reminders.dailyOn(ctx, 1)) }
    ThemedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(stringResource(R.string.morning_label) + " · 08:00", Modifier.weight(1f))
            ThemedCheck(m) { m = it; Reminders.setDaily(ctx, 0, it) }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(stringResource(R.string.eve_label) + " · 21:00", Modifier.weight(1f))
            ThemedCheck(e) { e = it; Reminders.setDaily(ctx, 1, it) }
        }
        var w by remember { mutableStateOf(Reminders.dailyOn(ctx, 2)) }
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(stringResource(R.string.st_week) + " · 20:00", Modifier.weight(1f))
            ThemedCheck(w) { w = it; Reminders.setDaily(ctx, 2, it) }
        }
    }
}

@Composable
fun FontCard(scale: Float, onChange: (Float) -> Unit) {
    ThemedCard(Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("A−" to 0.85f, "A" to 1f, "A+" to 1.2f).forEach { (label, v) ->
                ThemedButton((if (scale == v) "✔ " else "") + label, { onChange(v) })
            }
        }
    }
}

@Composable
fun ScaleCard() {
    val ctx = LocalContext.current
    val cur = com.odak.app.theme.UiScale.manual
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.ui_scale_title), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        val opts = listOf(0f to "", 0.9f to "90%", 1f to "100%", 1.15f to "115%", 1.3f to "130%", 1.5f to "150%")
        opts.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { (v, l) ->
                    val label = if (v == 0f) stringResource(R.string.lang_auto) else l
                    ThemedButton((if (cur == v) "✔ " else "") + label, { com.odak.app.theme.UiScale.set(ctx, v) })
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
fun MsgsCard() {
    val ctx = LocalContext.current
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.msg_title), style = MaterialTheme.typography.titleSmall)
        Text(stringResource(R.string.msg_hint), style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.7f))
        Spacer(Modifier.height(8.dp))
        com.odak.app.notify.Msgs.KINDS.forEach { k ->
            val label = stringResource(
                when (k) {
                    "remind" -> R.string.msg_k_remind
                    "morning" -> R.string.msg_k_morning
                    "evening" -> R.string.msg_k_evening
                    "week" -> R.string.msg_k_week
                    "warn" -> R.string.msg_k_warn
                    "limit" -> R.string.msg_k_limit
                    "focus" -> R.string.msg_k_focus
                    "pomo" -> R.string.msg_k_pomo
                    else -> R.string.msg_k_toast
                }
            )
            var v by remember(k) { mutableStateOf(com.odak.app.notify.Msgs.get(ctx, k)) }
            com.odak.app.theme.ThemedTextField(
                v, { v = it.take(200); com.odak.app.notify.Msgs.set(ctx, k, v) }, label, Modifier.fillMaxWidth()
            )
            val vars = com.odak.app.notify.Msgs.vars(k)
            if (vars.isNotEmpty()) Text(
                stringResource(R.string.msg_vars) + " " + vars.joinToString(" ") { "{$it}" },
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.6f)
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun NotesCard() {
    val ctx = LocalContext.current
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.notes_hint), style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.8f))
        Spacer(Modifier.height(8.dp))
        ThemedButton("📝 " + stringResource(R.string.notes_title), {
            ctx.startActivity(android.content.Intent(ctx, com.odak.app.notes.NotesActivity::class.java))
        })
    }
}

@Composable
fun DocsCard() {
    val ctx = LocalContext.current
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.doc_hint), style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.8f))
        Spacer(Modifier.height(8.dp))
        ThemedButton("📄 " + stringResource(R.string.doc_title), {
            ctx.startActivity(android.content.Intent(ctx, com.odak.app.docs.DocActivity::class.java))
        })
    }
}

@Composable
fun StatsCard() {
    val ctx = LocalContext.current
    val plans = remember { com.odak.app.plan.PlanStore.load(ctx) }
    val todos = remember { com.odak.app.todo.TodoStore.load(ctx) }
    val doneTotal = remember {
        ctx.getSharedPreferences("odak_app", Context.MODE_PRIVATE).getInt("todo_done_total", 0)
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(
            stringResource(R.string.tab_plan) + ": " + plans.count { it.done } + "/" + plans.size,
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            stringResource(R.string.tab_todo) + ": " + todos.count { it.done } + "/" + todos.size +
                "  (∑ " + doneTotal + ")",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            listOf("🥉" to 10, "🥈" to 50, "🥇" to 100, "🏆" to 250).forEach { (e, n) ->
                Text(
                    e + n,
                    color = androidx.compose.ui.graphics.Color.Unspecified,
                    modifier = Modifier.then(
                        if (doneTotal >= n) Modifier else Modifier.alpha(0.3f)
                    )
                )
            }
        }
    }
}

@Composable
fun EmojiCard() {
    val ctx = LocalContext.current
    var txt by remember { mutableStateOf(com.odak.app.plan.PlanEmoji.raw(ctx)) }
    com.odak.app.theme.ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.emoji_edit), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        com.odak.app.theme.ThemedTextField(txt, {
            txt = it
            com.odak.app.plan.PlanEmoji.save(ctx, it)
        }, "💼 🎓 🏠", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        ThemedButton("↺", {
            txt = com.odak.app.plan.PlanEmoji.defaults
            com.odak.app.plan.PlanEmoji.save(ctx, txt)
        })
    }
}
