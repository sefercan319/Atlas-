package com.odak.app.docs

import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler
import java.io.ByteArrayInputStream
import java.io.Closeable
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/** Belge içindeki görseller (saf Kotlin, birim testlenebilir): resim başvuruları, grafikler ve çizge/diyagramlar. */
enum class ChartKind { BAR, HBAR, LINE, AREA, PIE, SCATTER }

class ChartSeries(val name: String, val values: List<Double?>, val xs: List<Double?> = emptyList())

/** cats: kategori adları; series: her biri cats ile aynı sırada değerler. */
class DocChart(val title: String, val kind: ChartKind, val cats: List<String>, val series: List<ChartSeries>)

class DiaBox(val x: Double, val y: Double, val w: Double, val h: Double, val text: String, val round: Boolean = false)
class DiaLine(val x1: Double, val y1: Double, val x2: Double, val y2: Double)
class DocDiagram(val w: Double, val h: Double, val boxes: List<DiaBox>, val lines: List<DiaLine>)

/** images: zip içi tam yol (ör. word/media/image1.png). */
class Visuals(val images: List<String>, val charts: List<DocChart>, val diagrams: List<DocDiagram>) {
    val isEmpty: Boolean get() = images.isEmpty() && charts.isEmpty() && diagrams.isEmpty()
}

/** Zip içindeki bir girdiyi (resim) açan kaynak. Büyük dosyalarda tüm dosya belleğe alınmaz. */
interface MediaSource : Closeable {
    fun open(entry: String): InputStream?
    fun size(entry: String): Long
}

/** Diskteki dosya: ZipFile (merkezi dizinden rastgele erişim, ZIP64 destekli). */
class FileMedia(file: File, private val onClose: () -> Unit = {}) : MediaSource {
    private val z = ZipFile(file)
    override fun open(entry: String): InputStream? = z.getEntry(entry)?.let { z.getInputStream(it) }
    override fun size(entry: String): Long = z.getEntry(entry)?.size ?: -1L
    override fun close() { try { z.close() } catch (e: Exception) { }; onClose() }
}

/** Bellekteki küçük dosya. */
class BytesMedia(private val bytes: ByteArray) : MediaSource {
    override fun open(entry: String): InputStream? {
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            while (true) {
                val e = z.nextEntry ?: return null
                if (e.name == entry) return ByteArrayInputStream(z.readBytes())
            }
        }
    }
    override fun size(entry: String): Long = -1L
    override fun close() { }
}

object DocVisual {
    /** Ad alanı önekinden bağımsız yerel ad ("c:ser" → "ser"). */
    private fun ln(q: String): String { val i = q.indexOf(':'); return if (i < 0) q else q.substring(i + 1) }

    private const val MAX_IMAGES = 4000
    private const val MAX_BOXES = 2500
    private const val MAX_POINTS = 5000
    private const val MAX_SERIES = 40

    // ---------------- Yol ve ilişki yardımcıları ----------------
    /** base: ilişkiyi tanımlayan parçanın klasörü ("word/"). Mutlak ("/x") ve göreli ("../x") hedefleri çözer. */
    fun resolve(baseDir: String, target: String): String {
        val t = target.trim().replace('\\', '/')
        val parts = ArrayList<String>()
        val src = if (t.startsWith("/")) t.removePrefix("/") else baseDir + t
        for (p in src.split('/')) {
            when (p) {
                "", "." -> {}
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
                else -> parts.add(p)
            }
        }
        return parts.joinToString("/")
    }

    fun dirOf(path: String): String = if (path.contains('/')) path.substringBeforeLast('/') + "/" else ""
    fun relsPathOf(part: String): String = dirOf(part) + "_rels/" + part.substringAfterLast('/') + ".rels"

    class Rel(val type: String, val target: String, val external: Boolean)

    fun rels(e: Map<String, ByteArray>, relsPath: String): Map<String, Rel> {
        val xml = e[relsPath] ?: return emptyMap()
        val m = LinkedHashMap<String, Rel>()
        try {
            DocParse.sax(xml, object : DefaultHandler() {
                override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                    if (q == "Relationship" && a != null) {
                        val id = a.getValue("Id") ?: return
                        m[id] = Rel(a.getValue("Type") ?: "", a.getValue("Target") ?: "", (a.getValue("TargetMode") ?: "") == "External")
                    }
                }
            })
        } catch (ex: Exception) { }
        return m
    }

    private val BITMAP_EXT = setOf("png", "jpg", "jpeg", "gif", "bmp", "webp", "jfif", "heic", "heif", "avif")
    private val IMG_EXT = BITMAP_EXT + setOf("tif", "tiff", "emf", "wmf", "svg", "svgz")
    fun isImageName(n: String): Boolean = n.substringAfterLast('.', "").lowercase() in IMG_EXT

    /** Çözme yolu: "bitmap" (Android BitmapFactory), "tiff" (TiffDecoder), "meta" (Metafile: EMF/WMF), "svg", ya da "none". */
    fun imageKind(n: String): String = when (n.substringAfterLast('.', "").lowercase()) {
        in BITMAP_EXT -> "bitmap"
        "tif", "tiff" -> "tiff"
        "emf", "wmf" -> "meta"
        "svg", "svgz" -> "svg"
        else -> "none"
    }
    fun isDecodable(n: String): Boolean = imageKind(n) != "none"

    /** XML'deki resim/grafik başvuruları, görünme sırasıyla: ("img"|"chart", rId). */
    fun refs(xml: ByteArray): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            DocParse.sax(xml, object : DefaultHandler() {
                override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                    if (a == null) return
                    when (ln(q)) {
                        "blip" -> a.getValue("r:embed")?.let { out.add("img" to it) }
                        "imagedata" -> (a.getValue("r:id") ?: a.getValue("o:relid"))?.let { out.add("img" to it) }
                        "chart" -> a.getValue("r:id")?.let { out.add("chart" to it) }
                    }
                }
            })
        } catch (ex: Exception) { }
        return out
    }

    /** part'ın başvurduğu görselleri toplar. */
    private fun collect(e: Map<String, ByteArray>, part: String): Visuals {
        val xml = e[part]
        val rl = rels(e, relsPathOf(part))
        val base = dirOf(part)
        val images = LinkedHashSet<String>()
        val charts = ArrayList<DocChart>()
        val seenCharts = HashSet<String>()
        val dias = ArrayList<DocDiagram>()
        if (xml != null) for ((k, id) in refs(xml)) {
            val r = rl[id] ?: continue
            if (r.external) continue
            val path = resolve(base, r.target)
            if (k == "img") { if (isImageName(path) && images.size < MAX_IMAGES) images.add(path) }
            else if (seenCharts.add(path)) e[path]?.let { b -> parseChart(b)?.let { charts.add(it) } }
        }
        for ((_, r) in rl) {
            if (r.external) continue
            if (r.type.endsWith("/diagramDrawing")) {
                val path = resolve(base, r.target)
                e[path]?.let { b -> parseDsp(b)?.let { dias.add(it) } }
            }
        }
        return Visuals(images.toList(), charts, dias)
    }

    private fun merge(a: Visuals?, b: Visuals): Visuals =
        if (a == null) b else Visuals((a.images + b.images).distinct(), a.charts + b.charts, a.diagrams + b.diagrams)

    // ---------------- Belgeye iliştirme ----------------
    /** Metin sayfalarına görselleri iliştirir. Hiç görsel yoksa belge aynen döner. */
    fun attach(doc: Doc, e: Map<String, ByteArray>): Doc {
        val vis: List<Visuals?> = try {
            when (doc.kind) {
                DocKind.DOCX -> listOf(collect(e, "word/document.xml"))
                DocKind.PPTX -> {
                    val slides = e.keys.filter { Regex("""^ppt/slides/slide\d+\.xml$""").matches(it) }.sortedBy { DocParse.numOf(it) }
                    slides.map { collect(e, it) }
                }
                DocKind.XLSX -> DocParse.xlsxSheetFiles(e).map { (_, f) -> xlsxSheetVisuals(e, f) }
                DocKind.VSDX -> {
                    val pages = e.keys.filter { Regex("""^visio/pages/page\d+\.xml$""").matches(it) }.sortedBy { DocParse.numOf(it) }
                    pages.map { n -> parseVisio(e[n]!!)?.let { Visuals(emptyList(), emptyList(), listOf(it)) } }
                }
                DocKind.ODT, DocKind.ODS, DocKind.ODP, DocKind.ODG -> odfVisuals(doc.kind, e)
                else -> emptyList()
            }
        } catch (ex: Exception) { emptyList() } catch (ex: OutOfMemoryError) { emptyList() }
        if (vis.all { it == null || it.isEmpty }) return doc
        val pages = ArrayList<DocPage>()
        val n = maxOf(doc.pages.size, if (doc.kind == DocKind.PPTX || doc.kind == DocKind.ODP || doc.kind == DocKind.VSDX) 0 else vis.size)
        for (i in 0 until n) {
            val p = doc.pages.getOrNull(i) ?: DocPage(if (vis.size > 1) (i + 1).toString() else "", emptyList())
            val v = vis.getOrNull(i)
            pages.add(if (v == null || v.isEmpty) p else DocPage(p.title, p.paragraphs, p.table, v))
        }
        return Doc(doc.kind, pages, doc.approx, doc.link)
    }

    private fun xlsxSheetVisuals(e: Map<String, ByteArray>, sheet: String): Visuals? {
        val rl = rels(e, relsPathOf(sheet))
        var acc: Visuals? = null
        for ((_, r) in rl) if (r.type.endsWith("/drawing") && !r.external) {
            val dr = resolve(dirOf(sheet), r.target)
            if (e.containsKey(dr)) acc = merge(acc, collect(e, dr))
        }
        // Grafik sayfası ya da doğrudan grafik ilişkisi
        for ((_, r) in rl) if (r.type.endsWith("/chart") && !r.external) {
            val p = resolve(dirOf(sheet), r.target)
            e[p]?.let { b -> parseChart(b)?.let { c -> acc = merge(acc, Visuals(emptyList(), listOf(c), emptyList())) } }
        }
        return acc
    }

    // ---------------- ODF ----------------
    private fun odfVisuals(kind: DocKind, e: Map<String, ByteArray>): List<Visuals?> {
        val xml = e["content.xml"] ?: return emptyList()
        val pagesImgs = ArrayList<LinkedHashSet<String>>()
        val pagesObjs = ArrayList<LinkedHashSet<String>>()
        pagesImgs.add(LinkedHashSet()); pagesObjs.add(LinkedHashSet())
        val perPage = kind == DocKind.ODP
        var started = false
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                if (perPage && q == "draw:page") {
                    if (started) { pagesImgs.add(LinkedHashSet()); pagesObjs.add(LinkedHashSet()) }
                    started = true
                }
                if (a == null) return
                if (q == "draw:image") a.getValue("xlink:href")?.let { h -> if (!h.startsWith("http")) { val p = resolve("", h); if (isImageName(p) && pagesImgs.last().size < MAX_IMAGES) pagesImgs.last().add(p) } }
                if (q == "draw:object") a.getValue("xlink:href")?.let { h -> pagesObjs.last().add(resolve("", h)) }
            }
        })
        return pagesImgs.indices.map { i ->
            val charts = ArrayList<DocChart>()
            for (o in pagesObjs[i]) e["$o/content.xml"]?.let { b -> parseOdfChart(b)?.let { charts.add(it) } }
            Visuals(pagesImgs[i].toList(), charts, emptyList())
        }
    }

    // ---------------- OOXML grafik ----------------
    private class SerB { var name = ""; val cat = HashMap<Int, String>(); val v = HashMap<Int, String>(); val x = HashMap<Int, String>(); var maxIdx = -1; var cnt = 0 }

    fun parseChart(xml: ByteArray): DocChart? {
        var title = ""
        var kind: ChartKind? = null
        var barDirH = false
        val stack = ArrayList<String>()
        var inTitle = false
        var ser: SerB? = null
        var section = ""
        var idx = -1
        var inV = false
        val sb = StringBuilder()
        var inT = false
        val done = ArrayList<SerB>()
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                val parent = stack.lastOrNull()
                val q = ln(q)
                stack.add(q)
                if (kind == null) {
                    val k = chartKindOf(q)
                    if (k != null) kind = k
                }
                if (q == "barDir" && a?.getValue("val") == "bar") barDirH = true
                if (q == "title" && parent == "chart") inTitle = true
                if (inTitle && q == "t") { inT = true }
                when (q) {
                    "ser" -> if (done.size < MAX_SERIES) ser = SerB()
                    "tx", "cat", "val", "xVal", "yVal" -> if (ser != null) section = q
                    "pt" -> idx = a?.getValue("idx")?.toIntOrNull() ?: -1
                    "ptCount" -> ser?.let { s -> a?.getValue("val")?.toIntOrNull()?.let { c -> if (c in 1..MAX_POINTS && section != "tx") s.cnt = maxOf(s.cnt, c) } }
                    "v" -> { inV = true; sb.setLength(0) }
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) {
                if (inV) sb.append(ch, s, len)
                else if (inT) title += String(ch, s, len)
            }
            override fun endElement(u: String?, l: String?, q0: String) {
                val q = ln(q0)
                if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
                when (q) {
                    "t" -> inT = false
                    "title" -> if (stack.lastOrNull() == "chart") inTitle = false
                    "v" -> {
                        inV = false
                        val s = ser
                        if (s != null) {
                            val t = sb.toString()
                            when (section) {
                                "tx" -> if (s.name.isEmpty()) s.name = t
                                "cat" -> if (idx in 0 until MAX_POINTS) { s.cat.putIfAbsent(idx, t); s.maxIdx = maxOf(s.maxIdx, idx) }
                                "val", "yVal" -> if (idx in 0 until MAX_POINTS) { s.v[idx] = t; s.maxIdx = maxOf(s.maxIdx, idx) }
                                "xVal" -> if (idx in 0 until MAX_POINTS) { s.x.putIfAbsent(idx, t); s.maxIdx = maxOf(s.maxIdx, idx) }
                            }
                        }
                    }
                    "tx", "cat", "val", "xVal", "yVal" -> section = ""
                    "ser" -> { ser?.let { done.add(it) }; ser = null; section = "" }
                }
            }
        })
        val k = kind ?: return null
        val kk = if (k == ChartKind.BAR && barDirH) ChartKind.HBAR else k
        if (done.isEmpty()) return null
        val n = done.maxOf { maxOf(it.maxIdx + 1, it.cnt) }.coerceAtMost(MAX_POINTS)
        if (n <= 0) return null
        val catSrc = done.firstOrNull { it.cat.isNotEmpty() }?.cat ?: done.firstOrNull { it.x.isNotEmpty() }?.x ?: emptyMap()
        val cats = List(n) { catSrc[it] ?: (it + 1).toString() }
        val series = done.mapIndexed { i, s ->
            ChartSeries(s.name.ifEmpty { "S${i + 1}" }, List(n) { s.v[it]?.trim()?.toDoubleOrNull() }, if (kk == ChartKind.SCATTER) List(n) { s.x[it]?.trim()?.toDoubleOrNull() } else emptyList())
        }
        return DocChart(title.trim(), kk, cats, series)
    }

    private fun chartKindOf(q: String): ChartKind? = when (q) {
        "barChart", "bar3DChart" -> ChartKind.BAR
        "lineChart", "line3DChart", "radarChart", "stockChart" -> ChartKind.LINE
        "pieChart", "pie3DChart", "doughnutChart", "ofPieChart" -> ChartKind.PIE
        "areaChart", "area3DChart", "surfaceChart", "surface3DChart" -> ChartKind.AREA
        "scatterChart", "bubbleChart" -> ChartKind.SCATTER
        else -> null
    }

    // ---------------- ODF grafik ----------------
    fun parseOdfChart(xml: ByteArray): DocChart? {
        var cls = ""
        var title = ""
        var inTitle = false
        var inTitleP = false
        var inTable = 0
        var inHeader = false
        var inCell = false
        var cellVal: String? = null
        val cellTxt = StringBuilder()
        var inP = false
        val rows = ArrayList<List<String>>()
        val vals = ArrayList<List<String?>>()
        var rowS = ArrayList<String>()
        var rowV = ArrayList<String?>()
        var header: List<String>? = null
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) {
                    "chart:chart" -> cls = a?.getValue("chart:class") ?: ""
                    "chart:title" -> if (inTable == 0) inTitle = true
                    "table:table" -> inTable++
                    "table:table-header-rows" -> inHeader = true
                    "table:table-row" -> { rowS = ArrayList(); rowV = ArrayList() }
                    "table:table-cell" -> { inCell = true; cellTxt.setLength(0); cellVal = a?.getValue("office:value") }
                    "text:p" -> { inP = true; if (inTitle) inTitleP = true }
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) {
                if (inTitleP && inTable == 0) title += String(ch, s, len)
                else if (inCell && inP) cellTxt.append(ch, s, len)
            }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) {
                    "text:p" -> { inP = false; inTitleP = false }
                    "chart:title" -> inTitle = false
                    "table:table-cell" -> { inCell = false; rowS.add(cellTxt.toString()); rowV.add(cellVal); cellVal = null }
                    "table:table-row" -> {
                        if (inHeader && header == null) header = rowS else if (rowS.isNotEmpty()) { rows.add(rowS); vals.add(rowV) }
                    }
                    "table:table-header-rows" -> inHeader = false
                    "table:table" -> inTable--
                }
            }
        })
        val kind = when {
            cls.endsWith("circle") || cls.endsWith("ring") -> ChartKind.PIE
            cls.endsWith("line") || cls.endsWith("radar") || cls.endsWith("stock") -> ChartKind.LINE
            cls.endsWith("area") -> ChartKind.AREA
            cls.endsWith("scatter") || cls.endsWith("bubble") -> ChartKind.SCATTER
            cls.endsWith("bar") || cls.endsWith("gantt") -> ChartKind.BAR
            else -> return null
        }
        if (rows.isEmpty()) return null
        val cols = rows.maxOf { it.size } - 1
        if (cols <= 0) return null
        val cats = rows.map { it.firstOrNull().orEmpty() }.take(MAX_POINTS)
        val series = (1..minOf(cols, MAX_SERIES)).map { c ->
            val nm = header?.getOrNull(c)?.takeIf { it.isNotBlank() } ?: "S$c"
            ChartSeries(nm, vals.take(MAX_POINTS).map { v -> v.getOrNull(c)?.toDoubleOrNull() })
        }
        return DocChart(title.trim(), kind, cats, series)
    }

    // ---------------- SmartArt (dsp) ----------------
    fun parseDsp(xml: ByteArray): DocDiagram? {
        val boxes = ArrayList<DiaBox>()
        var inSp = false
        var inSpPr = false
        var x = 0.0; var y = 0.0; var w = 0.0; var h = 0.0
        var round = false
        val sb = StringBuilder()
        var inT = false
        var inTxBody = false
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) {
                    "dsp:sp" -> { inSp = true; x = 0.0; y = 0.0; w = 0.0; h = 0.0; round = false; sb.setLength(0) }
                    "dsp:spPr" -> inSpPr = true
                    "dsp:txBody" -> inTxBody = true
                    "a:off" -> if (inSp && inSpPr) { x = a?.getValue("x")?.toDoubleOrNull() ?: 0.0; y = a?.getValue("y")?.toDoubleOrNull() ?: 0.0 }
                    "a:ext" -> if (inSp && inSpPr) { w = a?.getValue("cx")?.toDoubleOrNull() ?: 0.0; h = a?.getValue("cy")?.toDoubleOrNull() ?: 0.0 }
                    "a:prstGeom" -> if (inSpPr) round = (a?.getValue("prst") ?: "").let { it.contains("ellipse") || it.contains("round") }
                    "a:t" -> if (inTxBody) inT = true
                    "a:br" -> if (inTxBody) sb.append('\n')
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inT) sb.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) {
                    "a:t" -> inT = false
                    "a:p" -> if (inTxBody && sb.isNotEmpty() && sb.last() != '\n') sb.append('\n')
                    "dsp:spPr" -> inSpPr = false
                    "dsp:txBody" -> inTxBody = false
                    "dsp:sp" -> { inSp = false; if (w > 0 && h > 0 && boxes.size < MAX_BOXES) boxes.add(DiaBox(x, y, w, h, sb.toString().trim(), round)) }
                }
            }
        })
        if (boxes.isEmpty()) return null
        return DocDiagram(boxes.maxOf { it.x + it.w }, boxes.maxOf { it.y + it.h }, boxes, emptyList())
    }

    // ---------------- Visio ----------------
    private class VS(var pinX: Double?, var pinY: Double?, var w: Double?, var h: Double?, var lx: Double?, var ly: Double?,
                     var bx: Double?, var by: Double?, var ex: Double?, var ey: Double?, var ox: Double, var oy: Double) { val text = StringBuilder() }

    fun parseVisio(xml: ByteArray): DocDiagram? {
        val stack = ArrayList<VS>()
        val rawBoxes = ArrayList<DiaBox>()
        val rawLines = ArrayList<DiaLine>()
        var inText = 0
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) {
                    "Shape" -> {
                        val par = stack.lastOrNull()
                        val ox = if (par == null) 0.0 else par.ox + (par.pinX ?: 0.0) - (par.lx ?: ((par.w ?: 0.0) / 2))
                        val oy = if (par == null) 0.0 else par.oy + (par.pinY ?: 0.0) - (par.ly ?: ((par.h ?: 0.0) / 2))
                        stack.add(VS(null, null, null, null, null, null, null, null, null, null, ox, oy))
                    }
                    "Cell" -> {
                        val s = stack.lastOrNull() ?: return
                        val v = a?.getValue("V")?.toDoubleOrNull() ?: return
                        when (a.getValue("N")) {
                            "PinX" -> s.pinX = v; "PinY" -> s.pinY = v; "Width" -> s.w = v; "Height" -> s.h = v
                            "LocPinX" -> s.lx = v; "LocPinY" -> s.ly = v
                            "BeginX" -> s.bx = v; "BeginY" -> s.by = v; "EndX" -> s.ex = v; "EndY" -> s.ey = v
                        }
                    }
                    "Text" -> { inText++; stack.lastOrNull()?.text?.setLength(0) }
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inText > 0) stack.lastOrNull()?.text?.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) {
                    "Text" -> inText = maxOf(0, inText - 1)
                    "Shape" -> {
                        val s = stack.removeAt(stack.size - 1)
                        val w = s.w ?: 0.0
                        val h = s.h ?: 0.0
                        // Kendi yerel koordinat başlangıcı: PinX - LocPinX (grup altındakiler için üst ofset eklenir)
                        val left = s.ox + (s.pinX ?: 0.0) - (s.lx ?: w / 2)
                        val bottom = s.oy + (s.pinY ?: 0.0) - (s.ly ?: h / 2)
                        if (s.bx != null && s.ex != null && s.by != null && s.ey != null) {
                            if (rawLines.size < MAX_BOXES) rawLines.add(DiaLine(s.ox + s.bx!!, s.oy + s.by!!, s.ox + s.ex!!, s.oy + s.ey!!))
                        } else if (s.pinX != null && s.pinY != null && w > 0 && h > 0 && rawBoxes.size < MAX_BOXES) {
                            rawBoxes.add(DiaBox(left, bottom, w, h, s.text.toString().trim()))
                        }
                    }
                }
            }
        })
        if (rawBoxes.isEmpty() && rawLines.isEmpty()) return null
        val maxY = maxOf(rawBoxes.maxOfOrNull { it.y + it.h } ?: 0.0, rawLines.maxOfOrNull { maxOf(it.y1, it.y2) } ?: 0.0)
        val maxX = maxOf(rawBoxes.maxOfOrNull { it.x + it.w } ?: 0.0, rawLines.maxOfOrNull { maxOf(it.x1, it.x2) } ?: 0.0)
        val boxes = rawBoxes.map { DiaBox(it.x, maxY - (it.y + it.h), it.w, it.h, it.text, it.round) }
        val lines = rawLines.map { DiaLine(it.x1, maxY - it.y1, it.x2, maxY - it.y2) }
        return DocDiagram(maxOf(maxX, 0.0001), maxOf(maxY, 0.0001), boxes, lines)
    }

    // ---------------- Çizim yardımcıları (saf, test edilebilir) ----------------
    /** Görsel bir yüksekliği genişliğe oranlar; sıfır/negatif girdide 0.5. */
    fun aspect(w: Double, h: Double): Double = if (w > 0 && h > 0) h / w else 0.5

    /** Çubuk/çizgi grafiği için değer aralığı: sıfırı içerir, tümü boşsa 0..1. */
    fun range(c: DocChart): Pair<Double, Double> {
        val vs = c.series.flatMap { it.values }.filterNotNull().filter { it.isFinite() }
        if (vs.isEmpty()) return 0.0 to 1.0
        var lo = minOf(0.0, vs.min()); var hi = maxOf(0.0, vs.max())
        if (hi == lo) hi = lo + 1.0
        return lo to hi
    }

    /** Pasta dilimi oranları (negatif/boş değerler 0 sayılır); toplam 0 ise boş liste. */
    fun pieShares(c: DocChart): List<Double> {
        val v = c.series.firstOrNull()?.values?.map { (it ?: 0.0).coerceAtLeast(0.0) } ?: return emptyList()
        val t = v.sum()
        return if (t <= 0.0) emptyList() else v.map { it / t }
    }

    /** Okunabilir sayı: tam sayılar ondalıksız, diğerleri en çok 2 ondalık. */
    fun num(d: Double): String = if (d == Math.rint(d) && Math.abs(d) < 1e15) d.toLong().toString() else String.format(java.util.Locale.ROOT, "%.2f", d).trimEnd('0').trimEnd('.')
}

object VisualPure {
    /** Uzun kenarı [maxSide]'ı geçmeyecek en küçük 2'nin kuvveti örnekleme oranı. */
    fun sampleSize(w: Int, h: Int, maxSide: Int): Int {
        var s = 1
        val m = maxOf(w, h)
        while (m / s > maxSide) s *= 2
        return s
    }
    const val MAX_IMAGE_BYTES = 80L * 1024 * 1024
}

