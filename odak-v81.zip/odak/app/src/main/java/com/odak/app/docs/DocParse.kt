package com.odak.app.docs

import java.io.ByteArrayInputStream
import java.io.StringReader
import java.util.zip.ZipInputStream
import javax.xml.parsers.SAXParserFactory
import org.xml.sax.Attributes
import org.xml.sax.InputSource
import org.xml.sax.helpers.DefaultHandler

/** Belge okuma (Android'e bağımlı değil, birim testlenebilir): zip+XML, RTF, metin, kaba metin çıkarma. */
enum class DocKind { PDF, DOCX, PPTX, XLSX, VSDX, ODT, ODP, ODS, ODG, ODF, ODB, RTF, TEXT, GOOGLE, LEGACY, OPAQUE, UNKNOWN }

/** Bir sayfa/slayt/sayfa sekmesi: paragraflar ve (varsa) tablo satırları. */
class DocPage(val title: String, val paragraphs: List<String>, val table: List<List<String>>? = null, val visuals: Visuals? = null)

class Doc(
    val kind: DocKind,
    val pages: List<DocPage>,
    /** true: yaklaşık metin (biçimsiz, eksik olabilir). */
    val approx: Boolean = false,
    /** Google belgelerinde çevrim içi adres. */
    val link: String? = null
)

object DocParse {
    const val MAX_BYTES = 256 * 1024 * 1024
    private const val MAX_ENTRY = 128 * 1024 * 1024
    private const val MAX_ENTRIES = 6000
    private const val MAX_PARAS = 20000
    private const val MAX_ROWS = 3000
    private const val MAX_COLS = 60

    private val ext = mapOf(
        "pdf" to DocKind.PDF,
        "docx" to DocKind.DOCX, "dotx" to DocKind.DOCX, "docm" to DocKind.DOCX, "dotm" to DocKind.DOCX,
        "pptx" to DocKind.PPTX, "potx" to DocKind.PPTX, "ppsx" to DocKind.PPTX, "pptm" to DocKind.PPTX,
        "ppsm" to DocKind.PPTX, "potm" to DocKind.PPTX,
        "xlsx" to DocKind.XLSX, "xltx" to DocKind.XLSX, "xlsm" to DocKind.XLSX, "xltm" to DocKind.XLSX,
        "vsdx" to DocKind.VSDX, "vsdm" to DocKind.VSDX, "vstx" to DocKind.VSDX,
        "odt" to DocKind.ODT, "ott" to DocKind.ODT,
        "odp" to DocKind.ODP, "otp" to DocKind.ODP,
        "ods" to DocKind.ODS, "ots" to DocKind.ODS,
        "odg" to DocKind.ODG, "otg" to DocKind.ODG,
        "odf" to DocKind.ODF,
        "rtf" to DocKind.RTF,
        "txt" to DocKind.TEXT, "csv" to DocKind.TEXT, "tsv" to DocKind.TEXT, "md" to DocKind.TEXT,
        "log" to DocKind.TEXT, "json" to DocKind.TEXT, "xml" to DocKind.TEXT, "ini" to DocKind.TEXT,
        "gdoc" to DocKind.GOOGLE, "gsheet" to DocKind.GOOGLE, "gslides" to DocKind.GOOGLE,
        "gform" to DocKind.GOOGLE, "gdraw" to DocKind.GOOGLE,
        "doc" to DocKind.LEGACY, "dot" to DocKind.LEGACY, "ppt" to DocKind.LEGACY, "pps" to DocKind.LEGACY,
        "xls" to DocKind.LEGACY, "xlt" to DocKind.LEGACY, "wps" to DocKind.LEGACY, "dps" to DocKind.LEGACY,
        "et" to DocKind.LEGACY, "wpt" to DocKind.LEGACY,
        "pub" to DocKind.LEGACY, "one" to DocKind.LEGACY, "odb" to DocKind.ODB
    )

    fun extOf(name: String): String = name.substringAfterLast('.', "").lowercase()

    /** Önce dosya adı uzantısı, sonra içerik imzası. */
    fun detect(name: String, head: ByteArray): DocKind {
        val byExt = ext[extOf(name)]
        val zip = head.size >= 4 && head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()
        val pdf = head.size >= 4 && String(head, 0, 4, Charsets.ISO_8859_1) == "%PDF"
        val ole = head.size >= 4 && head[0] == 0xD0.toByte() && head[1] == 0xCF.toByte() && head[2] == 0x11.toByte() && head[3] == 0xE0.toByte()
        val rtf = head.size >= 5 && String(head, 0, 5, Charsets.ISO_8859_1) == "{\\rtf"
        if (pdf) return DocKind.PDF
        if (rtf) return DocKind.RTF
        if (zip && (byExt == null || byExt == DocKind.LEGACY || byExt == DocKind.TEXT)) return DocKind.UNKNOWN // içerikten belirlenir
        if (ole && (byExt == null || byExt == DocKind.TEXT)) return DocKind.LEGACY
        return byExt ?: DocKind.UNKNOWN
    }

    /** Zip içindeki dosya adlarından tür: OOXML / Visio. ODF için mimetype dosyasına bakılır. */
    fun sniffZip(entries: Map<String, ByteArray>): DocKind {
        val mt = entries["mimetype"]?.let { String(it, Charsets.UTF_8).trim() } ?: ""
        return when {
            entries.containsKey("word/document.xml") -> DocKind.DOCX
            entries.containsKey("ppt/presentation.xml") -> DocKind.PPTX
            entries.containsKey("xl/workbook.xml") -> DocKind.XLSX
            entries.keys.any { it.startsWith("visio/") } -> DocKind.VSDX
            mt.endsWith("opendocument.text") || mt.endsWith("opendocument.text-template") -> DocKind.ODT
            mt.endsWith("opendocument.presentation") || mt.endsWith("opendocument.presentation-template") -> DocKind.ODP
            mt.endsWith("opendocument.spreadsheet") || mt.endsWith("opendocument.spreadsheet-template") -> DocKind.ODS
            mt.endsWith("opendocument.graphics") || mt.endsWith("opendocument.graphics-template") -> DocKind.ODG
            mt.endsWith("opendocument.formula") -> DocKind.ODF
            mt.endsWith("opendocument.base") || entries.containsKey("database/script") -> DocKind.ODB
            else -> DocKind.UNKNOWN
        }
    }

    // ---------------- Ana giriş ----------------
    /** PDF burada çözülmez (Android PdfRenderer). Bilinmeyen/okunamayan türde pages boş olur. */
    fun parse(name: String, bytes: ByteArray, maxBytes: Int = MAX_BYTES): Doc {
        if (bytes.size > maxBytes) return Doc(DocKind.UNKNOWN, emptyList())
        var kind = detect(name, bytes.copyOf(minOf(bytes.size, 16)))
        return try {
            if (kind == DocKind.PDF) return Doc(kind, emptyList())
            if (kind == DocKind.OPAQUE) return Doc(kind, emptyList())
            val isZip = bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()
            if (isZip && kind != DocKind.TEXT && kind != DocKind.GOOGLE) {
                val entries = readZip(bytes)
                val sniffed = sniffZip(entries)
                if (sniffed != DocKind.UNKNOWN) kind = sniffed
                return parseZip(kind, entries)
            }
            when (kind) {
                DocKind.RTF -> Doc(kind, listOf(DocPage("", rtfParas(String(bytes, Charsets.ISO_8859_1)))))
                DocKind.TEXT -> Doc(kind, listOf(DocPage("", textParas(decodeText(bytes)))))
                DocKind.GOOGLE -> googleDoc(String(bytes, Charsets.UTF_8))
                DocKind.LEGACY, DocKind.UNKNOWN -> {
                    OleDoc.parse(bytes)?.let { return it }
                    if (isOneNote(bytes)) {
                        val p = utf16Text(bytes)
                        return Doc(DocKind.LEGACY, if (p.isEmpty()) emptyList() else listOf(DocPage("", p)), approx = true)
                    }
                    val p = roughText(bytes)
                    Doc(DocKind.LEGACY, if (p.isEmpty()) emptyList() else listOf(DocPage("", p)), approx = true)
                }
                else -> Doc(kind, emptyList())
            }
        } catch (e: Exception) {
            Doc(kind, emptyList())
        }
    }

    private fun parseZip(kind: DocKind, e: Map<String, ByteArray>): Doc = DocVisual.attach(parseZipText(kind, e), e)

    private fun parseZipText(kind: DocKind, e: Map<String, ByteArray>): Doc = when (kind) {
        DocKind.DOCX -> Doc(kind, listOf(DocPage("", docxParas(e["word/document.xml"] ?: ByteArray(0)))))
        DocKind.PPTX -> Doc(kind, pptxPages(e))
        DocKind.XLSX -> Doc(kind, xlsxPages(e))
        DocKind.VSDX -> Doc(kind, vsdxPages(e))
        DocKind.ODT, DocKind.ODP, DocKind.ODS, DocKind.ODG -> Doc(kind, odfPages(kind, e["content.xml"] ?: ByteArray(0)))
        DocKind.ODF -> Doc(kind, odfFormula(e["content.xml"] ?: ByteArray(0)))
        DocKind.ODB -> Doc(kind, odbPages(e["database/script"], e["content.xml"]))
        else -> Doc(kind, emptyList())
    }

    /** Büyük dosyalar için: bellekte tüm dosyayı tutmaz. ZIP tabanlı belgelerde (DOCX/XLSX/PPTX/ODF…) rastgele erişimle yalnız XML parçalarını okur,
     *  resim/medya ne kadar büyük olursa olsun açılmaz (3 GB+ dosya bile birkaç MB bellekle açılır). Düz metinde ilk [textCap] bayt okunur (approx=true).
     *  Eski OLE (.doc/.xls) gibi tümü gereken türler [MAX_BYTES] üstünde açılmaz (UNKNOWN döner). */
    fun parseFile(name: String, f: java.io.File, textCap: Int = 64 * 1024 * 1024): Doc {
        val head = ByteArray(16)
        val n = f.inputStream().use { it.read(head) }.coerceAtLeast(0)
        var kind = detect(name, head.copyOf(n))
        if (kind == DocKind.PDF || kind == DocKind.OPAQUE) return Doc(kind, emptyList())
        val isZip = n >= 4 && head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()
        return try {
            if (isZip && kind != DocKind.TEXT && kind != DocKind.GOOGLE) {
                val entries = readZipFile(f)
                val sniffed = sniffZip(entries)
                if (sniffed != DocKind.UNKNOWN) kind = sniffed
                parseZip(kind, entries)
            } else if (f.length() <= MAX_BYTES) {
                parse(name, f.readBytes())
            } else if (kind == DocKind.TEXT) {
                val buf = ByteArray(textCap)
                val got = f.inputStream().use { i -> var t = 0; while (t < textCap) { val r = i.read(buf, t, textCap - t); if (r < 0) break; t += r }; t }
                val d = parse(name, buf.copyOf(got))
                Doc(d.kind, d.pages, approx = true)
            } else Doc(DocKind.UNKNOWN, emptyList())
        } catch (e: Exception) {
            Doc(kind, emptyList())
        } catch (e: OutOfMemoryError) {
            Doc(DocKind.UNKNOWN, emptyList())
        }
    }

    /** ZipFile (merkezi dizinden rastgele erişim, ZIP64 destekli): yalnız gerekli XML girdileri okunur. */
    fun readZipFile(f: java.io.File): Map<String, ByteArray> {
        val out = LinkedHashMap<String, ByteArray>()
        java.util.zip.ZipFile(f).use { z ->
            var n = 0
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (++n > MAX_ENTRIES) break
                if (e.isDirectory) continue
                val name = e.name
                if (!(name.endsWith(".xml") || name.endsWith(".rels") || name == "mimetype" || name == "database/script")) continue
                if (e.size > MAX_ENTRY) throw IllegalStateException("büyük girdi")
                val buf = java.io.ByteArrayOutputStream()
                val tmp = ByteArray(16 * 1024)
                var total = 0
                z.getInputStream(e).use { i ->
                    while (true) {
                        val r = i.read(tmp)
                        if (r < 0) break
                        total += r
                        if (total > MAX_ENTRY) throw IllegalStateException("büyük girdi")
                        buf.write(tmp, 0, r)
                    }
                }
                out[name] = buf.toByteArray()
            }
        }
        return out
    }

    // ---------------- Zip ----------------
    fun readZip(bytes: ByteArray): Map<String, ByteArray> {
        val out = LinkedHashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var n = 0
            while (true) {
                val en = z.nextEntry ?: break
                if (++n > MAX_ENTRIES) break
                if (en.isDirectory) continue
                val name = en.name
                // Yalnızca metin açısından gerekli dosyalar okunur (resim/medya atlanır).
                if (!(name.endsWith(".xml") || name.endsWith(".rels") || name == "mimetype" || name == "database/script")) continue
                val buf = java.io.ByteArrayOutputStream()
                val tmp = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val r = z.read(tmp)
                    if (r < 0) break
                    total += r
                    if (total > MAX_ENTRY) throw IllegalStateException("büyük girdi")
                    buf.write(tmp, 0, r)
                }
                out[name] = buf.toByteArray()
            }
        }
        return out
    }

    // ---------------- SAX yardımcısı ----------------
    internal fun sax(bytes: ByteArray, h: DefaultHandler) {
        if (bytes.isEmpty()) return
        val f = SAXParserFactory.newInstance()
        f.isNamespaceAware = false
        try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (e: Exception) { }
        try { f.setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (e: Exception) { }
        try { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (e: Exception) { }
        val r = f.newSAXParser().xmlReader
        r.entityResolver = org.xml.sax.EntityResolver { _, _ -> InputSource(StringReader("")) }
        r.contentHandler = h
        r.parse(InputSource(ByteArrayInputStream(bytes)))
    }

    // ---------------- DOCX ----------------
    fun docxParas(xml: ByteArray): List<String> {
        val out = ArrayList<String>()
        val para = StringBuilder()
        val cell = StringBuilder()
        val row = ArrayList<String>()
        var inT = false
        var cellDepth = 0
        sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) {
                    "w:t" -> inT = true
                    "w:tab" -> para.append('\t')
                    "w:br", "w:cr" -> para.append('\n')
                    "w:tc" -> { cellDepth++; cell.setLength(0) }
                    "w:tr" -> row.clear()
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inT) para.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) {
                    "w:t" -> inT = false
                    "w:p" -> {
                        val t = para.toString().trim()
                        para.setLength(0)
                        if (cellDepth > 0) { if (t.isNotEmpty()) { if (cell.isNotEmpty()) cell.append(' '); cell.append(t) } }
                        else if (t.isNotEmpty() && out.size < MAX_PARAS) out.add(t)
                    }
                    "w:tc" -> { cellDepth = maxOf(0, cellDepth - 1); row.add(cell.toString()); cell.setLength(0) }
                    "w:tr" -> { if (row.any { it.isNotEmpty() } && out.size < MAX_PARAS) out.add(row.joinToString(" │ ")); row.clear() }
                }
            }
        })
        return out
    }

    // ---------------- PPTX ----------------
    internal fun numOf(name: String): Int = Regex("""(\d+)\.xml$""").find(name)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    fun pptxPages(e: Map<String, ByteArray>): List<DocPage> {
        val slides = e.keys.filter { Regex("""^ppt/slides/slide\d+\.xml$""").matches(it) }.sortedBy { numOf(it) }
        return slides.mapIndexed { i, n ->
            val ps = drawParas(e[n]!!)
            val notes = e["ppt/notesSlides/notesSlide${numOf(n)}.xml"]?.let { drawParas(it) } ?: emptyList()
            DocPage((i + 1).toString(), ps + notes.filter { it.isNotBlank() }.map { "📝 $it" })
        }
    }

    /** a:p içindeki a:t metinleri. */
    private fun drawParas(xml: ByteArray): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var inT = false
        sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                if (q == "a:t") inT = true
                if (q == "a:br") sb.append('\n')
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inT) sb.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                if (q == "a:t") inT = false
                if (q == "a:p") { val t = sb.toString().trim(); sb.setLength(0); if (t.isNotEmpty() && out.size < MAX_PARAS) out.add(t) }
            }
        })
        return out
    }

    // ---------------- XLSX ----------------
    fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) { if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else if (ch in 'a'..'z') n = n * 26 + (ch - 'a' + 1) else break }
        return maxOf(0, n - 1)
    }

    private fun sharedStrings(xml: ByteArray?): List<String> {
        if (xml == null) return emptyList()
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var inT = false
        var inPh = 0
        sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                if (q == "si") sb.setLength(0)
                if (q == "rPh") inPh++
                if (q == "t" && inPh == 0) inT = true
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inT) sb.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                if (q == "t") inT = false
                if (q == "rPh") inPh--
                if (q == "si") out.add(sb.toString())
            }
        })
        return out
    }

    /** (sayfa adı, dosya yolu) çiftleri, çalışma kitabındaki sırayla. */
    fun xlsxSheetFiles(e: Map<String, ByteArray>): List<Pair<String, String>> {
        val names = ArrayList<Pair<String, String>>() // ad, rId
        sax(e["xl/workbook.xml"] ?: ByteArray(0), object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                if (q == "sheet" && a != null) names.add((a.getValue("name") ?: "") to (a.getValue("r:id") ?: ""))
            }
        })
        val rels = HashMap<String, String>()
        sax(e["xl/_rels/workbook.xml.rels"] ?: ByteArray(0), object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                if (q == "Relationship" && a != null) rels[a.getValue("Id") ?: ""] = a.getValue("Target") ?: ""
            }
        })
        val files = e.keys.filter { Regex("""^xl/worksheets/sheet\d+\.xml$""").matches(it) }.sortedBy { numOf(it) }
        val list = ArrayList<Pair<String, String>>() // başlık, dosya
        for ((n, rid) in names) {
            val t = rels[rid] ?: continue
            val path = if (t.startsWith("/")) t.removePrefix("/") else "xl/" + t.removePrefix("./")
            if (e.containsKey(path)) list.add(n to path)
        }
        if (list.isEmpty()) files.forEachIndexed { i, f -> list.add("${i + 1}" to f) }
        return list
    }

    fun xlsxPages(e: Map<String, ByteArray>): List<DocPage> {
        val shared = sharedStrings(e["xl/sharedStrings.xml"])
        return xlsxSheetFiles(e).map { (title, f) -> DocPage(title, emptyList(), sheetRows(e[f]!!, shared)) }
    }

    private fun sheetRows(xml: ByteArray, shared: List<String>): List<List<String>> {
        val rows = java.util.TreeMap<Int, java.util.TreeMap<Int, String>>()
        var ref = ""
        var type = ""
        var rowIdx = -1
        val v = StringBuilder()
        var inV = false
        var inIs = false
        var maxCol = 0
        sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) {
                    "row" -> rowIdx = (a?.getValue("r")?.toIntOrNull() ?: (rowIdx + 2)) - 1
                    "c" -> { ref = a?.getValue("r") ?: ""; type = a?.getValue("t") ?: ""; v.setLength(0) }
                    "v" -> inV = true
                    "is" -> inIs = true
                    "t" -> if (inIs) inV = true
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inV) v.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) {
                    "v" -> inV = false
                    "t" -> if (inIs) inV = false
                    "is" -> inIs = false
                    "c" -> {
                        val raw = v.toString()
                        val text = when (type) {
                            "s" -> raw.trim().toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                            "b" -> if (raw.trim() == "1") "TRUE" else "FALSE"
                            else -> raw
                        }
                        val col = if (ref.isNotEmpty()) colIndex(ref) else 0
                        if (text.isNotEmpty() && rowIdx in 0 until MAX_ROWS && col < MAX_COLS) {
                            rows.getOrPut(rowIdx) { java.util.TreeMap() }[col] = text
                            if (col + 1 > maxCol) maxCol = col + 1
                        }
                    }
                }
            }
        })
        return rows.values.map { r -> List(maxCol) { c -> r[c] ?: "" } }
    }

    // ---------------- VSDX ----------------
    fun vsdxPages(e: Map<String, ByteArray>): List<DocPage> {
        val pages = e.keys.filter { Regex("""^visio/pages/page\d+\.xml$""").matches(it) }.sortedBy { numOf(it) }
        return pages.mapIndexed { i, n ->
            val out = ArrayList<String>()
            val sb = StringBuilder()
            var inText = 0
            sax(e[n]!!, object : DefaultHandler() {
                override fun startElement(u: String?, l: String?, q: String, a: Attributes?) { if (q == "Text") { inText++; sb.setLength(0) } }
                override fun characters(ch: CharArray, s: Int, len: Int) { if (inText > 0) sb.append(ch, s, len) }
                override fun endElement(u: String?, l: String?, q: String) {
                    if (q == "Text") { inText = maxOf(0, inText - 1); val t = sb.toString().trim(); if (t.isNotEmpty() && out.size < MAX_PARAS) out.add(t) }
                }
            })
            DocPage((i + 1).toString(), out)
        }
    }

    // ---------------- ODF ----------------
    fun odfPages(kind: DocKind, xml: ByteArray): List<DocPage> {
        val pages = ArrayList<DocPage>()
        var title = ""
        var paras = ArrayList<String>()
        var rows = ArrayList<List<String>>()
        val sb = StringBuilder()
        val cell = StringBuilder()
        val row = ArrayList<String>()
        var inP = 0
        var cellDepth = 0
        var tableDepth = 0
        var annDepth = 0
        var cellRepeat = 1
        val pageTag = when (kind) { DocKind.ODS -> "table:table"; DocKind.ODP, DocKind.ODG -> "draw:page"; else -> "" }
        fun flush() {
            if (kind == DocKind.ODS) { if (rows.isNotEmpty()) pages.add(DocPage(title, emptyList(), rows)) }
            else if (paras.isNotEmpty() || kind == DocKind.ODP) pages.add(DocPage(title, paras))
            paras = ArrayList(); rows = ArrayList()
        }
        sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                if (q == "office:annotation") annDepth++
                if (annDepth > 0) return
                when (q) {
                    pageTag -> {
                        if (q == "table:table") { tableDepth++; if (tableDepth == 1) { title = a?.getValue("table:name") ?: ""; rows = ArrayList() } }
                        else { title = a?.getValue("draw:name") ?: ""; paras = ArrayList() }
                    }
                    "table:table" -> tableDepth++
                    "table:table-cell", "table:covered-table-cell" -> {
                        cellDepth++; cell.setLength(0)
                        cellRepeat = (a?.getValue("table:number-columns-repeated")?.toIntOrNull() ?: 1).coerceIn(1, MAX_COLS)
                    }
                    "table:table-row" -> row.clear()
                    "text:p", "text:h" -> { inP++; if (inP == 1) sb.setLength(0) }
                    "text:tab" -> if (inP > 0) sb.append('\t')
                    "text:line-break" -> if (inP > 0) sb.append('\n')
                    "text:s" -> if (inP > 0) sb.append(" ".repeat((a?.getValue("text:c")?.toIntOrNull() ?: 1).coerceIn(1, 50)))
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inP > 0 && annDepth == 0) sb.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                if (q == "office:annotation") { annDepth = maxOf(0, annDepth - 1); return }
                if (annDepth > 0) return
                when (q) {
                    "text:p", "text:h" -> {
                        inP = maxOf(0, inP - 1)
                        if (inP == 0) {
                            val t = sb.toString().trim(); sb.setLength(0)
                            if (t.isNotEmpty()) {
                                if (cellDepth > 0) { if (cell.isNotEmpty()) cell.append(' '); cell.append(t) }
                                else if (paras.size < MAX_PARAS) paras.add(t)
                            }
                        }
                    }
                    "table:table-cell", "table:covered-table-cell" -> {
                        cellDepth = maxOf(0, cellDepth - 1)
                        val txt = cell.toString()
                        repeat(minOf(cellRepeat, MAX_COLS - row.size).coerceAtLeast(0)) { row.add(txt) }
                        cell.setLength(0); cellRepeat = 1
                    }
                    "table:table-row" -> {
                        if (row.any { it.isNotEmpty() }) {
                            if (kind == DocKind.ODS) { if (rows.size < MAX_ROWS) rows.add(ArrayList(row)) }
                            else if (paras.size < MAX_PARAS) paras.add(row.joinToString(" │ "))
                        }
                        row.clear()
                    }
                    "table:table" -> { if (kind == DocKind.ODS && tableDepth == 1) flush(); tableDepth = maxOf(0, tableDepth - 1) }
                    "draw:page" -> if (kind == DocKind.ODP || kind == DocKind.ODG) flush()
                }
            }
            override fun endDocument() { if (kind == DocKind.ODT) flush() }
        })
        if (kind == DocKind.ODS) {
            val w = pages.maxOfOrNull { p -> p.table?.maxOfOrNull { it.size } ?: 0 } ?: 0
            return pages.map { p -> DocPage(p.title, emptyList(), p.table?.map { r -> r + List(maxOf(0, minOf(w, MAX_COLS) - r.size)) { "" } }) }
        }
        return pages
    }

    private fun odfFormula(xml: ByteArray): List<DocPage> {
        val sb = StringBuilder()
        var inA = false
        sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) { if (q.endsWith("annotation")) inA = true }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inA) sb.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) { if (q.endsWith("annotation")) inA = false }
        })
        val t = sb.toString().trim()
        return if (t.isEmpty()) emptyList() else listOf(DocPage("", listOf(t)))
    }

    // ---------------- RTF ----------------
    fun rtfParas(s: String): List<String> {
        val out = StringBuilder()
        val skipStack = ArrayList<Boolean>()
        var skip = false
        var uc = 1
        var i = 0
        var pendingSkipChars = 0
        val skipWords = setOf("fonttbl", "colortbl", "stylesheet", "info", "pict", "header", "footer", "headerl", "headerr",
            "footerl", "footerr", "object", "themedata", "colorschememapping", "latentstyles", "datastore", "listtable",
            "listoverridetable", "rsidtbl", "generator", "xmlnstbl", "fldinst", "bkmkstart", "bkmkend", "shpinst")
        while (i < s.length) {
            val c = s[i]
            when (c) {
                '{' -> { skipStack.add(skip); i++ }
                '}' -> { skip = if (skipStack.isNotEmpty()) skipStack.removeAt(skipStack.size - 1) else false; i++ }
                '\\' -> {
                    i++
                    if (i >= s.length) break
                    val d = s[i]
                    when {
                        d == '\\' || d == '{' || d == '}' -> { if (!skip && pendingSkipChars == 0) out.append(d) else if (pendingSkipChars > 0) pendingSkipChars--; i++ }
                        d == '\'' -> {
                            val hex = s.substring(i + 1, minOf(s.length, i + 3))
                            i += 3
                            if (pendingSkipChars > 0) pendingSkipChars--
                            else if (!skip) hex.toIntOrNull(16)?.let { out.append(String(byteArrayOf(it.toByte()), charset("windows-1252"))) }
                        }
                        d == '*' -> { skip = true; i++ }
                        d == '~' -> { if (!skip) out.append(' '); i++ }
                        d == '-' || d == '_' -> { if (!skip) out.append(if (d == '_') '-' else '­'); i++ }
                        d.isLetter() -> {
                            var j = i
                            while (j < s.length && s[j].isLetter()) j++
                            val word = s.substring(i, j)
                            var k = j
                            if (k < s.length && (s[k] == '-' || s[k].isDigit())) { k++; while (k < s.length && s[k].isDigit()) k++ }
                            val param = s.substring(j, k).toIntOrNull()
                            if (k < s.length && s[k] == ' ') k++
                            i = k
                            if (word in skipWords) skip = true
                            else if (!skip) when (word) {
                                "par", "line", "sect", "page" -> out.append('\n')
                                "tab" -> out.append('\t')
                                "cell" -> out.append(" │ ")
                                "row" -> out.append('\n')
                                "emdash" -> out.append('—')
                                "endash" -> out.append('–')
                                "bullet" -> out.append('•')
                                "lquote" -> out.append('‘')
                                "rquote" -> out.append('’')
                                "ldblquote" -> out.append('“')
                                "rdblquote" -> out.append('”')
                                "uc" -> uc = param ?: 1
                                "u" -> {
                                    if (param != null) { out.append((if (param < 0) param + 65536 else param).toChar()); pendingSkipChars = uc }
                                }
                            }
                        }
                        else -> i++
                    }
                }
                '\r', '\n' -> i++
                else -> {
                    if (pendingSkipChars > 0) pendingSkipChars-- else if (!skip) out.append(c)
                    i++
                }
            }
        }
        return out.toString().split('\n').map { it.trim() }.filter { it.isNotEmpty() }.take(MAX_PARAS)
    }

    // ---------------- Metin ----------------
    fun decodeText(b: ByteArray): String {
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        val off = if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) 3 else 0
        val s = String(b, off, b.size - off, Charsets.UTF_8)
        // Geçersiz UTF-8 ise (örn. eski Türkçe dosya) Windows-1254 dene
        return if (s.contains('�')) String(b, off, b.size - off, charset("windows-1254")) else s
    }

    fun textParas(s: String): List<String> = s.replace("\r\n", "\n").replace('\r', '\n').split('\n').take(MAX_PARAS)

    // ---------------- Google dosyaları ----------------
    fun googleDoc(json: String): Doc {
        val url = Regex(""""(?:url|doc_url)"\s*:\s*"([^"]+)"""").find(json)?.groupValues?.get(1)?.replace("\\/", "/")
        val ok = url != null && safeGoogleUrl(url)
        return Doc(DocKind.GOOGLE, emptyList(), link = if (ok) url else null)
    }

    /** Yalnızca https ve google.com alan adları açılır. */
    fun safeGoogleUrl(u: String): Boolean {
        if (!u.startsWith("https://")) return false
        if (u.any { it == '\\' || it.isWhitespace() || it.code < 32 }) return false // ters eğik çizgi/boşluk: ayrıştırıcılar farklı okur
        val auth = u.removePrefix("https://").substringBefore('/').substringBefore('?').substringBefore('#')
        if (auth.contains('@')) return false
        val host = auth.substringBefore(':').lowercase()
        if (!host.all { it in 'a'..'z' || it in '0'..'9' || it == '.' || it == '-' }) return false
        return host == "google.com" || host.endsWith(".google.com")
    }

    // ---------------- Eski ikili biçimler (kaba metin) ----------------
    private val junk = setOf(
        "times new roman", "calibri", "arial", "cambria", "courier new", "symbol", "wingdings", "tahoma", "verdana",
        "normal", "default paragraph font", "table normal", "no list", "root entry", "worddocument", "summaryinformation",
        "documentsummaryinformation", "microsoft word", "microsoft office word", "microsoft excel", "microsoft powerpoint",
        "normal.dot", "normal.dotm", "heading 1", "heading 2", "heading 3", "header", "footer", "title", "comp obj", "compobj",
        "current user", "powerpoint document", "pictures", "workbook", "book", "calibri light", "office theme", "default design"
    )

    fun roughText(b: ByteArray): List<String> {
        val runs = ArrayList<String>()
        val cur = StringBuilder()
        fun end() { if (cur.length >= 6) runs.add(cur.toString()); cur.setLength(0) }
        // 8 bit (windows-1252) çalıştırmalar
        val cp = CharArray(256) { String(byteArrayOf(it.toByte()), charset("windows-1252"))[0] }
        for (x in b) {
            val v = x.toInt() and 0xFF
            if (v in 32..126 || v in 0xC0..0xFF || v == 9) cur.append(cp[v]) else end()
        }
        end()
        // UTF-16LE çalıştırmalar
        var i = 0
        while (i + 1 < b.size) {
            val ch = ((b[i + 1].toInt() and 0xFF) shl 8) or (b[i].toInt() and 0xFF)
            val ok = ch in 32..126 || ch in 0xA0..0x24F || ch in 0x370..0x52F || ch in 0x600..0x6FF || ch == 0x20AC || ch == 9 || ch in 0x2010..0x2026
            if (ok) { cur.append(ch.toChar()); i += 2 } else { end(); i += if (b[i].toInt() == 0 && b[i + 1].toInt() == 0) 2 else 1 }
        }
        end()
        val seen = LinkedHashSet<String>()
        for (r in runs) {
            val t = r.trim()
            val letters = t.count { it.isLetter() }
            if (t.length < 6 || letters * 2 < t.length) continue
            if (t.count { it.code > 127 } * 10 > t.length * 3 && t.none { it in '\u011E'..'\u015F' }) continue
            if (t.toSet().size < 4) continue
            if (t.lowercase() in junk) continue
            if (t.all { it.isUpperCase() || it.isDigit() || it == '_' } && t.length < 12) continue
            if (t.length > 3000) continue
            seen.add(t)
            if (seen.size >= MAX_PARAS) break
        }
        return seen.toList()
    }


    // ---------------- OneNote (.one) ----------------
    private val oneMagic = intArrayOf(0xE4, 0x52, 0x5C, 0x7B, 0x8C, 0xD8, 0xA7, 0x4D, 0xAE, 0xB1, 0x53, 0x78, 0xD0, 0x29, 0x96, 0xD3)
    fun isOneNote(b: ByteArray): Boolean = b.size >= 16 && oneMagic.indices.all { (b[it].toInt() and 0xFF) == oneMagic[it] }

    /** Yalnızca UTF-16 çalıştırmaları: OneNote metni bu biçimde tutar. */
    fun utf16Text(b: ByteArray): List<String> {
        val runs = ArrayList<String>()
        val cur = StringBuilder()
        var i = 0
        fun end() { if (cur.length >= 4) runs.add(cur.toString()); cur.setLength(0) }
        while (i + 1 < b.size) {
            val ch = ((b[i + 1].toInt() and 0xFF) shl 8) or (b[i].toInt() and 0xFF)
            val ok = ch in 32..126 || ch in 0xA0..0x24F || ch in 0x370..0x52F || ch in 0x600..0x6FF || ch == 0x20AC || ch in 0x2010..0x2026 || ch == 9
            if (ok) { cur.append(ch.toChar()); i += 2 } else { end(); i += 1 }
        }
        end()
        val seen = LinkedHashSet<String>()
        for (r in runs) {
            val t = r.trim()
            if (t.length < 4 || t.count { it.isLetter() } * 2 < t.length || t.toSet().size < 3) continue
            if (t.startsWith("http") && !t.contains(' ')) continue
            if (t.length > 3000) continue
            seen.add(t)
            if (seen.size >= MAX_PARAS) break
        }
        return seen.toList()
    }

    // ---------------- LibreOffice Base (.odb, HSQLDB betiği) ----------------
    private fun splitTop(s: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var q = false
        var depth = 0
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (q) {
                if (c == '\'') { if (i + 1 < s.length && s[i + 1] == '\'') { sb.append('\''); i++ } else q = false } else sb.append(c)
            } else when (c) {
                '\'' -> q = true
                '(' -> { depth++; sb.append(c) }
                ')' -> { depth--; sb.append(c) }
                ',' -> if (depth == 0) { out.add(sb.toString()); sb.setLength(0) } else sb.append(c)
                else -> sb.append(c)
            }
            i++
        }
        out.add(sb.toString())
        return out
    }

    private fun unescapeSql(s: String): String =
        Regex("""\\u([0-9a-fA-F]{4})""").replace(s) { it.groupValues[1].toInt(16).toChar().toString() }

    fun odbPages(script: ByteArray?, content: ByteArray?): List<DocPage> {
        val pages = ArrayList<DocPage>()
        val info = ArrayList<String>()
        if (content != null) {
            val t = String(content, Charsets.UTF_8)
            Regex("""xlink:href="([^"]+)"""").findAll(t).map { it.groupValues[1] }.filter { it.startsWith("sdbc:") || it.startsWith("jdbc:") || it.startsWith("vnd.sun") || it.contains("://") }
                .take(3).forEach { info.add("🔗 $it") }
        }
        if (script != null) {
            val tables = LinkedHashMap<String, MutableList<List<String>>>()
            val createRe = Regex("""^CREATE\s+(?:CACHED\s+|MEMORY\s+|TEXT\s+)?TABLE\s+(?:PUBLIC\.)?"?([^"(\s]+)"?\s*\((.*)\)\s*$""", RegexOption.IGNORE_CASE)
            val insRe = Regex("""^INSERT\s+INTO\s+(?:PUBLIC\.)?"?([^"\s]+)"?\s+VALUES\s*\((.*)\)\s*$""", RegexOption.IGNORE_CASE)
            for (line in String(script, Charsets.UTF_8).lineSequence()) {
                val c = createRe.find(line)
                if (c != null) {
                    val cols = splitTop(c.groupValues[2]).map { it.trim() }
                        .filter { !Regex("""^(CONSTRAINT|PRIMARY|FOREIGN|UNIQUE|CHECK)\b""", RegexOption.IGNORE_CASE).containsMatchIn(it) }
                        .map { unescapeSql(it.removePrefix("\"").substringBefore("\" ").substringBefore(' ')) }
                    tables[unescapeSql(c.groupValues[1])] = arrayListOf(cols)
                    continue
                }
                val m = insRe.find(line) ?: continue
                val rows = tables[unescapeSql(m.groupValues[1])] ?: continue
                if (rows.size > MAX_ROWS) continue
                rows.add(splitTop(m.groupValues[2]).map { v -> val t = v.trim(); if (t.equals("NULL", true)) "" else unescapeSql(t) }.take(MAX_COLS))
            }
            for ((n, rows) in tables) pages.add(DocPage(n, emptyList(), rows))
        }
        if (info.isNotEmpty()) pages.add(0, DocPage("", info))
        return pages
    }

    // ---------------- Görüntü satırları ----------------
    /** kind: 0 başlık, 1 paragraf, 2 tablo satırı, 3 resim, 4 grafik, 5 diyagram. */
    class DocLine(
        val kind: Int, val text: String, val cells: List<String> = emptyList(),
        val img: String? = null, val chart: DocChart? = null, val dia: DocDiagram? = null
    )

    /** Sayfaları tek listeye düzleştirir; query doluysa yalnızca eşleşen satırlar (başlık yalnız eşleşme varsa) kalır. */
    fun flatten(doc: Doc, query: String, headerOf: (DocPage, Int) -> String): List<DocLine> {
        val q = query.trim()
        val out = ArrayList<DocLine>()
        doc.pages.forEachIndexed { idx, p ->
            val body = ArrayList<DocLine>()
            for (t in p.paragraphs) if (q.isEmpty() || com.odak.app.logic.Pure.matchStarts(t, q).isNotEmpty()) body.add(DocLine(1, t))
            p.table?.forEach { r -> if (q.isEmpty() || r.any { com.odak.app.logic.Pure.matchStarts(it, q).isNotEmpty() }) body.add(DocLine(2, "", r)) }
            if (q.isEmpty()) p.visuals?.let { v ->
                v.images.forEach { body.add(DocLine(3, "", img = it)) }
                v.charts.forEach { body.add(DocLine(4, it.title, chart = it)) }
                v.diagrams.forEach { body.add(DocLine(5, "", dia = it)) }
            }
            if (body.isEmpty()) return@forEachIndexed
            val h = headerOf(p, idx)
            if (h.isNotBlank() && (doc.pages.size > 1 || p.table != null)) out.add(DocLine(0, h))
            out.addAll(body)
        }
        return out
    }

    /** Son açılanlar: en yeni başta, aynı adres tekrarlanmaz, en çok max kayıt. Çift = (uri, ad). */
    fun addRecent(list: List<Pair<String, String>>, e: Pair<String, String>, max: Int = 8): List<Pair<String, String>> =
        (listOf(e) + list.filter { it.first != e.first }).take(max)
}
