
## v0.43 — Otomatik arayüz ölçeği
- PureLogicTest.autoScaleGrowsWithScreen / effectiveScaleManualOverridesAndClamps
- ManifestTest.mainActivityHandlesDensityChangeWithoutRecreate
