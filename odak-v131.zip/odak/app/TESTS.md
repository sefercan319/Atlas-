
## v0.43 — Otomatik arayüz ölçeği
- PureLogicTest.autoScaleGrowsWithScreen / effectiveScaleManualOverridesAndClamps
- ManifestTest.mainActivityHandlesDensityChangeWithoutRecreate

## v0.56.56 — Stil başına boyama profili
- RecolorProfileTest: 17 stil × 3 parça × 6 hedef (siyah, koyu lacivert, mor, sarı, açık gri, beyaz) — desen aralığının ≥%80'i korunur; Aero düğmesinde beyaz parlama boyanmadan kalır; mat stillerde (Clay, Minimal) parlama katmanı yok.
- ColorSlotTest güncellendi (türetimli düğme stilleri, kenar hedef toleransı).
- Doğrulanmadı: telefonda gerçek görünüm (yalnız JVM mantığı + PIL önizleme).

## v0.56.57 — Günlük açma sınırı (Engelleme)
- OpenLimitTest: 30 sn aralık kuralı, sayaç limit+1'de durur, tam `limit` kez açmaya izin, servis/arayüz bağlantısı, 9 dilde metinler.
- Doğrulanmadı: telefonda gerçek davranış (yalnız JVM mantığı + sözdizimi).

## v0.56.58 — Hata düzeltme
- BlockActivity: yeni engel gelince açık kalan çarpma sorusu/"yanlış" mesajı sıfırlanır (BlockScreenResetTest).

## v0.56.59 — Engelleme iyileştirmeleri
- Açma sınırı dolunca engel ekranı kendi başlığını gösterir ("Açma sınırı doldu"); uygulama başlığında bugünkü açılış sayısı (örn. "12m · 3×") görünür. OpenLimitScreenTest.

## v0.56.60 — GitHub Actions derleme hatası
- EmojiText.kt: InlineTextContent/appendInlineContent `foundation.text` paketinden; material3 Text çağrıları adlandırılmış argümanla (yeni sürümde araya `autoSize` girmişti); AnnotatedString sürümünde onTextLayout boş lambda ile. EmojiTextApiTest.

## v0.56.61 — Gün değişimi, logo, sabit imza, +700 uygulama, sıralama
- AppListTest: ek katalogdan ≥600 yeni uygulama (tekrarsız), paket adı biçimi, A–Z / Z–A / kullanım sıralaması (Türkçe harfler, eşitlikte ada göre), arayüz ve 9 dil bağlantısı.
- DayChangeTest: ekran süresi gün değişince "bugün"ü izler; manifestte uygulama simgesi; sabit imza anahtarı (build.gradle.kts + atlas-release.jks).
- Doğrulanmadı: paket adlarının Play Store'da varlığı (elle derlendi, ağ erişimi yok); telefonda gerçek davranış; yeni imzayla ilk kurulumda eski APK silinmeli.

## v0.56.62 — Engelleme ekranı sadeleştirme
- Uygulama satırı: ad + özet rozetleri + tek onay kutusu; Sınırlar / Özellikler / Sessiz saat ayrıntı penceresine ("⋯") taşındı. BlockWindowTest (rozet özeti, satırda ayrıntı yok, 9 dilde bölüm başlıkları).
- Doğrulanmadı: pencerenin telefonda görünümü (yalnız sözdizimi).

## v0.56.63 — Ayarlar sadeleştirme
- Görünüm: stil listesinde önizleme yalnız seçili stilde; Renkler ve Koyu/Açık mod ayrı alt sekmede; her renk satırı sade (ad + renk dairesi), palet dokununca pencerede açılır; sıfırlama pencerede. SettingsSimplifyTest.

## v0.56.64 — Diğer ekranlar pencereli
- Yapılacaklar: araçlar (🧰), ek seçenekler (⋯), filtre/sıralama (⇅) satır içi açılma yerine pencerede.
- Ekran süresi: özet kartında yalnız toplam + dünle fark; ayrıntılar (ⓘ) ve uygulama haftalık grafiği pencerede. OtherWindowsTest.

## v0.56.65 — Plan ve Program pencereli
- Plan ekleme satırı: başlık + ⋯ + Ekle; saat/süre/tekrar ve araçlar (şablon, günü kopyala, ara) ⋯ penceresinde. Program düzenleyici tam ekran yerine pencere. PlanScheduleWindowTest.

## v0.56.66 — Derleme hatası (BlockScreen)
- BlockScreen.kt: `Column` içe aktarması eksikti (ayrıntı penceresi/sade satır). ImportGuardTest: çıplak `Column(` kullanan dosyada içe aktarma şart.

## v0.56.67 — Bozulmaya karşı dayanıklılık
- ComposeImportTest: bilinen Compose sembolleri (Column, Row, Box, remember, verticalScroll ...) içe aktarılmadan kullanılırsa test düşer (eksik Column içe aktarmasıyla doğrulandı).
- GitHub workflow: en yeni zip derlenmezse/testi geçmezse bir öncekine döner; hangi zip'ten derlendiği özet sayfasında yazar (WorkflowFallbackTest).

## v0.56.68 — Çalışma anı dayanıklılığı
- Çökme raporu: AtlasApplication yakalanmamış hatayı filesDir/crash_report.txt'ye yazar (sürüm, cihaz, zaman, iz; en fazla 30 KB, en yeni korunur) ve eski işleyiciye devreder; sonraki açılışta "paylaş / kapat" penceresi.
- Engelleme servisi: tek olaydaki hata servisi öldürmez, rapora yazılır. CrashLogTest.
- Doğrulanmadı: telefonda gerçek çökme akışı.

## v0.56.69 — Çökmeye karşı ek koruma
- Çökme döngüsü: 2 dk içinde 3 çökme olursa açılışta yalnız görünüm ayarları (renkler, stil, yazı/arayüz ölçeği, son sekme) varsayılana döner; plan/not/yapılacak verilerine dokunulmaz. SafeModeTest.
- Hatırlatma/açılış/günlük/program alıcıları, widget ve bildirim servisi `CrashReport.guard` ile korunur; hata uygulamayı düşürmez, rapora yazılır.
- Yedek: seçili stil (odak_theme) yedek listesine eklendi; çökme sayacı (odak_safe) bilerek yedeklenmez.

## v0.56.70 — Derin/dev belge girdilerine karşı dayanıklılık
- SafeCall: Exception + OutOfMemoryError + StackOverflowError yakalanır, iptal yeniden fırlatılır (SafeCallTest, gerçek yığın taşmasıyla).
- Belge açma, PDF sayfa çizimi ve dönüştürme artık StackOverflowError/OutOfMemoryError ile çökmez; "belge açılamadı" gösterir. Açılış arka plan işi SafeCall ile.

## v0.56.71 — Dosya bozulmasına karşı
- SafeFile: önce geçici dosyaya yaz (diske zorla), eskiyi `.bak` yap, atomik yer değiştir; okurken ana dosya bozuk/boşsa yedek. Kural dosyaları (user_rules.json, block_rules.json) ve görülen kimlikler bununla yazılır/okunur. SafeFileTest (gerçek geçici dosyalarla).

## v0.56.72 — Güvenlik ve uyumluluk katmanı
- PIN deneme sınırı (PinLimiter): ilk 5 yanlışa bekleme yok, sonra 30 sn'den başlayıp ikiye katlanır (en çok 15 dk); saat geri alınırsa kilit açılmaz; kilitliyken doğru PIN de denenmez. Sayaç ayrı `odak_pinfail` dosyasında; PIN silinince sıfırlanır. Giriş ve ayar ekranında "X sn bekle" mesajı (9 dil).
- Yedek: PIN, deneme sayacı, çökme sayacı ve çökme raporu bulut/cihaz yedeğinden hariç (data_extraction_rules + backup_rules).
- NotesActivity kısayol için dışa açık kalır (ShortcutsTest korur).
- Uyumluluk: tüm startActivity çağrıları `Launch.go` ile; ayar/paylaşım ekranı olmayan ya da kısıtlı telefonlarda çökmek yerine sessizce başarısız olur. SecurityLayerTest.

## v0.56.72 düzeltme
- BlockScreen.openSettings açıkça `() -> Unit` (Launch.go Boolean döndürüyor; derleme hatası). SecurityLayerTest.openSettingsLambdaIsUnitTyped.
