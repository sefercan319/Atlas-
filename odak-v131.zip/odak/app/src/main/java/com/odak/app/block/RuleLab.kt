package com.odak.app.block

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.odak.app.logic.Pure
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Kuralı telefonda öğretme: bölümde ve dışında 20 sn kayıt, sonra ayırt edici kimlik türetme. */
object RuleLab {
    const val SECONDS = 20
    var app by mutableStateOf("")
    var feat by mutableStateOf("")
    var mode by mutableStateOf("")          // "", "pos", "neg"
    var endAt = 0L
    var posScans by mutableIntStateOf(0)
    var negScans by mutableIntStateOf(0)
    private val posCount = HashMap<String, Int>()
    private val neg = HashSet<String>()
    private val posSel = HashMap<String, Int>()
    private val negSel = HashSet<String>()

    fun start(a: String, f: String) { if (a != app || f != feat) reset(); app = a; feat = f }
    fun reset() { mode = ""; posScans = 0; negScans = 0; posCount.clear(); neg.clear(); posSel.clear(); negSel.clear() }
    fun record(m: String) { mode = m; endAt = System.currentTimeMillis() + SECONDS * 1000L }
    fun recording(now: Long = System.currentTimeMillis()) = mode.isNotEmpty() && now < endAt
    fun wants(appId: String) = recording() && appId == app

    /** Servis her taramada çağırır. */
    fun feed(ids: Set<String>, sel: Set<String> = emptySet()) {
        if (!recording()) { mode = ""; return }
        if (mode == "pos") { posScans++; ids.forEach { posCount[it] = (posCount[it] ?: 0) + 1 }; sel.forEach { posSel[it] = (posSel[it] ?: 0) + 1 } }
        else { negScans++; neg.addAll(ids); negSel.addAll(sel) }
    }

    /** Kimlik kuralları + (varsa) seçili sekme etiketi kuralları; dilden bağımsız kimlik yoksa sekme etiketi yedek olur. */
    fun preview(): List<String> = Pure.derive(posCount, posScans, neg) + Pure.deriveSel(posSel, posScans, negSel)

    /** Bu bölüm için daha önce kaydedilmiş kimlik sayısı (0 = kayıtlı kural yok). */
    fun savedCount(c: Context, app: String, feat: String): Int = try {
        val o = JSONObject(com.odak.app.logic.SafeFile.read(File(c.filesDir, "user_rules.json")) { validJson(it) } ?: return 0)
        o.optJSONArray(Pure.ruleKey(app, feat))?.length() ?: 0
    } catch (e: Exception) { 0 }

    fun validJson(s: String): Boolean = try { JSONObject(s); true } catch (e: Exception) { false }

    /** Kayıtlı kuralı siler; silindiyse true. Engellemeyi gevşettiği için çağıran tarafta onay gerekir. */
    fun removeSaved(c: Context, app: String, feat: String): Boolean {
        val f = File(c.filesDir, "user_rules.json")
        val o = try { JSONObject(com.odak.app.logic.SafeFile.read(f) { validJson(it) } ?: return false) } catch (e: Exception) { return false }
        val key = Pure.ruleKey(app, feat)
        if (!o.has(key)) return false
        o.remove(key)
        com.odak.app.logic.SafeFile.write(f, o.toString())
        return true
    }

    /** Türetilen kuralı user_rules.json'a yazar; kaç girdi yazıldığını döndürür. */
    fun make(c: Context): Int {
        val r = preview()
        if (r.isEmpty()) return 0
        val f = File(c.filesDir, "user_rules.json")
        val o = try { JSONObject(com.odak.app.logic.SafeFile.read(f) { validJson(it) } ?: "{}") } catch (e: Exception) { JSONObject() }
        o.put("$app/$feat", JSONArray(r))
        com.odak.app.logic.SafeFile.write(f, o.toString())
        reset()
        return r.size
    }
}
