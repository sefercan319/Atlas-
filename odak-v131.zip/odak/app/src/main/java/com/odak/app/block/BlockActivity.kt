package com.odak.app.block

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.sp
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ColorPrefs
import com.odak.app.theme.Design
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.ThemePrefs
import com.odak.app.theme.ThemedBackground
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.modeInvert
import com.odak.app.theme.tokensFor
import com.odak.app.theme.typographyFor

/** Tamamen engelli uygulamaya girilince açılan tam ekran uyarı. */
class BlockActivity : ComponentActivity() {
    private var appId by mutableStateOf<String?>(null)
    private var pkg by mutableStateOf<String?>(null)
    private var msgIdx by mutableIntStateOf(0)
    private var left by mutableIntStateOf(0)
    private var focus by mutableStateOf(false)
    private var limitHit by mutableStateOf(false)
    private var opensHit by mutableStateOf(false)
    private var quiz by mutableStateOf(false)
    private var qa by mutableIntStateOf(12)
    private var qb by mutableIntStateOf(3)
    private var ans by mutableStateOf("")
    private var wrong by mutableStateOf(false)

    private val msgs = listOf(
        R.string.motiv_1, R.string.motiv_2, R.string.motiv_3,
        R.string.motiv_4, R.string.motiv_5, R.string.motiv_6
    )

    private fun read(i: Intent?) {
        appId = i?.getStringExtra("app")
        pkg = i?.getStringExtra("pkg")
        focus = i?.getBooleanExtra("focus", false) ?: false
        limitHit = i?.getBooleanExtra("limit", false) ?: false
        opensHit = i?.getBooleanExtra("opens", false) ?: false
        msgIdx = msgs.indices.random()
        quiz = false; wrong = false; ans = ""   // yeni engelde eski soru/yanlış mesajı kalmasın
        left = BlockStore.passesLeft(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        read(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ColorPrefs.init(applicationContext)
        com.odak.app.theme.UiScale.init(applicationContext)
        read(intent)
        val style = ThemePrefs.load(this)
        val t = tokensFor(style)
        setContent {
            com.odak.app.theme.ProvideUiScale { CompositionLocalProvider(LocalDesign provides Design(style), com.odak.app.theme.LocalInverted provides com.odak.app.theme.ThemeMode.shouldInvert(style, com.odak.app.theme.ThemeMode.load(this@BlockActivity))) {
                MaterialTheme(typography = typographyFor(style)) {
                    ThemedBackground(Modifier.fillMaxSize().modeInvert(com.odak.app.theme.ThemeMode.shouldInvert(style, com.odak.app.theme.ThemeMode.load(this@BlockActivity)))) {
                        val kind = if (limitHit) "lim" else "blk"
                        val me = this@BlockActivity
                        val bgc = BlockStore.scr(me, kind, "bg").toLongOrNull()?.let { androidx.compose.ui.graphics.Color(it) }
                        val fg = if (bgc == null) t.text
                        else if (bgc.luminance() > 0.5f) androidx.compose.ui.graphics.Color(0xFF111111)
                        else androidx.compose.ui.graphics.Color.White
                        val k = when (BlockStore.scr(me, kind, "size")) { "0" -> 0.75f; "2" -> 1.35f; else -> 1f }
                        androidx.compose.foundation.layout.Box(
                            Modifier.fillMaxSize()
                                .then(if (bgc != null) Modifier.background(bgc) else Modifier)
                                .verticalScroll(rememberScrollState())
                        ) {
                        Column(
                            Modifier.fillMaxWidth()
                                .heightIn(min = androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp.dp)
                                .padding(32.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                BlockStore.scr(me, kind, "icon").ifBlank { "⛔" },
                                color = fg, fontSize = (45 * k).sp
                            )
                            Text(
                                BlockStore.scr(me, kind, "title").ifBlank {
                                    stringResource(if (opensHit) R.string.open_limit_reached else if (limitHit) R.string.limit_reached_title else R.string.block_app_msg)
                                },
                                color = fg,
                                textAlign = TextAlign.Center,
                                fontSize = (22 * k).sp,
                                modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
                            )
                            Text(
                                BlockStore.scr(me, kind, "msg").ifBlank { stringResource(msgs[msgIdx]) },
                                color = fg.copy(alpha = 0.8f),
                                fontSize = (16 * k).sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(28.dp))
                            ThemedButton(stringResource(R.string.block_back), { goHome() })
                            if (left > 0 && appId != null && !focus && !(limitHit && BlockStore.strictLimit(this@BlockActivity))) {
                                Spacer(Modifier.height(12.dp))
                                ThemedButton(stringResource(R.string.block_more) + " ($left)", { morePlease() })
                            }
                            if (appId != null && !focus && !(limitHit && BlockStore.strictLimit(this@BlockActivity))) {
                                Spacer(Modifier.height(12.dp))
                                if (!quiz) {
                                    ThemedButton(stringResource(R.string.unlock_btn), {
                                        qa = (12..29).random(); qb = (3..9).random(); ans = ""; wrong = false; quiz = true
                                    })
                                } else {
                                    Text("$qa × $qb = ?", color = fg, style = MaterialTheme.typography.titleLarge)
                                    Spacer(Modifier.height(8.dp))
                                    com.odak.app.theme.ThemedTextField(ans, { ans = it.filter { c -> c.isDigit() }.take(4) }, "?", Modifier.width(140.dp))
                                    Spacer(Modifier.height(8.dp))
                                    ThemedButton(stringResource(R.string.pin_ok), { solve() })
                                    if (wrong) Text(stringResource(R.string.unlock_wrong), color = fg.copy(alpha = 0.8f))
                                }
                            }
                        }
                        }
                    }
                }
            }
            }
        }
    }

    private fun morePlease() {
        val id = appId ?: return
        if (!BlockStore.grantPass(this, id)) return
        val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        if (launch != null) com.odak.app.Launch.go(this, launch)
        finish()
    }

    private fun solve() {
        val id = appId ?: return
        if (ans.toIntOrNull() != qa * qb) {
            wrong = true
            qa = (12..29).random(); qb = (3..9).random(); ans = ""
            return
        }
        BlockStore.grantQuizPass(this, id)
        val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        if (launch != null) com.odak.app.Launch.go(this, launch)
        finish()
    }

    private fun goHome() {
        com.odak.app.Launch.go(this, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
