package com.odak.app.notify

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.odak.app.MainActivity
import com.odak.app.R
import com.odak.app.plan.PlanStore
import com.odak.app.plan.fmtTime
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Ana ekran widget'ı: bugünün planları. */
class PlanWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, mgr: AppWidgetManager, ids: IntArray) {
        com.odak.app.CrashReport.guard(c, "widget") { ids.forEach { mgr.updateAppWidget(it, build(c)) } }
    }

    companion object {
        fun build(c: Context): RemoteViews {
            val today = LocalDate.now()
            val plans = PlanStore.load(c).filter { it.date == today }
                .sortedBy { if (it.hasTime) it.startMin else Int.MAX_VALUE }
            val v = RemoteViews(c.packageName, R.layout.widget_plan)
            v.setTextViewText(
                R.id.w_title,
                today.format(DateTimeFormatter.ofPattern("d MMM", Locale.getDefault())) +
                    " · " + c.getString(R.string.tab_plan) + " " + plans.count { it.done } + "/" + plans.size
            )
            val body = plans.take(5).joinToString("\n") {
                (if (it.done) "✓ " else "• ") + (if (it.hasTime) fmtTime(it.startMin) + " " else "") + it.title
            }
            v.setTextViewText(R.id.w_body, body.ifEmpty { "—" })
            v.setOnClickPendingIntent(
                R.id.w_root,
                PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            )
            return v
        }

        fun refresh(c: Context) {
            val mgr = AppWidgetManager.getInstance(c)
            val ids = mgr.getAppWidgetIds(ComponentName(c, PlanWidget::class.java))
            ids.forEach { mgr.updateAppWidget(it, build(c)) }
        }
    }
}
