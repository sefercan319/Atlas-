package com.odak.app

import android.content.Context
import android.content.Intent

/** Etkinlik başlatma: ayar/paylaşım ekranı olmayan ya da kısıtlı telefonlarda (bazı üretici arayüzleri) çökmek yerine false döner. */
object Launch {
    fun go(c: Context, i: Intent): Boolean = try {
        c.startActivity(i); true
    } catch (e: android.content.ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    } catch (e: Exception) {
        CrashReport.write(c, "launch", e); false
    }
}
