package com.odak.app.schedule

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.odak.app.R
import com.odak.app.notify.Reminders
import java.time.LocalDateTime
import java.time.ZoneId

/** Program satırları SharedPreferences'ta tutulur; her satır için bir sonraki zaman alarmı kurulur. */
object ScheduleStore {
    private fun p(c: Context) = c.getSharedPreferences("odak_sched", Context.MODE_PRIVATE)
    fun load(c: Context): List<SchedItem> = SchedulePure.decode(p(c).getString("items", "") ?: "")

    fun save(c: Context, l: List<SchedItem>) {
        val old = load(c)
        p(c).edit().putString("items", SchedulePure.encode(l)).apply()
        old.filter { o -> l.none { it.id == o.id } }.forEach { cancel(c, it.id) }
        l.forEach { schedule(c, it) }
    }

    private fun pending(c: Context, id: String) = PendingIntent.getBroadcast(
        c, 5000 + (id.hashCode() and 0x3FFFFFF), Intent(c, ScheduleReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun cancel(c: Context, id: String) = (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(c, id))

    fun schedule(c: Context, i: SchedItem) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(c, i.id)
        val t = SchedulePure.nextFire(i, LocalDateTime.now())
        if (t == null) { am.cancel(pi); return }
        val ms = t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
    }

    fun rescheduleAll(c: Context) = load(c).forEach { schedule(c, it) }
}

/** Vakti gelen program satırını bildirir ve aynı satırın sonraki zamanını kurar. */
class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { com.odak.app.CrashReport.guard(c, "schedule") { handle(c, i) } }
    private fun handle(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val item = ScheduleStore.load(c).firstOrNull { it.id == id } ?: return
        if (item.on && SchedulePure.runsOn(item, LocalDateTime.now().dayOfWeek)) {
            Reminders.note(c, 8000 + (id.hashCode() and 0xFFFFF), SchedulePure.fmt(item.min) + " · " + c.getString(R.string.sched_title), item.text)
        }
        ScheduleStore.schedule(c, item)
    }
}
