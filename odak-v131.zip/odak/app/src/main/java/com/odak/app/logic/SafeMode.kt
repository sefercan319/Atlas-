package com.odak.app.logic

/** Çökme döngüsü: kısa sürede art arda çökerse görünüm ayarları varsayılana döner (veriler silinmez). */
object SafeMode {
    const val WINDOW_MS = 120_000L
    const val LIMIT = 3
    const val KEEP = 6

    fun parse(s: String?): List<Long> = (s ?: "").split(',').mapNotNull { it.trim().toLongOrNull() }

    fun record(times: List<Long>, now: Long): List<Long> = (times + now).takeLast(KEEP)

    fun shouldReset(times: List<Long>, now: Long): Boolean = times.count { now - it in 0..WINDOW_MS } >= LIMIT

    fun encode(times: List<Long>): String = times.joinToString(",")
}
