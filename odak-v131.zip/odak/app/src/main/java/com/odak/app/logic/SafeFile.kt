package com.odak.app.logic

import java.io.File
import java.io.FileOutputStream

/**
 * Bozulmaya dayanıklı dosya yazma/okuma: yazma önce geçici dosyaya (diske zorlanarak), eski sürüm ".bak" olarak saklanır,
 * sonra yer değiştirilir. Okuma ana dosya bozuksa/boşsa yedeğe düşer. Elektrik/çökme yarım dosya bırakmaz.
 */
object SafeFile {
    private fun tmp(f: File) = File(f.parentFile, f.name + ".tmp")
    private fun bak(f: File) = File(f.parentFile, f.name + ".bak")

    fun write(f: File, text: String) {
        val t = tmp(f)
        FileOutputStream(t).use { o -> o.write(text.toByteArray(Charsets.UTF_8)); o.flush(); o.fd.sync() }
        if (f.exists() && f.length() > 0) try { f.copyTo(bak(f), overwrite = true) } catch (e: Exception) { }
        try {
            java.nio.file.Files.move(t.toPath(), f.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE)
        } catch (e: Exception) {
            f.writeText(text); t.delete()
        }
    }

    /** Ana dosya okunur ve [ok] doğrularsa onu, yoksa yedeği döndürür; ikisi de yoksa null. */
    fun read(f: File, ok: (String) -> Boolean = { true }): String? {
        for (c in listOf(f, bak(f))) {
            val s = try { if (c.exists()) c.readText() else null } catch (e: Exception) { null } ?: continue
            if (s.isNotBlank() && ok(s)) return s
        }
        return null
    }
}
