package com.odak.app.logic

/** PIN deneme sınırı: ilk 5 yanlışa bekleme yok, sonra 30 sn'den başlayıp her yanlışta ikiye katlanır (en çok 15 dk). */
object PinLimiter {
    const val FREE = 5
    const val BASE_MS = 30_000L
    const val MAX_MS = 15 * 60_000L

    fun lockMs(fails: Int): Long =
        if (fails < FREE) 0L else minOf(MAX_MS, BASE_MS shl minOf(fails - FREE, 10))

    /** Kalan bekleme (ms). Saat geriye alınırsa (now < lastFail) tam bekleme sayılır. */
    fun remainingMs(fails: Int, lastFail: Long, now: Long): Long {
        val lock = lockMs(fails)
        if (lock == 0L) return 0L
        if (now < lastFail) return lock
        return maxOf(0L, lastFail + lock - now)
    }
}
