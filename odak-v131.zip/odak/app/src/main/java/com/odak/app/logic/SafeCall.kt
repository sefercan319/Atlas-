package com.odak.app.logic

/** Hata yutan çağrı: Exception ve bellek/yığın taşması (OutOfMemoryError, StackOverflowError) yakalanır; iptal (CancellationException) yeniden fırlatılır. */
object SafeCall {
    inline fun <T> orElse(fallback: T, block: () -> T): T = try {
        block()
    } catch (e: java.util.concurrent.CancellationException) {
        throw e
    } catch (e: Exception) {
        fallback
    } catch (e: OutOfMemoryError) {
        fallback
    } catch (e: StackOverflowError) {
        fallback
    }

    inline fun <T> orNull(block: () -> T): T? = orElse(null) { block() }
}
