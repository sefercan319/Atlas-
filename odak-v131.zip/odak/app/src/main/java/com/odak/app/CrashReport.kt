package com.odak.app

import android.app.Application
import android.content.Context
import com.odak.app.logic.CrashLog
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** Beklenmedik çökmeleri dosyaya yazar; uygulama sonraki açılışta raporu paylaşmayı önerir. */
object CrashReport {
    private fun file(c: Context) = File(c.filesDir, "crash_report.txt")

    fun write(c: Context, thread: String, e: Throwable) {
        try {
            val sw = StringWriter(); e.printStackTrace(PrintWriter(sw))
            val ver = try { c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "?" } catch (x: Exception) { "?" }
            val entry = CrashLog.format(ver, android.os.Build.MODEL + " / Android " + android.os.Build.VERSION.RELEASE, java.time.LocalDateTime.now().toString(), thread, sw.toString())
            val f = file(c)
            f.writeText(CrashLog.append(if (f.exists()) f.readText() else "", entry))
        } catch (x: Throwable) { }
    }

    fun read(c: Context): String? = try { file(c).takeIf { it.exists() }?.readText()?.takeIf { CrashLog.hasReport(it) } } catch (x: Exception) { null }
    /** Yan görevlerde (alıcı, widget, servis) hata uygulamayı düşürmesin; rapora yazılır. */
    inline fun guard(c: Context, tag: String, body: () -> Unit) {
        try { body() } catch (x: Exception) { write(c, tag, x) }
    }

    private fun safePrefs(c: Context) = c.getSharedPreferences("odak_safe", Context.MODE_PRIVATE)

    fun noteCrash(c: Context) {
        try {
            val p = safePrefs(c)
            p.edit().putString("t", com.odak.app.logic.SafeMode.encode(com.odak.app.logic.SafeMode.record(com.odak.app.logic.SafeMode.parse(p.getString("t", "")), System.currentTimeMillis()))).commit()
        } catch (x: Throwable) { }
    }

    /** Art arda çökme varsa yalnız görünüm ayarlarını sıfırlar; true dönerse sıfırlandı. */
    fun resetAppearanceIfLooping(c: Context): Boolean = try {
        val p = safePrefs(c)
        val times = com.odak.app.logic.SafeMode.parse(p.getString("t", ""))
        if (com.odak.app.logic.SafeMode.shouldReset(times, System.currentTimeMillis())) {
            c.getSharedPreferences("odak_colors", Context.MODE_PRIVATE).edit().clear().commit()
            c.getSharedPreferences("odak_theme", Context.MODE_PRIVATE).edit().clear().commit()
            c.getSharedPreferences("odak_app", Context.MODE_PRIVATE).edit().remove("fscale").remove("ui_scale").remove("last_tab").commit()
            p.edit().clear().commit()
            true
        } else false
    } catch (x: Throwable) { false }

    fun clear(c: Context) { try { file(c).delete() } catch (x: Exception) { } }
}

class AtlasApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            CrashReport.write(applicationContext, t.name, e)
            CrashReport.noteCrash(applicationContext)
            prev?.uncaughtException(t, e)
        }
    }
}
