package com.odak.app.logic

/** Çökme raporu biçimi (saf mantık): en yeni kayıt korunur, boyut sınırlı. */
object CrashLog {
    const val MAX_ENTRY = 8000
    const val MAX_FILE = 30000

    fun format(version: String, device: String, time: String, thread: String, stack: String): String =
        ("== $time · $version · $device · $thread\n" + stack.trim()).take(MAX_ENTRY) + "\n"

    /** Yeni kaydı sona ekler; dosya sınırı aşılırsa en eski kısım atılır. */
    fun append(old: String, entry: String): String {
        val all = old + entry
        return if (all.length <= MAX_FILE) all else all.takeLast(MAX_FILE).let { s -> val i = s.indexOf("== "); if (i >= 0) s.substring(i) else s }
    }

    fun hasReport(s: String?): Boolean = !s.isNullOrBlank() && s.contains("== ")
}
