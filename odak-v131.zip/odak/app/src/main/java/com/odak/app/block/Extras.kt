package com.odak.app.block

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.sp
import com.odak.app.theme.plainClick
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import com.odak.app.R
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.ThemedTextField
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private class Cand(val pkg: String, val label: String)

private fun launchables(c: Context): List<Cand> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { Cand(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .distinctBy { it.pkg }
        .filter { !BlockCatalog.protectedPkg(c, it.pkg) && BlockCatalog.byPackage(it.pkg) == null }
        .sortedBy { it.label.lowercase() }
}

/** Yüklü uygulamalardan birini engellenecekler listesine ekletir. */
@Composable
fun CustomAppPicker(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var all by remember { mutableStateOf<List<Cand>>(emptyList()) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { all = withContext(Dispatchers.IO) { launchables(ctx) } }
    val shown = all.filter { com.odak.app.logic.Pure.nameMatches(it.label, q, it.pkg) }
    var lim by remember(q) { mutableStateOf(com.odak.app.logic.Pure.APP_PAGE) }
    AlertDialog(
        onDismissRequest = onDone,
        confirmButton = {},
        dismissButton = { ThemedButton("✕", onDone) },
        title = { Text(stringResource(R.string.custom_app_pick)) },
        text = {
            Column {
                ThemedTextField(q, { q = it }, "🔍", Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                if (all.isNotEmpty() && shown.isEmpty()) {
                    Text(stringResource(R.string.custom_app_none), style = MaterialTheme.typography.bodySmall)
                }
                LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(shown.take(com.odak.app.logic.Pure.appsVisible(lim, shown.size)), key = { it.pkg }) { a ->
                        // Aynı adlı uygulamaları ayırmak için paket adı da gösterilir.
                        ThemedButton(a.label + "\n" + a.pkg, {
                            BlockCatalog.addCustom(ctx, a.pkg, a.label)
                            onDone()
                        }, Modifier.fillMaxWidth())
                    }
                    item {
                        val rem = com.odak.app.logic.Pure.appsRemaining(lim, shown.size)
                        if (rem > 0) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemedButton(stringResource(R.string.blk_more, rem), { lim = com.odak.app.logic.Pure.appsNextShown(lim, shown.size) })
                            ThemedButton(stringResource(R.string.blk_all), { lim = shown.size })
                        }
                    }
                }
            }
        }
    )
}

/** Engelli uygulamaların bildirimlerini gizleme anahtarı + izin düğmesi. */
@Composable
fun NotifHideCard() {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(BlockStore.notifHide(ctx)) }
    var granted by remember { mutableStateOf(false) }
    LaunchedEffect(on) {
        while (true) {
            granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
            kotlinx.coroutines.delay(2000)
        }
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        androidx.compose.foundation.layout.Row(
            Modifier.fillMaxWidth(),
            Arrangement.SpaceBetween,
            androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(stringResource(R.string.notif_hide), Modifier.weight(1f))
            ThemedCheck(on && granted) { v ->
                if (v && !granted) {
                    com.odak.app.Launch.go(ctx, 
                        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } else {
                    on = v
                    BlockStore.setNotifHide(ctx, v)
                }
            }
        }
        if (!granted) {
            Spacer(Modifier.height(8.dp))
            ThemedButton(stringResource(R.string.block_grant), {
                on = true
                BlockStore.setNotifHide(ctx, true)
                com.odak.app.Launch.go(ctx, 
                    Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            })
        }
    }
}

/** Uyarı ve bildirim ayarları: eşik, bildirim, ek süre, özel mesajlar. */
@Composable
fun AlertsCard() {
    val ctx = LocalContext.current
    var warn by remember { mutableStateOf(BlockStore.warnOn(ctx)) }
    var pct by remember { mutableStateOf(BlockStore.warnPct(ctx)) }
    var note by remember { mutableStateOf(BlockStore.limitNoteOn(ctx)) }
    var strict by remember { mutableStateOf(BlockStore.strictLimit(ctx)) }
    var featHome by remember { mutableStateOf(BlockStore.featHome(ctx)) }
    var nmsg by remember { mutableStateOf(BlockStore.noteMsg(ctx)) }
    @Composable
    fun row(label: String, v: Boolean, f: (Boolean) -> Unit) {
        androidx.compose.foundation.layout.Row(
            Modifier.fillMaxWidth().padding(vertical = 4.dp),
            Arrangement.SpaceBetween,
            androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(label, Modifier.weight(1f))
            ThemedCheck(v, f)
        }
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text("🔔", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
        row(stringResource(R.string.alert_warn_on), warn) { warn = it; BlockStore.setWarnOn(ctx, it) }
        if (warn) {
            val opts = listOf(50, 70, 80, 90)
            androidx.compose.foundation.layout.Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.alert_pct), Modifier.weight(1f))
                opts.forEach { o ->
                    ThemedButton(if (pct == o) "✔ $o%" else "$o%", { pct = o; BlockStore.setWarnPct(ctx, o) })
                }
            }
        }
        row(stringResource(R.string.alert_limit_on), note) { note = it; BlockStore.setLimitNoteOn(ctx, it) }
        row(stringResource(R.string.alert_strict), strict) { strict = it; BlockStore.setStrictLimit(ctx, it) }
        row(stringResource(R.string.alert_feat_home), featHome) { featHome = it; BlockStore.setFeatHome(ctx, it) }
        Spacer(Modifier.height(8.dp))
        ThemedTextField(nmsg, { nmsg = it.take(120); BlockStore.setNoteMsg(ctx, nmsg) }, stringResource(R.string.alert_note_msg), Modifier.fillMaxWidth())
    }
}

private val ScrColors = listOf(
    0xFF111111, 0xFFB71C1C, 0xFFE65100, 0xFFF9A825, 0xFF1B5E20,
    0xFF006064, 0xFF0D47A1, 0xFF4A148C, 0xFFAD1457, 0xFFFFFFFF
)

/** Özelleştirilebilir uyarı ekranları (engel ve süre doldu) + canlı önizleme. */
@Composable
fun ScreensCard() {
    val ctx = LocalContext.current
    for (kind in listOf("blk", "lim")) {
        var icon by remember { mutableStateOf(BlockStore.scr(ctx, kind, "icon")) }
        var title by remember { mutableStateOf(BlockStore.scr(ctx, kind, "title")) }
        var msg by remember { mutableStateOf(BlockStore.scr(ctx, kind, "msg")) }
        var bg by remember { mutableStateOf(BlockStore.scr(ctx, kind, "bg")) }
        var size by remember { mutableStateOf(BlockStore.scr(ctx, kind, "size")) }
        val bgc = bg.toLongOrNull()?.let { androidx.compose.ui.graphics.Color(it) }
        ThemedCard(Modifier.fillMaxWidth()) {
            Text(
                stringResource(if (kind == "blk") R.string.scr_blk else R.string.scr_lim),
                style = androidx.compose.material3.MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
            // önizleme
            val tk = com.odak.app.theme.LocalDesign.current.tokens
            val fg = if (bgc == null) tk.text
            else if (bgc.luminance() > 0.5f) androidx.compose.ui.graphics.Color(0xFF111111)
            else androidx.compose.ui.graphics.Color.White
            val k = when (size) { "0" -> 0.75f; "2" -> 1.35f; else -> 1f }
            androidx.compose.foundation.layout.Box(
                Modifier.fillMaxWidth().height(150.dp)
                    .background(bgc ?: tk.background, androidx.compose.foundation.shape.RoundedCornerShape(10.dp)),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                    Text(icon.ifBlank { "⛔" }, fontSize = (34 * k).sp, color = fg)
                    Text(
                        title.ifBlank { stringResource(if (kind == "lim") R.string.limit_reached_title else R.string.block_app_msg) },
                        fontSize = (16 * k).sp, color = fg
                    )
                    Text(msg.ifBlank { stringResource(R.string.motiv_1) }, fontSize = (12 * k).sp, color = fg.copy(alpha = 0.8f), maxLines = 2)
                }
            }
            Spacer(Modifier.height(8.dp))
            ThemedTextField(icon, { icon = it.take(4); BlockStore.setScr(ctx, kind, "icon", icon) }, stringResource(R.string.scr_icon_hint), Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            ThemedTextField(title, { title = it.take(40); BlockStore.setScr(ctx, kind, "title", title) }, stringResource(R.string.scr_title_hint), Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            ThemedTextField(msg, { msg = it.take(120); BlockStore.setScr(ctx, kind, "msg", msg) }, stringResource(R.string.alert_block_msg), Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            androidx.compose.foundation.layout.FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                androidx.compose.foundation.layout.Box(
                    Modifier.size(30.dp)
                        .border(1.dp, tk.text.copy(alpha = 0.5f), androidx.compose.foundation.shape.CircleShape)
                        .plainClick { bg = ""; BlockStore.setScr(ctx, kind, "bg", "") },
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) { Text(if (bg.isEmpty()) "✓" else "∅", fontSize = 14.sp) }
                ScrColors.forEach { c ->
                    androidx.compose.foundation.layout.Box(
                        Modifier.size(30.dp)
                            .background(androidx.compose.ui.graphics.Color(c), androidx.compose.foundation.shape.CircleShape)
                            .border(1.dp, Color(0x55888888), androidx.compose.foundation.shape.CircleShape)
                            .plainClick { bg = c.toString(); BlockStore.setScr(ctx, kind, "bg", bg) },
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        if (bg == c.toString()) Text(
                            "✓", fontSize = 15.sp,
                            color = if (androidx.compose.ui.graphics.Color(c).luminance() > 0.5f) Color.Black else Color.White
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("A−", "A", "A+").forEachIndexed { i, l ->
                    val v = i.toString()
                    val on = size == v || (size.isEmpty() && i == 1)
                    ThemedButton(if (on) "✔ $l" else l, { size = v; BlockStore.setScr(ctx, kind, "size", v) })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

/** Kural Laboratuvarı: bölümde ve dışında kayıt alıp ayırt edici kimlikleri türetir. */
@Composable
fun RuleLabDialog(appId: String, featId: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var saved by remember { mutableStateOf(-1) }
    var savedN by remember { mutableStateOf(RuleLab.savedCount(ctx, appId, featId)) }
    var confirmDel by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        RuleLab.start(appId, featId)
        while (true) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(500) }
    }
    val rec = RuleLab.recording(now)
    val ids = if (rec) emptyList() else RuleLab.preview()
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(stringResource(R.string.rl_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(R.string.rl_help))
                if (rec) Text(
                    stringResource(R.string.rl_rec) + " " + ((RuleLab.endAt - now) / 1000 + 1) + " s"
                )
                ThemedButton("1 · " + stringResource(R.string.rl_pos) + "  (${RuleLab.posScans})", {
                    saved = -1; RuleLab.record("pos")
                })
                ThemedButton("2 · " + stringResource(R.string.rl_neg) + "  (${RuleLab.negScans})", {
                    saved = -1; RuleLab.record("neg")
                })
                if (ids.isNotEmpty()) Text(ids.joinToString("\n"))
                else if (!rec && RuleLab.posScans > 0 && RuleLab.negScans > 0) Text(stringResource(R.string.rl_none))
                if (saved > 0) Text("✅ " + stringResource(R.string.rl_done))
                if (savedN > 0) {
                    Text(stringResource(R.string.rl_saved_n, savedN), style = MaterialTheme.typography.bodySmall)
                    // Kural silmek engellemeyi zayıflatır. Bu yüzden yalnızca bölüm engelli değilken
                    // silinebilir (engel kapatma akışındaki bekleme süresi atlanmaz) ve iki adımlı onay ister.
                    if (!BlockStore.isFeatureBlocked(ctx, appId, featId)) {
                        ThemedButton(if (confirmDel) "⚠ " + stringResource(R.string.rl_del_confirm) else stringResource(R.string.rl_del), {
                            if (!confirmDel) confirmDel = true
                            else {
                                RuleLab.removeSaved(ctx, appId, featId)
                                savedN = 0; confirmDel = false
                            }
                        })
                    }
                }
                val uf = java.io.File(ctx.filesDir, "user_rules.json")
                if (uf.exists()) ThemedButton("📤 " + stringResource(R.string.rl_share), {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, uf.readText())
                    com.odak.app.Launch.go(ctx, Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                })
            }
        },
        confirmButton = {
            ThemedButton(stringResource(R.string.rl_make), {
                if (!rec && ids.isNotEmpty()) {
                    saved = RuleLab.make(ctx)
                    savedN = RuleLab.savedCount(ctx, appId, featId)
                    confirmDel = false
                }
            })
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ThemedButton(stringResource(R.string.rl_reset), { RuleLab.reset(); saved = -1 })
                ThemedButton("✕", onClose)
            }
        }
    )
}
