package com.odak.app.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard

/** "Diğer" sekmesi: tüm ikincil bölümler tek, düzenli listede. */
enum class MoreEntry(val icon: String, val titleRes: Int, val descRes: Int) {
    SCREEN_TIME("⏱", R.string.tab_screen_time, R.string.more_d_screen),
    DOCS("📄", R.string.doc_title, R.string.more_d_docs),
    PROGRAM("🗓", R.string.sched_title, R.string.more_d_sched),
    SETTINGS("⚙", R.string.tab_settings, R.string.more_d_settings)
}

private fun secTitle(id: String): Int = when (id) {
    "TOOLS" -> R.string.more_sec_tools
    else -> R.string.more_sec_app
}

@Composable
fun MoreScreen(screenTime: @Composable () -> Unit, settings: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf<MoreEntry?>(null) }
    val prefs = remember { ctx.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE) }
    var recents by remember { mutableStateOf(MoreRecents.decode(prefs.getString("more_recent", ""))) }
    fun launch(e: MoreEntry) {
        recents = MoreRecents.push(recents, e.name)
        prefs.edit().putString("more_recent", MoreRecents.encode(recents)).apply()
        when (e) {
            MoreEntry.DOCS -> com.odak.app.Launch.go(ctx, android.content.Intent(ctx, com.odak.app.docs.DocActivity::class.java))
            else -> open = e
        }
    }
    BackHandler(enabled = open != null) { open = null }
    when (open) {
        MoreEntry.SCREEN_TIME -> SubPage(MoreEntry.SCREEN_TIME, { open = null }, screenTime)
        MoreEntry.PROGRAM -> SubPage(MoreEntry.PROGRAM, { open = null }) { com.odak.app.schedule.ScheduleScreen() }
        MoreEntry.SETTINGS -> SubPage(MoreEntry.SETTINGS, { open = null }, settings)
        else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            if (recents.isNotEmpty()) {
                Text(stringResource(R.string.more_recent), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(bottom = 6.dp).alpha(0.7f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    recents.forEach { name ->
                        val e = MoreEntry.valueOf(name)
                        Box(Modifier.weight(1f)) { ThemedButton(e.icon + " " + stringResource(e.titleRes), { launch(e) }) }
                    }
                    if (recents.size < MoreRecents.MAX) Spacer(Modifier.weight((MoreRecents.MAX - recents.size).toFloat()))
                }
            }
            MoreLayout.sections.forEach { (id, names) ->
                Text(stringResource(secTitle(id)), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp).alpha(0.7f))
                MoreLayout.rows(names).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { name ->
                            val e = MoreEntry.valueOf(name)
                            ThemedCard(
                                modifier = Modifier.weight(1f).heightIn(min = 112.dp),
                                onClick = { launch(e) }
                            ) {
                                Text(e.icon, style = MaterialTheme.typography.headlineMedium)
                                Spacer(Modifier.height(6.dp))
                                Text(stringResource(e.titleRes), style = MaterialTheme.typography.titleMedium)
                                Text(stringResource(e.descRes), style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.7f))
                            }
                        }
                        if (row.size < MoreLayout.COLUMNS) Spacer(Modifier.weight((MoreLayout.COLUMNS - row.size).toFloat()))
                    }
                }
            }
        }
    }
}

@Composable
private fun SubPage(e: MoreEntry, onBack: () -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 16.dp, top = 12.dp, end = 16.dp)) {
            ThemedButton("‹ " + stringResource(R.string.tab_more), onBack)
        }
        Spacer(Modifier.height(4.dp))
        Column(Modifier.weight(1f)) { content() }
    }
}
