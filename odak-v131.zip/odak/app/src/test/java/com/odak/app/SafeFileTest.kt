package com.odak.app

import com.odak.app.logic.SafeFile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SafeFileTest {
    private fun dir(): File = java.nio.file.Files.createTempDirectory("sf").toFile()

    @Test fun writeThenRead() {
        val f = File(dir(), "a.json"); SafeFile.write(f, "{\"a\":1}")
        assertEquals("{\"a\":1}", SafeFile.read(f)); assertFalse(File(f.parentFile, "a.json.tmp").exists())
    }
    @Test fun secondWriteKeepsPreviousAsBackup() {
        val f = File(dir(), "a.json"); SafeFile.write(f, "v1"); SafeFile.write(f, "v2")
        assertEquals("v2", f.readText()); assertEquals("v1", File(f.parentFile, "a.json.bak").readText())
    }
    @Test fun corruptMainFallsBackToBackup() {
        val f = File(dir(), "a.json"); SafeFile.write(f, "{\"ok\":1}"); SafeFile.write(f, "{\"ok\":2}")
        f.writeText("{\"ok\":2") // yarım kalmış yazma
        assertEquals("{\"ok\":1}", SafeFile.read(f) { it.trim().endsWith("}") })
    }
    @Test fun emptyOrMissingGivesNullOrBackup() {
        val f = File(dir(), "a.json")
        assertNull(SafeFile.read(f))
        f.writeText("")
        assertNull(SafeFile.read(f))
    }
    @Test fun leftoverTmpIsIgnored() {
        val f = File(dir(), "a.json"); SafeFile.write(f, "good")
        File(f.parentFile, "a.json.tmp").writeText("half")
        assertEquals("good", SafeFile.read(f))
        SafeFile.write(f, "next"); assertEquals("next", SafeFile.read(f))
    }
    @Test fun utf8Roundtrip() {
        val f = File(dir(), "a.txt"); SafeFile.write(f, "şğüöçİ ✔ 🎯"); assertEquals("şğüöçİ ✔ 🎯", SafeFile.read(f))
    }
    @Test fun ruleFilesUseSafeFile() {
        fun src(p: String) = File(TestFiles.code, "com/odak/app/block/$p").readText()
        assertTrue(src("RuleLab.kt").contains("SafeFile.write(f, o.toString())") && !src("RuleLab.kt").contains("f.writeText"))
        val b = src("BlockData.kt")
        assertTrue(b.contains("SafeFile.write(File(c.filesDir, \"block_rules.json\"), text)") && b.contains("SafeFile.write(f, have.sorted()"))
    }
}
