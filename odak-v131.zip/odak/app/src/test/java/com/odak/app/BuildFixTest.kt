package com.odak.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.25: GitHub derlemesinde görülen iki hata için koruma testleri (fr tırnak kaçışı, MainActivity dp importu). */
class BuildFixTest {
    private fun stringBodies(text: String): List<String> =
        Regex("<string name=\"[^\"]+\"[^>]*>(.*?)</string>", RegexOption.DOT_MATCHES_ALL).findAll(text).map { it.groupValues[1] }.toList()

    private fun localeFiles(): List<File> =
        TestFiles.res.listFiles { f -> f.isDirectory && f.name.startsWith("values") }!!.map { File(it, "strings.xml") }.filter { it.exists() }

    @Test fun everyLocaleHasEscapedApostrophes() {
        val bad = mutableListOf<String>()
        for (f in localeFiles()) for (body in stringBodies(f.readText())) {
            if (Regex("(?<!\\\\)'").containsMatchIn(body)) bad.add("${f.parentFile.name}: $body")
        }
        assertTrue(bad.joinToString("\n"), bad.isEmpty())
    }

    @Test fun everyLocaleHasValidUnicodeEscapes() {
        val bad = mutableListOf<String>()
        for (f in localeFiles()) for (body in stringBodies(f.readText())) {
            if (Regex("\\\\u(?![0-9a-fA-F]{4})").containsMatchIn(body)) bad.add("${f.parentFile.name}: $body")
        }
        assertTrue(bad.joinToString("\n"), bad.isEmpty())
    }

    @Test fun frenchQuietStateSameIsEscaped() {
        val t = File(TestFiles.res, "values-fr/strings.xml").readText()
        assertTrue(t.contains("l\\'intervalle est fermé"))
        assertFalse(t.contains("l'intervalle"))
    }

    @Test fun mainActivityImportsDpWhenUsingIt() {
        val src = File(TestFiles.code, "com/odak/app/MainActivity.kt").readText()
        assertTrue(src.contains(").dp"))
        assertTrue(src.contains("import androidx.compose.ui.unit.dp"))
    }

    private val projectRoot: File get() = File(TestFiles.main, "../../..").canonicalFile

    @Test fun workflowUsesNode24ActionVersions() {
        val wf = File(projectRoot, ".github/workflows/build-apk.yml").readText()
        for (a in listOf("actions/checkout@v5", "actions/setup-java@v5", "gradle/actions/setup-gradle@v5")) assertTrue(a, wf.contains(a))
        for (a in listOf("actions/checkout@v4", "actions/setup-java@v4", "gradle/actions/setup-gradle@v4")) assertFalse(a, wf.contains(a))
    }

    @Test fun workflowExtractsProjectZip() {
        val wf = File(projectRoot, ".github/workflows/build-apk.yml").readText()
        assertTrue(wf.contains("unzip -q"))
        assertTrue(wf.contains("cd work/odak"))
    }

    @Test fun gradlePropertiesSuppressesCompileSdkWarning() {
        assertTrue(File(projectRoot, "gradle.properties").readText().contains("android.suppressUnsupportedCompileSdk=37,37.0"))
    }
}
