package com.odak.app

import com.odak.app.logic.SafeCall
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SafeCallTest {
    private fun deep(n: Int): Int = if (n == 0) 0 else 1 + deep(n - 1)

    @Test fun normalValuePassesThrough() { assertEquals(5, SafeCall.orElse(0) { 5 }) }
    @Test fun exceptionBecomesFallback() { assertEquals(-1, SafeCall.orElse(-1) { error("x") }) }
    @Test fun stackOverflowBecomesFallback() { assertNull(SafeCall.orNull { deep(10_000_000) }) }
    @Test fun outOfMemoryBecomesFallback() { assertEquals("x", SafeCall.orElse("x") { throw OutOfMemoryError() }) }
    @Test fun cancellationIsRethrown() {
        var thrown = false
        try { SafeCall.orElse(0) { throw java.util.concurrent.CancellationException("c") } } catch (e: java.util.concurrent.CancellationException) { thrown = true }
        assertTrue(thrown)
    }
    @Test fun docEntryPointsCatchDeepAndHugeInputs() {
        val d = java.io.File(TestFiles.code, "com/odak/app/docs/DocActivity.kt").readText()
        assertTrue(Regex("catch \\(e: StackOverflowError\\)").findAll(d).count() >= 3)
        assertTrue(d.contains("DocState.Err(R.string.doc_error) // çok derin"))
        assertTrue(java.io.File(TestFiles.code, "com/odak/app/MainActivity.kt").readText().contains("SafeCall.orNull"))
    }
}
