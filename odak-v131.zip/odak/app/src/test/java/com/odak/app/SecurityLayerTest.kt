package com.odak.app

import com.odak.app.logic.PinLimiter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SecurityLayerTest {
    private val main = File("src/main")
    private fun src(p: String) = File("src/main/java/com/odak/app/$p").readText()

    @Test fun noLockBeforeFiveFails() { for (n in 0..4) assertEquals(0L, PinLimiter.lockMs(n)) }
    @Test fun lockDoublesFromThirtySeconds() {
        assertEquals(30_000L, PinLimiter.lockMs(5)); assertEquals(60_000L, PinLimiter.lockMs(6)); assertEquals(120_000L, PinLimiter.lockMs(7))
    }
    @Test fun lockCappedAtFifteenMinutes() {
        assertEquals(15 * 60_000L, PinLimiter.lockMs(50)); assertEquals(15 * 60_000L, PinLimiter.lockMs(Int.MAX_VALUE))
    }
    @Test fun remainingCountsDown() {
        assertEquals(30_000L, PinLimiter.remainingMs(5, 1000, 1000))
        assertEquals(10_000L, PinLimiter.remainingMs(5, 1000, 21_000))
        assertEquals(0L, PinLimiter.remainingMs(5, 1000, 31_000))
        assertEquals(0L, PinLimiter.remainingMs(3, 1000, 1000))
    }
    @Test fun clockRollbackStaysLocked() { assertEquals(30_000L, PinLimiter.remainingMs(5, 100_000, 5_000)) }

    @Test fun pinCheckEnforcesLimiter() {
        val s = src("block/Pin.kt")
        assertTrue(s.contains("PinLimiter.remainingMs")); assertTrue(s.contains("recordFail(c)"))
        assertTrue(s.indexOf("lockRemainingMs(c) > 0") < s.indexOf("PinHash.verify(pin"))
        assertTrue(s.contains("odak_pinfail"))
    }
    @Test fun lockMessageInEveryLocale() {
        for (d in listOf("values", "values-tr", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az")) {
            val t = File(main, "res/$d/strings.xml").readText()
            val m = Regex("name=\"pin_locked\">([^<]*)<").find(t)
            assertTrue("$d pin_locked", m != null); assertTrue("$d placeholder", m!!.groupValues[1].contains("%1\$d"))
        }
    }
    @Test fun manifestHardening() {
        val m = File(main, "AndroidManifest.xml").readText()
                assertTrue(m.contains("@xml/data_extraction_rules")); assertTrue(m.contains("@xml/backup_rules"))
        for (f in listOf("data_extraction_rules", "backup_rules")) {
            val x = File(main, "res/xml/$f.xml").readText()
            for (k in listOf("odak_pin.xml", "odak_pinfail.xml", "odak_safe.xml", "crash_report.txt")) assertTrue("$f $k", x.contains(k))
        }
    }
    @Test fun noBareStartActivityOutsideLaunch() {
        File("src/main/java").walkTopDown().filter { it.extension == "kt" && it.name != "Launch.kt" }.forEach {
            assertFalse("${it.name} çıplak startActivity", Regex("\\bstartActivity\\(").containsMatchIn(it.readText()))
        }
    }
    @Test fun launchCatchesNotFoundAndSecurity() {
        val s = src("Launch.kt")
        assertTrue(s.contains("ActivityNotFoundException")); assertTrue(s.contains("SecurityException"))
    }
    @Test fun openSettingsLambdaIsUnitTyped() {
        // Launch.go Boolean döner; çıkarımla () -> Boolean olursa ThemedButton (() -> Unit) derlenmez
        assertTrue(src("block/BlockScreen.kt").contains("val openSettings: () -> Unit"))
    }
}
