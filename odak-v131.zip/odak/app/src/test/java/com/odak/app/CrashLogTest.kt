package com.odak.app

import com.odak.app.logic.CrashLog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CrashLogTest {
    @Test fun formatHasHeaderAndTrims() {
        val s = CrashLog.format("0.56.68", "Pixel / Android 16", "2026-10-29T10:00", "main", "  java.lang.Boom\n at x  ")
        assertTrue(s.startsWith("== 2026-10-29T10:00 · 0.56.68 · Pixel / Android 16 · main\n"))
        assertTrue(s.endsWith("at x\n"))
        assertTrue(CrashLog.format("v", "d", "t", "n", "x".repeat(50000)).length <= CrashLog.MAX_ENTRY + 1)
    }
    @Test fun appendKeepsNewestWithinLimit() {
        var f = ""
        repeat(20) { i -> f = CrashLog.append(f, CrashLog.format("v", "d", "t$i", "n", "y".repeat(3000))) }
        assertTrue(f.length <= CrashLog.MAX_FILE)
        assertTrue(f.startsWith("== "))
        assertTrue(f.contains("t19"))
        assertFalse(f.contains("== t0 "))
    }
    @Test fun hasReport() {
        assertFalse(CrashLog.hasReport(null)); assertFalse(CrashLog.hasReport("  ")); assertTrue(CrashLog.hasReport("== a"))
    }
    @Test fun wiredEverywhere() {
        val m = java.io.File(TestFiles.main, "AndroidManifest.xml").readText()
        assertTrue(m.contains("android:name=\".AtlasApplication\""))
        val c = java.io.File(TestFiles.code, "com/odak/app/CrashReport.kt").readText()
        assertTrue(c.contains("setDefaultUncaughtExceptionHandler") && c.contains("prev?.uncaughtException(t, e)"))
        val svc = java.io.File(TestFiles.code, "com/odak/app/block/OdakAccessibilityService.kt").readText()
        assertTrue(svc.contains("try { handle(e) } catch (x: Exception)"))
        assertTrue(java.io.File(TestFiles.code, "com/odak/app/MainActivity.kt").readText().contains("CrashReport.read(context)"))
        for (l in listOf("", "-tr", "-en", "-de", "-fr", "-es", "-ar", "-ru", "-az"))
            assertTrue(l, java.io.File(TestFiles.main, "res/values$l/strings.xml").readText().contains("name=\"crash_msg\""))
    }
}
