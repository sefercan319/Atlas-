package com.odak.app

import com.odak.app.logic.SafeMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SafeModeTest {
    @Test fun parseAndEncode() {
        assertEquals(listOf(1L, 2L), SafeMode.parse("1, 2,x,"))
        assertEquals(emptyList<Long>(), SafeMode.parse(null))
        assertEquals("1,2", SafeMode.encode(listOf(1L, 2L)))
    }
    @Test fun keepsOnlyLastFew() {
        var t = emptyList<Long>()
        repeat(10) { t = SafeMode.record(t, it.toLong()) }
        assertEquals(SafeMode.KEEP, t.size); assertEquals(9L, t.last())
    }
    @Test fun threeQuickCrashesTriggerReset() {
        val now = 1_000_000L
        assertTrue(SafeMode.shouldReset(listOf(now - 100_000, now - 50_000, now - 1_000), now))
        assertFalse(SafeMode.shouldReset(listOf(now - 100_000, now - 50_000), now))                 // yalnız 2
        assertFalse(SafeMode.shouldReset(listOf(now - 900_000, now - 800_000, now - 700_000), now)) // eski çökmeler
    }
    @Test fun wiredInApp() {
        fun src(f: String) = java.io.File(TestFiles.code, "com/odak/app/$f").readText()
        assertTrue(src("CrashReport.kt").contains("CrashReport.noteCrash(applicationContext)") && src("CrashReport.kt").contains("resetAppearanceIfLooping"))
        assertTrue(src("MainActivity.kt").contains("CrashReport.resetAppearanceIfLooping(applicationContext)"))
        // veri dosyaları sıfırlanmaz: yalnız görünüm tercihleri
        val r = src("CrashReport.kt").substringAfter("fun resetAppearanceIfLooping").substringBefore("fun clear(")
        assertTrue(r.contains("odak_colors") && r.contains("odak_theme") && !r.contains("odak_plan") && !r.contains("filesDir"))
    }
    @Test fun backgroundEntryPointsAreGuarded() {
        fun src(f: String) = java.io.File(TestFiles.code, "com/odak/app/$f").readText()
        assertEquals(3, Regex("CrashReport.guard\\(c, \"receiver\"").findAll(src("notify/Reminders.kt")).count { true })
        assertTrue(src("schedule/ScheduleStore.kt").contains("CrashReport.guard(c, \"schedule\")"))
        assertTrue(src("notify/PlanWidget.kt").contains("CrashReport.guard(c, \"widget\")"))
        assertTrue(src("block/OdakNotifService.kt").contains("CrashReport.guard(applicationContext, \"notif\")"))
    }
}
