package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * GitHub derlemesini kıran en sık hata: Compose sembolünü içe aktarmadan kullanmak.
 * Burada her kaynak dosyada çıplak kullanılan bilinen Compose sembollerinin içe aktarıldığı denetlenir.
 */
class ComposeImportTest {
    // ad -> kabul edilen paket önekleri (içe aktarma bu önekle başlayıp ".ad" ile bitmeli)
    private val types = mapOf(
        "Column" to "androidx.compose.foundation.layout", "Row" to "androidx.compose.foundation.layout",
        "Box" to "androidx.compose.foundation.layout", "Spacer" to "androidx.compose.foundation.layout",
        "LazyColumn" to "androidx.compose.foundation.lazy", "LazyRow" to "androidx.compose.foundation.lazy",
        "AlertDialog" to "androidx.compose.material3", "MaterialTheme" to "androidx.compose.material3",
        "LaunchedEffect" to "androidx.compose.runtime", "DisposableEffect" to "androidx.compose.runtime",
        "CircleShape" to "androidx.compose.foundation.shape", "RoundedCornerShape" to "androidx.compose.foundation.shape",
        "Modifier" to "androidx.compose.ui", "Alignment" to "androidx.compose.ui",
        "Arrangement" to "androidx.compose.foundation.layout", "Color" to "androidx.compose.ui.graphics"
    )
    private val plainFns = mapOf(
        "remember" to "androidx.compose.runtime", "mutableStateOf" to "androidx.compose.runtime",
        "mutableIntStateOf" to "androidx.compose.runtime", "rememberSaveable" to "androidx.compose.runtime.saveable",
        "rememberScrollState" to "androidx.compose.foundation", "stringResource" to "androidx.compose.ui.res"
    )
    private val modExt = mapOf(
        "verticalScroll" to "androidx.compose.foundation", "horizontalScroll" to "androidx.compose.foundation",
        "clickable" to "androidx.compose.foundation", "background" to "androidx.compose.foundation",
        "border" to "androidx.compose.foundation", "fillMaxWidth" to "androidx.compose.foundation.layout",
        "fillMaxSize" to "androidx.compose.foundation.layout", "padding" to "androidx.compose.foundation.layout",
        "size" to "androidx.compose.foundation.layout", "height" to "androidx.compose.foundation.layout",
        "width" to "androidx.compose.foundation.layout", "heightIn" to "androidx.compose.foundation.layout",
        "alpha" to "androidx.compose.ui.draw", "clip" to "androidx.compose.ui.draw", "imePadding" to "androidx.compose.foundation.layout"
    )

    private fun imported(t: String, name: String, pkg: String) =
        Regex("^import ${Regex.escape(pkg)}(\\.[a-z]+)*\\.$name(\\s+as\\s+\\w+)?\\s*$", RegexOption.MULTILINE).containsMatchIn(t) ||
            Regex("^import ${Regex.escape(pkg)}(\\.[a-z]+)*\\.\\*\\s*$", RegexOption.MULTILINE).containsMatchIn(t)

    @Test fun composeSymbolsAreImported() {
        val bad = ArrayList<String>()
        for (f in TestFiles.kotlinSources()) {
            val t = f.readText()
            if (!t.contains("@Composable") && !t.contains("import androidx.compose")) continue
            val code = t.lines().filterNot { it.trimStart().startsWith("//") || it.trimStart().startsWith("*") || it.trimStart().startsWith("/*") }.joinToString("\n")
            val body = code.lines().filterNot { it.startsWith("import ") }.joinToString("\n")
            for ((n, p) in types) if (Regex("(^|[^A-Za-z0-9_.\"])$n[(.]", RegexOption.MULTILINE).containsMatchIn(body) && !imported(t, n, p) && !t.contains("class $n") && !t.contains("object $n")) bad.add("${f.name}: $n")
            for ((n, p) in plainFns) if (Regex("(^|[^A-Za-z0-9_.])$n[ (<{]", RegexOption.MULTILINE).containsMatchIn(body) && !imported(t, n, p)) bad.add("${f.name}: $n")
            for ((n, p) in modExt) if (Regex("(Modifier|\\n\\s+|\\))\\s*\\.$n\\(").containsMatchIn(body) && !imported(t, n, p)) bad.add("${f.name}: .$n()")
        }
        assertTrue("içe aktarma eksik olabilir: $bad", bad.isEmpty())
    }
}

class WorkflowFallbackTest {
    @Test fun workflowFallsBackToPreviousZip() {
        val f = java.io.File(TestFiles.main, "../../../.github/workflows/build-apk.yml")
        assertTrue(f.exists())
        val t = f.readText()
        assertTrue(t.contains("sort -V -r") && t.contains("bir önceki zip deneniyor") && t.contains("testDebugUnitTest assembleDebug"))
    }
}
