package com.odak.app.settings

/** "Diğer" ekranının bölüm düzeni: her bölüm bir başlık ve 2 sütunlu kartlar. Saf mantık, sınanabilir. */
object MoreLayout {
    /** Bölüm kimliği -> o bölümdeki giriş adları (MoreEntry adlarıyla aynı). */
    val sections: List<Pair<String, List<String>>> = listOf(
        "TOOLS" to listOf("SCREEN_TIME", "DOCS"),
        "APP" to listOf("SETTINGS")
    )
    const val COLUMNS = 2

    fun rows(entries: List<String>): List<List<String>> = entries.chunked(COLUMNS)
    fun allEntries(): List<String> = sections.flatMap { it.second }
}
