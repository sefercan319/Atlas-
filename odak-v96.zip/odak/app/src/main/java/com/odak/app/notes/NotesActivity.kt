package com.odak.app.notes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.settings.DocsCard
import com.odak.app.theme.ClickSound
import com.odak.app.theme.ColorPrefs
import com.odak.app.theme.Design
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.ThemePrefs
import com.odak.app.theme.ThemedBackground
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedTabBar
import com.odak.app.theme.UiScale
import com.odak.app.theme.modeInvert
import com.odak.app.theme.typographyFor

/** Not defteri + belge okuyucu tek yerde: iki sekme (Notlar / Belgeler). */
class NotesActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ClickSound.init(applicationContext)
        ColorPrefs.init(applicationContext)
        UiScale.init(applicationContext)
        ClickSound.enabled = getSharedPreferences("odak_app", MODE_PRIVATE).getBoolean("sound", true)
        ClickSound.haptic = getSharedPreferences("odak_app", MODE_PRIVATE).getBoolean("haptic", true)
        val style = ThemePrefs.load(this)
        setContent {
            com.odak.app.theme.ProvideUiScale {
                CompositionLocalProvider(LocalDesign provides Design(style)) {
                    MaterialTheme(typography = typographyFor(style)) {
                        ThemedBackground(
                            Modifier.fillMaxSize().modeInvert(
                                com.odak.app.theme.ThemeMode.shouldInvert(style, com.odak.app.theme.ThemeMode.load(this@NotesActivity))
                            )
                        ) {
                            NotesHub()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NotesHub(embedded: Boolean = false, onEditorChange: (Boolean) -> Unit = {}) {
    var tab by rememberSaveable { mutableStateOf(0) }
    var inEditor by remember { mutableStateOf(false) }
    Column((if (embedded) Modifier.fillMaxSize() else Modifier.fillMaxSize().systemBarsPadding()).padding(horizontal = 12.dp)) {
        if (!inEditor) {
            ThemedTabBar(
                listOf(stringResource(R.string.notes_title), stringResource(R.string.notes_tab_docs)),
                tab, { tab = it }, bottom = false
            )
            Spacer(Modifier.height(8.dp))
        }
        if (tab == 0) NotesList(onEditorChange = { inEditor = it; onEditorChange(it) })
        else {
            ThemedCard(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.notes_hint), style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(8.dp))
            DocsCard()
        }
    }
}
