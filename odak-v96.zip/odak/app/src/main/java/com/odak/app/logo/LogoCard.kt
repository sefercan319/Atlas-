package com.odak.app.logo

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ThemedCard

object LogoSwitcher {
    fun apply(ctx: Context, n: Int) {
        val pm = ctx.packageManager
        val sel = LogoPure.clamp(n)
        // Önce seçileni aç, sonra diğerlerini kapat: her an en az bir başlatıcı girişi kalır.
        pm.setComponentEnabledSetting(ComponentName(ctx.packageName, LogoPure.aliasName(ctx.packageName, sel)), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        for (o in LogoPure.toDisable(sel)) pm.setComponentEnabledSetting(ComponentName(ctx.packageName, LogoPure.aliasName(ctx.packageName, o)), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
        ctx.getSharedPreferences("odak_app", Context.MODE_PRIVATE).edit().putInt("logo", sel).apply()
    }
}

@Composable
fun LogoCard() {
    val ctx = LocalContext.current
    var sel by remember { mutableIntStateOf(LogoPure.fromPref(ctx.getSharedPreferences("odak_app", Context.MODE_PRIVATE).getInt("logo", LogoPure.DEFAULT))) }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.logo_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LogoPure.all().chunked(5).forEach { rowItems ->
            Row(Modifier.padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                rowItems.forEach { n ->
                    val id = ctx.resources.getIdentifier(LogoPure.resName(n), "mipmap", ctx.packageName)
                    Image(
                        painterResource(id), LogoPure.code(n),
                        Modifier.size(52.dp).clip(RoundedCornerShape(12.dp))
                            .border(if (sel == n) 3.dp else 0.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                            .clickable { sel = n; LogoSwitcher.apply(ctx, n) }
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.logo_note), style = MaterialTheme.typography.bodySmall, modifier = Modifier.alpha(0.7f))
    }
}
