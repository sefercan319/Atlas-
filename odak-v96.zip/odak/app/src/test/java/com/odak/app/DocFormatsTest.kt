package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** v0.56.31: HTML ve EPUB okuma, ek metin tabanlı uzantılar. */
class DocFormatsTest {
    private fun zip(m: Map<String, String>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> for ((k, v) in m) { z.putNextEntry(ZipEntry(k)); z.write(v.toByteArray()); z.closeEntry() } }
        return bo.toByteArray()
    }
    private val container = "<container><rootfiles><rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles></container>"
    private fun xhtml(body: String) = "<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><title>t</title></head><body>$body</body></html>"

    @Test fun moreTextExtensionsAreText() {
        for (e in listOf("yaml", "yml", "toml", "cfg", "conf", "properties", "sql", "srt", "vtt", "ics", "vcf", "tex", "rst", "adoc", "gpx", "kml", "rss", "atom", "markdown"))
            assertEquals(e, DocKind.TEXT, DocParse.detect("x.$e", ByteArray(0)))
    }
    @Test fun htmlAndEpubKinds() {
        for (e in listOf("html", "htm", "xhtml")) assertEquals(e, DocKind.HTML, DocParse.detect("a.$e", ByteArray(0)))
        assertEquals(DocKind.EPUB, DocParse.detect("kitap.EPUB", byteArrayOf(0x50, 0x4B, 3, 4)))
    }
    @Test fun htmlDecodeNamedAndNumeric() {
        assertEquals("&<çş>", DocParse.htmlDecode("&amp;&lt;&#231;&#x15F;&gt;"))
        assertEquals("&bilinmeyen; &#99999999;", DocParse.htmlDecode("&bilinmeyen; &#99999999;"))
        assertEquals("“a”", DocParse.htmlDecode("&ldquo;a&rdquo;"))
    }
    @Test fun htmlParasStripsNoiseAndKeepsStructure() {
        val h = "<html><head><title>T</title><style>p{color:red}</style></head><body><h1>Başlık</h1><p>Bir&nbsp;iki</p><ul><li>A</li><li>B</li></ul><script>x()</script><!-- gizli --><div>Son<br>satır</div></body></html>"
        assertEquals(listOf("Başlık", "Bir iki", "• A", "• B", "Son", "satır"), DocParse.htmlParas(h))
    }
    @Test fun htmlTableCellsStayOnOneLine() {
        assertEquals(listOf("a b", "c d"), DocParse.htmlParas("<table><tr><td>a</td><td>b</td></tr><tr><td>c</td><td>d</td></tr></table>"))
    }
    @Test fun htmlParasEmptyAndPlain() {
        assertTrue(DocParse.htmlParas("").isEmpty())
        assertTrue(DocParse.htmlParas("<script>a()</script><style>b{}</style>").isEmpty())
        assertEquals(listOf("düz metin"), DocParse.htmlParas("düz metin"))
    }
    @Test fun parseHtmlFile() {
        val d = DocParse.parse("sayfa.html", "<p>Merhaba</p><p>Dünya</p>".toByteArray())
        assertEquals(DocKind.HTML, d.kind)
        assertEquals(listOf("Merhaba", "Dünya"), d.pages[0].paragraphs)
    }
    @Test fun parseHtmlWindows1254() {
        val d = DocParse.parse("eski.htm", "<p>Çığ şüphe</p>".toByteArray(charset("windows-1254")))
        assertEquals(listOf("Çığ şüphe"), d.pages[0].paragraphs)
    }
    @Test fun epubFollowsSpineOrderNotFileOrder() {
        val opf = "<package><manifest><item id=\"nav\" href=\"nav.xhtml\"/><item id=\"c1\" href=\"ch1.xhtml\"/><item id=\"c2\" href=\"ch2.xhtml\"/></manifest><spine><itemref idref=\"c2\"/><itemref idref=\"c1\"/></spine></package>"
        val z = zip(linkedMapOf(
            "mimetype" to "application/epub+zip", "META-INF/container.xml" to container, "OEBPS/content.opf" to opf,
            "OEBPS/ch1.xhtml" to xhtml("<p>Birinci</p>"), "OEBPS/ch2.xhtml" to xhtml("<p>İkinci</p>"), "OEBPS/nav.xhtml" to xhtml("<p>İçindekiler</p>")))
        val d = DocParse.parse("kitap.epub", z)
        assertEquals(DocKind.EPUB, d.kind)
        assertEquals(listOf("İkinci", "Birinci"), d.pages.map { it.paragraphs[0] })
        assertEquals(listOf("1", "2"), d.pages.map { it.title })
    }
    @Test fun epubPercentEncodedHrefAndEmptyChapterSkipped() {
        val opf = "<package><manifest><item id=\"a\" href=\"b%20c.xhtml\"/><item id=\"e\" href=\"bos.xhtml\"/></manifest><spine><itemref idref=\"e\"/><itemref idref=\"a\"/></spine></package>"
        val z = zip(linkedMapOf("META-INF/container.xml" to container, "OEBPS/content.opf" to opf,
            "OEBPS/b c.xhtml" to xhtml("<p>Boşluklu ad</p>"), "OEBPS/bos.xhtml" to xhtml("")))
        val d = DocParse.parse("k.epub", z)
        assertEquals(1, d.pages.size)
        assertEquals("Boşluklu ad", d.pages[0].paragraphs[0])
    }
    @Test fun epubWithoutOpfFallsBackToSortedXhtml() {
        val z = zip(linkedMapOf("mimetype" to "application/epub+zip", "b.xhtml" to xhtml("<p>iki</p>"), "a.xhtml" to xhtml("<p>bir</p>")))
        assertEquals(listOf("bir", "iki"), DocParse.parse("k.epub", z).pages.map { it.paragraphs[0] })
    }
    @Test fun epubDetectedByContentWhenNameIsZip() {
        val z = zip(linkedMapOf("mimetype" to "application/epub+zip", "a.xhtml" to xhtml("<p>x</p>")))
        assertEquals(DocKind.EPUB, DocParse.parse("kitap.zip", z).kind)
    }
    @Test fun brokenEpubDoesNotThrow() {
        val d = DocParse.parse("k.epub", zip(linkedMapOf("META-INF/container.xml" to "<rootfile full-path=\"yok.opf\"")))
        assertEquals(DocKind.EPUB, d.kind); assertTrue(d.pages.isEmpty())
    }
    @Test fun htmlAndEpubCanBeConverted() {
        assertTrue(DocConvert.targetsFor(DocKind.HTML, true).isNotEmpty())
        assertTrue(DocConvert.targetsFor(DocKind.EPUB, true).isNotEmpty())
        assertTrue(DocConvert.targetsFor(DocKind.EPUB, false).isEmpty())
    }
    @Test fun uiLabelsEpubChaptersAsPages() {
        assertTrue(File(TestFiles.code, "com/odak/app/docs/DocActivity.kt").readText().contains("DocKind.VSDX, DocKind.ODG, DocKind.EPUB ->"))
    }
    @Test fun zipReaderKeepsEpubEntries() {
        for (n in listOf("OEBPS/a.xhtml", "a.HTML", "x/b.htm", "content.opf", "word/document.xml", "mimetype", "_rels/.rels")) assertTrue(n, DocParse.wantedEntry(n))
        for (n in listOf("OEBPS/cover.jpg", "font.ttf", "style.css")) assertFalse(n, DocParse.wantedEntry(n))
    }
}
