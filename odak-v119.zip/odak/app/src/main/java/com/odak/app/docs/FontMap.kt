package com.odak.app.docs

/** Belge yazı tipi adı → Android sistem yazı tipi ailesi (Typeface.create adı). Saf mantık; telefonda yalnız bu aileler bulunur. */
object FontMap {
    val FAMILIES = listOf(
        "sans-serif", "sans-serif-light", "sans-serif-thin", "sans-serif-medium", "sans-serif-black", "sans-serif-condensed",
        "serif", "monospace", "serif-monospace", "cursive", "casual"
    )

    /** Pakete gömülü, ölçü uyumlu yazı tipi ailesi (Carlito, Caladea, Gelasio, Arimo, Tinos) ya da null. */
    fun asset(name: String?): String? {
        val f = (name ?: "").lowercase().trim()
        return when {
            f.startsWith("calibri") && !f.contains("light") || f.startsWith("carlito") -> "Carlito"
            f.startsWith("cambria") && !f.contains("math") || f.startsWith("caladea") -> "Caladea"
            f == "georgia" || f.startsWith("gelasio") -> "Gelasio"
            f == "arial" || f == "helvetica" || f == "helvetica neue" || f.startsWith("arimo") || f == "liberation sans" -> "Arimo"
            f == "times new roman" || f == "times" || f.startsWith("tinos") || f == "liberation serif" -> "Tinos"
            f == "courier new" || f == "courier" || f.startsWith("cousine") || f == "liberation mono" -> "Cousine"
            f.startsWith("comic sans") || f.startsWith("comic neue") -> "ComicNeue"
            f == "impact" || f.startsWith("anton") -> "Anton"
            f.endsWith("garamond") || f.startsWith("garamond") -> "EBGaramond"
            f == "segoe ui" || f == "verdana" || f == "tahoma" || f == "trebuchet ms" || f.startsWith("open sans") || f == "lucida sans" -> "OpenSans"
            f == "consolas" || f.startsWith("inconsolata") -> "Inconsolata"
            f.startsWith("palatino") || f == "book antiqua" || f.startsWith("bookman") || f == "century schoolbook" || f == "constantia" || f == "sylfaen" || f.startsWith("crimson") -> "CrimsonPro"
            f == "noto naskh arabic" || f.startsWith("notonaskh") -> "NotoNaskhArabic"
            f.startsWith("franklin gothic") || f.startsWith("libre franklin") -> "LibreFranklin"
            f == "century gothic" || f == "avant garde" || f == "itc avant garde gothic" || f == "futura" || f.startsWith("gill sans") || f.startsWith("questrial") -> "Questrial"
            f == "brush script mt" || f == "lucida handwriting" || f == "segoe script" || f == "monotype corsiva" || f == "freestyle script" || f == "edwardian script itc" || f.startsWith("dancing script") -> "DancingScript"
            else -> null
        }
    }

    /** Görüntüleyici HTML'i için (yalnız uygulama içi): belge yazı tipi adı → gömülü aile; adresler uygulama tarafından sunulur. */
    val HTML_FACES = listOf("Calibri" to "Carlito", "Cambria" to "Caladea", "Georgia" to "Gelasio", "Arial" to "Arimo", "Helvetica" to "Arimo", "Times New Roman" to "Tinos", "Times" to "Tinos",
        "Courier New" to "Cousine", "Courier" to "Cousine", "Comic Sans MS" to "ComicNeue", "Impact" to "Anton", "Garamond" to "EBGaramond", "Palatino Linotype" to "CrimsonPro", "Palatino" to "CrimsonPro", "Book Antiqua" to "CrimsonPro", "Bookman Old Style" to "CrimsonPro", "Constantia" to "CrimsonPro", "Franklin Gothic Medium" to "LibreFranklin", "Franklin Gothic Book" to "LibreFranklin", "Century Gothic" to "Questrial", "Gill Sans MT" to "Questrial", "Brush Script MT" to "DancingScript", "Lucida Handwriting" to "DancingScript", "Segoe Script" to "DancingScript", "Monotype Corsiva" to "DancingScript", "Segoe UI" to "OpenSans", "Verdana" to "OpenSans", "Tahoma" to "OpenSans", "Trebuchet MS" to "OpenSans", "Consolas" to "Inconsolata", "Arimo" to "Arimo", "Tinos" to "Tinos", "Noto Naskh Arabic" to "NotoNaskhArabic")
    const val HTML_BASE = "https://odak.local/"

    /** Uygulama atar: gömülü yazı tipi dosyasını (assets yolu) okur. Dışa aktarılan HTML'e yalnız kullanılan yüzler gömülür. */
    @Volatile var loader: ((String) -> ByteArray?)? = null

    /** Sayfalarda kullanılan (aile, kalın, eğik) kümesi; gömülü ailesi olanlar. */
    fun usedFaces(pages: List<RichPage>): Set<Triple<String, Boolean, Boolean>> {
        val out = LinkedHashSet<Triple<String, Boolean, Boolean>>()
        fun para(p: RPara, def: String?) { for (r in FontFallback.expand(p.runs, def)) if (r.img == null && r.text.isNotBlank()) asset(r.font ?: def)?.let { out.add(Triple(it, r.b, r.i)) } }
        fun walk(bl: List<RBlock>, def: String?) { for (b in bl) when (b) { is RPara -> para(b, def); is RTable -> b.rows.forEach { r -> r.forEach { c -> c.paras.forEach { para(it, def) } } }; is RBox -> walk(b.blocks, def) } }
        for (pg in pages) walk(pg.blocks, pg.defFont)
        return out
    }

    /** Kullanılan yüzler için data: URI'li @font-face (belge yazı tipi adı → gömülü aile). loader yoksa boş. */
    fun inlineFontCss(pages: List<RichPage>): String {
        val ld = loader ?: return ""
        val names = HashMap<String, MutableList<String>>()
        for ((n, fam) in HTML_FACES) names.getOrPut(fam) { ArrayList() }.add(n)
        val sb = StringBuilder(); val done = HashSet<String>()
        for ((fam, b, i) in usedFaces(pages)) {
            if (!hasStyle(fam, b, i)) { /* yüz yok: tarayıcı taklit eder; en yakın gerçek yüzü gömeriz */ }
            val file = assetFile(fam, b, i)
            val (rb, ri) = (file.endsWith("Bold.ttf") || file.endsWith("BoldItalic.ttf")) to file.endsWith("Italic.ttf")
            val key = "$fam|$rb|$ri"
            if (!done.add(key)) continue
            val data = try { ld(file) } catch (e: Exception) { null } ?: continue
            val b64 = java.util.Base64.getEncoder().encodeToString(data)
            for (n in names[fam] ?: emptyList())
                sb.append("@font-face{font-family:'").append(n).append("';font-weight:").append(if (rb) 700 else 400).append(";font-style:").append(if (ri) "italic" else "normal").append(";src:url(data:font/ttf;base64,").append(b64).append(")}")
        }
        return sb.toString()
    }

    fun fontFaceCss(): String {
        val sb = StringBuilder()
        for ((name, fam) in HTML_FACES) for ((b, i) in listOf(false to false, true to false, false to true, true to true)) if (hasStyle(fam, b, i))
            sb.append("@font-face{font-family:'").append(name).append("';font-weight:").append(if (b) 700 else 400).append(";font-style:").append(if (i) "italic" else "normal")
                .append(";src:url(").append(HTML_BASE).append(assetFile(fam, b, i)).append(")}")
        return sb.toString()
    }

    /** Sunulabilir yazı tipi yolu mu ("https://odak.local/fonts/Carlito-Bold.ttf" → assets yolu); değilse null. */
    fun servedAsset(url: String): String? {
        if (!url.startsWith(HTML_BASE)) return null
        val p = url.removePrefix(HTML_BASE)
        return p.takeIf { Regex("^fonts/(Carlito|Caladea|Gelasio|Arimo|Tinos|Cousine|ComicNeue|Anton|EBGaramond|OpenSans|Inconsolata|CrimsonPro|LibreFranklin|Questrial|DancingScript|NotoNaskhArabic)-(Regular|Bold|Italic|BoldItalic)\\.ttf$").matches(it) }
    }

    /** Aileye göre bulunan yüzler (R, B, I, BI); yazılmayan aile dört yüzü de içerir. */
    private val LIMITED = mapOf("Anton" to setOf("R"), "Inconsolata" to setOf("R", "B"), "Questrial" to setOf("R"), "DancingScript" to setOf("R", "B"), "NotoNaskhArabic" to setOf("R", "B"))
    private fun tag(b: Boolean, i: Boolean) = if (b && i) "BI" else if (b) "B" else if (i) "I" else "R"
    fun hasStyle(family: String, bold: Boolean, italic: Boolean): Boolean = LIMITED[family]?.contains(tag(bold, italic)) ?: true
    private fun hasBold(f: String) = LIMITED[f]?.any { it.contains('B') } ?: true
    private fun hasItalic(f: String) = LIMITED[f]?.any { it.contains('I') } ?: true

    /** Dosya adı; olmayan yüz yakın olana düşer (önce eğik, sonra kalın bırakılır). */
    fun assetFile(family: String, bold: Boolean, italic: Boolean): String {
        var b = bold && hasBold(family); var i = italic && hasItalic(family)
        if (!hasStyle(family, b, i)) { if (b && i) i = false; if (!hasStyle(family, b, i)) b = false }
        return "fonts/$family-" + (if (b && i) "BoldItalic" else if (b) "Bold" else if (i) "Italic" else "Regular") + ".ttf"
    }

    /** Dosyada karşılığı olmayan kalın/eğik için taklit gerekir: (sahte kalın, sahte eğik). */
    fun synth(family: String, bold: Boolean, italic: Boolean): Pair<Boolean, Boolean> {
        val f = assetFile(family, bold, italic)
        return (bold && !f.endsWith("Bold.ttf") && !f.endsWith("BoldItalic.ttf")) to (italic && !f.endsWith("Italic.ttf"))
    }

    private fun has(f: String, vararg k: String) = k.any { f.contains(it) }

    fun family(name: String?): String {
        val f = (name ?: "").lowercase().trim()
        return when {
            f.isEmpty() -> "sans-serif"
            has(f, "narrow", "condensed", "compressed", "cond") -> "sans-serif-condensed"
            has(f, "impact", "black", "heavy", "ultra", "haettenschweiler") -> "sans-serif-black"
            f.endsWith(" thin") || has(f, "hairline") -> "sans-serif-thin"
            has(f, " light", "segoe ui light", "calibri light") -> "sans-serif-light"
            has(f, "semibold", "demi", " medium") -> "sans-serif-medium"
            has(f, "courier", "typewriter", "american typewriter") -> "serif-monospace"
            has(f, "consolas", "mono", "menlo", "lucida console", "andale", "source code", "fira code", "cascadia", "letter gothic", "terminal", "monaco", "inconsolata", "code") -> "monospace"
            has(f, "script", "brush", "handwrit", "chancery", "corsiva", "kunstler", "edwardian", "vivaldi", "mistral", "bradley", "pacifico", "cursive", "zapf", "lucida calligraphy") -> "cursive"
            has(f, "comic", "chalk", "marker", "papyrus", "jokerman", "curlz", "kristen", "ink free", "casual") -> "casual"
            f.contains("sans") -> "sans-serif"
            has(f, "times", "serif", "georgia", "cambria", "garamond", "palatino", "book antiqua", "bookman", "century", "baskerville", "didot", "constantia", "minion", "caslon", "bodoni", "rockwell", "sylfaen", "cormorant", "playfair", "merriweather", "lora", "tinos", "liberation serif", "droid serif", "charter", "utopia") -> "serif"
            else -> "sans-serif"
        }
    }
}
