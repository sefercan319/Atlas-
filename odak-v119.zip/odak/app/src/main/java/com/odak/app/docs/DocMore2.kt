package com.odak.app.docs

/** v0.56.39: CSV/TSV, Markdown (zengin), vCard, iCalendar, MBOX. Saf Kotlin. */
object DocMore2 {
    private const val MAX_ROWS = 3000
    private const val MAX_COLS = 60
    private const val MAX_MSGS = 500

    // ================= CSV / TSV =================
    fun detectDelimiter(text: String): Char {
        val lines = text.lineSequence().filter { it.isNotBlank() }.take(8).toList()
        if (lines.isEmpty()) return ','
        var best = ','; var bestScore = -1
        for (d in charArrayOf(',', ';', '\t', '|')) {
            val counts = lines.map { l -> var q = false; var n = 0; for (c in l) { if (c == '"') q = !q else if (c == d && !q) n++ }; n }
            val c0 = counts[0]
            if (c0 == 0) continue
            val same = counts.count { it == c0 }
            val score = same * 1000 + c0
            if (score > bestScore) { bestScore = score; best = d }
        }
        return best
    }

    fun parseCsv(text: String, delim: Char = detectDelimiter(text)): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val f = StringBuilder()
        var inQ = false
        var i = 0
        val s = text.removePrefix("﻿")
        var any = false
        fun endField() { if (row.size < MAX_COLS) row.add(f.toString()); f.setLength(0) }
        fun endRow() { endField(); if (row.any { it.isNotEmpty() } || row.size > 1) rows.add(row); row = ArrayList() }
        while (i < s.length && rows.size < MAX_ROWS) {
            val c = s[i]
            if (inQ) {
                if (c == '"') { if (i + 1 < s.length && s[i + 1] == '"') { f.append('"'); i++ } else inQ = false } else f.append(c)
            } else when {
                c == '"' && f.isEmpty() -> inQ = true
                c == delim -> endField()
                c == '\r' -> { if (i + 1 < s.length && s[i + 1] == '\n') i++; endRow() }
                c == '\n' -> endRow()
                else -> f.append(c)
            }
            any = true
            i++
        }
        if (any && rows.size < MAX_ROWS && (f.isNotEmpty() || row.isNotEmpty())) endRow()
        return rows
    }

    fun csvDoc(text: String): Doc {
        val rows = parseCsv(text)
        if (rows.isEmpty()) return Doc(DocKind.CSV, emptyList())
        val w = rows.maxOf { it.size }
        return Doc(DocKind.CSV, listOf(DocPage("", emptyList(), rows.map { r -> r + List(w - r.size) { "" } })))
    }

    // ================= Markdown =================
    private val MD_HR = Regex("""^\s{0,3}([-*_])(\s*\1){2,}\s*$""")
    private val MD_H = Regex("""^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$""")
    private val MD_LI = Regex("""^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$""")
    private val MD_SEP = Regex("""^\s*\|?\s*:?-{1,}:?\s*(\|\s*:?-{1,}:?\s*)*\|?\s*$""")
    private val MD_FENCE = Regex("""^\s{0,3}(```|~~~)""")
    private const val CODE_FONT = "Courier New"

    fun mdInline(src: String, base: RRun = RRun("")): List<RRun> {
        val out = ArrayList<RRun>()
        val sb = StringBuilder()
        var b = base.b; var it = base.i; var st = base.s
        fun flush() { if (sb.isNotEmpty()) { out.add(RRun(sb.toString(), b, it, base.u, st, base.color, base.hl, base.sz, base.font)); sb.setLength(0) } }
        var i = 0
        while (i < src.length) {
            val c = src[i]
            val nx = if (i + 1 < src.length) src[i + 1] else ' '
            val pv = if (i > 0) src[i - 1] else ' '
            when {
                c == '\\' && i + 1 < src.length && nx in "\\`*_{}[]()#+-.!|~<>" -> { sb.append(nx); i += 2 }
                c == '`' -> {
                    val e = src.indexOf('`', i + 1)
                    if (e > i) { flush(); out.add(RRun(src.substring(i + 1, e), b, it, false, st, base.color, "F2F2F2", base.sz, CODE_FONT)); i = e + 1 } else { sb.append(c); i++ }
                }
                (c == '*' && nx == '*') || (c == '_' && nx == '_' && !pv.isLetterOrDigit()) -> { flush(); b = !b; i += 2 }
                c == '~' && nx == '~' -> { flush(); st = !st; i += 2 }
                c == '*' && !(pv == ' ' && nx == ' ') -> { flush(); it = !it; i++ }
                c == '_' && !pv.isLetterOrDigit() && nx != ' ' || c == '_' && it && !nx.isLetterOrDigit() -> { flush(); it = !it; i++ }
                c == '!' && nx == '[' -> {
                    val close = src.indexOf("](", i + 2)
                    val end = if (close > 0) src.indexOf(')', close) else -1
                    if (end > 0) {
                        val alt = src.substring(i + 2, close)
                        val url = src.substring(close + 2, end).trim().substringBefore(' ')
                        val im = HtmlRich.dataUri(url)?.let { HtmlRich.image(it, url) }
                        if (im != null) { flush(); out.add(RRun("", img = im)) } else sb.append('[').append(alt.ifEmpty { "image" }).append(']')
                        i = end + 1
                    } else { sb.append(c); i++ }
                }
                c == '[' -> {
                    val close = src.indexOf("](", i + 1)
                    val end = if (close > 0) src.indexOf(')', close) else -1
                    if (end > 0) {
                        flush()
                        val label = src.substring(i + 1, close)
                        val url = src.substring(close + 2, end).trim().substringBefore(' ')
                        for (r in mdInline(label, RRun("", b, it, true, st, "0563C1", base.hl, base.sz, base.font))) out.add(RRun(r.text, r.b, r.i, true, r.s, "0563C1", r.hl, r.sz, r.font, 0, url))
                        i = end + 1
                    } else { sb.append(c); i++ }
                }
                c == '<' && src.startsWith("<br", i) -> { val e = src.indexOf('>', i); if (e > 0) { sb.append('\n'); i = e + 1 } else { sb.append(c); i++ } }
                else -> { sb.append(c); i++ }
            }
        }
        flush()
        return out
    }

    private fun mdSize(level: Int) = when (level) { 1 -> 40; 2 -> 34; 3 -> 30; 4 -> 26; else -> 24 }

    private fun splitRow(l: String): List<String> {
        var t = l.trim()
        if (t.startsWith("|")) t = t.substring(1)
        if (t.endsWith("|") && !t.endsWith("\\|")) t = t.dropLast(1)
        return t.split(Regex("(?<!\\\\)\\|")).map { it.trim().replace("\\|", "|") }
    }

    fun mdRich(text: String): RichPage {
        val lines = text.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val blocks = ArrayList<RBlock>()
        val para = ArrayList<String>()
        val counters = IntArray(10)
        fun flushPara() {
            if (para.isEmpty()) return
            val joined = StringBuilder()
            para.forEachIndexed { k, l ->
                joined.append(l.trimEnd())
                if (k < para.size - 1) joined.append(if (l.endsWith("  ")) "\n" else " ")
            }
            blocks.add(RPara(mdInline(joined.toString().trim()), after = 160))
            para.clear()
        }
        var i = 0
        while (i < lines.size && blocks.size < 20000) {
            val l = lines[i]
            val fence = MD_FENCE.find(l)
            if (fence != null) {
                flushPara()
                val mark = fence.groupValues[1]
                i++
                while (i < lines.size && !lines[i].trimStart().startsWith(mark)) {
                    blocks.add(RPara(listOf(RRun(lines[i].ifEmpty { " " }, font = CODE_FONT, sz = 20)), left = 120, before = 0, after = 0, fill = "F2F2F2"))
                    i++
                }
                i++
                blocks.add(RPara(emptyList(), after = 120))
                continue
            }
            if (l.isBlank()) { flushPara(); i++; continue }
            val h = MD_H.find(l)
            if (h != null) {
                flushPara()
                val n = h.groupValues[1].length
                val runs = mdInline(h.groupValues[2], RRun("", b = true, sz = mdSize(n)))
                blocks.add(RPara(runs, head = n, before = if (n <= 2) 240 else 160, after = 120, bottom = if (n <= 2) Bd(4, "D0D7DE") else null))
                i++; continue
            }
            if (MD_HR.matches(l)) { flushPara(); blocks.add(RPara(emptyList(), after = 120, bottom = Bd(8, "808080"))); i++; continue }
            if (i + 1 < lines.size && para.isEmpty() && !MD_LI.matches(l) && !l.trimStart().startsWith(">") && !l.contains('|')) {
                val nx = lines[i + 1].trim()
                if (nx.length >= 2 && nx.all { it == '=' } || nx.length >= 2 && nx.all { it == '-' }) {
                    val n = if (nx[0] == '=') 1 else 2
                    blocks.add(RPara(mdInline(l.trim(), RRun("", b = true, sz = mdSize(n))), head = n, before = 240, after = 120, bottom = Bd(4, "D0D7DE")))
                    i += 2; continue
                }
            }
            if (l.contains('|') && i + 1 < lines.size && MD_SEP.matches(lines[i + 1]) && lines[i + 1].contains('-')) {
                flushPara()
                val head = splitRow(l)
                val rows = ArrayList<List<RCell>>()
                val bd = Bd(4, "999999")
                fun cellOf(t: String, header: Boolean) = RCell(listOf(RPara(mdInline(t, RRun("", b = header)), after = 0, before = 0)), fill = if (header) "EEEEEE" else null, bt = bd, bl = bd, bb = bd, br = bd)
                rows.add(head.map { cellOf(it, true) })
                i += 2
                while (i < lines.size && lines[i].isNotBlank() && lines[i].contains('|') && rows.size < 3000) {
                    val r = splitRow(lines[i]).take(60)
                    rows.add((0 until head.size).map { k -> cellOf(r.getOrElse(k) { "" }, false) })
                    i++
                }
                blocks.add(RTable(rows, emptyList()))
                blocks.add(RPara(emptyList(), after = 120))
                continue
            }
            if (l.trimStart().startsWith(">")) {
                flushPara()
                val q = StringBuilder()
                while (i < lines.size && lines[i].trimStart().startsWith(">")) { if (q.isNotEmpty()) q.append(' '); q.append(lines[i].trimStart().removePrefix(">").trim()); i++ }
                blocks.add(RPara(mdInline(q.toString(), RRun("", i = true, color = "595959")), left = 360, after = 160, fill = "F6F8FA"))
                continue
            }
            val li = MD_LI.find(l)
            if (li != null) {
                flushPara()
                val level = (li.groupValues[1].replace("\t", "    ").length / 2).coerceIn(0, 6)
                val bullet = li.groupValues[2][0] in "-*+"
                var body = li.groupValues[3]
                var marker: String
                if (bullet) {
                    marker = if (level % 2 == 0) "•" else "◦"
                    if (body.startsWith("[ ] ")) { marker = "☐"; body = body.substring(4) } else if (body.startsWith("[x] ", true)) { marker = "☑"; body = body.substring(4) }
                    counters.fill(0, level + 1, 10)
                } else {
                    counters[level]++
                    for (k in level + 1 until 10) counters[k] = 0
                    marker = counters[level].toString() + "."
                }
                blocks.add(RPara(mdInline(body), marker = marker, left = 360 * (level + 1), first = -360, after = 60))
                i++; continue
            }
            para.add(l)
            i++
        }
        flushPara()
        return RichPage(blocks, PageSetup(), 22, "Calibri", 0, 276)
    }

    fun markdownDoc(text: String): Doc {
        val rp = mdRich(text)
        if (rp.blocks.isEmpty()) return Doc(DocKind.MARKDOWN, emptyList())
        return Doc(DocKind.MARKDOWN, listOf(DocPage("", Rich.plain(rp), null, null, rp)))
    }

    // ================= vCard / iCalendar (RFC 6350 / 5545 satır biçimi) =================
    private class Prop(val name: String, val params: String, val value: String)

    private fun unfold(text: String): List<String> {
        val out = ArrayList<String>()
        for (l in text.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n').split('\n')) {
            if ((l.startsWith(" ") || l.startsWith("\t")) && out.isNotEmpty()) out[out.size - 1] = out.last() + l.substring(1)
            else out.add(l)
        }
        return out
    }

    private fun unesc(s: String) = s.replace("\\n", "\n").replace("\\N", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")

    private fun prop(line: String): Prop? {
        val colon = line.indexOf(':')
        if (colon <= 0) return null
        val head = line.substring(0, colon)
        val name = head.substringBefore(';').substringAfterLast('.').uppercase()
        val params = head.substringAfter(';', "")
        var v = line.substring(colon + 1)
        if (params.uppercase().contains("QUOTED-PRINTABLE")) v = String(DocMore.qpDecode(v, soft = false), Charsets.UTF_8)
        return Prop(name, params.uppercase(), v)
    }

    fun vcardDoc(text: String): Doc {
        val rows = ArrayList<List<String>>()
        rows.add(listOf("Name", "Organization", "Phone", "Email", "Address", "Note"))
        var cur: ArrayList<Prop>? = null
        for (l in unfold(text)) {
            val u = l.trim().uppercase()
            if (u == "BEGIN:VCARD") { cur = ArrayList(); continue }
            if (u == "END:VCARD") {
                val c = cur ?: continue
                cur = null
                if (rows.size > MAX_ROWS) continue
                fun all(n: String) = c.filter { it.name == n }
                val n = all("N").firstOrNull()?.value?.split(';')?.map { unesc(it).trim() } ?: emptyList()
                val fn = all("FN").firstOrNull()?.value?.let { unesc(it).trim() }?.ifEmpty { null }
                    ?: listOf(n.getOrNull(3), n.getOrNull(1), n.getOrNull(2), n.getOrNull(0), n.getOrNull(4)).filter { !it.isNullOrEmpty() }.joinToString(" ")
                val org = listOf(all("ORG").firstOrNull()?.value?.split(';')?.joinToString(", ") { unesc(it) }?.trim(','), all("TITLE").firstOrNull()?.value?.let { unesc(it) })
                    .filter { !it.isNullOrBlank() }.joinToString(" — ")
                fun typed(p: Prop): String {
                    val t = Regex("TYPE=([A-Z,]+)").find(p.params)?.groupValues?.get(1)?.lowercase()?.replace(",", "/")
                        ?: p.params.split(';').firstOrNull { it in listOf("HOME", "WORK", "CELL", "VOICE", "FAX") }?.lowercase()
                    return unesc(p.value).trim() + if (t.isNullOrEmpty() || t == "voice") "" else " ($t)"
                }
                val tel = all("TEL").joinToString("\n") { typed(it) }
                val mail = all("EMAIL").joinToString("\n") { typed(it) }
                val adr = all("ADR").joinToString("\n") { p -> p.value.split(';').drop(2).map { unesc(it).trim() }.filter { it.isNotEmpty() }.joinToString(", ") }
                val note = all("NOTE").joinToString(" ") { unesc(it.value) }.trim()
                if (fn.isNotEmpty() || tel.isNotEmpty() || mail.isNotEmpty()) rows.add(listOf(fn, org, tel, mail, adr, note))
                continue
            }
            cur?.let { c -> prop(l)?.let { c.add(it) } }
        }
        if (rows.size == 1) return Doc(DocKind.VCARD, emptyList())
        return Doc(DocKind.VCARD, listOf(DocPage("", listOf("${rows.size - 1} contacts"), rows)))
    }

    /** 20261025T093000Z / 20261025 → "2026-10-25 09:30" (Z ise " UTC"). */
    fun icalDate(v: String): String {
        val m = Regex("""^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?(Z)?)?$""").find(v.trim()) ?: return v
        val g = m.groupValues
        return "${g[1]}-${g[2]}-${g[3]}" + if (g[4].isNotEmpty()) " ${g[4]}:${g[5]}" + (if (g[7].isNotEmpty()) " UTC" else "") else ""
    }

    fun icalDoc(text: String): Doc {
        val rows = ArrayList<List<String>>()
        var cur: ArrayList<Prop>? = null
        var kind = ""
        for (l in unfold(text)) {
            val u = l.trim().uppercase()
            if (u == "BEGIN:VEVENT" || u == "BEGIN:VTODO" || u == "BEGIN:VJOURNAL") { cur = ArrayList(); kind = u.substringAfter("BEGIN:V").lowercase(); continue }
            if (u == "END:VEVENT" || u == "END:VTODO" || u == "END:VJOURNAL") {
                val c = cur ?: continue
                cur = null
                if (rows.size >= MAX_ROWS) continue
                fun f(n: String) = c.firstOrNull { it.name == n }?.value?.let { unesc(it).trim() } ?: ""
                val start = f("DTSTART").ifEmpty { f("DUE") }
                val type = when (kind) { "todo" -> "Task"; "journal" -> "Note"; else -> "Event" }
                rows.add(listOf(type, f("SUMMARY"), icalDate(start), icalDate(f("DTEND")), f("LOCATION"), f("DESCRIPTION"), f("RRULE").replace("FREQ=", "").replace(";", " ")))
                continue
            }
            cur?.let { c -> prop(l)?.let { c.add(it) } }
        }
        if (rows.isEmpty()) return Doc(DocKind.ICAL, emptyList())
        val sorted = rows.sortedBy { it[2].ifEmpty { "9999" } }
        val table = listOf(listOf("Type", "Title", "Start", "End", "Location", "Description", "Repeat")) + sorted
        return Doc(DocKind.ICAL, listOf(DocPage("", listOf("${rows.size} items"), table)))
    }

    // ================= MBOX =================
    fun mboxDoc(bytes: ByteArray): Doc {
        val msgs = ArrayList<ByteArray>()
        var start = -1
        var pos = 0
        val n = bytes.size
        fun isFrom(at: Int) = at + 5 <= n && bytes[at] == 'F'.code.toByte() && bytes[at + 1] == 'r'.code.toByte() && bytes[at + 2] == 'o'.code.toByte() && bytes[at + 3] == 'm'.code.toByte() && bytes[at + 4] == ' '.code.toByte()
        var lineStart = 0
        while (lineStart <= n && msgs.size < MAX_MSGS) {
            val atFirst = lineStart == 0
            val prevBlank = atFirst || (lineStart >= 1 && bytes[lineStart - 1] == '\n'.code.toByte() && (lineStart < 2 || bytes[lineStart - 2] == '\n'.code.toByte() || (bytes[lineStart - 2] == '\r'.code.toByte())))
            if (isFrom(lineStart) && prevBlank) {
                if (start >= 0) msgs.add(bytes.copyOfRange(start, lineStart))
                var e = lineStart
                while (e < n && bytes[e] != '\n'.code.toByte()) e++
                start = minOf(e + 1, n)
            }
            var e = lineStart
            while (e < n && bytes[e] != '\n'.code.toByte()) e++
            lineStart = e + 1
            if (e >= n) break
        }
        if (start >= 0 && msgs.size < MAX_MSGS) msgs.add(bytes.copyOfRange(start, n))
        val pages = ArrayList<DocPage>()
        msgs.forEachIndexed { k, m ->
            val d = try { DocMore.emlDoc(m) } catch (e: Exception) { null } ?: return@forEachIndexed
            val p = d.pages.firstOrNull() ?: return@forEachIndexed
            val subj = p.paragraphs.firstOrNull { it.startsWith("Subject:") }?.removePrefix("Subject:")?.trim().orEmpty()
            pages.add(DocPage("${k + 1}. ${subj.ifEmpty { "(no subject)" }}".take(80), p.paragraphs))
        }
        return Doc(DocKind.MBOX, pages)
    }
}
