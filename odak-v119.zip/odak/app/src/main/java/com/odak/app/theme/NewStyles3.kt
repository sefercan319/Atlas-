package com.odak.app.theme

import android.graphics.Paint as APaint
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.random.Random

/*
 * Cosmic Dark / Sci-Fi HUD / Cyber-Industrial / Neoclassical için çizim araçları.
 *  Cosmic: yıldız alanı + nebula + yörünge halkaları, "warp" dalgaları.
 *  HUD: köşe parantezleri, ızgara, tarama çizgisi, kilitlenme (lock-on) animasyonu.
 *  Cyber-Industrial: çelik plaka, perçin, uyarı şeridi, panjur süpürmesi.
 *  Neoclassical: mermer, çift çizgili çerçeve, köşe süsleri, Yunan anahtarı bandı, altın para.
 */

// ---------------------------------------------------------------- Cosmic
val CosmicLavender = Color(0xFFB4A7FF)
val CosmicGold = Color(0xFFFFC857)
val CosmicVoid = Color(0xFF05020F)

/** Cosmic zemini: yıldız alanı (göz kırpar, yavaş kayar), bulanık nebula bulutları, okunabilirlik örtüsü. */
@Composable
fun CosmicBackdrop(modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "cosmic")
    val ph by tr.animateFloat(
        0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Reverse), label = "twinkle"
    )
    val drift by tr.animateFloat(
        0f, 1f, infiniteRepeatable(tween(60000, easing = LinearEasing), RepeatMode.Restart), label = "drift"
    )
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(CosmicVoid, Color(0xFF0B0620), Color(0xFF14083A))))) {
        Box(
            Modifier.fillMaxSize().blur(70.dp).drawBehind {
                val w = size.width
                val h = size.height
                val r = minOf(w, h) * 0.5f
                // Renkler metin kontrastı için bilinçli koyu tutuldu; bkz. NewStyles3Test.
                drawCircle(Color(0xFF3B1E8F), r, Offset(w * (0.2f + 0.1f * ph), h * 0.2f), alpha = 0.75f)
                drawCircle(Color(0xFF7A1B73), r * 0.9f, Offset(w * 0.85f, h * (0.55f - 0.08f * ph)), alpha = 0.7f)
                drawCircle(Color(0xFF123F7A), r * 0.8f, Offset(w * 0.3f, h * 0.9f), alpha = 0.7f)
            }
        )
        Canvas(Modifier.fillMaxSize()) {
            val rnd = Random(21)
            val n = 90
            repeat(n) { i ->
                val x = rnd.nextFloat() * size.width
                val y = ((rnd.nextFloat() + drift * (0.2f + (i % 3) * 0.15f)) % 1f) * size.height
                val base = 0.5f + rnd.nextFloat() * 1.6f
                val tw = if (i % 2 == 0) ph else 1f - ph
                drawCircle(Color.White.copy(alpha = (0.25f + 0.75f * tw) * (if (i % 7 == 0) 1f else 0.6f)), base.dp.toPx() * 0.6f, Offset(x, y))
            }
        }
        Box(Modifier.fillMaxSize().background(Color(0x4D05020F)))
    }
}

/** Cosmic paneli: derin mor yarı saydam dolgu, yıldız ışığı kenar, köşede yörünge yayı. */
fun Modifier.cosmicPanel(shape: Shape, glow: Float = 0.3f): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection)
    drawIntoCanvas { c ->
        val nc = c.nativeCanvas
        nc.save()
        nc.clipOutPath(path.asAndroidPath())
        val p = APaint(APaint.ANTI_ALIAS_FLAG)
        p.color = android.graphics.Color.BLACK
        p.setShadowLayer(16.dp.toPx(), 0f, 4.dp.toPx(), CosmicLavender.copy(alpha = 0.28f * glow.coerceIn(0f, 1f)).toArgb())
        nc.drawPath(path.asAndroidPath(), p)
        nc.restore()
    }
    drawPath(path, Brush.verticalGradient(listOf(Color(0xE61A0E40), Color(0xE60F0829))))
    clipPath(path) {
        // yörünge yayı
        val r = minOf(size.width, size.height) * 0.9f
        drawCircle(CosmicLavender.copy(alpha = 0.10f), r, Offset(size.width, 0f), style = Stroke(1.dp.toPx()))
        drawCircle(CosmicLavender.copy(alpha = 0.06f), r * 0.7f, Offset(size.width, 0f), style = Stroke(1.dp.toPx()))
        drawCircle(CosmicGold.copy(alpha = 0.7f), 2.dp.toPx(), Offset(size.width - r * 0.7f * 0.707f, r * 0.7f * 0.707f))
    }
    drawPath(
        path,
        Brush.linearGradient(
            listOf(CosmicLavender.copy(alpha = 0.7f), Color(0xFF7A5CFF).copy(alpha = 0.3f), CosmicGold.copy(alpha = 0.35f)),
            start = Offset.Zero, end = Offset(size.width, size.height)
        ),
        style = Stroke(1.dp.toPx())
    )
}

/** Cosmic düğmesi: indigo→macenta degrade, parıltı; warp 0..1 parıltıyı büyütür. */
fun Modifier.cosmicButton(shape: Shape, warp: Float = 0f): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection)
    val w = warp.coerceIn(0f, 1f)
    drawIntoCanvas { c ->
        val nc = c.nativeCanvas
        val p = APaint(APaint.ANTI_ALIAS_FLAG)
        p.color = CosmicLavender.toArgb()
        p.setShadowLayer((10f + 14f * (1f - w)).dp.toPx(), 0f, 0f, Color(0xFF7A5CFF).copy(alpha = 0.6f).toArgb())
        nc.drawPath(path.asAndroidPath(), p)
    }
    drawPath(path, Brush.horizontalGradient(listOf(CosmicLavender, Color(0xFFE0A8FF), Color(0xFF9AB4FF))))
    drawPath(path, Color.White.copy(alpha = 0.5f), style = Stroke(1.dp.toPx()))
}

/** Dokunma noktasından genişleyen iki "warp" halkası. g: 0..1. */
fun DrawScope.warpRings(center: Offset, g: Float, color: Color) {
    val maxR = maxOf(size.width, size.height) * 1.1f
    for (k in 0..1) {
        val gg = (g - k * 0.18f).coerceIn(0f, 1f)
        if (gg <= 0f) continue
        drawCircle(color.copy(alpha = (1f - gg) * 0.8f), maxR * gg, center, style = Stroke((2.5f - k).dp.toPx()))
    }
}

/** Gezegen onay işareti: işaretliyken halkalı gezegen. */
fun Modifier.cosmicPlanet(checked: Boolean): Modifier = this.drawBehind {
    val c = Offset(size.width / 2f, size.height / 2f)
    val r = size.minDimension * 0.34f
    if (!checked) {
        drawCircle(CosmicLavender.copy(alpha = 0.8f), size.minDimension * 0.46f, c, style = Stroke(1.5.dp.toPx()))
        drawCircle(CosmicLavender.copy(alpha = 0.35f), 1.5.dp.toPx(), Offset(c.x + size.minDimension * 0.46f * 0.707f, c.y - size.minDimension * 0.46f * 0.707f))
    } else {
        drawCircle(Brush.radialGradient(listOf(Color(0xFFFFE08A), CosmicGold, Color(0xFFB07A10)), center = Offset(c.x - r * 0.3f, c.y - r * 0.3f), radius = r * 1.6f), r, c)
        rotate(-20f, c) {
            drawOval(CosmicLavender.copy(alpha = 0.9f), Offset(c.x - r * 1.5f, c.y - r * 0.38f), Size(r * 3f, r * 0.76f), style = Stroke(1.6.dp.toPx()))
        }
    }
}

// ---------------------------------------------------------------- HUD
val HudAmber = Color(0xFFFFB020)
val HudCyan = Color(0xFF4DD8FF)

/** Dört köşede L şeklinde parantez. inset kadar içeriden başlar. */
fun DrawScope.hudBrackets(color: Color, len: Float, stroke: Float, inset: Float = 0f) {
    val w = size.width
    val h = size.height
    val l = minOf(len, w / 2f, h / 2f)
    val i = inset
    fun seg(a: Offset, b: Offset) = drawLine(color, a, b, stroke)
    seg(Offset(i, i + l), Offset(i, i)); seg(Offset(i, i), Offset(i + l, i))
    seg(Offset(w - i - l, i), Offset(w - i, i)); seg(Offset(w - i, i), Offset(w - i, i + l))
    seg(Offset(i, h - i - l), Offset(i, h - i)); seg(Offset(i, h - i), Offset(i + l, h - i))
    seg(Offset(w - i - l, h - i), Offset(w - i, h - i)); seg(Offset(w - i, h - i), Offset(w - i, h - i - l))
}

/** HUD paneli: koyu yarı saydam dolgu, ince çerçeve, köşe parantezleri, silik teknik ızgara. */
fun Modifier.hudPanel(color: Color = HudAmber, lit: Float = 0f, grid: Boolean = true): Modifier = this.drawBehind {
    drawRect(Color(0xB30A1822))
    if (grid) {
        val step = 14.dp.toPx()
        var x = step
        while (x < size.width) { drawLine(HudCyan.copy(alpha = 0.04f), Offset(x, 0f), Offset(x, size.height), 1f); x += step }
        var y = step
        while (y < size.height) { drawLine(HudCyan.copy(alpha = 0.04f), Offset(0f, y), Offset(size.width, y), 1f); y += step }
    }
    drawRect(color.copy(alpha = 0.18f + 0.3f * lit), style = Stroke(1.dp.toPx()))
    hudBrackets(color, 12.dp.toPx(), (1.5f + lit).dp.toPx())
}

/** HUD zemini: koyu mavi-siyah, ızgara, yavaş inen tarama çizgisi. */
@Composable
fun HudBackdrop(modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "hud")
    val scan by tr.animateFloat(
        0f, 1f, infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart), label = "scan"
    )
    Canvas(modifier.fillMaxSize().background(Color(0xFF04090F))) {
        val step = 28.dp.toPx()
        var x = 0f
        while (x < size.width) { drawLine(HudCyan.copy(alpha = 0.05f), Offset(x, 0f), Offset(x, size.height), 1f); x += step }
        var y = 0f
        while (y < size.height) { drawLine(HudCyan.copy(alpha = 0.05f), Offset(0f, y), Offset(size.width, y), 1f); y += step }
        drawRect(
            Brush.radialGradient(listOf(Color.Transparent, Color(0xCC000000)), center = Offset(size.width / 2f, size.height / 2f), radius = maxOf(size.width, size.height) * 0.8f)
        )
        val sy = size.height * scan
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, HudAmber.copy(alpha = 0.10f), Color.Transparent), startY = sy - 40.dp.toPx(), endY = sy + 40.dp.toPx()),
            topLeft = Offset(0f, sy - 40.dp.toPx()), size = Size(size.width, 80.dp.toPx())
        )
    }
}

/** Kilitlenme: dışarıdan içeri kapanan parantezler + sonunda kısa parlama. g: 0..1. */
fun DrawScope.hudLockOn(color: Color, g: Float) {
    val off = (1f - g) * 16.dp.toPx()
    hudBrackets(color.copy(alpha = (0.3f + 0.7f * g).coerceIn(0f, 1f)), 10.dp.toPx(), 2.dp.toPx(), inset = -off)
    if (g > 0.7f) drawRect(color.copy(alpha = 0.22f * (1f - g) / 0.3f))
}

// ---------------------------------------------------------------- Cyber-Industrial
val SteelDark = Color(0xFF16181B)
val SteelPlate = Color(0xFF23272C)
val HazardYellow = Color(0xFFFFC400)

private fun DrawScope.rivet(c: Offset, r: Float) {
    drawCircle(Color(0xFF0C0D0F), r + 1f, Offset(c.x + 0.8f, c.y + 1f))
    drawCircle(Brush.radialGradient(listOf(Color(0xFF9AA0A8), Color(0xFF454A52)), center = Offset(c.x - r * 0.3f, c.y - r * 0.3f), radius = r * 1.4f), r, c)
}

/** Çelik plaka: gri degrade, taneli doku, köşe perçinleri, pah kenarı. */
fun Modifier.steelPlate(
    shape: Shape,
    base: Color = SteelPlate,
    pressed: Float = 0f,
    rivets: Boolean = true
): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection)
    val p = pressed.coerceIn(0f, 1f)
    drawPath(path, Brush.verticalGradient(listOf(lerp(base, Color.White, 0.10f - 0.08f * p), lerp(base, Color.Black, 0.18f))))
    clipPath(path) {
        val rnd = Random(5)
        val n = (size.width * size.height / (9.dp.toPx() * 9.dp.toPx()) * 4f).toInt().coerceIn(10, 700)
        repeat(n) {
            drawCircle(
                if (rnd.nextBoolean()) Color(0x14000000) else Color(0x0DFFFFFF),
                0.7.dp.toPx(), Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height)
            )
        }
        if (p > 0f) drawRect(Color.Black.copy(alpha = 0.3f * p), size = Size(size.width, 6.dp.toPx()))
    }
    drawPath(path, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.22f * (1f - p)), Color.Black.copy(alpha = 0.55f))), style = Stroke(1.2.dp.toPx()))
    if (rivets && size.width > 40.dp.toPx() && size.height > 30.dp.toPx()) {
        val m = 6.dp.toPx()
        val r = 2.dp.toPx()
        rivet(Offset(m, m), r); rivet(Offset(size.width - m, m), r)
        rivet(Offset(m, size.height - m), r); rivet(Offset(size.width - m, size.height - m), r)
    }
}

/** Uyarı şeridi: sarı-siyah çapraz bant. */
fun DrawScope.hazardStripes(topLeft: Offset, area: Size, stripe: Float, shift: Float = 0f) {
    clipPath(Path().apply { addRect(androidx.compose.ui.geometry.Rect(topLeft, area)) }) {
        drawRect(Color(0xFF111111), topLeft, area)
        var x = topLeft.x - area.height - shift % (stripe * 2f)
        while (x < topLeft.x + area.width + area.height) {
            val p = Path()
            p.moveTo(x, topLeft.y + area.height)
            p.lineTo(x + stripe, topLeft.y + area.height)
            p.lineTo(x + stripe + area.height, topLeft.y)
            p.lineTo(x + area.height, topLeft.y)
            p.close()
            drawPath(p, HazardYellow)
            x += stripe * 2f
        }
    }
}

/** Sarı iş plakası (düğme): sarı gövde, siyah alt şerit, perçinler. */
fun Modifier.yellowPlate(shape: Shape, pressed: Float = 0f): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection)
    val p = pressed.coerceIn(0f, 1f)
    drawPath(path, Brush.verticalGradient(listOf(lerp(HazardYellow, Color.White, 0.25f * (1f - p)), HazardYellow, lerp(HazardYellow, Color.Black, 0.25f))))
    clipPath(path) {
        hazardStripes(Offset(0f, size.height - 5.dp.toPx()), Size(size.width, 5.dp.toPx()), 6.dp.toPx())
        if (p > 0f) drawRect(Color.Black.copy(alpha = 0.25f * p), size = Size(size.width, 5.dp.toPx()))
    }
    drawPath(path, Color(0xFF111111), style = Stroke(1.5.dp.toPx()))
    rivet(Offset(6.dp.toPx(), size.height / 2f), 1.8.dp.toPx())
    rivet(Offset(size.width - 6.dp.toPx(), size.height / 2f), 1.8.dp.toPx())
}

/** Cyber-Industrial zemini: isli çelik, çapraz silik hatlar, alt-üst uyarı şeritleri. */
@Composable
fun CyberBackdrop(modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "cyber")
    val sh by tr.animateFloat(
        0f, 40f, infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart), label = "belt"
    )
    Canvas(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1B1E22), SteelDark)))) {
        val step = 22.dp.toPx()
        var x = -size.height
        while (x < size.width) {
            drawLine(Color(0x0DFFFFFF), Offset(x, size.height), Offset(x + size.height, 0f), 1f)
            x += step
        }
        val rnd = Random(9)
        repeat(160) { drawCircle(Color(0x10000000), 0.9.dp.toPx(), Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height)) }
        hazardStripes(Offset(0f, 0f), Size(size.width, 6.dp.toPx()), 8.dp.toPx(), sh)
        hazardStripes(Offset(0f, size.height - 6.dp.toPx()), Size(size.width, 6.dp.toPx()), 8.dp.toPx(), -sh)
    }
}

// ---------------------------------------------------------------- Neoclassical
val NeoGold = Color(0xFFC9A24B)
val NeoIvory = Color(0xFFF3EEE3)
val NeoInk = Color(0xFF1F1B16)

/** Mermer zemin: fildişi + ince gri damarlar. */
fun Modifier.neoMarble(): Modifier = this
    .background(Brush.verticalGradient(listOf(Color(0xFFF7F3EA), NeoIvory, Color(0xFFEBE5D6))))
    .drawBehind {
        val rnd = Random(13)
        repeat(7) {
            val p = Path()
            val x0 = rnd.nextFloat() * size.width
            p.moveTo(x0, 0f)
            var y = 0f
            var x = x0
            while (y < size.height) {
                val ny = y + size.height / 5f
                val nx = x + (rnd.nextFloat() - 0.4f) * size.width * 0.35f
                p.quadraticBezierTo((x + nx) / 2f + (rnd.nextFloat() - 0.5f) * 60f, (y + ny) / 2f, nx, ny)
                x = nx; y = ny
            }
            drawPath(p, Color(0x14796B55), style = Stroke((0.5f + rnd.nextFloat()).dp.toPx()))
        }
    }

/** Çift çizgili çerçeve: dış ince çizgi + 4dp içeride ikinci çizgi + köşe eşkenar süsleri. */
fun Modifier.neoFrame(color: Color = NeoGold, orn: Boolean = true, fill: Color? = null): Modifier = this.drawBehind {
    if (fill != null) drawRect(fill)
    drawRect(color, style = Stroke(1.dp.toPx()))
    val i = 4.dp.toPx()
    drawRect(color.copy(alpha = 0.55f), Offset(i, i), Size(size.width - 2 * i, size.height - 2 * i), style = Stroke(0.7.dp.toPx()))
    if (orn) {
        val r = 3.dp.toPx()
        listOf(Offset(0f, 0f), Offset(size.width, 0f), Offset(0f, size.height), Offset(size.width, size.height)).forEach { c ->
            val d = Path()
            d.moveTo(c.x, c.y - r); d.lineTo(c.x + r, c.y); d.lineTo(c.x, c.y + r); d.lineTo(c.x - r, c.y); d.close()
            drawPath(d, color)
        }
    }
}

/** Yunan anahtarı (meander) bandı: tekrar eden basamaklı kanca deseni. */
fun DrawScope.greekKey(color: Color, topLeft: Offset, width: Float, height: Float) {
    val u = height / 4f
    var x = topLeft.x
    val y0 = topLeft.y
    val w = Stroke(1.dp.toPx())
    while (x + 5 * u <= topLeft.x + width) {
        val p = Path()
        p.moveTo(x, y0 + 4 * u)
        p.lineTo(x, y0)
        p.lineTo(x + 4 * u, y0)
        p.lineTo(x + 4 * u, y0 + 3 * u)
        p.lineTo(x + u, y0 + 3 * u)
        p.lineTo(x + u, y0 + u)
        p.lineTo(x + 3 * u, y0 + u)
        p.lineTo(x + 3 * u, y0 + 2 * u)
        p.lineTo(x + 2 * u, y0 + 2 * u)
        drawPath(p, color, style = w)
        drawLine(color, Offset(x + 4 * u, y0 + 4 * u), Offset(x + 5 * u, y0 + 4 * u), 1.dp.toPx())
        x += 5 * u
    }
}

/** Altın para: işaretliyken dolu altın disk, değilken ince halka. */
fun Modifier.goldCoin(checked: Boolean, press: Float = 0f): Modifier = this.drawBehind {
    val c = Offset(size.width / 2f, size.height / 2f)
    val r = size.minDimension / 2f - 1.dp.toPx()
    if (checked) {
        drawCircle(Brush.radialGradient(listOf(Color(0xFFF1DB9A), NeoGold, Color(0xFF8D6A1C)), center = Offset(c.x - r * 0.3f, c.y - r * 0.3f), radius = r * 1.7f), r, c)
        drawCircle(Color(0xFF8D6A1C), r, c, style = Stroke(1.dp.toPx()))
        drawCircle(Color(0xFF8D6A1C).copy(alpha = 0.6f), r * 0.78f, c, style = Stroke(0.6.dp.toPx()))
    } else {
        drawCircle(NeoGold, r, c, style = Stroke(1.2.dp.toPx()))
        drawCircle(NeoGold.copy(alpha = 0.5f), r * 0.78f, c, style = Stroke(0.6.dp.toPx()))
        if (press > 0f) drawCircle(NeoGold.copy(alpha = 0.25f * press), r, c)
    }
}

/** Roma rakamı (1..39). */
fun roman(n: Int): String {
    var x = n.coerceIn(1, 3999)
    val sb = StringBuilder()
    for ((v, s) in listOf(1000 to "M", 900 to "CM", 500 to "D", 400 to "CD", 100 to "C", 90 to "XC", 50 to "L", 40 to "XL", 10 to "X", 9 to "IX", 5 to "V", 4 to "IV", 1 to "I")) {
        while (x >= v) { sb.append(s); x -= v }
    }
    return sb.toString()
}
