package com.odak.app.docs

import java.util.zip.Inflater

/**
 * Saf Kotlin TIFF çözücü (Android BitmapFactory TIFF'i çözmez). Desteklenen: şeritli ve döşemeli (tile) TIFF; sıkıştırma: yok, LZW,
 * PackBits, Deflate (+ yatay tahmin/predictor 2); 1/2/4/8/16 bit gri, palet, RGB, RGBA, gri+alfa, CMYK. Ayrıca CCITT (MH, Group 3 1B/2B, Group 4), BigTIFF ve JPEG-içi-TIFF
 * (dışarıdan verilen JPEG çözücüyle) desteklenir. Desteklenmeyenler (ayrı düzlem vb.) için null döner. Büyük görüntüler çözülürken doğrudan küçültülür (uzun kenar ≤ [maxSide]).
 */
object TiffDecoder {
    class Img(val w: Int, val h: Int, val argb: IntArray)

    private const val MAX_BYTES = 200_000_000L

    private class R(val b: ByteArray, val le: Boolean) {
        fun u8(o: Int): Int = if (o in b.indices) b[o].toInt() and 0xFF else 0
        fun u16(o: Int): Int = if (le) u8(o) or (u8(o + 1) shl 8) else (u8(o) shl 8) or u8(o + 1)
        fun u32(o: Int): Long = if (le) (u16(o).toLong() or (u16(o + 2).toLong() shl 16)) else ((u16(o).toLong() shl 16) or u16(o + 2).toLong())
        fun u64(o: Int): Long = if (le) (u32(o) or (u32(o + 4) shl 32)) else ((u32(o) shl 32) or u32(o + 4))
    }

    private class Tag(val type: Int, val count: Int, val valueOff: Int)

    private fun ver(b: ByteArray): Int = when {
        b.size < 8 -> 0
        b[0] == 'I'.code.toByte() && b[1] == 'I'.code.toByte() && b[3].toInt() == 0 && (b[2].toInt() == 42 || b[2].toInt() == 43) -> b[2].toInt()
        b[0] == 'M'.code.toByte() && b[1] == 'M'.code.toByte() && b[2].toInt() == 0 && (b[3].toInt() == 42 || b[3].toInt() == 43) -> b[3].toInt()
        else -> 0
    }
    fun isTiff(b: ByteArray): Boolean = ver(b) != 0

    /** [jpeg]: JPEG-içi-TIFF için tam bir JPEG akışını çözen işlev (Android: BitmapFactory); verilmezse bu sıkıştırma desteklenmez. */
    fun decode(bytes: ByteArray, maxSide: Int = 2048, jpeg: ((ByteArray) -> Img?)? = null): Img? = try { decodeInner(bytes, maxSide, jpeg) } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }

    private fun decodeInner(b: ByteArray, maxSide: Int, jpeg: ((ByteArray) -> Img?)?): Img? {
        if (!isTiff(b)) return null
        val r = R(b, b[0] == 'I'.code.toByte())
        val big = ver(b) == 43
        val ifdL = if (big) r.u64(8) else r.u32(4)
        if (ifdL <= 0 || ifdL + 2 > b.size) return null
        val ifd = ifdL.toInt()
        val n = if (big) r.u64(ifd).let { if (it < 0 || it > 65535) return null else it.toInt() } else r.u16(ifd)
        val head = if (big) 8 else 2; val esz = if (big) 20 else 12; val inl = if (big) 8 else 4
        val tags = HashMap<Int, Tag>()
        for (i in 0 until n) {
            val o = ifd + head + i * esz
            if (o + esz > b.size) break
            val id = r.u16(o); val type = r.u16(o + 2)
            val cntL = if (big) r.u64(o + 4) else r.u32(o + 4)
            if (cntL < 0 || cntL > Int.MAX_VALUE) continue
            val cnt = cntL.toInt()
            val size = when (type) { 1, 2, 6, 7 -> 1; 3, 8 -> 2; 4, 9, 11 -> 4; 5, 10, 12, 16, 17, 18 -> 8; else -> 1 }
            val total = size.toLong() * cnt
            val voff = if (total <= inl) (o + (if (big) 12 else 8)).toLong() else (if (big) r.u64(o + 12) else r.u32(o + 8))
            if (voff < 0 || voff > b.size) continue
            tags[id] = Tag(type, cnt, voff.toInt())
        }
        fun vals(id: Int): LongArray? {
            val t = tags[id] ?: return null
            if (t.count <= 0 || t.count > 5_000_000) return null
            return LongArray(t.count) { i ->
                when (t.type) {
                    3, 8 -> r.u16(t.valueOff + 2 * i).toLong()
                    4, 9 -> r.u32(t.valueOff + 4 * i)
                    16, 17, 18 -> r.u64(t.valueOff + 8 * i)
                    else -> r.u8(t.valueOff + i).toLong()
                }
            }
        }
        fun one(id: Int, def: Long): Long = vals(id)?.firstOrNull() ?: def

        val w = one(256, 0).toInt(); val h = one(257, 0).toInt()
        if (w <= 0 || h <= 0 || w.toLong() * h > 2_000_000_000L) return null
        val spp = one(277, 1).toInt().coerceAtLeast(1)
        val bpsArr = vals(258) ?: longArrayOf(1)
        val bps = bpsArr[0].toInt()
        if (bps !in setOf(1, 2, 4, 8, 16) || bpsArr.any { it.toInt() != bps }) return null
        val comp = one(259, 1).toInt()
        val photo = one(262, 1).toInt()
        val planar = one(284, 1).toInt()
        if (planar != 1) return null
        if (comp !in setOf(1, 2, 3, 4, 5, 7, 8, 32946, 32773)) return null
        if ((comp in 2..4) && (bps != 1 || spp != 1)) return null
        if (comp == 7 && jpeg == null) return null
        val t4opt = one(292, 0).toInt(); val fillRev = one(266, 1).toInt() == 2
        val jtables = if (comp == 7) tags[347]?.let { t -> if (t.count in 1..1_000_000 && t.valueOff + t.count <= b.size) b.copyOfRange(t.valueOff, t.valueOff + t.count) else null } else null
        val predictor = one(317, 1).toInt()
        if (predictor !in 1..2) return null
        if (predictor == 2 && bps != 8 && bps != 16) return null
        val extra = vals(338)?.firstOrNull()?.toInt() ?: -1
        val cmap = vals(320)
        val tiled = tags.containsKey(322)
        val step = maxOf(1, (maxOf(w, h) + maxSide - 1) / maxSide)
        val ow = (w + step - 1) / step; val oh = (h + step - 1) / step
        val out = IntArray(ow * oh)
        java.util.Arrays.fill(out, 0xFFFFFFFF.toInt())
        val bitsPerPixel = bps * spp

        fun rowBytesFor(px: Int): Int = (px * bitsPerPixel + 7) / 8

        fun decompress(off: Int, cnt: Int, expected: Int, pw: Int = w): ByteArray {
            val end = minOf(b.size.toLong(), off.toLong() + cnt).toInt()
            if (off < 0 || off >= b.size || end <= off) return ByteArray(expected)
            val src = b.copyOfRange(off, end)
            val raw = when (comp) {
                1 -> src
                2, 3, 4 -> {
                    val rows = expected / ((pw + 7) / 8)
                    // libtiff gibi: siyah koşu = bit 1, ardından fotometrik yorum (0: 1 = siyah, 1: 1 = beyaz) uygulanır
                    Ccitt.decode(src, pw, rows, comp, t4opt, fillRev)
                }
                32773 -> packBits(src, expected)
                5 -> lzw(src, expected)
                else -> inflate(src, expected)
            }
            return if (raw.size >= expected) raw else raw.copyOf(expected)
        }

        fun undoPredictor(row: ByteArray, o: Int, px: Int) {
            if (predictor != 2) return
            if (bps == 8) { for (i in spp until px * spp) row[o + i] = (row[o + i] + row[o + i - spp]).toByte() }
            else {
                // 16 bit
                for (i in spp until px * spp) {
                    val a = o + 2 * i; val p = o + 2 * (i - spp)
                    val cur = if (r.le) (row[a].toInt() and 0xFF) or ((row[a + 1].toInt() and 0xFF) shl 8) else ((row[a].toInt() and 0xFF) shl 8) or (row[a + 1].toInt() and 0xFF)
                    val prv = if (r.le) (row[p].toInt() and 0xFF) or ((row[p + 1].toInt() and 0xFF) shl 8) else ((row[p].toInt() and 0xFF) shl 8) or (row[p + 1].toInt() and 0xFF)
                    val s = (cur + prv) and 0xFFFF
                    if (r.le) { row[a] = s.toByte(); row[a + 1] = (s shr 8).toByte() } else { row[a] = (s shr 8).toByte(); row[a + 1] = s.toByte() }
                }
            }
        }

        fun sample(row: ByteArray, o: Int, idx: Int): Int {
            // idx: örnek sırası (piksel*spp + kanal); dönüş 0..255 (16 bitte yüksek bayt)
            return when (bps) {
                8 -> row[o + idx].toInt() and 0xFF
                16 -> (row[o + 2 * idx + (if (r.le) 1 else 0)].toInt() and 0xFF)
                else -> {
                    val bit = idx * bps
                    val by = row[o + bit / 8].toInt() and 0xFF
                    val shift = 8 - bps - (bit % 8)
                    val v = (by shr shift) and ((1 shl bps) - 1)
                    v
                }
            }
        }

        fun rawLevel(row: ByteArray, o: Int, idx: Int): Int = sample(row, o, idx)

        fun pixel(row: ByteArray, o: Int, x: Int): Int {
            val base = x * spp
            val maxV = if (bps >= 8) 255 else (1 shl bps) - 1
            when {
                spp == 1 || (spp == 2 && photo <= 1) -> {
                    val v = rawLevel(row, o, base)
                    var a = 255
                    if (spp == 2) a = rawLevel(row, o, base + 1).let { if (bps < 8) it * 255 / maxV else it }
                    if (photo == 3) {
                        val cm = cmap ?: return 0xFF000000.toInt()
                        val ents = 1 shl bps
                        if (cm.size < 3 * ents || v >= ents) return 0xFF000000.toInt()
                        return (0xFF shl 24) or (((cm[v] shr 8).toInt() and 0xFF) shl 16) or (((cm[ents + v] shr 8).toInt() and 0xFF) shl 8) or ((cm[2 * ents + v] shr 8).toInt() and 0xFF)
                    }
                    var g = if (bps < 8) v * 255 / maxV else v
                    if (photo == 0) g = 255 - g
                    return (a shl 24) or (g shl 16) or (g shl 8) or g
                }
                photo == 2 && spp >= 3 -> {
                    val rr = rawLevel(row, o, base); val gg = rawLevel(row, o, base + 1); val bb = rawLevel(row, o, base + 2)
                    var a = 255
                    if (spp >= 4 && (extra == 1 || extra == 2 || extra == -1)) a = rawLevel(row, o, base + 3)
                    if (extra == 1 && a in 1..254) { // ön-çarpılmış alfa
                        return (a shl 24) or (minOf(255, rr * 255 / a) shl 16) or (minOf(255, gg * 255 / a) shl 8) or minOf(255, bb * 255 / a)
                    }
                    return (a shl 24) or (rr shl 16) or (gg shl 8) or bb
                }
                photo == 5 && spp >= 4 -> {
                    val c = rawLevel(row, o, base); val m = rawLevel(row, o, base + 1); val y = rawLevel(row, o, base + 2); val k = rawLevel(row, o, base + 3)
                    val rr = (255 - c) * (255 - k) / 255; val gg = (255 - m) * (255 - k) / 255; val bb = (255 - y) * (255 - k) / 255
                    return (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
                }
                else -> return 0xFF000000.toInt()
            }
        }

        fun blit(data: ByteArray, x0: Int, y0: Int, pw: Int, ph: Int, stride: Int) {
            for (ry in 0 until ph) {
                val y = y0 + ry
                if (y >= h) break
                if (y % step != 0) continue
                val o = ry * stride
                undoPredictor(data, o, pw)
                var x = ((x0 + step - 1) / step) * step
                while (x < x0 + pw && x < w) {
                    val oi = (y / step) * ow + x / step
                    if (oi in out.indices) out[oi] = pixel(data, o, x - x0)
                    x += step
                }
            }
        }

        fun jpegBlit(off: Int, cnt: Int, x0: Int, y0: Int) {
            val end = minOf(b.size.toLong(), off.toLong() + cnt).toInt()
            if (off < 0 || off + 2 > end) return
            val strip = b.copyOfRange(off, end)
            val full = if (jtables != null && jtables.size > 4) {
                val tl = if (jtables[jtables.size - 2] == 0xFF.toByte() && jtables[jtables.size - 1] == 0xD9.toByte()) jtables.size - 2 else jtables.size
                val sk = if (strip[0] == 0xFF.toByte() && strip[1] == 0xD8.toByte()) 2 else 0
                jtables.copyOfRange(0, tl) + strip.copyOfRange(sk, strip.size)
            } else strip
            val im = try { jpeg!!(full) } catch (e: Exception) { null } ?: return
            for (ry in 0 until im.h) {
                val y = y0 + ry
                if (y >= h) break
                if (y % step != 0) continue
                var x = ((x0 + step - 1) / step) * step
                while (x < x0 + im.w && x < w) {
                    val oi = (y / step) * ow + x / step
                    if (oi in out.indices) out[oi] = im.argb[ry * im.w + (x - x0)] or (0xFF shl 24)
                    x += step
                }
            }
        }

        if (!tiled) {
            val rps = one(278, h.toLong()).toInt().let { if (it <= 0 || it > h) h else it }
            val offs = vals(273) ?: return null
            val cnts = vals(279)
            val rb = rowBytesFor(w)
            val strips = (h + rps - 1) / rps
            for (s in 0 until minOf(strips, offs.size)) {
                val y0 = s * rps
                val rows = minOf(rps, h - y0)
                val cnt = cnts?.getOrNull(s)?.toInt() ?: (b.size - offs[s].toInt())
                if (rows.toLong() * rb > MAX_BYTES) return null
                if (comp == 7) { jpegBlit(offs[s].toInt(), cnt, 0, y0); continue }
                blit(decompress(offs[s].toInt(), cnt, rows * rb), 0, y0, w, rows, rb)
            }
        } else {
            val tw = one(322, 0).toInt(); val th = one(323, 0).toInt()
            if (tw <= 0 || th <= 0) return null
            val offs = vals(324) ?: return null
            val cnts = vals(325)
            val across = (w + tw - 1) / tw; val down = (h + th - 1) / th
            val rb = rowBytesFor(tw)
            if (th.toLong() * rb > MAX_BYTES) return null
            for (ty in 0 until down) for (tx in 0 until across) {
                val idx = ty * across + tx
                if (idx >= offs.size) continue
                val cnt = cnts?.getOrNull(idx)?.toInt() ?: (b.size - offs[idx].toInt())
                if (comp == 7) { jpegBlit(offs[idx].toInt(), cnt, tx * tw, ty * th); continue }
                blit(decompress(offs[idx].toInt(), cnt, th * rb, tw), tx * tw, ty * th, tw, th, rb)
            }
        }
        return Img(ow, oh, out)
    }

    fun packBits(src: ByteArray, expected: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream(maxOf(expected, 16))
        var i = 0
        while (i < src.size && out.size() < expected) {
            val n = src[i++].toInt()
            if (n >= 0) { val c = n + 1; val e = minOf(src.size, i + c); out.write(src, i, e - i); i += c }
            else if (n != -128) { if (i >= src.size) break; val c = 1 - n; val v = src[i++].toInt(); repeat(c) { out.write(v) } }
        }
        return out.toByteArray()
    }

    fun inflate(src: ByteArray, expected: Int): ByteArray {
        val inf = Inflater()
        inf.setInput(src)
        val out = java.io.ByteArrayOutputStream(maxOf(expected, 16))
        val buf = ByteArray(64 * 1024)
        try {
            while (!inf.finished() && out.size() < expected) {
                val n = inf.inflate(buf)
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
                out.write(buf, 0, n)
            }
        } catch (e: Exception) { } finally { inf.end() }
        return out.toByteArray()
    }

    /** TIFF LZW (MSB ilk, "erken değişim"). */
    fun lzw(src: ByteArray, expected: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream(maxOf(expected, 16))
        val prefix = IntArray(4096); val suffix = ByteArray(4096); val length = IntArray(4096)
        for (i in 0 until 256) { suffix[i] = i.toByte(); length[i] = 1; prefix[i] = -1 }
        var next = 258; var bits = 9
        var buf = 0; var nb = 0; var pos = 0
        var prev = -1
        val tmp = ByteArray(4097)
        fun emit(code: Int): Int {
            var c = code; val len = length[c]
            var i = len - 1
            while (c >= 0 && i >= 0) { tmp[i--] = suffix[c]; c = prefix[c] }
            out.write(tmp, 0, len)
            return tmp[0].toInt() and 0xFF
        }
        while (out.size() < expected) {
            while (nb < bits && pos < src.size) { buf = (buf shl 8) or (src[pos++].toInt() and 0xFF); nb += 8 }
            if (nb < bits) break
            val code = (buf shr (nb - bits)) and ((1 shl bits) - 1)
            nb -= bits
            buf = buf and ((1 shl nb) - 1)
            if (code == 257) break
            if (code == 256) { next = 258; bits = 9; prev = -1; continue }
            if (prev == -1) {
                if (code >= 256) break
                emit(code); prev = code; continue
            }
            val first: Int
            if (code < next) {
                first = emit(code)
            } else if (code == next) {
                // KwKwK: prev + ilk(prev)
                var c = prev; var f = 0
                while (c >= 0) { f = suffix[c].toInt() and 0xFF; c = prefix[c] }
                first = f
                // önce prev'i yaz, sonra ilk karakteri
                emit(prev); out.write(first)
            } else break
            if (next < 4096) {
                prefix[next] = prev; suffix[next] = first.toByte(); length[next] = length[prev] + 1
                next++
            }
            if (next + 1 >= (1 shl bits) && bits < 12) bits++
            prev = code
        }
        return out.toByteArray()
    }
}
