package com.odak.app.docs

import java.text.Bidi

/** Sağdan sola (Arapça/İbranice) metin için paragraf yönü ve satırdaki parçaların görsel sırası. Saf mantık (java.text.Bidi). */
object RtlText {
    private fun strongRtl(cp: Int): Boolean = Character.getDirectionality(cp).let { it == Character.DIRECTIONALITY_RIGHT_TO_LEFT || it == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC }

    fun hasRtl(s: String): Boolean { var i = 0; while (i < s.length) { val cp = s.codePointAt(i); if (strongRtl(cp)) return true; i += Character.charCount(cp) }; return false }

    /** Paragraf yönü: ilk güçlü harf sağdan sola ise true. */
    fun isRtl(s: String): Boolean {
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i); i += Character.charCount(cp)
            if (strongRtl(cp)) return true
            if (Character.isLetter(cp)) return false
        }
        return false
    }

    /** Parçaların (sözcük/boşluk) soldan sağa görsel sırası; indeksler mantıksal sıraya işaret eder. RTL yoksa 0..n-1. */
    fun visualOrder(parts: List<String>, rtlBase: Boolean): IntArray {
        val n = parts.size
        val ident = IntArray(n) { it }
        if (n < 2 || !(rtlBase || parts.any { hasRtl(it) })) return ident
        val sb = StringBuilder(); val starts = IntArray(n)
        for ((i, p) in parts.withIndex()) { starts[i] = sb.length; sb.append(if (p.isEmpty()) "￼" else p) }
        val b = try { Bidi(sb.toString(), if (rtlBase) Bidi.DIRECTION_RIGHT_TO_LEFT else Bidi.DIRECTION_LEFT_TO_RIGHT) } catch (e: Exception) { return ident }
        if (b.isLeftToRight) return ident
        val levels = ByteArray(n) { b.getLevelAt(starts[it]).toByte() }
        val objs = Array<Int>(n) { it }
        Bidi.reorderVisually(levels, 0, objs, 0, n)
        return IntArray(n) { objs[it] }
    }
}
