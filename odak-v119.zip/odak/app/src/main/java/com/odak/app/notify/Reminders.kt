package com.odak.app.notify

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.odak.app.MainActivity
import com.odak.app.R
import com.odak.app.plan.PlanItem
import com.odak.app.plan.PlanStore
import com.odak.app.plan.fmtTime
import java.time.LocalDateTime
import java.time.ZoneId

const val CHANNEL = "odak_plan"

object Reminders {
    private fun pending(c: Context, id: String, title: String, time: String): PendingIntent {
        val i = Intent(c, ReminderReceiver::class.java)
            .putExtra("id", id).putExtra("title", title).putExtra("time", time)
        return PendingIntent.getBroadcast(
            c, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(c: Context, p: PlanItem) {
        if (!p.hasTime || p.done) return
        val whenMs = LocalDateTime.of(p.date, java.time.LocalTime.of((p.startMin / 60).coerceIn(0, 23), (p.startMin % 60).coerceIn(0, 59)))
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val fireMs = whenMs - leadMin(c) * 60_000L
        if (fireMs <= System.currentTimeMillis()) return
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(c, p.id, p.title, fmtTime(p.startMin))
        if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireMs, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireMs, pi)
    }

    fun scheduleAt(c: Context, id: String, title: String, text: String, whenMs: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(c, id, title, text)
        if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
    }

    fun cancelId(c: Context, id: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(c, id, "", ""))
    }

    fun cancel(c: Context, p: PlanItem) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(c, p.id, p.title, ""))
    }

    fun leadMin(c: Context) = c.getSharedPreferences("odak_app", Context.MODE_PRIVATE).getInt("lead", 0)
    fun setLeadMin(c: Context, m: Int) =
        c.getSharedPreferences("odak_app", Context.MODE_PRIVATE).edit().putInt("lead", m).apply()

    /** Basit bildirim (örneğin süre uyarısı). */
    fun note(c: Context, nid: Int, title: String, text: String) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val chId = StyleChannel.ensure(c, nm)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(
            nid,
            NotificationCompat.Builder(c, chId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(text)
                .setContentIntent(open).setAutoCancel(true).build()
        )
    }

    fun dailyOn(c: Context, kind: Int) =
        c.getSharedPreferences("odak_app", Context.MODE_PRIVATE).getBoolean("daily$kind", false)

    fun setDaily(c: Context, kind: Int, on: Boolean) {
        c.getSharedPreferences("odak_app", Context.MODE_PRIVATE).edit().putBoolean("daily$kind", on).apply()
        scheduleDaily(c, kind)
    }

    private fun dailyPending(c: Context, kind: Int) = PendingIntent.getBroadcast(
        c, 900 + kind, Intent(c, DailyReceiver::class.java).putExtra("kind", kind),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /** kind 0 = sabah 08:00, 1 = akşam 21:00. */
    fun scheduleDaily(c: Context, kind: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = dailyPending(c, kind)
        if (!dailyOn(c, kind)) { am.cancel(pi); return }
        var t = java.time.LocalDate.now().atTime(if (kind == 0) 8 else if (kind == 1) 21 else 20, 0)
        if (kind == 2) {
            while (t.dayOfWeek != java.time.DayOfWeek.SUNDAY) t = t.plusDays(1)
            if (!t.isAfter(LocalDateTime.now())) t = t.plusWeeks(1)
        } else if (!t.isAfter(LocalDateTime.now())) t = t.plusDays(1)
        val ms = t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
    }

    fun rescheduleAll(c: Context) {
        PlanStore.load(c).forEach { schedule(c, it) }
        scheduleDaily(c, 0)
        scheduleDaily(c, 1)
        scheduleDaily(c, 2)
        com.odak.app.schedule.ScheduleStore.rescheduleAll(c)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val nid = (i.getStringExtra("id") ?: "").hashCode()
        if (i.getBooleanExtra("snooze", false)) {
            nm.cancel(nid)
            Reminders.scheduleAt(
                c, i.getStringExtra("id") ?: return, i.getStringExtra("title") ?: "",
                i.getStringExtra("time") ?: "", System.currentTimeMillis() + 10 * 60_000L
            )
            return
        }
        val planId = i.getStringExtra("id") ?: ""
        if (i.getBooleanExtra("done", false)) {
            nm.cancel(nid)
            PlanStore.save(c, PlanStore.load(c).map { if (it.id == planId) it.copy(done = true) else it })
            PlanWidget.refresh(c)
            return
        }
        val isPlan = PlanStore.load(c).any { it.id == planId }
        val chId = StyleChannel.ensure(c, nm)
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val doneAct = PendingIntent.getBroadcast(
            c, nid + 2,
            Intent(c, ReminderReceiver::class.java).putExtra("id", planId).putExtra("done", true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val snooze = PendingIntent.getBroadcast(
            c, nid + 1,
            Intent(c, ReminderReceiver::class.java)
                .putExtra("id", i.getStringExtra("id")).putExtra("title", i.getStringExtra("title"))
                .putExtra("time", i.getStringExtra("time")).putExtra("snooze", true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(c, chId)
            .addAction(0, c.getString(R.string.snooze), snooze)
            .apply { if (isPlan) addAction(0, c.getString(R.string.plan_done_action), doneAct) }
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(i.getStringExtra("title"))
            .setContentText(
                Msgs.text(
                    c, "remind", i.getStringExtra("time") ?: "",
                    mapOf("title" to (i.getStringExtra("title") ?: ""), "time" to (i.getStringExtra("time") ?: ""))
                )
            )
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        // İzin yoksa SecurityException atmaz; bildirim sessizce gösterilmez.
        nm.notify(nid, n)
        PlanWidget.refresh(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                Reminders.rescheduleAll(c)
                com.odak.app.notify.PlanWidget.refresh(c)
                com.odak.app.block.BlockStore.pruneOld(c)
            }
        }
    }
}

/** Sabah / akşam özeti bildirimi; her seferinde ertesi günü yeniden kurar. */
class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val kind = i.getIntExtra("kind", 0)
        if (!Reminders.dailyOn(c, kind)) return
        val today = java.time.LocalDate.now()
        val plans = PlanStore.load(c).filter { it.date == today }
        if (kind == 0) {
            val todos = com.odak.app.todo.TodoStore.load(c)
            val tasks = todos.count { !it.done }
            val overdue = todos.count { com.odak.app.logic.Pure.isOverdue(it.due, it.done, today) }
            if (plans.isNotEmpty() || tasks > 0) {
                Reminders.note(
                    c, 7000, c.getString(R.string.morning_title),
                    Msgs.text(
                        c, "morning",
                        c.getString(R.string.tab_plan) + ": " + plans.size + " · " + c.getString(R.string.tab_todo) + ": " + tasks +
                            (if (overdue > 0) " · ⚠ $overdue" else ""),
                        mapOf("plans" to plans.size.toString(), "tasks" to tasks.toString(), "overdue" to overdue.toString())
                    )
                )
            }
        } else if (kind == 2) {
            val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
            val pm = c.packageManager
            val ms = try {
                usm.queryAndAggregateUsageStats(System.currentTimeMillis() - 7L * 86_400_000L, System.currentTimeMillis())
                    .filter { it.key != c.packageName && pm.getLaunchIntentForPackage(it.key) != null }
                    .values.sumOf { it.totalTimeInForeground }
            } catch (e: Exception) {
                0L
            }
            val m = ms / 60_000
            Reminders.note(c, 7002, c.getString(R.string.st_week),
                Msgs.text(c, "week", "${m / 60}h ${"%02d".format(m % 60)}m", mapOf("time" to "${m / 60}h ${"%02d".format(m % 60)}m")))
        } else if (plans.isNotEmpty()) {
            Reminders.note(
                c, 7001, c.getString(R.string.eve_title),
                Msgs.text(
                    c, "evening",
                    c.getString(R.string.tab_plan) + ": " + plans.count { it.done } + "/" + plans.size,
                    mapOf("done" to plans.count { it.done }.toString(), "total" to plans.size.toString())
                )
            )
        }
        Reminders.scheduleDaily(c, kind)
        // Güvenlik ağı: sistem alarmları kaybettiyse planları yeniden kur, widget'ı tazele
        Reminders.rescheduleAll(c)
        PlanWidget.refresh(c)
    }
}
