package com.odak.app.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.net.Uri
import com.odak.app.R
import com.odak.app.theme.DesignStyle
import com.odak.app.theme.ThemePrefs

/**
 * Bildirim sesi kanala bağlıdır (kanal oluşturulduktan sonra değiştirilemez).
 * Yeni tasarımlar (Skeuo, Neumo, Glass, Y2K, Aurora, Clay, Dark) kendi bildirim sesiyle ayrı kanal kullanır;
 * diğer tasarımlar eski kanalda kalır.
 */
object StyleChannel {
    private val own = setOf(
        DesignStyle.SKEUOMORPHISM, DesignStyle.NEUMORPHISM, DesignStyle.GLASSMORPHISM,
        DesignStyle.Y2K, DesignStyle.AURORA, DesignStyle.CLAYMORPHISM, DesignStyle.DARK,
        DesignStyle.COSMIC, DesignStyle.SCIFI_HUD, DesignStyle.CYBER_INDUSTRIAL, DesignStyle.NEOCLASSICAL
    )

    fun idFor(style: DesignStyle): String = if (style in own) "${CHANNEL}_${style.key}" else CHANNEL

    /** Kanalı (yoksa) oluşturur ve kimliğini döndürür. */
    fun ensure(c: Context, nm: NotificationManager, style: DesignStyle = ThemePrefs.load(c)): String {
        val id = idFor(style)
        val base = c.getString(R.string.notif_channel)
        val ch = NotificationChannel(
            id, if (id == CHANNEL) base else "$base · ${style.label}", NotificationManager.IMPORTANCE_HIGH
        )
        if (id != CHANNEL) {
            val res = c.resources.getIdentifier("snd_${style.key}_notify", "raw", c.packageName)
            if (res != 0) {
                ch.setSound(
                    Uri.parse("android.resource://${c.packageName}/$res"),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }
        }
        nm.createNotificationChannel(ch)
        return id
    }
}
