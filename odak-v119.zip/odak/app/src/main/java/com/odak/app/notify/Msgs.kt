package com.odak.app.notify

import android.content.Context
import com.odak.app.logic.Pure

/** Kullanıcının yazdığı bildirim/uyarı metinleri. Boşsa varsayılan metin kullanılır. */
object Msgs {
    /** Ayarlanabilir türler (sıra = ekranda görünme sırası). */
    val KINDS = listOf("remind", "morning", "evening", "week", "warn", "limit", "focus", "pomo", "toast")

    /** Her türde kullanılabilen yer tutucular. */
    fun vars(kind: String): List<String> = when (kind) {
        "remind" -> listOf("title", "time")
        "morning" -> listOf("plans", "tasks", "overdue")
        "evening" -> listOf("done", "total")
        "week" -> listOf("time")
        "warn" -> listOf("app", "min")
        "limit" -> listOf("app")
        else -> emptyList()
    }

    private fun p(c: Context) = c.getSharedPreferences("odak_app", Context.MODE_PRIVATE)
    fun get(c: Context, kind: String): String = p(c).getString("msg:$kind", "") ?: ""
    fun set(c: Context, kind: String, v: String) {
        val e = p(c).edit()
        if (v.isBlank()) e.remove("msg:$kind") else e.putString("msg:$kind", v.trim().take(200))
        e.apply()
    }

    fun text(c: Context, kind: String, def: String, vars: Map<String, String> = emptyMap()): String =
        Pure.msgOrDefault(get(c, kind), def, vars)
}
