package com.odak.app.theme

import android.graphics.Paint as APaint
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/*
 * Y2K / Aurora UI / Claymorphism / Dark Mode için çizim araçları.
 *  Y2K: jel hap (3 duraklı degrade + üst parlama + krom halka), hologram kenar, parıldayan yıldızlı zemin.
 *  Aurora: koyu gökyüzü + yavaş nefes alan bulanık ışık bulutları, degrade ışıklı kenarlı koyu paneller.
 *  Clay: renkli dış gölge + sol-üst beyaz iç ışık + sağ-alt koyu iç gölge (basınca ofsetler yarıya iner).
 *  Dark: #121212 zemin; yüzey yükseldikçe açılır, gölge yok.
 */

// ---------------------------------------------------------------- Dark
val DarkBase = Color(0xFF121212)

/** Material koyu tema yüksekliği: seviye arttıkça yüzey beyaza doğru açılır (gölge yerine). */
fun darkElevation(level: Int): Color = lerp(DarkBase, Color.White, 0.05f + 0.02f * level.coerceIn(0, 5))

// ---------------------------------------------------------------- Clay
/** Kil yüzey. depth 1 = dinlenme (tam ofset), 0.5 = basılı (ofsetler yarıya iner). */
fun Modifier.claySurface(
    shape: Shape,
    color: Color,
    depth: Float = 1f,
    offset: Dp = 8.dp,
    blur: Dp = 20.dp
): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection).asAndroidPath()
    val d = depth.coerceIn(0.2f, 1.2f)
    val dx = offset.toPx() * d
    val b = blur.toPx() * (0.6f + 0.4f * d)
    val drop = lerp(color, Color(0xFF6C4CF0), 0.5f)
    val shade = lerp(color, Color(0xFF3A1FA0), 0.45f)
    drawIntoCanvas { c ->
        val nc = c.nativeCanvas
        val p = APaint(APaint.ANTI_ALIAS_FLAG)
        p.color = color.toArgb()
        p.setShadowLayer(b, dx, dx, drop.copy(alpha = 0.45f).toArgb())
        nc.drawPath(path, p)
        p.clearShadowLayer()
        nc.drawPath(path, p)
        nc.save()
        nc.clipPath(path)
        val frame = android.graphics.Path()
        frame.fillType = android.graphics.Path.FillType.EVEN_ODD
        frame.addRect(-size.width, -size.height, size.width * 2f, size.height * 2f, android.graphics.Path.Direction.CW)
        frame.addPath(path)
        val q = APaint(APaint.ANTI_ALIAS_FLAG)
        q.color = color.toArgb()
        val inner = 5.dp.toPx() * d
        // sağ-alt koyu iç gölge
        q.setShadowLayer(inner * 2f, -inner, -inner, shade.copy(alpha = 0.40f).toArgb())
        nc.drawPath(frame, q)
        // sol-üst beyaz iç ışık
        q.setShadowLayer(inner * 2f, inner, inner, Color.White.copy(alpha = 0.65f).toArgb())
        nc.drawPath(frame, q)
        nc.restore()
    }
}

/** Kil içi çukur (giriş alanı, kapalı anahtar): yalnız iç gölgeler. */
fun Modifier.clayWell(shape: Shape, color: Color): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection).asAndroidPath()
    val d = 3.dp.toPx()
    val shade = lerp(color, Color(0xFF6C4CF0), 0.5f)
    drawIntoCanvas { c ->
        val nc = c.nativeCanvas
        val p = APaint(APaint.ANTI_ALIAS_FLAG)
        p.color = color.toArgb()
        nc.drawPath(path, p)
        nc.save()
        nc.clipPath(path)
        val frame = android.graphics.Path()
        frame.fillType = android.graphics.Path.FillType.EVEN_ODD
        frame.addRect(-size.width, -size.height, size.width * 2f, size.height * 2f, android.graphics.Path.Direction.CW)
        frame.addPath(path)
        val q = APaint(APaint.ANTI_ALIAS_FLAG)
        q.color = color.toArgb()
        q.setShadowLayer(d * 2.6f, d, d, shade.copy(alpha = 0.30f).toArgb())
        nc.drawPath(frame, q)
        q.setShadowLayer(d * 2.6f, -d, -d, Color.White.copy(alpha = 0.95f).toArgb())
        nc.drawPath(frame, q)
        nc.restore()
    }
}

// ---------------------------------------------------------------- Y2K
val Y2kPink = Color(0xFFFF2E9A)
val Y2kBlue = Color(0xFF2A5BFF)

/** Jel hap: 3 duraklı degrade, üst cam parlaması, alt ışıma, beyaz iç + gümüş dış halka, renkli gölge. */
fun Modifier.y2kGel(
    shape: Shape,
    top: Color,
    mid: Color,
    bottom: Color,
    pressed: Float = 0f
): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection)
    drawIntoCanvas { c ->
        val nc = c.nativeCanvas
        val p = APaint(APaint.ANTI_ALIAS_FLAG)
        p.color = mid.toArgb()
        p.setShadowLayer(10.dp.toPx(), 0f, (5.dp.toPx()) * (1f - 0.6f * pressed), mid.copy(alpha = 0.45f).toArgb())
        nc.drawPath(path.asAndroidPath(), p)
    }
    drawPath(path, Brush.verticalGradient(0f to top, 0.55f to mid, 1f to bottom))
    clipPath(path) {
        val w = size.width
        val h = size.height
        val inset = 3.dp.toPx()
        drawRoundRect(
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.75f - 0.3f * pressed), Color.White.copy(alpha = 0f))),
            topLeft = Offset(w * 0.08f, inset),
            size = Size(w * 0.84f, h * 0.45f),
            cornerRadius = CornerRadius(h * 0.25f)
        )
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.28f)), startY = h * 0.6f, endY = h),
            topLeft = Offset(0f, h * 0.6f), size = Size(w, h * 0.4f)
        )
    }
    drawPath(path, Color.White, style = Stroke(2.dp.toPx()))
    drawPath(
        path,
        Brush.verticalGradient(listOf(Color(0xFFF2F6FF), Color(0xFF8E9BB8), Color(0xFFE6ECF9))),
        style = Stroke(0.8.dp.toPx())
    )
}

/** Hologram kenar: pembe-aqua-mor döngülü degrade çerçeve. */
fun Modifier.holoBorder(shape: Shape, width: Dp = 2.dp): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection)
    drawPath(
        path,
        Brush.linearGradient(
            listOf(Color(0xFFFF9AD5), Color(0xFF7FE8FF), Color(0xFFB79BFF), Color(0xFFFF9AD5)),
            start = Offset.Zero, end = Offset(size.width, size.height)
        ),
        style = Stroke(width.toPx())
    )
}

private val StarSpots = listOf(
    Triple(0.12f, 0.08f, 1.0f), Triple(0.82f, 0.05f, 1.4f), Triple(0.55f, 0.16f, 0.7f),
    Triple(0.92f, 0.30f, 0.9f), Triple(0.06f, 0.42f, 1.2f), Triple(0.70f, 0.50f, 0.8f),
    Triple(0.30f, 0.62f, 1.0f), Triple(0.90f, 0.72f, 1.3f), Triple(0.15f, 0.86f, 0.9f),
    Triple(0.60f, 0.92f, 1.1f), Triple(0.40f, 0.30f, 0.6f), Triple(0.78f, 0.88f, 0.7f)
)

private fun DrawScope.sparkle(center: Offset, r: Float, color: Color) {
    val p = Path()
    val k = r * 0.26f
    p.moveTo(center.x, center.y - r)
    p.lineTo(center.x + k, center.y - k)
    p.lineTo(center.x + r, center.y)
    p.lineTo(center.x + k, center.y + k)
    p.lineTo(center.x, center.y + r)
    p.lineTo(center.x - k, center.y + k)
    p.lineTo(center.x - r, center.y)
    p.lineTo(center.x - k, center.y - k)
    p.close()
    drawPath(p, color)
}

/** Y2K zemini: aqua-lavanta-pembe degrade, cam baloncuklar ve göz kırpan yıldızlar. */
@Composable
fun Y2kSparkles(modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "y2k")
    val ph by tr.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Reverse), label = "tw"
    )
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        // cam baloncuklar
        listOf(Triple(0.2f, 0.25f, 0.16f), Triple(0.85f, 0.55f, 0.12f), Triple(0.35f, 0.8f, 0.2f)).forEach { (fx, fy, fr) ->
            val c = Offset(w * fx, h * fy)
            val r = minOf(w, h) * fr
            drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.22f)), center = c, radius = r), r, c)
            drawCircle(Color.White.copy(alpha = 0.55f), r, c, style = Stroke(1.5.dp.toPx()))
            drawCircle(Color.White.copy(alpha = 0.7f), r * 0.14f, Offset(c.x - r * 0.4f, c.y - r * 0.45f))
        }
        StarSpots.forEachIndexed { i, (fx, fy, s) ->
            val a = if (i % 2 == 0) ph else 1f - ph
            val r = 7.dp.toPx() * s * (0.6f + 0.6f * a)
            val c = Offset(w * fx, h * fy)
            sparkle(c, r * 1.8f, Y2kPink.copy(alpha = 0.18f * a))
            sparkle(c, r, Color.White.copy(alpha = 0.35f + 0.65f * a))
        }
    }
}

/** Dokunma noktasından saçılan parıltılar (Y2K basma efekti). g: 0..1. */
fun DrawScope.y2kBurst(center: Offset, g: Float) {
    val n = 7
    val reach = 46.dp.toPx() * g
    for (i in 0 until n) {
        val ang = (i.toFloat() / n) * 6.2831855f + 0.4f
        val c = Offset(center.x + kotlin.math.cos(ang) * reach, center.y + kotlin.math.sin(ang) * reach)
        sparkle(c, 5.dp.toPx() * (1.1f - g * 0.5f), (if (i % 2 == 0) Color.White else Y2kPink).copy(alpha = (1f - g).coerceIn(0f, 1f)))
    }
}

// ---------------------------------------------------------------- Aurora
val AuroraMint = Color(0xFF5EEAD4)
val AuroraViolet = Color(0xFFA78BFA)

/** Aurora zemini: koyu gökyüzü, nefes alan bulanık ışık bulutları ve okunabilirlik örtüsü. */
@Composable
fun AuroraBackdrop(modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "aurora")
    val a by tr.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "breath"
    )
    Box(modifier.fillMaxSize().background(Color(0xFF070B1F))) {
        Box(
            Modifier.fillMaxSize().blur(60.dp).drawBehind {
                val w = size.width
                val h = size.height
                val r = minOf(w, h) * 0.45f
                // Renkler metin kontrastı için bilinçli koyu tutuldu; bkz. NewStyles2Test.
                drawCircle(Color(0xFF127A5C), r * (1f + 0.2f * a), Offset(w * (0.2f + 0.2f * a), h * (0.15f + 0.1f * a)), alpha = 0.8f)
                drawCircle(Color(0xFF4A2BAE), r * 1.1f, Offset(w * (0.9f - 0.25f * a), h * (0.5f + 0.1f * a)), alpha = 0.8f)
                drawCircle(Color(0xFF0E6A86), r * (0.9f + 0.25f * a), Offset(w * (0.3f + 0.15f * a), h * (0.88f - 0.1f * a)), alpha = 0.8f)
            }
        )
        Box(Modifier.fillMaxSize().background(Color(0x59070B1F)))
    }
}

/** Aurora paneli: koyu yarı saydam dolgu, nane→mor ışıklı kenar, yumuşak parıltı. glow 0..1. */
fun Modifier.auroraPanel(shape: Shape, glow: Float = 0.3f): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection)
    drawIntoCanvas { c ->
        val nc = c.nativeCanvas
        nc.save()
        nc.clipOutPath(path.asAndroidPath())
        val p = APaint(APaint.ANTI_ALIAS_FLAG)
        p.color = android.graphics.Color.BLACK
        p.setShadowLayer(16.dp.toPx(), 0f, 4.dp.toPx(), AuroraMint.copy(alpha = 0.30f * glow.coerceIn(0f, 1f)).toArgb())
        nc.drawPath(path.asAndroidPath(), p)
        nc.restore()
    }
    drawPath(path, Brush.verticalGradient(listOf(Color(0xE60D1636), Color(0xE60A1230))))
    drawPath(
        path,
        Brush.linearGradient(
            listOf(AuroraMint.copy(alpha = 0.75f), AuroraViolet.copy(alpha = 0.55f), AuroraMint.copy(alpha = 0.15f)),
            start = Offset.Zero, end = Offset(size.width, size.height)
        ),
        style = Stroke(1.dp.toPx())
    )
}

/** Aurora düğmesi: nane→mor degrade; shift 0..1 degradeyi kaydırır, glow dış parıltıyı büyütür. */
fun Modifier.auroraButton(shape: Shape, shift: Float = 0f): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection)
    val s = shift.coerceIn(0f, 1f)
    drawIntoCanvas { c ->
        val nc = c.nativeCanvas
        val p = APaint(APaint.ANTI_ALIAS_FLAG)
        p.color = AuroraMint.toArgb()
        p.setShadowLayer((10f + 18f * s).dp.toPx(), 0f, 0f, lerp(AuroraMint, AuroraViolet, s).copy(alpha = 0.55f).toArgb())
        nc.drawPath(path.asAndroidPath(), p)
    }
    val w = size.width
    drawPath(
        path,
        Brush.horizontalGradient(
            listOf(AuroraMint, AuroraViolet, AuroraMint),
            startX = -w * s, endX = w * (2f - s)
        )
    )
}
