package com.odak.app.plan

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LocalTextStyle
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.odak.app.R
import com.odak.app.theme.DesignStyle
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.PeriodSelector
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.hairlineBottom
import com.odak.app.theme.aeroGlass
import com.odak.app.theme.plainClick
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.time.format.TextStyle as JTextStyle

private fun scroller(m: Modifier = Modifier) = m.fillMaxSize()

// =====================================================================
// FUTURİSTİK: HUD paneli, zaman çizgisi
// =====================================================================
@Composable
fun FuturisticPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val skin = skinFor(LocalDesign.current.style)
    Column(scroller().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("ODAK//SYS", color = t.primary, fontSize = 11.sp, letterSpacing = 4.sp)
            PeriodSelector(periodLabels(), vm.period.ordinal, { vm.setPeriod(Period.entries[it]) })
        }
        Spacer(Modifier.height(10.dp))
        NavRow(vm)
        Spacer(Modifier.height(10.dp))
        when (vm.period) {
            Period.DAY -> {
                FutHud(vm)
                Spacer(Modifier.height(12.dp))
                FutTimeline(vm)
            }
            Period.WEEK -> WeekGrid(vm.items, vm.weekStart, vm.today, skin, hourHeight = 44.dp, onPickDay = vm.pickDay)
            Period.MONTH -> {
                MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, onPickDay = vm.setAnchor)
                Spacer(Modifier.height(12.dp))
                FutTimeline(vm)
            }
        }
        Spacer(Modifier.height(16.dp))
        AddRow(vm)
    }
}

@Composable
private fun FutHud(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    val done = list.count { it.done }
    val total = list.size
    val pct = if (total == 0) 0f else done / total.toFloat()
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(130.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 9.dp.toPx()
                val inset = sw / 2f + 8.dp.toPx()
                val arcSize = Size(size.width - 2 * inset, size.height - 2 * inset)
                drawCircle(
                    Color(0xFF7C4DFF),
                    radius = size.minDimension / 2f - 1.dp.toPx(),
                    style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 14f)))
                )
                drawArc(
                    Color(0xFF12263A), -90f, 360f, false,
                    topLeft = Offset(inset, inset), size = arcSize, style = Stroke(sw)
                )
                drawArc(
                    t.primary, -90f, 360f * pct, false,
                    topLeft = Offset(inset, inset), size = arcSize,
                    style = Stroke(sw, cap = StrokeCap.Butt)
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${(pct * 100).toInt()}%", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("$done/$total", fontSize = 10.sp, color = Color(0xFF6F94AD))
            }
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(
                vm.anchor.format(DateTimeFormatter.ofPattern("dd.MM")),
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = t.primary,
                style = LocalTextStyle.current.copy(shadow = Shadow(t.primary, blurRadius = 24f))
            )
            Text(
                "${dayName(vm.anchor, JTextStyle.SHORT).uppercase(Locale.getDefault())} // ${vm.anchor.year}",
                fontSize = 11.sp,
                letterSpacing = 3.sp,
                color = t.accent
            )
        }
    }
}

@Composable
private fun FutTimeline(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) {
        com.odak.app.theme.PlanEmpty(Color(0xFF6F94AD))
        return
    }
    Column(
        Modifier.drawBehind {
            val x = 62.dp.toPx()
            drawLine(
                Brush.verticalGradient(listOf(t.primary, t.accent)),
                Offset(x, 0f), Offset(x, size.height), 2f
            )
        }
    ) {
        list.forEach { p ->
            Row(Modifier.fillMaxWidth().height(64.dp).plainClick { vm.startEdit(p) }, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    timeOf(p).ifEmpty { "--:--" },
                    fontSize = 11.sp,
                    color = Color(0xFF6F94AD),
                    modifier = Modifier.width(50.dp)
                )
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier
                        .size(12.dp)
                        .rotate(45f)
                        .background(if (p.done) t.primary else Color(0xFF04060C))
                        .border(2.dp, t.primary)
                )
                Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p, upper = true),
                        fontSize = 13.sp,
                        letterSpacing = 1.5.sp,
                        color = if (p.done) Color(0xFF5B7A90) else t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) {
                        Text("// ${p.durMin}'", fontSize = 10.sp, letterSpacing = 2.sp, color = Color(0xFF5F86A0))
                    }
                }
                ThemedCheck(p.done) { vm.toggle(p, it) }
                DeleteMark(Color(0xFF5B7A90)) { vm.remove(p) }
            }
        }
    }
}

// =====================================================================
// FRUTİGER AERO: cam pencere + parlak balonlar
// =====================================================================
@Composable
fun AeroPlan(vm: PlanVm) {
    val skin = skinFor(DesignStyle.FRUTIGER_AERO)
    val shape = RoundedCornerShape(18.dp)
    Column(scroller().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .shadow(10.dp, shape, ambientColor = Color(0xFF0054E3), spotColor = Color(0xFF0054E3))
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xB8FFFFFF), Color(0x8CE6F6FF))))
                .border(1.5.dp, Color.White, shape)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xE6FFFFFF), Color(0xBFA0D7FA), Color(0xB36EBEF5), Color(0xCCAAE1FC))
                        )
                    ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Atlas — ${rangeLabel(vm)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF0A3A78),
                    maxLines = 1,
                    modifier = Modifier.weight(1f).padding(start = 12.dp)
                )
                AeroOrb(Color(0xFF7FC6FF), Color(0xFF1C78E6))
                AeroOrb(Color(0xFF7FC6FF), Color(0xFF1C78E6))
                AeroOrb(Color(0xFFFF9B8A), Color(0xFFD8321C))
                Spacer(Modifier.width(8.dp))
            }
            Column(Modifier.padding(12.dp)) {
                PeriodSelector(periodLabels(), vm.period.ordinal, { vm.setPeriod(Period.entries[it]) })
                Spacer(Modifier.height(10.dp))
                NavRow(vm)
                Spacer(Modifier.height(10.dp))
                when (vm.period) {
                    Period.DAY -> {
                        AeroWeekStrip(vm)
                        Spacer(Modifier.height(8.dp))
                        AeroList(vm)
                    }
                    Period.WEEK -> WeekGrid(vm.items, vm.weekStart, vm.today, skin, hourHeight = 38.dp, onPickDay = vm.pickDay)
                    Period.MONTH -> {
                        MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 50.dp, onPickDay = vm.setAnchor)
                        Spacer(Modifier.height(8.dp))
                        AeroList(vm)
                    }
                }
                Spacer(Modifier.height(14.dp))
                AddRow(vm)
            }
        }
    }
}

@Composable
private fun AeroOrb(c1: Color, c2: Color) {
    Box(
        Modifier
            .padding(end = 5.dp)
            .size(22.dp)
            .background(Brush.verticalGradient(listOf(c1, c2)), CircleShape)
            .border(1.dp, Color.White, CircleShape)
    )
}

@Composable
private fun AeroWeekStrip(vm: PlanVm) {
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
        for (i in 0..6) {
            val d = vm.weekStart.plusDays(i.toLong())
            val on = d == vm.anchor
            Column(Modifier.plainClick { vm.setAnchor(d) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(dayName(d, JTextStyle.NARROW), fontSize = 10.sp, color = Color(0xFF1F4A75))
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .then(
                            if (on) Modifier.shadow(10.dp, CircleShape, ambientColor = Color(0xFF7CFC00), spotColor = Color(0xFF7CFC00))
                            else Modifier
                        )
                        .size(34.dp)
                        .background(
                            Brush.verticalGradient(
                                if (on) listOf(Color(0xFF9AF26A), Color(0xFF2FA52A))
                                else listOf(Color(0xE6FFFFFF), Color(0x66FFFFFF))
                            ),
                            CircleShape
                        )
                        .border(1.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        d.dayOfMonth.toString(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = if (on) Color.White else Color(0xFF0A3A78)
                    )
                }
            }
        }
    }
}

@Composable
private fun AeroList(vm: PlanVm) {
    val pill = RoundedCornerShape(14.dp)
    val list = vm.dayItems
    if (list.isEmpty()) com.odak.app.theme.PlanEmpty(Color(0xFF24527F))
    list.forEach { p ->
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .height(52.dp)
                .clip(pill)
                .aeroGlass(pill, Color(0xFFCDECFF))
                .border(1.dp, Color.White, pill)
                .plainClick { vm.startEdit(p) }
                .padding(start = 10.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ThemedCheck(p.done) { vm.toggle(p, it) }
            Spacer(Modifier.width(12.dp))
            Text(
                titleWithDot(p),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                textDecoration = if (p.done) TextDecoration.LineThrough else null,
                modifier = Modifier.weight(1f)
            )
            Text(timeOf(p), fontSize = 11.sp, color = Color(0xFF24527F))
            DeleteMark(Color(0xFF3A6A98)) { vm.remove(p) }
        }
    }
}

// =====================================================================
// MİNİMAL: tipografi, çizgi
// =====================================================================
@Composable
fun MinimalPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val skin = skinFor(DesignStyle.MINIMAL)
    Column(scroller().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 16.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.End, Alignment.CenterVertically) {
            PeriodSelector(periodLabels(), vm.period.ordinal, { vm.setPeriod(Period.entries[it]) })
        }
        Spacer(Modifier.height(6.dp))
        val big = when (vm.period) {
            Period.DAY -> vm.anchor.dayOfMonth.toString()
            Period.WEEK -> weekNumber(vm.anchor).toString()
            Period.MONTH -> monthName(vm.anchor)
        }
        val bigSize = when (vm.period) {
            Period.DAY -> 120.sp
            Period.WEEK -> 86.sp
            Period.MONTH -> 64.sp
        }
        Text(
            big,
            fontSize = bigSize,
            lineHeight = bigSize,
            letterSpacing = (-4).sp,
            fontWeight = FontWeight.Light,
            color = t.text,
            maxLines = 1
        )
        Spacer(Modifier.height(4.dp))
        NavRow(vm)
        Spacer(Modifier.height(14.dp))
        when (vm.period) {
            Period.DAY -> MinList(vm)
            Period.WEEK -> WeekGrid(vm.items, vm.weekStart, vm.today, skin, hourHeight = 38.dp, onPickDay = vm.pickDay)
            Period.MONTH -> {
                MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 56.dp, onPickDay = vm.setAnchor)
                Spacer(Modifier.height(14.dp))
                MinList(vm)
            }
        }
        Spacer(Modifier.height(20.dp))
        AddRow(vm)
    }
}

@Composable
private fun MinWeekStrip(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
        for (i in 0..6) {
            val d = vm.weekStart.plusDays(i.toLong())
            val on = d == vm.anchor
            Column(Modifier.plainClick { vm.setAnchor(d) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(dayName(d, JTextStyle.NARROW), fontSize = 11.sp, color = Color(0xFF6B6B6B))
                Text(
                    d.dayOfMonth.toString(),
                    fontSize = 15.sp,
                    color = t.text,
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .then(
                            if (on) Modifier.drawBehind {
                                drawLine(
                                    t.text,
                                    Offset(0f, size.height),
                                    Offset(size.width, size.height),
                                    1.dp.toPx()
                                )
                            } else Modifier
                        )
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun MinList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) com.odak.app.theme.PlanEmpty(Color(0xFF595959))
    list.forEach { p ->
        Row(
            Modifier.fillMaxWidth().hairlineBottom(Color(0xFFECEBE6), 1f).plainClick { vm.startEdit(p) }.padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ThemedCheck(p.done) { vm.toggle(p, it) }
            Spacer(Modifier.width(14.dp))
            Text(
                titleWithDot(p),
                fontSize = 17.sp,
                color = if (p.done) Color(0xFFB0B0B0) else t.text,
                textDecoration = if (p.done) TextDecoration.LineThrough else null,
                modifier = Modifier.weight(1f)
            )
            Text(timeOf(p), fontSize = 11.sp, color = Color(0xFF6B6B6B))
            DeleteMark(Color(0xFFB0B0B0)) { vm.remove(p) }
        }
    }
}

// =====================================================================
// WINDOWS 11: Fluent, takvim kartı + gruplu liste
// =====================================================================
@Composable
fun WindowsPlan(vm: PlanVm) {
    val skin = skinFor(DesignStyle.WINDOWS11)
    Column(scroller().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(stringResource(R.string.tab_plan), fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        PeriodSelector(periodLabels(), vm.period.ordinal, { vm.setPeriod(Period.entries[it]) })
        Spacer(Modifier.height(10.dp))
        NavRow(vm)
        Spacer(Modifier.height(10.dp))
        when (vm.period) {
            Period.DAY -> {
                ThemedCard(Modifier.fillMaxWidth()) {
                    MonthGrid(
                        vm.items, vm.month, vm.today, vm.anchor, skin,
                        cellHeight = 36.dp, marks = Marks.DOTS, onPickDay = vm.setAnchor
                    )
                }
                Spacer(Modifier.height(12.dp))
                WinList(vm)
            }
            Period.WEEK -> ThemedCard(Modifier.fillMaxWidth()) {
                WeekGrid(vm.items, vm.weekStart, vm.today, skin, hourHeight = 38.dp, onPickDay = vm.pickDay)
            }
            Period.MONTH -> {
                ThemedCard(Modifier.fillMaxWidth()) {
                    MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 66.dp, onPickDay = vm.setAnchor)
                }
                Spacer(Modifier.height(12.dp))
                WinList(vm)
            }
        }
        Spacer(Modifier.height(16.dp))
        AddRow(vm)
    }
}

@Composable
private fun WinList(vm: PlanVm) {
    val list = vm.dayItems
    val head = vm.anchor.format(DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault()))
    Text(
        "$head · ${list.count { it.done }}/${list.size}",
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = Color(0xFF333333)
    )
    Spacer(Modifier.height(6.dp))
    if (list.isEmpty()) {
        com.odak.app.theme.PlanEmpty(Color(0xFF595959))
        return
    }
    ThemedCard(Modifier.fillMaxWidth()) {
        list.forEachIndexed { i, p ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .then(if (i < list.lastIndex) Modifier.hairlineBottom(Color(0x12000000), 1f) else Modifier)
                    .plainClick { vm.startEdit(p) }
                    .padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p),
                        fontSize = 14.sp,
                        color = if (p.done) Color(0xFF6B6B6B) else Color(0xFF1A1A1A),
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text(timeOf(p), fontSize = 11.sp, color = Color(0xFF595959))
                }
                DeleteMark(Color(0xFF999999)) { vm.remove(p) }
            }
        }
    }
}

// =====================================================================
// NEON: synthwave
// =====================================================================
@Composable
fun NeonPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val skin = skinFor(DesignStyle.NEON)
    val pink = Color(0xFFFF2A6D)
    Box(scroller()) {
        if (vm.period == Period.DAY) NeonScenery()
        Column(scroller().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(
                "ODAK",
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 12.sp,
                color = Color(0xFFFFD6E8),
                textAlign = TextAlign.Center,
                style = LocalTextStyle.current.copy(shadow = Shadow(pink, blurRadius = 40f)),
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "${vm.anchor.dayOfMonth} · ${vm.anchor.month.getDisplayName(JTextStyle.SHORT, Locale.getDefault()).uppercase(Locale.getDefault())} · ${dayName(vm.anchor, JTextStyle.SHORT).uppercase(Locale.getDefault())}",
                fontSize = 12.sp,
                letterSpacing = 6.sp,
                color = t.accent,
                textAlign = TextAlign.Center,
                style = LocalTextStyle.current.copy(shadow = Shadow(t.accent, blurRadius = 16f)),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                PeriodSelector(periodLabels(), vm.period.ordinal, { vm.setPeriod(Period.entries[it]) })
            }
            Spacer(Modifier.height(12.dp))
            NavRow(vm)
            Spacer(Modifier.height(12.dp))
            when (vm.period) {
                Period.DAY -> NeonList(vm)
                Period.WEEK -> WeekGrid(vm.items, vm.weekStart, vm.today, skin, hourHeight = 38.dp, onPickDay = vm.pickDay)
                Period.MONTH -> {
                    MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 58.dp, onPickDay = vm.setAnchor)
                    Spacer(Modifier.height(12.dp))
                    NeonList(vm)
                }
            }
            Spacer(Modifier.height(16.dp))
            AddRow(vm)
        }
    }
}

@Composable
private fun NeonScenery() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val horizon = h * 0.64f
        val r = w * 0.27f
        val cx = w / 2f
        drawCircle(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFFFE45E), Color(0xFFFF2A6D), Color(0xFFB100E8)),
                startY = horizon - 2 * r,
                endY = horizon
            ),
            radius = r,
            center = Offset(cx, horizon - r),
            alpha = 0.55f
        )
        drawRect(Color(0xFF01012B), topLeft = Offset(0f, horizon), size = Size(w, h - horizon))
        for (i in -9..9) {
            drawLine(Color(0xCC05D9E8), Offset(cx, horizon), Offset(cx + i * (w / 5f), h), 2f)
        }
        for (k in 1..9) {
            val f = k / 9f
            val y = horizon + (h - horizon) * f * f
            drawLine(Color(0xCCFF2A6D), Offset(0f, y), Offset(w, y), 2f)
        }
        drawLine(Color(0xFFFF2A6D), Offset(0f, horizon), Offset(w, horizon), 4f)
    }
}

@Composable
private fun NeonList(vm: PlanVm) {
    val colors = listOf(Color(0xFFFF2A6D), Color(0xFF05D9E8), Color(0xFFB66BFF))
    val list = vm.dayItems
    if (list.isEmpty()) {
        com.odak.app.theme.PlanEmpty(Color(0xFF8FA4D8))
    }
    list.forEachIndexed { i, p ->
        val c = colors[i % 3]
        val shape = RoundedCornerShape(30.dp)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
                .height(54.dp)
                .shadow(10.dp, shape, ambientColor = c, spotColor = c)
                .background(Color(0xD1080432), shape)
                .border(2.dp, c, shape)
                .plainClick { vm.startEdit(p) }
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ThemedCheck(p.done) { vm.toggle(p, it) }
            Spacer(Modifier.width(14.dp))
            Text(
                titleWithDot(p),
                fontSize = 14.sp,
                letterSpacing = 1.sp,
                color = Color(0xFFE8FBFF),
                textDecoration = if (p.done) TextDecoration.LineThrough else null,
                modifier = Modifier.weight(1f)
            )
            Text(timeOf(p), fontSize = 11.sp, color = c)
            DeleteMark(c) { vm.remove(p) }
        }
    }
}
