package com.odak.app.block

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import com.odak.app.R
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.ZoneId

class Feat(val id: String, val res: Int? = null, val text: String? = null)

class BlockApp(
    val id: String,
    val name: String,
    val packages: List<String>,
    val features: List<Feat>
)

object BlockCatalog {
    private val base = listOf(
        BlockApp("youtube", "YouTube", listOf("com.google.android.youtube"), listOf(Feat("shorts", text = "Shorts"), Feat("search", R.string.feat_search), Feat("comments", R.string.feat_comments))),
        BlockApp("instagram", "Instagram", listOf("com.instagram.android"), listOf(Feat("reels", text = "Reels"), Feat("stories", R.string.feat_stories), Feat("dm", R.string.feat_dm), Feat("explore", R.string.feat_explore), Feat("shop", R.string.feat_shop))),
        BlockApp("tiktok", "TikTok", listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"), listOf(Feat("feed", R.string.feat_short_video), Feat("dm", R.string.feat_dm), Feat("search", R.string.feat_search), Feat("live", R.string.feat_live))),
        BlockApp("facebook", "Facebook", listOf("com.facebook.katana"), listOf(Feat("reels", text = "Reels"), Feat("stories", R.string.feat_stories), Feat("marketplace", R.string.feat_market), Feat("watch", R.string.feat_video), Feat("groups", R.string.feat_groups))),
        BlockApp("messenger", "Messenger", listOf("com.facebook.orca"), emptyList()),
        BlockApp("x", "X", listOf("com.twitter.android"), listOf(Feat("feed", R.string.feat_feed), Feat("dm", R.string.feat_dm), Feat("search", R.string.feat_search))),
        BlockApp("snapchat", "Snapchat", listOf("com.snapchat.android"), listOf(Feat("stories", R.string.feat_stories), Feat("spotlight", text = "Spotlight"), Feat("chat", R.string.feat_chat))),
        BlockApp("telegram", "Telegram", listOf("org.telegram.messenger"), emptyList()),
        BlockApp("whatsapp", "WhatsApp", listOf("com.whatsapp"), listOf(Feat("stories", R.string.feat_stories))),
        BlockApp("pinterest", "Pinterest", listOf("com.pinterest"), emptyList()),
        BlockApp("twitch", "Twitch", listOf("tv.twitch.android.app"), emptyList()),
        BlockApp("discord", "Discord", listOf("com.discord"), emptyList()),
        BlockApp("linkedin", "LinkedIn", listOf("com.linkedin.android"), listOf(Feat("video", R.string.feat_video), Feat("jobs", R.string.feat_jobs))),
        BlockApp("netflix", "Netflix", listOf("com.netflix.mediaclient"), listOf(Feat("games", R.string.feat_games))),
        BlockApp("reddit", "Reddit", listOf("com.reddit.frontpage"), listOf(Feat("feed", R.string.feat_feed), Feat("chat", R.string.feat_chat))),
        BlockApp("threads", "Threads", listOf("com.instagram.barcelona"), emptyList()),
        BlockApp("bluesky", "Bluesky", listOf("xyz.blueskyweb.app"), emptyList()),
        BlockApp("mastodon", "Mastodon", listOf("org.joinmastodon.android"), emptyList()),
        BlockApp("tumblr", "Tumblr", listOf("com.tumblr"), emptyList()),
        BlockApp("bereal", "BeReal", listOf("com.bereal.ft"), emptyList()),
        BlockApp("likee", "Likee", listOf("video.like"), emptyList()),
        BlockApp("kwai", "Kwai", listOf("com.kwai.video"), emptyList()),
        BlockApp("fblite", "Facebook Lite", listOf("com.facebook.lite"), emptyList()),
        BlockApp("iglite", "Instagram Lite", listOf("com.instagram.lite"), emptyList()),
        BlockApp("tiktoklite", "TikTok Lite", listOf("com.zhiliaoapp.musically.go"), emptyList()),
        BlockApp("quora", "Quora", listOf("com.quora.android"), emptyList()),
        BlockApp("medium", "Medium", listOf("com.medium.reader"), emptyList()),
        BlockApp("imgur", "Imgur", listOf("com.imgur.mobile"), emptyList()),
        BlockApp("9gag", "9GAG", listOf("com.ninegag.android.app"), emptyList()),
        BlockApp("ytmusic", "YouTube Music", listOf("com.google.android.apps.youtube.music"), emptyList()),
        BlockApp("disney", "Disney+", listOf("com.disney.disneyplus"), emptyList()),
        BlockApp("prime", "Prime Video", listOf("com.amazon.avod.thirdpartyclient"), emptyList()),
        BlockApp("max", "Max", listOf("com.wbd.stream"), emptyList()),
        BlockApp("hulu", "Hulu", listOf("com.hulu.plus"), emptyList()),
        BlockApp("crunchy", "Crunchyroll", listOf("com.crunchyroll.crunchyroid"), emptyList()),
        BlockApp("vimeo", "Vimeo", listOf("com.vimeo.android.videoapp"), emptyList()),
        BlockApp("spotify", "Spotify", listOf("com.spotify.music"), emptyList()),
        BlockApp("soundcloud", "SoundCloud", listOf("com.soundcloud.android"), emptyList()),
        BlockApp("deezer", "Deezer", listOf("deezer.android.app"), emptyList()),
        BlockApp("signal", "Signal", listOf("org.thoughtcrime.securesms"), emptyList()),
        BlockApp("viber", "Viber", listOf("com.viber.voip"), emptyList()),
        BlockApp("line", "LINE", listOf("jp.naver.line.android"), emptyList()),
        BlockApp("wechat", "WeChat", listOf("com.tencent.mm"), emptyList()),
        BlockApp("skype", "Skype", listOf("com.skype.raider"), emptyList()),
        BlockApp("slack", "Slack", listOf("com.Slack"), emptyList()),
        BlockApp("teams", "Microsoft Teams", listOf("com.microsoft.teams"), emptyList()),
        BlockApp("tinder", "Tinder", listOf("com.tinder"), emptyList()),
        BlockApp("bumble", "Bumble", listOf("com.bumble.app"), emptyList()),
        BlockApp("hinge", "Hinge", listOf("co.hinge.app"), emptyList()),
        BlockApp("roblox", "Roblox", listOf("com.roblox.client"), emptyList()),
        BlockApp("minecraft", "Minecraft", listOf("com.mojang.minecraftpe"), emptyList()),
        BlockApp("coc", "Clash of Clans", listOf("com.supercell.clashofclans"), emptyList()),
        BlockApp("clashroyale", "Clash Royale", listOf("com.supercell.clashroyale"), emptyList()),
        BlockApp("brawl", "Brawl Stars", listOf("com.supercell.brawlstars"), emptyList()),
        BlockApp("pubg", "PUBG Mobile", listOf("com.tencent.ig"), emptyList()),
        BlockApp("freefire", "Free Fire", listOf("com.dts.freefireth"), emptyList()),
        BlockApp("candy", "Candy Crush Saga", listOf("com.king.candycrushsaga"), emptyList()),
        BlockApp("subway", "Subway Surfers", listOf("com.kiloo.subwaysurf"), emptyList()),
        BlockApp("amongus", "Among Us", listOf("com.innersloth.spacemafia"), emptyList()),
        BlockApp("genshin", "Genshin Impact", listOf("com.miHoYo.GenshinImpact"), emptyList()),
        BlockApp("codm", "Call of Duty Mobile", listOf("com.activision.callofduty.shooter"), emptyList()),
        BlockApp("amazon", "Amazon", listOf("com.amazon.mShop.android.shopping"), emptyList()),
        BlockApp("aliexpress", "AliExpress", listOf("com.alibaba.aliexpresshd"), emptyList()),
        BlockApp("temu", "Temu", listOf("com.einnovation.temu"), emptyList()),
        BlockApp("shein", "SHEIN", listOf("com.zzkko"), emptyList()),
        BlockApp("ebay", "eBay", listOf("com.ebay.mobile"), emptyList()),
        BlockApp("trendyol", "Trendyol", listOf("trendyol.com"), emptyList()),
        BlockApp("hepsiburada", "Hepsiburada", listOf("com.pozitron.hepsiburada"), emptyList()),
        BlockApp("lemon8", "Lemon8", listOf("com.bd.nproject"), emptyList()),
        BlockApp("capcut", "CapCut", listOf("com.lemon.lvoverseas"), emptyList()),
        BlockApp("triller", "Triller", listOf("co.triller.droid"), emptyList()),
        BlockApp("dailymotion", "Dailymotion", listOf("com.dailymotion.dailymotion"), emptyList()),
        BlockApp("vk", "VK", listOf("com.vkontakte.android"), emptyList()),
        BlockApp("weibo", "Weibo", listOf("com.sina.weibo"), emptyList()),
        BlockApp("zalo", "Zalo", listOf("com.zing.zalo"), emptyList()),
        BlockApp("kakao", "KakaoTalk", listOf("com.kakao.talk"), emptyList()),
        BlockApp("imo", "imo", listOf("com.imo.android.imoim"), emptyList()),
        BlockApp("telegramx", "Telegram X", listOf("org.thunderdog.challegram"), emptyList()),
        BlockApp("meet", "Google Meet", listOf("com.google.android.apps.tachyon"), emptyList()),
        BlockApp("zoom", "Zoom", listOf("us.zoom.videomeetings"), emptyList()),
        BlockApp("gchat", "Google Chat", listOf("com.google.android.apps.dynamite"), emptyList()),
        BlockApp("tango", "Tango", listOf("com.sgiggle.production"), emptyList()),
        BlockApp("bigo", "Bigo Live", listOf("sg.bigo.live"), emptyList()),
        BlockApp("azar", "Azar", listOf("com.azarlive.android"), emptyList()),
        BlockApp("badoo", "Badoo", listOf("com.badoo.mobile"), emptyList()),
        BlockApp("grindr", "Grindr", listOf("com.grindrapp.android"), emptyList()),
        BlockApp("getir", "Getir", listOf("com.getir"), emptyList()),
        BlockApp("yemeksepeti", "Yemeksepeti", listOf("com.inovel.app.yemeksepeti"), emptyList()),
        BlockApp("sahibinden", "Sahibinden", listOf("com.sahibinden"), emptyList()),
        BlockApp("letgo", "letgo", listOf("com.abtnprojects.ambatana"), emptyList()),
        BlockApp("etsy", "Etsy", listOf("com.etsy.android"), emptyList()),
        BlockApp("walmart", "Walmart", listOf("com.walmart.android"), emptyList()),
        BlockApp("zalando", "Zalando", listOf("de.zalando.mobile"), emptyList()),
        BlockApp("tubi", "Tubi", listOf("com.tubitv"), emptyList()),
        BlockApp("plutotv", "Pluto TV", listOf("tv.pluto.android"), emptyList()),
        BlockApp("paramount", "Paramount+", listOf("com.cbs.app"), emptyList()),
        BlockApp("peacock", "Peacock", listOf("com.peacocktv.peacockandroid"), emptyList()),
        BlockApp("applemusic", "Apple Music", listOf("com.apple.android.music"), emptyList()),
        BlockApp("tidal", "TIDAL", listOf("com.aspiro.tidal"), emptyList()),
        BlockApp("audible", "Audible", listOf("com.audible.application"), emptyList()),
        BlockApp("pandora", "Pandora", listOf("com.pandora.android"), emptyList()),
        BlockApp("amazonmusic", "Amazon Music", listOf("com.amazon.mp3"), emptyList()),
        BlockApp("ytkids", "YouTube Kids", listOf("com.google.android.apps.youtube.kids"), emptyList()),
        BlockApp("podcastaddict", "Podcast Addict", listOf("com.bambuna.podcastaddict"), emptyList()),
        BlockApp("wattpad", "Wattpad", listOf("wp.wattpad"), emptyList()),
        BlockApp("webtoon", "WEBTOON", listOf("com.naver.linewebtoon"), emptyList()),
        BlockApp("kindle", "Kindle", listOf("com.amazon.kindle"), emptyList()),
        BlockApp("mlbb", "Mobile Legends", listOf("com.mobile.legends"), emptyList()),
        BlockApp("pokemongo", "Pokémon GO", listOf("com.nianticlabs.pokemongo"), emptyList()),
        BlockApp("candysoda", "Candy Crush Soda", listOf("com.king.candycrushsodasaga"), emptyList()),
        BlockApp("coinmaster", "Coin Master", listOf("com.moonactive.coinmaster"), emptyList()),
        BlockApp("eightball", "8 Ball Pool", listOf("com.miniclip.eightballpool"), emptyList()),
        BlockApp("ludoking", "Ludo King", listOf("com.ludo.king"), emptyList()),
        BlockApp("templerun", "Temple Run 2", listOf("com.imangi.templerun2"), emptyList()),
        BlockApp("hayday", "Hay Day", listOf("com.supercell.hayday"), emptyList()),
        BlockApp("eafc", "EA FC Mobile", listOf("com.ea.gp.fifamobile"), emptyList()),
        BlockApp("wildrift", "Wild Rift", listOf("com.riotgames.league.wildrift"), emptyList()),
        BlockApp("stumble", "Stumble Guys", listOf("com.kitkagames.fallbuddies"), emptyList()),
        BlockApp("township", "Township", listOf("com.playrix.township"), emptyList()),
        BlockApp("gardenscapes", "Gardenscapes", listOf("com.playrix.gardenscapes"), emptyList()),
        BlockApp("homescapes", "Homescapes", listOf("com.playrix.homescapes"), emptyList()),
        BlockApp("royalmatch", "Royal Match", listOf("com.dreamgames.royalmatch"), emptyList()),
        BlockApp("blockblast", "Block Blast", listOf("com.block.juggle"), emptyList()),
        BlockApp("lordsmobile", "Lords Mobile", listOf("com.igg.android.lordsmobile"), emptyList()),
        BlockApp("monopolygo", "Monopoly GO", listOf("com.scopely.monopolygo"), emptyList()),
        BlockApp("zyngapoker", "Zynga Poker", listOf("com.zynga.livepoker"), emptyList()),
        BlockApp("geometrydash", "Geometry Dash", listOf("com.robtopx.geometryjump"), emptyList()),
        BlockApp("hillclimb", "Hill Climb Racing", listOf("com.fingersoft.hillclimb"), emptyList()),
        BlockApp("pvz2", "Plants vs. Zombies 2", listOf("com.ea.game.pvz2_row"), emptyList()),
        BlockApp("angrybirds", "Angry Birds 2", listOf("com.rovio.baba"), emptyList()),
        BlockApp("fruitninja", "Fruit Ninja", listOf("com.halfbrick.fruitninja"), emptyList()),
        BlockApp("dls", "Dream League Soccer", listOf("com.firsttouchgames.dls7"), emptyList()),
        BlockApp("efootball", "eFootball", listOf("jp.konami.pesam"), emptyList()),
        BlockApp("standoff2", "Standoff 2", listOf("com.axlebolt.standoff2"), emptyList()),
        BlockApp("clubhouse", "Clubhouse", listOf("com.clubhouse.app"), emptyList()),
        BlockApp("sharechat", "ShareChat", listOf("in.mohalla.sharechat"), emptyList()),
        BlockApp("moj", "Moj", listOf("in.mohalla.video"), emptyList()),
        BlockApp("snackvideo", "SnackVideo", listOf("com.kwai.bulldog"), emptyList()),
        BlockApp("kik", "Kik", listOf("kik.android"), emptyList()),
        BlockApp("element", "Element", listOf("im.vector.app"), emptyList()),
        BlockApp("threema", "Threema", listOf("ch.threema.app"), emptyList()),
        BlockApp("gmessages", "Google Messages", listOf("com.google.android.apps.messaging"), emptyList()),
        BlockApp("pocketcasts", "Pocket Casts", listOf("au.com.shiftyjelly.pocketcasts"), emptyList()),
        BlockApp("exxen", "Exxen", listOf("com.exxen.android"), emptyList()),
        BlockApp("mxplayer", "MX Player", listOf("com.mxtech.videoplayer.ad"), emptyList()),
        BlockApp("steam", "Steam", listOf("com.valvesoftware.android.steam.community"), emptyList()),
        BlockApp("dolap", "Dolap", listOf("com.dolap.android"), emptyList()),
        BlockApp("trendyolgo", "Trendyol Go", listOf("com.trendyol.go"), emptyList()),
        BlockApp("ubereats", "Uber Eats", listOf("com.ubercab.eats"), emptyList()),
        BlockApp("uber", "Uber", listOf("com.ubercab"), emptyList()),
        BlockApp("booking", "Booking.com", listOf("com.booking"), emptyList()),
        BlockApp("airbnb", "Airbnb", listOf("com.airbnb.android"), emptyList()),
        BlockApp("tripadvisor", "Tripadvisor", listOf("com.tripadvisor.tripadvisor"), emptyList()),
        BlockApp("talkingtom", "My Talking Tom", listOf("com.outfit7.mytalkingtomfree"), emptyList()),
        BlockApp("talkingtom2", "My Talking Tom 2", listOf("com.outfit7.mytalkingtom2"), emptyList()),
        BlockApp("toca", "Toca Boca World", listOf("com.tocaboca.tocalifeworld"), emptyList()),
        BlockApp("carrom", "Carrom Pool", listOf("com.miniclip.carrom"), emptyList()),
        BlockApp("freefiremax", "Free Fire MAX", listOf("com.dts.freefiremax"), emptyList()),
        BlockApp("bgmi", "BGMI", listOf("com.pubg.imobile"), emptyList()),
        BlockApp("hsr", "Honkai: Star Rail", listOf("com.HoYoverse.hkrpgoversea"), emptyList()),
        BlockApp("mariokart", "Mario Kart Tour", listOf("com.nintendo.zaka"), emptyList()),
        BlockApp("arenabreakout", "Arena Breakout", listOf("com.proximabeta.mf.uamo"), emptyList()),
        BlockApp("wordsofwonders", "Words of Wonders", listOf("com.fugo.wow"), emptyList()),
        BlockApp("wordscapes", "Wordscapes", listOf("com.peoplefun.wordcross"), emptyList()),
        BlockApp("woodoku", "Woodoku", listOf("com.tripledot.woodoku"), emptyList()),
        BlockApp("slotomania", "Slotomania", listOf("air.com.playtika.slotomania"), emptyList()),
        BlockApp("minionrush", "Minion Rush", listOf("com.gameloft.android.ANMP.GloftDMHM"), emptyList()),
        BlockApp("asphalt9", "Asphalt Legends", listOf("com.gameloft.android.ANMP.GloftA9HM"), emptyList()),
        BlockApp("realracing3", "Real Racing 3", listOf("com.ea.games.r3_row"), emptyList()),
        BlockApp("nfsnl", "Need for Speed No Limits", listOf("com.ea.game.nfs14_row"), emptyList()),
        BlockApp("squadbusters", "Squad Busters", listOf("com.supercell.squad"), emptyList()),
        BlockApp("boombeach", "Boom Beach", listOf("com.supercell.boombeach"), emptyList()),
        BlockApp("duolingo", "Duolingo", listOf("com.duolingo"), emptyList()),
        BlockApp("chrome", "Google Chrome", listOf("com.android.chrome"), emptyList()),
        BlockApp("nextdoor", "Nextdoor", listOf("com.nextdoor"), emptyList()),
        BlockApp("strava", "Strava", listOf("com.strava"), emptyList()),
        BlockApp("goodreads", "Goodreads", listOf("com.goodreads"), emptyList()),
        BlockApp("ifunny", "iFunny", listOf("mobi.ifunny"), emptyList()),
        BlockApp("hotstar", "JioHotstar", listOf("in.startv.hotstar"), emptyList()),
        BlockApp("lazada", "Lazada", listOf("com.lazada.android"), emptyList()),
        BlockApp("mercadolibre", "Mercado Libre", listOf("com.mercadolibre"), emptyList()),
        BlockApp("ozon", "OZON", listOf("ru.ozon.app.android"), emptyList()),
        BlockApp("rok", "Rise of Kingdoms", listOf("com.lilithgame.roc.gp"), emptyList()),
        BlockApp("sos", "State of Survival", listOf("com.kingsgroup.sos"), emptyList()),
        BlockApp("whiteout", "Whiteout Survival", listOf("com.gof.global"), emptyList()),
        BlockApp("afkarena", "AFK Arena", listOf("com.lilithgame.hgame.gp"), emptyList()),
        BlockApp("raid", "RAID: Shadow Legends", listOf("com.plarium.raidlegends"), emptyList()),
        BlockApp("flipboard", "Flipboard", listOf("flipboard.app"), emptyList()),
        BlockApp("allegro", "Allegro", listOf("pl.allegro"), emptyList()),
        BlockApp("firefox", "Firefox", listOf("org.mozilla.firefox"), emptyList()),
        BlockApp("opera", "Opera", listOf("com.opera.browser"), emptyList()),
        BlockApp("brave", "Brave", listOf("com.brave.browser"), emptyList()),
        BlockApp("edge", "Microsoft Edge", listOf("com.microsoft.emmx"), emptyList()),
        BlockApp("wildberries", "Wildberries", listOf("com.wildberries.ru"), emptyList()),
        BlockApp("bilibili", "Bilibili", listOf("tv.danmaku.bili"), emptyList()),
        BlockApp("rumble", "Rumble", listOf("com.rumble.battles"), emptyList()),
        BlockApp("kick", "Kick", listOf("com.kick.mobile"), emptyList()),
        BlockApp("odysee", "Odysee", listOf("com.odysee.android"), emptyList()),
        BlockApp("hago", "Hago", listOf("com.yy.hiyo"), emptyList()),
        BlockApp("yubo", "Yubo", listOf("co.yellw.yellowapp"), emptyList()),
        BlockApp("flipkart", "Flipkart", listOf("com.flipkart.android"), emptyList()),
        BlockApp("meesho", "Meesho", listOf("com.meesho.supply"), emptyList()),
        BlockApp("myntra", "Myntra", listOf("com.myntra.android"), emptyList()),
        BlockApp("vinted", "Vinted", listOf("fr.vinted"), emptyList()),
        BlockApp("depop", "Depop", listOf("com.depop"), emptyList()),
        BlockApp("wish", "Wish", listOf("com.contextlogic.wish"), emptyList()),
        BlockApp("joom", "Joom", listOf("com.joom"), emptyList()),
        BlockApp("bip", "BiP", listOf("com.turkcell.bip"), emptyList()),
        BlockApp("pokemonunite", "Pokémon UNITE", listOf("com.pokemon.unite"), emptyList()),
        BlockApp("honorofkings", "Honor of Kings", listOf("com.levelinfinite.sgameGlobal"), emptyList()),
        BlockApp("hungryshark", "Hungry Shark Evolution", listOf("com.fgol.HungrySharkEvolution"), emptyList()),
        BlockApp("diabloimmortal", "Diablo Immortal", listOf("com.blizzard.diablo.immortal"), emptyList()),
        BlockApp("marvelsnap", "Marvel Snap", listOf("com.nvsgames.snap"), emptyList()),
        BlockApp("zooba", "Zooba", listOf("com.wildlife.games.battle.royale.free.zooba"), emptyList()),
        BlockApp("rushroyale", "Rush Royale", listOf("com.my.defense"), emptyList()),
        BlockApp("mergedragons", "Merge Dragons", listOf("com.gramgames.mergedragons"), emptyList()),
        BlockApp("gachaclub", "Gacha Club", listOf("air.com.lunime.gachaclub"), emptyList()),
        BlockApp("lastwar", "Last War: Survival", listOf("com.fun.lastwar.gp"), emptyList()),
        BlockApp("lastday", "Last Day on Earth", listOf("zombie.survival.craft.z"), emptyList()),
        BlockApp("bloonstd6", "Bloons TD 6", listOf("com.ninjakiwi.bloonstd6"), emptyList()),
        BlockApp("terraria", "Terraria", listOf("com.and.games505.TerrariaPaid"), emptyList()),
        BlockApp("stardew", "Stardew Valley", listOf("com.chucklefish.stardewvalley"), emptyList()),
        BlockApp("gtasa", "GTA: San Andreas", listOf("com.rockstargames.gtasa"), emptyList()),
        BlockApp("cookierun", "Cookie Run: Kingdom", listOf("com.devsisters.ck"), emptyList()),
        BlockApp("fgo", "Fate/Grand Order", listOf("com.aniplex.fategrandorder.en"), emptyList()),
        BlockApp("zzz", "Zenless Zone Zero", listOf("com.HoYoverse.Nap"), emptyList()),
        BlockApp("wuwa", "Wuthering Waves", listOf("com.kurogame.wutheringwaves.global"), emptyList()),
        BlockApp("bluearchive", "Blue Archive", listOf("com.nexon.bluearchive"), emptyList()),
        BlockApp("nikke", "NIKKE", listOf("com.proximabeta.nikke"), emptyList()),
        BlockApp("toweroffantasy", "Tower of Fantasy", listOf("com.levelinfinite.hotta.gp"), emptyList()),
        BlockApp("weverse", "Weverse", listOf("co.benx.weverse"), emptyList()),
        BlockApp("pixiv", "pixiv", listOf("jp.pxv.android"), emptyList()),
        BlockApp("deviantart", "DeviantArt", listOf("com.deviantart.android.damobile"), emptyList()),
        BlockApp("letterboxd", "Letterboxd", listOf("com.letterboxd.letterboxd"), emptyList()),
        BlockApp("vsco", "VSCO", listOf("com.vsco.cam"), emptyList()),
        BlockApp("josh", "Josh", listOf("com.eterno.shortvideos"), emptyList()),
        BlockApp("chingari", "Chingari", listOf("io.chingari.app"), emptyList()),
        BlockApp("roposo", "Roposo", listOf("com.roposo.android"), emptyList()),
        BlockApp("zee5", "ZEE5", listOf("com.graymatrix.did"), emptyList()),
        BlockApp("sonyliv", "SonyLIV", listOf("com.sonyliv"), emptyList()),
        BlockApp("viki", "Rakuten Viki", listOf("com.viki.android"), emptyList()),
        BlockApp("iqiyi", "iQIYI", listOf("com.iqiyi.i18n"), emptyList()),
        BlockApp("wetv", "WeTV", listOf("com.tencent.qqlivei18n"), emptyList()),
        BlockApp("viu", "Viu", listOf("com.vuclip.viu"), emptyList()),
        BlockApp("mubi", "MUBI", listOf("com.mubi"), emptyList()),
        BlockApp("plex", "Plex", listOf("com.plexapp.android"), emptyList()),
        BlockApp("kodi", "Kodi", listOf("org.xbmc.kodi"), emptyList()),
        BlockApp("jiosaavn", "JioSaavn", listOf("com.jio.media.jiobeats"), emptyList()),
        BlockApp("gaana", "Gaana", listOf("com.gaana"), emptyList()),
        BlockApp("anghami", "Anghami", listOf("com.anghami"), emptyList()),
        BlockApp("boomplay", "Boomplay", listOf("com.afmobi.boomplayer"), emptyList()),
        BlockApp("samsunginternet", "Samsung Internet", listOf("com.sec.android.app.sbrowser"), emptyList()),
        BlockApp("duckduckgo", "DuckDuckGo", listOf("com.duckduckgo.mobile.android"), emptyList()),
        BlockApp("ucbrowser", "UC Browser", listOf("com.UCMobile.intl"), emptyList()),
        BlockApp("yandexbrowser", "Yandex Browser", listOf("com.yandex.browser"), emptyList()),
        BlockApp("vivaldi", "Vivaldi", listOf("com.vivaldi.browser"), emptyList()),
        BlockApp("kiwi", "Kiwi Browser", listOf("com.kiwibrowser.browser"), emptyList()),
        BlockApp("pocket", "Pocket", listOf("com.ideashower.readitlater.pro"), emptyList()),
        BlockApp("feedly", "Feedly", listOf("com.devhd.feedly"), emptyList()),
        BlockApp("googlenews", "Google News", listOf("com.google.android.apps.magazines"), emptyList()),
        BlockApp("messengerlite", "Messenger Lite", listOf("com.facebook.mlite"), emptyList()),
        BlockApp("telegramweb", "Telegram (web)", listOf("org.telegram.messenger.web"), emptyList()),
        BlockApp("whatsappbiz", "WhatsApp Business", listOf("com.whatsapp.w4b"), emptyList()),
        BlockApp("session", "Session", listOf("network.loki.messenger"), emptyList()),
        BlockApp("wire", "Wire", listOf("com.wire"), emptyList()),
        BlockApp("groupme", "GroupMe", listOf("com.groupme.android"), emptyList()),
        BlockApp("textnow", "TextNow", listOf("com.enflick.android.TextNow"), emptyList()),
        BlockApp("okcupid", "OkCupid", listOf("com.okcupid.okcupid"), emptyList()),
        BlockApp("happn", "happn", listOf("com.ftw_and_co.happn"), emptyList()),
        BlockApp("feeld", "Feeld", listOf("co.feeld"), emptyList()),
        BlockApp("match", "Match", listOf("com.match.android.matchmobile"), emptyList()),
        BlockApp("pof", "Plenty of Fish", listOf("com.pof.android"), emptyList()),
        BlockApp("cmb", "Coffee Meets Bagel", listOf("com.coffeemeetsbagel"), emptyList()),
        BlockApp("hily", "Hily", listOf("com.hily.app"), emptyList()),
        BlockApp("muzz", "Muzz", listOf("com.muzmatch.muzmatchapp"), emptyList()),
        BlockApp("lovoo", "LOVOO", listOf("net.lovoo.android"), emptyList()),
        BlockApp("mamba", "Mamba", listOf("ru.mamba.client"), emptyList()),
        BlockApp("alibaba", "Alibaba.com", listOf("com.alibaba.intl.android.apps.poseidon"), emptyList()),
        BlockApp("dhgate", "DHgate", listOf("com.dhgate.buyer"), emptyList()),
        BlockApp("offerup", "OfferUp", listOf("com.offerup"), emptyList()),
        BlockApp("poshmark", "Poshmark", listOf("com.poshmark.app"), emptyList()),
        BlockApp("target", "Target", listOf("com.target.ui"), emptyList()),
        BlockApp("bestbuy", "Best Buy", listOf("com.bestbuy.android"), emptyList()),
        BlockApp("wayfair", "Wayfair", listOf("com.wayfair.wayfair"), emptyList()),
        BlockApp("hm", "H&M", listOf("com.hm"), emptyList()),
        BlockApp("zara", "Zara", listOf("com.inditex.zara"), emptyList()),
        BlockApp("nike", "Nike", listOf("com.nike.omega"), emptyList()),
        BlockApp("doordash", "DoorDash", listOf("com.dd.doordash"), emptyList()),
        BlockApp("grubhub", "Grubhub", listOf("com.grubhub.android"), emptyList()),
        BlockApp("glovo", "Glovo", listOf("com.glovo"), emptyList()),
        BlockApp("bolt", "Bolt", listOf("ee.mtakso.client"), emptyList()),
        BlockApp("lyft", "Lyft", listOf("me.lyft.android"), emptyList()),
        BlockApp("instacart", "Instacart", listOf("com.instacart.client"), emptyList()),
        BlockApp("pocketfm", "Pocket FM", listOf("com.radio.pocketfm"), emptyList()),
        BlockApp("storytel", "Storytel", listOf("grit.storytel.app"), emptyList()),
        BlockApp("scribd", "Scribd", listOf("com.scribd.app"), emptyList()),
        BlockApp("tapas", "Tapas", listOf("com.tapastic"), emptyList()),
        BlockApp("truthsocial", "Truth Social", listOf("com.truthsocial.android.app"), emptyList()),
        BlockApp("gettr", "GETTR", listOf("com.gettr.gettr"), emptyList())
    )

    /** Kullanıcının eklediği uygulamalar (id = "c:paket"). */
    val custom = androidx.compose.runtime.mutableStateListOf<BlockApp>()
    private val collator = java.text.Collator.getInstance().apply { strength = java.text.Collator.PRIMARY }
    private val sortedBase by lazy { base.sortedWith { a, b -> collator.compare(a.name, b.name) } }

    /** Alfabetik (yerel dile göre) sıralı tüm uygulamalar. */
    val apps: List<BlockApp> get() = (sortedBase + custom).sortedWith { a, b -> collator.compare(a.name, b.name) }

    fun byPackage(pkg: String): BlockApp? = apps.firstOrNull { pkg in it.packages }

    /** Engellenmemesi gereken sistem paketleri (kilitlenmeyi önler). */
    fun protectedPkg(c: Context, pkg: String): Boolean {
        if (pkg == c.packageName || pkg == "android" || pkg == "com.android.settings" ||
            pkg == "com.android.systemui" || pkg.contains("packageinstaller")
        ) return true
        val home = android.content.Intent(android.content.Intent.ACTION_MAIN)
            .addCategory(android.content.Intent.CATEGORY_HOME)
        return c.packageManager.queryIntentActivities(home, 0).any { it.activityInfo.packageName == pkg }
    }

    private fun cp(c: Context) = c.getSharedPreferences("odak_block", Context.MODE_PRIVATE)

    fun loadCustom(c: Context) {
        val raw = cp(c).getString("custom_apps", "") ?: ""
        val list = raw.lines().filter { it.contains("|") }.map {
            val pkg = it.substringBefore("|")
            BlockApp("c:$pkg", it.substringAfter("|"), listOf(pkg), emptyList())
        }
        custom.clear()
        custom.addAll(list)
    }

    private fun saveCustom(c: Context) {
        cp(c).edit().putString(
            "custom_apps",
            custom.joinToString("\n") { it.packages[0] + "|" + it.name.replace("\n", " ") }
        ).apply()
    }

    fun addCustom(c: Context, pkg: String, label: String) {
        if (custom.none { pkg in it.packages } && !protectedPkg(c, pkg)) {
            custom.add(BlockApp("c:$pkg", label, listOf(pkg), emptyList()))
            saveCustom(c)
        }
    }

    fun removeCustom(c: Context, id: String) {
        custom.removeAll { it.id == id }
        saveCustom(c)
        BlockStore.setAppBlocked(c, id, false)
        BlockStore.setAppLimit(c, id, 0)
    }
}

object BlockStore {
    private fun prefs(c: Context) = c.getSharedPreferences("odak_block", Context.MODE_PRIVATE)

    fun isAppBlocked(c: Context, app: String) = prefs(c).getBoolean("app:$app", false)
    fun setAppBlocked(c: Context, app: String, v: Boolean) = prefs(c).edit().putBoolean("app:$app", v).apply()

    fun isFeatureBlocked(c: Context, app: String, f: String) = prefs(c).getBoolean("feat:$app:$f", false)
    fun setFeatureBlocked(c: Context, app: String, f: String, v: Boolean) =
        prefs(c).edit().putBoolean("feat:$app:$f", v).apply()


    // ---- Günlük süre sınırları (dakika, 0 = sınırsız) ----
    fun appLimit(c: Context, app: String) = prefs(c).getInt("alim:$app", 0)
    fun setAppLimit(c: Context, app: String, m: Int) = prefs(c).edit().putInt("alim:$app", m).apply()
    fun featLimit(c: Context, app: String, f: String) = prefs(c).getInt("flim:$app:$f", 0)
    fun setFeatLimit(c: Context, app: String, f: String, m: Int) =
        prefs(c).edit().putInt("flim:$app:$f", m).apply()

    private fun day() = LocalDate.now().toString()
    fun featUsedMs(c: Context, app: String, f: String) = prefs(c).getLong("fu:${day()}:$app:$f", 0L)
    fun addFeatUsed(c: Context, app: String, f: String, ms: Long) =
        prefs(c).edit().putLong("fu:${day()}:$app:$f", featUsedMs(c, app, f) + ms).apply()

    // ---- Günlük açma sınırı ----
    fun openLimit(c: Context, app: String) = prefs(c).getInt("olim:$app", 0)
    fun setOpenLimit(c: Context, app: String, n: Int) = prefs(c).edit().putInt("olim:$app", n).apply()
    fun opensToday(c: Context, app: String) = prefs(c).getInt("oc:${day()}:$app", 0)
    fun registerOpen(c: Context, app: String, limit: Int): Int {
        val n = com.odak.app.logic.Pure.nextOpens(opensToday(c, app), limit)
        prefs(c).edit().putInt("oc:${day()}:$app", n).apply()
        return n
    }

    // ---- Zamanlı engel (gece) ----
    fun quietOn(c: Context) = prefs(c).getBoolean("q:on", false)
    fun setQuietOn(c: Context, v: Boolean) = prefs(c).edit().putBoolean("q:on", v).apply()
    fun quietFrom(c: Context) = prefs(c).getInt("q:from", 22 * 60)
    fun quietTo(c: Context) = prefs(c).getInt("q:to", 7 * 60)
    fun setQuietFrom(c: Context, m: Int) = prefs(c).edit().putInt("q:from", m).apply()
    fun setQuietTo(c: Context, m: Int) = prefs(c).edit().putInt("q:to", m).apply()
    fun quietDays(c: Context) = prefs(c).getInt("q:days", 127)
    fun setQuietDays(c: Context, m: Int) = prefs(c).edit().putInt("q:days", m).apply()
    fun appQuiet(c: Context, app: String) = prefs(c).getBoolean("q:app:$app", false)
    fun setAppQuiet(c: Context, app: String, v: Boolean) = prefs(c).edit().putBoolean("q:app:$app", v).apply()

    fun quietNow(c: Context): Boolean {
        if (!quietOn(c)) return false
        val now = java.time.LocalTime.now().let { it.hour * 60 + it.minute }
        return com.odak.app.logic.Pure.quietActive(
            now, quietFrom(c), quietTo(c), LocalDate.now().dayOfWeek.value - 1, quietDays(c)
        )
    }

    // ---- "5 dk daha" izni: günde en çok 3 ----
    fun passActive(c: Context, app: String) = System.currentTimeMillis() < prefs(c).getLong("pass:$app", 0L)
    /** Uyarı ekranı ayarı. kind: "blk" (engel) veya "lim" (süre doldu); alan: icon,title,msg,bg,size. */
    fun scr(c: Context, kind: String, f: String): String =
        if (kind == "blk" && f == "msg") blockMsg(c) else prefs(c).getString("scr:$kind:$f", "") ?: ""
    fun setScr(c: Context, kind: String, f: String, v: String) {
        if (kind == "blk" && f == "msg") setBlockMsg(c, v) else prefs(c).edit().putString("scr:$kind:$f", v).apply()
    }
    fun warnOn(c: Context) = prefs(c).getBoolean("warn_on", true)
    fun setWarnOn(c: Context, v: Boolean) = prefs(c).edit().putBoolean("warn_on", v).apply()
    fun warnPct(c: Context) = prefs(c).getInt("warn_pct", 80)
    fun setWarnPct(c: Context, v: Int) = prefs(c).edit().putInt("warn_pct", v).apply()
    fun limitNoteOn(c: Context) = prefs(c).getBoolean("limit_note_on", true)
    fun setLimitNoteOn(c: Context, v: Boolean) = prefs(c).edit().putBoolean("limit_note_on", v).apply()
    fun strictLimit(c: Context) = prefs(c).getBoolean("strict_limit", false)
    fun setStrictLimit(c: Context, v: Boolean) = prefs(c).edit().putBoolean("strict_limit", v).apply()
    /** Özellik süresi dolunca uygulamadan atmak yerine ana menüye git (varsayılan açık). */
    fun featHome(c: Context) = prefs(c).getBoolean("feat_home", true)
    fun setFeatHome(c: Context, v: Boolean) = prefs(c).edit().putBoolean("feat_home", v).apply()
    fun blockMsg(c: Context) = prefs(c).getString("block_msg", "") ?: ""
    fun setBlockMsg(c: Context, v: String) = prefs(c).edit().putString("block_msg", v).apply()
    fun noteMsg(c: Context) = prefs(c).getString("note_msg", "") ?: ""
    fun setNoteMsg(c: Context, v: String) = prefs(c).edit().putString("note_msg", v).apply()
    fun limitNoteOnce(c: Context, app: String): Boolean {
        val k = "limnote:${LocalDate.now()}:$app"
        if (prefs(c).getBoolean(k, false)) return false
        prefs(c).edit().putBoolean(k, true).apply()
        return true
    }
    fun notifHide(c: Context) = prefs(c).getBoolean("notif_hide", false)
    fun setNotifHide(c: Context, v: Boolean) = prefs(c).edit().putBoolean("notif_hide", v).apply()
    fun grantQuizPass(c: Context, app: String) =
        prefs(c).edit().putLong("pass:$app", System.currentTimeMillis() + 10 * 60_000L).apply()
    fun passesLeft(c: Context) = 3 - prefs(c).getInt("passn:${LocalDate.now()}", 0)
    fun grantPass(c: Context, app: String): Boolean {
        if (passesLeft(c) <= 0) return false
        prefs(c).edit()
            .putLong("pass:$app", System.currentTimeMillis() + 5 * 60_000L)
            .putInt("passn:${LocalDate.now()}", 3 - passesLeft(c) + 1)
            .apply()
        return true
    }

    fun warnOnce(c: Context, app: String): Boolean {
        val k = "warn:${LocalDate.now()}:$app"
        if (prefs(c).getBoolean(k, false)) return false
        prefs(c).edit().putBoolean(k, true).apply()
        return true
    }

    // ---- Bugün kaç kez engellendi ----
    fun blockedToday(c: Context) = prefs(c).getInt("bc:${LocalDate.now()}", 0)
    fun incBlocked(c: Context) = prefs(c).edit().putInt("bc:${LocalDate.now()}", blockedToday(c) + 1).apply()

    /** Uygulamada herhangi bir engel/sınır/sessiz saat etkin mi? ("Yalnızca etkin olanlar" süzgeci) */
    fun isActiveApp(c: Context, app: BlockApp): Boolean =
        isAppBlocked(c, app.id) || appLimit(c, app.id) > 0 || appQuiet(c, app.id) ||
            app.features.any { isFeatureBlocked(c, app.id, it.id) || featLimit(c, app.id, it.id) > 0 }

    fun goalMin(c: Context) = prefs(c).getInt("goal", 0)
    fun setGoalMin(c: Context, m: Int) = prefs(c).edit().putInt("goal", m).apply()

    // ---- Odak modu ----
    fun focusUntil(c: Context) = prefs(c).getLong("focus", 0L)
    fun setFocusUntil(c: Context, t: Long) = prefs(c).edit().putLong("focus", t).apply()
    fun focusActive(c: Context) = System.currentTimeMillis() < focusUntil(c)

    // ---- Ekran kimliği kaydı (kural bulmak için) ----
    fun learnOn(c: Context) = prefs(c).getBoolean("learn", false)
    fun setLearnOn(c: Context, v: Boolean) = prefs(c).edit().putBoolean("learn", v).apply()
    private fun seenFile(c: Context) = File(c.filesDir, "seen_ids.txt")
    fun recordIds(c: Context, pkg: String, ids: Set<String>) {
        val f = seenFile(c)
        val have = if (f.exists()) f.readLines().toMutableSet() else mutableSetOf()
        if (have.size >= 800) return
        var changed = false
        for (id in ids) if (have.add("$pkg:$id")) changed = true
        if (changed) f.writeText(have.sorted().joinToString("\n"))
    }
    fun seenText(c: Context): String = seenFile(c).let { if (it.exists()) it.readText() else "" }
    fun clearSeen(c: Context) { seenFile(c).delete() }
    fun importRules(c: Context, text: String): Boolean = try {
        val o = JSONObject(text)
        val good = o.keys().asSequence().count { !it.startsWith("_") && (o.optJSONArray(it)?.length() ?: 0) > 0 }
        if (good == 0) false
        else { File(c.filesDir, "block_rules.json").writeText(text); true }
    } catch (e: Exception) {
        false
    }

    class DayStats(val opens: Map<String, Int>, val hourMs: LongArray, val unlocks: Int = 0)

    /** Açılma sayısı ve saatlik kullanım (ms). ok(pkg) ile uygulamalar süzülür. */
    fun eventStats(c: Context, startMs: Long, endMs: Long, ok: (String) -> Boolean): DayStats {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val ev = usm.queryEvents(startMs, endMs)
        val e = android.app.usage.UsageEvents.Event()
        val opens = HashMap<String, Int>()
        val hours = LongArray(24)
        val fg = HashMap<String, Long>()
        val lastPause = HashMap<String, Long>()
        var unlocks = 0
        val zone = ZoneId.systemDefault()
        fun add(s: Long, en: Long) {
            var t = s
            while (t < en) {
                val z = java.time.Instant.ofEpochMilli(t).atZone(zone)
                val next = z.truncatedTo(java.time.temporal.ChronoUnit.HOURS).plusHours(1).toInstant().toEpochMilli()
                val seg = minOf(next, en) - t
                hours[z.hour] += seg
                t += seg
            }
        }
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == android.app.usage.UsageEvents.Event.KEYGUARD_HIDDEN) { unlocks++; continue }
            val pkg = e.packageName ?: continue
            if (!ok(pkg)) continue
            when (e.eventType) {
                android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED -> {
                    if (com.odak.app.logic.Pure.isNewOpen(lastPause[pkg], e.timeStamp)) opens[pkg] = (opens[pkg] ?: 0) + 1
                    fg[pkg] = e.timeStamp
                }
                android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED -> {
                    val s = fg.remove(pkg)
                    if (s != null && e.timeStamp > s) add(s, e.timeStamp)
                    lastPause[pkg] = e.timeStamp
                }
            }
        }
        // Hâlâ ön planda olan uygulama (bugün) aralık sonuna kadar sayılır
        for ((_, s) in fg) if (endMs > s) add(s, endMs)
        return DayStats(opens, hours, unlocks)
    }

    fun usageAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    /** Bugün paket başına ön planda geçen süre (ms). */
    fun usageToday(c: Context): Map<String, Long> {
        val start = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        return usageRange(c, start, System.currentTimeMillis())
    }

    fun usageRange(c: Context, startMs: Long, endMs: Long): Map<String, Long> {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        return usm.queryAndAggregateUsageStats(startMs, endMs).mapValues { it.value.totalTimeInForeground }
    }

    fun appUsedMs(c: Context, app: BlockApp): Long {
        val m = usageToday(c)
        return app.packages.sumOf { m[it] ?: 0L }
    }

    /** Kurallar: önce filesDir/block_rules.json (güncelleme için), yoksa assets. */
    fun rules(c: Context): Map<String, List<String>> {
        val out = HashMap<String, List<String>>()
        fun load(o: JSONObject, replace: Boolean) {
            for (k in o.keys()) {
                if (k.startsWith("_")) continue
                val a = o.optJSONArray(k) ?: continue
                val l = List(a.length()) { a.optString(it, "") }.filter { it.isNotBlank() }
                if (l.isEmpty()) continue
                out[k] = if (replace) l else ((out[k] ?: emptyList()) + l).distinct()
            }
        }
        val asset = try { c.assets.open("block_rules.json").bufferedReader().use { it.readText() } } catch (e: Exception) { "" }
        val over = try { File(c.filesDir, "block_rules.json").takeIf { it.exists() }?.readText() } catch (e: Exception) { null }
        // Önce gömülü kurallar; içe aktarılan dosya anahtar bazında üzerine yazar (bozuksa yok sayılır),
        // böylece uygulama güncellemesiyle gelen yeni kurallar eski içe aktarmayla kaybolmaz.
        try { load(JSONObject(asset), false) } catch (e: Exception) { /* asset yoksa yalnız içe aktarılan */ }
        if (over != null) try { load(JSONObject(over), true) } catch (e: Exception) { }
        try {
            val u = File(c.filesDir, "user_rules.json")
            if (u.exists()) load(JSONObject(u.readText()), true)
        } catch (e: Exception) { /* bozuk kullanıcı kuralı yok sayılır */ }
        return out
    }

    /** 14 günden eski günlük sayaç anahtarlarını siler (tercih dosyası şişmesin). */
    fun pruneOld(c: Context) {
        val p = prefs(c)
        val today = LocalDate.now()
        val old = p.all.keys.filter { com.odak.app.logic.Pure.staleDayKey(it, today) }
        if (old.isNotEmpty()) p.edit().apply { old.forEach { remove(it) } }.apply()
    }

    /** İki kural dosyasının değişim damgası (sıcak yükleme için). */
    fun rulesStamp(c: Context): Long =
        File(c.filesDir, "block_rules.json").lastModified() + File(c.filesDir, "user_rules.json").lastModified()

    fun a11yEnabled(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(c, OdakAccessibilityService::class.java)
        return s.split(':').any { ComponentName.unflattenFromString(it) == me }
    }
}
