package com.odak.app.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/** Bu yazı rengi [bg] üstünde okunmuyorsa siyah/beyaza çevirir; okunuyorsa dokunmaz. */
fun Color.readableOn(bg: Color, min: Double = Contrast.MIN): Color =
    Color(Contrast.readable(toArgb(), bg.toArgb(), min))

/** Yarı saydam yazı rengini [bg] üstünde en az [min] kontrast verecek şekilde opaklaştırır. */
fun Color.legibleAlpha(bg: Color, desired: Float, min: Double = Contrast.MIN): Color =
    copy(alpha = Contrast.alphaFor(copy(alpha = 1f).toArgb(), bg.toArgb(), desired.toDouble(), min).toFloat())

/** Yarı saydam yüzeyi zeminle karıştırıp opak zemin rengi verir. */
fun Color.over(bg: Color): Color = Color(Contrast.blend(toArgb(), bg.toArgb()))

/** Hata yazısı rengi, şu anki tasarımın zeminine göre. */
@androidx.compose.runtime.Composable
fun errorColor(): Color = Color(Contrast.errorFor(LocalDesign.current.tokens.background.toArgb()))
