package com.odak.app.docs

/**
 * CCITT faks çözücü (TIFF sıkıştırma 2 = Modified Huffman, 3 = Group 3 (1B/2B), 4 = Group 4). Saf Kotlin.
 * Çıktı: satır başına (w+7)/8 bayt, bit 1 = siyah piksel. Hatalı veride kalan satırlar beyaz kalır, hiç hata fırlatmaz.
 */
object Ccitt {
    private const val WHITE_T = "00110101:0,000111:1,0111:2,1000:3,1011:4,1100:5,1110:6,1111:7,10011:8,10100:9,00111:10,01000:11,001000:12,000011:13,110100:14,110101:15,101010:16,101011:17,0100111:18,0001100:19,0001000:20,0010111:21,0000011:22,0000100:23,0101000:24,0101011:25,0010011:26,0100100:27,0011000:28,00000010:29,00000011:30,00011010:31,00011011:32,00010010:33,00010011:34,00010100:35,00010101:36,00010110:37,00010111:38,00101000:39,00101001:40,00101010:41,00101011:42,00101100:43,00101101:44,00000100:45,00000101:46,00001010:47,00001011:48,01010010:49,01010011:50,01010100:51,01010101:52,00100100:53,00100101:54,01011000:55,01011001:56,01011010:57,01011011:58,01001010:59,01001011:60,00110010:61,00110011:62,00110100:63,11011:64,10010:128,010111:192,0110111:256,00110110:320,00110111:384,01100100:448,01100101:512,01101000:576,01100111:640,011001100:704,011001101:768,011010010:832,011010011:896,011010100:960,011010101:1024,011010110:1088,011010111:1152,011011000:1216,011011001:1280,011011010:1344,011011011:1408,010011000:1472,010011001:1536,010011010:1600,011000:1664,010011011:1728,00000001000:1792,00000001100:1856,00000001101:1920,000000010010:1984,000000010011:2048,000000010100:2112,000000010101:2176,000000010110:2240,000000010111:2304,000000011100:2368,000000011101:2432,000000011110:2496,000000011111:2560"
    private const val BLACK_T = "0000110111:0,010:1,11:2,10:3,011:4,0011:5,0010:6,00011:7,000101:8,000100:9,0000100:10,0000101:11,0000111:12,00000100:13,00000111:14,000011000:15,0000010111:16,0000011000:17,0000001000:18,00001100111:19,00001101000:20,00001101100:21,00000110111:22,00000101000:23,00000010111:24,00000011000:25,000011001010:26,000011001011:27,000011001100:28,000011001101:29,000001101000:30,000001101001:31,000001101010:32,000001101011:33,000011010010:34,000011010011:35,000011010100:36,000011010101:37,000011010110:38,000011010111:39,000001101100:40,000001101101:41,000011011010:42,000011011011:43,000001010100:44,000001010101:45,000001010110:46,000001010111:47,000001100100:48,000001100101:49,000001010010:50,000001010011:51,000000100100:52,000000110111:53,000000111000:54,000000100111:55,000000101000:56,000001011000:57,000001011001:58,000000101011:59,000000101100:60,000001011010:61,000001100110:62,000001100111:63,0000001111:64,000011001000:128,000011001001:192,000001011011:256,000000110011:320,000000110100:384,000000110101:448,0000001101100:512,0000001101101:576,0000001001010:640,0000001001011:704,0000001001100:768,0000001001101:832,0000001110010:896,0000001110011:960,0000001110100:1024,0000001110101:1088,0000001110110:1152,0000001110111:1216,0000001010010:1280,0000001010011:1344,0000001010100:1408,0000001010101:1472,0000001011010:1536,0000001011011:1600,0000001100100:1664,0000001100101:1728,00000001000:1792,00000001100:1856,00000001101:1920,000000010010:1984,000000010011:2048,000000010100:2112,000000010101:2176,000000010110:2240,000000010111:2304,000000011100:2368,000000011101:2432,000000011110:2496,000000011111:2560"

    private fun build(t: String): HashMap<Int, Int> {
        val m = HashMap<Int, Int>()
        for (e in t.split(',')) { val i = e.indexOf(':'); val bits = e.substring(0, i); m[(bits.length shl 16) or bits.toInt(2)] = e.substring(i + 1).toInt() }
        return m
    }
    private val WHITE = build(WHITE_T)
    private val BLACK = build(BLACK_T)

    private class Bits(val d: ByteArray) {
        var pos = 0
        val total = d.size * 8
        fun left() = total - pos
        fun bit(): Int { if (pos >= total) return -1; val v = (d[pos shr 3].toInt() shr (7 - (pos and 7))) and 1; pos++; return v }
        fun peek(n: Int): Int { var v = 0; for (i in 0 until n) { val p = pos + i; v = (v shl 1) or (if (p < total) (d[p shr 3].toInt() shr (7 - (p and 7))) and 1 else 0) }; return v }
    }

    /** Bir renk için tam çalışma uzunluğu (makeup+terminating); hata: -1. */
    private fun run(br: Bits, black: Boolean): Int {
        val tab = if (black) BLACK else WHITE
        var sum = 0
        while (true) {
            var code = 0; var len = 0; var r = -1
            while (len < 13) { val b = br.bit(); if (b < 0) return -1; code = (code shl 1) or b; len++; val v = tab[(len shl 16) or code]; if (v != null) { r = v; break } }
            if (r < 0) return -1
            sum += r
            if (r < 64) return sum
        }
    }

    private fun skipEol(br: Bits): Boolean {
        // en az 11 sıfır ve ardından 1 (dolgu bitleri dahil)
        var p = br.pos; var z = 0
        while (p < br.total && ((br.d[p shr 3].toInt() shr (7 - (p and 7))) and 1) == 0) { z++; p++ }
        if (z >= 11 && p < br.total) { br.pos = p + 1; return true }
        return false
    }

    /** [comp]: 2, 3 veya 4. [t4opt]: tag 292 (bit0 = 2B, bit2 = dolgu bitleri), [t6opt] yok sayılır. */
    fun decode(src: ByteArray, w: Int, h: Int, comp: Int, t4opt: Int = 0, fillReversed: Boolean = false): ByteArray {
        val rb = (w + 7) / 8
        if (w <= 0 || h <= 0 || w > 200000) return ByteArray(0)
        val out = ByteArray(rb * h)
        val data = if (fillReversed) ByteArray(src.size) { Integer.reverse(src[it].toInt()).ushr(24).toByte() } else src
        val br = Bits(data)
        var ref = IntArray(0); var refN = 0           // başvuru satırın değişim noktaları
        var cur = IntArray(w + 4); var curN: Int
        val twoD = comp == 4 || (comp == 3 && (t4opt and 1) != 0)
        for (y in 0 until h) {
            if (br.left() <= 0) break
            var oneD = !twoD
            if (comp == 3) {
                skipEol(br)
                if (twoD) { val tag = br.bit(); if (tag < 0) break; oneD = tag == 1 }
            } else if (comp == 2) { br.pos = (br.pos + 7) and 7.inv() }
            else if (comp == 4) {
                if (br.peek(24) == 0x001001) break    // EOFB
                if (br.left() < 1) break
            }
            curN = 0
            var ok = true
            if (oneD) {
                var x = 0; var black = false
                while (x < w) {
                    val r = run(br, black)
                    if (r < 0) { ok = false; break }
                    x = minOf(w, x + r); cur[curN++] = x; black = !black
                }
            } else {
                var a0 = -1; var black = false
                while (a0 < w) {
                    // b1: ref içinde a0'dan büyük, geçişi "mevcut renkten ters renge" olan ilk nokta
                    var i = if (black) 1 else 0
                    while (i < refN && ref[i] <= a0) i += 2
                    val b1 = if (i < refN) ref[i] else w
                    val b2 = if (i + 1 < refN) ref[i + 1] else w
                    // mod kodu
                    var mode = -99
                    if (br.bit().also { if (it < 0) { ok = false } } == 1) mode = 0
                    else if (!ok) break
                    else {
                        val b2n = br.bit()
                        if (b2n < 0) { ok = false; break }
                        val b3 = br.bit()
                        if (b3 < 0) { ok = false; break }
                        val c3 = (b2n shl 1) or b3
                        when (c3) {
                            3 -> mode = 1          // 011 VR1
                            2 -> mode = -1         // 010 VL1
                            1 -> mode = 100        // 001 H
                            else -> {
                                val b4 = br.bit()
                                if (b4 == 1) mode = 101   // 0001 P
                                else {
                                    val x5 = br.bit(); val x6 = br.bit()
                                    if (x5 == 1) mode = if (x6 == 1) 2 else -2          // 000011 VR2 / 000010 VL2
                                    else {
                                        val x7 = br.bit()
                                        if (x6 == 1) mode = if (x7 == 1) 3 else -3      // 0000011 VR3 / 0000010 VL3
                                        else { ok = false; break }                       // uzantı / EOL
                                    }
                                }
                            }
                        }
                    }
                    when {
                        mode == 101 -> { a0 = b2 }
                        mode == 100 -> {
                            val r1 = run(br, black); if (r1 < 0) { ok = false; break }
                            val r2 = run(br, !black); if (r2 < 0) { ok = false; break }
                            val s = if (a0 < 0) 0 else a0
                            val p1 = minOf(w, s + r1); val p2 = minOf(w, p1 + r2)
                            cur[curN++] = p1; cur[curN++] = p2; a0 = p2
                            if (a0 >= w) break
                        }
                        else -> {
                            val a1 = (b1 + mode).coerceIn(maxOf(0, a0), w)
                            if (curN >= cur.size - 2) { ok = false; break }
                            cur[curN++] = a1; a0 = a1; black = !black
                            if (a0 >= w) break
                        }
                    }
                    if (curN >= cur.size - 2) { ok = false; break }
                }
            }
            // satırı çiz
            var x = 0; var black = false
            val o = y * rb
            for (k in 0 until curN) {
                val e = minOf(w, cur[k])
                if (black && e > x) fillBits(out, o, x, e)
                if (e > x) x = e
                black = !black
            }
            if (!ok) {
                if (comp == 4) break
                // G3/MH: sonraki EOL'e kadar ilerle
                var guard = 0
                while (br.left() > 12 && br.peek(12) != 1 && guard++ < 1_000_000) br.pos++
            }
            // başvuru = bu satır (tekrarlı / sıfır uzunluklu geçişleri ele)
            if (ref.size < curN) ref = IntArray(cur.size)
            System.arraycopy(cur, 0, ref, 0, curN); refN = curN
        }
        return out
    }

    private fun fillBits(out: ByteArray, o: Int, from: Int, to: Int) {
        for (x in from until to) out[o + (x shr 3)] = (out[o + (x shr 3)].toInt() or (0x80 shr (x and 7))).toByte()
    }
}
