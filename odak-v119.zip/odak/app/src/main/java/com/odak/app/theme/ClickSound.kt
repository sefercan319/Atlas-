package com.odak.app.theme

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

enum class SoundKind(val key: String) {
    TAP("tap"),
    SUCCESS("success"),
    DELETE("delete"),
    NOTIFY("notify")
}

object ClickSound {
    @Volatile var enabled = true
    @Volatile var haptic = true
    private var pool: SoundPool? = null
    private val ids = mutableMapOf<Pair<DesignStyle, SoundKind>, Int>()

    fun init(context: Context) {
        if (pool != null) return
        val p = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        for (style in DesignStyle.entries) {
            for (kind in SoundKind.entries) {
                val res = context.resources.getIdentifier(
                    "snd_${style.key}_${kind.key}", "raw", context.packageName
                )
                if (res != 0) ids[style to kind] = p.load(context, res, 1)
            }
        }
        pool = p
    }

    fun play(style: DesignStyle, kind: SoundKind = SoundKind.TAP) {
        if (!enabled) return
        val id = ids[style to kind] ?: return
        pool?.play(id, 0.7f, 0.7f, 1, 0, 1f)
    }
}
