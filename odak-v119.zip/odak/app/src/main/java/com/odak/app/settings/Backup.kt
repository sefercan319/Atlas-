package com.odak.app.settings

import android.content.Context
import com.odak.app.logic.Pure
import org.json.JSONArray
import org.json.JSONObject

/** Tam yedek (v2): plan, görev, alışkanlık + engel ayarları, renkler, metinler. İçe aktarma önce doğrular, sonra yazar. */
object Backup {
    private class Op(val file: String, val key: String, val type: String, val value: Any)

    fun export(c: Context): String {
        val today = java.time.LocalDate.now()
        val prefs = JSONObject()
        for (f in Pure.BACKUP_FILES) {
            val o = JSONObject()
            for ((k, v) in c.getSharedPreferences(f, Context.MODE_PRIVATE).all) {
                if (Pure.backupSkip(k, today)) continue
                val e = JSONObject()
                when (v) {
                    is Boolean -> e.put("t", "b").put("v", v)
                    is Int -> e.put("t", "i").put("v", v)
                    is Long -> e.put("t", "l").put("v", v)
                    is Float -> e.put("t", "f").put("v", v.toDouble())
                    is String -> e.put("t", "s").put("v", v)
                    is Set<*> -> e.put("t", "ss").put("v", JSONArray(v.map { it.toString() }))
                    else -> continue
                }
                o.put(k, e)
            }
            prefs.put(f, o)
        }
        fun raw(f: String) = c.getSharedPreferences(f, Context.MODE_PRIVATE).getString("items", "[]") ?: "[]"
        return JSONObject().put("v", 2).put("prefs", prefs)
            .put("plan", raw("odak_plan")).put("todo", raw("odak_todo")).put("habits", raw("odak_habits"))
            .toString()
    }

    /** Başarılıysa true. Geçersiz dosyada hiçbir şey değiştirilmez. */
    fun import(c: Context, text: String): Boolean {
        val ops = ArrayList<Op>()
        try {
            val root = JSONObject(text)
            val prefs = root.optJSONObject("prefs")
            if (prefs != null) {
                for (f in prefs.keys()) {
                    if (!Pure.backupFileAllowed(f)) continue
                    val o = prefs.getJSONObject(f)
                    for (k in o.keys()) {
                        val e = o.getJSONObject(k)
                        val v: Any = when (val t = e.getString("t")) {
                            "b" -> e.getBoolean("v")
                            "i" -> e.getInt("v")
                            "l" -> e.getLong("v")
                            "f" -> e.getDouble("v").toFloat()
                            "s" -> e.getString("v")
                            "ss" -> e.getJSONArray("v").let { a -> (0 until a.length()).map { a.getString(it) }.toSet() }
                            else -> throw IllegalArgumentException("tür: $t")
                        }
                        if (k == "items" && !Pure.looksLikeJsonArray(v as? String ?: throw IllegalArgumentException("items"))) {
                            throw IllegalArgumentException("items")
                        }
                        ops.add(Op(f, k, e.getString("t"), v))
                    }
                }
            } else {
                for ((field, file) in listOf("plan" to "odak_plan", "todo" to "odak_todo", "habits" to "odak_habits")) {
                    val s = root.optString(field, "")
                    if (s.isBlank()) { if (field == "habits") continue else return false }
                    JSONArray(s)
                    ops.add(Op(file, "items", "s", s))
                }
            }
            if (ops.isEmpty()) return false
        } catch (e: Exception) {
            return false
        }
        val editors = HashMap<String, android.content.SharedPreferences.Editor>()
        for (op in ops) {
            val ed = editors.getOrPut(op.file) { c.getSharedPreferences(op.file, Context.MODE_PRIVATE).edit() }
            @Suppress("UNCHECKED_CAST")
            when (op.type) {
                "b" -> ed.putBoolean(op.key, op.value as Boolean)
                "i" -> ed.putInt(op.key, op.value as Int)
                "l" -> ed.putLong(op.key, op.value as Long)
                "f" -> ed.putFloat(op.key, op.value as Float)
                "s" -> ed.putString(op.key, op.value as String)
                else -> ed.putStringSet(op.key, op.value as Set<String>)
            }
        }
        editors.values.forEach { it.apply() }
        return true
    }
}
