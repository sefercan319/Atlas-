package com.odak.app.docs

import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/** Çok büyük düz metin dosyaları (GB'lar): tamamı okunmaz, pencere pencere gösterilir. Saf JVM, birim testlenebilir. */
object BigText {
    const val WINDOW = 1 shl 20          // ekranda bir seferde ~1 MB
    private const val SEARCH_CHUNK = 4 shl 20

    /** Metin kodlaması. unit: karakter birimi bayt sayısı (UTF-16 için 2), bom: dosya başındaki atlanacak bayt. */
    class Enc(val charset: java.nio.charset.Charset, val unit: Int, val bom: Int, val label: String, val le: Boolean = true)

    val UTF8 = Enc(Charsets.UTF_8, 1, 0, "UTF-8")
    val UTF8_BOM = Enc(Charsets.UTF_8, 1, 3, "UTF-8")
    val UTF16LE = Enc(Charsets.UTF_16LE, 2, 0, "UTF-16LE", true)
    val UTF16LE_BOM = Enc(Charsets.UTF_16LE, 2, 2, "UTF-16LE", true)
    val UTF16BE = Enc(Charsets.UTF_16BE, 2, 0, "UTF-16BE", false)
    val UTF16BE_BOM = Enc(Charsets.UTF_16BE, 2, 2, "UTF-16BE", false)
    val TR1254 = Enc(charset("windows-1254"), 1, 0, "windows-1254")

    /** start..end: dosyadaki bayt aralığı (end sonraki pencerenin başlangıcıdır). */
    class Win(val start: Long, val end: Long, val lines: List<String>, val eof: Boolean, val enc: Enc = UTF8)

    private fun readAt(ch: FileChannel, pos: Long, len: Int): ByteArray {
        val bb = ByteBuffer.allocate(len)
        var p = pos
        while (bb.hasRemaining()) {
            val r = ch.read(bb, p)
            if (r < 0) break
            p += r
        }
        return bb.array().copyOf(bb.position())
    }

    /** UTF-8 devam baytı (10xxxxxx) mu. */
    private fun cont(b: Byte): Boolean = (b.toInt() and 0xC0) == 0x80

    /** UTF-8 olarak geçerli mi (sondaki yarım karakter ve baştaki devam baytları hoş görülür). */
    fun utf8Ok(b: ByteArray, skipLead: Boolean = true): Boolean {
        var s = 0
        if (skipLead) while (s < b.size && s < 3 && cont(b[s])) s++
        val dec = Charsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT).onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
        val r = dec.decode(ByteBuffer.wrap(b, s, b.size - s), java.nio.CharBuffer.allocate(b.size + 1), false)
        return !r.isError
    }

    /**
     * Kodlamayı doğrular (varsaymaz): BOM → UTF-8/UTF-16; BOM yoksa UTF-16 sıfır-bayt deseni; aksi halde dosyanın başı, sonu ve
     * arasından alınan örnekler UTF-8 olarak geçerli mi bakılır — geçersizse Türkçe Windows-1254 kullanılır.
     */
    fun detect(ch: FileChannel, size: Long): Enc {
        val head = readAt(ch, 0, minOf(size, 65536L).toInt())
        if (head.size >= 3 && head[0] == 0xEF.toByte() && head[1] == 0xBB.toByte() && head[2] == 0xBF.toByte()) return UTF8_BOM
        if (head.size >= 2 && head[0] == 0xFF.toByte() && head[1] == 0xFE.toByte()) return UTF16LE_BOM
        if (head.size >= 2 && head[0] == 0xFE.toByte() && head[1] == 0xFF.toByte()) return UTF16BE_BOM
        val n = minOf(head.size, 4096) / 2
        if (n >= 8) {
            var ze = 0; var zo = 0
            for (i in 0 until n) { if (head[2 * i].toInt() == 0) ze++; if (head[2 * i + 1].toInt() == 0) zo++ }
            if (zo > n * 0.3 && ze < n * 0.05) return UTF16LE
            if (ze > n * 0.3 && zo < n * 0.05) return UTF16BE
        }
        if (!utf8Ok(head, false)) return TR1254
        if (size > head.size) {
            val chunk = 65536
            val points = 8
            for (i in 0..points) {
                val pos = if (i == points) maxOf(0L, size - chunk) else (size - chunk).coerceAtLeast(0L) * i / points
                if (pos == 0L) continue
                if (!utf8Ok(readAt(ch, pos, chunk), true)) return TR1254
            }
        }
        return UTF8
    }

    private fun isNl(raw: ByteArray, i: Int, e: Enc): Boolean = when {
        i < 0 || i >= raw.size -> false
        e.unit == 1 -> raw[i] == 0x0A.toByte()
        i + 1 >= raw.size -> false
        e.le -> raw[i] == 0x0A.toByte() && raw[i + 1].toInt() == 0
        else -> raw[i].toInt() == 0 && raw[i + 1] == 0x0A.toByte()
    }

    /**
     * [from] konumundan başlayan pencere. from > 0 ise yarım satırı atlamak için bir sonraki satır başına gidilir
     * (exact=true ile atlama yapılmaz: ardışık "sonraki" pencereler için tam devam). Pencere son satır sonunda kesilir.
     */
    fun window(ch: FileChannel, size: Long, from: Long, exact: Boolean = false, w: Int = WINDOW, enc: Enc = UTF8): Win {
        val u = enc.unit
        val ww = if (u == 2) w and 1.inv() else w
        var start = from.coerceIn(0L, size)
        if (u == 2) start = start and 1L.inv()
        val raw = readAt(ch, start, ww + 4)
        var off = 0
        if (start == 0L) off = minOf(enc.bom, raw.size)
        if (!exact && start > 0) {
            var i = 0
            while (i < raw.size && !isNl(raw, i, enc)) i += u
            off = if (i < raw.size) i + u else 0
        } else if (u == 1 && enc.charset == Charsets.UTF_8) {
            while (off < raw.size && off < 3 && cont(raw[off])) off++   // UTF-8 ortasına denk geldiysek ilerle
        }
        start += off
        var end = minOf(raw.size, ww + off)
        if (u == 2) end = off + ((end - off) and 1.inv())
        val eof = start + (end - off) >= size
        if (!eof) {
            var e = end
            while (e > off && !isNl(raw, e - u, enc)) e -= u
            if (e > off) end = e
            else if (u == 1 && enc.charset == Charsets.UTF_8) { while (end > off && end < raw.size && cont(raw[end])) end-- }
            else if (u == 2 && end - off >= 2) {
                val hi = if (enc.le) raw[end - 1].toInt() and 0xFF else raw[end - 2].toInt() and 0xFF
                if (hi in 0xD8..0xDB) end -= 2
            }
        }
        val bytes = raw.copyOfRange(off, end)
        // UTF-8 seçilmiş ama bu pencerede geçersiz bayt var: yalnız bu pencereyi Windows-1254 çöz (� yerine doğru Türkçe)
        val useEnc = if (enc.charset == Charsets.UTF_8 && !utf8Ok(bytes, false)) TR1254 else enc
        val text = String(bytes, useEnc.charset)
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        return Win(start, start + bytes.size, if (lines.isNotEmpty() && lines.last().isEmpty()) lines.dropLast(1) else lines, eof, useEnc)
    }

    /** Önceki pencerenin başlangıç tahmini. */
    fun prevStart(start: Long, w: Int = WINDOW): Long = (start - w).coerceAtLeast(0L)

    /** Dosya yüzdesi (0..100). */
    fun percent(pos: Long, size: Long): Int = if (size <= 0) 0 else ((pos.toDouble() / size) * 100).toInt().coerceIn(0, 100)

    /** Yüzdeden bayt konumu. */
    fun posOf(fraction: Float, size: Long): Long = (size * fraction.toDouble().coerceIn(0.0, 1.0)).toLong().coerceIn(0L, maxOf(0L, size - 1))

    /**
     * [from] konumundan sonra [query] ilk eşleşmesinin bayt konumu, yoksa -1. Büyük/küçük harf duyarsız.
     * Parçalar örtüşür; sınırdaki eşleşmeler kaçmaz. [cancel] true dönerse -2 ile çıkar.
     */
    fun find(ch: FileChannel, size: Long, from: Long, query: String, enc: Enc = UTF8, cancel: () -> Boolean = { false }): Long {
        if (query.isEmpty()) return -1
        val u = enc.unit
        val overlap = query.toByteArray(enc.charset).size + 8
        var pos = from.coerceIn(0L, size)
        if (u == 2) pos = pos and 1L.inv()
        while (pos < size) {
            if (cancel()) return -2
            val len = minOf(SEARCH_CHUNK.toLong() + overlap, size - pos).toInt().let { if (u == 2) it and 1.inv() else it }
            if (len <= 0) return -1
            val bytes = readAt(ch, pos, len)
            var s = 0
            if (u == 1 && enc.charset == Charsets.UTF_8) while (s < bytes.size && s < 3 && cont(bytes[s])) s++
            if (pos == 0L) s = maxOf(s, minOf(enc.bom, bytes.size))
            val cs = if (enc.charset == Charsets.UTF_8 && !utf8Ok(bytes, true)) TR1254.charset else enc.charset
            val text = String(bytes, s, bytes.size - s, cs)
            val i = text.indexOf(query, ignoreCase = true)
            if (i >= 0) return pos + s + text.substring(0, i).toByteArray(cs).size
            if (pos + len >= size) return -1
            pos += SEARCH_CHUNK
        }
        return -1
    }
}
