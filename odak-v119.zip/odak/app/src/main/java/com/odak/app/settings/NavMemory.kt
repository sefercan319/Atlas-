package com.odak.app.settings

/** Alt gezinme: son açık sekmeyi hatırlama. Saf mantık. */
object NavMemory {
    const val KEY = "last_tab"
    /** Kayıtlı sekmeyi geçerli aralığa çeker; bozuk/eski değerde ilk sekme. */
    fun restore(saved: Int, count: Int): Int = if (count <= 0 || saved !in 0 until count) 0 else saved
}
