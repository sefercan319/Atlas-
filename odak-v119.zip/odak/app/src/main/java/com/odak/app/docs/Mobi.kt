package com.odak.app.docs

/** Kindle MOBI/AZW/AZW3/PRC (PalmDOC ve HUFF/CDIC sıkıştırmalı) okuyucu; metin + gömülü resimler (MOBI6 recindex). Saf Kotlin. DRM'li (şifreli) dosyalar açılmaz. */
object Mobi {
    private const val MAX_PAGES = 400
    private const val MAX_TEXT = 64 * 1024 * 1024

    private fun u16(b: ByteArray, i: Int) = ((b[i].toInt() and 255) shl 8) or (b[i + 1].toInt() and 255)
    private fun u32(b: ByteArray, i: Int) = (u16(b, i).toLong() shl 16) or u16(b, i + 2).toLong()

    fun isMobi(b: ByteArray): Boolean {
        if (b.size < 68) return false
        val t = String(b, 60, 8, Charsets.ISO_8859_1)
        return t == "BOOKMOBI" || t == "TEXtREAd"
    }

    /** PalmDOC LZ77 açma. */
    fun palmDecompress(inp: ByteArray, out: java.io.ByteArrayOutputStream) {
        val buf = ArrayList<Byte>()
        var i = 0
        val n = inp.size
        val o = ByteArray(inp.size * 8 + 16)
        var op = 0
        fun put(b: Int) { if (op < o.size) { o[op++] = b.toByte() } }
        while (i < n) {
            val c = inp[i++].toInt() and 255
            when {
                c in 1..8 -> { var k = 0; while (k < c && i < n) { put(inp[i++].toInt() and 255); k++ } }
                c < 0x80 -> put(c)
                c >= 0xC0 -> { put(' '.code); put(c xor 0x80) }
                else -> {
                    if (i >= n) break
                    val cc = (c shl 8) or (inp[i++].toInt() and 255)
                    val dist = (cc shr 3) and 0x7FF
                    val len = (cc and 7) + 3
                    if (dist == 0 || dist > op) continue
                    for (k in 0 until len) { put(o[op - dist].toInt() and 255) }
                }
            }
        }
        out.write(o, 0, op)
    }

    private fun trailing(d: ByteArray, flags: Int): Int {
        var size = 0
        for (bit in 15 downTo 1) if (flags and (1 shl bit) != 0) {
            var pos = d.size - size
            var res = 0; var shift = 0
            while (pos > 0) {
                val v = d[pos - 1].toInt() and 255
                res = res or ((v and 0x7F) shl shift); shift += 7; pos--
                if (v and 0x80 != 0 || shift >= 28) break
            }
            size += res
        }
        if (flags and 1 != 0 && d.size - size - 1 >= 0) size += (d[d.size - size - 1].toInt() and 3) + 1
        return size
    }

    /** MOBI HUFF/CDIC (sıkıştırma türü 17480) açıcı. */
    class Huff(huffs: List<ByteArray>) {
        private val dict1 = LongArray(256)
        private val dict1len = IntArray(256)
        private val dict1term = BooleanArray(256)
        private val minCode = LongArray(33)
        private val maxCode = LongArray(33)
        private val dictionary = ArrayList<Pair<ByteArray, Boolean>?>()
        private val ok: Boolean

        init {
            var good = true
            val h = huffs[0]
            if (h.size < 16 || String(h, 0, 4, Charsets.ISO_8859_1) != "HUFF") good = false
            else {
                val off1 = u32(h, 8).toInt(); val off2 = u32(h, 12).toInt()
                if (off1 < 0 || off2 < 0 || off1 + 1024 > h.size || off2 + 256 > h.size) good = false
                else {
                    for (i in 0 until 256) {
                        val v = u32(h, off1 + i * 4)
                        val cl = (v and 0x1f).toInt(); val term = (v and 0x80) != 0L
                        dict1len[i] = cl; dict1term[i] = term
                        dict1[i] = (((v shr 8) + 1) shl (32 - cl)) - 1
                        if (cl == 0) good = false
                    }
                    for (cl in 1..32) {
                        val mn = u32(h, off2 + (cl - 1) * 8); val mx = u32(h, off2 + (cl - 1) * 8 + 4)
                        minCode[cl] = mn shl (32 - cl)
                        maxCode[cl] = ((mx + 1) shl (32 - cl)) - 1
                    }
                }
            }
            if (good) for (k in 1 until huffs.size) {
                val c = huffs[k]
                if (c.size < 16 || String(c, 0, 4, Charsets.ISO_8859_1) != "CDIC") { good = false; break }
                val phrases = u32(c, 8).toInt(); val bits = u32(c, 12).toInt()
                val n = minOf(1 shl bits.coerceIn(0, 16), phrases - dictionary.size)
                for (j in 0 until n) {
                    if (16 + j * 2 + 2 > c.size) { good = false; break }
                    val off = u16(c, 16 + j * 2)
                    if (16 + off + 2 > c.size) { dictionary.add(null); continue }
                    val bl = u16(c, 16 + off)
                    val len = bl and 0x7fff
                    if (18 + off + len > c.size) { dictionary.add(null); continue }
                    dictionary.add(c.copyOfRange(18 + off, 18 + off + len) to ((bl and 0x8000) != 0))
                }
            }
            ok = good && dictionary.isNotEmpty()
        }

        fun unpack(data: ByteArray, depth: Int = 0): ByteArray {
            val out = java.io.ByteArrayOutputStream()
            if (!ok || depth > 16) return out.toByteArray()
            val d = data.copyOf(data.size + 8)
            var bitsLeft = data.size.toLong() * 8
            var pos = 0
            fun q(p: Int): Long { var x = 0L; for (k in 0 until 8) x = (x shl 8) or (d[p + k].toLong() and 255); return x }
            var x = q(0); var n = 32
            var guard = 0L
            while (guard++ < 200_000_000L) {
                if (n <= 0) { pos += 4; if (pos + 8 > d.size) break; x = q(pos); n += 32 }
                val code = (x ushr n) and 0xFFFFFFFFL
                val top = (code ushr 24).toInt()
                var cl = dict1len[top]
                var mc = dict1[top]
                if (!dict1term[top]) {
                    while (cl < 32 && code < minCode[cl]) cl++
                    mc = maxCode[cl]
                }
                n -= cl; bitsLeft -= cl
                if (bitsLeft < 0) break
                val r = ((mc - code) ushr (32 - cl)).toInt()
                val e = dictionary.getOrNull(r) ?: break
                var (sl, flag) = e
                if (!flag) {
                    sl = unpack(sl, depth + 1)
                    dictionary[r] = sl to true
                }
                out.write(sl)
                if (out.size() > MAX_TEXT) break
            }
            return out.toByteArray()
        }
    }

    /** "kindle:embed:0004?mime=image/jpeg" → 4 (taban 32: 0-9, A-V); geçersizse null. */
    fun kf8Index(src: String): Int? {
        val t = src.removePrefix("kindle:embed:").substringBefore('?').trim().uppercase()
        if (t.isEmpty() || t.length > 6) return null
        var v = 0
        for (c in t) { val d = when (c) { in '0'..'9' -> c - '0'; in 'A'..'V' -> c - 'A' + 10; else -> return null }; v = v * 32 + d }
        return v
    }

    /** Birleşik MOBI/KF8 dosyasında KF8 bölümünün ilk kaydı (EXTH 121); yoksa 0. */
    fun kf8Base(r0: ByteArray?, nAll: Int): Int {
        if (r0 == null || r0.size < 0x90 || String(r0, 16, 4, Charsets.ISO_8859_1) != "MOBI") return 0
        val hl = u32(r0, 20).toInt()
        if (u32(r0, 0x80) and 0x40L == 0L) return 0
        val ex = 16 + hl
        if (ex + 12 > r0.size || String(r0, ex, 4, Charsets.ISO_8859_1) != "EXTH") return 0
        val cnt = u32(r0, ex + 8).toInt().coerceIn(0, 500)
        var p = ex + 12
        repeat(cnt) {
            if (p + 8 > r0.size) return 0
            val t = u32(r0, p).toInt(); val l = u32(r0, p + 4).toInt()
            if (l < 8 || p + l > r0.size) return 0
            if (t == 121 && l == 12) { val v = u32(r0, p + 8).toInt(); return if (v in 1 until nAll) v else 0 }
            p += l
        }
        return 0
    }

    fun mobiDoc(b: ByteArray): Doc {
        val empty = Doc(DocKind.MOBI, emptyList())
        if (!isMobi(b) || b.size < 100) return empty
        val nAll = u16(b, 76)
        if (nAll < 2 || 78 + nAll * 8 > b.size) return empty
        val offAll = IntArray(nAll) { u32(b, 78 + it * 8).toInt() }
        fun recAll(i: Int): ByteArray? {
            if (i < 0 || i >= nAll) return null
            val s = offAll[i]; val e = if (i + 1 < nAll) offAll[i + 1] else b.size
            return if (s < 0 || e > b.size || s >= e) null else b.copyOfRange(s, e)
        }
        // KF8 (AZW3): birleşik dosyada EXTH 121 yeni bölümün başlangıç kaydını verir; salt KF8'de sürüm 8'dir.
        val base = kf8Base(recAll(0), nAll)
        val nRec = nAll - base
        fun rec(i: Int): ByteArray? = recAll(base + i)
        val r0 = rec(0) ?: return empty
        val kf8 = r0.size > 40 && String(r0, 16, 4, Charsets.ISO_8859_1) == "MOBI" && u32(r0, 36) == 8L
        if (r0.size < 16) return empty
        val comp = u16(r0, 0)
        val count = u16(r0, 8)
        val enc = u16(r0, 12)
        if (enc != 0 || (comp != 1 && comp != 2 && comp != 17480)) return empty
        var charset = java.nio.charset.Charset.forName("windows-1252")
        var flags = 0
        var firstImage = -1
        var huff: Huff? = null
        if (r0.size > 32 && String(r0, 16, 4, Charsets.ISO_8859_1) == "MOBI") {
            val hl = u32(r0, 20).toInt()
            if (u32(r0, 28).toInt() == 65001) charset = Charsets.UTF_8
            if (hl >= 0xE4 && r0.size > 0xF4) flags = u16(r0, 0xF2)
            if (hl >= 0x74 && r0.size > 0x70) firstImage = u32(r0, 0x6C).toInt().let { if (it in 1 until nRec) it else -1 }
            if (comp == 17480) {
                if (hl < 0x78 || r0.size < 0x78) return empty
                val ho = u32(r0, 0x70).toInt(); val hn = u32(r0, 0x74).toInt()
                if (ho !in 1 until nRec || hn !in 2..nRec - ho) return empty
                val hs = (ho until ho + hn).map { rec(it) ?: return empty }
                huff = Huff(hs)
            }
        }
        if (comp == 17480 && huff == null) return empty
        val out = java.io.ByteArrayOutputStream()
        for (i in 1..minOf(count, nRec - 1)) {
            var d = rec(i) ?: continue
            if (flags != 0) { val t = trailing(d, flags); if (t in 1 until d.size) d = d.copyOf(d.size - t) }
            if (comp == 17480) out.write(huff!!.unpack(d)) else if (comp == 2) palmDecompress(d, out) else out.write(d)
            if (out.size() > MAX_TEXT) break
        }
        val html = String(out.toByteArray(), charset)
        val parts = if (kf8) html.split(Regex("(?i)</html\\s*>")).filter { it.contains("<body", true) || it.contains("<p", true) }.map { it + "</html>" }
            else html.split(Regex("(?i)<mbp:pagebreak\\s*/?>"))
        val pages = ArrayList<DocPage>()
        for (p in parts) {
            if (pages.size >= MAX_PAGES) break
            val paras = DocParse.htmlParas(p)
            if (paras.any { it.isNotBlank() }) {
                val rich = try {
                    HtmlRich.page(HtmlRich.parse(p, { src ->
                        val n = if (src.startsWith("kindle:embed:")) kf8Index(src) else src.removePrefix("recindex:").trim().toIntOrNull()
                        if (n != null && firstImage > 0 && firstImage + n - 1 < nRec) rec(firstImage + n - 1)?.let { HtmlRich.image(it) }
                            ?: (if (base > 0) recAll(firstImage + n - 1)?.let { HtmlRich.image(it) } else null) else null
                    })).takeIf { it.blocks.isNotEmpty() }
                } catch (e: Exception) { null }
                pages.add(DocPage((pages.size + 1).toString(), paras, null, null, rich))
            }
        }
        return Doc(DocKind.MOBI, pages)
    }
}
