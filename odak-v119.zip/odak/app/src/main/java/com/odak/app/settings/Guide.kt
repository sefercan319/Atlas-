package com.odak.app.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedHeader

/** İlk açılışta bir kez gösterilen kısa rehber. */
@Composable
fun GuideScreen(onStart: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        ThemedHeader(stringResource(R.string.guide_title))
        Spacer(Modifier.height(16.dp))
        Text("📅  " + stringResource(R.string.guide_1))
        Spacer(Modifier.height(12.dp))
        Text("⏱  " + stringResource(R.string.guide_2))
        Spacer(Modifier.height(12.dp))
        Text("⛔  " + stringResource(R.string.guide_3))
        Spacer(Modifier.height(28.dp))
        ThemedButton(stringResource(R.string.guide_start), onStart)
    }
}
