package com.odak.app.plan

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Locale
import java.util.UUID

data class PlanItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val date: LocalDate,
    val done: Boolean = false,
    /** Günün başından itibaren dakika. -1 = saatsiz. */
    val startMin: Int = -1,
    val durMin: Int = 60,
    val note: String = "",
    /** 0 = otomatik, 1..3 = sabit renk. */
    val color: Int = 0
) {
    val hasTime: Boolean get() = startMin >= 0
}

fun fmtTime(min: Int): String = com.odak.app.logic.Pure.fmtTime(min)

fun parseTime(s: String): Int? = com.odak.app.logic.Pure.parseTime(s)

/** Etkinlik rengi için kararlı 0..2 indeksi. */
fun colorIndex(p: PlanItem): Int = (p.id.hashCode() and 0x7fffffff) % 3

/** Seçilebilir 24 plan rengi (PlanItem.color = indeks + 1, 0 = otomatik). */
val PlanPalette: List<androidx.compose.ui.graphics.Color> = listOf(
    0xFFE53935, 0xFFD81B60, 0xFF8E24AA, 0xFF5E35B1, 0xFF3949AB, 0xFF1E88E5,
    0xFF039BE5, 0xFF00ACC1, 0xFF00897B, 0xFF43A047, 0xFF7CB342, 0xFFC0CA33,
    0xFFFDD835, 0xFFFFB300, 0xFFFB8C00, 0xFFF4511E, 0xFF6D4C41, 0xFF757575,
    0xFF546E7A, 0xFFFF6E9C, 0xFF00E5FF, 0xFF76FF03, 0xFFB388FF, 0xFF263238
).map { androidx.compose.ui.graphics.Color(it) }

fun customColor(p: PlanItem): androidx.compose.ui.graphics.Color? =
    if (p.color in 1..PlanPalette.size) PlanPalette[p.color - 1] else null

/** Başlığın önüne seçili renkte nokta koyar (renk seçilmediyse düz başlık). */
fun titleWithDot(p: PlanItem, upper: Boolean = false): androidx.compose.ui.text.AnnotatedString {
    val t = if (upper) p.title.uppercase(java.util.Locale.getDefault()) else p.title
    val c = customColor(p) ?: return androidx.compose.ui.text.AnnotatedString(t)
    return androidx.compose.ui.text.buildAnnotatedString {
        pushStyle(androidx.compose.ui.text.SpanStyle(color = c))
        append("● ")
        pop()
        append(t)
    }
}

object PlanStore {
    private const val PREFS = "odak_plan"
    private const val KEY = "items"

    fun load(context: Context): List<PlanItem> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            var bad = 0
            val list = (0 until arr.length()).mapNotNull { i -> try {
                val o = arr.getJSONObject(i)
                PlanItem(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    date = LocalDate.parse(o.getString("date")),
                    done = o.optBoolean("done", false),
                    startMin = o.optInt("startMin", -1),
                    durMin = o.optInt("durMin", 60),
                    note = o.optString("note", ""),
                    color = o.optInt("color", 0)
                )
            } catch (e: Exception) { bad++; null } }
            // Okunamayan kayıt varsa ham veri bir kez yedeklenir: sonraki kayıt eski veriyi ezip kalıcı kayba yol açmasın.
            if (bad > 0) context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY + "_bak", raw).apply()
            list
        } catch (e: Exception) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY + "_bak", raw).apply()
            emptyList()
        }
    }

    fun save(context: Context, items: List<PlanItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("title", it.title)
                put("date", it.date.toString())
                put("done", it.done)
                put("startMin", it.startMin)
                put("durMin", it.durMin)
                put("note", it.note)
                put("color", it.color)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }
}

/** Plan etiket emojileri (en fazla 20, kullanıcı değiştirebilir). */
object PlanEmoji {
    val defaults = "💼 🎓 🏠 ❤ 🏃 🛒 📞 🎯 🍽 💊 🎵 ✈ 📚 🧹 💻 🛏 ☕ 🚗 🎮 🙏"
    private fun p(c: Context) = c.getSharedPreferences("odak_app", Context.MODE_PRIVATE)
    fun raw(c: Context): String = p(c).getString("tag_emojis", defaults) ?: defaults
    fun save(c: Context, s: String) = p(c).edit().putString("tag_emojis", s).apply()
    fun list(c: Context): List<String> = raw(c).split(Regex("\\s+")).filter { it.isNotEmpty() }.take(20)

    /** Başlığın başındaki eski etiketi çıkarıp yenisini koyar. */
    fun tagged(title: String, e: String, all: List<String>): String {
        return com.odak.app.logic.Pure.tagged(title, e, all)
    }
}
