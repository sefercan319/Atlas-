package com.odak.app.docs

/**
 * Saf Kotlin EMF ve WMF (Windows metafile) okuyucu: kayıtları çizim komutlarına çevirir (Android'e bağlı değil).
 * Desteklenen: çoklu çizgi/çokgen/bezier, dikdörtgen, yuvarlak dikdörtgen, elips, yay/dilim, yollar (path), kalem/fırça/yazı tipi nesneleri,
 * dünya dönüşümü, pencere/görünüm kutusu eşlemesi, metin (EXTTEXTOUT/TEXTOUT) ve bitmap (DIB) kayıtları.
 * Ayrıca: kırpma (dikdörtgen, yol, bölge), desenli (DIB/mono/tarama) ve gradyan (GRADIENTFILL, EMF+ doğrusal) fırçalar, RLE4/RLE8 bitmap,
 * çizgi stilleri (kesik/nokta) ve EMF+ kayıtları (yalnız-EMF+ dosyalar dahil; "dual" dosyalarda EMF kayıtları kullanılır).
 * Desteklenmeyenler: ROP işlemleri, EMF+ doku/yol-gradyan fırçaları ve bölge nesneleri, özel çizgi uçları.
 */
object Metafile {
    class Sub(val pts: DoubleArray, val closed: Boolean)

    sealed class Op
    /** fill/stroke: ARGB ya da null. sw: çizgi kalınlığı (çıktı birimi). */
    class Poly(val subs: List<Sub>, val fill: Int?, val stroke: Int?, val sw: Double, val evenOdd: Boolean, val shade: Shade? = null, val dash: Int = 0) : Op()
    /** align: Windows TA_* bayrakları (2=sağ, 6=orta, 8=alt, 24=taban çizgisi). angle: derece (saat yönünün tersi). */
    class Text(val x: Double, val y: Double, val s: String, val color: Int, val size: Double, val bold: Boolean, val italic: Boolean, val angle: Double, val align: Int) : Op()
    class Bmp(val x: Double, val y: Double, val w: Double, val h: Double, val pw: Int, val ph: Int, val argb: IntArray) : Op()
    /** Sıkıştırılmış resim (PNG/JPEG/GIF…): çözme işi çizim katmanına bırakılır. */
    class Img(val x: Double, val y: Double, val w: Double, val h: Double, val data: ByteArray) : Op()
    /** DC durumu kaydet/geri yükle (kırpmayı sınırlar). */
    object Save : Op()
    object Restore : Op()
    /** Kırpma: mevcut kırpma ile kesişim (exclude: bu alanı çıkar). */
    class Clip(val subs: List<Sub>, val evenOdd: Boolean, val exclude: Boolean = false) : Op()

    /** Düz renk yerine kullanılan dolgu. Tile: çıktı biriminde 1 piksel = 1 birim, tekrarlı; Linear: iki nokta arası renk geçişi. */
    sealed class Shade
    class Tile(val w: Int, val h: Int, val argb: IntArray) : Shade()
    class Linear(val x0: Double, val y0: Double, val x1: Double, val y1: Double, val colors: IntArray, val pos: DoubleArray) : Shade()

    class Meta(val left: Double, val top: Double, val right: Double, val bottom: Double, val ops: List<Op>) {
        val w: Double get() = right - left
        val h: Double get() = bottom - top
    }

    private const val MAX_OPS = 200_000
    private const val MAX_PIXELS = 40_000_000L

    fun isEmf(b: ByteArray): Boolean = b.size >= 44 && u32(b, 0) == 1L && u32(b, 40) == 0x464D4520L   // " EMF"
    fun isWmf(b: ByteArray): Boolean = b.size >= 18 && (u32(b, 0) == 0x9AC6CDD7L || (u16(b, 0) in 1..2 && u16(b, 2) == 9))

    fun parse(b: ByteArray): Meta? = try {
        when {
            isEmf(b) -> parseEmf(b)
            isWmf(b) -> parseWmf(b)
            else -> null
        }
    } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }

    // ---------------- Bayt okuma ----------------
    private fun u8(b: ByteArray, o: Int): Int = if (o in b.indices) b[o].toInt() and 0xFF else 0
    private fun u16(b: ByteArray, o: Int): Int = u8(b, o) or (u8(b, o + 1) shl 8)
    private fun s16(b: ByteArray, o: Int): Int = u16(b, o).toShort().toInt()
    private fun u32(b: ByteArray, o: Int): Long = (u16(b, o).toLong()) or (u16(b, o + 2).toLong() shl 16)
    private fun s32(b: ByteArray, o: Int): Int = u32(b, o).toInt()
    private fun f32(b: ByteArray, o: Int): Double = java.lang.Float.intBitsToFloat(s32(b, o)).toDouble()
    private fun colorOf(c: Int): Int = (0xFF shl 24) or ((c and 0xFF) shl 16) or (((c shr 8) and 0xFF) shl 8) or ((c shr 16) and 0xFF)

    // ---------------- Ortak durum ----------------
    private class Pen(val color: Int, val width: Double, val style: Int) { val none get() = style and 0xF == 5 }
    private class Brush(val color: Int, val none: Boolean, val shade: Shade? = null)
    private class Font(val height: Double, val weight: Int, val italic: Boolean, val angle: Double)

    private class St {
        var wox = 0.0; var woy = 0.0; var wex = 1.0; var wey = 1.0
        var vox = 0.0; var voy = 0.0; var vex = 1.0; var vey = 1.0
        var mapMode = 1
        var m11 = 1.0; var m12 = 0.0; var m21 = 0.0; var m22 = 1.0; var dx = 0.0; var dy = 0.0
        var pen: Pen = Pen(0xFF000000.toInt(), 1.0, 0)
        var brush: Brush = Brush(0xFFFFFFFF.toInt(), false)
        var font: Font? = null
        var textColor = 0xFF000000.toInt()
        var textAlign = 0
        var evenOdd = true
        var cx = 0.0; var cy = 0.0
        fun copy(): St { val s = St(); s.wox = wox; s.woy = woy; s.wex = wex; s.wey = wey; s.vox = vox; s.voy = voy; s.vex = vex; s.vey = vey; s.mapMode = mapMode; s.m11 = m11; s.m12 = m12; s.m21 = m21; s.m22 = m22; s.dx = dx; s.dy = dy; s.pen = pen; s.brush = brush; s.font = font; s.textColor = textColor; s.textAlign = textAlign; s.evenOdd = evenOdd; s.cx = cx; s.cy = cy; return s }
        fun set(s: St) { wox = s.wox; woy = s.woy; wex = s.wex; wey = s.wey; vox = s.vox; voy = s.voy; vex = s.vex; vey = s.vey; mapMode = s.mapMode; m11 = s.m11; m12 = s.m12; m21 = s.m21; m22 = s.m22; dx = s.dx; dy = s.dy; pen = s.pen; brush = s.brush; font = s.font; textColor = s.textColor; textAlign = s.textAlign; evenOdd = s.evenOdd; cx = s.cx; cy = s.cy }
        private fun mapped() = mapMode == 7 || mapMode == 8
        fun tx(x: Double, y: Double): Double {
            val x1 = m11 * x + m21 * y + dx
            return if (mapped() && wex != 0.0) vox + (x1 - wox) * vex / wex else x1
        }
        fun ty(x: Double, y: Double): Double {
            val y1 = m12 * x + m22 * y + dy
            return if (mapped() && wey != 0.0) voy + (y1 - woy) * vey / wey else y1
        }
        private fun det() = Math.sqrt(Math.abs(m11 * m22 - m12 * m21)).let { if (it == 0.0) 1.0 else it }
        fun scaleX(): Double = Math.abs(if (mapped() && wex != 0.0) vex / wex else 1.0) * det()
        fun scaleY(): Double = Math.abs(if (mapped() && wey != 0.0) vey / wey else 1.0) * det()
    }

    private class Out(val st: St = St()) {
        val ops = ArrayList<Op>()
        val stack = ArrayList<St>()
        var cur = st
        var inPath = false
        val path = ArrayList<Sub>()
        var curSub = ArrayList<Double>()
        var figX = 0.0; var figY = 0.0
        var arcCw = false
        var minX = Double.MAX_VALUE; var minY = Double.MAX_VALUE; var maxX = -Double.MAX_VALUE; var maxY = -Double.MAX_VALUE

        fun ext(x: Double, y: Double) { if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y }

        fun pts(raw: DoubleArray): DoubleArray {
            val o = DoubleArray(raw.size)
            var i = 0
            while (i + 1 < raw.size) { o[i] = cur.tx(raw[i], raw[i + 1]); o[i + 1] = cur.ty(raw[i], raw[i + 1]); ext(o[i], o[i + 1]); i += 2 }
            return o
        }
        fun penW(): Double = maxOf(1.0, cur.pen.width * (cur.scaleX() + cur.scaleY()) / 2)

        fun poly(subsRaw: List<Pair<DoubleArray, Boolean>>, fillIt: Boolean, strokeIt: Boolean) {
            if (ops.size >= MAX_OPS) return
            val subs = subsRaw.map { Sub(pts(it.first), it.second) }
            if (inPath) { path.addAll(subs); return }
            emit(subs, fillIt, strokeIt)
        }
        fun emit(subs: List<Sub>, fillIt: Boolean, strokeIt: Boolean) {
            val f = if (fillIt && !cur.brush.none) cur.brush.color else null
            val s = if (strokeIt && !cur.pen.none) cur.pen.color else null
            if (f != null || s != null) ops.add(Poly(subs, f, s, penW(), cur.evenOdd, if (f != null) cur.brush.shade else null, cur.pen.style and 0xF))
        }
        /** Aygıt (çıktı) koordinatlarında hazır şekil; EMF+ ve gradyan dolgu için. */
        fun emitDev(subs: List<Sub>, fill: Int?, stroke: Int?, sw: Double, shade: Shade?, dash: Int, eo: Boolean) {
            if (ops.size >= MAX_OPS) return
            for (sb in subs) { var i = 0; while (i + 1 < sb.pts.size) { ext(sb.pts[i], sb.pts[i + 1]); i += 2 } }
            if (fill != null || stroke != null) ops.add(Poly(subs, fill, stroke, sw, eo, shade, dash))
        }
        /** Mantıksal koordinatlı bölgeyi kırpmaya ekler. */
        fun clipRaw(subsRaw: List<Pair<DoubleArray, Boolean>>, exclude: Boolean) {
            if (ops.size >= MAX_OPS || subsRaw.isEmpty()) return
            val subs = subsRaw.map { Sub(pts(it.first), it.second) }
            ops.add(Clip(subs, cur.evenOdd, exclude))
        }
        /** Yol modunda biriken noktaları (mantıksal) bir alt yola çevirir. */
        fun flushSub(closed: Boolean) { if (curSub.size >= 4) path.add(Sub(pts(curSub.toDoubleArray()), closed)); curSub = ArrayList() }
        fun finishPath(fillIt: Boolean, strokeIt: Boolean) { flushSub(false); if (path.isNotEmpty()) emit(ArrayList(path), fillIt, strokeIt); path.clear(); inPath = false }
    }

    private fun bezier(p: DoubleArray, startIdx: Int, out: ArrayList<Double>) {
        // p[startIdx..] içinde 4 nokta (x0,y0,...,x3,y3); başlangıç noktası zaten out'ta
        val x0 = p[startIdx]; val y0 = p[startIdx + 1]; val x1 = p[startIdx + 2]; val y1 = p[startIdx + 3]
        val x2 = p[startIdx + 4]; val y2 = p[startIdx + 5]; val x3 = p[startIdx + 6]; val y3 = p[startIdx + 7]
        val n = 14
        for (i in 1..n) {
            val t = i.toDouble() / n; val u = 1 - t
            out.add(u * u * u * x0 + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x3)
            out.add(u * u * u * y0 + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3)
        }
    }

    private fun ellipsePts(l: Double, t: Double, r: Double, b: Double, a0: Double = 0.0, a1: Double = 360.0, steps: Int = 48): DoubleArray {
        val cx = (l + r) / 2; val cy = (t + b) / 2; val rx = (r - l) / 2; val ry = (b - t) / 2
        val o = DoubleArray(2 * (steps + 1))
        for (i in 0..steps) { val a = Math.toRadians(a0 + (a1 - a0) * i / steps); o[2 * i] = cx + rx * Math.cos(a); o[2 * i + 1] = cy - ry * Math.sin(a) }
        return o
    }
    private fun roundRectPts(l: Double, t: Double, r: Double, b: Double, cw: Double, ch: Double): DoubleArray {
        val rx = minOf(Math.abs(cw) / 2, Math.abs(r - l) / 2); val ry = minOf(Math.abs(ch) / 2, Math.abs(b - t) / 2)
        val o = ArrayList<Double>()
        fun arc(cx: Double, cy: Double, a0: Double) { for (i in 0..8) { val a = Math.toRadians(a0 + 90.0 * i / 8); o.add(cx + rx * Math.cos(a)); o.add(cy - ry * Math.sin(a)) } }
        arc(r - rx, t + ry, 0.0); arc(l + rx, t + ry, 90.0); arc(l + rx, b - ry, 180.0); arc(r - rx, b - ry, 270.0)
        return o.toDoubleArray()
    }
    /** (x,y) merkezine göre açı (derece, saat yönünün tersi, y yukarı). */
    private fun angleOf(l: Double, t: Double, r: Double, b: Double, px: Double, py: Double): Double {
        val cx = (l + r) / 2; val cy = (t + b) / 2
        return Math.toDegrees(Math.atan2(-(py - cy) / maxOf(1e-9, Math.abs(b - t) / 2), (px - cx) / maxOf(1e-9, Math.abs(r - l) / 2)))
    }
    /** Yay aralığı: saat yönünün tersine (varsayılan) a0'dan a1'e; cw ise saat yönünde. */
    private fun arcRange(a0: Double, a1: Double, cw: Boolean): Pair<Double, Double> {
        var e = a1
        if (!cw) { while (e <= a0) e += 360.0 } else { while (e >= a0) e -= 360.0 }
        return a0 to e
    }

    /** GDI/GDI+ tarama stili (0 yatay, 1 dikey, 2 \\, 3 /, 4 artı, 5 çapraz) için 8x8 desen. */
    private fun hatchTile(style: Int, fg: Int, bg: Int): Tile {
        val a = IntArray(64) { bg }
        for (y in 0 until 8) for (x in 0 until 8) {
            val on = when (style) {
                0 -> y == 3
                1 -> x == 3
                2 -> (x - y + 8) % 8 == 0
                3 -> (x + y) % 8 == 7
                4 -> y == 3 || x == 3
                5 -> (x - y + 8) % 8 == 0 || (x + y) % 8 == 7
                else -> y == 3 || x == 3
            }
            if (on) a[y * 8 + x] = fg
        }
        return Tile(8, 8, a)
    }

    // ---------------- DIB ----------------
    class Dib(val w: Int, val h: Int, val argb: IntArray)

    fun dib(b: ByteArray, offBmi: Int, cbBmi: Int, offBits: Int, cbBits: Int): Dib? {
        if (offBmi < 0 || offBmi + 40 > b.size) return null
        val hs = u32(b, offBmi).toInt()
        if (hs < 40) return null
        val w = s32(b, offBmi + 4); var h = s32(b, offBmi + 8)
        val bpp = u16(b, offBmi + 14); val comp = u32(b, offBmi + 16).toInt()
        val topDown = h < 0; h = Math.abs(h)
        if (w <= 0 || h <= 0 || w.toLong() * h > MAX_PIXELS) return null
        if (comp != 0 && comp != 3 && !((comp == 1 && bpp == 8) || (comp == 2 && bpp == 4)) || (comp in 1..2 && topDown)) return null
        if (bpp !in setOf(1, 4, 8, 16, 24, 32)) return null
        var clr = u32(b, offBmi + 32).toInt()
        if (bpp <= 8 && clr == 0) clr = 1 shl bpp
        val palOff = offBmi + hs + (if (comp == 3 && hs == 40) 12 else 0)
        var bits = offBits
        if (bits <= 0 || bits >= b.size) bits = offBmi + hs + (if (bpp <= 8) 4 * clr else 0) + (if (comp == 3 && hs == 40) 12 else 0)
        val stride = ((w * bpp + 31) / 32) * 4
        val out = IntArray(w * h)
        if (comp == 1 || comp == 2) {
            val idx = rle(b, bits, if (cbBits > 0) minOf(b.size, bits + cbBits) else b.size, w, h, comp == 2)
            for (y in 0 until h) for (x in 0 until w) {
                val v = idx[y * w + x]                       // satır 0 = alt satır
                out[(h - 1 - y) * w + x] = if (v < 0) 0 else pal(b, palOff, v, clr)
            }
            return Dib(w, h, out)
        }
        var rm = 0xFF0000; var gm = 0x00FF00; var bm = 0x0000FF
        if (comp == 3 && bpp >= 16) { rm = u32(b, offBmi + 40).toInt(); gm = u32(b, offBmi + 44).toInt(); bm = u32(b, offBmi + 48).toInt() }
        else if (bpp == 16) { rm = 0x7C00; gm = 0x03E0; bm = 0x001F }
        fun comp8(v: Int, mask: Int): Int { if (mask == 0) return 0; val sh = Integer.numberOfTrailingZeros(mask); val m = mask ushr sh; return ((v and mask) ushr sh) * 255 / m }
        var anyAlpha = false
        for (y in 0 until h) {
            val sy = if (topDown) y else h - 1 - y
            val ro = bits + sy * stride
            if (ro + (w * bpp + 7) / 8 > b.size) break
            for (x in 0 until w) {
                val px = when (bpp) {
                    1 -> { val v = (u8(b, ro + x / 8) shr (7 - x % 8)) and 1; pal(b, palOff, v, clr) }
                    4 -> { val v = (u8(b, ro + x / 2) shr (if (x % 2 == 0) 4 else 0)) and 15; pal(b, palOff, v, clr) }
                    8 -> pal(b, palOff, u8(b, ro + x), clr)
                    16 -> { val v = u16(b, ro + 2 * x); (0xFF shl 24) or (comp8(v, rm) shl 16) or (comp8(v, gm) shl 8) or comp8(v, bm) }
                    24 -> (0xFF shl 24) or (u8(b, ro + 3 * x + 2) shl 16) or (u8(b, ro + 3 * x + 1) shl 8) or u8(b, ro + 3 * x)
                    else -> { val a = u8(b, ro + 4 * x + 3); if (a != 0) anyAlpha = true; (a shl 24) or (u8(b, ro + 4 * x + 2) shl 16) or (u8(b, ro + 4 * x + 1) shl 8) or u8(b, ro + 4 * x) }
                }
                out[y * w + x] = px
            }
        }
        if (bpp == 32 && !anyAlpha) for (i in out.indices) out[i] = out[i] or (0xFF shl 24)
        return Dib(w, h, out)
    }
    /** RLE8/RLE4 → palet indeksleri (-1 = yazılmamış). Satır 0 = dosyadaki ilk (alt) satır. */
    private fun rle(b: ByteArray, from: Int, end: Int, w: Int, h: Int, four: Boolean): IntArray {
        val out = IntArray(w * h) { -1 }
        var p = from; var x = 0; var y = 0
        fun put(v: Int) { if (x in 0 until w && y in 0 until h) out[y * w + x] = v; x++ }
        while (p + 1 < end && y < h) {
            val n = u8(b, p); val v = u8(b, p + 1); p += 2
            if (n > 0) {
                if (!four) repeat(n) { put(v) } else for (k in 0 until n) put(if (k % 2 == 0) v shr 4 else v and 15)
            } else when (v) {
                0 -> { x = 0; y++ }
                1 -> return out
                2 -> { x += u8(b, p); y += u8(b, p + 1); p += 2 }
                else -> {
                    if (!four) { for (k in 0 until v) put(u8(b, p + k)); p += v + (v and 1) }
                    else { for (k in 0 until v) { val by = u8(b, p + k / 2); put(if (k % 2 == 0) by shr 4 else by and 15) }; val bytes = (v + 1) / 2; p += bytes + (bytes and 1) }
                }
            }
        }
        return out
    }
    private fun pal(b: ByteArray, off: Int, i: Int, n: Int): Int {
        if (i >= n) return 0xFF000000.toInt()
        val o = off + 4 * i
        return (0xFF shl 24) or (u8(b, o + 2) shl 16) or (u8(b, o + 1) shl 8) or u8(b, o)
    }
    private fun crop(d: Dib, sx: Int, sy: Int, sw: Int, sh: Int): Dib {
        if (sw <= 0 || sh <= 0 || sx < 0 || sy < 0 || sx + sw > d.w || sy + sh > d.h || (sx == 0 && sy == 0 && sw == d.w && sh == d.h)) return d
        val o = IntArray(sw * sh)
        for (y in 0 until sh) System.arraycopy(d.argb, (sy + y) * d.w + sx, o, y * sw, sw)
        return Dib(sw, sh, o)
    }

    // ---------------- EMF ----------------
    private fun parseEmf(b: ByteArray): Meta? {
        val o = Out()
        val objs = HashMap<Int, Any>()
        var bl = s32(b, 8).toDouble(); var bt = s32(b, 12).toDouble(); var br = s32(b, 16).toDouble(); var bb = s32(b, 20).toDouble()
        var p = 0
        var guard = 0
        val plusOnly = isPlusOnly(b)
        val plus = if (plusOnly) Plus(o, b) else null
        while (p + 8 <= b.size && guard++ < 2_000_000) {
            val type = u32(b, p).toInt(); val size = u32(b, p + 4).toInt()
            if (size < 8 || size % 4 != 0 || p.toLong() + size > b.size) break
            val d = p // kayıt başı
            if (plusOnly && type != 70 && type != 14 && type != 1) { p += size; continue }
            val st = o.cur
            fun i32(off: Int) = s32(b, d + off)
            fun d32(off: Int) = s32(b, d + off).toDouble()
            when (type) {
                14 -> break
                70 -> if (plus != null && size >= 20 && u32(b, d + 12) == 0x2B464D45L) plus.run(d + 16, minOf(d + size, d + 12 + maxOf(0, i32(8))))
                9 -> { st.wex = d32(8); st.wey = d32(12) }
                10 -> { st.wox = d32(8); st.woy = d32(12) }
                11 -> { st.vex = d32(8); st.vey = d32(12) }
                12 -> { st.vox = d32(8); st.voy = d32(12) }
                17 -> st.mapMode = i32(8)
                19 -> st.evenOdd = i32(8) != 2
                22 -> st.textAlign = i32(8)
                24 -> st.textColor = colorOf(i32(8))
                27 -> { st.cx = d32(8); st.cy = d32(12); if (o.inPath) { o.flushSub(false); o.curSub = arrayListOf(st.cx, st.cy); o.figX = st.cx; o.figY = st.cy } }
                33 -> { o.stack.add(st.copy()); o.ops.add(Save) }
                34 -> { val n = i32(8); if (n < 0 && o.stack.size >= -n) { var x = st; repeat(-n) { x = o.stack.removeAt(o.stack.size - 1); o.ops.add(Restore) }; o.cur = x } }
                30, 29 -> { val l = d32(8); val t = d32(12); val r = d32(16); val bt2 = d32(20); o.clipRaw(listOf(doubleArrayOf(l, t, r, t, r, bt2, l, bt2) to true), type == 29) }
                67 -> { val m = i32(8); if (!o.inPath && o.path.isNotEmpty() && (m == 1 || m == 5 || m == 4)) o.ops.add(Clip(ArrayList(o.path), st.evenOdd, m == 4)); o.path.clear() }
                75 -> {
                    val cb = i32(8); val m = i32(12)
                    if (cb >= 32 && (m == 1 || m == 4 || m == 5) && 16 + cb <= size) {
                        val cnt = i32(24).coerceIn(0, 100000)
                        val rects = ArrayList<Pair<DoubleArray, Boolean>>()
                        for (k in 0 until cnt) { val q = 48 + 16 * k; if (q + 16 > size) break; val l = d32(q); val t = d32(q + 4); val r = d32(q + 8); val bt2 = d32(q + 12); rects.add(doubleArrayOf(l, t, r, t, r, bt2, l, bt2) to true) }
                        o.clipRaw(rects, m == 4)
                    }
                }
                93, 94 -> {
                    val offBmi = i32(16); val cbBmi = i32(20); val offBits = i32(24); val cbBits = i32(28)
                    if (cbBmi > 0 && offBmi > 0 && offBmi < size) {
                        val dd = dib(b, d + offBmi, cbBmi, if (offBits > 0) d + offBits else 0, cbBits)
                        if (dd != null) objs[i32(8)] = Brush(dd.argb[0], false, Tile(dd.w, dd.h, dd.argb))
                    }
                }
                118 -> {
                    val nv = i32(24); val nt = i32(28); val mode = i32(32)
                    if (nv in 1..100000 && nt in 0..100000 && 36 + 16 * nv.toLong() <= size) {
                        fun vx(k: Int) = d32(36 + 16 * k)
                        fun vy(k: Int) = d32(40 + 16 * k)
                        fun vc(k: Int): Int { val q = d + 44 + 16 * k; return (0xFF shl 24) or ((u16(b, q) shr 8) shl 16) or ((u16(b, q + 2) shr 8) shl 8) or (u16(b, q + 4) shr 8) }
                        val base = 36 + 16 * nv
                        for (k in 0 until nt) {
                            if (mode == 2) {
                                val q = base + 12 * k; if (q + 12 > size) break
                                val ia = i32(q); val ib = i32(q + 4); val ic = i32(q + 8)
                                if (ia !in 0 until nv || ib !in 0 until nv || ic !in 0 until nv) continue
                                val ca = vc(ia); val cb2 = vc(ib); val cc = vc(ic)
                                val avg = (0xFF shl 24) or (((((ca shr 16) and 255) + ((cb2 shr 16) and 255) + ((cc shr 16) and 255)) / 3) shl 16) or (((((ca shr 8) and 255) + ((cb2 shr 8) and 255) + ((cc shr 8) and 255)) / 3) shl 8) or (((ca and 255) + (cb2 and 255) + (cc and 255)) / 3)
                                o.emitDev(listOf(Sub(o.pts(doubleArrayOf(vx(ia), vy(ia), vx(ib), vy(ib), vx(ic), vy(ic))), true)), avg, null, 1.0, null, 0, true)
                            } else {
                                val q = base + 8 * k; if (q + 8 > size) break
                                val ia = i32(q); val ib = i32(q + 4)
                                if (ia !in 0 until nv || ib !in 0 until nv) continue
                                val l = minOf(vx(ia), vx(ib)); val r = maxOf(vx(ia), vx(ib)); val t = minOf(vy(ia), vy(ib)); val bm = maxOf(vy(ia), vy(ib))
                                val pr = o.pts(doubleArrayOf(l, t, r, t, r, bm, l, bm))
                                val first = if (vx(ia) <= vx(ib) && vy(ia) <= vy(ib)) ia else if (mode == 0) (if (vx(ia) <= vx(ib)) ia else ib) else (if (vy(ia) <= vy(ib)) ia else ib)
                                val second = if (first == ia) ib else ia
                                val sh = if (mode == 0) Linear(pr[0], pr[1], pr[2], pr[3], intArrayOf(vc(first), vc(second)), doubleArrayOf(0.0, 1.0))
                                         else Linear(pr[0], pr[1], pr[6], pr[7], intArrayOf(vc(first), vc(second)), doubleArrayOf(0.0, 1.0))
                                o.emitDev(listOf(Sub(pr, true)), vc(first), null, 1.0, sh, 0, true)
                            }
                        }
                    }
                }
                35 -> { st.m11 = f32(b, d + 8); st.m12 = f32(b, d + 12); st.m21 = f32(b, d + 16); st.m22 = f32(b, d + 20); st.dx = f32(b, d + 24); st.dy = f32(b, d + 28) }
                36 -> {
                    val a11 = f32(b, d + 8); val a12 = f32(b, d + 12); val a21 = f32(b, d + 16); val a22 = f32(b, d + 20); val adx = f32(b, d + 24); val ady = f32(b, d + 28)
                    when (i32(32)) {
                        1 -> { st.m11 = 1.0; st.m12 = 0.0; st.m21 = 0.0; st.m22 = 1.0; st.dx = 0.0; st.dy = 0.0 }
                        2 -> { // yeni × mevcut
                            val n11 = a11 * st.m11 + a12 * st.m21; val n12 = a11 * st.m12 + a12 * st.m22
                            val n21 = a21 * st.m11 + a22 * st.m21; val n22 = a21 * st.m12 + a22 * st.m22
                            val ndx = adx * st.m11 + ady * st.m21 + st.dx; val ndy = adx * st.m12 + ady * st.m22 + st.dy
                            st.m11 = n11; st.m12 = n12; st.m21 = n21; st.m22 = n22; st.dx = ndx; st.dy = ndy
                        }
                        3 -> { // mevcut × yeni
                            val n11 = st.m11 * a11 + st.m12 * a21; val n12 = st.m11 * a12 + st.m12 * a22
                            val n21 = st.m21 * a11 + st.m22 * a21; val n22 = st.m21 * a12 + st.m22 * a22
                            val ndx = st.dx * a11 + st.dy * a21 + adx; val ndy = st.dx * a12 + st.dy * a22 + ady
                            st.m11 = n11; st.m12 = n12; st.m21 = n21; st.m22 = n22; st.dx = ndx; st.dy = ndy
                        }
                        4 -> { st.m11 = a11; st.m12 = a12; st.m21 = a21; st.m22 = a22; st.dx = adx; st.dy = ady }
                    }
                }
                37 -> {
                    val h = i32(8)
                    if (h < 0) { // stok nesne
                        when (h and 0x7FFFFFFF) {
                            0 -> st.brush = Brush(0xFFFFFFFF.toInt(), false)
                            1 -> st.brush = Brush(0xFFC0C0C0.toInt(), false)
                            2 -> st.brush = Brush(0xFF808080.toInt(), false)
                            3 -> st.brush = Brush(0xFF404040.toInt(), false)
                            4 -> st.brush = Brush(0xFF000000.toInt(), false)
                            5 -> st.brush = Brush(0, true)
                            6 -> st.pen = Pen(0xFFFFFFFF.toInt(), 1.0, 0)
                            7 -> st.pen = Pen(0xFF000000.toInt(), 1.0, 0)
                            8 -> st.pen = Pen(0, 1.0, 5)
                        }
                    } else when (val ob = objs[h]) { is Pen -> st.pen = ob; is Brush -> st.brush = ob; is Font -> st.font = ob }
                }
                38 -> objs[i32(8)] = Pen(colorOf(i32(24)), d32(16).let { if (it < 1) 1.0 else it }, i32(12))
                95 -> objs[i32(8)] = Pen(colorOf(i32(40)), u32(b, d + 32).toDouble().let { if (it < 1) 1.0 else it }, i32(28))
                39 -> {
                    val sty = i32(12); val col = colorOf(i32(16))
                    objs[i32(8)] = if (sty == 2) Brush(col, false, hatchTile(i32(20), col, 0)) else Brush(col, sty == 1)
                }
                82 -> {
                    val h = d32(12); val w = i32(28); val ital = u8(b, d + 12 + 20) != 0
                    objs[i32(8)] = Font(h, w, ital, i32(20) / 10.0)
                }
                40 -> objs.remove(i32(8))
                54 -> {
                    val nx = d32(8); val ny = d32(12)
                    if (o.inPath) { if (o.curSub.isEmpty()) { o.curSub.add(st.cx); o.curSub.add(st.cy) }; o.curSub.add(nx); o.curSub.add(ny) }
                    else o.poly(listOf(doubleArrayOf(st.cx, st.cy, nx, ny) to false), false, true)
                    st.cx = nx; st.cy = ny
                }
                2, 5, 85, 88 -> { // bezier
                    val n = i32(24); val wide = type == 2 || type == 5
                    val pts = DoubleArray(2 * n) { k -> if (wide) d32(28 + 4 * k) else s16(b, d + 28 + 2 * k).toDouble() }
                    val to = type == 5 || type == 88
                    val all = ArrayList<Double>()
                    if (to) { all.add(st.cx); all.add(st.cy); for (v in pts) all.add(v) } else for (v in pts) all.add(v)
                    val arr = all.toDoubleArray()
                    val res = ArrayList<Double>(); if (arr.size >= 2) { res.add(arr[0]); res.add(arr[1]) }
                    var i = 0
                    while (i + 8 <= arr.size) { bezier(arr, i, res); i += 6 }
                    if (o.inPath && to) {
                        if (o.curSub.isEmpty()) { o.curSub.add(st.cx); o.curSub.add(st.cy) }
                        for (k in 2 until res.size) o.curSub.add(res[k])
                    } else if (res.size >= 4) { if (o.inPath) o.flushSub(false); o.poly(listOf(res.toDoubleArray() to false), false, true) }
                    if (arr.size >= 2) { st.cx = arr[arr.size - 2]; st.cy = arr[arr.size - 1] }
                }
                3, 4, 6, 86, 87, 89 -> {
                    val n = i32(24); val wide = type in setOf(3, 4, 6)
                    if (n in 1..1_000_000) {
                        val pts = ArrayList<Double>()
                        if (type == 6 || type == 89) { pts.add(st.cx); pts.add(st.cy) }
                        for (k in 0 until n) { pts.add(if (wide) d32(28 + 8 * k) else s16(b, d + 28 + 4 * k).toDouble()); pts.add(if (wide) d32(32 + 8 * k) else s16(b, d + 30 + 4 * k).toDouble()) }
                        val closed = type == 3 || type == 86
                        if (o.inPath && (type == 6 || type == 89)) {
                            if (o.curSub.isEmpty()) { o.curSub.add(st.cx); o.curSub.add(st.cy) }
                            for (k in 2 until pts.size) o.curSub.add(pts[k])
                        } else { if (o.inPath) o.flushSub(false); o.poly(listOf(pts.toDoubleArray() to closed), closed, true) }
                        st.cx = pts[pts.size - 2]; st.cy = pts[pts.size - 1]
                    }
                }
                7, 8, 90, 91 -> {
                    val np = i32(24); val total = i32(28); val wide = type == 7 || type == 8
                    if (np in 1..100000 && total in 0..2_000_000) {
                        val counts = IntArray(np) { i32(32 + 4 * it) }
                        var base = 32 + 4 * np
                        val subs = ArrayList<Pair<DoubleArray, Boolean>>()
                        val closed = type == 8 || type == 91
                        for (c in counts) {
                            if (c < 0 || c > total) break
                            val pts = DoubleArray(2 * c) { k -> val idx = k / 2; if (wide) d32(base + 8 * idx + 4 * (k % 2)) else s16(b, d + base + 4 * idx + 2 * (k % 2)).toDouble() }
                            subs.add(pts to closed)
                            base += c * (if (wide) 8 else 4)
                        }
                        o.poly(subs, closed, true)
                    }
                }
                43 -> o.poly(listOf(doubleArrayOf(d32(8), d32(12), d32(16), d32(12), d32(16), d32(20), d32(8), d32(20)) to true), true, true)
                44 -> o.poly(listOf(roundRectPts(d32(8), d32(12), d32(16), d32(20), d32(24), d32(28)) to true), true, true)
                42 -> o.poly(listOf(ellipsePts(d32(8), d32(12), d32(16), d32(20)) to true), true, true)
                45, 46, 47 -> {
                    val l = d32(8); val t = d32(12); val r = d32(16); val bt2 = d32(20)
                    val (a0, a1) = arcRange(angleOf(l, t, r, bt2, d32(24), d32(28)), angleOf(l, t, r, bt2, d32(32), d32(36)), o.arcCw)
                    val pts = ellipsePts(l, t, r, bt2, a0, a1, 40)
                    when (type) {
                        45 -> o.poly(listOf(pts to false), false, true)
                        46 -> o.poly(listOf(pts to true), true, true)
                        else -> o.poly(listOf((doubleArrayOf((l + r) / 2, (t + bt2) / 2) + pts) to true), true, true)
                    }
                }
                59 -> { o.inPath = true; o.path.clear(); o.curSub = ArrayList() }
                60 -> { o.flushSub(false); o.inPath = false }
                61 -> { o.flushSub(true); st.cx = o.figX; st.cy = o.figY }
                57 -> o.arcCw = i32(8) == 2
                55 -> {
                    val l = d32(8); val t = d32(12); val r = d32(16); val bt2 = d32(20)
                    val a0 = angleOf(l, t, r, bt2, d32(24), d32(28)); val a1 = angleOf(l, t, r, bt2, d32(32), d32(36))
                    val (s0, s1) = arcRange(a0, a1, o.arcCw)
                    val arc = ellipsePts(l, t, r, bt2, s0, s1, 40)
                    val pts = ArrayList<Double>(); pts.add(st.cx); pts.add(st.cy); for (v in arc) pts.add(v)
                    if (o.inPath) { if (o.curSub.isEmpty()) { o.curSub.add(st.cx); o.curSub.add(st.cy) }; for (k in 2 until pts.size) o.curSub.add(pts[k]) }
                    else o.poly(listOf(pts.toDoubleArray() to false), false, true)
                    st.cx = arc[arc.size - 2]; st.cy = arc[arc.size - 1]
                }
                62 -> o.finishPath(true, false)
                63 -> o.finishPath(true, true)
                64 -> o.finishPath(false, true)
                68 -> { o.path.clear(); o.inPath = false }
                83, 84 -> {
                    val wide = type == 84
                    val n = i32(44); val offS = i32(48)
                    if (n in 1..100000 && offS in 8 until size) {
                        val s = if (wide) String(b, d + offS, minOf(2 * n, size - offS), Charsets.UTF_16LE) else String(b, d + offS, minOf(n, size - offS), charset("windows-1254"))
                        val f = st.font
                        val sizePx = if (f != null) Math.abs(f.height) * st.scaleY() * (if (f.height > 0) 0.8 else 1.0) else 12.0 * st.scaleY()
                        val rx = d32(36); val ry = d32(40)
                        val x = st.tx(rx, ry); val y = st.ty(rx, ry)
                        o.ext(x, y)
                        o.ops.add(Text(x, y, s, st.textColor, maxOf(4.0, sizePx), (f?.weight ?: 400) >= 600, f?.italic ?: false, f?.angle ?: 0.0, st.textAlign))
                    }
                }
                76, 77, 81, 80 -> {
                    val xd: Int; val yd: Int; var cxd: Int; var cyd: Int; val offBmi: Int; val cbBmi: Int; val offBits: Int; val cbBits: Int
                    var sx = 0; var sy = 0; var sw = 0; var sh = 0
                    when (type) {
                        81 -> { xd = i32(24); yd = i32(28); sx = i32(32); sy = i32(36); sw = i32(40); sh = i32(44); offBmi = i32(48); cbBmi = i32(52); offBits = i32(56); cbBits = i32(60); cxd = i32(72); cyd = i32(76) }
                        80 -> { xd = i32(24); yd = i32(28); sx = i32(32); sy = i32(36); sw = i32(40); sh = i32(44); offBmi = i32(48); cbBmi = i32(52); offBits = i32(56); cbBits = i32(60); cxd = sw; cyd = sh }
                        else -> { xd = i32(24); yd = i32(28); cxd = i32(32); cyd = i32(36); offBmi = i32(84); cbBmi = i32(88); offBits = i32(92); cbBits = i32(96); sx = i32(44); sy = i32(48); sw = if (type == 77) i32(100) else cxd; sh = if (type == 77) i32(104) else cyd }
                    }
                    if (cbBmi > 0 && offBmi > 0 && offBmi < size) {
                        val dd = dib(b, d + offBmi, cbBmi, if (offBits > 0) d + offBits else 0, cbBits)
                        if (dd != null && o.ops.size < MAX_OPS) {
                            val c = if (sw > 0 && sh > 0) crop(dd, sx, sy, sw, sh) else dd
                            val x0 = st.tx(xd.toDouble(), yd.toDouble()); val y0 = st.ty(xd.toDouble(), yd.toDouble())
                            val x1 = st.tx((xd + cxd).toDouble(), (yd + cyd).toDouble()); val y1 = st.ty((xd + cxd).toDouble(), (yd + cyd).toDouble())
                            o.ext(x0, y0); o.ext(x1, y1)
                            o.ops.add(Bmp(minOf(x0, x1), minOf(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0), c.w, c.h, c.argb))
                        }
                    }
                }
            }
            p += size
        }
        return finish(o, bl, bt, br + 1, bb + 1)
    }

    // ---------------- EMF+ ----------------
    /** Dosyada EMF+ başlığı var ve "dual" bayrağı yoksa true (yalnız-EMF+: EMF kayıtları çizilmez). */
    private fun isPlusOnly(b: ByteArray): Boolean {
        var p = 0; var g = 0
        while (p + 8 <= b.size && g++ < 100000) {
            val type = u32(b, p).toInt(); val size = u32(b, p + 4).toInt()
            if (size < 8 || size % 4 != 0 || p.toLong() + size > b.size) return false
            if (type == 70 && size >= 28 && u32(b, p + 12) == 0x2B464D45L) return u16(b, p + 16) == 0x4001 && (u16(b, p + 18) and 1) == 0
            if (type == 14) return false
            p += size
        }
        return false
    }

    private class PBrush(val kind: Int, val argb: Int, val rx: Double = 0.0, val ry: Double = 0.0, val rw: Double = 0.0, val rh: Double = 0.0, val mat: DoubleArray? = null, val colors: IntArray? = null, val pos: DoubleArray? = null, val tile: Tile? = null)
    private class PPen(val width: Double, val brush: PBrush?, val dash: Int)
    private class PFont(val em: Double, val unit: Int, val bold: Boolean, val italic: Boolean)
    private class PPath(val subs: List<Sub>)
    private class PImage(val w: Int, val h: Int, val argb: IntArray?, val data: ByteArray?)

    private fun mmul(a: DoubleArray, c: DoubleArray): DoubleArray = doubleArrayOf(
        a[0] * c[0] + a[1] * c[2], a[0] * c[1] + a[1] * c[3], a[2] * c[0] + a[3] * c[2], a[2] * c[1] + a[3] * c[3],
        a[4] * c[0] + a[5] * c[2] + c[4], a[4] * c[1] + a[5] * c[3] + c[5])

    private class Plus(val o: Out, val b: ByteArray) {
        var dpi = 96.0
        var world = doubleArrayOf(1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
        var ps = 1.0
        val objs = HashMap<Int, Any>()
        val partial = HashMap<Int, java.io.ByteArrayOutputStream>()
        val partialTotal = HashMap<Int, Int>()
        class Saved(val index: Int, val world: DoubleArray, val ps: Double)
        val stack = ArrayList<Saved>()

        fun f(off: Int) = f32(b, off)
        fun argb(off: Int): Int = (u8(b, off + 3) shl 24) or (u8(b, off + 2) shl 16) or (u8(b, off + 1) shl 8) or u8(b, off)
        fun scale(): Double = Math.sqrt(Math.abs(world[0] * world[3] - world[1] * world[2])).let { if (it == 0.0) 1.0 else it } * ps
        fun dx(x: Double, y: Double) = (x * world[0] + y * world[2] + world[4]) * ps
        fun dy(x: Double, y: Double) = (x * world[1] + y * world[3] + world[5]) * ps
        fun tr(raw: DoubleArray): DoubleArray { val r = DoubleArray(raw.size); var i = 0; while (i + 1 < raw.size) { r[i] = dx(raw[i], raw[i + 1]); r[i + 1] = dy(raw[i], raw[i + 1]); i += 2 }; return r }
        fun unitScale(u: Int): Double = when (u) { 3 -> dpi / 72; 4 -> dpi; 5 -> dpi / 300; 6 -> dpi / 25.4; else -> 1.0 }

        fun run(start: Int, end: Int) {
            var p = start; var g = 0
            while (p + 12 <= end && g++ < 1_000_000) {
                val type = u16(b, p); val flags = u16(b, p + 2); val size = u32(b, p + 4).toInt(); val dsz = u32(b, p + 8).toInt()
                if (size < 12 || p + size > end + 3 || dsz < 0) break
                val de = minOf(end, p + 12 + dsz)
                try { record(type, flags, p + 12, de) } catch (e: IndexOutOfBoundsException) { } catch (e: NegativeArraySizeException) { }
                p += size
            }
        }

        // ---- şekil yardımcıları
        fun rectPts(l: Double, t: Double, r: Double, bt: Double) = doubleArrayOf(l, t, r, t, r, bt, l, bt)
        /** Sıkıştırılmış (int16) ya da float dikdörtgen: (x,y,w,h) → (l,t,r,b). */
        fun rectAt(off: Int, comp: Boolean): DoubleArray = if (comp) { val x = s16(b, off).toDouble(); val y = s16(b, off + 2).toDouble(); doubleArrayOf(x, y, x + s16(b, off + 4), y + s16(b, off + 6)) } else { val x = f(off); val y = f(off + 4); doubleArrayOf(x, y, x + f(off + 8), y + f(off + 12)) }
        fun rectSize(comp: Boolean) = if (comp) 8 else 16
        fun points(off: Int, n: Int, comp: Boolean): DoubleArray = DoubleArray(2 * n) { k -> if (comp) s16(b, off + 2 * k).toDouble() else f(off + 4 * k) }

        fun cardinal(pt: DoubleArray, tension: Double, closed: Boolean): DoubleArray {
            val n = pt.size / 2; if (n < 2) return pt
            val out = ArrayList<Double>(); out.add(pt[0]); out.add(pt[1])
            fun px(i: Int) = if (closed) pt[2 * ((i % n + n) % n)] else pt[2 * i.coerceIn(0, n - 1)]
            fun py(i: Int) = if (closed) pt[2 * ((i % n + n) % n) + 1] else pt[2 * i.coerceIn(0, n - 1) + 1]
            val segs = if (closed) n else n - 1
            for (i in 0 until segs) {
                val tx0 = tension * (px(i + 1) - px(i - 1)); val ty0 = tension * (py(i + 1) - py(i - 1))
                val tx1 = tension * (px(i + 2) - px(i)); val ty1 = tension * (py(i + 2) - py(i))
                val arr = doubleArrayOf(px(i), py(i), px(i) + tx0 / 3, py(i) + ty0 / 3, px(i + 1) - tx1 / 3, py(i + 1) - ty1 / 3, px(i + 1), py(i + 1))
                val tmp = ArrayList<Double>(); bezier(arr, 0, tmp); out.addAll(tmp)
            }
            return out.toDoubleArray()
        }

        // ---- fırça / kalem çözümü
        fun brushAt(sel: Int, isColor: Boolean): PBrush? = if (isColor) PBrush(0, sel) else objs[sel and 0xFF] as? PBrush

        fun fillOf(br: PBrush): Triple<Int?, Shade?, Boolean> = when (br.kind) {
            0 -> Triple(br.argb, null, true)
            1 -> Triple(br.argb, br.tile, true)
            4 -> {
                val m = br.mat ?: doubleArrayOf(1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
                val sx = br.rx; val sy = br.ry + br.rh / 2; val ex = br.rx + br.rw; val ey = sy
                val ax = sx * m[0] + sy * m[2] + m[4]; val ay = sx * m[1] + sy * m[3] + m[5]
                val bx = ex * m[0] + ey * m[2] + m[4]; val by = ex * m[1] + ey * m[3] + m[5]
                val cols = br.colors ?: intArrayOf(br.argb, br.argb); val pos = br.pos ?: doubleArrayOf(0.0, 1.0)
                Triple(cols.first(), Linear(dx(ax, ay), dy(ax, ay), dx(bx, by), dy(bx, by), cols, pos), true)
            }
            else -> Triple(br.argb, null, true)
        }

        fun fillShapes(raw: List<Pair<DoubleArray, Boolean>>, br: PBrush?, eo: Boolean = false) {
            if (br == null) return
            val (c, sh, _) = fillOf(br)
            o.emitDev(raw.map { Sub(tr(it.first), it.second) }, c, null, 1.0, sh, 0, eo)
        }
        fun strokeShapes(raw: List<Pair<DoubleArray, Boolean>>, pen: PPen?) {
            if (pen == null) return
            val col = pen.brush?.let { fillOf(it).first } ?: 0xFF000000.toInt()
            o.emitDev(raw.map { Sub(tr(it.first), it.second) }, null, col, maxOf(1.0, pen.width * scale()), null, pen.dash, false)
        }
        fun penOf(flags: Int): PPen? = objs[flags and 0xFF] as? PPen

        // ---- nesne ayrıştırma
        fun parseBrush(off: Int): PBrush? {
            val kind = s32(b, off + 4)
            return when (kind) {
                0 -> PBrush(0, argb(off + 8))
                1 -> { val hs = s32(b, off + 8); PBrush(1, argb(off + 12), tile = hatchTile(hs, argb(off + 12), argb(off + 16))) }
                4 -> {
                    val fl = s32(b, off + 8)
                    val rx = f(off + 16); val ry = f(off + 20); val rw = f(off + 24); val rh = f(off + 28)
                    val c0 = argb(off + 32); val c1 = argb(off + 36)
                    var q = off + 48
                    var mat: DoubleArray? = null
                    if (fl and 0x2 != 0) { mat = DoubleArray(6) { f(q + 4 * it) }; q += 24 }
                    var cols: IntArray? = null; var pos: DoubleArray? = null
                    if (fl and 0x4 != 0) {
                        val n = s32(b, q); if (n in 1..1024) { pos = DoubleArray(n) { f(q + 4 + 4 * it) }; cols = IntArray(n) { argb(q + 4 + 4 * n + 4 * it) } }
                    } else if (fl and 0x8 != 0) {
                        val n = s32(b, q)
                        if (n in 1..1024) {
                            pos = DoubleArray(n) { f(q + 4 + 4 * it) }
                            cols = IntArray(n) { val t = f(q + 4 + 4 * n + 4 * it).coerceIn(0.0, 1.0); lerp(c0, c1, t) }
                        }
                    }
                    PBrush(4, c0, rx, ry, rw, rh, mat, cols ?: intArrayOf(c0, c1), pos ?: doubleArrayOf(0.0, 1.0))
                }
                3 -> PBrush(0, argb(off + 16))        // yol gradyanı: merkez renkle yaklaşık
                else -> null
            }
        }
        fun lerp(a: Int, c: Int, t: Double): Int {
            fun ch(sh: Int) = (((a ushr sh) and 255) + (((c ushr sh) and 255) - ((a ushr sh) and 255)) * t).toInt().coerceIn(0, 255)
            return (ch(24) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
        }

        fun parsePen(off: Int, end: Int): PPen? {
            val fl = s32(b, off + 8); val width = f(off + 16)
            var q = off + 20
            if (fl and 0x1 != 0) q += 24
            if (fl and 0x2 != 0) q += 4
            if (fl and 0x4 != 0) q += 4
            if (fl and 0x8 != 0) q += 4
            if (fl and 0x10 != 0) q += 4
            var dash = 0
            if (fl and 0x20 != 0) { dash = s32(b, q).let { if (it in 0..4) it else 1 }; q += 4 }
            if (fl and 0x40 != 0) q += 4
            if (fl and 0x80 != 0) q += 4
            if (fl and 0x100 != 0) { val n = s32(b, q); if (n < 0 || n > 1000) return null; q += 4 + 4 * n; if (dash == 0) dash = 1 }
            if (fl and 0x200 != 0) q += 4
            if (fl and 0x400 != 0) { val n = s32(b, q); if (n < 0 || n > 1000) return null; q += 4 + 4 * n }
            if (fl and 0x1800 != 0 || q + 8 > end) return PPen(width, null, dash)
            return PPen(width.toDouble(), parseBrush(q), dash)
        }

        fun parsePath(off: Int): PPath? {
            val n = s32(b, off + 4); val fl = s32(b, off + 8)
            if (n !in 1..500000) return null
            if (fl and 0x800 != 0) return null           // göreli noktalar desteklenmez
            val comp = fl and 0x4000 != 0
            val ps = if (comp) 4 else 8
            val pts = points(off + 12, n, comp)
            val tOff = off + 12 + ps * n
            val subs = ArrayList<Sub>(); var cur = ArrayList<Double>(); var closed = false
            fun flush() { if (cur.size >= 4) subs.add(Sub(cur.toDoubleArray(), closed)); cur = ArrayList(); closed = false }
            var i = 0
            while (i < n) {
                val t = u8(b, tOff + i); val ty = t and 0xF
                val x = pts[2 * i]; val y = pts[2 * i + 1]
                when (ty) {
                    0 -> { flush(); cur.add(x); cur.add(y) }
                    1 -> { if (cur.isEmpty()) { cur.add(x); cur.add(y) } else { cur.add(x); cur.add(y) } }
                    3 -> {
                        if (i + 2 < n && cur.size >= 2) {
                            val arr = doubleArrayOf(cur[cur.size - 2], cur[cur.size - 1], x, y, pts[2 * i + 2], pts[2 * i + 3], pts[2 * i + 4], pts[2 * i + 5])
                            val tmp = ArrayList<Double>(); bezier(arr, 0, tmp); cur.addAll(tmp)
                            i += 2
                        } else { cur.add(x); cur.add(y) }
                    }
                }
                if ((u8(b, tOff + i) and 0x80) != 0) { closed = true; flush() }
                i++
            }
            flush()
            return PPath(subs)
        }

        fun parseImage(off: Int, end: Int): PImage? {
            val type = s32(b, off + 4)
            if (type != 1) return null
            val w = s32(b, off + 8); val h = s32(b, off + 12); val stride = s32(b, off + 16); val pf = s32(b, off + 20); val dt = s32(b, off + 24)
            val data = off + 28
            if (dt == 1) return if (end - data > 8) PImage(w, h, null, b.copyOfRange(data, end)) else null
            if (w <= 0 || h <= 0 || w.toLong() * h > MAX_PIXELS || stride == 0) return null
            val out = IntArray(w * h)
            val bpp = when (pf and 0xFF00) { 0x2000 -> 32; 0x1800 -> 24; else -> return null }
            for (y in 0 until h) {
                val ro = data + y * stride
                if (ro + w * bpp / 8 > end) break
                for (x in 0 until w) {
                    out[y * w + x] = if (bpp == 32) {
                        val a = u8(b, ro + 4 * x + 3); var r = u8(b, ro + 4 * x + 2); var gg = u8(b, ro + 4 * x + 1); var bl = u8(b, ro + 4 * x)
                        val alpha = if (pf == 0x0026200A || pf == 0x000E200B) a else 255
                        if (pf == 0x000E200B && a in 1..254) { r = minOf(255, r * 255 / a); gg = minOf(255, gg * 255 / a); bl = minOf(255, bl * 255 / a) }
                        (alpha shl 24) or (r shl 16) or (gg shl 8) or bl
                    } else (0xFF shl 24) or (u8(b, ro + 3 * x + 2) shl 16) or (u8(b, ro + 3 * x + 1) shl 8) or u8(b, ro + 3 * x)
                }
            }
            return PImage(w, h, out, null)
        }

        fun parseObject(type: Int, off: Int, end: Int): Any? = when (type) {
            1 -> parseBrush(off)
            2 -> parsePen(off, end)
            3 -> parsePath(off)
            5 -> parseImage(off, end)
            6 -> { val em = f(off + 4); val un = s32(b, off + 8); val st = s32(b, off + 12); PFont(em.toDouble(), un, st and 1 != 0, st and 2 != 0) }
            else -> null
        }

        fun combineClip(mode: Int, subsRaw: List<Pair<DoubleArray, Boolean>>) {
            if (mode == 1 || mode == 0) o.ops.add(Clip(subsRaw.map { Sub(tr(it.first), it.second) }, false, false))
            else if (mode == 4) o.ops.add(Clip(subsRaw.map { Sub(tr(it.first), it.second) }, false, true))
        }

        fun record(type: Int, flags: Int, d: Int, end: Int) {
            val isColor = flags and 0x8000 != 0; val comp = flags and 0x4000 != 0
            when (type) {
                0x4001 -> { dpi = u32(b, d + 8).toDouble().let { if (it in 10.0..2400.0) it else 96.0 } }
                0x4008 -> {
                    val id = flags and 0xFF; val ot = (flags shr 8) and 0x7F
                    if (flags and 0x8000 != 0) {
                        val total = s32(b, d)
                        val bo = partial.getOrPut(id) { java.io.ByteArrayOutputStream() }
                        if (bo.size() == 0) { partialTotal[id] = total; bo.write(b, d + 4, end - d - 4) } else bo.write(b, d, end - d)
                        if (bo.size() >= (partialTotal[id] ?: Int.MAX_VALUE)) { val data = bo.toByteArray(); partial.remove(id); partialTotal.remove(id); sub(ot, data)?.let { objs[id] = it } }
                    } else {
                        parseObject(ot, d, end)?.let { objs[id] = it }
                    }
                }
                0x402A -> { world = DoubleArray(6) { f(d + 4 * it) } }
                0x402B -> { world = doubleArrayOf(1.0, 0.0, 0.0, 1.0, 0.0, 0.0) }
                0x402C -> { val m = DoubleArray(6) { f(d + 4 * it) }; world = if (flags and 0x2000 != 0) mmul(world, m) else mmul(m, world) }
                0x402D -> { val m = doubleArrayOf(1.0, 0.0, 0.0, 1.0, f(d), f(d + 4)); world = if (flags and 0x2000 != 0) mmul(world, m) else mmul(m, world) }
                0x402E -> { val m = doubleArrayOf(f(d), 0.0, 0.0, f(d + 4), 0.0, 0.0); world = if (flags and 0x2000 != 0) mmul(world, m) else mmul(m, world) }
                0x402F -> { val a = Math.toRadians(f(d)); val m = doubleArrayOf(Math.cos(a), Math.sin(a), -Math.sin(a), Math.cos(a), 0.0, 0.0); world = if (flags and 0x2000 != 0) mmul(world, m) else mmul(m, world) }
                0x4030 -> { val sc = f(d); ps = unitScale(flags and 0xFF) * (if (sc > 0) sc else 1.0) }
                0x4025, 0x4029, 0x4027 -> {
                    val idx = if (type == 0x4027) s32(b, d + 32) else s32(b, d)
                    stack.add(Saved(idx, world.copyOf(), ps)); o.ops.add(Save)
                }
                0x4026, 0x4028 -> {
                    val idx = s32(b, d)
                    val at = stack.indexOfLast { it.index == idx }
                    if (at >= 0) { val sv = stack[at]; while (stack.size > at) { stack.removeAt(stack.size - 1); o.ops.add(Restore) }; world = sv.world; ps = sv.ps }
                }
                0x4031 -> { /* ResetClip: desteklenmez */ }
                0x4032 -> { val r = rectAt(d, false); combineClip((flags shr 8) and 0xF, listOf(rectPts(r[0], r[1], r[2], r[3]) to true)) }
                0x4033 -> { val pa = objs[flags and 0xFF] as? PPath; if (pa != null) combineClip((flags shr 8) and 0xF, pa.subs.map { it.pts to it.closed }) }
                0x400A -> {   // FillRects
                    val br = brushAt(s32(b, d), isColor); val n = s32(b, d + 4)
                    if (n in 1..100000) fillShapes((0 until n).map { k -> val r = rectAt(d + 8 + k * rectSize(comp), comp); rectPts(r[0], r[1], r[2], r[3]) to true }, br)
                }
                0x400B -> {   // DrawRects
                    val n = s32(b, d)
                    if (n in 1..100000) strokeShapes((0 until n).map { k -> val r = rectAt(d + 4 + k * rectSize(comp), comp); rectPts(r[0], r[1], r[2], r[3]) to true }, penOf(flags))
                }
                0x400C -> {   // FillPolygon
                    val br = brushAt(s32(b, d), isColor); val n = s32(b, d + 4)
                    if (n in 2..500000 && flags and 0x0800 == 0) fillShapes(listOf(points(d + 8, n, comp) to true), br)
                }
                0x400D -> {   // DrawLines
                    val n = s32(b, d)
                    if (n in 2..500000 && flags and 0x0800 == 0) strokeShapes(listOf(points(d + 4, n, comp) to (flags and 0x2000 != 0)), penOf(flags))
                }
                0x400E -> { val br = brushAt(s32(b, d), isColor); val r = rectAt(d + 4, comp); fillShapes(listOf(ellipsePts(r[0], r[1], r[2], r[3]) to true), br) }
                0x400F -> { val r = rectAt(d, comp); strokeShapes(listOf(ellipsePts(r[0], r[1], r[2], r[3]) to true), penOf(flags)) }
                0x4010 -> {
                    val br = brushAt(s32(b, d), isColor); val st0 = f(d + 4); val sw = f(d + 8); val r = rectAt(d + 12, comp)
                    fillShapes(listOf((doubleArrayOf((r[0] + r[2]) / 2, (r[1] + r[3]) / 2) + ellipsePts(r[0], r[1], r[2], r[3], -st0, -(st0 + sw), 40)) to true), br)
                }
                0x4011, 0x4012 -> {
                    val st0 = f(d); val sw = f(d + 4); val r = rectAt(d + 8, comp)
                    val arc = ellipsePts(r[0], r[1], r[2], r[3], -st0, -(st0 + sw), 40)
                    strokeShapes(listOf((if (type == 0x4011) doubleArrayOf((r[0] + r[2]) / 2, (r[1] + r[3]) / 2) + arc else arc) to (type == 0x4011)), penOf(flags))
                }
                0x4014 -> { val pa = objs[flags and 0xFF] as? PPath; val br = brushAt(s32(b, d), isColor); if (pa != null) fillShapes(pa.subs.map { it.pts to true }, br) }
                0x4015 -> { val pa = objs[flags and 0xFF] as? PPath; val pen = objs[s32(b, d) and 0xFF] as? PPen; if (pa != null) strokeShapes(pa.subs.map { it.pts to it.closed }, pen) }
                0x4016 -> { val br = brushAt(s32(b, d), isColor); val t = f(d + 4); val n = s32(b, d + 8); if (n in 3..100000) fillShapes(listOf(cardinal(points(d + 12, n, comp), t, true) to true), br) }
                0x4017 -> { val t = f(d); val n = s32(b, d + 4); if (n in 3..100000) strokeShapes(listOf(cardinal(points(d + 8, n, comp), t, true) to true), penOf(flags)) }
                0x4018 -> { val t = f(d); val n = s32(b, d + 12); if (n in 2..100000) strokeShapes(listOf(cardinal(points(d + 16, n, comp), t, false) to false), penOf(flags)) }
                0x4019 -> {
                    val n = s32(b, d)
                    if (n in 4..500000 && flags and 0x0800 == 0) {
                        val pt = points(d + 4, n, comp); val res = ArrayList<Double>(); res.add(pt[0]); res.add(pt[1])
                        var i = 0; while (i + 8 <= pt.size) { bezier(pt, i, res); i += 6 }
                        strokeShapes(listOf(res.toDoubleArray() to false), penOf(flags))
                    }
                }
                0x401A, 0x401B -> {
                    val img = objs[flags and 0xFF] as? PImage
                    if (img != null) {
                        val sr = DoubleArray(4) { f(d + 8 + 4 * it) }       // x, y, w, h (kaynak)
                        val dr: DoubleArray
                        if (type == 0x401A) { dr = rectAt(d + 24, comp) }
                        else {
                            val n = s32(b, d + 24); if (n != 3) return
                            val q = points(d + 28, 3, comp)
                            dr = doubleArrayOf(q[0], q[1], q[2] + q[4] - q[0], q[3] + q[5] - q[1])
                        }
                        val x0 = dx(dr[0], dr[1]); val y0 = dy(dr[0], dr[1]); val x1 = dx(dr[2], dr[3]); val y1 = dy(dr[2], dr[3])
                        o.ext(x0, y0); o.ext(x1, y1)
                        if (o.ops.size < MAX_OPS) {
                            if (img.argb != null) {
                                val sx = sr[0].toInt(); val sy = sr[1].toInt(); val sw = sr[2].toInt(); val sh = sr[3].toInt()
                                val c = crop(Dib(img.w, img.h, img.argb), sx, sy, sw, sh)
                                o.ops.add(Bmp(minOf(x0, x1), minOf(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0), c.w, c.h, c.argb))
                            } else if (img.data != null) o.ops.add(Img(minOf(x0, x1), minOf(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0), img.data))
                        }
                    }
                }
                0x401C -> {   // DrawString
                    val fnt = objs[flags and 0xFF] as? PFont; val br = brushAt(s32(b, d), isColor)
                    val n = s32(b, d + 8); val lx = f(d + 12); val ly = f(d + 16)
                    if (fnt != null && n in 1..100000 && d + 28 + 2 * n <= end) {
                        val s = String(b, d + 28, 2 * n, Charsets.UTF_16LE)
                        val col = br?.let { fillOf(it).first } ?: 0xFF000000.toInt()
                        val px = fnt.em * (if (fnt.unit == 0) scale() else unitScale(fnt.unit))
                        val x = dx(lx, ly); val y = dy(lx, ly)
                        o.ext(x, y)
                        o.ops.add(Text(x, y, s, col, maxOf(4.0, px), fnt.bold, fnt.italic, -Math.toDegrees(Math.atan2(world[1], world[0])), 0))
                    }
                }
            }
        }
        /** Parçalı nesnenin birleşmiş baytlarını [parseObject]'e uygun biçimde çözer. */
        fun sub(type: Int, data: ByteArray): Any? { val pb = Plus(o, data); pb.dpi = dpi; return pb.parseObject(type, 0, data.size) }
    }

    private fun finish(o: Out, l: Double, t: Double, r: Double, b: Double): Meta? {
        if (o.ops.none { it is Poly || it is Text || it is Bmp || it is Img }) return null
        val m = if (r > l && b > t && r - l < 1e7 && b - t < 1e7) Meta(l, t, r, b, o.ops)
        else if (o.maxX > o.minX || o.maxY > o.minY) Meta(o.minX, o.minY, maxOf(o.maxX, o.minX + 1), maxOf(o.maxY, o.minY + 1), o.ops)
        else null
        if (m == null) return null
        // Sınır kutusu çizgi kalınlığını içermez: kenarlarda kesilmesin diye küçük pay bırak
        val pad = maxOf(m.w, m.h) * 0.01 + o.ops.filterIsInstance<Poly>().maxOfOrNull { it.sw / 2 }.let { minOf(it ?: 0.0, maxOf(m.w, m.h) * 0.05) }
        return Meta(m.left - pad, m.top - pad, m.right + pad, m.bottom + pad, m.ops)
    }

    // ---------------- WMF ----------------
    private fun parseWmf(b: ByteArray): Meta? {
        var p = 0
        var bl = 0.0; var bt = 0.0; var br = 0.0; var bb = 0.0
        var placeable = false
        if (u32(b, 0) == 0x9AC6CDD7L) { bl = s16(b, 6).toDouble(); bt = s16(b, 8).toDouble(); br = s16(b, 10).toDouble(); bb = s16(b, 12).toDouble(); p = 22; placeable = true }
        if (p + 18 > b.size) return null
        p += u16(b, p + 2) * 2   // başlık boyutu (sözcük)
        val o = Out()
        val st = o.cur
        st.wex = 0.0; st.wey = 0.0   // pencere boyutu tanımlanana kadar kimlik
        st.mapMode = 8
        val objs = ArrayList<Any?>()
        fun add(x: Any) { val i = objs.indexOfFirst { it == null }; if (i >= 0) objs[i] = x else objs.add(x) }
        var wox = 0.0; var woy = 0.0; var wex = 0.0; var wey = 0.0
        fun sync() {
            // WMF: dev = (log - org) * |ext| / ext  (ters eksenlere izin verir)
            st.wox = wox; st.woy = woy
            st.wex = wex; st.wey = wey
            st.vox = 0.0; st.voy = 0.0
            st.vex = Math.abs(wex); st.vey = Math.abs(wey)
        }
        var guard = 0
        while (p + 6 <= b.size && guard++ < 2_000_000) {
            val words = u32(b, p).toInt(); val fn = u16(b, p + 4)
            if (words < 3 || p.toLong() + words.toLong() * 2 > b.size) break
            val d = p + 6
            val end = p + words * 2
            fun w(i: Int) = s16(b, d + 2 * i).toDouble()
            when (fn) {
                0x0000 -> break
                0x020B -> { woy = w(0); wox = w(1); sync() }
                0x020C -> { wey = w(0); wex = w(1); sync() }
                0x001E -> { o.stack.add(st.copy()); o.ops.add(Save) }
                0x0127 -> {
                    val n = w(0).toInt(); val k = if (n < 0) -n else if (n > 0 && n <= o.stack.size) o.stack.size - n + 1 else 0
                    if (k in 1..o.stack.size) { var x = st; repeat(k) { x = o.stack.removeAt(o.stack.size - 1); o.ops.add(Restore) }; st.set(x); wox = st.wox; woy = st.woy; wex = st.wex; wey = st.wey }
                }
                0x0416, 0x0415 -> { val l = w(3); val t = w(2); val r = w(1); val bt2 = w(0); o.clipRaw(listOf(doubleArrayOf(l, t, r, t, r, bt2, l, bt2) to true), fn == 0x0415) }
                0x0142 -> {
                    if (d + 4 + 40 <= end) { val dd = dib(b, d + 4, end - d - 4, 0, 0); if (dd != null) add(Brush(dd.argb[0], false, Tile(dd.w, dd.h, dd.argb))) else add(Brush(0xFF808080.toInt(), false)) }
                    else add(Brush(0xFF808080.toInt(), false))
                }
                0x0209 -> st.textColor = colorOf(u32(b, d).toInt())
                0x012E -> st.textAlign = u16(b, d)
                0x0214 -> { st.cx = w(1); st.cy = w(0) }
                0x0213 -> { val nx = w(1); val ny = w(0); o.poly(listOf(doubleArrayOf(st.cx, st.cy, nx, ny) to false), false, true); st.cx = nx; st.cy = ny }
                0x0324, 0x0325 -> {
                    val n = u16(b, d)
                    if (n in 1..60000 && d + 2 + 4 * n <= end) {
                        val pts = DoubleArray(2 * n) { k -> s16(b, d + 2 + 2 * k).toDouble() }
                        val closed = fn == 0x0324
                        o.poly(listOf(pts to closed), closed, true)
                    }
                }
                0x0538 -> {
                    val np = u16(b, d)
                    if (np in 1..20000) {
                        var q = d + 2 + 2 * np
                        val subs = ArrayList<Pair<DoubleArray, Boolean>>()
                        for (i in 0 until np) {
                            val c = u16(b, d + 2 + 2 * i)
                            if (q + 4 * c > end) break
                            subs.add(DoubleArray(2 * c) { k -> s16(b, q + 2 * k).toDouble() } to true)
                            q += 4 * c
                        }
                        o.poly(subs, true, true)
                    }
                }
                0x041B -> o.poly(listOf(doubleArrayOf(w(3), w(2), w(1), w(2), w(1), w(0), w(3), w(0)) to true), true, true)
                0x061C -> o.poly(listOf(roundRectPts(w(5), w(4), w(3), w(2), w(1), w(0)) to true), true, true)
                0x0418 -> o.poly(listOf(ellipsePts(w(3), w(2), w(1), w(0)) to true), true, true)
                0x02FA -> add(Pen(colorOf(u32(b, d + 6).toInt()), maxOf(1.0, w(1)), u16(b, d)))
                0x02FC -> { val sty = u16(b, d); val col = colorOf(u32(b, d + 2).toInt()); add(if (sty == 2) Brush(col, false, hatchTile(u16(b, d + 6), col, 0)) else Brush(col, sty == 1)) }
                0x02FB -> add(Font(w(0), u16(b, d + 8), u8(b, d + 10) != 0, w(2) / 10.0))
                0x012D -> { val ob = objs.getOrNull(u16(b, d)); when (ob) { is Pen -> st.pen = ob; is Brush -> st.brush = ob; is Font -> st.font = ob } }
                0x01F0 -> { val i = u16(b, d); if (i in objs.indices) objs[i] = null }
                0x0A32 -> {
                    val y = w(0); val x = w(1); val n = u16(b, d + 4); val opts = u16(b, d + 6)
                    val so = d + 8 + (if (opts and 6 != 0) 8 else 0)
                    if (n in 1..100000 && so + n <= end) emitWmfText(o, st, x, y, String(b, so, n, charset("windows-1254")))
                }
                0x0521 -> {
                    val n = u16(b, d)
                    val pad = n + (n and 1)
                    if (n in 1..100000 && d + 2 + pad + 4 <= end) emitWmfText(o, st, s16(b, d + 2 + pad + 2).toDouble(), s16(b, d + 2 + pad).toDouble(), String(b, d + 2, n, charset("windows-1254")))
                }
                0x0F43, 0x0B41, 0x0940, 0x0D33 -> {
                    val dibOff: Int; val xd: Double; val yd: Double; val cw: Double; val ch: Double; var sx = 0; var sy = 0; var sw = 0; var sh = 0
                    when (fn) {
                        0x0F43 -> { dibOff = d + 22; sh = w(3).toInt(); sw = w(4).toInt(); sy = w(5).toInt(); sx = w(6).toInt(); ch = w(7); cw = w(8); yd = w(9); xd = w(10) }
                        0x0B41 -> { dibOff = d + 20; sh = w(2).toInt(); sw = w(3).toInt(); sy = w(4).toInt(); sx = w(5).toInt(); ch = w(6); cw = w(7); yd = w(8); xd = w(9) }
                        0x0940 -> { dibOff = d + 16; sy = w(2).toInt(); sx = w(3).toInt(); ch = w(4); cw = w(5); yd = w(6); xd = w(7); sw = cw.toInt(); sh = ch.toInt() }
                        else -> { dibOff = d + 18; ch = w(5); cw = w(6); yd = w(7); xd = w(8); sh = ch.toInt(); sw = cw.toInt() }
                    }
                    if (dibOff + 40 <= end) {
                        val dd = dib(b, dibOff, end - dibOff, 0, 0)
                        if (dd != null && o.ops.size < MAX_OPS) {
                            val c = if (sw > 0 && sh > 0) crop(dd, sx, sy, sw, sh) else dd
                            val x0 = st.tx(xd, yd); val y0 = st.ty(xd, yd); val x1 = st.tx(xd + cw, yd + ch); val y1 = st.ty(xd + cw, yd + ch)
                            o.ext(x0, y0); o.ext(x1, y1)
                            o.ops.add(Bmp(minOf(x0, x1), minOf(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0), c.w, c.h, c.argb))
                        }
                    }
                }
            }
            p = end
        }
        if (placeable) return finish(o, 0.0, 0.0, if (wex != 0.0) Math.abs(wex) else Math.abs(br - bl), if (wey != 0.0) Math.abs(wey) else Math.abs(bb - bt))
        return if (wex != 0.0 && wey != 0.0) finish(o, 0.0, 0.0, Math.abs(wex), Math.abs(wey)) else finish(o, 0.0, 0.0, 0.0, 0.0)
    }

    private fun emitWmfText(o: Out, st: St, x: Double, y: Double, s: String) {
        val f = st.font
        val sizePx = if (f != null) Math.abs(f.height) * st.scaleY() * (if (f.height > 0) 0.8 else 1.0) else 12.0 * st.scaleY()
        val tx = st.tx(x, y); val ty = st.ty(x, y)
        o.ext(tx, ty)
        o.ops.add(Text(tx, ty, s, st.textColor, maxOf(4.0, sizePx), (f?.weight ?: 400) >= 600, f?.italic ?: false, f?.angle ?: 0.0, st.textAlign))
    }
}
