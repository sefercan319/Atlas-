package com.odak.app.logic

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * PIN özeti. Sürüm 1 (eski): SHA-256(tuz + pin), tek tur. Sürüm 2: PBKDF2-HMAC-SHA256, 120 000 tur.
 * Dört-sekiz haneli PIN'ler tek turlu özetle saniyeler içinde denenebildiği için yeni PIN'ler sürüm 2 ile saklanır;
 * eski PIN doğru girildiğinde sürüm 2'ye otomatik yükseltilir.
 */
object PinHash {
    const val VERSION = 2
    const val ITERATIONS = 120_000
    private const val KEY_BITS = 256

    fun newSalt(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    /** Eski, tek turlu özet (sürüm 1). Yalnızca eski kayıtları doğrulamak için tutulur. */
    fun legacy(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    /** Sürüm 2 özeti: PBKDF2-HMAC-SHA256. */
    fun pbkdf2(pin: String, salt: String): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt.toByteArray(Charsets.UTF_8), ITERATIONS, KEY_BITS)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return key.joinToString("") { "%02x".format(it) }
    }

    /** Sürüm bilgisi yoksa eski kayıttır (1). */
    fun verify(pin: String, salt: String, stored: String, version: Int): Boolean = when {
        version >= VERSION -> pbkdf2(pin, salt) == stored
        else -> legacy(pin, salt) == stored
    }

    /** Eski sürümle doğru girildiyse yeniden özetlemek gerekir. */
    fun needsUpgrade(version: Int): Boolean = version < VERSION
}
