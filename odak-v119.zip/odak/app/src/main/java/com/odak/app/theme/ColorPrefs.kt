package com.odak.app.theme

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.graphics.Color

/** Tasarım başına kullanıcı renkleri (yuva başına). Durum tabanlı: değişince arayüz kendini yeniler. */
object ColorPrefs {
    private const val PREFS = "odak_colors"
    private val values = mutableStateMapOf<String, Int>()

    fun init(c: Context) {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        for (s in DesignStyle.entries) for (slot in ColorSlot.entries) {
            val k = ColorSlot.prefKey(s.key, slot)
            if (p.contains(k)) values[k] = p.getInt(k, 0)
        }
    }

    fun get(s: DesignStyle, slot: ColorSlot): Color? = values[ColorSlot.prefKey(s.key, slot)]?.let { Color(it) }

    fun set(c: Context, s: DesignStyle, slot: ColorSlot, argb: Int) {
        val k = ColorSlot.prefKey(s.key, slot)
        values[k] = argb
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(k, argb).apply()
    }

    /** Tek yuvayı varsayılana döndürür; diğer renklere dokunmaz. */
    fun clear(c: Context, s: DesignStyle, slot: ColorSlot) {
        val k = ColorSlot.prefKey(s.key, slot)
        values.remove(k)
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(k).apply()
    }

    fun primaryOf(s: DesignStyle): Color? = get(s, ColorSlot.PRIMARY)
    fun accentOf(s: DesignStyle): Color? = get(s, ColorSlot.ACCENT)
    fun backgroundOf(s: DesignStyle): Color? = get(s, ColorSlot.BACKGROUND)
    fun textOf(s: DesignStyle): Color? = get(s, ColorSlot.TEXT)
    fun surfaceOf(s: DesignStyle): Color? = get(s, ColorSlot.SURFACE)
    fun buttonOf(s: DesignStyle): Color? = get(s, ColorSlot.BUTTON)
    fun buttonTextOf(s: DesignStyle): Color? = get(s, ColorSlot.BUTTON_TEXT)

    fun setPrimary(c: Context, s: DesignStyle, argb: Int) = set(c, s, ColorSlot.PRIMARY, argb)
    fun setAccent(c: Context, s: DesignStyle, argb: Int) = set(c, s, ColorSlot.ACCENT, argb)
    fun setBackground(c: Context, s: DesignStyle, argb: Int) = set(c, s, ColorSlot.BACKGROUND, argb)
    fun setText(c: Context, s: DesignStyle, argb: Int) = set(c, s, ColorSlot.TEXT, argb)
}
