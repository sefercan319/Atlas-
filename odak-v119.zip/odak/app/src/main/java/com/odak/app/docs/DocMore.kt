package com.odak.app.docs

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/**
 * Altı ek belge türü (saf Kotlin, Android'siz): e-posta (EML), web arşivi (MHTML), FictionBook e-kitap (FB2),
 * Jupyter not defteri (IPYNB), ZIP/CBZ/JAR arşiv dökümü ve biçimli JSON.
 */
object DocMore {
    private const val MAX_PARAS = 20000
    private const val MAX_PARTS = 200
    private const val MAX_DEPTH = 8
    private const val MAX_ARCHIVE_ENTRIES = 20000
    private const val PRETTY_JSON_MAX = 8 * 1024 * 1024

    // =====================================================================
    // Küçük JSON okuyucu / biçimlendirici
    // =====================================================================
    /** Sayıyı özgün yazımıyla tutar (1.0 → "1.0" kalır, hassasiyet bozulmaz). */
    class JNum(val raw: String)

    object Json {
        private const val MAX_DEPTH_JSON = 200

        /** Ayrıştırır: Map (sıralı), List, String, JNum, Boolean, null. Bozuk girdide IllegalArgumentException. */
        fun parse(s: String): Any? {
            val p = P(s)
            p.ws()
            val v = p.value(0)
            p.ws()
            if (p.i != s.length) throw IllegalArgumentException("fazla veri")
            return v
        }

        private class P(val s: String) {
            var i = 0
            fun ws() { while (i < s.length && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t' || s[i] == '\uFEFF')) i++ }
            fun fail(): Nothing = throw IllegalArgumentException("json@$i")

            fun value(d: Int): Any? {
                if (d > MAX_DEPTH_JSON) fail()
                if (i >= s.length) fail()
                return when (val c = s[i]) {
                    '{' -> obj(d)
                    '[' -> arr(d)
                    '"' -> str()
                    't' -> lit("true", true)
                    'f' -> lit("false", false)
                    'n' -> lit("null", null)
                    else -> if (c == '-' || c.isDigit()) num() else fail()
                }
            }

            fun lit(w: String, v: Any?): Any? { if (!s.startsWith(w, i)) fail(); i += w.length; return v }

            fun num(): JNum {
                val st = i
                if (s[i] == '-') i++
                while (i < s.length && (s[i].isDigit() || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' || s[i] == '-')) i++
                if (i == st || (i == st + 1 && s[st] == '-')) fail()
                return JNum(s.substring(st, i))
            }

            fun str(): String {
                i++ // "
                val sb = StringBuilder()
                while (true) {
                    if (i >= s.length) fail()
                    val c = s[i++]
                    when {
                        c == '"' -> return sb.toString()
                        c == '\\' -> {
                            if (i >= s.length) fail()
                            when (val e = s[i++]) {
                                'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r')
                                'b' -> sb.append('\b'); 'f' -> sb.append('\u000C')
                                '/' -> sb.append('/'); '\\' -> sb.append('\\'); '"' -> sb.append('"')
                                'u' -> {
                                    if (i + 4 > s.length) fail()
                                    val h = s.substring(i, i + 4).toIntOrNull(16) ?: fail()
                                    sb.append(h.toChar()); i += 4
                                }
                                else -> { sb.append(e) }
                            }
                        }
                        else -> sb.append(c)
                    }
                }
            }

            fun arr(d: Int): List<Any?> {
                i++
                val out = ArrayList<Any?>()
                ws()
                if (i < s.length && s[i] == ']') { i++; return out }
                while (true) {
                    ws(); out.add(value(d + 1)); ws()
                    if (i >= s.length) fail()
                    if (s[i] == ',') { i++; continue }
                    if (s[i] == ']') { i++; return out }
                    fail()
                }
            }

            fun obj(d: Int): Map<String, Any?> {
                i++
                val out = LinkedHashMap<String, Any?>()
                ws()
                if (i < s.length && s[i] == '}') { i++; return out }
                while (true) {
                    ws()
                    if (i >= s.length || s[i] != '"') fail()
                    val k = str(); ws()
                    if (i >= s.length || s[i] != ':') fail()
                    i++; ws()
                    out[k] = value(d + 1); ws()
                    if (i >= s.length) fail()
                    if (s[i] == ',') { i++; continue }
                    if (s[i] == '}') { i++; return out }
                    fail()
                }
            }
        }

        fun quote(s: String): String {
            val sb = StringBuilder(s.length + 2)
            sb.append('"')
            for (c in s) when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c.code < 0x20 -> sb.append("\\u").append(String.format("%04x", c.code))
                else -> sb.append(c)
            }
            return sb.append('"').toString()
        }

        /** Girintili (2 boşluk) çıktı; satır listesi döner. */
        fun pretty(v: Any?): List<String> {
            val out = ArrayList<String>()
            fun scalar(x: Any?): String = when (x) {
                null -> "null"; is String -> quote(x); is JNum -> x.raw; else -> x.toString()
            }
            fun emit(x: Any?, ind: String, prefix: String, comma: String) {
                if (out.size >= MAX_PARAS) return
                when (x) {
                    is Map<*, *> -> if (x.isEmpty()) out.add("$ind$prefix{}$comma") else {
                        out.add("$ind$prefix{")
                        val es = x.entries.toList()
                        es.forEachIndexed { n, e -> emit(e.value, "$ind  ", quote(e.key.toString()) + ": ", if (n < es.size - 1) "," else "") }
                        out.add("$ind}$comma")
                    }
                    is List<*> -> if (x.isEmpty()) out.add("$ind$prefix[]$comma") else {
                        out.add("$ind$prefix[")
                        x.forEachIndexed { n, e -> emit(e, "$ind  ", "", if (n < x.size - 1) "," else "") }
                        out.add("$ind]$comma")
                    }
                    else -> out.add("$ind$prefix${scalar(x)}$comma")
                }
            }
            emit(v, "", "", "")
            return out
        }
    }

    /** JSON dosyası: geçerliyse girintili gösterim, değilse (veya çok büyükse) olduğu gibi satırlar. */
    fun jsonDoc(text: String): Doc {
        val raw = DocParse.textParas(text)
        if (text.length > PRETTY_JSON_MAX) return Doc(DocKind.JSON, listOf(DocPage("", raw)), approx = true)
        return try {
            Doc(DocKind.JSON, listOf(DocPage("", Json.pretty(Json.parse(text)))))
        } catch (e: Exception) {
            Doc(DocKind.JSON, listOf(DocPage("", raw)), approx = true)
        }
    }

    // =====================================================================
    // MIME (EML / MHTML)
    // =====================================================================
    class Mime(val headers: Map<String, String>, val body: ByteArray)

    private fun indexOfBlank(b: ByteArray): Pair<Int, Int> { // (başlık sonu, gövde başı)
        var i = 0
        while (i < b.size) {
            if (b[i] == '\n'.code.toByte()) {
                if (i + 1 < b.size && b[i + 1] == '\n'.code.toByte()) return i to i + 2
                if (i + 2 < b.size && b[i + 1] == '\r'.code.toByte() && b[i + 2] == '\n'.code.toByte()) return i to i + 3
            }
            i++
        }
        return b.size to b.size
    }

    /** Başlık baytları geçerli UTF-8 ise öyle (SMTPUTF8), değilse Latin-1 okunur. */
    private fun headText(b: ByteArray, n: Int): String = try {
        Charsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(b, 0, n)).toString()
    } catch (e: java.nio.charset.CharacterCodingException) { String(b, 0, n, Charsets.ISO_8859_1) }

    fun parseMime(b: ByteArray): Mime {
        val (he, bs) = indexOfBlank(b)
        val head = headText(b, he).replace("\r\n", "\n").replace('\r', '\n')
        val headers = LinkedHashMap<String, String>()
        var key: String? = null
        for (ln in head.split('\n')) {
            if (ln.isEmpty()) continue
            if ((ln[0] == ' ' || ln[0] == '\t') && key != null) { headers[key] = headers[key] + " " + ln.trim(); continue }
            val c = ln.indexOf(':')
            if (c <= 0) continue
            key = ln.substring(0, c).trim().lowercase()
            if (!headers.containsKey(key)) headers[key] = ln.substring(c + 1).trim() else key = key + "#"
        }
        return Mime(headers, b.copyOfRange(bs.coerceAtMost(b.size), b.size))
    }

    /** Başlık parametresi: Content-Type: text/plain; charset="utf-8" → param("charset"). */
    fun param(v: String?, name: String): String? {
        if (v == null) return null
        val m = Regex("(?i)(?:^|;)\\s*" + Regex.escape(name) + "\\s*=\\s*(\"([^\"]*)\"|[^;\\s]*)").find(v) ?: return null
        return (m.groupValues[2].ifEmpty { m.groupValues[1].trim('"') }).ifEmpty { null }
    }

    private fun mediaType(v: String?): String = (v ?: "text/plain").substringBefore(';').trim().lowercase()

    private fun charsetOf(name: String?): java.nio.charset.Charset =
        try { if (name == null) Charsets.UTF_8 else java.nio.charset.Charset.forName(name.trim()) } catch (e: Exception) { Charsets.UTF_8 }

    fun qpDecode(s: String, soft: Boolean = true): ByteArray {
        val out = java.io.ByteArrayOutputStream(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '=' && soft && i + 1 < s.length && (s[i + 1] == '\n' || s[i + 1] == '\r')) {
                i += if (s[i + 1] == '\r' && i + 2 < s.length && s[i + 2] == '\n') 3 else 2
                continue
            }
            if (c == '=' && i + 2 < s.length) {
                val h = s.substring(i + 1, i + 3).toIntOrNull(16)
                if (h != null) { out.write(h); i += 3; continue }
            }
            out.write(c.code and 0xFF)
            i++
        }
        return out.toByteArray()
    }

    private fun transferDecode(body: ByteArray, enc: String?): ByteArray = when ((enc ?: "").trim().lowercase()) {
        "base64" -> try {
            java.util.Base64.getMimeDecoder().decode(String(body, Charsets.ISO_8859_1))
        } catch (e: Exception) { body }
        "quoted-printable" -> qpDecode(String(body, Charsets.ISO_8859_1))
        else -> body
    }

    /** RFC 2047: =?utf-8?B?...?= ve =?iso-8859-9?Q?...?= üstbilgi kelimeleri. */
    fun decodeWords(s: String): String {
        val re = Regex("=\\?([^?\\s]+)\\?([bBqQ])\\?([^?]*)\\?=")
        // Yan yana kodlu kelimeler arasındaki boşluk atılır.
        val joined = s.replace(Regex("(\\?=)\\s+(?==\\?)"), "$1")
        return re.replace(joined) { m ->
            val cs = charsetOf(m.groupValues[1])
            val data = m.groupValues[3]
            try {
                if (m.groupValues[2].equals("b", true)) String(java.util.Base64.getMimeDecoder().decode(data), cs)
                else String(qpDecode(data.replace('_', ' '), soft = false), cs)
            } catch (e: Exception) { m.value }
        }
    }

    private class Collected {
        val plain = ArrayList<String>()
        val html = ArrayList<String>()
        val attachments = ArrayList<String>()
    }

    private fun collect(m: Mime, depth: Int, out: Collected, count: IntArray) {
        if (depth > MAX_DEPTH || ++count[0] > MAX_PARTS) return
        val ct = m.headers["content-type"]
        val type = mediaType(ct)
        val disp = m.headers["content-disposition"] ?: ""
        val fname = param(disp, "filename") ?: param(ct, "name")
        if (type.startsWith("multipart/")) {
            val bd = param(ct, "boundary") ?: return
            val parts = splitMultipart(m.body, bd)
            if (type == "multipart/alternative") {
                // En zengin olanı değil, sırayla hepsini topla; aşağıda düz metin varsa o seçilir.
                for (p in parts) collect(parseMime(p), depth + 1, out, count)
            } else for (p in parts) collect(parseMime(p), depth + 1, out, count)
            return
        }
        if (type == "message/rfc822") { collect(parseMime(m.body), depth + 1, out, count); return }
        if (disp.trim().lowercase().startsWith("attachment") || (fname != null && !type.startsWith("text/"))) {
            if (fname != null) out.attachments.add(decodeWords(fname))
            return
        }
        val data = transferDecode(m.body, m.headers["content-transfer-encoding"])
        val text = String(data, charsetOf(param(ct, "charset")))
        when (type) {
            "text/plain" -> out.plain.add(text)
            "text/html" -> out.html.add(text)
            else -> if (fname != null) out.attachments.add(decodeWords(fname))
        }
    }

    fun splitMultipart(body: ByteArray, boundary: String): List<ByteArray> {
        val s = String(body, Charsets.ISO_8859_1)
        val delim = "--$boundary"
        val parts = ArrayList<ByteArray>()
        var pos = s.indexOf(delim)
        while (pos >= 0 && parts.size < MAX_PARTS) {
            val after = pos + delim.length
            if (s.startsWith("--", after)) break
            val lineEnd = s.indexOf('\n', after).let { if (it < 0) s.length else it + 1 }
            val next = s.indexOf("\n$delim", lineEnd - 1)
            val end = if (next < 0) s.length else next
            var e = end
            if (e > lineEnd && s[e - 1] == '\r') e--
            if (lineEnd <= e) parts.add(s.substring(lineEnd, e).toByteArray(Charsets.ISO_8859_1))
            if (next < 0) break
            pos = next + 1
        }
        return parts
    }

    private fun bodyParas(c: Collected): List<String> {
        val paras = ArrayList<String>()
        if (c.plain.isNotEmpty()) c.plain.forEach { paras.addAll(DocParse.textParas(it)) }
        else c.html.forEach { paras.addAll(DocParse.htmlParas(it)) }
        return paras
    }

    private val HEADER_LABELS = listOf("subject" to "Subject", "from" to "From", "to" to "To", "cc" to "Cc", "date" to "Date")

    fun emlDoc(bytes: ByteArray): Doc {
        val m = parseMime(bytes)
        val c = Collected()
        collect(m, 0, c, intArrayOf(0))
        val paras = ArrayList<String>()
        for ((k, label) in HEADER_LABELS) m.headers[k]?.let { if (it.isNotBlank()) paras.add("$label: ${decodeWords(it)}") }
        if (paras.isNotEmpty()) paras.add("")
        paras.addAll(bodyParas(c))
        if (c.attachments.isNotEmpty()) { paras.add(""); c.attachments.forEach { paras.add("📎 $it") } }
        return Doc(DocKind.EML, if (paras.isEmpty()) emptyList() else listOf(DocPage("", paras.take(MAX_PARAS))))
    }

    fun mhtmlDoc(bytes: ByteArray): Doc {
        val m = parseMime(bytes)
        val c = Collected()
        collect(m, 0, c, intArrayOf(0))
        val paras = ArrayList<String>()
        m.headers["subject"]?.let { if (it.isNotBlank()) { paras.add(decodeWords(it)); paras.add("") } }
        // Web arşivinde önce HTML okunur (düz metin kısmı çoğu zaman yoktur).
        val src = if (c.html.isNotEmpty()) c.html.first() else c.plain.joinToString("\n")
        paras.addAll(if (c.html.isNotEmpty()) DocParse.htmlParas(src) else DocParse.textParas(src))
        return Doc(DocKind.MHTML, if (paras.all { it.isBlank() }) emptyList() else listOf(DocPage("", paras.take(MAX_PARAS))))
    }

    // =====================================================================
    // FB2 (FictionBook)
    // =====================================================================
    private fun fb2Text(bytes: ByteArray): String {
        val head = String(bytes, 0, minOf(bytes.size, 300), Charsets.ISO_8859_1)
        val enc = Regex("encoding=[\"']([^\"']+)[\"']").find(head)?.groupValues?.get(1)
        return String(bytes, charsetOf(enc))
    }

    fun fb2Doc(bytes: ByteArray): Doc {
        var x = fb2Text(bytes)
        val bins = HashMap<String, ByteArray>()
        for (m in Regex("(?s)<binary\\b([^>]*)>(.*?)</binary>").findAll(x)) {
            val id = HtmlRich.attrs(m.groupValues[1])["id"] ?: continue
            if (bins.size < 80 && m.groupValues[2].length < 5_000_000) try { bins[id] = java.util.Base64.getMimeDecoder().decode(m.groupValues[2].trim()) } catch (e: Exception) {}
        }
        x = x.replace(Regex("(?s)<binary\\b.*?</binary>"), "")
        val desc = Regex("(?s)<description>(.*?)</description>").find(x)?.groupValues?.get(1) ?: ""
        val bookTitle = Regex("(?s)<book-title>(.*?)</book-title>").find(desc)?.groupValues?.get(1)?.let { DocParse.htmlDecode(it.replace(Regex("<[^>]+>"), "")).trim() } ?: ""
        val authors = Regex("(?s)<author>(.*?)</author>").findAll(desc).map { a ->
            listOf("first-name", "middle-name", "last-name").mapNotNull { t ->
                Regex("(?s)<$t>(.*?)</$t>").find(a.groupValues[1])?.groupValues?.get(1)?.trim()?.ifEmpty { null }
            }.joinToString(" ")
        }.filter { it.isNotBlank() }.toList()
        val bodyStart = x.indexOf("<body")
        val body = if (bodyStart >= 0) x.substring(bodyStart) else ""
        val pages = ArrayList<DocPage>()
        if (bookTitle.isNotEmpty() || authors.isNotEmpty()) {
            pages.add(DocPage("", listOfNotNull(bookTitle.ifEmpty { null }, authors.joinToString(", ").ifEmpty { null })))
        }
        var title = ""
        var paras = ArrayList<String>()
        var inTitle = false
        val titleParts = ArrayList<String>()
        var inP = false
        val buf = StringBuilder()
        var sliceStart = bodyStart.coerceAtLeast(0).let { 0 }
        fun richOf(from: Int, to: Int): RichPage? = try {
            val html = fb2Html(body.substring(from.coerceIn(0, body.length), to.coerceIn(0, body.length)))
            HtmlRich.page(HtmlRich.parse(html, { src -> bins[src.removePrefix("#")]?.let { HtmlRich.image(it, src) } })).takeIf { it.blocks.isNotEmpty() }
        } catch (e: Exception) { null }
        fun flush(end: Int = body.length) {
            if (paras.isNotEmpty() || title.isNotEmpty()) pages.add(DocPage(title, paras, null, null, richOf(sliceStart, end)))
            paras = ArrayList(); title = ""
        }
        val tag = Regex("<(/?)([A-Za-z][\\w:-]*)([^>]*?)(/?)>")
        var pos = 0
        for (m in tag.findAll(body)) {
            if (inP && m.range.first > pos) buf.append(body, pos, m.range.first)
            pos = m.range.last + 1
            val close = m.groupValues[1] == "/"
            val name = m.groupValues[2].lowercase()
            val selfClose = m.groupValues[4] == "/"
            when (name) {
                "section" -> if (!close) { flush(m.range.first); sliceStart = m.range.first; inTitle = false }
                "title" -> if (!close) { inTitle = true; titleParts.clear() } else { inTitle = false; if (title.isEmpty()) title = titleParts.joinToString(" ").trim() }
                "p", "v", "subtitle", "text-author" -> if (!close && !selfClose) { inP = true; buf.setLength(0) } else if (close && inP) {
                    inP = false
                    val t = DocParse.htmlDecode(buf.toString().replace(Regex("\\s+"), " ")).trim()
                    if (t.isNotEmpty()) { if (inTitle) titleParts.add(t) else if (paras.size < MAX_PARAS) paras.add(t) }
                }
                "empty-line" -> if (!inTitle) paras.add("")
            }
        }
        flush()
        return Doc(DocKind.FB2, pages.take(2000))
    }

    /** FB2 işaretlemesini HtmlRich'in anladığı HTML'e çevirir. */
    private fun fb2Html(s: String): String = s
        .replace(Regex("<(/?)title\\b"), "<$1h2")
        .replace(Regex("<(/?)subtitle\\b"), "<$1h4")
        .replace(Regex("<(/?)emphasis\\b"), "<$1i")
        .replace(Regex("<(/?)strikethrough\\b"), "<$1s")
        .replace(Regex("<(/?)(v|text-author)\\b"), "<$1p")
        .replace(Regex("<empty-line\\s*/?>"), "<br/>")

    // =====================================================================
    // IPYNB (Jupyter)
    // =====================================================================
    private fun src(v: Any?): String = when (v) {
        is String -> v
        is List<*> -> v.joinToString("") { it?.toString() ?: "" }
        else -> ""
    }

    fun ipynbDoc(text: String): Doc {
        val root = try { Json.parse(text) } catch (e: Exception) { null }
        val cells = ((root as? Map<*, *>)?.get("cells") as? List<*>) ?: return Doc(DocKind.IPYNB, emptyList())
        val paras = ArrayList<String>()
        var n = 0
        for (c in cells) {
            if (paras.size >= MAX_PARAS) break
            val cell = c as? Map<*, *> ?: continue
            val type = cell["cell_type"]?.toString() ?: ""
            val s = src(cell["source"])
            if (type == "code") {
                n++
                paras.add("In [${(cell["execution_count"] as? JNum)?.raw ?: n}]:")
                s.replace("\r\n", "\n").split('\n').forEach { paras.add("    $it") }
                for (o in (cell["outputs"] as? List<*>) ?: emptyList<Any?>()) {
                    val od = o as? Map<*, *> ?: continue
                    val t = when {
                        od["text"] != null -> src(od["text"])
                        (od["data"] as? Map<*, *>)?.get("text/plain") != null -> src((od["data"] as Map<*, *>)["text/plain"])
                        od["traceback"] != null -> src(od["traceback"]).replace(Regex("\u001B\\[[0-9;]*m"), "")
                        else -> ""
                    }
                    if (t.isNotBlank()) t.trimEnd('\n').replace("\r\n", "\n").split('\n').forEach { paras.add("  ⇒ $it") }
                }
                paras.add("")
            } else if (type == "markdown" || type == "raw") {
                s.replace("\r\n", "\n").split('\n').forEach { paras.add(it) }
                paras.add("")
            }
        }
        return Doc(DocKind.IPYNB, if (paras.isEmpty()) emptyList() else listOf(DocPage("", paras.take(MAX_PARAS))))
    }

    // =====================================================================
    // Arşiv dökümü (ZIP / CBZ / JAR)
    // =====================================================================
    fun humanSize(n: Long): String = when {
        n < 0 -> "?"
        n < 1024 -> "$n B"
        n < 1024 * 1024 -> String.format(java.util.Locale.ROOT, "%.1f KB", n / 1024.0)
        n < 1024L * 1024 * 1024 -> String.format(java.util.Locale.ROOT, "%.1f MB", n / 1048576.0)
        else -> String.format(java.util.Locale.ROOT, "%.2f GB", n / 1073741824.0)
    }

    private fun archiveDoc(entries: List<Pair<String, Long>>, truncated: Boolean): Doc {
        val files = entries.filter { !it.first.endsWith("/") }
        val total = files.sumOf { it.second.coerceAtLeast(0) }
        val rows = ArrayList<List<String>>()
        rows.add(listOf("Name", "Size"))
        entries.forEach { rows.add(listOf(it.first, if (it.first.endsWith("/")) "" else humanSize(it.second))) }
        val head = "${files.size} files, ${humanSize(total)}" + if (truncated) " (+)" else ""
        return Doc(DocKind.ARCHIVE, listOf(DocPage("", listOf(head), rows)), approx = truncated)
    }

    /** Bellekteki zip: ZipInputStream; boyutu bilinmeyen girdiler (-1) okunarak sayılır (üst sınırlı). */
    fun archiveFromBytes(bytes: ByteArray): Doc {
        val list = ArrayList<Pair<String, Long>>()
        var truncated = false
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            val buf = ByteArray(16 * 1024)
            var budget = 512L * 1024 * 1024
            while (true) {
                val e = z.nextEntry ?: break
                if (list.size >= MAX_ARCHIVE_ENTRIES) { truncated = true; break }
                var size = e.size
                if (size < 0 && !e.isDirectory) {
                    var t = 0L
                    while (budget > 0) { val r = z.read(buf); if (r < 0) break; t += r; budget -= r }
                    size = t
                }
                list.add(e.name to size)
            }
        }
        return archiveDoc(list, truncated)
    }

    /** Diskteki zip: merkezi dizinden (ZIP64 dahil) adlar ve boyutlar; içerik okunmaz. */
    fun archiveFromFile(f: java.io.File): Doc {
        val list = ArrayList<Pair<String, Long>>()
        var truncated = false
        java.util.zip.ZipFile(f).use { z ->
            val en = z.entries()
            while (en.hasMoreElements()) {
                if (list.size >= MAX_ARCHIVE_ENTRIES) { truncated = true; break }
                val e = en.nextElement()
                list.add(e.name to e.size)
            }
        }
        return archiveDoc(list, truncated)
    }
}
