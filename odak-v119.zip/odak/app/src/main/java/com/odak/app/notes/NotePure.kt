package com.odak.app.notes

import java.util.Locale
import java.util.UUID
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Nokta: x sayfa genişliğine oranlanmış (0..1), y de aynı ölçekte (ekran boyutundan bağımsız). p: kalem basıncı 0..1 (kalem yoksa 1). */
data class Pt(val x: Float, val y: Float, val p: Float = 1f)

/** Sayfaya yerleştirilmiş resim: dosya adı (notes/img altında), konum ve genişlik sayfa genişliğine oranlı, a = yükseklik/genişlik. */
data class NoteImg(val file: String, val x: Float, val y: Float, val w: Float, val a: Float)

/** Ses kaydı: dosya adı (notes/audio altında), süre ms, kayıt zamanı. */
data class NoteAudio(val file: String, val durMs: Long, val at: Long)

/** tool: 0 kalem, 1 fosforlu, 2 kurşun kalem. color: ARGB. width: sayfa genişliğinin binde biri. */
data class Stroke(val tool: Int, val color: Int, val width: Float, val pts: List<Pt>)

/** paper: 0 düz, 1 çizgili, 2 kareli, 3 noktalı. */
data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val body: String = "",
    val strokes: List<Stroke> = emptyList(),
    val paper: Int = 0,
    val color: Int = 0,
    val pinned: Boolean = false,
    val folder: String = "",
    val created: Long = 0L,
    val updated: Long = 0L,
    val trashedAt: Long = 0L,
    val locked: Boolean = false,
    /** PDF üstüne yazma notu: notes/pdf altındaki dosya adı; boşsa normal not. */
    val pdf: String = "",
    val images: List<NoteImg> = emptyList(),
    val audios: List<NoteAudio> = emptyList()
)

object NotePure {
    const val TOOL_PEN = 0
    const val TOOL_HIGHLIGHT = 1
    const val TOOL_PENCIL = 2
    const val MAX_STROKES = 5000
    const val MAX_PTS = 20000
    const val TRASH_DAYS = 30
    const val PAPERS = 4
    const val MAGIC = "ODN1"
    const val MAX_MEDIA = 60

    // ---------- Kodlama ----------
    fun esc(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (ch in s) when (ch) {
            '\\' -> sb.append("\\\\")
            '\n' -> sb.append("\\n")
            '\r' -> {}
            else -> sb.append(ch)
        }
        return sb.toString()
    }

    fun unesc(s: String): String {
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) { 'n' -> sb.append('\n'); '\\' -> sb.append('\\'); else -> { sb.append(c); sb.append(s[i + 1]) } }
                i += 2
            } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    private fun f(v: Float): String = String.format(Locale.ROOT, "%.4f", v).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    fun encode(n: Note): String {
        val sb = StringBuilder()
        sb.append(MAGIC).append('\n')
        sb.append("id=").append(n.id).append('\n')
        sb.append("title=").append(esc(n.title)).append('\n')
        sb.append("paper=").append(n.paper).append('\n')
        sb.append("color=").append(n.color).append('\n')
        sb.append("pinned=").append(if (n.pinned) 1 else 0).append('\n')
        sb.append("folder=").append(esc(n.folder)).append('\n')
        sb.append("created=").append(n.created).append('\n')
        sb.append("updated=").append(n.updated).append('\n')
        sb.append("trashed=").append(n.trashedAt).append('\n')
        sb.append("locked=").append(if (n.locked) 1 else 0).append('\n')
        sb.append("body=").append(esc(n.body)).append('\n')
        if (safeFile(n.pdf)) sb.append("pdf=").append(n.pdf).append('\n')
        for (i in n.images.take(MAX_MEDIA)) if (safeFile(i.file)) sb.append("I ").append(i.file).append(' ').append(f(i.x)).append(' ').append(f(i.y)).append(' ').append(f(i.w)).append(' ').append(f(i.a)).append('\n')
        for (a in n.audios.take(MAX_MEDIA)) if (safeFile(a.file)) sb.append("A ").append(a.file).append(' ').append(a.durMs).append(' ').append(a.at).append('\n')
        for (s in n.strokes.take(MAX_STROKES)) {
            sb.append("S ").append(s.tool).append(' ').append(s.color).append(' ').append(f(s.width))
            for (p in s.pts.take(MAX_PTS)) {
                sb.append(' ').append(f(p.x)).append(',').append(f(p.y))
                if (p.p < 0.999f) sb.append(',').append(f(p.p))
            }
            sb.append('\n')
        }
        return sb.toString()
    }

    fun decode(text: String): Note? {
        val lines = text.split('\n')
        if (lines.isEmpty() || lines[0].trim() != MAGIC) return null
        var n = Note()
        val strokes = ArrayList<Stroke>()
        val imgs = ArrayList<NoteImg>()
        val auds = ArrayList<NoteAudio>()
        for (i in 1 until lines.size) {
            val ln = lines[i]
            if (ln.isEmpty()) continue
            if (ln.startsWith("S ")) {
                if (strokes.size >= MAX_STROKES) continue
                val parts = ln.split(' ')
                if (parts.size < 4) continue
                val tool = parts[1].toIntOrNull() ?: continue
                val color = parts[2].toIntOrNull() ?: continue
                val w = parts[3].toFloatOrNull() ?: continue
                val pts = ArrayList<Pt>()
                for (j in 4 until min(parts.size, MAX_PTS + 4)) {
                    val xy = parts[j].split(',')
                    if (xy.size != 2 && xy.size != 3) continue
                    val x = xy[0].toFloatOrNull() ?: continue
                    val y = xy[1].toFloatOrNull() ?: continue
                    val pr = if (xy.size == 3) (xy[2].toFloatOrNull() ?: continue) else 1f
                    if (x.isNaN() || y.isNaN() || x.isInfinite() || y.isInfinite() || pr.isNaN()) continue
                    pts.add(Pt(x, y, pr.coerceIn(0f, 1f)))
                }
                if (pts.isNotEmpty()) strokes.add(Stroke(tool.coerceIn(0, 2), color, w.coerceIn(0.1f, 100f), pts))
                continue
            }
            if (ln.startsWith("I ")) {
                val q = ln.split(' ')
                if (q.size == 6 && imgs.size < MAX_MEDIA && safeFile(q[1])) {
                    val x = q[2].toFloatOrNull(); val y = q[3].toFloatOrNull(); val w = q[4].toFloatOrNull(); val a = q[5].toFloatOrNull()
                    if (x != null && y != null && w != null && a != null && listOf(x, y, w, a).none { it.isNaN() || it.isInfinite() })
                        imgs.add(NoteImg(q[1], x.coerceIn(0f, 1f), y.coerceIn(0f, 50f), w.coerceIn(0.05f, 1f), a.coerceIn(0.05f, 20f)))
                }
                continue
            }
            if (ln.startsWith("A ")) {
                val q = ln.split(' ')
                if (q.size == 4 && auds.size < MAX_MEDIA && safeFile(q[1])) {
                    val d = q[2].toLongOrNull(); val at = q[3].toLongOrNull()
                    if (d != null && at != null) auds.add(NoteAudio(q[1], d.coerceAtLeast(0L), at))
                }
                continue
            }
            val eq = ln.indexOf('=')
            if (eq <= 0) continue
            val k = ln.substring(0, eq)
            val v = ln.substring(eq + 1)
            n = when (k) {
                "id" -> if (v.isNotBlank() && v.length <= 80 && v.all { it.isLetterOrDigit() || it == '-' || it == '_' }) n.copy(id = v) else n
                "title" -> n.copy(title = unesc(v))
                "paper" -> n.copy(paper = (v.toIntOrNull() ?: 0).coerceIn(0, PAPERS - 1))
                "color" -> n.copy(color = v.toIntOrNull() ?: 0)
                "pinned" -> n.copy(pinned = v == "1")
                "folder" -> n.copy(folder = unesc(v))
                "created" -> n.copy(created = v.toLongOrNull() ?: 0L)
                "updated" -> n.copy(updated = v.toLongOrNull() ?: 0L)
                "trashed" -> n.copy(trashedAt = v.toLongOrNull() ?: 0L)
                "locked" -> n.copy(locked = v == "1")
                "body" -> n.copy(body = unesc(v))
                "pdf" -> if (safeFile(v)) n.copy(pdf = v) else n
                else -> n
            }
        }
        return n.copy(strokes = strokes, images = imgs, audios = auds)
    }

    // ---------- Liste: arama / sıralama / filtre ----------
    fun displayTitle(n: Note): String {
        if (n.title.isNotBlank()) return n.title.trim()
        val first = n.body.lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: return ""
        return first.removePrefix("[ ] ").removePrefix("[x] ").take(60)
    }

    /** Kilitli notların içeriği aramaya girmez (yalnızca başlık). */
    fun matches(n: Note, q: String): Boolean {
        val t = com.odak.app.logic.Pure.foldForSearch(q.trim())
        if (t.isEmpty()) return true
        if (com.odak.app.logic.Pure.foldForSearch(n.title).contains(t) || com.odak.app.logic.Pure.foldForSearch(n.folder).contains(t)) return true
        return !n.locked && com.odak.app.logic.Pure.foldForSearch(n.body).contains(t)
    }

    const val SORT_UPDATED = 0
    const val SORT_CREATED = 1
    const val SORT_ALPHA = 2

    /** Kayıtlı sıralama değerini geçerli bir moda çevirir; bilinmeyen değer son değişen olur. */
    fun sortMode(v: Int): Int = if (v in SORT_UPDATED..SORT_ALPHA) v else SORT_UPDATED

    /** Türkçe alfabe sırası (ç, ğ, ı, i, ş, ö, ü doğru yerde). */
    private val trCollator: java.text.Collator = java.text.Collator.getInstance(Locale("tr", "TR")).apply {
        strength = java.text.Collator.PRIMARY
    }

    /** mode: 0 son değişen, 1 oluşturulma (yeni üstte), 2 başlık A-Z (Türkçe sıra). Sabitlenenler hep üstte. */
    fun sorted(list: List<Note>, mode: Int): List<Note> {
        val cmp: Comparator<Note> = when (sortMode(mode)) {
            SORT_CREATED -> compareByDescending<Note> { it.created }
            SORT_ALPHA -> Comparator { a, b -> trCollator.compare(displayTitle(a), displayTitle(b)) }
            else -> compareByDescending<Note> { it.updated }
        }
        return list.sortedWith(compareByDescending<Note> { it.pinned }.then(cmp))
    }

    /** folder: null = hepsi, "" = klasörsüz. trash=true yalnızca çöp kutusu. */
    fun visible(list: List<Note>, folder: String?, trash: Boolean, q: String): List<Note> =
        list.filter { (it.trashedAt > 0L) == trash && (trash || folder == null || it.folder == folder) && matches(it, q) }

    fun folders(list: List<Note>): List<String> =
        list.filter { it.trashedAt == 0L && it.folder.isNotBlank() }.map { it.folder }.distinct().sortedBy { it.lowercase(Locale.ROOT) }

    fun cleanFolder(s: String): String = s.replace('\n', ' ').trim().take(30)

    fun isExpired(n: Note, now: Long, days: Int = TRASH_DAYS): Boolean =
        n.trashedAt > 0L && now - n.trashedAt > days * 86_400_000L

    fun daysLeft(n: Note, now: Long, days: Int = TRASH_DAYS): Int =
        if (n.trashedAt <= 0L) days else max(0, days - ((now - n.trashedAt) / 86_400_000L).toInt())

    fun wordCount(s: String): Int = s.split(Regex("\\s+")).count { it.isNotEmpty() }

    /** Okuma süresi (dk): dakikada 200 kelime, en az 1; boşsa 0. */
    fun readMinutes(s: String): Int { val w = wordCount(s); return if (w == 0) 0 else max(1, (w + 199) / 200) }

    /** Renge göre süzer: 0 = hepsi (renk 0 "renksiz" değil, "filtre yok" demektir). */
    fun byColor(list: List<Note>, color: Int): List<Note> = if (color == 0) list else list.filter { it.color == color }

    /** Seçili süzgeç rengi kullanılan renkler arasında değilse 0 (süzgeç yok). */
    fun activeColor(used: List<Int>, selected: Int): Int = if (selected != 0 && selected in used) selected else 0

    /** Listede kullanılan renkler (0 hariç, tekrarsız, ilk görülme sırası). */
    fun colorsUsed(list: List<Note>): List<Int> = list.filter { it.trashedAt == 0L && it.color != 0 }.map { it.color }.distinct()

    // ---------- Yapılacaklar listesi (gövdede "[ ] " / "[x] ") ----------
    fun toggleCheck(body: String, line: Int): String {
        val ls = body.split('\n').toMutableList()
        if (line !in ls.indices) return body
        val l = ls[line]
        ls[line] = when {
            l.startsWith("[ ] ") -> "[x] " + l.substring(4)
            l.startsWith("[x] ") -> "[ ] " + l.substring(4)
            else -> l
        }
        return ls.joinToString("\n")
    }

    /**
     * Yapılacaklar satırında Enter: yeni satır "[ ] " ile başlar (işaretli satırdan sonra da işaretsiz).
     * Boş bir yapılacak satırında Enter listeyi bitirir: o satırın öneki kalkar. Yalnızca tek karakterlik
     * bir yeni satır eklendiğinde (yazarken Enter) çalışır; yapıştırma ve diğer değişiklikler olduğu gibi döner.
     */
    fun enterInList(old: String, new: String): String {
        if (new.length != old.length + 1) return new
        val i = (0 until old.length).firstOrNull { old[it] != new[it] } ?: old.length
        if (new[i] != '\n') return new
        val lineStart = if (i == 0) 0 else old.lastIndexOf('\n', i - 1) + 1
        val line = old.substring(lineStart, i)
        if (!(line.startsWith("[ ] ") || line.startsWith("[x] "))) return new
        if (line.substring(4).isBlank()) return old.substring(0, lineStart) + old.substring(i)
        return new.substring(0, i + 1) + "[ ] " + new.substring(i + 1)
    }

    fun addCheckLine(body: String): String = if (body.isEmpty() || body.endsWith("\n")) body + "[ ] " else "$body\n[ ] "

    fun checkCounts(body: String): Pair<Int, Int> {
        val ls = body.split('\n')
        val done = ls.count { it.startsWith("[x] ") }
        return done to (done + ls.count { it.startsWith("[ ] ") })
    }

    // ---------- Çizim ----------
    /** Birbirine min uzaklıktan yakın noktaları atar (ilk ve son nokta kalır). */
    fun simplify(pts: List<Pt>, minDist: Float): List<Pt> {
        if (pts.size <= 2) return pts
        val out = ArrayList<Pt>()
        out.add(pts[0])
        for (i in 1 until pts.size - 1) {
            val l = out.last()
            if (hypot(pts[i].x - l.x, pts[i].y - l.y) >= minDist) out.add(pts[i])
        }
        out.add(pts.last())
        return out
    }

    /** Noktadan doğru parçasına uzaklık. */
    fun segDist(px: Float, py: Float, a: Pt, b: Pt): Float {
        val dx = b.x - a.x; val dy = b.y - a.y
        val l2 = dx * dx + dy * dy
        if (l2 == 0f) return hypot(px - a.x, py - a.y)
        val t = (((px - a.x) * dx + (py - a.y) * dy) / l2).coerceIn(0f, 1f)
        return hypot(px - (a.x + t * dx), py - (a.y + t * dy))
    }

    fun strokeHit(s: Stroke, x: Float, y: Float, r: Float): Boolean {
        if (s.pts.size == 1) return hypot(x - s.pts[0].x, y - s.pts[0].y) <= r
        for (i in 0 until s.pts.size - 1) if (segDist(x, y, s.pts[i], s.pts[i + 1]) <= r) return true
        return false
    }

    /** Silgi: değdiği çizgileri komple siler. */
    fun eraseAt(strokes: List<Stroke>, x: Float, y: Float, r: Float): List<Stroke> =
        strokes.filterNot { strokeHit(it, x, y, r) }

    /** Çizimlerin en alt y değeri (sayfa yüksekliğini büyütmek için). */
    fun maxY(strokes: List<Stroke>): Float = strokes.maxOfOrNull { s -> s.pts.maxOfOrNull { it.y } ?: 0f } ?: 0f

    /** Sayfa yüksekliği (genişlik biriminde): en az 1.4, içerikten 0.6 fazla. */
    fun pageHeight(strokes: List<Stroke>): Float = max(1.4f, maxY(strokes) + 0.6f)
    fun pageHeight(strokes: List<Stroke>, images: List<NoteImg>): Float =
        max(1.4f, max(maxY(strokes), images.maxOfOrNull { imgBottom(it) } ?: 0f) + 0.6f)

    fun strokeAlpha(tool: Int): Float = when (tool) { TOOL_HIGHLIGHT -> 0.35f; TOOL_PENCIL -> 0.8f; else -> 1f }

    /** Fosforlu kalem kalındır: etkin kalınlık. */
    fun effWidth(tool: Int, w: Float): Float = if (tool == TOOL_HIGHLIGHT) w * 3f else w


    // ---------- Dosya adı güvenliği ----------
    /** notes/ altındaki medya dosyaları için güvenli ad: harf/rakam/_/-/. ; nokta ile başlamaz, ".." içermez. */
    fun safeFile(s: String): Boolean =
        s.isNotEmpty() && s.length <= 100 && !s.startsWith(".") && !s.contains("..") && s.all { (it in 'a'..'z') || (it in 'A'..'Z') || (it in '0'..'9') || it == '_' || it == '-' || it == '.' }

    // ---------- Kalem basıncı ----------
    /** Basınca göre kalınlık: p=0 → %35, p=1 → %100. */
    fun pressW(base: Float, p: Float): Float = base * (0.35f + 0.65f * p.coerceIn(0f, 1f))

    /** Çizgideki ortalama basınç (liste boşsa 1). */
    fun avgPressure(pts: List<Pt>): Float = if (pts.isEmpty()) 1f else pts.map { it.p }.average().toFloat()

    // ---------- Resimler ----------
    fun imgBottom(i: NoteImg): Float = i.y + i.w * i.a
    fun imgHit(i: NoteImg, x: Float, y: Float): Boolean = x >= i.x && x <= i.x + i.w && y >= i.y && y <= imgBottom(i)
    /** En üstteki (listede sonraki) isabet eden resmin sırası; yoksa -1. */
    fun imgAt(list: List<NoteImg>, x: Float, y: Float): Int = list.indexOfLast { imgHit(it, x, y) }
    fun moveImg(i: NoteImg, dx: Float, dy: Float): NoteImg =
        i.copy(x = (i.x + dx).coerceIn(0f, 1f - i.w), y = (i.y + dy).coerceAtLeast(0f))
    fun scaleImg(i: NoteImg, factor: Float): NoteImg {
        val w = (i.w * factor).coerceIn(0.1f, 1f)
        return i.copy(w = w, x = i.x.coerceIn(0f, 1f - w))
    }
    /** Bitmap'i en çok maxPx kenara küçült: (yeni genişlik, yeni yükseklik). Küçültme yoksa aynı. */
    fun fitSize(w: Int, h: Int, maxPx: Int): Pair<Int, Int> {
        if (w <= 0 || h <= 0) return 1 to 1
        val m = max(w, h)
        if (m <= maxPx) return w to h
        val k = maxPx.toFloat() / m
        return max(1, (w * k).toInt()) to max(1, (h * k).toInt())
    }

    // ---------- Ses ----------
    fun fmtDur(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "${s / 60}:${"%02d".format(s % 60)}" }

    // ---------- PDF sayfa yerleşimi (sayfa genişliği = 1) ----------
    const val PDF_GAP = 0.02f
    /** aspects: her sayfanın yükseklik/genişlik oranı. Dönüş: her sayfanın üst y'si. */
    fun pdfTops(aspects: List<Float>, gap: Float = PDF_GAP): List<Float> {
        val out = ArrayList<Float>(); var y = 0f
        for (a in aspects) { out.add(y); y += a + gap }
        return out
    }
    fun pdfTotal(aspects: List<Float>, gap: Float = PDF_GAP): Float = if (aspects.isEmpty()) 0f else pdfTops(aspects, gap).last() + aspects.last()
    /** y noktasının hangi sayfada olduğu (boşluklar önceki sayfaya sayılır). */
    fun pdfPageAt(tops: List<Float>, y: Float): Int {
        var r = 0
        for (i in tops.indices) if (tops[i] <= y) r = i
        return r
    }
    /** Çizgi hangi sayfaya ait: ilk noktasının sayfası. */
    fun strokePage(tops: List<Float>, s: Stroke): Int = if (s.pts.isEmpty() || tops.isEmpty()) 0 else pdfPageAt(tops, s.pts[0].y)
    fun strokesOfPage(tops: List<Float>, strokes: List<Stroke>, page: Int): List<Stroke> = strokes.filter { strokePage(tops, it) == page }

    // ---------- Geri al / yinele ----------
    class History<T>(private val limit: Int = 100) {
        private val undo = ArrayList<T>()
        private val redo = ArrayList<T>()
        fun push(state: T) { undo.add(state); if (undo.size > limit) undo.removeAt(0); redo.clear() }
        fun canUndo() = undo.isNotEmpty()
        fun canRedo() = redo.isNotEmpty()
        /** current: şimdiki durum; geri alınınca dönülecek önceki durumu verir. */
        fun undo(current: T): T? { if (undo.isEmpty()) return null; redo.add(current); return undo.removeAt(undo.size - 1) }
        fun redo(current: T): T? { if (redo.isEmpty()) return null; undo.add(current); return redo.removeAt(redo.size - 1) }
        fun clear() { undo.clear(); redo.clear() }
    }

    // ---------- Metin dışa aktarma ----------
    /**
     * Paylaşılan düz metin: başlık, bir boş satır, gövde. Yapılacak satırları ham önek yerine ☐ / ☑ ile
     * yazılır; sondaki boş satırlar atılır. Başlık boşsa gövde doğrudan başlar.
     */
    fun exportText(n: Note): String {
        val body = n.body.split('\n').joinToString("\n") { l ->
            when {
                l.startsWith("[ ] ") -> "☐ " + l.substring(4)
                l.startsWith("[x] ") -> "☑ " + l.substring(4)
                else -> l
            }
        }.trimEnd()
        val title = n.title.trim()
        return when {
            title.isEmpty() -> body
            body.isEmpty() -> title
            else -> title + "\n\n" + body
        }
    }
}
