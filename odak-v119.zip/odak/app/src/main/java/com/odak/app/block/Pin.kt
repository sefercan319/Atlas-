package com.odak.app.block

import android.content.Context
import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedHeader
import com.odak.app.theme.ThemedTextField

object Pin {
    private fun prefs(c: Context) = c.getSharedPreferences("odak_pin", Context.MODE_PRIVATE)
    private var unlockedUntil = 0L

    fun isSet(c: Context) = prefs(c).contains("h")

    /** Yeni PIN'i sürüm 2 (PBKDF2) ile saklar. */
    private fun store(c: Context, pin: String) {
        val salt = com.odak.app.logic.PinHash.newSalt()
        prefs(c).edit()
            .putString("s", salt)
            .putString("h", com.odak.app.logic.PinHash.pbkdf2(pin, salt))
            .putInt("v", com.odak.app.logic.PinHash.VERSION)
            .apply()
    }

    fun set(c: Context, pin: String) {
        store(c, pin)
        unlock()
    }

    fun check(c: Context, pin: String): Boolean {
        val p = prefs(c)
        val s = p.getString("s", null) ?: return false
        val stored = p.getString("h", null) ?: return false
        val ver = p.getInt("v", 1)
        if (!com.odak.app.logic.PinHash.verify(pin, s, stored, ver)) return false
        // Doğru PIN eski özetle saklanmışsa, aynı girişte güçlü özete yükselt.
        if (com.odak.app.logic.PinHash.needsUpgrade(ver)) store(c, pin)
        return true
    }

    fun clear(c: Context) = prefs(c).edit().clear().apply()

    /** Doğru PIN'den sonra 3 dakika açık kalır. */
    fun unlock() {
        unlockedUntil = SystemClock.elapsedRealtime() + 3 * 60_000
    }

    fun locked(c: Context) = isSet(c) && SystemClock.elapsedRealtime() > unlockedUntil
}

@Composable
fun PinGate(title: String, onUnlocked: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ThemedHeader(title)
        Spacer(Modifier.height(12.dp))
        ThemedTextField(
            value = pin,
            onValueChange = { pin = it.filter(Char::isDigit).take(8); wrong = false },
            placeholder = stringResource(R.string.pin_enter),
            modifier = Modifier.fillMaxWidth(),
            secret = true
        )
        if (wrong) Text(stringResource(R.string.pin_wrong), color = com.odak.app.theme.errorColor())
        Spacer(Modifier.height(12.dp))
        ThemedButton(stringResource(R.string.pin_ok), {
            if (Pin.check(ctx, pin)) {
                Pin.unlock()
                onUnlocked()
            } else wrong = true
        })
    }
}
