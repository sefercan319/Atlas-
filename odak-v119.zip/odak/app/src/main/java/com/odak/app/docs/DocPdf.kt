package com.odak.app.docs

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import com.odak.app.notes.NoteMedia
import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Kelime kelime yazı boyutu/kalın/italik bilgisi toplayan çıkarıcı (PDF → biçimli metin için). */
private class FmtStripper : PDFTextStripper() {
    class W(val text: String, val size: Float, val bold: Boolean, val italic: Boolean, val y: Float, val x: Float)
    val words = ArrayList<W>()
    override fun writeString(text: String?, textPositions: MutableList<TextPosition>?) {
        if (text != null && textPositions != null && textPositions.isNotEmpty() && text.isNotBlank()) {
            val tp = textPositions[0]
            val name = (tp.font?.name ?: "").lowercase()
            words.add(W(text.trim(), tp.fontSizeInPt, name.contains("bold") || name.contains("black") || name.contains("heavy"),
                name.contains("italic") || name.contains("oblique"), tp.yDirAdj, tp.xDirAdj))
        }
        super.writeString(text, textPositions)
    }
}

/** Android'e bağlı dönüştürmeler: belge → PDF (PdfDocument ile) ve PDF → sayfa resimleri (PNG zip). */
object DocPdf {
    private const val MAX_LINES = 20000

    /** PDF'teki yazıyı sayfa sayfa çıkarır (pdfbox-android). Dosya önce cache'e akıtılır, pdfbox geçici dosya kullanır; boyut sınırı yoktur. Yazı yoksa (taranmış PDF) sayfalar boş gelir. */
    fun extractText(ctx: Context, uri: Uri): Doc {
        PDFBoxResourceLoader.init(ctx.applicationContext)
        val tmp = File(File(ctx.cacheDir, "convert").also { it.mkdirs() }, "src.pdf")
        try {
            ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            PDDocument.load(tmp, MemoryUsageSetting.setupTempFileOnly()).use { d ->
                val st = FmtStripper()
                val pages = ArrayList<DocPage>()
                var total = 0
                for (n in 1..d.numberOfPages) {
                    st.startPage = n; st.endPage = n
                    st.words.clear()
                    val lines = st.getText(d).replace("\r\n", "\n").split('\n').map { it.trim() }.filter { it.isNotEmpty() }
                    if (total + lines.size > MAX_LINES) break
                    total += lines.size
                    val rich = try { richPage(d, n, st) } catch (e: Exception) { null }
                    pages.add(DocPage("Sayfa $n", lines, null, null, rich))
                }
                return Doc(DocKind.PDF, if (pages.any { it.paragraphs.isNotEmpty() }) pages else emptyList())
            }
        } finally { tmp.delete() }
    }

    /** Sayfadaki kelimeleri satır → paragraf → başlık olarak toplar; en sık boyut gövde sayılır. */
    private fun richPage(doc: PDDocument, n: Int, st: FmtStripper): RichPage? {
        val ws = st.words.toList()
        if (ws.isEmpty()) return null
        val lines = ArrayList<ArrayList<FmtStripper.W>>()
        for (w in ws) {
            val last = lines.lastOrNull()
            if (last != null && Math.abs(last[0].y - w.y) < maxOf(2f, last[0].size * 0.5f)) last.add(w) else lines.add(arrayListOf(w))
        }
        val bySize = HashMap<Int, Int>()
        for (w in ws) bySize.merge(Math.round(w.size * 2f), w.text.length) { a, b -> a + b }
        val body = (bySize.maxByOrNull { it.value }?.key ?: 22) / 2f
        val blocks = ArrayList<RBlock>()
        var cur = ArrayList<RRun>()
        var prevY = Float.NaN; var prevSize = 0f
        fun flush() { if (cur.isNotEmpty()) { blocks.add(RPara(ArrayList(cur), after = 120)); cur = ArrayList() } }
        for (ln in lines) {
            val size = ln.map { it.size }.average().toFloat()
            val y = ln[0].y
            val text = ln.joinToString(" ") { it.text }
            val head = if (size >= body * 1.25f && text.length < 120) (if (size >= body * 1.8f) 1 else if (size >= body * 1.4f) 2 else 3) else 0
            val newPara = prevY.isNaN() || head > 0 || prevSize >= body * 1.25f || Math.abs(y - prevY) > size * 1.6f || Math.abs(size - prevSize) > body * 0.15f
            if (newPara) flush()
            if (head > 0) {
                blocks.add(RPara(listOf(RRun(text, b = true, sz = Math.round(size * 2f))), head = head, before = 120, after = 120))
            } else {
                if (cur.isNotEmpty()) cur.add(RRun(" "))
                var i = 0
                while (i < ln.size) {
                    var j = i
                    val sb = StringBuilder()
                    while (j < ln.size && ln[j].bold == ln[i].bold && ln[j].italic == ln[i].italic) { if (sb.isNotEmpty()) sb.append(' '); sb.append(ln[j].text); j++ }
                    if (j < ln.size) sb.append(' ')
                    cur.add(RRun(sb.toString(), ln[i].bold, ln[i].italic, sz = Math.round(body * 2f)))
                    i = j
                }
            }
            prevY = y; prevSize = size
        }
        flush()
        val box = doc.getPage(n - 1).mediaBox
        return RichPage(blocks, PageSetup((box.width * 20).toInt(), (box.height * 20).toInt(), 720, 720, 720, 720), Math.round(body * 2f), null, 0, 0)
    }

    private const val PW = 595
    private const val PH = 842
    private const val M = 40f

    /** Belgeyi A4 sayfalara yazar. Kaynakta birden çok sayfa/slayt/sayfa sekmesi varsa her biri yeni PDF sayfasında başlar. Dönüş: sayfa sayısı. */
    fun write(doc: Doc, out: File): Int {
        val pdf = PdfDocument()
        var pageNo = 0
        var page: PdfDocument.Page? = null
        var cv: Canvas? = null
        var y = 0f
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = Color.BLACK }
        val head = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; isFakeBoldText = true; color = Color.BLACK }
        val line = Paint().apply { color = 0xFF999999.toInt(); strokeWidth = 0.7f; style = Paint.Style.STROKE }

        fun newPage() {
            page?.let { pdf.finishPage(it) }
            pageNo++
            val p = pdf.startPage(PdfDocument.PageInfo.Builder(PW, PH, pageNo).create())
            page = p; cv = p.canvas; y = M
        }
        fun ensure(h: Float) { if (cv == null || y + h > PH - M) newPage() }
        fun text(t: String, paint: Paint, lead: Float) {
            for (l in DocConvert.wrap(t, PW - 2 * M, { paint.measureText(it) })) {
                ensure(lead)
                cv!!.drawText(l, M, y + paint.textSize, paint)
                y += lead
            }
        }

        var drawn = false
        doc.pages.forEachIndexed { i, p ->
            val rich = p.rich
            if (rich != null) {
                RichPdfPainter { w, h ->
                    page?.let { pdf.finishPage(it) }
                    pageNo++
                    val np = pdf.startPage(PdfDocument.PageInfo.Builder(w.toInt().coerceAtLeast(100), h.toInt().coerceAtLeast(100), pageNo).create())
                    page = np; cv = np.canvas; drawn = true
                    np.canvas
                }.draw(rich)
                return@forEachIndexed
            }
            if (i > 0 || cv == null || drawn) { newPage(); drawn = false }
            if (DocConvert.showTitle(doc, p)) { text(p.title, head, 22f); y += 4f }
            for (t in p.paragraphs) { text(t, body, 15f); y += 3f }
            val rows = p.table?.let { DocConvert.padRows(it) }
            if (!rows.isNullOrEmpty() && rows[0].isNotEmpty()) {
                val cols = rows[0].size
                val tp = Paint(body).apply { textSize = if (cols > 8) 7f else if (cols > 5) 9f else 11f }
                val cw = (PW - 2 * M) / cols
                for (r in rows) {
                    val cells = r.map { DocConvert.wrap(it, cw - 6f, { s -> tp.measureText(s) }) }
                    val lead = tp.textSize + 4f
                    val h = (cells.maxOf { it.size }.coerceAtMost(12)) * lead + 4f
                    ensure(h)
                    r.indices.forEach { c ->
                        val x = M + c * cw
                        cv!!.drawRect(x, y, x + cw, y + h, line)
                        cells[c].take(12).forEachIndexed { k, l -> cv!!.drawText(l, x + 3f, y + 2f + tp.textSize + k * lead, tp) }
                    }
                    y += h
                }
                y += 8f
            }
        }
        if (cv == null) newPage()
        page?.let { pdf.finishPage(it) }
        out.outputStream().use { pdf.writeTo(it) }
        pdf.close()
        return pageNo
    }

    /** PDF'in her sayfasını PNG yapıp zip'e koyar (sayfa-001.png …). Dönüş: yazılan sayfa sayısı. */
    fun pdfToPngZip(renderer: PdfRenderer, out: File, widthPx: Int = 1240): Int {
        var n = 0
        ZipOutputStream(out.outputStream()).use { z ->
            for (i in 0 until renderer.pageCount) {
                val bmp: Bitmap = NoteMedia.renderPdfPage(renderer, i, widthPx) ?: continue
                z.putNextEntry(ZipEntry("sayfa-%03d.png".format(i + 1)))
                bmp.compress(Bitmap.CompressFormat.PNG, 100, z)
                z.closeEntry()
                bmp.recycle()
                n++
            }
        }
        return n
    }
}
