package com.odak.app.docs

import java.util.IdentityHashMap

/** Paragrafa göre konumlu kutular (RTable.at, 5. eleman 1): hangi paragrafa bağlı ve sayfada nereye düşer. Saf mantık. */
object Anchors {
    fun isParaRel(t: RTable): Boolean { val a = t.at; return a != null && a.size > 4 && a[4] == 1 }

    /**
     * Akıştan paragrafa bağlı kutuları ayırır: (kalan bloklar, paragraf → kutular). Kutu, kendinden önceki en yakın paragrafa
     * (arada başka kutu/tablo olsa da son paragraf) bağlanır; öncesinde paragraf yoksa akışta kalır (sayfa üstüne göre çizilir).
     */
    fun split(blocks: List<RBlock>): Pair<List<RBlock>, IdentityHashMap<RPara, MutableList<RTable>>> {
        val map = IdentityHashMap<RPara, MutableList<RTable>>()
        val flow = ArrayList<RBlock>()
        var last: RPara? = null
        for (b in blocks) {
            if (b is RTable && isParaRel(b) && last != null) { map.getOrPut(last) { ArrayList() }.add(b); continue }
            flow.add(b)
            if (b is RPara) last = b
        }
        return flow to map
    }

    /**
     * Kutunun üstü (punto): paragrafın BAŞLADIĞI sayfadaki ilk satır üstü + ofset; sayfanın dışına taşmaz
     * (alt kenara sığmazsa yukarı çekilir, üstten taşmaz). Böylece paragraf sonraki sayfaya taşsa da kutu kendi sayfasında kalır.
     */
    fun top(lineTopPt: Float, offTwips: Int, boxHTwips: Int, pageHPt: Float): Float {
        val h = boxHTwips / 20f
        val t = lineTopPt + offTwips / 20f
        return minOf(t, pageHPt - h).coerceAtLeast(0f)
    }
}
