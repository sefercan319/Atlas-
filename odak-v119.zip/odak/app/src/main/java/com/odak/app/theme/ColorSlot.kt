package com.odak.app.theme

/** Kullanıcının değiştirebildiği renk yuvaları. [key] tercih anahtarının sonudur (eski kayıtlarla uyumlu: p, a, b, t). */
enum class ColorSlot(val key: String) {
    PRIMARY("p"), ACCENT("a"), BACKGROUND("b"), TEXT("t"), SURFACE("s"), BUTTON("bb"), BUTTON_TEXT("bt");

    companion object {
        fun prefKey(styleKey: String, slot: ColorSlot) = "$styleKey:${slot.key}"
    }
}

/** Stilin bir parçasının (zemin, düğme, kart) boyama karakteri. lo/hi: tasarımın parlaklık aralığı (0..255), spec: parlama koruma gücü. */
class RecolorProfile(val gain: Float, val lo: Float, val hi: Float, val spec: Float = 0f, val specFrom: Float = 220f)

/**
 * Yeniden boyama: bir görselin (gradyan, parlama, desen) açık-koyu yapısını koruyup rengini hedef renge çeker.
 * Taban rengin parlaklığındaki piksel hedef renk olur; daha parlak/koyu pikseller aynı farkla açılır/koyulur.
 * Hedef çok koyu/açıksa desen kırpılmasın diye merkez parlaklığı kaydırılır ve gerekirse kontrast azaltılır.
 * Çıktı: ColorMatrix (4x5, satır sıralı, ofsetler 0..255). Saf mantık.
 */
object Recolor {
    private const val WR = 0.299f; private const val WG = 0.587f; private const val WB = 0.114f
    const val MIN_KEEP = 0.8f   // tasarımın açık-koyu farkının en az bu kadarı korunur

    fun luma(argb: Int): Float = WR * ((argb shr 16) and 255) + WG * ((argb shr 8) and 255) + WB * (argb and 255)

    /** Kırpılmadan sığan kontrast ve merkez kayması: (gain, merkez parlaklık kayması). */
    fun fit(targetLuma: Float, baseLuma: Float, pr: RecolorProfile): Pair<Float, Float> {
        val down = maxOf(baseLuma - pr.lo, 0f); val up = maxOf(pr.hi - baseLuma, 0f)
        val m = 3f
        var g = pr.gain
        val span = down + up
        if (span > 0f && g * span > 255f - 2 * m) g = (255f - 2 * m) / span
        val minC = g * down + m; val maxC = 255f - g * up - m
        val c = targetLuma.coerceIn(minOf(minC, maxC), maxOf(minC, maxC))
        return g to (c - targetLuma)
    }

    fun matrix(target: Int, base: Int, pr: RecolorProfile): FloatArray {
        val l0 = luma(base)
        val (g, shift) = fit(luma(target), l0, pr)
        val off = FloatArray(3) { i -> ((target shr (16 - 8 * i)) and 255) + shift - g * l0 }
        fun row(o: Float) = floatArrayOf(g * WR, g * WG, g * WB, 0f, o)
        return row(off[0]) + row(off[1]) + row(off[2]) + floatArrayOf(0f, 0f, 0f, 1f, 0f)
    }

    fun matrix(target: Int, base: Int, gain: Float = 1f): FloatArray = matrix(target, base, RecolorProfile(gain, luma(base), luma(base)))

    /** Parlama katmanı: yalnız çok parlak pikseller (beyaz parlama) gri olarak kalır; Screen ile boyanmış katmanın üstüne bindirilir. */
    fun highlightMatrix(pr: RecolorProfile): FloatArray {
        val k = pr.spec * 255f / (255f - pr.specFrom)
        fun row() = floatArrayOf(k * WR, k * WG, k * WB, 0f, -k * pr.specFrom)
        return row() + row() + row() + floatArrayOf(0f, 0f, 0f, 1f, 0f)
    }

    /** Matrisi tek ARGB pikseline uygular (test/önizleme için). */
    fun apply(m: FloatArray, argb: Int): Int {
        val r = ((argb shr 16) and 255).toFloat(); val g = ((argb shr 8) and 255).toFloat(); val b = (argb and 255).toFloat()
        fun ch(i: Int) = Math.round(m[i * 5] * r + m[i * 5 + 1] * g + m[i * 5 + 2] * b + m[i * 5 + 4]).coerceIn(0, 255)
        return (argb and (0xFF shl 24)) or (ch(0) shl 16) or (ch(1) shl 8) or ch(2)
    }

    /** Boyanmış piksel + parlama katmanı (Screen) birleşik sonucu (önizleme/test için). */
    fun applyWithSpec(target: Int, base: Int, pr: RecolorProfile, argb: Int): Int {
        val a = apply(matrix(target, base, pr), argb)
        if (pr.spec <= 0f) return a
        val h = apply(highlightMatrix(pr), argb)
        fun scr(x: Int, y: Int) = 255 - (255 - x) * (255 - y) / 255
        fun ch(sh: Int) = scr((a shr sh) and 255, (h shr sh) and 255)
        return (a and (0xFF shl 24)) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }
}

/** Her stilin zemin / düğme / kart parçası için boyama karakteri. Aralıklar tasarım kodundaki gradyan duraklarından tahmin edilmiştir. */
object RecolorProfiles {
    enum class Part { BACKGROUND, BUTTON, CARD }

    private val FLAT = RecolorProfile(1f, 0f, 0f)
    private val bg = mapOf(
        "futuristic" to RecolorProfile(1f, 4f, 40f), "terminal" to RecolorProfile(1f, 4f, 40f),
        "frutiger_aero" to RecolorProfile(0.95f, 146f, 226f),
        "minimal" to FLAT, "windows11" to RecolorProfile(1f, 238f, 244f),
        "neon" to RecolorProfile(1f, 7f, 40f),
        "skeuomorphism" to RecolorProfile(1f, 0f, 0f).let { RecolorProfile(1f, 150f, 200f) },
        "neumorphism" to FLAT, "glassmorphism" to RecolorProfile(1f, 20f, 110f),
        "y2k" to RecolorProfile(0.95f, 200f, 255f, spec = 0.35f, specFrom = 240f),
        "aurora" to RecolorProfile(1f, 10f, 120f), "claymorphism" to FLAT, "dark_mode" to FLAT,
        "cosmic" to RecolorProfile(1f, 8f, 110f), "scifi_hud" to RecolorProfile(1f, 8f, 90f),
        "cyber_industrial" to RecolorProfile(1f, 20f, 90f), "neoclassical" to RecolorProfile(1f, 190f, 245f)
    )
    private val btn = mapOf(
        "frutiger_aero" to RecolorProfile(1f, 96f, 235f, spec = 0.9f, specFrom = 215f),
        "y2k" to RecolorProfile(1f, 70f, 240f, spec = 0.9f, specFrom = 220f),
        "minimal" to RecolorProfile(1f, 17f, 255f),
        "neumorphism" to RecolorProfile(1f, 150f, 245f),
        "aurora" to RecolorProfile(1f, 30f, 200f, spec = 0.3f, specFrom = 225f),
        "cosmic" to RecolorProfile(1f, 30f, 200f, spec = 0.3f, specFrom = 225f),
        "scifi_hud" to RecolorProfile(1f, 20f, 180f, spec = 0.2f, specFrom = 225f),
        "cyber_industrial" to RecolorProfile(1f, 20f, 200f, spec = 0.2f, specFrom = 225f),
        "neoclassical" to RecolorProfile(1f, 40f, 230f, spec = 0.4f, specFrom = 220f)
    )
    private val card = mapOf(
        "frutiger_aero" to RecolorProfile(1f, 190f, 255f, spec = 0.6f, specFrom = 235f),
        "y2k" to RecolorProfile(1f, 225f, 255f, spec = 0.5f, specFrom = 245f),
        "aurora" to RecolorProfile(1f, 15f, 120f), "dark_mode" to RecolorProfile(1f, 20f, 70f),
        "cosmic" to RecolorProfile(1f, 15f, 110f), "scifi_hud" to RecolorProfile(1f, 10f, 90f),
        "cyber_industrial" to RecolorProfile(1f, 40f, 120f, spec = 0.15f, specFrom = 200f)
    )

    /** Düğme türetimli (ışıma/kenar ana renkten çizilen) stiller: boyama yerine ana renk doğrudan düğme rengi olur. */
    val BUTTON_DERIVED = setOf("terminal", "futuristic", "neon", "skeuomorphism", "windows11", "glassmorphism", "claymorphism", "dark_mode")

    fun forStyle(styleKey: String, part: Part): RecolorProfile = when (part) {
        Part.BACKGROUND -> bg[styleKey]; Part.BUTTON -> btn[styleKey]; Part.CARD -> card[styleKey]
    } ?: FLAT

    val STYLE_KEYS: List<String> = listOf("futuristic", "frutiger_aero", "minimal", "windows11", "terminal", "neon", "skeuomorphism", "neumorphism",
        "glassmorphism", "y2k", "aurora", "claymorphism", "dark_mode", "cosmic", "scifi_hud", "cyber_industrial", "neoclassical")
}
