package com.odak.app.docs

import android.content.res.AssetManager
import android.graphics.Typeface

/** Gömülü yazı tiplerini (Carlito, Caladea) assets/fonts'tan yükleyip önbellekler; bulunamazsa null. */
internal object RichFonts {
    @Volatile var assets: AssetManager? = null
    private val cache = HashMap<String, Typeface?>()

    @Synchronized
    fun typeface(name: String?, bold: Boolean, italic: Boolean): Typeface? {
        val fam = FontMap.asset(name) ?: return null
        val am = assets ?: return null
        val file = FontMap.assetFile(fam, bold, italic)
        return cache.getOrPut(file) { try { Typeface.createFromAsset(am, file) } catch (e: Exception) { null } catch (e: RuntimeException) { null } }
    }
}
