package com.odak.app.theme

import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Typography
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

private val FluentEase = CubicBezierEasing(0.1f, 0.9f, 0.2f, 1f)

/** Her tasarımın kendi hareket karakteri. */
fun <T> motion(style: DesignStyle): FiniteAnimationSpec<T> = when (style) {
    DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> tween<T>(130, easing = LinearEasing)
    DesignStyle.FRUTIGER_AERO -> spring<T>(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)
    DesignStyle.MINIMAL -> tween<T>(420, easing = FastOutSlowInEasing)
    DesignStyle.WINDOWS11 -> tween<T>(170, easing = FluentEase)
    DesignStyle.NEON -> tween<T>(280, easing = FastOutSlowInEasing)
    DesignStyle.SKEUOMORPHISM -> spring<T>(0.55f, Spring.StiffnessMedium)
    DesignStyle.NEUMORPHISM -> tween<T>(160, easing = FastOutSlowInEasing)
    DesignStyle.GLASSMORPHISM -> tween<T>(380, easing = FastOutSlowInEasing)
    DesignStyle.Y2K -> spring<T>(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)
    DesignStyle.AURORA -> tween<T>(600, easing = FastOutSlowInEasing)
    DesignStyle.CLAYMORPHISM -> spring<T>(0.5f, Spring.StiffnessMediumLow)
    DesignStyle.DARK -> tween<T>(150, easing = FastOutSlowInEasing)
    DesignStyle.COSMIC -> spring<T>(Spring.DampingRatioNoBouncy, Spring.StiffnessLow)
    DesignStyle.SCIFI_HUD -> tween<T>(120, easing = LinearEasing)
    DesignStyle.CYBER_INDUSTRIAL -> spring<T>(Spring.DampingRatioMediumBouncy, Spring.StiffnessHigh)
    DesignStyle.NEOCLASSICAL -> tween<T>(500, easing = FastOutSlowInEasing)
}

/** Renk geçişleri taşma yapmasın diye yaylı değil, süreli kullanılır. */
fun fadeMs(style: DesignStyle): Int = when (style) {
    DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> 120
    DesignStyle.FRUTIGER_AERO -> 260
    DesignStyle.MINIMAL -> 400
    DesignStyle.WINDOWS11 -> 150
    DesignStyle.NEON -> 300
    DesignStyle.SKEUOMORPHISM -> 220
    DesignStyle.NEUMORPHISM -> 160
    DesignStyle.GLASSMORPHISM -> 360
    DesignStyle.Y2K -> 240
    DesignStyle.AURORA -> 520
    DesignStyle.CLAYMORPHISM -> 200
    DesignStyle.DARK -> 150
    DesignStyle.COSMIC -> 420
    DesignStyle.SCIFI_HUD -> 110
    DesignStyle.CYBER_INDUSTRIAL -> 90
    DesignStyle.NEOCLASSICAL -> 500
}

fun pressScale(style: DesignStyle): Float = when (style) {
    DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> 0.97f
    DesignStyle.FRUTIGER_AERO -> 0.90f
    DesignStyle.MINIMAL -> 0.99f
    DesignStyle.WINDOWS11 -> 0.96f
    DesignStyle.NEON -> 0.94f
    DesignStyle.SKEUOMORPHISM -> 0.97f
    DesignStyle.NEUMORPHISM -> 0.985f
    DesignStyle.GLASSMORPHISM -> 0.96f
    DesignStyle.Y2K -> 0.92f
    DesignStyle.AURORA -> 0.98f
    DesignStyle.CLAYMORPHISM -> 0.97f
    DesignStyle.DARK -> 0.98f
    DesignStyle.COSMIC -> 0.96f
    DesignStyle.SCIFI_HUD -> 0.98f
    DesignStyle.CYBER_INDUSTRIAL -> 0.97f
    DesignStyle.NEOCLASSICAL -> 0.99f
}

fun pageTransition(style: DesignStyle): ContentTransform = when (style) {
    DesignStyle.FUTURISTIC, DesignStyle.TERMINAL ->
        (slideInHorizontally(tween(150, easing = LinearEasing)) { it / 3 } + fadeIn(tween(150))) togetherWith
            (slideOutHorizontally(tween(150, easing = LinearEasing)) { -it / 3 } + fadeOut(tween(100)))
    DesignStyle.FRUTIGER_AERO ->
        (scaleIn(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), initialScale = 0.85f) +
            fadeIn(tween(250))) togetherWith
            (scaleOut(tween(200), targetScale = 1.1f) + fadeOut(tween(150)))
    DesignStyle.MINIMAL ->
        fadeIn(tween(450)) togetherWith fadeOut(tween(200))
    DesignStyle.WINDOWS11 ->
        (slideInVertically(tween(220, easing = FluentEase)) { it / 12 } + fadeIn(tween(200))) togetherWith
            fadeOut(tween(100))
    DesignStyle.NEON ->
        (scaleIn(tween(300), initialScale = 0.92f) + fadeIn(tween(300))) togetherWith fadeOut(tween(150))
    // Sayfa çevirme: yeni sayfa sağdan kayar, eskisi hafifçe geri çekilir.
    DesignStyle.SKEUOMORPHISM ->
        (slideInHorizontally(tween(340, easing = FastOutSlowInEasing)) { it / 2 } + fadeIn(tween(260))) togetherWith
            (slideOutHorizontally(tween(340, easing = FastOutSlowInEasing)) { -it / 5 } + fadeOut(tween(200)))
    // Yüzey “basılıp” yeni içerik yükselir.
    DesignStyle.NEUMORPHISM ->
        (scaleIn(tween(200, easing = FastOutSlowInEasing), initialScale = 0.97f) + fadeIn(tween(200))) togetherWith
            (scaleOut(tween(140), targetScale = 1.02f) + fadeOut(tween(140)))
    // Buzlu cam: aşağıdan süzülür, yavaşça netleşir.
    DesignStyle.GLASSMORPHISM ->
        (slideInVertically(tween(420, easing = FastOutSlowInEasing)) { it / 10 } + fadeIn(tween(420))) togetherWith
            (fadeOut(tween(220)) + scaleOut(tween(260), targetScale = 0.98f))
    // Balon gibi: alttan yaylanarak yükselir.
    DesignStyle.Y2K ->
        (slideInVertically(spring(0.5f, Spring.StiffnessLow)) { it / 6 } +
            scaleIn(spring(0.5f, Spring.StiffnessLow), initialScale = 0.9f) + fadeIn(tween(200))) togetherWith
            (fadeOut(tween(120)) + scaleOut(tween(160), targetScale = 1.08f))
    // Ağır, ışık perdesi gibi yavaş kayma.
    DesignStyle.AURORA ->
        (slideInHorizontally(tween(700, easing = FastOutSlowInEasing)) { it / 8 } + fadeIn(tween(700))) togetherWith
            fadeOut(tween(400))
    // Kil: yumuşak yaylı büyüme.
    DesignStyle.CLAYMORPHISM ->
        (scaleIn(spring(0.55f, Spring.StiffnessMediumLow), initialScale = 0.88f) + fadeIn(tween(180))) togetherWith
            (scaleOut(tween(150), targetScale = 0.96f) + fadeOut(tween(150)))
    // Material "fade through".
    DesignStyle.DARK ->
        fadeIn(tween(180, delayMillis = 60)) togetherWith fadeOut(tween(90))
    // Warp: ışık hızına geçer gibi içeri yaklaşıp açılır.
    DesignStyle.COSMIC ->
        (scaleIn(tween(500, easing = FastOutSlowInEasing), initialScale = 1.15f) + fadeIn(tween(500))) togetherWith
            (scaleOut(tween(400), targetScale = 0.9f) + fadeOut(tween(300)))
    // HUD: hızlı tarama, üstten iner.
    DesignStyle.SCIFI_HUD ->
        (slideInVertically(tween(180, easing = LinearEasing)) { it / 10 } + fadeIn(tween(120))) togetherWith
            fadeOut(tween(80))
    // Ağır panjur: yukarıdan sert iner.
    DesignStyle.CYBER_INDUSTRIAL ->
        (slideInVertically(tween(220, easing = FastOutSlowInEasing)) { -it / 3 } + fadeIn(tween(100))) togetherWith
            (slideOutVertically(tween(200)) { it / 3 } + fadeOut(tween(120)))
    // Neoklasik: yavaş, zarif solma.
    DesignStyle.NEOCLASSICAL ->
        fadeIn(tween(550)) togetherWith fadeOut(tween(300))
}

fun buttonShape(style: DesignStyle): Shape = when (style) {
    DesignStyle.TERMINAL -> RectangleShape
    DesignStyle.FUTURISTIC -> CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp)
    DesignStyle.FRUTIGER_AERO -> RoundedCornerShape(10.dp)
    DesignStyle.MINIMAL -> RoundedCornerShape(0.dp)
    DesignStyle.WINDOWS11 -> RoundedCornerShape(4.dp)
    DesignStyle.NEON -> RoundedCornerShape(10.dp)
    DesignStyle.SKEUOMORPHISM -> RoundedCornerShape(8.dp)
    DesignStyle.NEUMORPHISM -> RoundedCornerShape(16.dp)
    DesignStyle.GLASSMORPHISM -> RoundedCornerShape(18.dp)
    DesignStyle.Y2K -> RoundedCornerShape(50)
    DesignStyle.AURORA -> RoundedCornerShape(16.dp)
    DesignStyle.CLAYMORPHISM -> RoundedCornerShape(18.dp)
    DesignStyle.DARK -> RoundedCornerShape(20.dp)
    DesignStyle.COSMIC -> RoundedCornerShape(50)
    DesignStyle.SCIFI_HUD -> RectangleShape
    DesignStyle.CYBER_INDUSTRIAL -> CutCornerShape(5.dp)
    DesignStyle.NEOCLASSICAL -> RoundedCornerShape(2.dp)
}

fun cardShape(style: DesignStyle): Shape = when (style) {
    DesignStyle.TERMINAL -> RectangleShape
    DesignStyle.FUTURISTIC -> CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp)
    DesignStyle.FRUTIGER_AERO -> RoundedCornerShape(14.dp)
    DesignStyle.MINIMAL -> RoundedCornerShape(0.dp)
    DesignStyle.WINDOWS11 -> RoundedCornerShape(8.dp)
    DesignStyle.NEON -> RoundedCornerShape(16.dp)
    DesignStyle.SKEUOMORPHISM -> RoundedCornerShape(10.dp)
    DesignStyle.NEUMORPHISM -> RoundedCornerShape(20.dp)
    DesignStyle.GLASSMORPHISM -> RoundedCornerShape(24.dp)
    DesignStyle.Y2K -> RoundedCornerShape(22.dp)
    DesignStyle.AURORA -> RoundedCornerShape(20.dp)
    DesignStyle.CLAYMORPHISM -> RoundedCornerShape(26.dp)
    DesignStyle.DARK -> RoundedCornerShape(12.dp)
    DesignStyle.COSMIC -> RoundedCornerShape(20.dp)
    DesignStyle.SCIFI_HUD -> RectangleShape
    DesignStyle.CYBER_INDUSTRIAL -> CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp)
    DesignStyle.NEOCLASSICAL -> RoundedCornerShape(2.dp)
}

fun checkShape(style: DesignStyle): Shape = when (style) {
    DesignStyle.TERMINAL -> RectangleShape
    DesignStyle.FUTURISTIC -> CutCornerShape(5.dp)
    DesignStyle.FRUTIGER_AERO -> RoundedCornerShape(6.dp)
    DesignStyle.MINIMAL -> RoundedCornerShape(0.dp)
    DesignStyle.WINDOWS11 -> RoundedCornerShape(4.dp)
    DesignStyle.NEON -> CircleShape
    DesignStyle.SKEUOMORPHISM -> RoundedCornerShape(4.dp)
    DesignStyle.NEUMORPHISM -> RoundedCornerShape(8.dp)
    DesignStyle.GLASSMORPHISM -> RoundedCornerShape(9.dp)
    DesignStyle.Y2K -> CircleShape
    DesignStyle.AURORA -> CircleShape
    DesignStyle.CLAYMORPHISM -> CircleShape
    DesignStyle.DARK -> RoundedCornerShape(6.dp)
    DesignStyle.COSMIC -> CircleShape
    DesignStyle.SCIFI_HUD -> RectangleShape
    DesignStyle.CYBER_INDUSTRIAL -> RectangleShape
    DesignStyle.NEOCLASSICAL -> CircleShape
}

fun typographyFor(style: DesignStyle): Typography {
    val family = when (style) {
        DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> FontFamily.Monospace
        DesignStyle.FRUTIGER_AERO -> FontFamily.SansSerif
        DesignStyle.MINIMAL -> FontFamily.Serif
        DesignStyle.WINDOWS11 -> FontFamily.Default
        DesignStyle.NEON -> FontFamily.Monospace
        DesignStyle.SKEUOMORPHISM -> FontFamily.Serif
        DesignStyle.NEUMORPHISM -> FontFamily.SansSerif
        DesignStyle.GLASSMORPHISM -> FontFamily.SansSerif
        DesignStyle.Y2K -> FontFamily.SansSerif
        DesignStyle.AURORA -> FontFamily.SansSerif
        DesignStyle.CLAYMORPHISM -> FontFamily.SansSerif
        DesignStyle.DARK -> FontFamily.Default
        DesignStyle.COSMIC -> FontFamily.SansSerif
        DesignStyle.SCIFI_HUD -> FontFamily.Monospace
        DesignStyle.CYBER_INDUSTRIAL -> FontFamily.Monospace
        DesignStyle.NEOCLASSICAL -> FontFamily.Serif
    }
    val b = Typography()
    fun TextStyle.f() = copy(fontFamily = family)
    return b.copy(
        bodyLarge = b.bodyLarge.f(),
        bodyMedium = b.bodyMedium.f(),
        bodySmall = b.bodySmall.f(),
        titleLarge = b.titleLarge.f(),
        titleMedium = b.titleMedium.f(),
        labelLarge = b.labelLarge.f()
    )
}
