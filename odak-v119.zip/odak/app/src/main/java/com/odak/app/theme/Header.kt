package com.odak.app.theme

import androidx.compose.foundation.layout.padding
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.material3.LocalTextStyle
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

/** Sayfa başlığı. Her tasarımda ayrı yazım: // BÜYÜK, parlak, ince küçük harf, kalın, neon. */
@Composable
fun ThemedHeader(title: String, modifier: Modifier = Modifier) {
    val d = LocalDesign.current
    val t = d.tokens
    val m = modifier.padding(vertical = 8.dp)
    val base = LocalTextStyle.current
    when (d.style) {
        DesignStyle.TERMINAL -> Text(
            "> " + title.lowercase(Locale.getDefault()) + "_",
            color = t.primary, fontSize = 20.sp, modifier = m,
            style = base.copy(shadow = Shadow(t.primary, blurRadius = 8f))
        )
        DesignStyle.FUTURISTIC -> Text(
            "// " + title.uppercase(Locale.getDefault()),
            color = t.primary, fontSize = 20.sp, letterSpacing = 2.sp, modifier = m,
            style = base.copy(shadow = Shadow(t.primary, blurRadius = 14f))
        )
        DesignStyle.FRUTIGER_AERO -> Text(
            title, color = t.text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = m,
            style = base.copy(shadow = Shadow(Color.White, blurRadius = 8f))
        )
        DesignStyle.MINIMAL -> Text(
            title.lowercase(Locale.getDefault()),
            color = t.text, fontSize = 26.sp, fontWeight = FontWeight.Light, letterSpacing = 1.sp, modifier = m
        )
        DesignStyle.WINDOWS11 -> Text(
            title, color = t.text, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, modifier = m
        )
        DesignStyle.NEON -> Text(
            title.uppercase(Locale.getDefault()),
            color = t.accent, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, modifier = m,
            style = base.copy(shadow = Shadow(t.accent, blurRadius = 20f))
        )
        // Tipografik baskı (letterpress): açık renk alt gölge ile yüzeye basılmış gibi.
        DesignStyle.SKEUOMORPHISM -> Text(
            title, color = t.text, fontSize = 27.sp, fontWeight = FontWeight.Bold, modifier = m,
            style = base.copy(shadow = Shadow(Color(0xCCFFFFFF), Offset(0f, 2f), 0f))
        )
        // Kabartma yazı: sol-üst ışık gölgesi.
        DesignStyle.NEUMORPHISM -> Text(
            title, color = t.text, fontSize = 27.sp, fontWeight = FontWeight.SemiBold, modifier = m,
            style = base.copy(shadow = Shadow(Color.White, Offset(-2f, -2f), 3f))
        )
        // İnce, geniş aralıklı yazı; hafif gölgeyle cam üstünde okunur.
        DesignStyle.GLASSMORPHISM -> Text(
            title, color = t.text, fontSize = 28.sp, fontWeight = FontWeight.Light, letterSpacing = 1.sp, modifier = m,
            style = base.copy(shadow = Shadow(Color(0x66000000), Offset(0f, 3f), 12f))
        )
        // Hologram degradeli, tekno aralıklı büyük harf (piksel yazı hissi için tek aralıklı).
        DesignStyle.Y2K -> Text(
            title.uppercase(Locale.getDefault()),
            fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, modifier = m,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            style = base.copy(
                brush = Brush.horizontalGradient(listOf(Color(0xFF1F46D6), Y2kPink, Color(0xFF14A8A0))),
                shadow = Shadow(Color.White, Offset(0f, 2f), 0f)
            )
        )
        // Işık gibi: nane→mor degrade metin.
        DesignStyle.AURORA -> Text(
            title, fontSize = 27.sp, fontWeight = FontWeight.Light, letterSpacing = 1.sp, modifier = m,
            style = base.copy(brush = Brush.horizontalGradient(listOf(AuroraMint, AuroraViolet)))
        )
        DesignStyle.CLAYMORPHISM -> Text(
            title, color = t.text, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, modifier = m
        )
        DesignStyle.DARK -> Text(
            title, color = t.text, fontSize = 24.sp, fontWeight = FontWeight.Medium, modifier = m
        )
        // Yıldız ışığı: geniş aralıklı, lavanta parıltılı.
        DesignStyle.COSMIC -> Text(
            title.uppercase(Locale.getDefault()),
            color = t.text, fontSize = 22.sp, fontWeight = FontWeight.Light, letterSpacing = 4.sp, modifier = m,
            style = base.copy(shadow = Shadow(CosmicLavender, blurRadius = 22f))
        )
        // Telemetri satırı: amber, tek aralıklı.
        DesignStyle.SCIFI_HUD -> Text(
            "▌" + title.uppercase(Locale.getDefault()) + " //",
            color = HudAmber, fontSize = 20.sp, letterSpacing = 2.sp, modifier = m,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            style = base.copy(shadow = Shadow(HudAmber.copy(alpha = 0.6f), blurRadius = 10f))
        )
        // Stencil: ağır, büyük harf, altında uyarı şeridi.
        DesignStyle.CYBER_INDUSTRIAL -> Text(
            title.uppercase(Locale.getDefault()),
            color = t.text, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            modifier = m.drawBehind {
                clipRect { hazardStripes(Offset(0f, size.height - 4.dp.toPx()), Size(size.width, 4.dp.toPx()), 6.dp.toPx()) }
            }.padding(bottom = 6.dp)
        )
        // Serif, harf aralıklı; altın ince çizgi.
        DesignStyle.NEOCLASSICAL -> Text(
            title.uppercase(Locale.getDefault()),
            color = t.text, fontSize = 22.sp, fontWeight = FontWeight.Normal, letterSpacing = 5.sp,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
            modifier = m.drawBehind {
                drawLine(NeoGold, Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx())
                drawLine(NeoGold.copy(alpha = 0.5f), Offset(0f, size.height - 3.dp.toPx()), Offset(size.width, size.height - 3.dp.toPx()), 0.6.dp.toPx())
            }.padding(bottom = 6.dp)
        )
    }
}
