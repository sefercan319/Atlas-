package com.odak.app.plan

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.odak.app.notify.Reminders
import com.odak.app.theme.LocalDesign
import java.time.LocalDate

@Composable
fun PlanScreen() {
    val context = LocalContext.current
    val style = LocalDesign.current.style
    var all by remember { mutableStateOf(PlanStore.load(context)) }
    var period by remember { mutableStateOf(Period.DAY) }
    var anchor by remember { mutableStateOf(LocalDate.now()) }
    var editing by remember { mutableStateOf<PlanItem?>(null) }

    fun save(list: List<PlanItem>) {
        all = list
        PlanStore.save(context, list)
        com.odak.app.notify.PlanWidget.refresh(context)
    }

    val vm = PlanVm(
        items = all,
        period = period,
        anchor = anchor,
        today = LocalDate.now(),
        setPeriod = { period = it },
        setAnchor = { anchor = it },
        step = { dir ->
            anchor = when (period) {
                Period.DAY -> anchor.plusDays(dir.toLong())
                Period.WEEK -> anchor.plusWeeks(dir.toLong())
                Period.MONTH -> anchor.plusMonths(dir.toLong())
            }
        },
        add = { title, min, dur, rep ->
            val n = when (rep) { 1 -> 14; 2 -> 8; else -> 1 }
            val step = if (rep == 2) 7L else 1L
            val created = (0 until n).map {
                PlanItem(title = title, date = anchor.plusDays(it * step), startMin = min, durMin = dur)
            }
            created.forEach { Reminders.schedule(context, it) }
            save(all + created)
        },
        toggle = { p, checked ->
            val upd = p.copy(done = checked)
            if (checked) Reminders.cancel(context, p) else Reminders.schedule(context, upd)
            save(all.map { if (it.id == p.id) upd else it })
        },
        remove = { p ->
            Reminders.cancel(context, p)
            save(all.filter { it.id != p.id })
        },
        startEdit = { editing = it },
        copyDay = {
            val src = all.filter { it.date == anchor }
            if (src.isNotEmpty()) {
                val copies = src.map { it.copy(id = java.util.UUID.randomUUID().toString(), date = anchor.plusDays(1), done = false) }
                copies.forEach { Reminders.schedule(context, it) }
                save(all + copies)
                anchor = anchor.plusDays(1)
            }
        }
    )

    editing?.let { old ->
        EditPlanDialog(old, { editing = null }) { upd ->
            Reminders.cancel(context, old)
            Reminders.schedule(context, upd)
            save(all.map { if (it.id == upd.id) upd else it })
            editing = null
        }
    }

    UnifiedPlan(vm, style)
}
