package com.odak.app.docs

/** OLE/CFB (eski Office, WPS, Publisher) okuyucu ve doc/xls/ppt/pub metin çıkarıcıları. Android'e bağımlı değil. */
object OleDoc {
    private val MAGIC = byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte(), 0xA1.toByte(), 0xB1.toByte(), 0x1A, 0xE1.toByte())
    private const val MAX_TOTAL = 256L * 1024 * 1024
    private val cp1252 = charset("windows-1252")

    fun isOle(b: ByteArray): Boolean = b.size >= 8 && (0 until 8).all { b[it] == MAGIC[it] }

    private fun u8(b: ByteArray, o: Int): Int = if (o in b.indices) b[o].toInt() and 0xFF else 0
    private fun u16(b: ByteArray, o: Int): Int = u8(b, o) or (u8(b, o + 1) shl 8)
    private fun u32(b: ByteArray, o: Int): Long = (u16(b, o).toLong()) or (u16(b, o + 2).toLong() shl 16)
    private fun i32(b: ByteArray, o: Int): Int = u32(b, o).toInt()

    // ---------------- CFB ----------------
    /** Tüm akışlar: "Ad" ya da "Klasör/Ad" -> içerik. Bozuksa null. */
    fun streams(b: ByteArray): Map<String, ByteArray>? {
        if (!isOle(b) || b.size < 512) return null
        return try { readStreams(b) } catch (e: Exception) { null }
    }

    private fun readStreams(b: ByteArray): Map<String, ByteArray> {
        val shift = u16(b, 0x1E)
        val miniShift = u16(b, 0x20)
        if (shift !in 7..16 || miniShift !in 4..12) return emptyMap()
        val secSize = 1 shl shift
        val miniSize = 1 shl miniShift
        val nFat = i32(b, 0x2C)
        val firstDir = i32(b, 0x30)
        val cutoff = u32(b, 0x38).toInt().let { if (it <= 0) 4096 else it }
        val firstMiniFat = i32(b, 0x3C)
        val firstDifat = i32(b, 0x44)
        val nDifat = i32(b, 0x48)
        fun secOff(id: Int): Long = (id.toLong() + 1) shl shift
        fun secOk(id: Int): Boolean = id >= 0 && secOff(id) + secSize <= b.size

        // FAT sektör listesi
        val fatSecs = ArrayList<Int>()
        for (i in 0 until 109) { val id = i32(b, 0x4C + i * 4); if (id >= 0 && fatSecs.size < nFat) fatSecs.add(id) }
        var d = firstDifat
        var guard = 0
        while (d >= 0 && guard++ < nDifat.coerceAtMost(2000) && secOk(d)) {
            val base = secOff(d).toInt()
            for (i in 0 until secSize / 4 - 1) { val id = i32(b, base + i * 4); if (id >= 0 && fatSecs.size < nFat) fatSecs.add(id) }
            d = i32(b, base + secSize - 4)
        }
        val fat = IntArray(fatSecs.size * (secSize / 4))
        var fi = 0
        for (s in fatSecs) {
            if (!secOk(s)) { fi += secSize / 4; continue }
            val base = secOff(s).toInt()
            for (i in 0 until secSize / 4) fat[fi++] = i32(b, base + i * 4)
        }
        fun chain(start: Int, limit: Long = MAX_TOTAL): ByteArray {
            val bo = java.io.ByteArrayOutputStream()
            var s = start
            var n = 0
            while (s >= 0 && s < fat.size && secOk(s) && n++ < 1_000_000) {
                bo.write(b, secOff(s).toInt(), secSize)
                if (bo.size() > limit) throw IllegalStateException("büyük")
                s = fat[s]
            }
            return bo.toByteArray()
        }

        val dir = chain(firstDir)
        class Ent(val name: String, val type: Int, val left: Int, val right: Int, val child: Int, val start: Int, val size: Long)
        val ents = ArrayList<Ent>()
        var p = 0
        while (p + 128 <= dir.size) {
            val nameLen = u16(dir, p + 0x40).coerceIn(0, 64)
            val name = if (nameLen >= 2) String(dir, p, nameLen - 2, Charsets.UTF_16LE) else ""
            ents.add(Ent(name, u8(dir, p + 0x42), i32(dir, p + 0x44), i32(dir, p + 0x48), i32(dir, p + 0x4C), i32(dir, p + 0x74), u32(dir, p + 0x78)))
            p += 128
        }
        if (ents.isEmpty()) return emptyMap()
        val root = ents[0]

        val miniFat: IntArray by lazy {
            val raw = if (firstMiniFat >= 0) chain(firstMiniFat) else ByteArray(0)
            IntArray(raw.size / 4) { i32(raw, it * 4) }
        }
        val miniStream: ByteArray by lazy { chain(root.start).let { if (it.size > root.size) it.copyOf(root.size.toInt()) else it } }
        fun miniChain(start: Int, size: Int): ByteArray {
            val bo = java.io.ByteArrayOutputStream()
            var s = start
            var n = 0
            while (s >= 0 && s < miniFat.size && n++ < 1_000_000 && bo.size() < size) {
                val off = s * miniSize
                if (off + miniSize > miniStream.size) break
                bo.write(miniStream, off, miniSize)
                s = miniFat[s]
            }
            val r = bo.toByteArray()
            return if (r.size > size) r.copyOf(size) else r
        }

        val out = LinkedHashMap<String, ByteArray>()
        var total = 0L
        val seen = HashSet<Int>()
        fun walk(i: Int, prefix: String) {
            if (i < 0 || i >= ents.size || !seen.add(i)) return
            val e = ents[i]
            walk(e.left, prefix)
            val path = if (prefix.isEmpty()) e.name else "$prefix/${e.name}"
            if (e.type == 2) {
                val sz = e.size
                if (sz in 0..MAX_TOTAL && total + sz <= MAX_TOTAL) {
                    val data = if (sz < cutoff) miniChain(e.start, sz.toInt()) else chain(e.start, sz + secSize).let { if (it.size > sz) it.copyOf(sz.toInt()) else it }
                    total += data.size
                    out[path] = data
                }
            } else if (e.type == 1) walk(e.child, path)
            walk(e.right, prefix)
        }
        walk(root.child, "")
        return out
    }

    private fun find(m: Map<String, ByteArray>, vararg names: String): ByteArray? {
        for (n in names) m.entries.firstOrNull { it.key.equals(n, ignoreCase = true) }?.let { return it.value }
        return null
    }

    // ---------------- Üst düzey ----------------
    /** OLE içindeki biçimi akış adlarından belirler ve metni çıkarır. */
    fun parse(b: ByteArray): Doc? {
        val s = streams(b) ?: return null
        find(s, "WordDocument")?.let { w ->
            val paras = try { docParas(w, s) } catch (e: Exception) { emptyList() }
            if (paras.isNotEmpty()) return Doc(DocKind.LEGACY, listOf(DocPage("", paras)))
            return Doc(DocKind.LEGACY, rough(w), approx = true)
        }
        find(s, "Workbook", "Book")?.let { wb ->
            val pages = try { xlsPages(wb) } catch (e: Exception) { emptyList() }
            if (pages.isNotEmpty()) return Doc(DocKind.LEGACY, pages)
        }
        find(s, "PowerPoint Document")?.let { pp ->
            val pages = try { pptPages(pp) } catch (e: Exception) { emptyList() }
            if (pages.isNotEmpty()) return Doc(DocKind.LEGACY, pages)
        }
        // Publisher: metin "Quill/QuillSub/CONTENTS" ya da "Contents" akışında
        val pub = find(s, "Quill/QuillSub/CONTENTS", "Contents")
        if (pub != null) return Doc(DocKind.LEGACY, rough(pub), approx = true)
        // Bilinmeyen OLE: bilgi akışlarını atlayıp kalanda kaba tarama
        val skip = setOf("\u0005SummaryInformation", "\u0005DocumentSummaryInformation", "\u0001CompObj", "\u0001Ole")
        val rest = s.filter { it.key !in skip && !it.key.startsWith("\u0005") }.values
        val all = java.io.ByteArrayOutputStream().also { o -> rest.forEach { o.write(it) } }.toByteArray()
        return Doc(DocKind.LEGACY, rough(all), approx = true)
    }

    private fun rough(b: ByteArray): List<DocPage> {
        val p = DocParse.roughText(b)
        return if (p.isEmpty()) emptyList() else listOf(DocPage("", p))
    }

    // ---------------- DOC (Word 97-2003 / WPS) ----------------
    fun docParas(w: ByteArray, s: Map<String, ByteArray>): List<String> {
        if (u16(w, 0) != 0xA5EC) return emptyList()
        val flags = u16(w, 0x0A)
        val tbl = find(s, if (flags and 0x0200 != 0) "1Table" else "0Table") ?: return emptyList()
        val ccpText = u32(w, 0x4C).toInt().coerceAtLeast(0)
        val fcClx = u32(w, 0x1A2).toInt()
        val lcbClx = u32(w, 0x1A6).toInt()
        if (fcClx < 0 || lcbClx <= 0 || fcClx + lcbClx > tbl.size) return emptyList()
        var pos = fcClx
        val end = fcClx + lcbClx
        val sb = StringBuilder()
        while (pos < end) {
            val t = u8(tbl, pos)
            if (t == 1) { pos += 3 + u16(tbl, pos + 1); continue }
            if (t != 2) break
            val lcb = u32(tbl, pos + 1).toInt()
            val plc = pos + 5
            val n = (lcb - 4) / 12
            if (n <= 0 || n > 200_000) break
            for (i in 0 until n) {
                val cpStart = u32(tbl, plc + i * 4).toInt()
                val cpEnd = u32(tbl, plc + (i + 1) * 4).toInt()
                val len = cpEnd - cpStart
                if (len <= 0 || cpStart >= ccpText) continue
                val take = minOf(len, ccpText - cpStart)
                val fc = u32(tbl, plc + (n + 1) * 4 + i * 8 + 2)
                val compressed = fc and 0x40000000L != 0L
                val real = (fc and 0x3FFFFFFFL).toInt()
                if (compressed) {
                    val off = real / 2
                    if (off >= 0 && off + take <= w.size) sb.append(String(w, off, take, cp1252))
                } else {
                    if (real >= 0 && real + take * 2 <= w.size) sb.append(String(w, real, take * 2, Charsets.UTF_16LE))
                }
            }
            break
        }
        return docText(sb.toString())
    }

    /** Word metnini paragraflara çevirir: alan kodları atılır, hücre işaretleri │ olur. */
    fun docText(raw: String): List<String> {
        val o = StringBuilder()
        val mode = ArrayList<Boolean>() // true = alan kodu (atla)
        for (c in raw) {
            val code = c.code
            when {
                code == 0x13 -> mode.add(true)
                code == 0x14 -> if (mode.isNotEmpty()) mode[mode.size - 1] = false
                code == 0x15 -> if (mode.isNotEmpty()) mode.removeAt(mode.size - 1)
                mode.isNotEmpty() && mode.last() -> { }
                c == '\r' -> o.append('\n')
                code == 0x07 -> o.append(" │ ")
                code == 0x0B || code == 0x0C -> o.append('\n')
                c == '\t' -> o.append('\t')
                code < 0x20 -> { }
                else -> o.append(c)
            }
        }
        return o.toString().split('\n').map { it.trim().removeSuffix("│").trim() }.filter { it.isNotEmpty() }.take(20000)
    }

    // ---------------- PPT ----------------
    fun pptPages(b: ByteArray): List<DocPage> {
        val slides = ArrayList<List<String>>()
        fun walk(start: Int, end: Int, cur: MutableList<String>?) {
            var p = start
            while (p + 8 <= end) {
                val ver = u16(b, p) and 0x0F
                val type = u16(b, p + 2)
                val len = u32(b, p + 4).toInt()
                val body = p + 8
                if (len < 0 || body + len > end) break
                if (ver == 0x0F) {
                    if (type == 0x03EE) { val l = ArrayList<String>(); walk(body, body + len, l); if (l.isNotEmpty()) slides.add(l) }
                    else if (type == 0x03F8 || type == 0x03F0) { /* ana slayt / notlar atlanır */ }
                    else walk(body, body + len, cur)
                } else if (cur != null && (type == 0x0FA0 || type == 0x0FA8)) {
                    val text = if (type == 0x0FA0) String(b, body, len and 1.inv(), Charsets.UTF_16LE) else String(b, body, len, Charsets.ISO_8859_1)
                    text.split('\r', '\u000B', '\n').map { it.trim() }.filter { it.isNotEmpty() }.forEach { cur.add(it) }
                }
                p = body + len
            }
        }
        walk(0, b.size, null)
        return slides.mapIndexed { i, l -> DocPage((i + 1).toString(), l) }
    }

    // ---------------- XLS (BIFF8 / WPS ET) ----------------
    private class Rec(val id: Int, val data: ByteArray)

    private fun records(b: ByteArray): List<Rec> {
        val out = ArrayList<Rec>()
        var p = 0
        while (p + 4 <= b.size) {
            val id = u16(b, p)
            val len = u16(b, p + 2)
            if (p + 4 + len > b.size) break
            out.add(Rec(id, b.copyOfRange(p + 4, p + 4 + len)))
            p += 4 + len
        }
        return out
    }

    /** SST dizgileri; CONTINUE sınırlarında karakter bayrağı yeniden okunur. */
    private fun readSst(chunks: List<ByteArray>): List<String> {
        var ci = 0
        var off = 8 // total + unique
        val out = ArrayList<String>()
        fun cur(): ByteArray? = chunks.getOrNull(ci)
        fun avail(): Boolean { while (ci < chunks.size && off >= chunks[ci].size) { ci++; off = 0 }; return ci < chunks.size }
        fun rd8(): Int { if (!avail()) return 0; return chunks[ci][off++].toInt() and 0xFF }
        fun rd16(): Int = rd8() or (rd8() shl 8)
        fun rd32(): Int = rd16() or (rd16() shl 16)
        fun skip(n: Int) { var k = n; while (k > 0 && avail()) { val t = minOf(k, chunks[ci].size - off); off += t; k -= t } }
        while (avail() && out.size < 500_000) {
            val cch = rd16()
            val flags = rd8()
            val runs = if (flags and 0x08 != 0) rd16() else 0
            val ext = if (flags and 0x04 != 0) rd32() else 0
            var wide = flags and 0x01 != 0
            val sb = StringBuilder()
            var left = cch
            while (left > 0) {
                if (off >= (cur()?.size ?: 0)) {
                    if (!avail()) break
                    wide = (rd8() and 0x01) != 0   // CONTINUE başında yeni bayrak baytı
                    continue
                }
                if (wide) { if (off + 1 >= chunks[ci].size) { off++; continue }; sb.append((u16(chunks[ci], off)).toChar()); off += 2 }
                else { sb.append((chunks[ci][off].toInt() and 0xFF).toChar().let { String(byteArrayOf(it.code.toByte()), cp1252)[0] }); off++ }
                left--
            }
            skip(runs * 4)
            skip(ext)
            out.add(sb.toString())
        }
        return out
    }

    private fun rkValue(v: Int): Double {
        val d = if (v and 2 != 0) (v shr 2).toDouble() else java.lang.Double.longBitsToDouble((v.toLong() and 0xFFFFFFFCL) shl 32)
        return if (v and 1 != 0) d / 100.0 else d
    }

    private val numFmt = java.text.DecimalFormat("0.##########", java.text.DecimalFormatSymbols(java.util.Locale.ROOT))
    fun fmtNum(d: Double): String =
        if (d.isNaN() || d.isInfinite()) "" else if (d == Math.rint(d) && Math.abs(d) < 1e15) d.toLong().toString() else numFmt.format(d)

    fun xlsPages(b: ByteArray): List<DocPage> {
        val recs = records(b)
        var sst: List<String> = emptyList()
        val names = ArrayList<Pair<String, Int>>() // ad, tür
        // SST + CONTINUE
        run {
            var i = 0
            while (i < recs.size) {
                if (recs[i].id == 0x00FC) {
                    val chunks = arrayListOf(recs[i].data)
                    var j = i + 1
                    while (j < recs.size && recs[j].id == 0x003C) { chunks.add(recs[j].data); j++ }
                    sst = readSst(chunks)
                    i = j
                } else i++
            }
        }
        for (r in recs) if (r.id == 0x0085) {
            val d = r.data
            val type = u8(d, 5)
            val cch = u8(d, 6)
            val wide = u8(d, 7) and 1 != 0
            val name = if (wide) String(d, 8, minOf(cch * 2, d.size - 8).coerceAtLeast(0), Charsets.UTF_16LE) else String(d, 8, minOf(cch, d.size - 8).coerceAtLeast(0), cp1252)
            names.add(name to type)
        }
        val pages = ArrayList<DocPage>()
        var sheet = -1
        var rows = java.util.TreeMap<Int, java.util.TreeMap<Int, String>>()
        var inSheet = false
        var maxCol = 0
        var lastFormula: Pair<Int, Int>? = null
        var depth = 0
        fun put(r: Int, c: Int, v: String) {
            if (v.isEmpty() || r !in 0 until 3000 || c !in 0 until 60) return
            rows.getOrPut(r) { java.util.TreeMap() }[c] = v
            if (c + 1 > maxCol) maxCol = c + 1
        }
        fun finish() {
            if (!inSheet) return
            val nm = names.getOrNull(sheet)
            if (nm != null && nm.second == 0 && rows.isNotEmpty()) {
                val w = maxCol
                pages.add(DocPage(nm.first, emptyList(), rows.values.map { r -> List(w) { c -> r[c] ?: "" } }))
            }
            rows = java.util.TreeMap(); maxCol = 0; inSheet = false
        }
        for (r in recs) {
            val d = r.data
            when (r.id) {
                0x0809 -> { // BOF (gömülü grafik BOF'ları iç içe sayılır)
                    val type = u16(d, 2)
                    if (depth == 0 && type != 0x0005) { sheet++; inSheet = true }
                    depth++
                }
                0x000A -> { depth = maxOf(0, depth - 1); if (depth == 0 && inSheet) finish() }
                0x00FD -> if (inSheet) put(u16(d, 0), u16(d, 2), sst.getOrElse(i32(d, 6)) { "" })
                0x0203 -> if (inSheet) put(u16(d, 0), u16(d, 2), fmtNum(java.lang.Double.longBitsToDouble(u32(d, 6) or (u32(d, 10) shl 32))))
                0x027E -> if (inSheet) put(u16(d, 0), u16(d, 2), fmtNum(rkValue(i32(d, 6))))
                0x00BD -> if (inSheet) {
                    val row = u16(d, 0)
                    val first = u16(d, 2)
                    val n = (d.size - 6) / 6
                    for (k in 0 until n) put(row, first + k, fmtNum(rkValue(i32(d, 4 + k * 6 + 2))))
                }
                0x0204 -> if (inSheet) {
                    val cch = u16(d, 6)
                    val wide = u8(d, 8) and 1 != 0
                    val t = if (wide) String(d, 9, minOf(cch * 2, d.size - 9).coerceAtLeast(0), Charsets.UTF_16LE) else String(d, 9, minOf(cch, d.size - 9).coerceAtLeast(0), cp1252)
                    put(u16(d, 0), u16(d, 2), t)
                }
                0x0205 -> if (inSheet && u8(d, 7) == 0) put(u16(d, 0), u16(d, 2), if (u8(d, 6) != 0) "TRUE" else "FALSE")
                0x0006 -> if (inSheet) {
                    val row = u16(d, 0); val col = u16(d, 2)
                    if (u8(d, 12) == 0xFF && u8(d, 13) == 0xFF) {
                        // sonuç türü: 0 dizgi (sonraki STRING kaydı), 1 mantık, 2 hata, 3 boş
                        if (u8(d, 6) == 1) { lastFormula = null; put(row, col, if (u8(d, 8) != 0) "TRUE" else "FALSE") }
                        else lastFormula = if (u8(d, 6) == 0) row to col else null
                    }
                    else { lastFormula = null; put(row, col, fmtNum(java.lang.Double.longBitsToDouble(u32(d, 6) or (u32(d, 10) shl 32)))) }
                }
                0x0207 -> if (inSheet) {
                    val lf = lastFormula
                    if (lf != null) {
                        val cch = u16(d, 0)
                        val wide = u8(d, 2) and 1 != 0
                        val t = if (wide) String(d, 3, minOf(cch * 2, d.size - 3).coerceAtLeast(0), Charsets.UTF_16LE) else String(d, 3, minOf(cch, d.size - 3).coerceAtLeast(0), cp1252)
                        put(lf.first, lf.second, t)
                        lastFormula = null
                    }
                }
            }
        }
        finish()
        return pages
    }
}
