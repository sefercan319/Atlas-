package com.odak.app.docs

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.caverock.androidsvg.SVG

/** EMF/WMF çizim komutlarını Android Canvas'a çizer (beyaz zemin). */
object MetaRender {
    fun render(m: Metafile.Meta, maxSide: Int): Bitmap? {
        if (m.w <= 0.0 || m.h <= 0.0) return null
        val sc = maxSide.toDouble() / maxOf(m.w, m.h)
        val bw = (m.w * sc).toInt().coerceIn(1, maxSide); val bh = (m.h * sc).toInt().coerceIn(1, maxSide)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawColor(Color.WHITE)
        cv.scale(sc.toFloat(), sc.toFloat())
        cv.translate((-m.left).toFloat(), (-m.top).toFloat())
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND }
        val txt = Paint(Paint.ANTI_ALIAS_FLAG)
        val bp = Paint(Paint.FILTER_BITMAP_FLAG)
        var depth = 0
        val clipPaint = Paint()
        fun pathOf(subs: List<Metafile.Sub>, eo: Boolean): Path {
            val p = Path()
            p.fillType = if (eo) Path.FillType.EVEN_ODD else Path.FillType.WINDING
            for (s in subs) {
                if (s.pts.size < 4) continue
                p.moveTo(s.pts[0].toFloat(), s.pts[1].toFloat())
                var i = 2
                while (i + 1 < s.pts.size) { p.lineTo(s.pts[i].toFloat(), s.pts[i + 1].toFloat()); i += 2 }
                if (s.closed) p.close()
            }
            return p
        }
        fun shader(sh: Metafile.Shade?): android.graphics.Shader? = when (sh) {
            is Metafile.Tile -> {
                val tb = Bitmap.createBitmap(sh.argb, sh.w, sh.h, Bitmap.Config.ARGB_8888)
                android.graphics.BitmapShader(tb, android.graphics.Shader.TileMode.REPEAT, android.graphics.Shader.TileMode.REPEAT)
            }
            is Metafile.Linear -> if (sh.colors.size >= 2 && (sh.x0 != sh.x1 || sh.y0 != sh.y1))
                android.graphics.LinearGradient(sh.x0.toFloat(), sh.y0.toFloat(), sh.x1.toFloat(), sh.y1.toFloat(), sh.colors, FloatArray(sh.pos.size) { sh.pos[it].toFloat() }, android.graphics.Shader.TileMode.CLAMP) else null
            null -> null
        }
        fun dashOf(style: Int, w: Float): android.graphics.PathEffect? = when (style) {
            1 -> android.graphics.DashPathEffect(floatArrayOf(w * 6, w * 2), 0f)
            2 -> android.graphics.DashPathEffect(floatArrayOf(w, w * 2), 0f)
            3 -> android.graphics.DashPathEffect(floatArrayOf(w * 6, w * 2, w, w * 2), 0f)
            4 -> android.graphics.DashPathEffect(floatArrayOf(w * 6, w * 2, w, w * 2, w, w * 2), 0f)
            else -> null
        }
        for (op in m.ops) when (op) {
            is Metafile.Save -> { cv.save(); depth++ }
            is Metafile.Restore -> if (depth > 0) { cv.restore(); depth-- }
            is Metafile.Clip -> {
                val cp = pathOf(op.subs, op.evenOdd)
                if (op.exclude) cv.clipOutPath(cp) else cv.clipPath(cp)
            }
            is Metafile.Img -> {
                val b = android.graphics.BitmapFactory.decodeByteArray(op.data, 0, op.data.size)
                if (b != null) { cv.drawBitmap(b, null, RectF(op.x.toFloat(), op.y.toFloat(), (op.x + op.w).toFloat(), (op.y + op.h).toFloat()), bp); b.recycle() }
            }
            is Metafile.Poly -> {
                val p = Path()
                p.fillType = if (op.evenOdd) Path.FillType.EVEN_ODD else Path.FillType.WINDING
                for (s in op.subs) {
                    if (s.pts.size < 4) continue
                    p.moveTo(s.pts[0].toFloat(), s.pts[1].toFloat())
                    var i = 2
                    while (i + 1 < s.pts.size) { p.lineTo(s.pts[i].toFloat(), s.pts[i + 1].toFloat()); i += 2 }
                    if (s.closed) p.close()
                }
                op.fill?.let {
                    fill.color = it
                    fill.shader = try { shader(op.shade) } catch (e: Exception) { null }
                    cv.drawPath(p, fill)
                    fill.shader = null
                }
                op.stroke?.let { line.color = it; line.strokeWidth = op.sw.toFloat(); line.pathEffect = dashOf(op.dash, op.sw.toFloat()); cv.drawPath(p, line) }
            }
            is Metafile.Text -> {
                txt.color = op.color
                txt.textSize = op.size.toFloat()
                txt.typeface = Typeface.create(Typeface.SANS_SERIF, if (op.bold && op.italic) Typeface.BOLD_ITALIC else if (op.bold) Typeface.BOLD else if (op.italic) Typeface.ITALIC else Typeface.NORMAL)
                val w = txt.measureText(op.s)
                var x = op.x.toFloat()
                if (op.align and 6 == 6) x -= w / 2 else if (op.align and 2 != 0) x -= w
                var y = op.y.toFloat()
                if (op.align and 24 == 0) y += (op.size * 0.8).toFloat() else if (op.align and 24 == 8) y -= (op.size * 0.2).toFloat()
                cv.save()
                if (op.angle != 0.0) cv.rotate((-op.angle).toFloat(), op.x.toFloat(), op.y.toFloat())
                cv.drawText(op.s, x, y, txt)
                cv.restore()
            }
            is Metafile.Bmp -> {
                val b = Bitmap.createBitmap(op.argb, op.pw, op.ph, Bitmap.Config.ARGB_8888)
                cv.drawBitmap(b, null, RectF(op.x.toFloat(), op.y.toFloat(), (op.x + op.w).toFloat(), (op.y + op.h).toFloat()), bp)
                b.recycle()
            }
        }
        return bmp
    }
}

/** SVG'yi AndroidSVG ile çizer. Harici kaynaklar yüklenmez. */
object SvgRender {
    fun render(bytes: ByteArray, maxSide: Int): Bitmap? {
        val data = if (bytes.size > 2 && bytes[0] == 0x1F.toByte() && bytes[1] == 0x8B.toByte()) java.util.zip.GZIPInputStream(bytes.inputStream()).use { it.readBytes() } else bytes
        val svg = SVG.getFromInputStream(data.inputStream())
        var w = svg.documentWidth; var h = svg.documentHeight
        if (w <= 0f || h <= 0f) {
            val vb = svg.documentViewBox
            if (vb != null && vb.width() > 0f && vb.height() > 0f) { w = vb.width(); h = vb.height(); svg.setDocumentWidth(w); svg.setDocumentHeight(h) } else { w = 512f; h = 512f; svg.setDocumentWidth(w); svg.setDocumentHeight(h) }
        }
        val sc = maxSide.toFloat() / maxOf(w, h)
        val bw = (w * sc).toInt().coerceIn(1, maxSide); val bh = (h * sc).toInt().coerceIn(1, maxSide)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawColor(Color.WHITE)
        cv.scale(sc, sc)
        svg.renderToCanvas(cv)
        return bmp
    }
}
