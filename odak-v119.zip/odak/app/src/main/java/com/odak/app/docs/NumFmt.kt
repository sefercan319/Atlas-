package com.odak.app.docs

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.time.LocalDateTime
import java.util.Locale

/** Excel sayı/tarih biçimi (numFmt) → metin. Saf mantık. Kesir ("# ?/?") ve koşullu bölüm ([>100]) desteklenmez: genel biçime düşer. */
object NumFmt {
    private val BUILTIN = mapOf(
        0 to "General", 1 to "0", 2 to "0.00", 3 to "#,##0", 4 to "#,##0.00", 9 to "0%", 10 to "0.00%", 11 to "0.00E+00",
        14 to "dd.mm.yyyy", 15 to "d-mmm-yy", 16 to "d-mmm", 17 to "mmm-yy", 18 to "h:mm AM/PM", 19 to "h:mm:ss AM/PM",
        20 to "h:mm", 21 to "h:mm:ss", 22 to "dd.mm.yyyy h:mm", 37 to "#,##0;(#,##0)", 38 to "#,##0;(#,##0)",
        39 to "#,##0.00;(#,##0.00)", 40 to "#,##0.00;(#,##0.00)", 45 to "mm:ss", 46 to "[h]:mm:ss", 47 to "mm:ss.0", 48 to "##0.0E+0", 49 to "@"
    )

    fun codeFor(id: Int, custom: Map<Int, String>): String = custom[id] ?: BUILTIN[id] ?: "General"

    fun general(raw: String): String {
        val t = raw.trim()
        val d = t.toBigDecimalOrNull() ?: return raw
        if (t.matches(Regex("-?\\d+"))) return t
        val r = d.round(MathContext(15, RoundingMode.HALF_UP)).stripTrailingZeros()
        return if (r.signum() == 0) "0" else if (r.scale() < -10 || r.precision() - r.scale() > 15) r.toString() else r.toPlainString()
    }

    private fun sections(code: String): List<String> {
        val out = ArrayList<String>(); val sb = StringBuilder(); var q = false; var i = 0
        while (i < code.length) {
            val c = code[i]
            when {
                c == '"' -> { q = !q; sb.append(c) }
                c == '\\' && i + 1 < code.length -> { sb.append(c).append(code[i + 1]); i++ }
                c == ';' && !q -> { out.add(sb.toString()); sb.setLength(0) }
                else -> sb.append(c)
            }
            i++
        }
        out.add(sb.toString())
        return out
    }

    /** Biçim kodundaki tırnaklı/kaçışlı/köşeli parçaları atarak yalnız yer tutucuları bırakır. */
    private fun bare(sec: String): String {
        val sb = StringBuilder(); var i = 0
        while (i < sec.length) {
            val c = sec[i]
            when {
                c == '"' -> { i++; while (i < sec.length && sec[i] != '"') i++ }
                c == '\\' || c == '_' || c == '*' -> i++
                c == '[' -> { val e = sec.indexOf(']', i); if (e > 0 && sec.substring(i + 1, e).lowercase().startsWith("h") || e > 0 && sec.substring(i + 1, e).lowercase().startsWith("m") || e > 0 && sec.substring(i + 1, e).lowercase().startsWith("s")) sb.append('[').append(sec[i + 1].lowercaseChar()).append(']'); i = if (e > 0) e else i }
                else -> sb.append(c)
            }
            i++
        }
        return sb.toString()
    }

    private fun isDate(sec: String): Boolean {
        val b = bare(sec)
        if (b.contains(Regex("(?i)general"))) return false
        return b.contains(Regex("(?i)[ymdhs]")) && !b.contains(Regex("(?i)e[+-]"))
    }

    fun format(raw: String, code: String, locale: Locale = Locale.ENGLISH): String {
        val t = raw.trim()
        if (code.isBlank() || code.equals("General", true)) return general(raw)
        val v = t.toBigDecimalOrNull() ?: return raw
        val secs = sections(code)
        val neg = v.signum() < 0
        val conds = secs.map { cond(it) }
        var sec: String; var showMinus: Boolean; var value = v
        if (conds.any { it != null }) {
            val d = v.toDouble()
            val k = secs.indices.firstOrNull { i -> conds[i]?.let { (op, x) -> holds(d, op, x) } == true }
                ?: secs.indices.lastOrNull { conds[it] == null } ?: return general(raw)
            sec = secs[k]; showMinus = neg && secs.size < 3 && k == 0 || neg && conds[k] != null
            if (neg && conds[k] == null && secs.size > 1) { showMinus = false; value = v.abs() }
        } else {
            sec = when {
                secs.size == 1 -> secs[0]
                secs.size == 2 -> if (neg) secs[1] else secs[0]
                else -> if (v.signum() > 0) secs[0] else if (neg) secs[1] else secs[2]
            }
            showMinus = neg && secs.size == 1
            if (neg && secs.size > 1) value = v.abs()
        }
        if (sec.trim() == "@") return raw
        return try {
            when {
                isDate(sec) -> dateFmt(value.toDouble(), sec, locale)
                isFraction(sec) -> fractionFmt(value, sec, showMinus)
                else -> numFmt(value, sec, showMinus)
            }
        } catch (e: Exception) { general(raw) }
    }

    private val COND = Regex("\\[(<=|>=|<>|<|>|=)\\s*(-?[0-9.]+)\\]")
    private fun cond(sec: String): Pair<String, Double>? = COND.find(sec)?.let { it.groupValues[1] to (it.groupValues[2].toDoubleOrNull() ?: return null) }
    private fun holds(v: Double, op: String, x: Double) = when (op) { "<" -> v < x; ">" -> v > x; "<=" -> v <= x; ">=" -> v >= x; "=" -> v == x; else -> v != x }

    // ---- kesir ----
    private val FRAC = Regex("^([^#0?/]*?)(?:([#0?]+)\\s)?([#0?]+)/([#0?]+|[0-9]+)([^#0?/]*)$")
    private fun clean(s: String) = s.replace(Regex("\"([^\"]*)\""), "$1").replace("\\", "").replace(Regex("\\[[^\\]]*\\]"), "").replace("_", "").replace("*", "")
    private fun isFraction(sec: String): Boolean = !isDate(sec) && FRAC.matches(clean(sec).let { it })

    private fun fractionFmt(v: BigDecimal, sec: String, minus: Boolean): String {
        val m = FRAC.find(clean(sec)) ?: return general(v.toPlainString())
        val (pre, whole, _, den, post) = m.destructured
        val hasWhole = m.groupValues[2].isNotEmpty()
        val av = v.abs().toDouble()
        val fixed = den.toIntOrNull()?.takeIf { den.all { it.isDigit() } }
        val maxDen = fixed ?: (Math.pow(10.0, den.length.toDouble()).toInt() - 1).coerceIn(1, 999)
        var w = if (hasWhole) Math.floor(av).toLong() else 0L
        val frac = if (hasWhole) av - w else av
        var bn = 0L; var bd = 1L
        if (fixed != null) { bd = fixed.toLong(); bn = Math.round(frac * fixed) }
        else {
            var best = Double.MAX_VALUE
            for (d in 1..maxDen) { val n = Math.round(frac * d); val err = Math.abs(frac - n.toDouble() / d); if (err < best - 1e-12) { best = err; bn = n; bd = d.toLong() } }
        }
        if (hasWhole && bn >= bd) { w += bn / bd; bn %= bd }
        val body = when {
            hasWhole && bn == 0L -> w.toString()
            hasWhole && w == 0L -> "$bn/$bd"
            hasWhole -> "$w $bn/$bd"
            else -> "$bn/$bd"
        }
        return (if (minus && v.signum() < 0) "-" else "") + pre + body + post
    }

    // ---- sayı ----
    private fun numFmt(vIn: BigDecimal, sec: String, minus: Boolean): String {
        var v = vIn
        val pre = StringBuilder(); val post = StringBuilder()
        val intPat = StringBuilder(); val fracPat = StringBuilder()
        var seenDot = false; var state = 0 // 0: önek, 1: sayı, 2: sonek
        var sci = false; var sciDigits = 0; var percent = 0; var scaleComma = 0
        var i = 0
        fun lit(s: String) { if (state == 0) pre.append(s) else { state = 2; post.append(s) } }
        while (i < sec.length) {
            val c = sec[i]
            when {
                c == '"' -> { val e = sec.indexOf('"', i + 1).let { if (it < 0) sec.length else it }; lit(sec.substring(i + 1, e)); i = e }
                c == '\\' && i + 1 < sec.length -> { lit(sec[i + 1].toString()); i++ }
                c == '_' -> { lit(" "); i++ }
                c == '*' -> i++
                c == '[' -> { val e = sec.indexOf(']', i); if (e < 0) { i = sec.length } else { val inner = sec.substring(i + 1, e); if (inner.startsWith("$")) lit(inner.drop(1).substringBefore('-')); i = e } }
                c == '%' -> { percent++; lit("%") }
                (c == '0' || c == '#' || c == '?') && state < 2 -> { state = 1; if (seenDot) fracPat.append(c) else intPat.append(c) }
                c == '.' && state == 1 && !seenDot -> seenDot = true
                c == ',' && state == 1 && !seenDot -> intPat.append(c)
                c == ',' && state == 1 -> { scaleComma++ }
                (c == 'E' || c == 'e') && state == 1 && i + 1 < sec.length && (sec[i + 1] == '+' || sec[i + 1] == '-') -> {
                    sci = true; i += 2; while (i < sec.length && sec[i] == '0') { sciDigits++; i++ }; i--; state = 2
                }
                else -> lit(c.toString())
            }
            i++
        }
        if (intPat.isEmpty() && fracPat.isEmpty() && !sci) return pre.toString() + post
        // ",", rakamlar arasında binlik ayracı; sonda ise 1000'e bölme
        var ip = intPat.toString()
        var thousands = false
        while (ip.endsWith(",")) { ip = ip.dropLast(1); scaleComma++ }
        if (ip.contains(',')) { thousands = true; ip = ip.replace(",", "") }
        repeat(percent) { v = v.multiply(BigDecimal(100)) }
        repeat(scaleComma) { v = v.divide(BigDecimal(1000)) }
        val fp = fracPat.toString()
        val sb = StringBuilder()
        if (sci) {
            val ex = if (v.signum() == 0) 0 else v.abs().precision() - v.abs().scale() - 1
            val mant = v.movePointLeft(ex)
            sb.append(plain(mant, ip, fp, thousands, minus && v.signum() < 0))
            sb.append('E').append(if (ex < 0) '-' else '+').append(Math.abs(ex).toString().padStart(maxOf(sciDigits, 1), '0'))
        } else sb.append(plain(v, ip, fp, thousands, minus && v.signum() < 0))
        return pre.toString() + sb + post
    }

    private fun plain(v: BigDecimal, ip: String, fp: String, thousands: Boolean, minus: Boolean): String {
        val minFrac = fp.count { it == '0' }
        val r = v.abs().setScale(fp.length, RoundingMode.HALF_UP)
        var s = r.toPlainString()
        var intS = s.substringBefore('.'); var fracS = if (s.contains('.')) s.substringAfter('.') else ""
        while (fracS.length > minFrac && fracS.endsWith("0")) fracS = fracS.dropLast(1)
        val minInt = ip.count { it == '0' }
        if (intS == "0" && minInt == 0) intS = ""
        intS = intS.padStart(minInt, '0')
        if (thousands && intS.length > 3) intS = intS.reversed().chunked(3).joinToString(",").reversed()
        val zero = r.signum() == 0
        return (if (minus && !zero) "-" else "") + intS + (if (fracS.isNotEmpty()) ".$fracS" else "").let { if (fp.isNotEmpty() && intS.isEmpty() && fracS.isEmpty()) "0" else it }
    }

    // ---- tarih/saat ----
    fun serialToDateTime(serial: Double): LocalDateTime {
        val days = Math.floor(serial).toLong()
        var secs = Math.round((serial - days) * 86400.0)
        var base = java.time.LocalDate.of(1899, 12, 30)
        if (serial < 60) base = base.plusDays(1)
        var d = base.plusDays(days)
        if (secs >= 86400) { secs -= 86400; d = d.plusDays(1) }
        return d.atStartOfDay().plusSeconds(secs)
    }

    private fun dateFmt(serial: Double, sec: String, locale: Locale): String {
        val dt = serialToDateTime(serial)
        val ampm = Regex("(?i)(AM/PM|A/P)").containsMatchIn(sec)
        val out = StringBuilder(); var i = 0
        // 'm' ay mı dakika mı: önceki belirteç h ise veya sonraki s ise dakika
        var lastH = false
        val total = serial * 24
        while (i < sec.length) {
            val c = sec[i]; val lc = c.lowercaseChar()
            fun run(ch: Char): Int { var n = 0; while (i + n < sec.length && sec[i + n].lowercaseChar() == ch) n++; return n }
            when {
                c == '"' -> { val e = sec.indexOf('"', i + 1).let { if (it < 0) sec.length else it }; out.append(sec, i + 1, e); i = e + 1 }
                c == '\\' && i + 1 < sec.length -> { out.append(sec[i + 1]); i += 2 }
                c == '_' || c == '*' -> i += 2
                c == '[' -> {
                    val e = sec.indexOf(']', i).let { if (it < 0) sec.length - 1 else it }
                    val inner = sec.substring(i + 1, e).lowercase()
                    when {
                        inner.startsWith("h") -> { out.append(Math.floor(total).toLong().toString().padStart(inner.length, '0')); lastH = true }
                        inner.startsWith("m") -> out.append(Math.floor(total * 60).toLong().toString().padStart(inner.length, '0'))
                        inner.startsWith("s") -> out.append(Math.round(total * 3600).toString().padStart(inner.length, '0'))
                        inner.startsWith("$") -> out.append(inner.drop(1).substringBefore('-'))
                    }
                    i = e + 1
                }
                lc == 'y' -> { val n = run('y'); out.append(if (n <= 2) "%02d".format(dt.year % 100) else "%04d".format(dt.year)); i += n; lastH = false }
                lc == 'd' -> {
                    val n = run('d')
                    out.append(when (n) { 1 -> dt.dayOfMonth.toString(); 2 -> "%02d".format(dt.dayOfMonth); 3 -> dt.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, locale); else -> dt.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, locale) })
                    i += n; lastH = false
                }
                lc == 'm' -> {
                    val n = run('m')
                    var j = i + n; while (j < sec.length && !sec[j].isLetter()) j++
                    val minute = lastH || (j < sec.length && sec[j].lowercaseChar() == 's')
                    if (minute) out.append(if (n >= 2) "%02d".format(dt.minute) else dt.minute.toString())
                    else out.append(when (n) { 1 -> dt.monthValue.toString(); 2 -> "%02d".format(dt.monthValue); 3 -> java.time.Month.of(dt.monthValue).getDisplayName(java.time.format.TextStyle.SHORT, locale); 4 -> java.time.Month.of(dt.monthValue).getDisplayName(java.time.format.TextStyle.FULL, locale); else -> java.time.Month.of(dt.monthValue).getDisplayName(java.time.format.TextStyle.FULL, locale).take(1) })
                    i += n; lastH = false
                }
                lc == 'h' -> { val n = run('h'); val h = if (ampm) (dt.hour % 12).let { if (it == 0) 12 else it } else dt.hour; out.append(if (n >= 2) "%02d".format(h) else h.toString()); i += n; lastH = true }
                lc == 's' -> {
                    val n = run('s'); out.append(if (n >= 2) "%02d".format(dt.second) else dt.second.toString()); i += n; lastH = false
                    if (i + 1 < sec.length && sec[i] == '.' && sec[i + 1] == '0') { var k = 0; while (i + 1 + k < sec.length && sec[i + 1 + k] == '0') k++; out.append('.').append("0".repeat(k)); i += 1 + k }
                }
                (c == 'A' || c == 'a') && sec.regionMatches(i, "AM/PM", 0, 5, true) -> { out.append(if (dt.hour < 12) "AM" else "PM"); i += 5 }
                (c == 'A' || c == 'a') && sec.regionMatches(i, "A/P", 0, 3, true) -> { out.append(if (dt.hour < 12) "A" else "P"); i += 3 }
                else -> { out.append(c); i++ }
            }
        }
        return out.toString()
    }
}
