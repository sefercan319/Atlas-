package com.odak.app.theme

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color

@Composable
fun Modifier.plainClick(onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )

fun Modifier.hairlineTop(color: Color, widthPx: Float = 2f): Modifier =
    drawBehind { drawLine(color, Offset(0f, 0f), Offset(size.width, 0f), widthPx) }

fun Modifier.hairlineBottom(color: Color, widthPx: Float = 2f): Modifier =
    drawBehind { drawLine(color, Offset(0f, size.height), Offset(size.width, size.height), widthPx) }

/** Geniş/yatay ekran mı (yan şerit + iki sütun)? Boyut/yön değişince otomatik yeniden hesaplanır. */
@Composable
fun rememberLandscape(): Boolean {
    val c = androidx.compose.ui.platform.LocalConfiguration.current
    return com.odak.app.logic.Pure.useRail(c.screenWidthDp, c.screenHeightDp)
}
