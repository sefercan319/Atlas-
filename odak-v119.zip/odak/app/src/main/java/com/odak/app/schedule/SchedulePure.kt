package com.odak.app.schedule

import java.time.DayOfWeek
import java.time.LocalDateTime

/** Günlük program satırı: saat (dakika), hangi günler (bit0 = Pazartesi … bit6 = Pazar), açık/kapalı, metin. */
data class SchedItem(val id: String, val min: Int, val days: Int = SchedulePure.ALL, val on: Boolean = true, val text: String)

/** Saf mantık (Android'siz, sınanabilir): sıralama, sonraki bildirim zamanı, kayıt biçimi. */
object SchedulePure {
    const val ALL = 127
    const val MAX_ITEMS = 300
    const val MAX_TEXT = 200

    fun bit(d: DayOfWeek) = 1 shl (d.value - 1)
    fun runsOn(i: SchedItem, d: DayOfWeek) = i.days and bit(d) != 0
    fun fmt(min: Int) = "%02d:%02d".format(min.coerceIn(0, 1439) / 60, min.coerceIn(0, 1439) % 60)
    fun clean(text: String) = text.replace(Regex("\\s+"), " ").trim().take(MAX_TEXT)

    fun sorted(l: List<SchedItem>) = l.sortedWith(compareBy({ it.min }, { it.text.lowercase() }))
    fun forDay(l: List<SchedItem>, d: DayOfWeek) = sorted(l.filter { runsOn(it, d) })

    /** Bu satırın [now]'dan sonraki ilk çalışma anı; kapalı/günsüz satırda null. */
    fun nextFire(i: SchedItem, now: LocalDateTime): LocalDateTime? {
        if (!i.on || i.days and ALL == 0) return null
        val m = i.min.coerceIn(0, 1439)
        for (k in 0..7) {
            val d = now.toLocalDate().plusDays(k.toLong())
            val t = d.atTime(m / 60, m % 60)
            if (runsOn(i, d.dayOfWeek) && t.isAfter(now)) return t
        }
        return null
    }

    /** Bugünden itibaren sıradaki satır ve zamanı (özet için). */
    fun upcoming(l: List<SchedItem>, now: LocalDateTime): Pair<SchedItem, LocalDateTime>? =
        l.mapNotNull { i -> nextFire(i, now)?.let { i to it } }.minByOrNull { it.second }

    fun daysLabel(mask: Int, names: List<String>, everyDay: String): String {
        val m = mask and ALL
        if (m == ALL) return everyDay
        return (0..6).filter { m and (1 shl it) != 0 }.joinToString(" ") { names[it] }
    }

    fun toggleDay(mask: Int, d: DayOfWeek) = (mask xor bit(d)) and ALL

    private fun esc(s: String) = s.replace("\\", "\\\\").replace("|", "\\p").replace("\n", "\\n")
    private fun unesc(s: String): String {
        val sb = StringBuilder(); var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) { sb.append(when (s[i + 1]) { 'p' -> '|'; 'n' -> '\n'; else -> s[i + 1] }); i += 2 } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    fun encode(l: List<SchedItem>): String = l.take(MAX_ITEMS).joinToString("\n") { "${esc(it.id)}|${it.min}|${it.days}|${if (it.on) 1 else 0}|${esc(it.text)}" }

    fun decode(s: String): List<SchedItem> = s.lines().mapNotNull { line ->
        val p = line.split("|")
        if (p.size < 5) return@mapNotNull null
        val min = p[1].toIntOrNull() ?: return@mapNotNull null
        val days = p[2].toIntOrNull() ?: return@mapNotNull null
        val id = unesc(p[0]); val text = clean(unesc(p.drop(4).joinToString("|")))
        if (id.isBlank() || text.isEmpty() || min !in 0..1439) null else SchedItem(id, min, days and ALL, p[3] == "1", text)
    }.distinctBy { it.id }.take(MAX_ITEMS)
}
