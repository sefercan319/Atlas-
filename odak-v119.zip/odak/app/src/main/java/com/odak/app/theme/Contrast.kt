package com.odak.app.theme

/** WCAG kontrast hesabı (ARGB Int). Saf mantık; yazı rengi zemine göre okunamıyorsa güvenli renge çevirmek için. */
object Contrast {
    const val MIN = 4.5

    private fun lin(v: Int): Double { val c = v / 255.0; return if (c <= 0.03928) c / 12.92 else Math.pow((c + 0.055) / 1.055, 2.4) }
    fun luminance(argb: Int): Double = 0.2126 * lin((argb shr 16) and 255) + 0.7152 * lin((argb shr 8) and 255) + 0.0722 * lin(argb and 255)

    /** [fg] yarı saydamsa [bg] üstüne karıştırılır; sonuç opak ARGB. */
    fun blend(fg: Int, bg: Int): Int {
        val a = ((fg ushr 24) and 255) / 255.0
        fun ch(s: Int) = Math.round(((fg shr s) and 255) * a + ((bg shr s) and 255) * (1 - a)).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    fun ratio(fg: Int, bg: Int): Double {
        val b = blend(bg, 0xFFFFFFFF.toInt())
        val a = luminance(blend(fg, b)); val c = luminance(b)
        return (maxOf(a, c) + 0.05) / (minOf(a, c) + 0.05)
    }

    const val BLACK = 0xFF000000.toInt()
    const val WHITE = 0xFFFFFFFF.toInt()

    /** Tercih edilen yazı rengi zeminde okunuyorsa aynısı; değilse zeminde en çok kontrast veren siyah/beyaz. */
    fun readable(pref: Int, bg: Int, min: Double = MIN): Int {
        if (ratio(pref, bg) >= min) return pref
        return if (ratio(WHITE, bg) >= ratio(BLACK, bg)) WHITE else BLACK
    }

    /** Zemine uygun (siyah/beyaz) yazı rengi. */
    fun onColor(bg: Int): Int = readable(0x00000000, bg, 99.0)

    /** [fg] rengini en az [desired] saydamlıkla, ama [min] kontrastı sağlayacak en küçük saydamlıkta döndürür (opaklık 0..1). */
    fun alphaFor(fg: Int, bg: Int, desired: Double, min: Double = MIN): Double {
        var a = desired.coerceIn(0.0, 1.0)
        while (a < 1.0) {
            val c = ((Math.round(a * 255).toInt()) shl 24) or (fg and 0xFFFFFF)
            if (ratio(c, bg) >= min) return a
            a += 0.05
        }
        return 1.0
    }

    /** Hata (kırmızı) yazı rengi: açık zeminde koyu, koyu zeminde açık kırmızı; her ikisi de ≥4.5 kontrast. */
    fun errorFor(bg: Int): Int = if (luminance(blend(bg, WHITE)) > 0.4) 0xFFA61515.toInt() else 0xFFFF8A80.toInt()
}
