package com.odak.app.theme

/** Metni "renkli emoji" ve sıradan parçalara böler (koyu/açık mod ters çevirmesinde emojiyi korumak için). Saf mantık. */
object EmojiSplit {
    class Seg(val text: String, val emoji: Boolean)

    // Varsayılan olarak emoji görünümlü (Emoji_Presentation) BMP simgeleri
    private val BMP = setOf(
        0x231A, 0x231B, 0x23E9, 0x23EA, 0x23EB, 0x23EC, 0x23F0, 0x23F3, 0x25FD, 0x25FE, 0x2614, 0x2615,
        0x2648, 0x2649, 0x264A, 0x264B, 0x264C, 0x264D, 0x264E, 0x264F, 0x2650, 0x2651, 0x2652, 0x2653,
        0x267F, 0x2693, 0x26A1, 0x26AA, 0x26AB, 0x26BD, 0x26BE, 0x26C4, 0x26C5, 0x26CE, 0x26D4, 0x26EA,
        0x26F2, 0x26F3, 0x26F5, 0x26FA, 0x26FD, 0x2705, 0x270A, 0x270B, 0x2728, 0x274C, 0x274E, 0x2753,
        0x2754, 0x2755, 0x2757, 0x2795, 0x2796, 0x2797, 0x27B0, 0x27BF, 0x2B1B, 0x2B1C, 0x2B50, 0x2B55
    )

    fun isColorEmoji(cp: Int): Boolean = cp in 0x1F300..0x1FAFF || cp in 0x1F000..0x1F2FF || cp in BMP

    fun hasEmoji(s: String): Boolean {
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i); val n = Character.charCount(cp)
            if (isColorEmoji(cp) || (i + n < s.length && s[i + n] == '️' && cp > 0xFF)) return true
            i += n
        }
        return false
    }

    /** Ardışık emojiler (ZWJ, FE0F, ten tonu dahil) tek parça olur; sıradan metin ayrı kalır. */
    fun split(s: String): List<Seg> {
        val out = ArrayList<Seg>(); val sb = StringBuilder(); var cur = false
        fun flush() { if (sb.isNotEmpty()) { out.add(Seg(sb.toString(), cur)); sb.setLength(0) } }
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i); val n = Character.charCount(cp)
            val next = if (i + n < s.length) s[i + n] else '\u0000'
            val isMod = cp == 0xFE0F || cp == 0x200D || cp in 0x1F3FB..0x1F3FF || cp == 0x20E3
            val emo = isColorEmoji(cp) || (next == '️' && cp > 0xFF) || (isMod && cur && sb.isNotEmpty())
            if (sb.isNotEmpty() && emo != cur) flush()
            cur = emo
            sb.appendCodePoint(cp); i += n
        }
        flush()
        return out
    }
}
