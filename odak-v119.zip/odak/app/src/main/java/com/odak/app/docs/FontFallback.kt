package com.odak.app.docs

/**
 * Gömülü yazı tipinde olmayan harfler (Arapça, Kiril, Yunanca, Ə, İ, Ğ...) için yedek yüz seçer; çalışmayı parçalara böler.
 * Eksik tablosu asset yazı tiplerinin cmap'inden üretildi; test gerçek dosyalarla doğrular. Saf mantık.
 */
object FontFallback {
    const val ARABIC = "NotoNaskhArabic"
    const val ARABIC_NAME = "Noto Naskh Arabic"

    /** aile → eksik kod noktası aralıkları (çiftler: baş, son) — yalnız Türkçe/Azerice, Yunanca ve Kiril bloğu denendi. */
    val MISSING: Map<String, IntArray> = mapOf(
        "Anton" to intArrayOf(913, 915, 917, 929, 932, 936, 938, 959, 961, 969, 1024, 1119),
        "Caladea" to intArrayOf(399, 399, 601, 601, 913, 929, 931, 969, 1024, 1119),
        "ComicNeue" to intArrayOf(286, 287, 304, 304, 399, 399, 601, 601, 913, 929, 931, 969, 1024, 1119),
        "CrimsonPro" to intArrayOf(913, 915, 917, 929, 932, 936, 938, 955, 957, 959, 961, 969, 1024, 1119),
        "DancingScript" to intArrayOf(913, 929, 931, 969, 1024, 1119),
        "Gelasio" to intArrayOf(915, 915, 920, 920, 923, 923, 926, 926, 928, 928, 934, 934, 936, 936, 938, 955, 957, 959, 961, 969, 1024, 1119),
        "Inconsolata" to intArrayOf(913, 929, 931, 969, 1024, 1119),
        "LibreFranklin" to intArrayOf(913, 915, 917, 929, 931, 936, 938, 955, 957, 959, 961, 969),
        "OpenSans" to intArrayOf(399, 399),
        "Questrial" to intArrayOf(913, 929, 931, 936, 938, 959, 961, 969, 1024, 1119)
    )

    fun isArabic(cp: Int) = cp in 0x600..0x6FF || cp in 0x750..0x77F || cp in 0xFB50..0xFDFF || cp in 0xFE70..0xFEFF

    fun missing(family: String, cp: Int): Boolean {
        val r = MISSING[family] ?: return false
        var i = 0
        while (i < r.size) { if (cp >= r[i] && cp <= r[i + 1]) return true; i += 2 }
        return false
    }

    /** Eksik harf için yedek aile adı (belge yazı tipi adı olarak kullanılır) ya da null. */
    fun fallbackFor(family: String, cp: Int): String? {
        if (isArabic(cp)) return ARABIC_NAME
        if (!missing(family, cp)) return null
        return when (family) { "Caladea", "Gelasio", "CrimsonPro", "EBGaramond" -> "Tinos"; "Inconsolata" -> "Cousine"; else -> "Arimo" }
    }

    private fun copy(r: RRun, text: String, font: String?) = RRun(text, r.b, r.i, r.u, r.s, r.color, r.hl, r.sz, font, r.sup, r.href, r.img)

    /** Çalışmaları eksik harf sınırlarında böler; gerekmiyorsa aynı listeyi döndürür. Boşluk/noktalama/rakam bulunduğu parçada kalır. */
    fun expand(runs: List<RRun>, defFont: String?): List<RRun> {
        var out: ArrayList<RRun>? = null
        for ((idx, r) in runs.withIndex()) {
            val fam = if (r.img == null && r.text.isNotEmpty()) FontMap.asset(r.font ?: defFont) else null
            var parts: List<RRun>? = null
            if (fam != null && fam != ARABIC) {
                val segs = ArrayList<Pair<String, String?>>()   // (metin, yazı tipi; null = asıl)
                val sb = StringBuilder(); var cur: String? = null; var started = false
                var i = 0
                while (i < r.text.length) {
                    val cp = r.text.codePointAt(i); val n = Character.charCount(cp)
                    val neutral = !Character.isLetter(cp) && !Character.isISOControl(cp) && cp != 0x200D
                    val fb = if (neutral) (if (started) cur else null) else fallbackFor(fam, cp)
                    if (started && fb != cur) { segs.add(sb.toString() to cur); sb.setLength(0) }
                    cur = fb; started = true
                    sb.appendCodePoint(cp); i += n
                }
                if (sb.isNotEmpty()) segs.add(sb.toString() to cur)
                if (segs.any { it.second != null }) parts = segs.map { copy(r, it.first, it.second ?: r.font ?: defFont) }
            } else if (fam == ARABIC) { /* zaten Arapça yüzü */ }
            if (parts != null && out == null) { out = ArrayList(runs.subList(0, idx)) }
            if (out != null) { if (parts != null) out.addAll(parts) else out.add(r) }
        }
        return out ?: runs
    }
}
