package com.odak.app.theme

/** Renk seçici için HSV ↔ ARGB ve onaltılık (#RRGGBB) dönüşümleri. Saf mantık. */
object ColorMath {
    /** h 0..360, s ve v 0..1 → opak ARGB. */
    fun hsv(h: Float, s: Float, v: Float): Int {
        val hh = ((h % 360f) + 360f) % 360f
        val c = v * s; val x = c * (1 - Math.abs((hh / 60f) % 2 - 1)); val m = v - c
        val (r, g, b) = when ((hh / 60f).toInt()) {
            0 -> Triple(c, x, 0f); 1 -> Triple(x, c, 0f); 2 -> Triple(0f, c, x)
            3 -> Triple(0f, x, c); 4 -> Triple(x, 0f, c); else -> Triple(c, 0f, x)
        }
        fun f(t: Float) = Math.round((t + m) * 255f).coerceIn(0, 255)
        return (0xFF shl 24) or (f(r) shl 16) or (f(g) shl 8) or f(b)
    }

    /** ARGB → (h, s, v). */
    fun toHsv(argb: Int): Triple<Float, Float, Float> {
        val r = ((argb shr 16) and 255) / 255f; val g = ((argb shr 8) and 255) / 255f; val b = (argb and 255) / 255f
        val mx = maxOf(r, g, b); val mn = minOf(r, g, b); val d = mx - mn
        val h = when {
            d == 0f -> 0f
            mx == r -> 60f * (((g - b) / d) % 6f)
            mx == g -> 60f * ((b - r) / d + 2f)
            else -> 60f * ((r - g) / d + 4f)
        }
        return Triple((h + 360f) % 360f, if (mx == 0f) 0f else d / mx, mx)
    }

    fun toHex(argb: Int): String = "#%06X".format(argb and 0xFFFFFF)

    /** "#RGB", "#RRGGBB", "RRGGBB" (büyük/küçük harf) → opak ARGB; geçersizse null. */
    fun parseHex(s: String): Int? {
        var t = s.trim().removePrefix("#")
        if (t.length == 3) t = t.map { "$it$it" }.joinToString("")
        if (t.length != 6 || !t.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) return null
        return (0xFF shl 24) or t.toInt(16)
    }

    /** 32 renkli palet: eski 24 renk + 8 yeni (turkuaz, lavanta, mercan, zeytin, gece mavisi, bordo, kum, antrasit). */
    val PALETTE: List<Int> = listOf(
        0xFFE53935, 0xFFFF7043, 0xFFFFA000, 0xFFFDD835, 0xFF7CB342, 0xFF2FA52A, 0xFF00A86B, 0xFF05D9E8,
        0xFF00B0FF, 0xFF0067C0, 0xFF5C6BC0, 0xFF7C4DFF, 0xFFAB47BC, 0xFFFF2A6D, 0xFFF8BBD0, 0xFFFFE0B2,
        0xFFFFF9C4, 0xFFC8E6C9, 0xFFB3E5FC, 0xFFD1C4E9,
        0xFF14B8A6, 0xFFB794F4, 0xFFFF8A80, 0xFF808000, 0xFF0B1F4B, 0xFF800020, 0xFFE8DCC4, 0xFF263238,
        0xFF111111, 0xFF3A3A3A, 0xFF9E9E9E, 0xFFFFFFFF
    ).map { it.toInt() }

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(sh: Int) = Math.round(((a shr sh) and 255) * (1 - t) + ((b shr sh) and 255) * t).coerceIn(0, 255)
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /** Kullanıcı arka plan rengi seçtiğinde kartların yüzey rengi: açık zeminde beyaza, koyu zeminde hafif aydınlığa doğru. */
    fun surfaceFor(bg: Int): Int = if (Contrast.luminance(bg) > 0.5) mix(bg, 0xFFFFFFFF.toInt(), 0.55f) else mix(bg, 0xFFFFFFFF.toInt(), 0.08f)

    /** Seçilen yazı rengi hem zeminde hem yüzeyde ≥4.5 ise aynen; değilse zeminde daha çok kontrast veren siyah/beyaz. */
    fun safeText(text: Int, bg: Int, surface: Int): Int {
        fun worst(c: Int) = minOf(Contrast.ratio(c, bg), Contrast.ratio(c, Contrast.blend(surface, bg)))
        if (worst(text) >= Contrast.MIN) return text
        return if (Contrast.ratio(0xFFFFFFFF.toInt(), bg) >= Contrast.ratio(0xFF000000.toInt(), bg)) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()   // zemin esas
    }

    /** Koyu seçilen zemin için yumuşak üst renk (düz zemin yerine hafif dikey geçiş). */
    fun lighter(c: Int, t: Float = 0.08f): Int = mix(c, 0xFFFFFFFF.toInt(), t)
}
