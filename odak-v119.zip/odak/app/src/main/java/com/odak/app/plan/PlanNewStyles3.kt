package com.odak.app.plan

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.odak.app.R
import com.odak.app.theme.CosmicGold
import com.odak.app.theme.CosmicLavender
import com.odak.app.theme.DesignStyle
import com.odak.app.theme.HazardYellow
import com.odak.app.theme.HudAmber
import com.odak.app.theme.HudCyan
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.NeoGold
import com.odak.app.theme.SteelPlate
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.cosmicPanel
import com.odak.app.theme.greekKey
import com.odak.app.theme.hazardStripes
import com.odak.app.theme.hudPanel
import com.odak.app.theme.neoFrame
import com.odak.app.theme.plainClick
import com.odak.app.theme.roman
import com.odak.app.theme.steelPlate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
private fun EmptyNote(color: Color) {
    com.odak.app.theme.PlanEmpty(color)
}

// =====================================================================
// COSMIC: yörünge halkası ilerleme, yıldız ışıklı paneller
// =====================================================================
@Composable
fun CosmicPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    val done = list.count { it.done }
    val frac = if (list.isEmpty()) 0f else done.toFloat() / list.size
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    vm.anchor.format(DateTimeFormatter.ofPattern("EEEE", Locale.getDefault())).uppercase(Locale.getDefault()),
                    fontSize = 12.sp, letterSpacing = 4.sp, color = CosmicLavender
                )
                Text(
                    vm.anchor.format(DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault())),
                    fontSize = 32.sp, fontWeight = FontWeight.Light, color = t.text
                )
            }
            // yörünge ilerlemesi: dış halka + üzerinde gezegen
            Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 4.dp.toPx()
                    val inset = sw
                    val sz = Size(size.width - 2 * inset, size.height - 2 * inset)
                    drawArc(CosmicLavender.copy(alpha = 0.2f), 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(sw))
                    drawArc(CosmicGold, -90f, 360f * frac, false, Offset(inset, inset), sz, style = Stroke(sw, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                }
                Text("$done/${list.size}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = t.text)
            }
        }
        Spacer(Modifier.height(16.dp))
        PlanBody(vm, DesignStyle.COSMIC, 12) { CosmicList(vm) }
    }
}

@Composable
private fun CosmicList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) { EmptyNote(t.text.copy(alpha = 0.8f)); return }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        list.forEach { p ->
            Row(
                Modifier.fillMaxWidth()
                    .cosmicPanel(RoundedCornerShape(20.dp), if (p.done) 0.1f else 0.45f)
                    .plainClick { vm.startEdit(p) }
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p), fontSize = 15.sp,
                        color = if (p.done) t.text.copy(alpha = 0.6f) else t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text(timeOf(p), fontSize = 11.sp, color = CosmicGold)
                }
                DeleteMark(t.text.copy(alpha = 0.7f)) { vm.remove(p) }
            }
        }
    }
}

// =====================================================================
// SCI-FI HUD: radar kadranı, telemetri satırları
// =====================================================================
@Composable
fun HudPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    val sweep by rememberInfiniteTransition(label = "radar").animateFloat(
        0f, 360f, infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart), label = "sweep"
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth().hudPanel(HudAmber, 0f).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(84.dp)) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val r = size.minDimension / 2f - 2.dp.toPx()
                    drawCircle(HudCyan.copy(alpha = 0.5f), r, c, style = Stroke(1.dp.toPx()))
                    drawCircle(HudCyan.copy(alpha = 0.3f), r * 0.66f, c, style = Stroke(1.dp.toPx()))
                    drawCircle(HudCyan.copy(alpha = 0.3f), r * 0.33f, c, style = Stroke(1.dp.toPx()))
                    drawLine(HudCyan.copy(alpha = 0.3f), Offset(c.x - r, c.y), Offset(c.x + r, c.y), 1f)
                    drawLine(HudCyan.copy(alpha = 0.3f), Offset(c.x, c.y - r), Offset(c.x, c.y + r), 1f)
                    drawArc(HudAmber.copy(alpha = 0.35f), sweep - 40f, 40f, true, Offset(c.x - r, c.y - r), Size(2 * r, 2 * r))
                    // görev noktaları: her görev bir "blip"
                    list.forEachIndexed { i, p ->
                        val a = Math.toRadians((i * 137.5) % 360.0)
                        val rr = r * (0.3f + 0.6f * ((i * 37 % 100) / 100f))
                        val col = if (p.done) HudCyan else HudAmber
                        drawCircle(col, 2.5.dp.toPx(), Offset(c.x + (rr * Math.cos(a)).toFloat(), c.y + (rr * Math.sin(a)).toFloat()))
                    }
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "▌" + stringResource(R.string.tab_plan).uppercase(Locale.getDefault()) + " //",
                    fontFamily = FontFamily.Monospace, fontSize = 14.sp, letterSpacing = 2.sp, color = HudAmber
                )
                Text(
                    vm.anchor.format(DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.getDefault())),
                    fontFamily = FontFamily.Monospace, fontSize = 20.sp, color = t.text
                )
                Text(
                    "OK ${list.count { it.done }} / ${list.size}",
                    fontFamily = FontFamily.Monospace, fontSize = 12.sp, letterSpacing = 1.sp, color = HudCyan
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        PlanBody(vm, DesignStyle.SCIFI_HUD, 10) { HudList(vm) }
    }
}

@Composable
private fun HudList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) { EmptyNote(t.text.copy(alpha = 0.8f)); return }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEachIndexed { i, p ->
            Row(
                Modifier.fillMaxWidth()
                    .hudPanel(if (p.done) HudCyan else HudAmber, 0f, grid = false)
                    .plainClick { vm.startEdit(p) }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("%02d".format(i + 1), fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = HudCyan)
                Spacer(Modifier.width(10.dp))
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p, upper = true), fontFamily = FontFamily.Monospace, fontSize = 13.sp, letterSpacing = 1.sp,
                        color = if (p.done) t.text.copy(alpha = 0.6f) else t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text("T+" + timeOf(p), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = HudAmber)
                }
                DeleteMark(t.text.copy(alpha = 0.7f)) { vm.remove(p) }
            }
        }
    }
}

// =====================================================================
// CYBER-INDUSTRIAL: uyarı şeritli iş emri, çelik biletler
// =====================================================================
@Composable
fun CyberPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Column(Modifier.fillMaxWidth().steelPlate(CutCornerShape(topEnd = 12.dp, bottomStart = 12.dp), SteelPlate)) {
            Box(Modifier.fillMaxWidth().height(10.dp).drawBehind { hazardStripes(Offset.Zero, size, 8.dp.toPx()) })
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        stringResource(R.string.tab_plan).uppercase(Locale.getDefault()),
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 3.sp, color = t.text
                    )
                    Text(
                        vm.anchor.format(DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.getDefault())),
                        fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = HazardYellow
                    )
                }
                Box(Modifier.background(HazardYellow, CutCornerShape(4.dp)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Text("${list.count { it.done }}/${list.size}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color(0xFF111111))
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        PlanBody(vm, DesignStyle.CYBER_INDUSTRIAL, 10) { CyberList(vm) }
    }
}

@Composable
private fun CyberList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) { EmptyNote(t.text.copy(alpha = 0.8f)); return }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.forEachIndexed { i, p ->
            Row(
                Modifier.fillMaxWidth()
                    .steelPlate(CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp), SteelPlate, if (p.done) 1f else 0f, rivets = false)
                    .plainClick { vm.startEdit(p) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                // sarı bilet numarası
                Box(Modifier.width(44.dp).height(56.dp).background(if (p.done) Color(0xFF6B5A00) else HazardYellow), contentAlignment = Alignment.Center) {
                    Text("#%02d".format(i + 1), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 13.sp, color = if (p.done) Color(0xFFF3E7A0) else Color(0xFF111111))
                }
                Spacer(Modifier.width(12.dp))
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                    Text(
                        titleWithDot(p, upper = true), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.sp,
                        color = if (p.done) t.text.copy(alpha = 0.6f) else t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text(timeOf(p), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = HazardYellow)
                }
                DeleteMark(t.text.copy(alpha = 0.7f)) { vm.remove(p) }
                Spacer(Modifier.width(6.dp))
            }
        }
    }
}

// =====================================================================
// NEOCLASSICAL: Yunan anahtarı bandı, Roma rakamları, çift çizgili çerçeve
// =====================================================================
@Composable
fun NeoPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Box(Modifier.fillMaxWidth().height(14.dp).drawBehind { greekKey(NeoGold, Offset.Zero, size.width, size.height) })
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                vm.anchor.format(DateTimeFormatter.ofPattern("EEEE", Locale.getDefault())).uppercase(Locale.getDefault()),
                fontFamily = FontFamily.Serif, fontSize = 12.sp, letterSpacing = 5.sp, color = t.primary
            )
            Text(
                roman(vm.anchor.dayOfMonth) + " · " + vm.anchor.format(DateTimeFormatter.ofPattern("MMMM", Locale.getDefault())),
                fontFamily = FontFamily.Serif, fontSize = 28.sp, color = t.text
            )
            Text(
                "${list.count { it.done }} / ${list.size}",
                fontFamily = FontFamily.Serif, fontSize = 13.sp, letterSpacing = 2.sp, color = t.text.copy(alpha = 0.7f)
            )
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(14.dp).drawBehind { greekKey(NeoGold, Offset.Zero, size.width, size.height) })
        Spacer(Modifier.height(16.dp))
        PlanBody(vm, DesignStyle.NEOCLASSICAL, 12) { NeoList(vm) }
    }
}

@Composable
private fun NeoList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) { EmptyNote(t.text.copy(alpha = 0.8f)); return }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        list.forEachIndexed { i, p ->
            Row(
                Modifier.fillMaxWidth()
                    .neoFrame(NeoGold, true, if (p.done) Color(0xFFEFE9DA) else t.surface)
                    .plainClick { vm.startEdit(p) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(roman(i + 1), fontFamily = FontFamily.Serif, fontSize = 14.sp, color = t.primary, modifier = Modifier.width(34.dp))
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p), fontFamily = FontFamily.Serif, fontSize = 16.sp,
                        color = if (p.done) t.text.copy(alpha = 0.65f) else t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text(timeOf(p), fontFamily = FontFamily.Serif, fontSize = 12.sp, color = t.primary)
                }
                DeleteMark(t.text.copy(alpha = 0.7f)) { vm.remove(p) }
            }
        }
    }
}
