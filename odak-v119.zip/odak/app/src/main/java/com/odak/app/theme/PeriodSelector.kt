package com.odak.app.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

/** Gün / Hafta / Ay seçici. Her tasarımda farklı görünür. */
@Composable
fun PeriodSelector(
    labels: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val d = LocalDesign.current
    val t = d.tokens
    val style = d.style
    val pick: (Int) -> Unit = {
        ClickSound.play(style, SoundKind.TAP)
        onSelect(it)
    }
    when (style) {
        DesignStyle.FUTURISTIC, DesignStyle.TERMINAL -> Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Box(
                    Modifier
                        .size(28.dp)
                        .background(if (on) t.primary.copy(alpha = 0.14f) else Color.Transparent)
                        .border(1.dp, if (on) t.primary else Color(0xFF2A4A66))
                        .plainClick { pick(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        l.take(1).uppercase(Locale.getDefault()),
                        fontSize = 11.sp,
                        color = if (on) t.primary else Color(0xFF6A8AA6)
                    )
                }
            }
        }
        DesignStyle.FRUTIGER_AERO -> {
            val pill = RoundedCornerShape(50)
            Row(
                modifier
                    .clip(pill)
                    .background(Brush.verticalGradient(listOf(Color(0x99B4DCFA), Color(0xB3FFFFFF))))
                    .border(1.dp, Color.White, pill)
                    .padding(3.dp)
            ) {
                labels.forEachIndexed { i, l ->
                    val on = i == selected
                    Box(
                        Modifier
                            .clip(pill)
                            .then(
                                if (on) Modifier
                                    .background(Brush.verticalGradient(listOf(Color(0xFF9AF26A), Color(0xFF2FA52A))))
                                    .border(1.dp, Color.White, pill)
                                else Modifier
                            )
                            .plainClick { pick(i) }
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            l,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (on) Color.White else Color(0xFF3A6A98)
                        )
                    }
                }
            }
        }
        DesignStyle.MINIMAL -> Row(modifier, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Text(
                    l.lowercase(Locale.getDefault()),
                    fontSize = 12.sp,
                    color = if (on) t.text else Color(0xFF9A9A9A),
                    textDecoration = if (on) TextDecoration.Underline else null,
                    modifier = Modifier.plainClick { pick(i) }
                )
            }
        }
        DesignStyle.WINDOWS11 -> {
            val shape = RoundedCornerShape(6.dp)
            Row(
                modifier
                    .clip(shape)
                    .background(Color(0x0F000000))
                    .padding(3.dp)
            ) {
                labels.forEachIndexed { i, l ->
                    val on = i == selected
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .then(if (on) Modifier.background(Color.White) else Modifier)
                            .plainClick { pick(i) }
                            .padding(horizontal = 14.dp, vertical = 5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            l,
                            fontSize = 13.sp,
                            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (on) t.text else Color(0xFF444444)
                        )
                    }
                }
            }
        }
        DesignStyle.NEON -> Row(modifier, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val shape = RoundedCornerShape(50)
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Box(
                    Modifier
                        .then(
                            if (on) Modifier.shadow(14.dp, shape, ambientColor = t.accent, spotColor = t.accent)
                            else Modifier
                        )
                        .clip(shape)
                        .background(if (on) t.accent else Color.Transparent)
                        .border(1.5.dp, t.accent, shape)
                        .plainClick { pick(i) }
                        .padding(horizontal = 14.dp, vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        l.uppercase(Locale.getDefault()),
                        fontSize = 11.sp,
                        letterSpacing = 2.sp,
                        color = if (on) t.background else t.accent
                    )
                }
            }
        }
        // Deri tepsi içinde pirinç kaydırıcı parça.
        DesignStyle.SKEUOMORPHISM -> Row(
            modifier.skeuoSurface(
                RoundedCornerShape(8.dp), Color(0xFF4A2F18), Color(0xFF5E3C20),
                pressed = 1f, elevation = 0.dp, gloss = false
            ).padding(3.dp)
        ) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Box(
                    Modifier
                        .then(
                            if (on) Modifier.skeuoSurface(
                                RoundedCornerShape(6.dp), Color(0xFFF0CE7A), Color(0xFFB8892E),
                                grain = Grain.METAL, elevation = 3.dp
                            ) else Modifier
                        )
                        .plainClick { pick(i) }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        l, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        color = if (on) Color(0xFF3A2208) else Color(0xFFFFF3D6)
                    )
                }
            }
        }
        // Çukur tepsi, kabarık seçili parça.
        DesignStyle.NEUMORPHISM -> Row(
            modifier.neuSurface(RoundedCornerShape(14.dp), t.surface, 1f, 3.dp, 6.dp).padding(5.dp)
        ) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Box(
                    Modifier
                        .then(if (on) Modifier.neuSurface(RoundedCornerShape(10.dp), t.surface, 0f, 3.dp, 6.dp) else Modifier)
                        .plainClick { pick(i) }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        l, fontSize = 12.sp,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        color = if (on) t.primary else t.text.copy(alpha = 0.78f)
                    )
                }
            }
        }
        // Cam hap; seçili parça renkli cam.
        DesignStyle.GLASSMORPHISM -> {
            val pill = RoundedCornerShape(50)
            Row(modifier.glassPanel(pill, Color.White, 0.12f, shadow = false).padding(3.dp)) {
                labels.forEachIndexed { i, l ->
                    val on = i == selected
                    Box(
                        Modifier
                            .then(if (on) Modifier.glassPanel(pill, t.primary, 0.32f, shadow = false) else Modifier)
                            .plainClick { pick(i) }
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            l, fontSize = 12.sp,
                            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (on) t.text else t.text.copy(alpha = 0.75f)
                        )
                    }
                }
            }
        }
        // Gümüş jel tepsi, mavi jel seçili parça.
        DesignStyle.Y2K -> {
            val pill = RoundedCornerShape(50)
            Row(modifier.y2kGel(pill, Color.White, Color(0xFFE3E9F8), Color(0xFFB9C4DE)).padding(4.dp)) {
                labels.forEachIndexed { i, l ->
                    val on = i == selected
                    Box(
                        Modifier
                            .then(if (on) Modifier.y2kGel(pill, Color(0xFF8FE8FF), Color(0xFF2A5BFF), Color(0xFF1B3FD0)) else Modifier)
                            .plainClick { pick(i) }
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(l, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (on) Color.White else t.text)
                    }
                }
            }
        }
        // Işıklı çerçeveli koyu tepsi, degrade seçili parça.
        DesignStyle.AURORA -> Row(modifier.auroraPanel(RoundedCornerShape(14.dp), 0.3f).padding(3.dp)) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Box(
                    Modifier
                        .then(if (on) Modifier.auroraButton(RoundedCornerShape(11.dp), 0.4f) else Modifier)
                        .plainClick { pick(i) }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        l, fontSize = 12.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        color = if (on) Color(0xFF06122B) else t.text.copy(alpha = 0.85f)
                    )
                }
            }
        }
        // Çukur kil tepsi, kabarık pastel mor seçili parça.
        DesignStyle.CLAYMORPHISM -> {
            val pill = RoundedCornerShape(50)
            Row(modifier.clayWell(pill, t.background).padding(4.dp)) {
                labels.forEachIndexed { i, l ->
                    val on = i == selected
                    Box(
                        Modifier
                            .then(if (on) Modifier.claySurface(pill, Color(0xFFB8A6FF), 1f, 4.dp, 10.dp) else Modifier)
                            .plainClick { pick(i) }
                            .padding(horizontal = 16.dp, vertical = 7.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(l, fontSize = 12.sp, fontWeight = if (on) FontWeight.ExtraBold else FontWeight.SemiBold, color = if (on) t.text else t.text.copy(alpha = 0.75f))
                    }
                }
            }
        }
        // Material segmentli düğme: ince çerçeve, seçili parça soluk mavi.
        DesignStyle.DARK -> {
            val pill = RoundedCornerShape(20.dp)
            Row(modifier.clip(pill).border(1.dp, Color(0x1FFFFFFF), pill)) {
                labels.forEachIndexed { i, l ->
                    val on = i == selected
                    Box(
                        Modifier
                            .background(if (on) Color(0x338AB4F8) else Color.Transparent)
                            .plainClick { pick(i) }
                            .padding(horizontal = 16.dp, vertical = 7.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(l, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = if (on) t.accent else t.text.copy(alpha = 0.7f))
                    }
                }
            }
        }
         // Cosmic: hap içinde, seçili parça lavanta parıltılı.
        DesignStyle.COSMIC -> Row(modifier.cosmicPanel(RoundedCornerShape(50), 0.3f).padding(3.dp)) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Box(
                    Modifier.background(if (on) CosmicLavender.copy(alpha = 0.25f) else Color.Transparent, RoundedCornerShape(50))
                        .plainClick { pick(i) }.padding(horizontal = 14.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) { Text(l, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = if (on) CosmicGold else t.text.copy(alpha = 0.75f)) }
            }
        }
        // HUD: köşeli parçalar, seçili parça amber çerçeve + parantez.
        DesignStyle.SCIFI_HUD -> Row(modifier, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Box(
                    Modifier.then(if (on) Modifier.hudPanel(HudAmber, 1f, grid = false) else Modifier.border(1.dp, HudAmber.copy(alpha = 0.25f)))
                        .plainClick { pick(i) }.padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        l.uppercase(Locale.getDefault()), fontSize = 11.sp, letterSpacing = 1.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        color = if (on) HudAmber else HudCyan.copy(alpha = 0.75f)
                    )
                }
            }
        }
        // Cyber-Industrial: çelik şerit; seçili parça sarı plaka, siyah yazı.
        DesignStyle.CYBER_INDUSTRIAL -> Row(modifier.steelPlate(androidx.compose.foundation.shape.CutCornerShape(5.dp), SteelDark, 0f, rivets = false).padding(3.dp)) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Box(
                    Modifier.then(if (on) Modifier.yellowPlate(androidx.compose.foundation.shape.CutCornerShape(4.dp), 0f) else Modifier)
                        .plainClick { pick(i) }.padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        l.uppercase(Locale.getDefault()), fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp,
                        color = if (on) Color(0xFF111111) else t.text.copy(alpha = 0.8f)
                    )
                }
            }
        }
        // Neoklasik: serif, harf aralıklı; seçili parçanın altında altın çizgi.
        DesignStyle.NEOCLASSICAL -> Row(modifier, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            labels.forEachIndexed { i, l ->
                val on = i == selected
                Text(
                    l.uppercase(Locale.getDefault()), fontSize = 11.sp, letterSpacing = 2.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
                    color = if (on) t.primary else t.text.copy(alpha = 0.6f),
                    modifier = Modifier.plainClick { pick(i) }
                        .drawBehind { if (on) drawLine(NeoGold, androidx.compose.ui.geometry.Offset(0f, size.height), androidx.compose.ui.geometry.Offset(size.width, size.height), 1.5.dp.toPx()) }
                        .padding(vertical = 5.dp)
                )
            }
        }
    }
}
