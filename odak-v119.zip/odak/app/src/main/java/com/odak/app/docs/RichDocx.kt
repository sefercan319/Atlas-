package com.odak.app.docs

import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler

/** DOCX → zengin model: kalın/italik/renk/boyut, hizalama, girinti, liste imleri, tablo çizgileri/gölge/birleştirme, sayfa boyutu. */
object RichDocx {
    private const val MAX_BLOCKS = 20000

    private fun on(a: Attributes?): Boolean {
        val v = a?.getValue("w:val") ?: return true
        return !(v == "0" || v == "false" || v == "off" || v == "none")
    }
    private fun bdOf(a: Attributes?): Bd? {
        val v = a?.getValue("w:val") ?: return null
        if (v == "nil" || v == "none" || v.isEmpty()) return Bd(0, "000000")
        val sz = a.getValue("w:sz")?.toIntOrNull() ?: 4
        return Bd(sz.coerceAtLeast(2), Rich.hex(a.getValue("w:color")) ?: "000000")
    }

    class RP(var b: Boolean? = null, var i: Boolean? = null, var u: Boolean? = null, var s: Boolean? = null,
             var color: String? = null, var hl: String? = null, var sz: Int = 0, var font: String? = null, var sup: Int = 0) {
        fun over(o: RP) {
            o.b?.let { b = it }; o.i?.let { i = it }; o.u?.let { u = it }; o.s?.let { s = it }
            o.color?.let { color = it }; o.hl?.let { hl = it }; if (o.sz > 0) sz = o.sz; o.font?.let { font = it }; if (o.sup != 0) sup = o.sup
        }
    }

    class St(val id: String) {
        var name = ""; var type = ""; var basedOn: String? = null
        val rp = RP()
        var jc: String? = null; var left: Int? = null; var first: Int? = null; var before: Int? = null; var after: Int? = null; var line: Int? = null
        var num: Int? = null; var ilvl: Int? = null
        val tb = HashMap<String, Bd>()
        var head = 0
        var pTop: Bd? = null; var pBottom: Bd? = null
        val cond = HashMap<String, Cond>()
    }

    class Cond { var fill: String? = null; var b: Boolean? = null; var color: String? = null }

    class Styles {
        val map = HashMap<String, St>()
        var defRp = RP(); var defSz = 22; var defFont: String? = null
        var defAfter = 0; var defBefore = 0; var defLine = 0
        var defPara: String? = null
        fun chain(id: String?): List<St> {
            val out = ArrayList<St>()
            var cur = id?.let { map[it] }
            var n = 0
            while (cur != null && n++ < 12) { out.add(0, cur); cur = cur.basedOn?.let { map[it] } }
            return out
        }
    }

    fun styles(xml: ByteArray?): Styles {
        val s = Styles()
        if (xml == null) return s
        var cur: St? = null
        var inDef = false; var inRpr = false; var inPpr = false; var inTb = false; var inPb = false; var condKey: String? = null
        DocParse.sax(xml, object : DefaultHandler() {
            fun rprAt(a: String, at: Attributes?, rp: RP) {
                when (a) {
                    "w:b" -> rp.b = on(at); "w:i" -> rp.i = on(at)
                    "w:u" -> rp.u = at?.getValue("w:val")?.let { it != "none" } ?: true
                    "w:strike", "w:dstrike" -> rp.s = on(at)
                    "w:color" -> rp.color = Rich.hex(at?.getValue("w:val"))
                    "w:sz" -> rp.sz = at?.getValue("w:val")?.toIntOrNull() ?: 0
                    "w:rFonts" -> rp.font = at?.getValue("w:ascii") ?: at?.getValue("w:hAnsi")
                    "w:vertAlign" -> rp.sup = when (at?.getValue("w:val")) { "superscript" -> 1; "subscript" -> -1; else -> 0 }
                }
            }
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) {
                    "w:docDefaults" -> inDef = true
                    "w:style" -> { cur = St(a?.getValue("w:styleId") ?: "").also { it.type = a?.getValue("w:type") ?: ""; if (a?.getValue("w:default") == "1" && it.type == "paragraph") s.defPara = it.id } }
                    "w:name" -> cur?.let { c -> c.name = a?.getValue("w:val") ?: ""; val n = c.name.lowercase()
                        c.head = when { n.startsWith("heading ") -> n.removePrefix("heading ").trim().toIntOrNull()?.coerceIn(1, 6) ?: 0; n == "title" -> 1; n == "subtitle" -> 2; else -> 0 } }
                    "w:basedOn" -> cur?.basedOn = a?.getValue("w:val")
                    "w:rPr" -> inRpr = true
                    "w:pPr" -> if (condKey == null) inPpr = true
                    "w:tblStylePr" -> condKey = a?.getValue("w:type")
                    "w:shd" -> { val k = condKey; if (k != null) cur?.let { c -> c.cond.getOrPut(k) { Cond() }.fill = Rich.hex(a?.getValue("w:fill")) } }
                    "w:tblBorders" -> if (condKey == null) inTb = true
                    "w:pBdr" -> if (inPpr) inPb = true
                    "w:spacing" -> if (inPpr) {
                        val bf = a?.getValue("w:before")?.toIntOrNull(); val af = a?.getValue("w:after")?.toIntOrNull(); val ln = a?.getValue("w:line")?.toIntOrNull()
                        val c = cur
                        if (c != null) { c.before = bf; c.after = af; if (a?.getValue("w:lineRule").let { it == null || it == "auto" }) c.line = ln }
                        else if (inDef) { s.defBefore = bf ?: 0; s.defAfter = af ?: 0; s.defLine = if (a?.getValue("w:lineRule").let { it == null || it == "auto" }) ln ?: 0 else 0 }
                    }
                    "w:jc" -> if (inPpr) cur?.jc = a?.getValue("w:val")
                    "w:ind" -> if (inPpr) cur?.let { c ->
                        c.left = (a?.getValue("w:left") ?: a?.getValue("w:start"))?.toIntOrNull()
                        c.first = a?.getValue("w:hanging")?.toIntOrNull()?.let { -it } ?: a?.getValue("w:firstLine")?.toIntOrNull()
                    }
                    "w:numId" -> if (inPpr) cur?.num = a?.getValue("w:val")?.toIntOrNull()
                    "w:ilvl" -> if (inPpr) cur?.ilvl = a?.getValue("w:val")?.toIntOrNull()
                    "w:top", "w:bottom" -> if (inPb) { val d = bdOf(a)?.takeIf { it.w > 0 }; cur?.let { c -> if (q == "w:top") c.pTop = d else c.pBottom = d } }
                        else if (inTb) cur?.let { c -> bdOf(a)?.let { c.tb[q.removePrefix("w:")] = it } }
                    "w:left", "w:right", "w:insideH", "w:insideV", "w:start", "w:end" -> if (inTb) {
                        val k = when (q) { "w:start" -> "left"; "w:end" -> "right"; else -> q.removePrefix("w:") }
                        cur?.let { c -> bdOf(a)?.let { c.tb[k] = it } }
                    }
                    else -> if (inRpr) {
                        val c = cur
                        val k = condKey
                        if (c != null && k != null) {
                            val cd = c.cond.getOrPut(k) { Cond() }
                            if (q == "w:b") cd.b = on(a) else if (q == "w:color") cd.color = Rich.hex(a?.getValue("w:val"))
                        } else if (c != null) rprAt(q, a, c.rp) else if (inDef) {
                            rprAt(q, a, s.defRp)
                        }
                    }
                }
            }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) {
                    "w:docDefaults" -> { inDef = false; if (s.defRp.sz > 0) s.defSz = s.defRp.sz; s.defFont = s.defRp.font }
                    "w:style" -> { cur?.let { s.map[it.id] = it }; cur = null }
                    "w:rPr" -> inRpr = false
                    "w:pPr" -> inPpr = false
                    "w:tblStylePr" -> condKey = null
                    "w:tblBorders" -> inTb = false
                    "w:pBdr" -> inPb = false
                }
            }
        })
        // Normal stilinin yazı tipi/boyutu varsayılanı ezer
        s.defPara?.let { id -> s.map[id]?.let { n -> if (n.rp.sz > 0) s.defSz = n.rp.sz; n.rp.font?.let { f -> s.defFont = f } } }
        return s
    }

    class Num {
        val absFmt = HashMap<String, String>()      // "abs:ilvl" → numFmt
        val absTxt = HashMap<String, String>()      // "abs:ilvl" → lvlText
        val absLeft = HashMap<String, Int>()
        val absHang = HashMap<String, Int>()
        val numAbs = HashMap<Int, String>()
    }

    fun numbering(xml: ByteArray?): Num {
        val n = Num()
        if (xml == null) return n
        var abs = ""; var lvl = -1; var curNum = -1
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) {
                    "w:abstractNum" -> abs = a?.getValue("w:abstractNumId") ?: ""
                    "w:lvl" -> lvl = a?.getValue("w:ilvl")?.toIntOrNull() ?: 0
                    "w:numFmt" -> if (lvl >= 0) n.absFmt["$abs:$lvl"] = a?.getValue("w:val") ?: ""
                    "w:lvlText" -> if (lvl >= 0) n.absTxt["$abs:$lvl"] = a?.getValue("w:val") ?: ""
                    "w:ind" -> if (lvl >= 0) {
                        (a?.getValue("w:left") ?: a?.getValue("w:start"))?.toIntOrNull()?.let { n.absLeft["$abs:$lvl"] = it }
                        a?.getValue("w:hanging")?.toIntOrNull()?.let { n.absHang["$abs:$lvl"] = it }
                    }
                    "w:num" -> curNum = a?.getValue("w:numId")?.toIntOrNull() ?: -1
                    "w:abstractNumId" -> if (curNum >= 0) n.numAbs[curNum] = a?.getValue("w:val") ?: ""
                }
            }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) { "w:lvl" -> lvl = -1; "w:abstractNum" -> abs = ""; "w:num" -> curNum = -1 }
            }
        })
        return n
    }

    private fun fmtNum(n: Int, fmt: String): String = when (fmt) {
        "lowerLetter" -> ('a' + (n - 1) % 26).toString()
        "upperLetter" -> ('A' + (n - 1) % 26).toString()
        "lowerRoman" -> roman(n).lowercase()
        "upperRoman" -> roman(n)
        else -> n.toString()
    }
    private fun roman(n0: Int): String {
        var n = n0.coerceIn(1, 3999); val sb = StringBuilder()
        for ((v, s) in listOf(1000 to "M", 900 to "CM", 500 to "D", 400 to "CD", 100 to "C", 90 to "XC", 50 to "L", 40 to "XL", 10 to "X", 9 to "IX", 5 to "V", 4 to "IV", 1 to "I")) while (n >= v) { sb.append(s); n -= v }
        return sb.toString()
    }

    private val HL = mapOf("yellow" to "FFFF00", "green" to "00FF00", "cyan" to "00FFFF", "magenta" to "FF00FF", "blue" to "0000FF", "red" to "FF0000",
        "darkBlue" to "000080", "darkCyan" to "008080", "darkGreen" to "008000", "darkMagenta" to "800080", "darkRed" to "800000", "darkYellow" to "808000",
        "darkGray" to "808080", "lightGray" to "C0C0C0", "black" to "000000", "white" to "FFFFFF")

    private class CellB {
        val paras = ArrayList<RPara>(); var span = 1; var vm = 0; var fill: String? = null; var width = 0; var valign = ""
        val bd = HashMap<String, Bd>()
    }
    private class TblB {
        val rows = ArrayList<ArrayList<RCell>>(); val cols = ArrayList<Int>(); val bd = HashMap<String, Bd>(); var style: String? = null; var look = 0x04A0
        var rowCells = ArrayList<CellB>()
        val rowsB = ArrayList<ArrayList<CellB>>()
    }

    private fun relMap(xml: ByteArray?, base: String): Map<String, String> {
        val m = HashMap<String, String>()
        if (xml == null) return m
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                if (q == "Relationship") {
                    val id = a?.getValue("Id") ?: return; var t = a.getValue("Target") ?: return
                    if (a.getValue("TargetMode") == "External") return
                    val parts = ArrayList<String>()
                    for (x in (if (t.startsWith("/")) t.substring(1) else "$base/$t").split('/')) { if (x == "..") { if (parts.isNotEmpty()) parts.removeAt(parts.size - 1) } else if (x != "." && x.isNotEmpty()) parts.add(x) }
                    m[id] = parts.joinToString("/")
                }
            }
        })
        return m
    }

    private fun noteTexts(xml: ByteArray?): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        if (xml == null) return m
        var id: String? = null; val sb = StringBuilder(); var inT = false
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q) { "w:footnote", "w:endnote" -> { id = a?.getValue("w:id"); sb.setLength(0) }; "w:t" -> inT = true; "w:tab" -> sb.append(' ') }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inT) sb.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) { "w:t" -> inT = false; "w:p" -> if (sb.isNotEmpty() && !sb.endsWith(" ")) sb.append(' '); "w:footnote", "w:endnote" -> { id?.let { m[it] = sb.toString().trim() }; id = null } }
            }
        })
        return m
    }

    internal class AtInfo(val relH: String, val alignH: String, val offH: Long, val relV: String, val alignV: String, val offV: Long, val w: Int, val h: Int)

    /** Çapa bilgisinden sayfa üstünde (x, y, w, h) twips; çözülemezse null. */
    internal fun resolveAt(i: AtInfo, s: PageSetup): IntArray? {
        val pageH = s.w < s.h
        val bx: Int; val aw: Int
        if (i.relH == "page") { bx = 0; aw = s.w } else if (i.relH == "rightMargin") { bx = s.w - s.right; aw = s.right } else if (i.relH == "leftMargin") { bx = 0; aw = s.left } else { bx = s.left; aw = s.w - s.left - s.right }
        val x = when (i.alignH) { "left", "inside" -> bx; "right", "outside" -> bx + aw - i.w; "center" -> bx + (aw - i.w) / 2; else -> if (i.offH != Long.MIN_VALUE) bx + (i.offH / 635).toInt() else return null }
        if (i.relV == "paragraph" || i.relV == "line") {
            val ry = (i.offV / 635).toInt()
            if (x < -2000 || x > s.w || ry < -2000 || ry > s.h) return null
            return intArrayOf(x, ry, i.w, i.h, 1)   // 5. eleman 1: y son paragrafın üstüne göre
        }
        val by: Int; val ah: Int
        when (i.relV) { "page" -> { by = 0; ah = s.h }; "topMargin" -> { by = 0; ah = s.top }; "bottomMargin" -> { by = s.h - s.bottom; ah = s.bottom }; else -> { by = s.top; ah = s.h - s.top - s.bottom } }
        val y = when (i.alignV) { "top", "inside" -> by; "bottom", "outside" -> by + ah - i.h; "center" -> by + (ah - i.h) / 2; else -> by + (i.offV / 635).toInt() }
        if (x < -2000 || y < -2000 || x > s.w || y > s.h || pageH && false) return null
        return intArrayOf(x, y, i.w, i.h)
    }

    /** Belgedeki (mc:Fallback dışındaki) en üst düzey w:txbxContent iç XML'leri, belge sırasıyla. */
    internal fun textBoxes(x: String): List<String> {
        val out = ArrayList<String>()
        val tag = Regex("<(/?)(w:txbxContent|mc:Fallback)(\\s[^>]*)?(/?)>")
        var boxDepth = 0; var fbDepth = 0; var start = 0
        for (m in tag.findAll(x)) {
            val close = m.groupValues[1] == "/"; val self = m.groupValues[4] == "/"
            if (self) continue
            if (m.groupValues[2] == "mc:Fallback") { fbDepth += if (close) -1 else 1; if (fbDepth < 0) fbDepth = 0; continue }
            if (!close) { if (boxDepth == 0) start = m.range.last + 1; boxDepth++ }
            else if (boxDepth > 0) { boxDepth--; if (boxDepth == 0 && fbDepth == 0 && out.size < 200) out.add(x.substring(start, m.range.first)) }
        }
        return out
    }

    fun parse(doc: ByteArray, stylesXml: ByteArray?, numXml: ByteArray?, e: Map<String, ByteArray> = emptyMap(), relsPath: String = "word/_rels/document.xml.rels", depth: Int = 0): RichPage {
        val st = styles(stylesXml)
        val nm = numbering(numXml)
        val rels = relMap(e[relsPath], "word")
        val notes = ArrayList<String>()
        var hdrRef: String? = null; var ftrRef: String? = null
        var extCx = 0; var extCy = 0; var fb = 0
        var imgBytes = 0L
        val blocks = ArrayList<RBlock>()
        val docStr = if (depth < 2) String(doc, Charsets.UTF_8) else ""
        val boxes = if (depth < 2 && docStr.contains("txbxContent")) textBoxes(docStr) else emptyList()
        val rootTag = Regex("<w:document\\b[^>]*>").find(docStr)?.value ?: "<w:document>"
        var boxIdx = 0
        val pendingBoxes = ArrayList<List<RBlock>>(); val pendingFloat = ArrayList<Triple<String, Int, Int>>(); val pendingAt = ArrayList<AtInfo?>(); val atList = ArrayList<Pair<RTable, AtInfo>>()
        var aOn = false; var aWrap = false; var aCx = 0; var aAlign = ""; var aOff = Long.MIN_VALUE; var aPos = ""; var aVRel = ""; var aVOff = 0L; var aHRel = ""; var aAlignV = ""; var aCy = 0; var capK = 0; val capB = StringBuilder()
        var setup = PageSetup()
        val counters = HashMap<Int, IntArray>()

        // paragraf durumu
        var pStyle: String? = null
        var jc: String? = null; var left: Int? = null; var first: Int? = null; var before: Int? = null; var after: Int? = null; var line: Int? = null
        var pTop: Bd? = null; var pBottom: Bd? = null; var pFill: String? = null; var pPb = false
        var numId = -1; var ilvl = 0
        val runs = ArrayList<RRun>()
        var inP = false; var inPPr = false; var inRPr = false; var inRun = false; var inT = false
        var inPBdr = false; var inTcPr = false; var inTblPr = false; var inTcB = false; var inTblB = false
        var txbx = 0; var inSect = false
        val direct = RP(); var rStyle: String? = null
        val rtext = StringBuilder()
        var pendingPb = false
        // tablo durumu
        var tblDepth = 0
        var tb: TblB? = null
        var cell: CellB? = null

        fun addPara(p: RPara) {
            if (tblDepth >= 1) { cell?.paras?.add(p) } else if (blocks.size < MAX_BLOCKS) blocks.add(p)
        }

        fun flushRun() {
            if (rtext.isEmpty()) { direct.b = null; direct.i = null; direct.u = null; direct.s = null; direct.color = null; direct.hl = null; direct.sz = 0; direct.font = null; direct.sup = 0; rStyle = null; return }
            val eff = RP()
            eff.over(st.defRp)
            st.chain(pStyle ?: st.defPara).forEach { eff.over(it.rp) }
            st.chain(rStyle).forEach { eff.over(it.rp) }
            eff.over(direct)
            val sz = if (eff.sz > 0) eff.sz else st.defSz
            val fx = SymbolFonts.fix(rtext.toString(), eff.font)
            runs.add(RRun(fx.first, eff.b == true, eff.i == true, eff.u == true, eff.s == true, eff.color, eff.hl, sz, fx.second, eff.sup))
            rtext.setLength(0)
            direct.b = null; direct.i = null; direct.u = null; direct.s = null; direct.color = null; direct.hl = null; direct.sz = 0; direct.font = null; direct.sup = 0; rStyle = null
        }

        fun endPara() {
            val chain = st.chain(pStyle ?: st.defPara)
            var head = chain.lastOrNull { it.head > 0 }?.head ?: 0
            var jcv = jc; var lv = left; var fv = first; var bv = before; var av = after; var lnv = line
            var nId = numId; var il = ilvl
            var tp = pTop; var bt = pBottom
            for (c in chain) {
                if (jc == null) c.jc?.let { jcv = it }
                if (left == null) c.left?.let { lv = it }
                if (first == null) c.first?.let { fv = it }
                if (before == null) c.before?.let { bv = it }
                if (after == null) c.after?.let { av = it }
                if (line == null) c.line?.let { lnv = it }
                if (pTop == null) c.pTop?.let { tp = it }
                if (pBottom == null) c.pBottom?.let { bt = it }
                if (numId < 0) c.num?.let { nId = it }
                if (numId < 0) c.ilvl?.let { il = it }
            }
            var marker = ""
            if (nId > 0) {
                val abs = nm.numAbs[nId]
                if (abs != null) {
                    val key = "$abs:$il"
                    val fmt = nm.absFmt[key] ?: "decimal"
                    val cnt = counters.getOrPut(nId) { IntArray(9) }
                    if (fmt == "none") marker = ""
                    else if (fmt == "bullet") {
                        val t = nm.absTxt[key] ?: "•"
                        marker = if (t.isNotEmpty() && t[0].code in 0x20..0x24FF) t.take(1).let { if (it == "o" || it == "-" || it == "·") it else if (t[0].code < 0x80) "•" else it } else "•"
                    } else {
                        cnt[il.coerceIn(0, 8)]++
                        for (k in il + 1..8) cnt[k] = 0
                        var pat = nm.absTxt[key] ?: "%${il + 1}."
                        for (k in 0..il) pat = pat.replace("%${k + 1}", fmtNum(cnt[k].coerceAtLeast(1), nm.absFmt["$abs:$k"] ?: "decimal"))
                        marker = pat
                    }
                    if (left == null && lv == null) nm.absLeft[key]?.let { lv = it }
                    if (first == null && fv == null) nm.absHang[key]?.let { fv = -it }
                }
            }
            flushRun()
            if (head > 0 && st.map[pStyle ?: ""] == null && runs.isNotEmpty()) {
                val sz = when (head) { 1 -> 32; 2 -> 26; 3 -> 24; else -> 22 }
                for (k in runs.indices) { val r = runs[k]; runs[k] = RRun(r.text, true, r.i, r.u, r.s, r.color, r.hl, sz, r.font, r.sup) }
            }
            val al = when (jcv) { "center" -> "center"; "right", "end" -> "right"; "both", "distribute" -> "justify"; else -> "" }
            addPara(RPara(ArrayList(runs), al, head, marker, lv ?: 0, fv ?: 0, bv ?: -1, av ?: -1, lnv ?: 0, tp, bt, pFill, pPb || pendingPb))
            pendingPb = false
            if (txbx == 0 && pendingBoxes.isNotEmpty()) {
                for ((bi, bx) in pendingBoxes.withIndex()) {
                    val ps = bx.filterIsInstance<RPara>()
                    val fl = pendingFloat.getOrNull(bi) ?: Triple("", 8000, 0)
                    val atx = pendingAt.getOrNull(bi)
                    if (tblDepth >= 1) ps.forEach { cell?.paras?.add(it) }
                    else if (blocks.size < MAX_BLOCKS) {
                        val bd = Bd(6, "7F7F7F")
                        val tb = RTable(listOf(listOf(RCell(if (ps.isEmpty()) listOf(RPara(emptyList())) else ps.take(200), 1, 0, null, bd, bd, bd, bd))), listOf(if (atx != null) atx.w else if (fl.first.isNotEmpty()) fl.second else 8000), fl.first, fl.third)
                        blocks.add(tb)
                        if (atx != null) atList.add(tb to atx)
                        if (fl.first.isEmpty() && atx == null) blocks.add(RPara(emptyList(), before = 0, after = 0))
                    }
                }
                pendingBoxes.clear(); pendingFloat.clear(); pendingAt.clear()
            }
            runs.clear()
            pStyle = null; jc = null; left = null; first = null; before = null; after = null; line = null
            pTop = null; pBottom = null; pFill = null; pPb = false; numId = -1; ilvl = 0
        }

        DocParse.sax(doc, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                if (q == "mc:Fallback") { fb++; return }
                if (fb > 0) return
                if (txbx > 0) { if (q == "w:txbxContent") txbx++; return }
                when (q) {
                    "wp:anchor" -> { aOn = true; aWrap = false; aCx = 0; aAlign = ""; aOff = Long.MIN_VALUE; aPos = ""; aVRel = ""; aVOff = 0L; aHRel = ""; aAlignV = ""; aCy = 0 }
                    "wp:inline" -> aOn = false
                    "wp:positionH" -> { aPos = "H"; aHRel = a?.getValue("relativeFrom") ?: "" }
                    "wp:positionV" -> { aPos = "V"; aVRel = a?.getValue("relativeFrom") ?: "" }
                    "wp:align" -> if (aOn && aPos == "H") { capK = 1; capB.setLength(0) } else if (aOn && aPos == "V") { capK = 4; capB.setLength(0) }
                    "wp:posOffset" -> if (aOn && aPos == "H") { capK = 2; capB.setLength(0) } else if (aOn && aPos == "V") { capK = 3; capB.setLength(0) }
                    "wp:extent" -> if (aOn && aCx == 0) { aCx = (a?.getValue("cx")?.toLongOrNull() ?: 0L).let { (it / 635).toInt() }; aCy = (a?.getValue("cy")?.toLongOrNull() ?: 0L).let { (it / 635).toInt() } }
                    "wp:wrapSquare", "wp:wrapTight", "wp:wrapThrough" -> aWrap = true
                    "w:txbxContent" -> {
                        var flt = Triple("", 8000, 0)
                        val atI = if (aOn && aCx > 0 && aCy > 0 && (aVRel in setOf("page", "margin", "topMargin", "bottomMargin") || !aWrap && (aVRel == "paragraph" || aVRel == "line")) && (aOff != Long.MIN_VALUE || aAlign.isNotEmpty()) && (aVOff != 0L || aAlignV.isNotEmpty() || aVRel != "")) AtInfo(aHRel, aAlign, aOff, aVRel, aAlignV, aVOff, aCx, aCy) else null
                        if (aOn && aWrap && aCx > 0) {
                            val side = when { aAlign == "left" -> "left"; aAlign == "right" -> "right"; aOff != Long.MIN_VALUE -> if ((aOff / 635 + aCx / 2) < 5953) "left" else "right"; else -> "" }
                            flt = Triple(side, aCx.coerceIn(1500, 8000), if (aVRel == "paragraph" || aVRel == "line") (aVOff / 635).toInt() else 0)
                        }
                        if (boxIdx < boxes.size) {
                            val inner = try { parse((rootTag + "<w:body>" + boxes[boxIdx] + "</w:body></w:document>").toByteArray(Charsets.UTF_8), stylesXml, numXml, e, relsPath, depth + 1).blocks } catch (x: Exception) { emptyList() }
                            if (inner.isNotEmpty()) { pendingBoxes.add(inner); pendingFloat.add(flt); pendingAt.add(atI) }
                        }
                        boxIdx++; txbx++
                    }
                    "w:headerReference" -> if (inSect && a?.getValue("w:type") == "default" && hdrRef == null) hdrRef = a.getValue("r:id")
                    "w:footerReference" -> if (inSect && a?.getValue("w:type") == "default" && ftrRef == null) ftrRef = a.getValue("r:id")
                    "w:tblLook" -> if (tblDepth == 1) tb?.let { t ->
                        val v = a?.getValue("w:val")?.toIntOrNull(16)
                        if (v != null) t.look = v else {
                            var f = 0
                            if (a?.getValue("w:firstRow") == "1") f = f or 0x20; if (a?.getValue("w:lastRow") == "1") f = f or 0x40
                            if (a?.getValue("w:firstColumn") == "1") f = f or 0x80; if (a?.getValue("w:lastColumn") == "1") f = f or 0x100
                            if (a?.getValue("w:noHBand") == "1") f = f or 0x200
                            t.look = f
                        }
                    }
                    "wp:extent" -> { extCx = a?.getValue("cx")?.toIntOrNull() ?: 0; extCy = a?.getValue("cy")?.toIntOrNull() ?: 0 }
                    "a:blip" -> if (inRun) {
                        val data = a?.getValue("r:embed")?.let { rels[it] }?.let { e[it] }
                        val mime = data?.let { RImg.mimeOf("", it) }
                        if (data != null && mime != null && imgBytes + data.size <= 24L * 1024 * 1024) {
                            imgBytes += data.size
                            val px = RImg.pixelSize(data)
                            val w = if (extCx > 0) (extCx / 635L).toInt() else (px?.first ?: 200) * 15
                            val h = if (extCy > 0) (extCy / 635L).toInt() else (px?.second ?: 150) * 15
                            flushRun()
                            runs.add(RRun("", img = RImg(data, mime, w.coerceAtLeast(100), h.coerceAtLeast(100))))
                        }
                    }
                    "w:footnoteReference", "w:endnoteReference" -> if (inRun) {
                        val id = a?.getValue("w:id") ?: ""
                        flushRun(); notes.add(id)
                        runs.add(RRun("[" + notes.size + "]", sup = 1, sz = st.defSz))
                    }
                    "w:sectPr" -> inSect = true
                    "w:pgSz" -> if (inSect) {
                        val w = a?.getValue("w:w")?.toIntOrNull() ?: setup.w; val h = a?.getValue("w:h")?.toIntOrNull() ?: setup.h
                        setup = PageSetup(w, h, setup.top, setup.right, setup.bottom, setup.left)
                    }
                    "w:pgMar" -> if (inSect) setup = PageSetup(setup.w, setup.h,
                        a?.getValue("w:top")?.toIntOrNull() ?: setup.top, a?.getValue("w:right")?.toIntOrNull() ?: setup.right,
                        a?.getValue("w:bottom")?.toIntOrNull() ?: setup.bottom, a?.getValue("w:left")?.toIntOrNull() ?: setup.left)
                    "w:tbl" -> { tblDepth++; if (tblDepth == 1) tb = TblB() }
                    "w:tblPr" -> if (tblDepth == 1) inTblPr = true
                    "w:tblStyle" -> if (tblDepth == 1 && inTblPr) tb?.style = a?.getValue("w:val")
                    "w:tblBorders" -> if (tblDepth == 1 && inTblPr) inTblB = true
                    "w:gridCol" -> if (tblDepth == 1) tb?.cols?.add(a?.getValue("w:w")?.toIntOrNull() ?: 0)
                    "w:tr" -> if (tblDepth == 1) tb?.rowCells = ArrayList()
                    "w:tc" -> if (tblDepth == 1) cell = CellB()
                    "w:tcPr" -> if (tblDepth == 1) inTcPr = true
                    "w:tcBorders" -> if (tblDepth == 1 && inTcPr) inTcB = true
                    "w:gridSpan" -> if (inTcPr) cell?.span = a?.getValue("w:val")?.toIntOrNull()?.coerceIn(1, 60) ?: 1
                    "w:vMerge" -> if (inTcPr) cell?.vm = if (a?.getValue("w:val") == "restart") 1 else 2
                    "w:tcW" -> if (inTcPr) cell?.width = a?.getValue("w:w")?.toIntOrNull() ?: 0
                    "w:vAlign" -> if (inTcPr) cell?.valign = a?.getValue("w:val") ?: ""
                    "w:top", "w:left", "w:bottom", "w:right", "w:insideH", "w:insideV", "w:start", "w:end" -> {
                        val k = when (q) { "w:start" -> "left"; "w:end" -> "right"; else -> q.removePrefix("w:") }
                        if (inTcB) bdOf(a)?.let { cell?.bd?.set(k, it) }
                        else if (inTblB) bdOf(a)?.let { tb?.bd?.set(k, it) }
                        else if (inPBdr && inPPr) { val d = bdOf(a); if (k == "top") pTop = d?.takeIf { it.w > 0 } else if (k == "bottom") pBottom = d?.takeIf { it.w > 0 } }
                    }
                    "w:pBdr" -> if (inPPr) inPBdr = true
                    "w:shd" -> {
                        val f = Rich.hex(a?.getValue("w:fill"))
                        if (inTcPr) cell?.fill = f
                        else if (inPPr) pFill = f
                        else if (inRPr) direct.hl = f ?: direct.hl
                    }
                    "w:p" -> { inP = true; runs.clear() }
                    "w:pPr" -> if (inP && !inRun) inPPr = true
                    "w:pStyle" -> if (inPPr) pStyle = a?.getValue("w:val")
                    "w:jc" -> if (inPPr) jc = a?.getValue("w:val")
                    "w:ind" -> if (inPPr) {
                        left = (a?.getValue("w:left") ?: a?.getValue("w:start"))?.toIntOrNull()
                        first = a?.getValue("w:hanging")?.toIntOrNull()?.let { -it } ?: a?.getValue("w:firstLine")?.toIntOrNull()
                    }
                    "w:spacing" -> if (inPPr) {
                        before = a?.getValue("w:before")?.toIntOrNull(); after = a?.getValue("w:after")?.toIntOrNull()
                        if (a?.getValue("w:lineRule").let { it == null || it == "auto" }) line = a?.getValue("w:line")?.toIntOrNull()
                    }
                    "w:pageBreakBefore" -> if (inPPr) pPb = on(a)
                    "w:numId" -> if (inPPr) numId = a?.getValue("w:val")?.toIntOrNull() ?: -1
                    "w:ilvl" -> if (inPPr) ilvl = a?.getValue("w:val")?.toIntOrNull()?.coerceIn(0, 8) ?: 0
                    "w:r" -> if (inP) { inRun = true; rtext.setLength(0) }
                    "w:rPr" -> if (inRun) inRPr = true
                    "w:rStyle" -> if (inRPr) rStyle = a?.getValue("w:val")
                    "w:b" -> if (inRPr) direct.b = on(a)
                    "w:i" -> if (inRPr) direct.i = on(a)
                    "w:u" -> if (inRPr) direct.u = a?.getValue("w:val")?.let { it != "none" } ?: true
                    "w:strike", "w:dstrike" -> if (inRPr) direct.s = on(a)
                    "w:color" -> if (inRPr) direct.color = Rich.hex(a?.getValue("w:val"))
                    "w:highlight" -> if (inRPr) direct.hl = HL[a?.getValue("w:val") ?: ""]
                    "w:sz" -> if (inRPr) direct.sz = a?.getValue("w:val")?.toIntOrNull() ?: 0
                    "w:rFonts" -> if (inRPr) direct.font = a?.getValue("w:ascii") ?: a?.getValue("w:hAnsi")
                    "w:vertAlign" -> if (inRPr) direct.sup = when (a?.getValue("w:val")) { "superscript" -> 1; "subscript" -> -1; else -> 0 }
                    "w:t" -> if (inRun) inT = true
                    "w:tab" -> if (inRun && !inRPr && !inPPr) rtext.append('\t')
                    "w:br", "w:cr" -> if (inRun) {
                        if (a?.getValue("w:type") == "page") pendingPb = true else rtext.append('\n')
                    }
                    "w:noBreakHyphen" -> if (inRun) rtext.append('-')
                    "w:sym" -> if (inRun) { val c = a?.getValue("w:char")?.toIntOrNull(16); if (c != null) rtext.append(SymbolFonts.mapChar(a.getValue("w:font") ?: "Symbol", c)) }
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inT && txbx == 0) rtext.append(ch, s, len); if (capK != 0) capB.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                if (q == "mc:Fallback") { fb = maxOf(0, fb - 1); return }
                if (fb > 0) return
                if (txbx > 0) { if (q == "w:txbxContent") txbx--; return }
                when (q) {
                    "wp:align" -> if (capK == 1) { aAlign = capB.toString().trim(); capK = 0 } else if (capK == 4) { aAlignV = capB.toString().trim(); capK = 0 }
                    "wp:posOffset" -> if (capK == 2) { aOff = capB.toString().trim().toLongOrNull() ?: Long.MIN_VALUE; capK = 0 } else if (capK == 3) { aVOff = capB.toString().trim().toLongOrNull() ?: 0L; capK = 0 }
                    "w:sectPr" -> inSect = false
                    "w:t" -> inT = false
                    "w:r" -> if (inRun) { flushRun(); inRun = false; inRPr = false }
                    "w:rPr" -> inRPr = false
                    "w:pBdr" -> inPBdr = false
                    "w:pPr" -> inPPr = false
                    "w:p" -> if (inP) { endPara(); inP = false }
                    "w:tcBorders" -> inTcB = false
                    "w:tblBorders" -> inTblB = false
                    "w:tblPr" -> inTblPr = false
                    "w:tcPr" -> inTcPr = false
                    "w:tc" -> if (tblDepth == 1) { cell?.let { tb?.rowCells?.add(it) }; cell = null }
                    "w:tr" -> if (tblDepth == 1) tb?.let { t -> finishRow(t, st) }
                    "w:tbl" -> {
                        if (tblDepth == 1) tb?.let { t -> if (blocks.size < MAX_BLOCKS) blocks.add(finishTable(t, st)) }
                        tblDepth = maxOf(0, tblDepth - 1)
                        if (tblDepth == 0) { tb = null; cell = null }
                    }
                }
            }
        })
        var hdr: List<RPara> = emptyList(); var ftr: List<RPara> = emptyList()
        if (depth == 0) {
            fun part(ref: String?): List<RPara> {
                val path = ref?.let { rels[it] } ?: return emptyList()
                val x = e[path] ?: return emptyList()
                val rp = try { parse(x, stylesXml, numXml, e, path.substringBeforeLast('/') + "/_rels/" + path.substringAfterLast('/') + ".rels", 1) } catch (ex: Exception) { return emptyList() }
                return rp.blocks.filterIsInstance<RPara>().filter { it.runs.any { r -> r.text.isNotBlank() || r.img != null } }
            }
            hdr = part(hdrRef); ftr = part(ftrRef)
            if (notes.isNotEmpty()) {
                val texts = noteTexts(e["word/footnotes.xml"]) + noteTexts(e["word/endnotes.xml"])
                blocks.add(RPara(emptyList(), before = 240, after = 60, top = Bd(4, "999999")))
                notes.forEachIndexed { k, id -> texts[id]?.takeIf { it.isNotEmpty() }?.let { t -> blocks.add(RPara(listOf(RRun("[" + (k + 1) + "] " + t, sz = maxOf(16, st.defSz - 2))), after = 40)) } }
            }
        }
        for ((t, i) in atList) t.at = resolveAt(i, setup)
        return RichPage(blocks, setup, st.defSz, st.defFont, st.defAfter, st.defLine, hdr, ftr)
    }

    private fun finishRow(t: TblB, st: Styles) {
        t.rowsB.add(ArrayList(t.rowCells))
        t.rowCells = ArrayList()
    }

    private fun finishTable(t: TblB, st: Styles): RTable {
        val rowsB = t.rowsB
        val sty = HashMap<String, Bd>()
        st.chain(t.style).forEach { sty.putAll(it.tb) }
        sty.putAll(t.bd)
        val nRows = rowsB.size
        val gridN = maxOf(t.cols.size, rowsB.maxOfOrNull { r -> r.sumOf { it.span } } ?: 0)
        fun pick(d: Bd?): Bd? = d?.takeIf { it.w > 0 }
        val conds = st.chain(t.style).flatMap { it.cond.entries }.groupBy({ it.key }, { it.value }).mapValues { (_, v) -> v.last() }
        val rows = ArrayList<List<RCell>>()
        rowsB.forEachIndexed { r, cells ->
            var c = 0
            val out = ArrayList<RCell>()
            for (cb in cells) {
                val tgt = sty
                val topD = cb.bd["top"] ?: (if (r == 0) tgt["top"] else tgt["insideH"])
                val botD = cb.bd["bottom"] ?: (if (r == nRows - 1) tgt["bottom"] else tgt["insideH"])
                val lefD = cb.bd["left"] ?: (if (c == 0) tgt["left"] else tgt["insideV"])
                val rigD = cb.bd["right"] ?: (if (c + cb.span >= gridN) tgt["right"] else tgt["insideV"])
                var fill = cb.fill; var paras: List<RPara> = ArrayList(cb.paras)
                val firstRow = t.look and 0x20 != 0 && r == 0; val lastRow = t.look and 0x40 != 0 && r == nRows - 1
                val firstCol = t.look and 0x80 != 0 && c == 0; val lastCol = t.look and 0x100 != 0 && c + cb.span >= gridN
                val k = r - (if (t.look and 0x20 != 0) 1 else 0)
                val key = when { firstRow -> "firstRow"; lastRow -> "lastRow"; firstCol -> "firstCol"; lastCol -> "lastCol"
                    t.look and 0x200 == 0 && k >= 0 -> if (k % 2 == 0) "band1Horz" else "band2Horz"; else -> null }
                val cd = key?.let { conds[it] }
                if (cd != null) {
                    if (fill == null) fill = cd.fill
                    if (cd.b == true || cd.color != null) paras = paras.map { p -> RPara(p.runs.map { x -> RRun(x.text, x.b || cd.b == true, x.i, x.u, x.s, x.color ?: cd.color, x.hl, x.sz, x.font, x.sup, x.href, x.img) }, p.align, p.head, p.marker, p.left, p.first, p.before, p.after, p.line, p.top, p.bottom, p.fill, p.pageBreak) }
                }
                out.add(RCell(paras, cb.span, cb.vm, fill, pick(topD), pick(lefD), pick(botD), pick(rigD), cb.width, cb.valign))
                c += cb.span
            }
            rows.add(out)
        }
        return RTable(rows, ArrayList(t.cols))
    }
}
