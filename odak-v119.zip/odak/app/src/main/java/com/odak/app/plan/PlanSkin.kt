package com.odak.app.plan

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.odak.app.theme.DesignStyle

data class EvColor(val bg: Color, val border: Color, val text: Color)

enum class Marks { BARS, ORBS, DOTS, CHIPS, GLOW }

enum class NumStyle { PLAIN, RING, FILLED }

/** Hafta ve ay ızgarasının tasarıma göre görünümü. */
data class GridSkin(
    val line: Color,
    val hourLabel: Color,
    val dayLabel: Color,
    val dayNum: Color,
    val todayAccent: Color,
    val todayOnAccent: Color,
    val todayColBg: Color,
    val events: List<EvColor>,
    val eventShape: Shape,
    val eventBorderW: Dp,
    val leftBar: Boolean,
    val eventUpper: Boolean,
    val cellShape: Shape,
    val cellBg: Color,
    val cellBorder: Color,
    val cellBorderW: Dp,
    val todayCellBg: Color,
    val todayCellText: Color,
    val otherAlpha: Float,
    val marks: Marks,
    val markColors: List<Color>,
    val numberStyle: NumStyle,
    val centerNumber: Boolean
)

fun skinFor(style: DesignStyle): GridSkin = when (style) {
    DesignStyle.FUTURISTIC -> GridSkin(
        line = Color(0x2400E5FF),
        hourLabel = Color(0xFF5F86A0),
        dayLabel = Color(0xFF6F94AD),
        dayNum = Color(0xFFCFEEFF),
        todayAccent = Color(0xFF00E5FF),
        todayOnAccent = Color(0xFF04060C),
        todayColBg = Color(0x0F00E5FF),
        events = listOf(
            EvColor(Color(0x2E00E5FF), Color(0xFF00E5FF), Color(0xFFBFF6FF)),
            EvColor(Color(0x477C4DFF), Color(0xFF7C4DFF), Color(0xFFE0D4FF)),
            EvColor(Color(0x2EFF2DAA), Color(0xFFFF2DAA), Color(0xFFFFD0EE))
        ),
        eventShape = RectangleShape,
        eventBorderW = 1.dp,
        leftBar = true,
        eventUpper = true,
        cellShape = CutCornerShape(topStart = 8.dp),
        cellBg = Color(0xB30A1428),
        cellBorder = Color(0xFF17384C),
        cellBorderW = 1.dp,
        todayCellBg = Color(0x2900E5FF),
        todayCellText = Color(0xFF00E5FF),
        otherAlpha = 0.35f,
        marks = Marks.BARS,
        markColors = listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF), Color(0xFFFF2DAA)),
        numberStyle = NumStyle.PLAIN,
        centerNumber = false
    )
    DesignStyle.TERMINAL -> GridSkin(
        line = Color(0x2433FF66),
        hourLabel = Color(0xFF3C8A50),
        dayLabel = Color(0xFF4FA865),
        dayNum = Color(0xFFCFFFD8),
        todayAccent = Color(0xFF33FF66),
        todayOnAccent = Color(0xFF04060C),
        todayColBg = Color(0x0F33FF66),
        events = listOf(
            EvColor(Color(0x2E33FF66), Color(0xFF33FF66), Color(0xFFCFFFD8)),
            EvColor(Color(0x47FFB000), Color(0xFFFFB000), Color(0xFFFFE9B0)),
            EvColor(Color(0x2E1FA84A), Color(0xFF1FA84A), Color(0xFFB8FFC8))
        ),
        eventShape = RectangleShape,
        eventBorderW = 1.dp,
        leftBar = true,
        eventUpper = true,
        cellShape = CutCornerShape(topStart = 8.dp),
        cellBg = Color(0xB307160A),
        cellBorder = Color(0xFF14502A),
        cellBorderW = 1.dp,
        todayCellBg = Color(0x2933FF66),
        todayCellText = Color(0xFF33FF66),
        otherAlpha = 0.35f,
        marks = Marks.BARS,
        markColors = listOf(Color(0xFF33FF66), Color(0xFFFFB000), Color(0xFF1FA84A)),
        numberStyle = NumStyle.PLAIN,
        centerNumber = false
    )
    DesignStyle.FRUTIGER_AERO -> GridSkin(
        line = Color(0x382878C8),
        hourLabel = Color(0xFF24527F),
        dayLabel = Color(0xFF24527F),
        dayNum = Color(0xFF0A3A78),
        todayAccent = Color(0xFF2FA52A),
        todayOnAccent = Color.White,
        todayColBg = Color(0x297CFC00),
        events = listOf(
            EvColor(Color(0xFF3F9BEA), Color.White, Color.White),
            EvColor(Color(0xFF4CBF3A), Color.White, Color.White),
            EvColor(Color(0xFFF0A020), Color.White, Color.White)
        ),
        eventShape = RoundedCornerShape(7.dp),
        eventBorderW = 1.dp,
        leftBar = false,
        eventUpper = false,
        cellShape = RoundedCornerShape(10.dp),
        cellBg = Color(0xCCFFFFFF),
        cellBorder = Color.White,
        cellBorderW = 1.dp,
        todayCellBg = Color(0xFF4CBF3A),
        todayCellText = Color.White,
        otherAlpha = 0.45f,
        marks = Marks.ORBS,
        markColors = listOf(Color(0xFF1C78E6), Color(0xFF2FA52A), Color(0xFFEE8A10)),
        numberStyle = NumStyle.PLAIN,
        centerNumber = false
    )
    DesignStyle.MINIMAL -> GridSkin(
        line = Color(0xFFEFEEEA),
        hourLabel = Color(0xFF6E6E6E),
        dayLabel = Color(0xFF6B6B6B),
        dayNum = Color(0xFF161616),
        todayAccent = Color(0xFF161616),
        todayOnAccent = Color(0xFFFAF9F6),
        todayColBg = Color.Transparent,
        events = listOf(
            EvColor(Color(0x0D161616), Color(0xFF161616), Color(0xFF161616)),
            EvColor(Color(0x08161616), Color(0xFF8A8A8A), Color(0xFF161616)),
            EvColor(Color.Transparent, Color(0xFFC4C4C4), Color(0xFF161616))
        ),
        eventShape = RectangleShape,
        eventBorderW = 1.dp,
        leftBar = true,
        eventUpper = false,
        cellShape = RectangleShape,
        cellBg = Color.Transparent,
        cellBorder = Color.Transparent,
        cellBorderW = 0.dp,
        todayCellBg = Color.Transparent,
        todayCellText = Color(0xFF161616),
        otherAlpha = 0.3f,
        marks = Marks.DOTS,
        markColors = listOf(Color(0xFF161616), Color(0xFF8A8A8A), Color(0xFFC4C4C4)),
        numberStyle = NumStyle.RING,
        centerNumber = true
    )
    DesignStyle.WINDOWS11 -> GridSkin(
        line = Color(0xFFE8E8E8),
        hourLabel = Color(0xFF6F6F6F),
        dayLabel = Color(0xFF595959),
        dayNum = Color(0xFF1A1A1A),
        todayAccent = Color(0xFF0067C0),
        todayOnAccent = Color.White,
        todayColBg = Color(0x0D0067C0),
        events = listOf(
            EvColor(Color(0xFFCFE4F7), Color(0xFF0067C0), Color(0xFF0B3C6B)),
            EvColor(Color(0xFFD9F0E2), Color(0xFF107C10), Color(0xFF0B4A0B)),
            EvColor(Color(0xFFFDE7C8), Color(0xFFC25700), Color(0xFF6B3000))
        ),
        eventShape = RoundedCornerShape(4.dp),
        eventBorderW = 1.dp,
        leftBar = true,
        eventUpper = false,
        cellShape = RectangleShape,
        cellBg = Color.Transparent,
        cellBorder = Color(0xFFE5E5E5),
        cellBorderW = 0.5.dp,
        todayCellBg = Color(0x0F0067C0),
        todayCellText = Color.White,
        otherAlpha = 0.4f,
        marks = Marks.CHIPS,
        markColors = listOf(Color(0xFF0067C0), Color(0xFF107C10), Color(0xFFC25700)),
        numberStyle = NumStyle.FILLED,
        centerNumber = false
    )
    DesignStyle.NEON -> GridSkin(
        line = Color(0x4D05D9E8),
        hourLabel = Color(0xFF05D9E8),
        dayLabel = Color(0xFF8FA4D8),
        dayNum = Color(0xFFE8FBFF),
        todayAccent = Color(0xFFFF2A6D),
        todayOnAccent = Color.White,
        todayColBg = Color(0x1AFF2A6D),
        events = listOf(
            EvColor(Color(0xD9080432), Color(0xFFFF2A6D), Color(0xFFFFC0D6)),
            EvColor(Color(0xD9080432), Color(0xFF05D9E8), Color(0xFFC8FAFF)),
            EvColor(Color(0xD9080432), Color(0xFFB66BFF), Color(0xFFE6D2FF))
        ),
        eventShape = RoundedCornerShape(7.dp),
        eventBorderW = 1.5.dp,
        leftBar = false,
        eventUpper = false,
        cellShape = RoundedCornerShape(9.dp),
        cellBg = Color(0x99080432),
        cellBorder = Color(0x6605D9E8),
        cellBorderW = 1.dp,
        todayCellBg = Color(0xFFFF2A6D),
        todayCellText = Color.White,
        otherAlpha = 0.3f,
        marks = Marks.GLOW,
        markColors = listOf(Color(0xFFFF2A6D), Color(0xFF05D9E8), Color(0xFFB66BFF)),
        numberStyle = NumStyle.PLAIN,
        centerNumber = false
    )
    DesignStyle.SKEUOMORPHISM -> GridSkin(
        line = Color(0x338A6A44),
        hourLabel = Color(0xFF6B5638),
        dayLabel = Color(0xFF6B5638),
        dayNum = Color(0xFF2B1D12),
        todayAccent = Color(0xFF7A3E1D),
        todayOnAccent = Color(0xFFFFF3D6),
        todayColBg = Color(0x1A7A3E1D),
        events = listOf(
            EvColor(Color(0xFFF0D9A8), Color(0xFFB8892E), Color(0xFF3A2208)),
            EvColor(Color(0xFFE7C9B0), Color(0xFF7A3E1D), Color(0xFF3A1A08)),
            EvColor(Color(0xFFCFE0C2), Color(0xFF4F7A33), Color(0xFF1F3A10))
        ),
        eventShape = RoundedCornerShape(4.dp),
        eventBorderW = 1.dp,
        leftBar = true,
        eventUpper = false,
        cellShape = RoundedCornerShape(6.dp),
        cellBg = Color(0x66FFF8E6),
        cellBorder = Color(0x338A6A44),
        cellBorderW = 0.5.dp,
        todayCellBg = Color(0xFF7A3E1D),
        todayCellText = Color(0xFFFFF3D6),
        otherAlpha = 0.4f,
        marks = Marks.ORBS,
        markColors = listOf(Color(0xFF7A3E1D), Color(0xFFB8892E), Color(0xFF4F7A33)),
        numberStyle = NumStyle.FILLED,
        centerNumber = false
    )
    DesignStyle.NEUMORPHISM -> GridSkin(
        line = Color(0x1A2D3748),
        hourLabel = Color(0xFF5B6B8C),
        dayLabel = Color(0xFF5B6B8C),
        dayNum = Color(0xFF2D3748),
        todayAccent = Color(0xFF2F49D1),
        todayOnAccent = Color.White,
        todayColBg = Color(0x0F2F49D1),
        events = listOf(
            EvColor(Color(0x1A2F49D1), Color(0xFF2F49D1), Color(0xFF1E2F9A)),
            EvColor(Color(0x1A0F766E), Color(0xFF0F766E), Color(0xFF0A4F4A)),
            EvColor(Color(0x1A5B6B8C), Color(0xFF5B6B8C), Color(0xFF2D3748))
        ),
        eventShape = RoundedCornerShape(10.dp),
        eventBorderW = 1.dp,
        leftBar = false,
        eventUpper = false,
        cellShape = RoundedCornerShape(12.dp),
        cellBg = Color.Transparent,
        cellBorder = Color.Transparent,
        cellBorderW = 0.dp,
        todayCellBg = Color(0xFF2F49D1),
        todayCellText = Color.White,
        otherAlpha = 0.35f,
        marks = Marks.DOTS,
        markColors = listOf(Color(0xFF2F49D1), Color(0xFF0F766E), Color(0xFF5B6B8C)),
        numberStyle = NumStyle.FILLED,
        centerNumber = true
    )
    DesignStyle.GLASSMORPHISM -> GridSkin(
        line = Color(0x33FFFFFF),
        hourLabel = Color(0xFFC9D2FF),
        dayLabel = Color(0xFFC9D2FF),
        dayNum = Color.White,
        todayAccent = Color(0xFF7DF9FF),
        todayOnAccent = Color(0xFF0A1440),
        todayColBg = Color(0x1F7DF9FF),
        events = listOf(
            EvColor(Color(0x337DF9FF), Color(0xFF7DF9FF), Color.White),
            EvColor(Color(0x33FF9BD2), Color(0xFFFF9BD2), Color.White),
            EvColor(Color(0x33B79BFF), Color(0xFFB79BFF), Color.White)
        ),
        eventShape = RoundedCornerShape(10.dp),
        eventBorderW = 1.dp,
        leftBar = false,
        eventUpper = false,
        cellShape = RoundedCornerShape(12.dp),
        cellBg = Color(0x1FFFFFFF),
        cellBorder = Color(0x33FFFFFF),
        cellBorderW = 0.5.dp,
        todayCellBg = Color(0xFF7DF9FF),
        todayCellText = Color(0xFF0A1440),
        otherAlpha = 0.3f,
        marks = Marks.GLOW,
        markColors = listOf(Color(0xFF7DF9FF), Color(0xFFFF9BD2), Color(0xFFB79BFF)),
        numberStyle = NumStyle.PLAIN,
        centerNumber = true
    )
    DesignStyle.Y2K -> GridSkin(
        line = Color(0x337B5FD0),
        hourLabel = Color(0xFF4A4F8A),
        dayLabel = Color(0xFF4A4F8A),
        dayNum = Color(0xFF1B1F4B),
        todayAccent = Color(0xFFC0106F),
        todayOnAccent = Color.White,
        todayColBg = Color(0x14C0106F),
        events = listOf(
            EvColor(Color(0xFFCFF3FF), Color(0xFF2A5BFF), Color(0xFF0E2A8A)),
            EvColor(Color(0xFFFFD6EE), Color(0xFFC0106F), Color(0xFF6A0B40)),
            EvColor(Color(0xFFE6DAFF), Color(0xFF7B5FD0), Color(0xFF2E1F6A))
        ),
        eventShape = RoundedCornerShape(12.dp),
        eventBorderW = 1.5.dp,
        leftBar = false,
        eventUpper = false,
        cellShape = RoundedCornerShape(14.dp),
        cellBg = Color(0x99FFFFFF),
        cellBorder = Color.White,
        cellBorderW = 1.dp,
        todayCellBg = Color(0xFFC0106F),
        todayCellText = Color.White,
        otherAlpha = 0.4f,
        marks = Marks.ORBS,
        markColors = listOf(Color(0xFF2A5BFF), Color(0xFFFF2E9A), Color(0xFF14A8A0)),
        numberStyle = NumStyle.FILLED,
        centerNumber = true
    )
    DesignStyle.AURORA -> GridSkin(
        line = Color(0x335EEAD4),
        hourLabel = Color(0xFF9DB0D8),
        dayLabel = Color(0xFF9DB0D8),
        dayNum = Color(0xFFEAF2FF),
        todayAccent = Color(0xFF5EEAD4),
        todayOnAccent = Color(0xFF06122B),
        todayColBg = Color(0x145EEAD4),
        events = listOf(
            EvColor(Color(0x335EEAD4), Color(0xFF5EEAD4), Color(0xFFD5FFF8)),
            EvColor(Color(0x33A78BFA), Color(0xFFA78BFA), Color(0xFFEDE6FF)),
            EvColor(Color(0x3338BDF8), Color(0xFF38BDF8), Color(0xFFDDF4FF))
        ),
        eventShape = RoundedCornerShape(10.dp),
        eventBorderW = 1.dp,
        leftBar = false,
        eventUpper = false,
        cellShape = RoundedCornerShape(12.dp),
        cellBg = Color(0x990D1636),
        cellBorder = Color(0x335EEAD4),
        cellBorderW = 0.5.dp,
        todayCellBg = Color(0xFF5EEAD4),
        todayCellText = Color(0xFF06122B),
        otherAlpha = 0.3f,
        marks = Marks.GLOW,
        markColors = listOf(Color(0xFF5EEAD4), Color(0xFFA78BFA), Color(0xFF38BDF8)),
        numberStyle = NumStyle.PLAIN,
        centerNumber = true
    )
    DesignStyle.CLAYMORPHISM -> GridSkin(
        line = Color(0x1A6C4CF0),
        hourLabel = Color(0xFF6B6580),
        dayLabel = Color(0xFF6B6580),
        dayNum = Color(0xFF2E2A3F),
        todayAccent = Color(0xFFB8352B),
        todayOnAccent = Color.White,
        todayColBg = Color(0x14FF7A6B),
        events = listOf(
            EvColor(Color(0xFFE0D6FF), Color(0xFF8F78F0), Color(0xFF2E2A3F)),
            EvColor(Color(0xFFFFD9D2), Color(0xFFFF7A6B), Color(0xFF2E2A3F)),
            EvColor(Color(0xFFCDEEDD), Color(0xFF4FB587), Color(0xFF2E2A3F))
        ),
        eventShape = RoundedCornerShape(12.dp),
        eventBorderW = 0.dp,
        leftBar = false,
        eventUpper = false,
        cellShape = RoundedCornerShape(14.dp),
        cellBg = Color.Transparent,
        cellBorder = Color.Transparent,
        cellBorderW = 0.dp,
        todayCellBg = Color(0xFFB8352B),
        todayCellText = Color.White,
        otherAlpha = 0.35f,
        marks = Marks.DOTS,
        markColors = listOf(Color(0xFF8F78F0), Color(0xFFFF7A6B), Color(0xFF4FB587)),
        numberStyle = NumStyle.FILLED,
        centerNumber = true
    )
    DesignStyle.DARK -> GridSkin(
        line = Color(0x14FFFFFF),
        hourLabel = Color(0xFF9A9A9A),
        dayLabel = Color(0xFF9A9A9A),
        dayNum = Color(0xFFE6E6E6),
        todayAccent = Color(0xFF8AB4F8),
        todayOnAccent = Color(0xFF0B1B33),
        todayColBg = Color(0x148AB4F8),
        events = listOf(
            EvColor(Color(0xFF1F2A3D), Color(0xFF8AB4F8), Color(0xFFD2E3FC)),
            EvColor(Color(0xFF2A2236), Color(0xFFC58AF9), Color(0xFFEBD7FD)),
            EvColor(Color(0xFF1F3329), Color(0xFF81C995), Color(0xFFCEEAD6))
        ),
        eventShape = RoundedCornerShape(6.dp),
        eventBorderW = 1.dp,
        leftBar = true,
        eventUpper = false,
        cellShape = RoundedCornerShape(8.dp),
        cellBg = Color.Transparent,
        cellBorder = Color(0x14FFFFFF),
        cellBorderW = 0.5.dp,
        todayCellBg = Color(0xFF8AB4F8),
        todayCellText = Color(0xFF0B1B33),
        otherAlpha = 0.35f,
        marks = Marks.DOTS,
        markColors = listOf(Color(0xFF8AB4F8), Color(0xFFC58AF9), Color(0xFF81C995)),
        numberStyle = NumStyle.FILLED,
        centerNumber = false
    )
    DesignStyle.COSMIC -> GridSkin(
        line = Color(0x26B4A7FF),
        hourLabel = Color(0xFFB9B0E6),
        dayLabel = Color(0xFFC7BFF0),
        dayNum = Color(0xFFF1EEFF),
        todayAccent = Color(0xFFFFC857),
        todayOnAccent = Color(0xFF05020F),
        todayColBg = Color(0x1FFFC857),
        events = listOf(
            EvColor(Color(0xFF2A1A66), Color(0xFFB4A7FF), Color(0xFFEDE9FF)),
            EvColor(Color(0xFF4A1650), Color(0xFFE0A8FF), Color(0xFFF8E4FF)),
            EvColor(Color(0xFF12335E), Color(0xFF7FC4FF), Color(0xFFDDEEFF))
        ),
        eventShape = RoundedCornerShape(10.dp),
        eventBorderW = 1.dp,
        leftBar = false,
        eventUpper = false,
        cellShape = CircleShape,
        cellBg = Color.Transparent,
        cellBorder = Color(0x26B4A7FF),
        cellBorderW = 0.5.dp,
        todayCellBg = Color(0xFFFFC857),
        todayCellText = Color(0xFF05020F),
        otherAlpha = 0.35f,
        marks = Marks.ORBS,
        markColors = listOf(Color(0xFFB4A7FF), Color(0xFFE0A8FF), Color(0xFFFFC857)),
        numberStyle = NumStyle.FILLED,
        centerNumber = true
    )
    DesignStyle.SCIFI_HUD -> GridSkin(
        line = Color(0x264DD8FF),
        hourLabel = Color(0xFF7FB8CC),
        dayLabel = Color(0xFF8FC4D6),
        dayNum = Color(0xFFD6F3FF),
        todayAccent = Color(0xFFFFB020),
        todayOnAccent = Color(0xFF04090F),
        todayColBg = Color(0x1AFFB020),
        events = listOf(
            EvColor(Color(0xFF0C2B38), Color(0xFF4DD8FF), Color(0xFFD6F3FF)),
            EvColor(Color(0xFF3A2A06), Color(0xFFFFB020), Color(0xFFFFE6B0)),
            EvColor(Color(0xFF3A1114), Color(0xFFFF5A4D), Color(0xFFFFD6D2))
        ),
        eventShape = RectangleShape,
        eventBorderW = 1.dp,
        leftBar = true,
        eventUpper = true,
        cellShape = RectangleShape,
        cellBg = Color.Transparent,
        cellBorder = Color(0x334DD8FF),
        cellBorderW = 0.5.dp,
        todayCellBg = Color(0xFFFFB020),
        todayCellText = Color(0xFF04090F),
        otherAlpha = 0.35f,
        marks = Marks.BARS,
        markColors = listOf(Color(0xFF4DD8FF), Color(0xFFFFB020), Color(0xFFFF5A4D)),
        numberStyle = NumStyle.PLAIN,
        centerNumber = false
    )
    DesignStyle.CYBER_INDUSTRIAL -> GridSkin(
        line = Color(0x33FFFFFF),
        hourLabel = Color(0xFFB4B9C0),
        dayLabel = Color(0xFFC9CDD3),
        dayNum = Color(0xFFF0F1F3),
        todayAccent = Color(0xFFFFC400),
        todayOnAccent = Color(0xFF111111),
        todayColBg = Color(0x1AFFC400),
        events = listOf(
            EvColor(Color(0xFF3A3410), Color(0xFFFFC400), Color(0xFFFFF0B0)),
            EvColor(Color(0xFF2B3138), Color(0xFF9AA4B0), Color(0xFFE6EAEE)),
            EvColor(Color(0xFF3D1E12), Color(0xFFFF7A3D), Color(0xFFFFDCCB))
        ),
        eventShape = CutCornerShape(topEnd = 6.dp, bottomStart = 6.dp),
        eventBorderW = 1.5.dp,
        leftBar = true,
        eventUpper = true,
        cellShape = CutCornerShape(4.dp),
        cellBg = Color(0x14FFFFFF),
        cellBorder = Color(0x33FFFFFF),
        cellBorderW = 0.5.dp,
        todayCellBg = Color(0xFFFFC400),
        todayCellText = Color(0xFF111111),
        otherAlpha = 0.35f,
        marks = Marks.CHIPS,
        markColors = listOf(Color(0xFFFFC400), Color(0xFF9AA4B0), Color(0xFFFF7A3D)),
        numberStyle = NumStyle.FILLED,
        centerNumber = false
    )
    DesignStyle.NEOCLASSICAL -> GridSkin(
        line = Color(0x40C9A24B),
        hourLabel = Color(0xFF6B5A33),
        dayLabel = Color(0xFF5A4A28),
        dayNum = Color(0xFF1F1B16),
        todayAccent = Color(0xFF6F5210),
        todayOnAccent = Color(0xFFFBF8F0),
        todayColBg = Color(0x1AC9A24B),
        events = listOf(
            EvColor(Color(0xFFF1E6C6), Color(0xFFC9A24B), Color(0xFF3A2A06)),
            EvColor(Color(0xFFE6E2D6), Color(0xFF8B8574), Color(0xFF2B2820)),
            EvColor(Color(0xFFEBD9D2), Color(0xFFA85C4B), Color(0xFF3F1E16))
        ),
        eventShape = RoundedCornerShape(1.dp),
        eventBorderW = 1.dp,
        leftBar = false,
        eventUpper = false,
        cellShape = RoundedCornerShape(1.dp),
        cellBg = Color.Transparent,
        cellBorder = Color(0x40C9A24B),
        cellBorderW = 0.5.dp,
        todayCellBg = Color(0xFF6F5210),
        todayCellText = Color(0xFFFBF8F0),
        otherAlpha = 0.4f,
        marks = Marks.DOTS,
        markColors = listOf(Color(0xFFC9A24B), Color(0xFF8B8574), Color(0xFFA85C4B)),
        numberStyle = NumStyle.RING,
        centerNumber = true
    )
}
