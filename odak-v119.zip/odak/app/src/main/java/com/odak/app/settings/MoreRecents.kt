package com.odak.app.settings

/** "Diğer" ekranında son açılan girişlerin kısa listesi (en yeni başta). Saf mantık; tercihlerde virgüllü metin olarak saklanır. */
object MoreRecents {
    const val MAX = 2

    fun push(list: List<String>, name: String, max: Int = MAX): List<String> {
        if (name !in MoreLayout.allEntries()) return clean(list, max)
        return (listOf(name) + list.filter { it != name }).let { clean(it, max) }
    }

    /** Bilinmeyen adları ve tekrarları atar, en fazla [max] öğe bırakır. */
    fun clean(list: List<String>, max: Int = MAX): List<String> = list.filter { it in MoreLayout.allEntries() }.distinct().take(max)

    fun decode(s: String?): List<String> = clean((s ?: "").split(',').map { it.trim() }.filter { it.isNotEmpty() })
    fun encode(list: List<String>): String = clean(list).joinToString(",")
}
