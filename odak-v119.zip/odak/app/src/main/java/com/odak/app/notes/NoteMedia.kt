package com.odak.app.notes

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.Paint
import android.graphics.Path
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.core.content.FileProvider
import java.io.File

/** Not ekleri: resim, ses, PDF dosyaları ve dışa aktarma. Dosyalar filesDir/notes/{img,audio,pdf} altındadır. */
object NoteMedia {
    const val MAX_PDF_BYTES = 100L * 1024 * 1024
    const val MAX_IMG_PX = 1600

    fun dir(c: Context, sub: String): File = File(File(c.filesDir, "notes"), sub).also { it.mkdirs() }
    fun file(c: Context, sub: String, name: String): File? = if (NotePure.safeFile(name)) File(dir(c, sub), name) else null

    // ---------- Resim ----------
    /** Seçilen resmi küçültüp (en çok 1600 px) JPEG olarak kaydeder. y: sayfada yerleştirileceği üst konum. */
    fun importImage(c: Context, uri: Uri, noteId: String, y: Float): NoteImg? = try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (opts.outWidth <= 0 || opts.outHeight <= 0) null else {
            var sample = 1
            while (opts.outWidth / (sample * 2) >= MAX_IMG_PX || opts.outHeight / (sample * 2) >= MAX_IMG_PX) sample *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bmp == null) null else {
                val (w, h) = NotePure.fitSize(bmp.width, bmp.height, MAX_IMG_PX)
                val scaled = if (w == bmp.width && h == bmp.height) bmp else Bitmap.createScaledBitmap(bmp, w, h, true)
                val name = "i_${noteId.take(12).filter { it.isLetterOrDigit() }}_${System.currentTimeMillis()}.jpg"
                File(dir(c, "img"), name).outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                NoteImg(name, 0.1f, y, 0.5f, h.toFloat() / w)
            }
        }
    } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }

    fun loadImage(c: Context, name: String): Bitmap? = try {
        file(c, "img", name)?.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) }
    } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }

    // ---------- PDF ----------
    /** PDF'i uygulama klasörüne kopyalar (kaynak silinse de not açılır); geçerli PDF değilse null. */
    fun importPdf(c: Context, uri: Uri): String? = try {
        val name = "p_${System.currentTimeMillis()}.pdf"
        val out = File(dir(c, "pdf"), name)
        var total = 0L
        c.contentResolver.openInputStream(uri)?.use { ins ->
            out.outputStream().use { os ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val r = ins.read(buf); if (r < 0) break
                    total += r; if (total > MAX_PDF_BYTES) throw java.io.IOException("big")
                    os.write(buf, 0, r)
                }
            }
        } ?: throw java.io.IOException("open")
        val ok = ParcelFileDescriptor.open(out, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd -> PdfRenderer(pfd).use { it.pageCount > 0 } }
        if (ok) name else { out.delete(); null }
    } catch (e: Exception) { null }

    /** PDF sayfalarının yükseklik/genişlik oranları. */
    fun pdfAspects(c: Context, name: String): List<Float> = try {
        val f = file(c, "pdf", name)!!
        ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { r -> List(r.pageCount) { i -> r.openPage(i).use { p -> p.height.toFloat() / p.width } } }
        }
    } catch (e: Exception) { emptyList() }

    /** Tek sayfayı verilen genişlikte beyaz zeminli bitmap olarak çizer. */
    fun renderPdfPage(renderer: PdfRenderer, index: Int, widthPx: Int): Bitmap? = try {
        synchronized(renderer) {
            renderer.openPage(index).use { p ->
                val h = (widthPx.toFloat() * p.height / p.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(AColor.WHITE)
                p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            }
        }
    } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }

    // ---------- Çizim (dışa aktarma için android.graphics) ----------
    private fun inkColor(s: Stroke): Int {
        val base = if (s.color == 0) AColor.BLACK else s.color
        val a = (NotePure.strokeAlpha(s.tool) * 255).toInt().coerceIn(0, 255)
        return (base and 0x00FFFFFF) or (a shl 24)
    }

    /** Çizgileri canvas'a çizer. scale: sayfa genişliği (px); yOff: sayfa üstü (genişlik biriminde), çıkarılır. */
    fun drawStrokes(cv: Canvas, strokes: List<Stroke>, scale: Float, yOff: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        for (s in strokes) {
            if (s.pts.isEmpty()) continue
            paint.color = inkColor(s)
            val w = NotePure.effWidth(s.tool, s.width) * scale / 1000f
            if (s.pts.size == 1) {
                paint.style = Paint.Style.FILL
                cv.drawCircle(s.pts[0].x * scale, (s.pts[0].y - yOff) * scale, NotePure.pressW(w, s.pts[0].p) / 2f, paint)
                paint.style = Paint.Style.STROKE
                continue
            }
            val pressured = s.tool != NotePure.TOOL_HIGHLIGHT && s.pts.any { it.p < 0.999f }
            if (pressured) {
                for (i in 1 until s.pts.size) {
                    val a = s.pts[i - 1]; val b = s.pts[i]
                    paint.strokeWidth = NotePure.pressW(w, (a.p + b.p) / 2f)
                    cv.drawLine(a.x * scale, (a.y - yOff) * scale, b.x * scale, (b.y - yOff) * scale, paint)
                }
            } else {
                paint.strokeWidth = w
                val path = Path()
                path.moveTo(s.pts[0].x * scale, (s.pts[0].y - yOff) * scale)
                for (i in 1 until s.pts.size) path.lineTo(s.pts[i].x * scale, (s.pts[i].y - yOff) * scale)
                cv.drawPath(path, paint)
            }
        }
    }

    private fun drawPaper(cv: Canvas, type: Int, w: Float, h: Float) {
        val p = Paint().apply { color = 0x26000000; strokeWidth = 1.5f }
        val step = w * 0.06f
        when (type) {
            1 -> { var y = step * 1.5f; while (y < h) { cv.drawLine(0f, y, w, y, p); y += step } }
            2 -> { var y = step; while (y < h) { cv.drawLine(0f, y, w, y, p); y += step }; var x = step; while (x < w) { cv.drawLine(x, 0f, x, h, p); x += step } }
            3 -> { var y = step; while (y < h) { var x = step; while (x < w) { cv.drawCircle(x, y, 2f, p); x += step }; y += step } }
        }
    }

    /** Notu (kâğıt, resimler, çizimler) tek PNG olarak çizer. Çok uzun notlar 12000 px ile sınırlanır. */
    fun renderNote(c: Context, n: Note, widthPx: Int = 1080): Bitmap? = try {
        val hUnits = NotePure.pageHeight(n.strokes, n.images)
        val h = (hUnits * widthPx).toInt().coerceIn(1, 12000)
        val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawColor(AColor.WHITE)
        if (n.color != 0) cv.drawColor((n.color and 0x00FFFFFF) or 0x38000000)
        drawPaper(cv, n.paper, widthPx.toFloat(), h.toFloat())
        for (i in n.images) {
            val b = loadImage(c, i.file) ?: continue
            val r = android.graphics.RectF(i.x * widthPx, i.y * widthPx, (i.x + i.w) * widthPx, NotePure.imgBottom(i) * widthPx)
            cv.drawBitmap(b, null, r, Paint(Paint.FILTER_BITMAP_FLAG))
        }
        drawStrokes(cv, n.strokes, widthPx.toFloat(), 0f)
        bmp
    } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }

    private fun shareDir(c: Context) = File(c.cacheDir, "share").also { it.mkdirs() }

    private fun send(c: Context, f: File, mime: String) {
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
        val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Notu PNG olarak paylaşır; başarısızsa false. */
    fun sharePng(c: Context, n: Note): Boolean = try {
        val bmp = renderNote(c, n) ?: throw IllegalStateException()
        val f = File(shareDir(c), "not_${n.id.filter { it.isLetterOrDigit() }.take(12)}.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        send(c, f, "image/png"); true
    } catch (e: Exception) { false }

    /** PDF notunu çizimleriyle birlikte yeni bir PDF olarak paylaşır. */
    fun sharePdf(c: Context, n: Note): Boolean = try {
        val src = file(c, "pdf", n.pdf)!!
        val aspects = pdfAspects(c, n.pdf)
        val tops = NotePure.pdfTops(aspects)
        val doc = PdfDocument()
        ParcelFileDescriptor.open(src, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { r ->
                for (i in aspects.indices) {
                    val wPx = 1240
                    val bmp = renderPdfPage(r, i, wPx) ?: continue
                    val page = doc.startPage(PdfDocument.PageInfo.Builder(bmp.width, bmp.height, i + 1).create())
                    page.canvas.drawBitmap(bmp, 0f, 0f, null)
                    drawStrokes(page.canvas, NotePure.strokesOfPage(tops, n.strokes, i), wPx.toFloat(), tops[i])
                    doc.finishPage(page)
                    bmp.recycle()
                }
            }
        }
        val f = File(shareDir(c), "not_${n.id.filter { it.isLetterOrDigit() }.take(12)}.pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        send(c, f, "application/pdf"); true
    } catch (e: Exception) { false }

    // ---------- Silme ----------
    fun deleteFiles(c: Context, n: Note) {
        for (i in n.images) file(c, "img", i.file)?.delete()
        for (a in n.audios) file(c, "audio", a.file)?.delete()
        if (n.pdf.isNotEmpty()) file(c, "pdf", n.pdf)?.delete()
    }
}

/** Ses kaydı: başlat/durdur. start() izin yoksa ya da cihaz hata verirse null döner. */
class NoteRecorder(private val c: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var startAt = 0L

    fun start(noteId: String): Boolean = try {
        val name = "a_${noteId.take(12).filter { it.isLetterOrDigit() }}_${System.currentTimeMillis()}.m4a"
        val f = File(NoteMedia.dir(c, "audio"), name)
        val r = MediaRecorder(c)
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioEncodingBitRate(64_000)
        r.setAudioSamplingRate(44_100)
        r.setOutputFile(f.absolutePath)
        r.prepare(); r.start()
        rec = r; file = f; startAt = System.currentTimeMillis(); true
    } catch (e: Exception) { release(); false }

    fun active() = rec != null
    fun elapsedMs(): Long = if (rec == null) 0L else System.currentTimeMillis() - startAt

    /** Kaydı bitirir; çok kısa ya da bozuk kayıt için null. */
    fun stop(): NoteAudio? {
        val r = rec ?: return null; val f = file
        val dur = System.currentTimeMillis() - startAt
        rec = null; file = null
        return try { r.stop(); r.release(); if (f != null && f.exists() && dur >= 500) NoteAudio(f.name, dur, System.currentTimeMillis()) else { f?.delete(); null } }
        catch (e: Exception) { try { r.release() } catch (x: Exception) { }; f?.delete(); null }
    }

    fun release() { try { rec?.release() } catch (x: Exception) { }; rec = null; file?.delete(); file = null }
}

/** Tek seferde bir kaydı çalar. */
class NotePlayer(private val c: Context) {
    private var mp: MediaPlayer? = null
    var current: String? = null
        private set

    fun play(name: String, onDone: () -> Unit): Boolean {
        stop()
        val f = NoteMedia.file(c, "audio", name)?.takeIf { it.exists() } ?: return false
        return try {
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath); p.prepare()
            p.setOnCompletionListener { stop(); onDone() }
            p.start(); mp = p; current = name; true
        } catch (e: Exception) { stop(); false }
    }

    fun stop() { try { mp?.stop() } catch (x: Exception) { }; try { mp?.release() } catch (x: Exception) { }; mp = null; current = null }
}
