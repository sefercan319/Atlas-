package com.odak.app.block

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.odak.app.logic.Pure

/** Engelli uygulamaların bildirimlerini gizler (isteğe bağlı, bildirim erişimi izni gerekir). */
class OdakNotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn ?: return
        if (!BlockStore.notifHide(this)) return
        val app = BlockCatalog.byPackage(n.packageName) ?: return
        val blocked = BlockStore.focusActive(this) ||
            BlockStore.isAppBlocked(this, app.id) ||
            (BlockStore.appQuiet(this, app.id) && BlockStore.quietNow(this)) ||
            limitReached(app) || Pure.openLimitHit(BlockStore.opensToday(this, app.id), BlockStore.openLimit(this, app.id))
        if (Pure.hideNotification(n.isOngoing, blocked, BlockStore.passActive(this, app.id))) cancelNotification(n.key)
    }

    /** Günlük süre sınırı dolmuş uygulamanın bildirimleri de gizlenir (sınır engeliyle tutarlı). */
    private fun limitReached(app: BlockApp): Boolean {
        val limit = BlockStore.appLimit(this, app.id)
        if (limit <= 0 || !BlockStore.usageAccess(this)) return false
        return Pure.limitReached(BlockStore.appUsedMs(this, app), limit)
    }
}
