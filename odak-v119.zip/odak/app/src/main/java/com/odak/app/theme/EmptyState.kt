package com.odak.app.theme

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Boş liste/hata için ortak görünüm: büyük simge, başlık, ipucu ve isteğe bağlı eylem. Her tasarım kendi renk/yazı tipini kullanır. */
@Composable
fun EmptyState(icon: String, title: String, hint: String? = null, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    val tk = LocalDesign.current.tokens
    Column(
        modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(icon, style = MaterialTheme.typography.displaySmall, modifier = Modifier.alpha(0.85f))
        Text(title, color = tk.text, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        if (!hint.isNullOrBlank()) Text(hint, color = tk.text, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, modifier = Modifier.alpha(0.7f))
        action?.invoke()
    }
}

/** Plan sekmesi için sıkı boş durum: tasarımın kendi yazı rengiyle iki satır (başlık + ipucu). */
@Composable
fun PlanEmpty(color: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Column(modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("📅 " + androidx.compose.ui.res.stringResource(com.odak.app.R.string.plan_empty), color = color, fontSize = 13.sp)
        Text(androidx.compose.ui.res.stringResource(com.odak.app.R.string.plan_empty_hint), color = color.copy(alpha = color.alpha * 0.75f), fontSize = 11.sp)
    }
}
