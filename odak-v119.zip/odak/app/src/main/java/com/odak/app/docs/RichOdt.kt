package com.odak.app.docs

import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler

/** ODT (ve OpenOffice 1.x .sxw, düz .fodt) → zengin model. Stiller styles.xml + content.xml'den birleştirilir. */
object RichOdt {
    private const val MAX_BLOCKS = 20000

    /** Uzunluk → twips ("2.5cm", "10pt", "0.5in", "5mm"). */
    fun twips(v: String?): Int? {
        val s = v?.trim() ?: return null
        val m = Regex("""^(-?[0-9]*\.?[0-9]+)\s*(cm|mm|in|pt|pc|px)?$""").find(s) ?: return null
        val n = m.groupValues[1].toDoubleOrNull() ?: return null
        return when (m.groupValues[2]) { "cm" -> n * 567.0; "mm" -> n * 56.7; "in" -> n * 1440.0; "pt" -> n * 20.0; "pc" -> n * 240.0; "px" -> n * 15.0; else -> n * 20.0 }.toInt()
    }

    private fun bd(v: String?): Bd? {
        val s = v?.trim() ?: return null
        if (s == "none" || s.isEmpty() || s == "0cm") return null
        val parts = s.split(Regex("\\s+"))
        val w = parts.firstNotNullOfOrNull { twips(it) } ?: 10
        val color = parts.firstNotNullOfOrNull { Rich.hex(it) } ?: "000000"
        val eighths = (w / 20.0 * 8).toInt().coerceAtLeast(4)
        return Bd(eighths, color)
    }

    private class OS(val name: String, val family: String) {
        var parent: String? = null; var display = ""; var outline = 0
        var b: Boolean? = null; var i: Boolean? = null; var u: Boolean? = null; var s: Boolean? = null
        var color: String? = null; var hl: String? = null; var szRaw: String? = null; var font: String? = null; var sup = 0
        var align: String? = null; var left: Int? = null; var first: Int? = null; var before: Int? = null; var after: Int? = null; var line: Int? = null
        var pb = false; var top: Bd? = null; var bottom: Bd? = null; var fill: String? = null
        var tb: Bd? = null; var tl: Bd? = null; var tbt: Bd? = null; var tr: Bd? = null; var tfill: String? = null; var valign = ""
        var colW: Int? = null
        var tblW: Int? = null
    }

    private class LL(var bullet: Boolean, var text: String, var left: Int, var hang: Int, var fmt: String, var suffix: String)

    /** Belgedeki en üst düzey draw:text-box iç XML'leri, belge sırasıyla. */
    internal fun textBoxes(x: String): List<String> {
        val out = ArrayList<String>()
        var depth = 0; var start = 0
        for (m in Regex("<(/?)draw:text-box(\\s[^>]*)?(/?)>").findAll(x)) {
            if (m.groupValues[3] == "/") continue
            if (m.groupValues[1] != "/") { if (depth == 0) start = m.range.last + 1; depth++ }
            else if (depth > 0) { depth--; if (depth == 0 && out.size < 200) out.add(x.substring(start, m.range.first)) }
        }
        return out
    }

    fun parse(content: ByteArray, styles: ByteArray?, media: Map<String, ByteArray> = emptyMap(), depth: Int = 0): RichPage {
        val cs = if (depth < 2) String(content, Charsets.UTF_8) else ""
        val boxes = if (depth < 2 && cs.contains("draw:text-box")) textBoxes(cs) else emptyList()
        val textTag = Regex("<office:text(?:\\s[^>]*)?(?<!/)>").find(cs)
        var boxIdx = 0
        val pendingBoxes = ArrayList<List<RBlock>>(); val pendingFloat = ArrayList<Triple<String, Int, Int>>(); var fx = Int.MIN_VALUE; var fy = 0; var fAt: IntArray? = null; val pendingAt = ArrayList<IntArray?>()
        val st = HashMap<String, OS>()
        val fonts = HashMap<String, String>()
        val lists = HashMap<String, HashMap<Int, LL>>()
        var defSzRaw: String? = null; var defFont: String? = null
        var setup = PageSetup()
        val wrapOf = HashMap<String, String>()

        fun readStyles(xml: ByteArray, isStylesFile: Boolean) {
            var cur: OS? = null
            var curList: HashMap<Int, LL>? = null
            var curLevel: LL? = null
            var inDefault = false
            DocParse.sax(xml, object : DefaultHandler() {
                override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                    when (q) {
                        "style:font-face" -> { val n = a?.getValue("style:name"); val f = a?.getValue("svg:font-family"); if (n != null && f != null) fonts[n] = f.trim('\'', '"') }
                        "style:default-style" -> inDefault = a?.getValue("style:family") == "paragraph"
                        "style:style" -> cur = OS(a?.getValue("style:name") ?: "", a?.getValue("style:family") ?: "").also {
                            it.parent = a?.getValue("style:parent-style-name"); it.display = a?.getValue("style:display-name") ?: it.name
                            it.outline = a?.getValue("style:default-outline-level")?.toIntOrNull() ?: 0
                        }
                        "style:graphic-properties" -> cur?.let { c -> if (c.family == "graphic") wrapOf[c.name] = a?.getValue("style:wrap") ?: "" }
                        "text:list-style" -> curList = HashMap<Int, LL>().also { lists[a?.getValue("style:name") ?: ""] = it }
                        "text:list-level-style-bullet", "text:list-level-style-number" -> {
                            val lv = a?.getValue("text:level")?.toIntOrNull() ?: 1
                            curLevel = LL(q.endsWith("bullet"), a?.getValue("text:bullet-char") ?: "•", 0, 0, a?.getValue("style:num-format") ?: a?.getValue("text:num-format") ?: "1", (a?.getValue("style:num-suffix") ?: a?.getValue("text:num-suffix") ?: "."))
                            curList?.put(lv, curLevel!!)
                        }
                        "style:list-level-properties" -> curLevel?.let { c ->
                            val sb = twips(a?.getValue("text:space-before")) ?: 0; val mw = twips(a?.getValue("text:min-label-width")) ?: 0
                            c.left = sb + mw; c.hang = mw
                        }
                        "style:list-level-label-alignment" -> curLevel?.let { c ->
                            c.left = twips(a?.getValue("fo:margin-left")) ?: c.left
                            c.hang = -(twips(a?.getValue("fo:text-indent")) ?: -c.hang)
                        }
                        "style:page-layout-properties" -> if (isStylesFile && setup.w == 11906 && a?.getValue("fo:page-width") != null) {
                            val w = twips(a.getValue("fo:page-width")) ?: 11906; val h = twips(a.getValue("fo:page-height")) ?: 16838
                            val m = twips(a.getValue("fo:margin"));
                            setup = PageSetup(w, h, twips(a.getValue("fo:margin-top")) ?: m ?: 1440, twips(a.getValue("fo:margin-right")) ?: m ?: 1440,
                                twips(a.getValue("fo:margin-bottom")) ?: m ?: 1440, twips(a.getValue("fo:margin-left")) ?: m ?: 1440)
                        }
                        "style:text-properties" -> {
                            if (inDefault) { a?.getValue("fo:font-size")?.let { defSzRaw = it }; (a?.getValue("fo:font-family") ?: a?.getValue("style:font-name"))?.let { defFont = it } }
                            cur?.let { c ->
                                a?.getValue("fo:font-weight")?.let { c.b = it == "bold" || (it.toIntOrNull() ?: 400) >= 600 }
                                a?.getValue("fo:font-style")?.let { c.i = it == "italic" || it == "oblique" }
                                a?.getValue("style:text-underline-style")?.let { c.u = it != "none" }
                                a?.getValue("style:text-line-through-style")?.let { c.s = it != "none" }
                                c.color = Rich.hex(a?.getValue("fo:color")) ?: c.color
                                c.hl = Rich.hex(a?.getValue("fo:background-color")) ?: c.hl
                                a?.getValue("fo:font-size")?.let { c.szRaw = it }
                                (a?.getValue("fo:font-family") ?: a?.getValue("style:font-name"))?.let { c.font = it }
                                a?.getValue("style:text-position")?.let { p -> c.sup = if (p.startsWith("super") || (p.substringBefore(' ').removeSuffix("%").toIntOrNull() ?: 0) > 0) 1 else if (p.startsWith("sub") || (p.substringBefore(' ').removeSuffix("%").toIntOrNull() ?: 0) < 0) -1 else 0 }
                            }
                        }
                        "style:paragraph-properties" -> {
                            cur?.let { c ->
                                a?.getValue("fo:text-align")?.let { c.align = when (it) { "center" -> "center"; "end", "right" -> "right"; "justify" -> "justify"; else -> "" } }
                                (twips(a?.getValue("fo:margin-left")))?.let { c.left = it }
                                twips(a?.getValue("fo:text-indent"))?.let { c.first = it }
                                twips(a?.getValue("fo:margin-top"))?.let { c.before = it }
                                twips(a?.getValue("fo:margin-bottom"))?.let { c.after = it }
                                a?.getValue("fo:line-height")?.let { v -> if (v.endsWith("%")) c.line = (v.removeSuffix("%").toDoubleOrNull() ?: 100.0).times(2.4).toInt() }
                                if (a?.getValue("fo:break-before") == "page") c.pb = true
                                a?.getValue("fo:border-bottom")?.let { c.bottom = bd(it) }
                                a?.getValue("fo:border-top")?.let { c.top = bd(it) }
                                a?.getValue("fo:border")?.let { v -> val d = bd(v); c.top = d; c.bottom = d }
                                Rich.hex(a?.getValue("fo:background-color"))?.let { c.fill = it }
                            }
                        }
                        "style:table-cell-properties" -> cur?.let { c ->
                            val all = a?.getValue("fo:border")
                            if (all != null) { val d = bd(all); c.tbt = d; c.tb = d; c.tl = d; c.tr = d }
                            a?.getValue("fo:border-top")?.let { c.tbt = bd(it) }
                            a?.getValue("fo:border-bottom")?.let { c.tb = bd(it) }
                            a?.getValue("fo:border-left")?.let { c.tl = bd(it) }
                            a?.getValue("fo:border-right")?.let { c.tr = bd(it) }
                            Rich.hex(a?.getValue("fo:background-color"))?.let { c.tfill = it }
                            a?.getValue("style:vertical-align")?.let { c.valign = when (it) { "middle" -> "center"; "bottom" -> "bottom"; else -> "" } }
                        }
                        "style:table-column-properties" -> cur?.colW = twips(a?.getValue("style:column-width"))
                        "style:table-properties" -> cur?.tblW = twips(a?.getValue("style:width"))
                    }
                }
                override fun endElement(u: String?, l: String?, q: String) {
                    when (q) {
                        "style:style" -> { cur?.let { st[it.family + ":" + it.name] = it }; cur = null }
                        "style:default-style" -> inDefault = false
                        "text:list-style" -> { curList = null; curLevel = null }
                        "text:list-level-style-bullet", "text:list-level-style-number" -> curLevel = null
                    }
                }
            })
        }
        if (styles != null) readStyles(styles, true)
        readStyles(content, false)

        fun chain(family: String, name: String?): List<OS> {
            val out = ArrayList<OS>()
            var cur = name?.let { st["$family:$it"] }
            var n = 0
            while (cur != null && n++ < 12) { out.add(0, cur); cur = cur.parent?.let { st["$family:$it"] } }
            return out
        }
        fun pt(raw: String?, cur: Int): Int {
            if (raw == null) return cur
            if (raw.endsWith("%")) return ((raw.removeSuffix("%").toDoubleOrNull() ?: 100.0) / 100.0 * cur).toInt().coerceAtLeast(2)
            val t = twips(raw) ?: return cur
            return t / 10   // twips → yarım punto
        }
        val defSz = pt(defSzRaw, 24).let { if (it <= 0) 24 else it }
        val defFontName = defFont?.let { fonts[it] ?: it }

        val blocks = ArrayList<RBlock>()
        var tblDepth = 0
        var tbl: OTbl? = null
        var cell: OCell? = null
        // paragraf
        var pStyle: String? = null; var head = 0
        val runs = ArrayList<RRun>()
        val spanStack = ArrayList<String?>()
        val txt = StringBuilder()
        var inP = 0
        var frame = 0; var ann = 0
        // liste
        val listStack = ArrayList<String>()
        val counters = HashMap<Int, Int>()
        var pendingMarker = ""; var itemLeft = 0; var itemHang = 0
        var pendingPb = false
        var fw = 0; var fh = 0; var imgBytes = 0L
        var inNote = false; var cite = 0
        val noteBuf = StringBuilder(); val noteList = ArrayList<String>()
        var sRuns: List<RRun> = emptyList(); var sStyle: String? = null; var sHead = 0; var sSpans: List<String?> = emptyList(); var sInP = 0

        fun runProps(): RRun {
            var b = false; var i = false; var u = false; var s = false; var color: String? = null; var hl: String? = null; var sz = defSz; var font: String? = defFontName; var sup = 0
            fun app(o: OS) {
                o.b?.let { b = it }; o.i?.let { i = it }; o.u?.let { u = it }; o.s?.let { s = it }; o.color?.let { color = it }; o.hl?.let { hl = it }
                o.szRaw?.let { sz = pt(it, sz) }; o.font?.let { font = fonts[it] ?: it }; if (o.sup != 0) sup = o.sup
            }
            chain("paragraph", pStyle).forEach { app(it) }
            for (sp in spanStack) if (sp != null) chain("text", sp).forEach { app(it) }
            return RRun("", b, i, u, s, color, hl, sz, font?.takeIf { it != defFontName }, sup)
        }
        fun flushBoxes() {
            if (pendingBoxes.isEmpty()) return
            for ((bi, bx) in pendingBoxes.withIndex()) {
                val ps = bx.filterIsInstance<RPara>()
                val fl = pendingFloat.getOrNull(bi) ?: Triple("", 8000, 0); val atx = pendingAt.getOrNull(bi)
                if (cell != null) ps.forEach { cell!!.paras.add(it) }
                else if (blocks.size < MAX_BLOCKS) {
                    val bd = Bd(6, "7F7F7F")
                    val tb = RTable(listOf(listOf(RCell(if (ps.isEmpty()) listOf(RPara(emptyList())) else ps.take(200), 1, 0, null, bd, bd, bd, bd))), listOf(if (atx != null) atx[2] else if (fl.first.isNotEmpty()) fl.second else 8000), fl.first, fl.third)
                    tb.at = atx
                    blocks.add(tb)
                    if (fl.first.isEmpty() && atx == null) blocks.add(RPara(emptyList(), before = 0, after = 0))
                }
            }
            pendingBoxes.clear(); pendingFloat.clear(); pendingAt.clear()
        }
        fun flushText() {
            if (txt.isEmpty()) return
            val p = runProps()
            val fx = SymbolFonts.fix(txt.toString(), p.font)
            runs.add(RRun(fx.first, p.b, p.i, p.u, p.s, p.color, p.hl, p.sz, fx.second, p.sup))
            txt.setLength(0)
        }
        fun endPara() {
            flushText()
            if (inNote) {
                val t = runs.joinToString("") { it.text }
                if (t.isNotBlank()) noteBuf.append(t.trim()).append(' ')
                runs.clear(); spanStack.clear(); pStyle = null; head = 0
                return
            }
            val ch = chain("paragraph", pStyle)
            var al = ""; var left = 0; var first = 0; var before = -1; var after = -1; var line = 0; var pb = pendingPb; var top: Bd? = null; var bot: Bd? = null; var fill: String? = null
            for (o in ch) {
                o.align?.let { al = it }; o.left?.let { left = it }; o.first?.let { first = it }; o.before?.let { before = it }; o.after?.let { after = it }
                o.line?.let { line = it }; if (o.pb) pb = true; if (o.top != null) top = o.top; if (o.bottom != null) bot = o.bottom; o.fill?.let { fill = it }
            }
            if (pendingMarker.isNotEmpty() || itemLeft > 0) { if (left == 0) left = itemLeft; if (first == 0) first = -itemHang }
            val h = if (head > 0) head else ch.lastOrNull { it.outline > 0 }?.outline ?: 0
            val p = RPara(ArrayList(runs), al, h, pendingMarker, left, first, before, after, line, top, bot, fill, pb)
            pendingPb = false; pendingMarker = ""
            if (cell != null) cell!!.paras.add(p) else if (blocks.size < MAX_BLOCKS) blocks.add(p)
            runs.clear(); spanStack.clear(); pStyle = null; head = 0
            flushBoxes()
        }

        DocParse.sax(content, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                if (q == "office:annotation") ann++
                if (q == "draw:frame") {
                    if (frame == 0) { fw = twips(a?.getValue("svg:width")) ?: 0; fh = twips(a?.getValue("svg:height")) ?: 0; fx = twips(a?.getValue("svg:x")) ?: Int.MIN_VALUE; fy = if (a?.getValue("text:anchor-type") == "paragraph") (twips(a.getValue("svg:y")) ?: 0) else 0
                        fAt = if (a?.getValue("text:anchor-type") == "page" && fx != Int.MIN_VALUE && fw > 0 && fh > 0) (twips(a.getValue("svg:y")) ?: null)?.let { yy -> intArrayOf(fx, yy, fw, fh) }
                            else if (a?.getValue("text:anchor-type") == "paragraph" && (wrapOf[a.getValue("draw:style-name") ?: ""] ?: "") in setOf("run-through", "none", "") && fx != Int.MIN_VALUE && fw > 0 && fh > 0) intArrayOf(fx + setup.left, twips(a.getValue("svg:y")) ?: 0, fw, fh, 1) else null }
                    frame++
                }
                if (q == "draw:text-box" && frame == 1 && ann == 0) {
                    if (boxIdx < boxes.size && textTag != null) {
                        val inner = try {
                            parse((cs.substring(0, textTag.range.last + 1) + boxes[boxIdx] + "</office:text></office:body></office:document-content>").toByteArray(Charsets.UTF_8), styles, media, depth + 1).blocks
                        } catch (x: Exception) { emptyList() }
                        if (inner.isNotEmpty()) {
                            pendingBoxes.add(inner)
                            pendingAt.add(fAt)
                            pendingFloat.add(if (fx != Int.MIN_VALUE && fw in 1500..9000) Triple(if (fx + fw / 2 < 5953) "left" else "right", fw, fy) else Triple("", 8000, 0))
                        }
                    }
                    boxIdx++
                }
                if (q == "draw:image" && frame == 1 && ann == 0) {
                    val href = a?.getValue("xlink:href") ?: ""
                    val data = media[href]
                    val mime = data?.let { RImg.mimeOf(href, it) }
                    if (data != null && mime != null && imgBytes + data.size <= 24L * 1024 * 1024) {
                        imgBytes += data.size
                        val px = RImg.pixelSize(data)
                        val w = if (fw > 0) fw else (px?.first ?: 200) * 15
                        val h = if (fh > 0) fh else (px?.second ?: 150) * 15
                        val run = RRun("", img = RImg(data, mime, w, h))
                        if (inP > 0) { flushText(); runs.add(run) }
                        else { val pr = RPara(listOf(run)); if (cell != null) cell!!.paras.add(pr) else if (blocks.size < MAX_BLOCKS) blocks.add(pr) }
                    }
                }
                if (ann > 0 || frame > 0) return
                if (q == "text:note" && inP > 0 && !inNote) {
                    flushText(); noteList.size.let { runs.add(RRun("[" + (it + 1) + "]", sup = 1, sz = defSz)) }
                    sRuns = ArrayList(runs); sStyle = pStyle; sHead = head; sSpans = ArrayList(spanStack); sInP = inP
                    inNote = true; inP = 0; runs.clear(); spanStack.clear(); noteBuf.setLength(0)
                    return
                }
                if (q == "text:note-citation") cite++
                when (q) {
                    "text:list" -> {
                        listStack.add(a?.getValue("text:style-name") ?: listStack.lastOrNull() ?: "")
                        if (a?.getValue("text:continue-numbering") != "true") counters[listStack.size] = 0
                    }
                    "text:list-item" -> {
                        val lv = listStack.size
                        val def = lists[listStack.lastOrNull() ?: ""]?.get(lv)
                        if (def != null) {
                            itemLeft = def.left; itemHang = def.hang
                            if (def.bullet) pendingMarker = def.text.take(1).let { if (it.isEmpty() || it[0].code < 0x20 || it[0].code in 0xE000..0xF8FF) "•" else it }
                            else {
                                val n = (counters[lv] ?: 0) + 1; counters[lv] = n
                                pendingMarker = when (def.fmt) { "a" -> ('a' + (n - 1) % 26).toString(); "A" -> ('A' + (n - 1) % 26).toString(); "i" -> toRoman(n).lowercase(); "I" -> toRoman(n); else -> n.toString() } + def.suffix
                            }
                        } else { pendingMarker = "•"; itemLeft = 360 * lv; itemHang = 360 }
                    }
                    "table:table" -> { tblDepth++; if (tblDepth == 1) tbl = OTbl().also { it.style = a?.getValue("table:style-name") } }
                    "table:table-column" -> if (tblDepth == 1) {
                        val w = st["table-column:" + (a?.getValue("table:style-name") ?: "")]?.colW ?: 0
                        repeat((a?.getValue("table:number-columns-repeated")?.toIntOrNull() ?: 1).coerceIn(1, 60)) { tbl?.colW?.add(w) }
                    }
                    "table:table-row" -> if (tblDepth == 1) tbl?.row = ArrayList()
                    "table:table-cell", "table:covered-table-cell" -> if (tblDepth == 1) {
                        val c = OCell(); c.style = a?.getValue("table:style-name"); c.span = (a?.getValue("table:number-columns-spanned")?.toIntOrNull() ?: 1).coerceIn(1, 60)
                        c.covered = q.contains("covered")
                        cell = c
                        val rep = (a?.getValue("table:number-columns-repeated")?.toIntOrNull() ?: 1).coerceIn(1, 60)
                        c.rowSpan = (a?.getValue("table:number-rows-spanned")?.toIntOrNull() ?: 1).coerceIn(1, 200)
                        if (rep > 1) { c.rep = rep }
                    }
                    "text:p", "text:h" -> {
                        inP++
                        if (inP == 1) { pStyle = a?.getValue("text:style-name"); head = if (q == "text:h") (a?.getValue("text:outline-level")?.toIntOrNull() ?: 1).coerceIn(1, 6) else 0; runs.clear(); spanStack.clear(); txt.setLength(0) }
                    }
                    "text:span" -> if (inP > 0) { flushText(); spanStack.add(a?.getValue("text:style-name")) }
                    "text:tab" -> if (inP > 0) txt.append('\t')
                    "text:line-break" -> if (inP > 0) txt.append('\n')
                    "text:s" -> if (inP > 0) txt.append(" ".repeat((a?.getValue("text:c")?.toIntOrNull() ?: 1).coerceIn(1, 50)))
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inP > 0 && ann == 0 && frame == 0 && cite == 0) txt.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                if (q == "office:annotation") { ann = maxOf(0, ann - 1); return }
                if (q == "draw:frame") { frame = maxOf(0, frame - 1); if (frame == 0 && inP == 0 && !inNote) flushBoxes(); return }
                if (ann > 0 || frame > 0) return
                if (q == "text:note-citation") { cite = maxOf(0, cite - 1); return }
                if (q == "text:note" && inNote) {
                    inNote = false
                    noteList.add(noteBuf.toString().trim())
                    runs.clear(); runs.addAll(sRuns); pStyle = sStyle; head = sHead; spanStack.clear(); spanStack.addAll(sSpans); inP = sInP
                    return
                }
                when (q) {
                    "text:span" -> if (inP > 0) { flushText(); if (spanStack.isNotEmpty()) spanStack.removeAt(spanStack.size - 1) }
                    "text:p", "text:h" -> { inP = maxOf(0, inP - 1); if (inP == 0) endPara() }
                    "text:list-item" -> { pendingMarker = ""; if (listStack.size <= 1) { itemLeft = 0; itemHang = 0 } }
                    "text:list" -> { if (listStack.isNotEmpty()) listStack.removeAt(listStack.size - 1); if (listStack.isEmpty()) { itemLeft = 0; itemHang = 0 } }
                    "table:table-cell", "table:covered-table-cell" -> if (tblDepth == 1) { cell?.let { c -> repeat(if (c.covered || c.paras.isEmpty()) c.rep.coerceAtMost(60) else 1) { tbl?.row?.add(c) } }; cell = null }
                    "table:table-row" -> if (tblDepth == 1) tbl?.let { it.rows.add(it.row); it.row = ArrayList() }
                    "table:table" -> {
                        if (tblDepth == 1) tbl?.let { t -> if (blocks.size < MAX_BLOCKS) blocks.add(buildTable(t, st)) }
                        tblDepth = maxOf(0, tblDepth - 1)
                        if (tblDepth == 0) { tbl = null; cell = null }
                    }
                }
            }
        })
        if (noteList.isNotEmpty()) {
            blocks.add(RPara(emptyList(), before = 240, after = 60, top = Bd(4, "999999")))
            noteList.forEachIndexed { k, t -> if (t.isNotEmpty()) blocks.add(RPara(listOf(RRun("[" + (k + 1) + "] " + t, sz = maxOf(16, defSz - 2))), after = 40)) }
        }
        return RichPage(blocks, setup, defSz, defFontName, 0, 0)
    }

    private fun toRoman(n0: Int): String {
        var n = n0.coerceIn(1, 3999); val sb = StringBuilder()
        for ((v, s) in listOf(1000 to "M", 900 to "CM", 500 to "D", 400 to "CD", 100 to "C", 90 to "XC", 50 to "L", 40 to "XL", 10 to "X", 9 to "IX", 5 to "V", 4 to "IV", 1 to "I")) while (n >= v) { sb.append(s); n -= v }
        return sb.toString()
    }

    private class OCell { val paras = ArrayList<RPara>(); var span = 1; var rowSpan = 1; var style: String? = null; var covered = false; var rep = 1 }
    private class OTbl { val rows = ArrayList<ArrayList<OCell>>(); val colW = ArrayList<Int>(); var style: String? = null; var row = ArrayList<OCell>() }

    private fun buildTable(t: OTbl, st: HashMap<String, OS>): RTable {
        val ncols = maxOf(t.colW.size, t.rows.maxOfOrNull { r -> r.size } ?: 0).coerceAtMost(60)
        val rem = IntArray(ncols + 1); val remSpan = IntArray(ncols + 1)
        val rows = ArrayList<List<RCell>>()
        for (r in t.rows) {
            val out = ArrayList<RCell>()
            var c = 0; var skip = 0
            for (cell in r) {
                if (c >= ncols) break
                if (cell.covered) {
                    if (skip > 0) { skip--; c++; continue }
                    if (c < rem.size && rem[c] > 0) {
                        val sp = remSpan[c].coerceAtLeast(1)
                        for (k in c until minOf(c + sp, rem.size)) rem[k]--
                        out.add(RCell(emptyList(), sp, 2)); skip = sp - 1; c++; continue
                    }
                    c++; continue
                }
                val cs = st["table-cell:" + (cell.style ?: "")]
                val rs = cell.rowSpan
                if (rs > 1) for (k in c until minOf(c + cell.span, rem.size)) { rem[k] = rs - 1; remSpan[k] = cell.span }
                out.add(RCell(cell.paras, cell.span, if (rs > 1) 1 else 0, cs?.tfill, cs?.tbt, cs?.tl, cs?.tb, cs?.tr, 0, cs?.valign ?: ""))
                skip = cell.span - 1; c++
            }
            rows.add(out)
        }
        val cols = if (t.colW.size == ncols && t.colW.all { it > 0 }) ArrayList(t.colW) else emptyList()
        return RTable(rows, cols)
    }
}
