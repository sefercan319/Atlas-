package com.odak.app.notes

import android.content.Context
import java.io.File

/** Notlar filesDir/notes/<id>.odn dosyalarında tutulur (her not ayrı dosya; biri bozulsa diğerleri etkilenmez). */
object NoteStore {
    private fun dir(c: Context): File = File(c.filesDir, "notes").also { it.mkdirs() }

    private fun safeId(id: String) = id.isNotBlank() && id.length <= 80 && id.all { it.isLetterOrDigit() || it == '-' || it == '_' }

    fun loadAll(c: Context): List<Note> {
        val now = System.currentTimeMillis()
        val out = ArrayList<Note>()
        for (f in dir(c).listFiles { x -> x.extension == "odn" } ?: emptyArray()) {
            val n = try { NotePure.decode(f.readText()) } catch (e: Exception) { null } ?: continue
            if (NotePure.isExpired(n, now)) { NoteMedia.deleteFiles(c, n); f.delete(); continue }
            out.add(n)
        }
        return out
    }

    fun save(c: Context, n: Note) {
        if (!safeId(n.id)) return
        val f = File(dir(c), n.id + ".odn")
        val tmp = File(dir(c), n.id + ".tmp")
        try {
            tmp.writeText(NotePure.encode(n))
            if (!tmp.renameTo(f)) { f.writeText(NotePure.encode(n)); tmp.delete() }
        } catch (e: Exception) { tmp.delete() }
    }

    /** Kalıcı silme: notun resim/ses/PDF dosyaları da silinir. */
    fun delete(c: Context, id: String) {
        if (!safeId(id)) return
        val f = File(dir(c), "$id.odn")
        try { NotePure.decode(f.readText())?.let { NoteMedia.deleteFiles(c, it) } } catch (e: Exception) { }
        f.delete()
    }

    fun trash(c: Context, n: Note) = save(c, n.copy(trashedAt = System.currentTimeMillis(), pinned = false))
    fun restore(c: Context, n: Note) = save(c, n.copy(trashedAt = 0L, updated = System.currentTimeMillis()))
    fun emptyTrash(c: Context) { loadAll(c).filter { it.trashedAt > 0L }.forEach { delete(c, it.id) } }
}
