package com.odak.app.theme

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/**
 * Her tasarımın kendine özgü dokunma tepkisi:
 *  Futuristik  – tarama çizgisi soldan sağa süpürür
 *  Frutiger    – jöle gibi ezilip esner (squash & stretch)
 *  Minimal     – alt çizgi mürekkep gibi soldan uzar, yazı solar
 *  Modern      – dokunulan noktada ışık lekesi (reveal) + hafif küçülme
 *  Neon        – dokunulan noktadan genişleyen halka
 *  Terminal    – anında ters renk, tuş gibi 2dp aşağı iner
 *  Skeuomorphism – fiziksel tuş: yaylı biçimde gömülür, üstten iç gölge, bırakınca geri yaylanır
 *  Neumorphism – kabarık yüzey 160 ms'de içe basık (inset) yüzeye döner
 *  Glassmorphism – cam yüzey hafif küçülür, çapraz bir ışık bandı süpürür
 *  Y2K – jel balon gibi ezilir (yassılaşıp genişler), dokunma noktasından yıldızlar saçılır
 *  Aurora – dokunulan noktadan nane renkli ışık yayılır, degrade kayar
 *  Claymorphism – kil gibi hafifçe gömülür (gölge ofsetleri yarıya iner), bırakınca yaylanır
 *  Dark Mode – Material durum katmanı: yüzey %12 açılır
 *  Cosmic – dokunma noktasından iki "warp" ışık halkası yayılır
 *  Sci-Fi HUD – dört köşe parantezi dışarıdan hedefe kilitlenir, sonda kısa parlama
 *  Cyber-Industrial – piston gibi 3dp iner, koyu panjur soldan sağa kapanır
 *  Neoclassical – altın dolgu alttan yükselir, alt çizgi soldan çizilir
 */
class Press(
    val style: DesignStyle,
    val pressed: State<Boolean>,
    val sx: State<Float>,
    val sy: State<Float>,
    val prog: Animatable<Float, androidx.compose.animation.core.AnimationVector1D>,
    val touch: androidx.compose.runtime.MutableState<Offset>
)

@Composable
fun rememberPress(style: DesignStyle, interaction: MutableInteractionSource): Press {
    val pressedState = interaction.collectIsPressedAsState()
    val p = pressedState.value
    val touch = remember { mutableStateOf(Offset.Unspecified) }
    val prog = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val sx = animateFloatAsState(pressTarget(style, p, true), pressSpec(style), label = "psx")
    val sy = animateFloatAsState(pressTarget(style, p, false), pressSpec(style), label = "psy")
    LaunchedEffect(p, style) {
        when (style) {
            DesignStyle.FUTURISTIC -> if (p) scope.launch {
                prog.snapTo(0f); prog.animateTo(1f, tween(260, easing = LinearEasing))
            }
            DesignStyle.NEON -> if (p) scope.launch {
                prog.snapTo(0f); prog.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
            }
            DesignStyle.MINIMAL, DesignStyle.WINDOWS11 ->
                prog.animateTo(if (p) 1f else 0f, tween(if (p) 220 else 340))
            DesignStyle.SKEUOMORPHISM ->
                prog.animateTo(if (p) 1f else 0f, if (p) tween<Float>(70) else spring<Float>(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium))
            DesignStyle.NEUMORPHISM ->
                prog.animateTo(if (p) 1f else 0f, tween(160, easing = FastOutSlowInEasing))
            DesignStyle.GLASSMORPHISM -> if (p) scope.launch {
                prog.snapTo(0f); prog.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
            }
            DesignStyle.Y2K -> if (p) scope.launch {
                prog.snapTo(0f); prog.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
            }
            DesignStyle.AURORA ->
                prog.animateTo(if (p) 1f else 0f, tween(if (p) 250 else 700, easing = FastOutSlowInEasing))
            DesignStyle.CLAYMORPHISM ->
                prog.animateTo(if (p) 1f else 0f, tween(140))
            DesignStyle.DARK ->
                prog.animateTo(if (p) 1f else 0f, tween(if (p) 100 else 250))
            DesignStyle.COSMIC -> if (p) scope.launch {
                prog.snapTo(0f); prog.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
            }
            DesignStyle.SCIFI_HUD -> if (p) scope.launch {
                prog.snapTo(0f); prog.animateTo(1f, tween(320, easing = LinearEasing))
            }
            DesignStyle.CYBER_INDUSTRIAL ->
                prog.animateTo(if (p) 1f else 0f, tween(if (p) 60 else 200))
            DesignStyle.NEOCLASSICAL ->
                prog.animateTo(if (p) 1f else 0f, tween(if (p) 450 else 300, easing = FastOutSlowInEasing))
            else -> {}
        }
    }
    return Press(style, pressedState, sx, sy, prog, touch)
}

private fun pressTarget(style: DesignStyle, p: Boolean, x: Boolean): Float {
    if (!p) return 1f
    return when (style) {
        DesignStyle.FRUTIGER_AERO -> if (x) 1.08f else 0.84f
        DesignStyle.WINDOWS11, DesignStyle.NEON -> 0.97f
        DesignStyle.SKEUOMORPHISM -> 0.975f
        DesignStyle.NEUMORPHISM -> 0.985f
        DesignStyle.GLASSMORPHISM -> 0.96f
        DesignStyle.Y2K -> if (x) 1.12f else 0.80f
        DesignStyle.CLAYMORPHISM -> 0.97f
        DesignStyle.AURORA, DesignStyle.DARK, DesignStyle.SCIFI_HUD -> 0.98f
        DesignStyle.COSMIC -> 0.96f
        DesignStyle.CYBER_INDUSTRIAL -> 0.97f
        DesignStyle.NEOCLASSICAL -> 0.99f
        else -> 1f
    }
}

private fun pressSpec(style: DesignStyle): androidx.compose.animation.core.FiniteAnimationSpec<Float> = when (style) {
    DesignStyle.FRUTIGER_AERO, DesignStyle.Y2K -> spring(Spring.DampingRatioHighBouncy, Spring.StiffnessMedium)
    DesignStyle.SKEUOMORPHISM -> spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)
    DesignStyle.GLASSMORPHISM -> spring(Spring.DampingRatioLowBouncy, Spring.StiffnessMediumLow)
    DesignStyle.CLAYMORPHISM -> spring(0.45f, Spring.StiffnessMedium)
    DesignStyle.COSMIC -> spring(0.6f, Spring.StiffnessLow)
    DesignStyle.CYBER_INDUSTRIAL -> spring(0.5f, Spring.StiffnessHigh)
    else -> tween(110)
}

/** En dışta uygulanır: ölçek / kayma / solma. */
fun Modifier.pressOuter(p: Press): Modifier = this
    .pointerInput(Unit) {
        awaitEachGesture {
            val d = awaitFirstDown(requireUnconsumed = false)
            p.touch.value = d.position
        }
    }
    .graphicsLayer {
        scaleX = p.sx.value
        scaleY = p.sy.value
        translationY = if ((p.style == DesignStyle.TERMINAL) && p.pressed.value) 2.dp.toPx()
        else if (p.style == DesignStyle.CYBER_INDUSTRIAL && p.pressed.value) 3.dp.toPx()
        else if (p.style == DesignStyle.SKEUOMORPHISM) 1.5.dp.toPx() * p.prog.value.coerceIn(0f, 1f)
        else 0f
        alpha = if (p.style == DesignStyle.MINIMAL) 1f - 0.45f * p.prog.value else 1f
    }

/** İçeriğin üstüne çizilen efekt; şekle kırpılır. */
fun Modifier.pressOverlay(p: Press, tint: Color, shape: Shape): Modifier = this
    .clip(shape)
    .drawWithContent {
        drawContent()
        val w = size.width
        val h = size.height
        val g = p.prog.value
        val c = if (p.touch.value.isSpecified) p.touch.value else Offset(w / 2f, h / 2f)
        when (p.style) {
            DesignStyle.FUTURISTIC -> if (g > 0f && g < 1f) {
                val x = w * g
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, tint.copy(alpha = 0.6f), Color.Transparent),
                        startX = x - 26.dp.toPx(), endX = x + 26.dp.toPx()
                    ),
                    size = Size(w, h)
                )
            }
            DesignStyle.MINIMAL -> if (g > 0f) {
                drawRect(tint, Offset(0f, h - 2.dp.toPx()), Size(w * g, 2.dp.toPx()))
            }
            DesignStyle.WINDOWS11 -> if (g > 0f) {
                val r = 90.dp.toPx()
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.40f * g), Color.Transparent), center = c, radius = r
                    ),
                    radius = r, center = c
                )
            }
            // Cam: dokunuşta çapraz ışık bandı soldan sağa geçer.
            DesignStyle.GLASSMORPHISM -> if (g > 0f && g < 1f) {
                val x = -w * 0.3f + g * w * 1.6f
                val half = 40.dp.toPx()
                drawRect(
                    Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.40f * (1f - g * 0.4f)), Color.Transparent),
                        start = Offset(x - half, 0f), end = Offset(x + half, h * 0.5f)
                    ),
                    size = Size(w, h)
                )
            }
            // Balon: dokunma noktasından yıldız parıltıları saçılır.
            DesignStyle.Y2K -> if (g > 0f && g < 1f) y2kBurst(c, g)
            // Aurora: dokunulan noktadan yumuşak ışık yayılır.
            DesignStyle.AURORA -> if (g > 0f) {
                val r = 150.dp.toPx() * (0.5f + 0.5f * g)
                drawCircle(
                    Brush.radialGradient(listOf(tint.copy(alpha = 0.38f * g), Color.Transparent), center = c, radius = r),
                    radius = r, center = c
                )
            }
            // Warp: dokunma noktasından iki ışık halkası yayılır.
            DesignStyle.COSMIC -> if (g > 0f && g < 1f) warpRings(c, g, tint)
            // HUD: parantezler hedefe kilitlenir.
            DesignStyle.SCIFI_HUD -> if (g > 0f && g < 1f) hudLockOn(tint, g)
            // Panjur: koyu bir perde soldan sağa kapanır (piston/damga hissi).
            DesignStyle.CYBER_INDUSTRIAL -> if (g > 0f) drawRect(Color(0x66000000), size = Size(w * g, h))
            // Neoklasik: altın dolgu alttan yükselir.
            DesignStyle.NEOCLASSICAL -> if (g > 0f) {
                drawRect(tint.copy(alpha = 0.22f), Offset(0f, h * (1f - g)), Size(w, h * g))
                drawRect(tint, Offset(0f, h - 1.5.dp.toPx()), Size(w * g, 1.5.dp.toPx()))
            }
            // Material durum katmanı: basılıyken yüzey %12 açılır.
            DesignStyle.DARK -> if (g > 0f) drawRect(Color.White.copy(alpha = 0.12f * g))
            // Fiziksel tuş: üstten iç gölge.
            DesignStyle.SKEUOMORPHISM -> if (g > 0f) {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.22f * g.coerceIn(0f, 1f)), Color.Transparent),
                        startY = 0f, endY = 8.dp.toPx()
                    ),
                    size = Size(w, 8.dp.toPx())
                )
            }
            DesignStyle.NEON -> if (g > 0f && g < 1f) {
                drawCircle(
                    tint.copy(alpha = (1f - g) * 0.9f),
                    radius = maxOf(w, h) * g, center = c, style = Stroke(2.dp.toPx())
                )
            }
            else -> {}
        }
    }
