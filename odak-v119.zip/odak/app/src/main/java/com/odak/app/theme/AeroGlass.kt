package com.odak.app.theme

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.background

/** Frutiger Aero cam yüzey: yarı saydam renk, üst parlama, alt ışıma. */
fun Modifier.aeroGlass(shape: Shape, tint: Color = Color(0xFFBFE4FF), strong: Boolean = false): Modifier = this
    .background(
        Brush.verticalGradient(
            listOf(
                tint.copy(alpha = if (strong) 0.95f else 0.55f),
                tint.copy(alpha = if (strong) 0.80f else 0.30f)
            )
        ),
        shape
    )
    .drawBehind {
        val inset = 2.dp.toPx()
        val r = minOf(size.height / 2f, 10.dp.toPx())
        drawRoundRect(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = if (strong) 0.55f else 0.42f), Color.White.copy(alpha = 0.08f))
            ),
            topLeft = Offset(inset, inset),
            size = Size(size.width - inset * 2, size.height * 0.48f),
            cornerRadius = CornerRadius(r)
        )
        drawOval(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.25f), Color.Transparent),
                center = Offset(size.width / 2f, size.height),
                radius = size.width * 0.5f
            ),
            topLeft = Offset(size.width * 0.1f, size.height * 0.6f),
            size = Size(size.width * 0.8f, size.height * 0.4f)
        )
    }
