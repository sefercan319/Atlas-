package com.odak.app.docs

import java.security.MessageDigest

/** E-kitap çıktıları: EPUB 3 (+ NCX uyumu) ve FB2. Saf Kotlin. Biçimsiz sayfalar önce zengin modele çevrilir. */
object EbookWrite {
    private const val XH = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"

    class Chapter(val title: String, val blocks: List<RBlock>, val rp: RichPage)

    private fun plainToRich(p: DocPage, showTitle: Boolean): RichPage {
        val bl = ArrayList<RBlock>()
        if (showTitle) bl.add(RPara(listOf(RRun(p.title, b = true, sz = 32)), head = 1, after = 160))
        for (t in p.paragraphs) bl.add(RPara(listOf(RRun(t)), after = 120))
        p.table?.let { rows ->
            val bd = Bd(4, "999999")
            val r2 = DocConvert.padRows(rows)
            bl.add(RTable(r2.map { r -> r.map { c -> RCell(listOf(RPara(listOf(RRun(c)))), bt = bd, bl = bd, bb = bd, br = bd) } }, emptyList()))
        }
        return RichPage(bl, PageSetup(), 22, null, 0, 0)
    }

    fun title(doc: Doc, given: String): String {
        if (given.isNotBlank()) return given.substringBeforeLast('.').take(120)
        for (p in doc.pages) {
            if (p.title.isNotBlank()) return p.title.take(120)
            p.paragraphs.firstOrNull { it.isNotBlank() }?.let { return it.take(60) }
        }
        return "Document"
    }

    /** Sayfaları bölümlere ayırır; biçimli sayfada başlık (en üst düzey) bölüm başlatır. */
    fun chapters(doc: Doc, book: String): List<Chapter> {
        val out = ArrayList<Chapter>()
        doc.pages.forEachIndexed { i, p ->
            val rp = p.rich?.let { Rich.flat(it) } ?: plainToRich(p, DocConvert.showTitle(doc, p))
            val heads = rp.blocks.withIndex().filter { (_, b) -> b is RPara && b.head in 1..2 }
            val level = heads.minOfOrNull { (it.value as RPara).head }
            val cuts = if (level == null) emptyList() else heads.filter { (it.value as RPara).head == level }.map { it.index }
            if (cuts.size < 2) {
                val t = p.title.ifBlank { (heads.firstOrNull()?.value as? RPara)?.plain?.trim().orEmpty() }.ifBlank { if (doc.pages.size > 1) "${i + 1}" else book }
                out.add(Chapter(t, rp.blocks, rp))
            } else {
                var start = 0
                if (cuts[0] > 0) { out.add(Chapter(book, rp.blocks.subList(0, cuts[0]), rp)); start = cuts[0] }
                cuts.forEachIndexed { k, c ->
                    val end = if (k + 1 < cuts.size) cuts[k + 1] else rp.blocks.size
                    out.add(Chapter((rp.blocks[c] as RPara).plain.trim().ifBlank { "${out.size + 1}" }.take(120), rp.blocks.subList(c, end), rp))
                }
            }
        }
        if (out.isEmpty()) out.add(Chapter(book, emptyList(), RichPage(emptyList())))
        return out
    }

    fun xhtmlFragment(h: String): String = h
        .replace("<br>", "<br/>").replace("&nbsp;", "&#160;")
        .replace(Regex("class=(\\w+)")) { "class=\"" + it.groupValues[1] + "\"" }
        .replace(Regex("(colspan|rowspan)=(\\d+)")) { it.groupValues[1] + "=\"" + it.groupValues[2] + "\"" }
        .replace(Regex("<(col|img)(\\s[^>]*[^/])>")) { "<" + it.groupValues[1] + it.groupValues[2] + "/>" }

    private fun x(s: String) = DocConvert.xml(s)

    private const val CSS = "body{font-family:serif;line-height:1.4;margin:0 .6em}p,h1,h2,h3,h4,h5,h6{margin:0 0 .5em;font-size:inherit;font-weight:inherit}h1{font-size:1.6em;font-weight:bold}h2{font-size:1.3em;font-weight:bold}" +
        "table{border-collapse:collapse;width:100%}td{vertical-align:top;padding:2px 4px}img{max-width:100%;height:auto}.t{display:inline-block;width:2em}.m{display:inline-block}"

    fun epub(doc: Doc, given: String = ""): ByteArray {
        val book = title(doc, given)
        val chs = chapters(doc, book)
        val files = ArrayList<Pair<String, ByteArray>>()
        val manifest = StringBuilder(); val spine = StringBuilder(); val nav = StringBuilder(); val ncx = StringBuilder()
        var imgN = 0
        val imgFiles = ArrayList<Pair<String, RImg>>()
        chs.forEachIndexed { i, c ->
            val id = "c${i + 1}"
            val body = StringBuilder()
            val src: (RImg) -> String = { im -> imgN++; val n = "images/img$imgN.${im.ext}"; imgFiles.add(n to im); n }
            for (b in c.blocks) body.append(xhtmlFragment(when (b) { is RPara -> RichHtml.para(b, c.rp, src); is RTable -> RichHtml.table(b, c.rp, src); is RBox -> "" }))
            val page = XH + "<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\"><head><meta charset=\"utf-8\"/><title>${x(c.title)}</title><link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\"/></head><body>\n$body</body></html>"
            files.add("OEBPS/$id.xhtml" to page.toByteArray())
            manifest.append("<item id=\"$id\" href=\"$id.xhtml\" media-type=\"application/xhtml+xml\"/>")
            spine.append("<itemref idref=\"$id\"/>")
            nav.append("<li><a href=\"$id.xhtml\">${x(c.title)}</a></li>")
            ncx.append("<navPoint id=\"n${i + 1}\" playOrder=\"${i + 1}\"><navLabel><text>${x(c.title)}</text></navLabel><content src=\"$id.xhtml\"/></navPoint>")
        }
        imgFiles.forEachIndexed { k, (n, im) ->
            files.add("OEBPS/$n" to im.data)
            manifest.append("<item id=\"i${k + 1}\" href=\"$n\" media-type=\"${im.mime}\"/>")
        }
        val uid = "urn:uuid:" + MessageDigest.getInstance("MD5").digest((book + chs.size + chs.sumOf { it.blocks.size }).toByteArray()).joinToString("") { "%02x".format(it) }.let { h -> "${h.substring(0, 8)}-${h.substring(8, 12)}-${h.substring(12, 16)}-${h.substring(16, 20)}-${h.substring(20)}" }
        val now = java.time.Instant.now().truncatedTo(java.time.temporal.ChronoUnit.SECONDS).toString()
        val opf = XH + "<package xmlns=\"http://www.idpf.org/2007/opf\" version=\"3.0\" unique-identifier=\"uid\"><metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\">" +
            "<dc:identifier id=\"uid\">$uid</dc:identifier><dc:title>${x(book)}</dc:title><dc:language>und</dc:language><meta property=\"dcterms:modified\">$now</meta></metadata>" +
            "<manifest><item id=\"nav\" href=\"nav.xhtml\" media-type=\"application/xhtml+xml\" properties=\"nav\"/><item id=\"ncx\" href=\"toc.ncx\" media-type=\"application/x-dtbncx+xml\"/><item id=\"css\" href=\"style.css\" media-type=\"text/css\"/>$manifest</manifest><spine toc=\"ncx\">$spine</spine></package>"
        val navX = XH + "<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\"><head><meta charset=\"utf-8\"/><title>${x(book)}</title></head><body><nav epub:type=\"toc\"><ol>$nav</ol></nav></body></html>"
        val ncxX = XH + "<ncx xmlns=\"http://www.daisy.org/z3986/2005/ncx/\" version=\"2005-1\"><head><meta name=\"dtb:uid\" content=\"$uid\"/></head><docTitle><text>${x(book)}</text></docTitle><navMap>$ncx</navMap></ncx>"
        val container = XH + "<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\"><rootfiles><rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles></container>"
        return DocWrite.zipBytes(listOf(
            "META-INF/container.xml" to container.toByteArray(), "OEBPS/content.opf" to opf.toByteArray(), "OEBPS/nav.xhtml" to navX.toByteArray(),
            "OEBPS/toc.ncx" to ncxX.toByteArray(), "OEBPS/style.css" to CSS.toByteArray()
        ) + files, mimetype = "application/epub+zip")
    }

    // ---------------- FB2 ----------------
    private fun fbRuns(p: RPara, bin: (RImg) -> String): String {
        val sb = StringBuilder()
        if (p.marker.isNotEmpty()) sb.append(x(p.marker)).append(' ')
        for (r in p.runs) {
            if (r.img != null) continue
            if (r.text.isEmpty()) continue
            var t = x(r.text).replace("\t", " ").replace("\n", " ")
            if (r.sup > 0) t = "<sup>$t</sup>" else if (r.sup < 0) t = "<sub>$t</sub>"
            if (r.s) t = "<strikethrough>$t</strikethrough>"
            if (r.i) t = "<emphasis>$t</emphasis>"
            if (r.b) t = "<strong>$t</strong>"
            if (r.font?.lowercase()?.let { it.contains("courier") || it.contains("mono") } == true) t = "<code>$t</code>"
            sb.append(t)
        }
        return sb.toString()
    }

    fun fb2(doc: Doc, given: String = ""): ByteArray {
        val book = title(doc, given)
        val chs = chapters(doc, book)
        val bins = ArrayList<Pair<String, RImg>>()
        val reg: (RImg) -> String = { im -> val id = "img${bins.size + 1}"; bins.add(id to im); id }
        val body = StringBuilder("<body><title><p>${x(book)}</p></title>\n")
        for (c in chs) {
            body.append("<section><title><p>${x(c.title)}</p></title>\n")
            var skippedTitle = false
            for (b in c.blocks) when (b) {
                is RPara -> {
                    val txt = fbRuns(b, reg)
                    if (!skippedTitle && b.head in 1..2 && b.plain.trim() == c.title) { skippedTitle = true }
                    else if (b.head > 0 && txt.isNotBlank()) body.append("<subtitle>").append(txt).append("</subtitle>\n")
                    else if (txt.isNotBlank()) body.append("<p>").append(txt).append("</p>\n")
                    else if (b.runs.none { it.img != null }) body.append("<empty-line/>\n")
                    for (r in b.runs) r.img?.let { body.append("<image l:href=\"#").append(reg(it)).append("\"/>\n") }
                }
                is RBox -> {}
                is RTable -> {
                    body.append("<table>")
                    for (r in b.rows) { body.append("<tr>"); for (cell in r) { if (cell.vMerge == 2) continue; body.append("<td").append(if (cell.span > 1) " colspan=\"${cell.span}\"" else "").append(">").append(cell.paras.joinToString(" ") { fbRuns(it, reg) }).append("</td>") }; body.append("</tr>") }
                    body.append("</table>\n")
                }
            }
            body.append("</section>\n")
        }
        body.append("</body>\n")
        val date = java.time.LocalDate.now().toString()
        val id = MessageDigest.getInstance("MD5").digest(book.toByteArray()).joinToString("") { "%02x".format(it) }
        val sb = StringBuilder(XH)
        sb.append("<FictionBook xmlns=\"http://www.gribuser.ru/xml/fictionbook/2.0\" xmlns:l=\"http://www.w3.org/1999/xlink\"><description><title-info><genre>prose_contemporary</genre><author><nickname>Atlas</nickname></author><book-title>${x(book)}</book-title><lang>und</lang></title-info>")
        sb.append("<document-info><author><nickname>Atlas</nickname></author><date value=\"$date\">$date</date><id>$id</id><version>1.0</version></document-info></description>\n")
        sb.append(body)
        for ((bid, im) in bins) sb.append("<binary id=\"$bid\" content-type=\"${im.mime}\">").append(java.util.Base64.getEncoder().encodeToString(im.data)).append("</binary>\n")
        sb.append("</FictionBook>")
        return sb.toString().toByteArray()
    }
}
