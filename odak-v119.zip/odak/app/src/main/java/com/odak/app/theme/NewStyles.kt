package com.odak.app.theme

import android.graphics.Paint as APaint
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.random.Random

/*
 * Skeuomorphism / Neumorphism / Glassmorphism için ortak çizim araçları.
 *  Skeuo: doku (deri, fırçalı metal, kâğıt), parlama, kabartma kenar, basınca içe gömülme.
 *  Neumo: tek renk yüzey + çift gölge (sol-üst ışık, sağ-alt koyu); basınca içe (inset) geçiş.
 *  Glass: yarı saydam panel, ışıklı kenar, speküler parlama, dokunuşta ışık süpürmesi.
 */

/** Şekli (dp'ye çözülmüş) Path'e çevirir. */
internal fun shapePath(shape: Shape, size: Size, density: Density, dir: LayoutDirection): Path =
    when (val o = shape.createOutline(size, dir, density)) {
        is Outline.Rectangle -> Path().apply { addRect(o.rect) }
        is Outline.Rounded -> Path().apply { addRoundRect(o.roundRect) }
        is Outline.Generic -> o.path
    }

/** Neumorphism ışık/gölge renkleri: zemin rengine göre türetilir (koyu zeminde de çalışır). */
fun neuLight(base: Color): Color = lerp(base, Color.White, 0.85f).copy(alpha = 0.95f)
fun neuDark(base: Color): Color = lerp(base, Color(0xFF3A4660), 0.55f).copy(alpha = 0.60f)

/** depth 0 = kabarık (iki dış gölge), 1 = içe basık (iki iç gölge). Aradaki değerler karışır. */
fun Modifier.neuSurface(
    shape: Shape,
    base: Color,
    depth: Float = 0f,
    dist: Dp = 6.dp,
    blur: Dp = 12.dp
): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection).asAndroidPath()
    val d = dist.toPx()
    val b = blur.toPx()
    val ins = depth.coerceIn(0f, 1f)
    val raise = 1f - ins
    val light = neuLight(base)
    val dark = neuDark(base)
    drawIntoCanvas { c ->
        val nc = c.nativeCanvas
        val p = APaint(APaint.ANTI_ALIAS_FLAG)
        p.color = base.toArgb()
        if (raise > 0.02f) {
            p.setShadowLayer(b, -d * raise, -d * raise, light.copy(alpha = light.alpha * raise).toArgb())
            nc.drawPath(path, p)
            p.setShadowLayer(b, d * raise, d * raise, dark.copy(alpha = dark.alpha * raise).toArgb())
            nc.drawPath(path, p)
        }
        p.clearShadowLayer()
        nc.drawPath(path, p)
        if (ins > 0.02f) {
            nc.save()
            nc.clipPath(path)
            val frame = android.graphics.Path()
            frame.fillType = android.graphics.Path.FillType.EVEN_ODD
            frame.addRect(-size.width, -size.height, size.width * 2f, size.height * 2f, android.graphics.Path.Direction.CW)
            frame.addPath(path)
            val q = APaint(APaint.ANTI_ALIAS_FLAG)
            q.color = base.toArgb()
            q.setShadowLayer(b * 0.8f, d * ins * 0.8f, d * ins * 0.8f, dark.copy(alpha = dark.alpha * ins).toArgb())
            nc.drawPath(frame, q)
            q.setShadowLayer(b * 0.8f, -d * ins * 0.8f, -d * ins * 0.8f, light.copy(alpha = light.alpha * ins).toArgb())
            nc.drawPath(frame, q)
            nc.restore()
        }
    }
}

enum class Grain { NONE, LEATHER, METAL, PAPER }

/** Skeuomorphic malzeme yüzeyi. pressed 0..1: içe gömülür, gölge küçülür, üst iç gölge büyür. */
fun Modifier.skeuoSurface(
    shape: Shape,
    top: Color,
    bottom: Color,
    pressed: Float = 0f,
    grain: Grain = Grain.NONE,
    elevation: Dp = 5.dp,
    stitch: Color? = null,
    gloss: Boolean = true
): Modifier {
    val p = pressed.coerceIn(0f, 1f)
    val lift = if (elevation > 0.dp) Modifier.shadow(elevation * (1f - 0.75f * p), shape) else Modifier
    return this.then(lift).drawBehind {
        val path = shapePath(shape, size, this, layoutDirection)
        val t = lerp(top, Color.Black, 0.14f * p)
        val b = lerp(bottom, Color.Black, 0.06f * p)
        drawPath(path, Brush.verticalGradient(listOf(t, b)))
        clipPath(path) {
            val w = size.width
            val h = size.height
            when (grain) {
                Grain.LEATHER -> {
                    val rnd = Random(7)
                    val n = (w * h / (10.dp.toPx() * 10.dp.toPx()) * 5f).toInt().coerceIn(20, 900)
                    repeat(n) {
                        val r = (0.5f + rnd.nextFloat() * 0.9f) * 1.dp.toPx()
                        val c = if (rnd.nextBoolean()) Color(0x1A000000) else Color(0x0DFFFFFF)
                        drawCircle(c, r, Offset(rnd.nextFloat() * w, rnd.nextFloat() * h))
                    }
                }
                Grain.METAL -> {
                    val step = 2.dp.toPx()
                    var y = 0f
                    var i = 0
                    while (y < h) {
                        drawLine(
                            if (i % 2 == 0) Color(0x0DFFFFFF) else Color(0x0A000000),
                            Offset(0f, y), Offset(w, y), 1f
                        )
                        y += step; i++
                    }
                }
                Grain.PAPER -> {
                    val rnd = Random(3)
                    val n = (w * h / (12.dp.toPx() * 12.dp.toPx()) * 3f).toInt().coerceIn(10, 400)
                    repeat(n) {
                        drawCircle(Color(0x0F5A4630), 0.6.dp.toPx(), Offset(rnd.nextFloat() * w, rnd.nextFloat() * h))
                    }
                }
                Grain.NONE -> {}
            }
            if (gloss) {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.34f * (1f - p)), Color.White.copy(alpha = 0.02f)),
                        startY = 0f, endY = h * 0.5f
                    ),
                    size = Size(w, h * 0.5f)
                )
            }
            if (p > 0f) {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.38f * p), Color.Transparent),
                        startY = 0f, endY = 9.dp.toPx()
                    ),
                    size = Size(w, 9.dp.toPx())
                )
            }
        }
        drawPath(
            path,
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.55f * (1f - p)), Color.Black.copy(alpha = 0.40f))),
            style = Stroke(1.2.dp.toPx())
        )
        if (stitch != null) {
            val inset = 4.dp.toPx()
            drawRoundRect(
                stitch,
                topLeft = Offset(inset, inset),
                size = Size(size.width - inset * 2, size.height - inset * 2),
                cornerRadius = CornerRadius(6.dp.toPx()),
                style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 3.dp.toPx())))
            )
        }
    }
}

/** Buzlu cam panel. sweep 0..1: dokunuşta çapraz ışık bandı geçer. */
fun Modifier.glassPanel(
    shape: Shape,
    tint: Color = Color.White,
    alpha: Float = 0.16f,
    sweep: Float = 0f,
    shadow: Boolean = true
): Modifier = this.drawBehind {
    val path = shapePath(shape, size, this, layoutDirection)
    if (shadow) {
        drawIntoCanvas { c ->
            val nc = c.nativeCanvas
            nc.save()
            nc.clipOutPath(path.asAndroidPath())
            val p = APaint(APaint.ANTI_ALIAS_FLAG)
            p.color = android.graphics.Color.BLACK
            p.setShadowLayer(22.dp.toPx(), 0f, 8.dp.toPx(), 0x55000000)
            nc.drawPath(path.asAndroidPath(), p)
            nc.restore()
        }
    }
    drawPath(
        path,
        Brush.linearGradient(
            listOf(tint.copy(alpha = alpha * 1.7f), tint.copy(alpha = alpha * 0.5f)),
            start = Offset.Zero, end = Offset(size.width, size.height)
        )
    )
    clipPath(path) {
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
                center = Offset(size.width * 0.12f, 0f), radius = size.width * 0.65f
            ),
            radius = size.width * 0.65f, center = Offset(size.width * 0.12f, 0f)
        )
        if (sweep > 0f && sweep < 1f) {
            val x = -size.width * 0.3f + sweep * size.width * 1.6f
            val half = 44.dp.toPx()
            drawRect(
                Brush.linearGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.38f), Color.Transparent),
                    start = Offset(x - half, 0f), end = Offset(x + half, size.height * 0.5f)
                ),
                size = size
            )
        }
    }
    drawPath(
        path,
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.75f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.35f)),
            start = Offset.Zero, end = Offset(size.width, size.height)
        ),
        style = Stroke(1.dp.toPx())
    )
}

/** Skeuomorphism masa zemini: kraft kâğıt/keten dokusu + kenar karartması. */
fun Modifier.skeuoDesk(base: Color): Modifier = this
    .background(Brush.verticalGradient(listOf(lerp(base, Color.White, 0.12f), base, lerp(base, Color.Black, 0.12f))))
    .drawBehind {
        val step = 3.dp.toPx()
        var y = 0f
        var i = 0
        while (y < size.height) {
            drawLine(if (i % 2 == 0) Color(0x0A000000) else Color(0x08FFFFFF), Offset(0f, y), Offset(size.width, y), 1f)
            y += step; i++
        }
        var x = 0f
        while (x < size.width) {
            drawLine(Color(0x06000000), Offset(x, 0f), Offset(x, size.height), 1f)
            x += step * 2
        }
        drawRect(
            Brush.radialGradient(
                listOf(Color.Transparent, Color(0x33000000)),
                center = Offset(size.width / 2f, size.height / 2f),
                radius = maxOf(size.width, size.height) * 0.75f
            )
        )
    }

/** Glassmorphism zemini: renkli, yavaşça süzülen bulanık küreler (cam panellerin arkasında görünür). */
@Composable
fun GlassOrbs(modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "glassOrbs")
    val a by tr.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "orbPhase"
    )
    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(listOf(Color(0xFF14083F), Color(0xFF2B1B86), Color(0xFF0A4A66)))
            )
    ) {
        Box(
            Modifier.fillMaxSize().blur(56.dp).drawBehind {
                val w = size.width
                val h = size.height
                val r = minOf(w, h) * 0.42f
                // Renkler metin kontrastı (≥4.5:1) için bilinçli koyu tutuldu; bkz. NewStylesTest.
                drawCircle(Color(0xFFA3217A), r, Offset(w * (0.15f + 0.25f * a), h * (0.18f + 0.10f * a)), alpha = 0.75f)
                drawCircle(Color(0xFF0B7096), r * 1.1f, Offset(w * (0.85f - 0.20f * a), h * (0.45f + 0.12f * a)), alpha = 0.75f)
                drawCircle(Color(0xFF5B35C8), r * 0.9f, Offset(w * (0.30f + 0.15f * a), h * (0.85f - 0.12f * a)), alpha = 0.75f)
            }
        )
        // Okunabilirlik örtüsü: parlak küre altında bile beyaz metin okunur.
        Box(Modifier.fillMaxSize().background(Color(0x66140A3F)))
    }
}
