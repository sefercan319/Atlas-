package com.odak.app.theme

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Bu modifierin içindekini (stilin gradyanı, parlaması, deseni) açık-koyu yapısını koruyarak [target] rengine boyar.
 * [base]: stilin kendi tasarımındaki ortalama renk. [profile]: stilin karakteri (parlama korunur mu, kontrast ne kadar).
 * [target] null ise hiçbir şey yapmaz. [pad]: gölge/parıltı kutu dışına taşarsa kesilmesin diye katman payı.
 */
fun Modifier.recolor(target: Color?, base: Color, profile: RecolorProfile, pad: Dp = 0.dp): Modifier {
    if (target == null) return this
    val m = Recolor.matrix(target.toArgb(), base.toArgb(), profile)
    val hm = if (profile.spec > 0f) Recolor.highlightMatrix(profile) else null
    return this.drawWithContent {
        drawIntoCanvas { canvas ->
            val p = pad.toPx()
            val bounds = Rect(-p, -p, size.width + p, size.height + p)
            canvas.saveLayer(bounds, Paint())
            canvas.saveLayer(bounds, Paint().apply { colorFilter = ColorFilter.colorMatrix(ColorMatrix(m)) })
            drawContent()
            canvas.restore()
            if (hm != null) {
                // Parlama: yalnız çok parlak pikseller gri olarak Screen ile eklenir → beyaz parlama boyanmadan kalır.
                canvas.saveLayer(bounds, Paint().apply { colorFilter = ColorFilter.colorMatrix(ColorMatrix(hm)); blendMode = BlendMode.Screen })
                drawContent()
                canvas.restore()
            }
            canvas.restore()
        }
    }
}
