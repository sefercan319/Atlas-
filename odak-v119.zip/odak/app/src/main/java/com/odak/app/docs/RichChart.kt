package com.odak.app.docs

import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler

/**
 * PPTX grafiği (c:chart) → kutular. Sütun/çubuk ve çizgi grafikleri kutu + döndürülmüş çizgi parçalarıyla çizilir;
 * pasta, alan, dağılım vb. veri tablosu olarak verilir. Saf Kotlin.
 */
object RichChart {
    class Ser(var name: String = "", val cats: MutableMap<Int, String> = HashMap(), val vals: MutableMap<Int, Double> = HashMap(), var color: String? = null, var noLine: Boolean = false, val size: MutableMap<Int, Double> = HashMap())
    class Data(var kind: String = "", var doughnut: Boolean = false, var horizontal: Boolean = false, var title: String = "", val sers: ArrayList<Ser> = ArrayList())

    private val PALETTE = listOf("4472C4", "ED7D31", "A5A5A5", "FFC000", "5B9BD5", "70AD47")

    fun parse(xml: ByteArray, theme: Map<String, String>): Data {
        val d = Data()
        val stack = ArrayList<String>()
        var cur: Ser? = null; var sec = ""; var idx = 0; var inV = false; val buf = StringBuilder(); var titleDone = false; var inTitleT = false
        DocParse.sax(xml, object : DefaultHandler() {
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                stack.add(q); val n = stack.size - 1
                when (q) {
                    "c:barChart", "c:bar3DChart" -> if (d.kind.isEmpty()) d.kind = "bar"
                    "c:lineChart", "c:line3DChart" -> if (d.kind.isEmpty()) d.kind = "line"
                    "c:pieChart", "c:pie3DChart", "c:doughnutChart", "c:ofPieChart" -> if (d.kind.isEmpty()) { d.kind = "pie"; d.doughnut = q == "c:doughnutChart" }
                    "c:areaChart", "c:area3DChart" -> if (d.kind.isEmpty()) d.kind = "area"
                    "c:scatterChart" -> if (d.kind.isEmpty()) d.kind = "scatter"
                    "c:radarChart" -> if (d.kind.isEmpty()) d.kind = "radar"
                    "c:bubbleChart" -> if (d.kind.isEmpty()) d.kind = "bubble"
                    "c:stockChart" -> if (d.kind.isEmpty()) d.kind = "stock"
                    "c:surfaceChart", "c:surface3DChart" -> if (d.kind.isEmpty()) d.kind = "other"
                    "a:noFill" -> if (cur != null && stack.getOrNull(n - 1) == "a:ln" && stack.getOrNull(n - 2) == "c:spPr" && stack.getOrNull(n - 3) == "c:ser") cur!!.noLine = true
                    "c:bubbleSize" -> if (cur != null) sec = "size"
                    "c:barDir" -> if (a?.getValue("val") == "bar") d.horizontal = true
                    "c:ser" -> if (d.sers.size < 12) { cur = Ser().also { d.sers.add(it) }; sec = "" }
                    "c:tx" -> if (cur != null && stack.getOrNull(n - 1) == "c:ser") sec = "tx"
                    "c:cat", "c:xVal" -> if (cur != null) sec = "cat"
                    "c:val", "c:yVal" -> if (cur != null) sec = "val"
                    "c:pt" -> idx = a?.getValue("idx")?.toIntOrNull() ?: 0
                    "c:v" -> { inV = true; buf.setLength(0) }
                    "a:t" -> if (!titleDone && cur == null && stack.contains("c:title")) { inTitleT = true; buf.setLength(0) }
                    "a:srgbClr", "a:schemeClr" -> if (cur != null && stack.getOrNull(n - 1) == "a:solidFill" && stack.getOrNull(n - 2) == "c:spPr" && stack.getOrNull(n - 3) == "c:ser" && cur!!.color == null)
                        cur!!.color = if (q == "a:srgbClr") Rich.hex(a?.getValue("val")) else a?.getValue("val")?.let { RichPptx.schemeName(it) }?.let { theme[it] }
                }
            }
            override fun characters(ch: CharArray, s: Int, len: Int) { if (inV || inTitleT) buf.append(ch, s, len) }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q) {
                    "c:v" -> {
                        inV = false
                        val c = cur
                        if (c != null) when (sec) {
                            "tx" -> if (c.name.isEmpty()) c.name = buf.toString().trim()
                            "cat" -> if (c.cats.size < 500) c.cats[idx] = buf.toString().trim()
                            "val" -> if (c.vals.size < 500) buf.toString().trim().toDoubleOrNull()?.let { c.vals[idx] = it }
                            "size" -> if (c.size.size < 500) buf.toString().trim().toDoubleOrNull()?.let { c.size[idx] = it }
                        }
                    }
                    "a:t" -> if (inTitleT) { inTitleT = false; d.title += buf.toString() }
                    "c:title" -> if (cur == null) titleDone = true
                    "c:ser" -> { cur = null; sec = "" }
                }
                if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
            }
        })
        d.title = d.title.trim()
        return d
    }

    private fun nice(v: Double): Double {
        if (v <= 0) return 1.0
        val p = Math.pow(10.0, Math.floor(Math.log10(v)))
        val f = v / p
        return p * when { f <= 1 -> 1.0; f <= 2 -> 2.0; f <= 2.5 -> 2.5; f <= 5 -> 5.0; else -> 10.0 }
    }

    private fun fmt(v: Double): String = if (v == Math.floor(v) && Math.abs(v) < 1e9) v.toLong().toString() else String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

    private fun text(t: String, sz: Int, align: String, color: String = "404040", bold: Boolean = false) =
        RPara(listOf(RRun(t, b = bold, color = color, sz = sz)), align, before = 0, after = 0)

    private fun seg(out: MutableList<RBlock>, x1: Int, y1: Int, x2: Int, y2: Int, thick: Int, col: String) {
        val dx = (x2 - x1).toDouble(); val dy = (y2 - y1).toDouble()
        val len = Math.sqrt(dx * dx + dy * dy).toInt().coerceAtLeast(1)
        out.add(RBox((x1 + x2) / 2 - len / 2, (y1 + y2) / 2 - thick / 2, len, thick, emptyList(), fill = col, rot = Math.toDegrees(Math.atan2(dy, dx)).toFloat()))
    }

    private fun niceRange(mn: Double, mx: Double): Pair<Double, Double> {
        val span = if (mx > mn) mx - mn else Math.abs(mx).coerceAtLeast(1.0)
        var step = nice(span / 4)
        var lo = Math.floor(mn / step) * step
        while (lo + 4 * step < mx) step = nice(step * 1.01 + 1e-9).let { if (it <= step) step * 2 else it }
        lo = Math.floor(mn / step) * step
        return lo to lo + 4 * step
    }

    private fun radar(d: Data, out: MutableList<RBlock>, x: Int, y: Int, w: Int, h: Int, titleH: Int, legH: Int, ncat: Int, cats: List<String>, color: (Int) -> String) {
        val areaTop = y + titleH + 100; val areaH = h - titleH - legH - 150
        val R = (minOf(w, areaH) / 2 - 420).coerceAtLeast(300)
        val cx = x + w / 2; val cy = areaTop + areaH / 2
        val mx = nice(d.sers.maxOf { sr -> sr.vals.values.maxOrNull() ?: 0.0 }.coerceAtLeast(0.0001))
        fun pt(i: Int, f: Double): Pair<Int, Int> { val a = -Math.PI / 2 + 2 * Math.PI * i / ncat; return (cx + R * f * Math.cos(a)).toInt() to (cy + R * f * Math.sin(a)).toInt() }
        for (ring in 1..4) {
            val f = ring / 4.0
            for (i in 0 until ncat) { val a = pt(i, f); val b = pt((i + 1) % ncat, f); seg(out, a.first, a.second, b.first, b.second, 8, "D9D9D9") }
            out.add(RBox(cx + 40, pt(0, f).second - 120, 700, 240, listOf(text(fmt(mx * f), 14, "left", "808080"))))
        }
        for (i in 0 until ncat) {
            val e = pt(i, 1.0); seg(out, cx, cy, e.first, e.second, 8, "D9D9D9")
            val l = pt(i, 1.0 + 300.0 / R)
            out.add(RBox(l.first - 700, l.second - 130, 1400, 260, listOf(text(cats[i].take(14), 16, "center")), valign = "center"))
        }
        for (j in d.sers.indices) {
            var first: Pair<Int, Int>? = null; var prev: Pair<Int, Int>? = null
            for (i in 0 until ncat) {
                val v = d.sers[j].vals[i] ?: continue
                val p = pt(i, (v / mx).coerceIn(0.0, 1.0))
                prev?.let { seg(out, it.first, it.second, p.first, p.second, 24, color(j)) }
                out.add(RBox(p.first - 45, p.second - 45, 90, 90, emptyList(), fill = color(j), round = true))
                if (first == null) first = p; prev = p
            }
            if (first != null && prev != null && prev != first) seg(out, prev.first, prev.second, first.first, first.second, 24, color(j))
        }
    }

    fun render(xml: ByteArray, x: Int, y: Int, w: Int, h: Int, theme: Map<String, String>): List<RBlock> =
        try { render(parse(xml, theme), x, y, w, h, theme) } catch (e: Exception) { emptyList() }

    fun render(d: Data, x: Int, y: Int, w: Int, h: Int, theme: Map<String, String>): List<RBlock> {
        if (d.sers.isEmpty() || w < 600 || h < 600) return emptyList()
        val out = ArrayList<RBlock>()
        val ncat = d.sers.maxOf { s -> maxOf(s.cats.size, (s.vals.keys.maxOrNull() ?: -1) + 1) }.coerceAtLeast(1)
        val cats = (0 until ncat).map { i -> d.sers.firstNotNullOfOrNull { it.cats[i] } ?: (i + 1).toString() }
        fun color(i: Int) = d.sers[i].color ?: PALETTE[i % PALETTE.size]
        val titleH = if (d.title.isNotEmpty()) 380 else 0
        if (titleH > 0) out.add(RBox(x, y, w, titleH, listOf(text(d.title, 24, "center", bold = true)), valign = "center"))
        val legend = d.sers.size > 1 || d.kind == "pie"
        val legH = if (legend && d.kind != "pie") 300 else 0
        if (d.kind == "radar") {
            radar(d, out, x, y, w, h, titleH, if (d.sers.size > 1) 300 else 0, ncat, cats, ::color)
            if (d.sers.size > 1) out.add(RBox(x, y + h - 300, w, 300, listOf(RPara(d.sers.indices.flatMap { j -> listOf(RRun("■ ", color = color(j), sz = 18), RRun(d.sers[j].name.ifEmpty { "Seri ${j + 1}" } + "   ", color = "404040", sz = 16)) }, "center", before = 0, after = 0)), valign = "center"))
            return out
        }
        val isXY = d.kind == "scatter" || d.kind == "bubble"
        if (d.kind == "bar" || d.kind == "line" || d.kind == "area" || isXY || d.kind == "stock") {
            val horizontal = d.kind == "bar" && d.horizontal
            val maxV = maxOf(0.0, d.sers.maxOf { s -> s.vals.values.maxOrNull() ?: 0.0 })
            val minV = minOf(0.0, d.sers.minOf { s -> s.vals.values.minOrNull() ?: 0.0 })
            val rng = if (d.kind == "stock") niceRange(d.sers.minOf { s -> s.vals.values.minOrNull() ?: 0.0 }, d.sers.maxOf { s -> s.vals.values.maxOrNull() ?: 1.0 }) else null
            val hi = rng?.second ?: if (maxV <= 0.0) 0.0 else nice(maxV)
            val lo = rng?.first ?: if (minV >= 0.0) 0.0 else -nice(-minV)
            val span = (hi - lo).takeIf { it > 0 } ?: 1.0
            val labW = 700; val catH = if (horizontal) 0 else 360
            val px = x + labW; val pw = w - labW - 150
            val py = y + titleH + 100; val ph = h - titleH - legH - catH - 150
            if (pw < 300 || ph < 300) return out
            // ızgara + değer etiketleri
            for (k in 0..4) {
                val v = lo + span * k / 4.0
                if (!horizontal) {
                    val gy = py + ph - (ph * k / 4.0).toInt()
                    out.add(RBox(px, gy - 3, pw, 6, emptyList(), fill = "D9D9D9"))
                    out.add(RBox(x, gy - 130, labW - 60, 260, listOf(text(fmt(v), 16, "right")), valign = "center"))
                } else {
                    val gx = px + (pw * k / 4.0).toInt()
                    out.add(RBox(gx - 3, py, 6, ph, emptyList(), fill = "D9D9D9"))
                    out.add(RBox(gx - 300, py + ph + 20, 600, 260, listOf(text(fmt(v), 16, "center")), valign = "center"))
                }
            }
            val nser = d.sers.size
            val slot = (if (horizontal) ph else pw).toDouble() / ncat
            val zero = (-lo) / span
            val xsAll = if (isXY) d.sers.flatMap { sr -> (0 until ncat).mapNotNull { i -> (sr.cats[i] ?: "").toDoubleOrNull() ?: (i + 1).toDouble() } } else emptyList()
            val xMin = xsAll.minOrNull() ?: 0.0; val xMax = (xsAll.maxOrNull() ?: 1.0).let { if (it <= xMin) xMin + 1 else it }
            if (isXY) for (k in 0..4) {
                val v = xMin + (xMax - xMin) * k / 4.0
                out.add(RBox(px + (pw * k / 4.0).toInt() - 400, py + ph + 30, 800, catH, listOf(text(fmt(v), 16, "center"))))
            }
            if (!isXY) for (i in 0 until ncat) {
                val label = cats[i].take(14)
                if (!horizontal) out.add(RBox((px + slot * i).toInt(), py + ph + 30, slot.toInt(), catH, listOf(text(label, 16, "center")), valign = "")) 
                else out.add(RBox(x, (py + slot * i).toInt(), labW - 60, slot.toInt(), listOf(text(label, 16, "right")), valign = "center"))
            }
            if (d.kind == "bar") {
                val bw = slot * 0.8 / nser
                for (j in 0 until nser) for (i in 0 until ncat) {
                    val v = d.sers[j].vals[i] ?: continue
                    val frac = Math.abs(v) / span
                    val off = slot * 0.1 + bw * j
                    if (!horizontal) {
                        val hh = (ph * frac).toInt().coerceAtLeast(1)
                        val base = py + ph - (ph * zero).toInt()
                        val top = if (v >= 0) base - hh else base
                        out.add(RBox((px + slot * i + off).toInt(), top, bw.toInt().coerceAtLeast(1), hh, emptyList(), fill = color(j)))
                    } else {
                        val ww = (pw * frac).toInt().coerceAtLeast(1)
                        val base = px + (pw * zero).toInt()
                        val left = if (v >= 0) base else base - ww
                        out.add(RBox(left, (py + slot * i + off).toInt(), ww, bw.toInt().coerceAtLeast(1), emptyList(), fill = color(j)))
                    }
                }
            } else if (d.kind == "stock") {
                val n = nser
                for (i in 0 until ncat) {
                    val cx = (px + slot * i + slot / 2).toInt()
                    fun yv(v: Double) = py + ph - (ph * ((v - lo) / span)).toInt()
                    val hiV = d.sers[if (n >= 4) 1 else 0].vals[i]; val loV = d.sers[if (n >= 4) 2 else 1.coerceAtMost(n - 1)].vals[i]; val clV = d.sers[n - 1].vals[i]; val opV = if (n >= 4) d.sers[0].vals[i] else null
                    if (hiV != null && loV != null) out.add(RBox(cx - 20, yv(hiV), 40, (yv(loV) - yv(hiV)).coerceAtLeast(2), emptyList(), fill = "404040"))
                    if (clV != null) out.add(RBox(cx, yv(clV) - 15, 130, 30, emptyList(), fill = "404040"))
                    if (opV != null) out.add(RBox(cx - 130, yv(opV) - 15, 130, 30, emptyList(), fill = "404040"))
                }
            } else {
                val bMax = if (d.kind == "bubble") d.sers.maxOf { sr -> sr.size.values.maxOrNull() ?: 1.0 }.coerceAtLeast(1e-9) else 1.0
                for (j in 0 until nser) {
                    val pts = ArrayList<Triple<Int, Int, Int>>()
                    for (i in 0 until ncat) {
                        val v = d.sers[j].vals[i] ?: continue
                        val cx = if (isXY) (px + pw * (((d.sers[j].cats[i] ?: "").toDoubleOrNull() ?: (i + 1).toDouble()) - xMin) / (xMax - xMin)).toInt() else (px + slot * i + slot / 2).toInt()
                        pts.add(Triple(cx, py + ph - (ph * ((v - lo) / span)).toInt(), i))
                    }
                    if (isXY) pts.sortBy { it.first }
                    if (d.kind == "area") {
                        val base = py + ph - (ph * ((0.0 - lo) / span)).toInt()
                        for (k in 1 until pts.size) {
                            val (ax, ay) = pts[k - 1]; val (bx, by) = pts[k]
                            val steps = ((bx - ax) / 30).coerceIn(4, 80)
                            for (q in 0 until steps) {
                                val t0 = q.toDouble() / steps; val t1 = (q + 1.0) / steps
                                val sy = ay + (by - ay) * (t0 + t1) / 2
                                val sx = (ax + (bx - ax) * t0).toInt(); val sw = ((bx - ax) * (t1 - t0)).toInt() + 2
                                out.add(RBox(sx, minOf(sy.toInt(), base), sw.coerceAtLeast(2), Math.abs(base - sy).toInt().coerceAtLeast(1), emptyList(), fill = color(j)))
                            }
                        }
                    }
                    val lines = !d.sers[j].noLine && (d.kind == "line" || d.kind == "area" || d.kind == "scatter")
                    if (lines) for (k in 1 until pts.size) seg(out, pts[k - 1].first, pts[k - 1].second, pts[k].first, pts[k].second, if (d.kind == "area") 20 else 30, color(j))
                    if (d.kind != "area") for ((cx, cy, i) in pts) {
                        val rad = if (d.kind == "bubble") (80 + 320 * Math.sqrt(((d.sers[j].size[i] ?: bMax / 4) / bMax).coerceIn(0.0, 1.0))).toInt() else 50
                        out.add(RBox(cx - rad, cy - rad, 2 * rad, 2 * rad, emptyList(), fill = color(j), round = true))
                    }
                }
            }
            if (legend) out.add(RBox(x, y + h - legH, w, legH, listOf(RPara(d.sers.indices.flatMap { j -> listOf(RRun("■ ", color = color(j), sz = 18), RRun(d.sers[j].name.ifEmpty { "Seri ${j + 1}" } + "   ", color = "404040", sz = 16)) }, "center", before = 0, after = 0)), valign = "center"))
            return out
        }
        if (d.kind == "pie" && d.sers.size == 1 && d.sers[0].vals.values.all { it >= 0 } && d.sers[0].vals.values.sum() > 0) {
            val vals = (0 until ncat).map { d.sers[0].vals[it] ?: 0.0 }; val tot = vals.sum()
            val areaH = h - titleH - 100
            val r = (minOf(w * 0.5, areaH.toDouble()) / 2 - 60).toInt().coerceAtLeast(100)
            val cx = x + r + 120; val cy = y + titleH + 50 + areaH / 2
            out.add(RBox(cx - r, cy - r, 2 * r, 2 * r, emptyList(), round = true, pie = vals.mapIndexed { i, v -> (v / tot).toFloat() to PALETTE[i % PALETTE.size] }))
            if (d.doughnut) out.add(RBox(cx - r / 2, cy - r / 2, r, r, emptyList(), fill = "FFFFFF", round = true))
            val lx = cx + r + 250
            val lines = (0 until minOf(ncat, 14)).map { i ->
                RPara(listOf(RRun("■ ", color = PALETTE[i % PALETTE.size], sz = 20), RRun(cats[i].take(24) + "  " + String.format(java.util.Locale.US, "%.1f%%", vals[i] * 100 / tot), color = "404040", sz = 18)), before = 0, after = 60)
            }
            if (lx + 800 < x + w) out.add(RBox(lx, cy - 220 * lines.size, x + w - lx, 440 * lines.size + 100, lines, valign = "center"))
            return out
        }
        // diğer türler: veri tablosu
        val onePie = d.kind == "pie" && d.sers.size == 1
        val total = if (onePie) d.sers[0].vals.values.sum() else 0.0
        val head = listOf("") + d.sers.mapIndexed { j, s -> s.name.ifEmpty { "Seri ${j + 1}" } } + (if (onePie) listOf("%") else emptyList())
        val rows = ArrayList<List<RCell>>()
        fun cell(t: String, bold: Boolean, fill: String?) = RCell(listOf(text(t, 18, "", "000000", bold)), fill = fill, bt = Bd(4, "BFBFBF"), bl = Bd(4, "BFBFBF"), bb = Bd(4, "BFBFBF"), br = Bd(4, "BFBFBF"))
        rows.add(head.map { cell(it, true, "D9E2F3") })
        for (i in 0 until minOf(ncat, 60)) {
            val r = ArrayList<RCell>()
            r.add(cell(cats[i], false, null))
            for (s in d.sers) r.add(cell(s.vals[i]?.let { fmt(it) } ?: "", false, null))
            if (onePie) r.add(cell(d.sers[0].vals[i]?.let { if (total != 0.0) String.format(java.util.Locale.US, "%.1f%%", it * 100 / total) else "" } ?: "", false, null))
            rows.add(r)
        }
        val inner = h - titleH
        out.add(RBox(x, y + titleH, w, inner.coerceAtLeast(300), listOf(RTable(rows, List(head.size) { w / head.size }))))
        return out
    }
}
