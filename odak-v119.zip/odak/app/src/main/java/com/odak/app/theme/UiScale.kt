package com.odak.app.theme

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.odak.app.logic.Pure

/** Arayüz ölçeği: 0 = otomatik (ekran boyutuna göre), aksi halde elle seçilen çarpan. */
object UiScale {
    private const val PREFS = "odak_app"
    private const val KEY = "ui_scale"
    var manual by mutableFloatStateOf(0f)
        private set

    fun init(c: Context) {
        manual = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY, 0f)
    }

    fun set(c: Context, v: Float) {
        manual = v
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY, v).apply()
    }
}

/** Düğme, liste, yazı ve görselleri ekrana göre ölçekler (dp tabanlı → 2K dahil tüm çözünürlükler). */
@Composable
fun ProvideUiScale(content: @Composable () -> Unit) {
    val cfg = LocalConfiguration.current
    val d = LocalDensity.current
    val k = Pure.effectiveScale(UiScale.manual, Pure.autoScale(cfg.screenWidthDp, cfg.screenHeightDp))
    CompositionLocalProvider(LocalDensity provides Density(d.density * k, d.fontScale)) {
        content()
    }
}
