package com.odak.app.logo

/** Uygulama simgesi seçenekleri: her biri bir activity-alias (".alias.A01"…) ve bir mipmap (ic_logo_a01). */
object LogoPure {
    const val COUNT = 19
    const val DEFAULT = 1

    fun clamp(n: Int): Int = if (n in 1..COUNT) n else DEFAULT
    fun code(n: Int): String = "A" + clamp(n).toString().padStart(2, '0')
    fun aliasName(pkg: String, n: Int): String = "$pkg.alias.${code(n)}"
    fun resName(n: Int): String = "ic_logo_" + code(n).lowercase()
    fun all(): List<Int> = (1..COUNT).toList()

    /** Kayıtlı değerden seçili numara; bozuk değer varsayılana döner. */
    fun fromPref(v: Int): Int = clamp(v)

    /** Açılacak ve kapatılacak numaralar (yalnızca seçili açık kalır). */
    fun toDisable(selected: Int): List<Int> = all().filter { it != clamp(selected) }
}
