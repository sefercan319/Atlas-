package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class PureLogicTest {
    private val rules = mapOf(
        "yt/shorts" to listOf("reel_player_page_container", "reel_recycler"),
        "!yt/shorts" to listOf("live_chat_content"),
        "ig/dm" to listOf("direct_thread_header")
    )

    // ---- kural eşleştirme ----
    @Test fun matchesWhenPositiveIdSeen() =
        assertTrue(Pure.matches(setOf("reel_player_page_container"), rules, "yt", "shorts"))

    @Test fun matchesBySubstring() =
        assertTrue(Pure.matches(setOf("x_reel_recycler_y"), rules, "yt", "shorts"))

    @Test fun noMatchWhenNothingSeen() =
        assertFalse(Pure.matches(emptySet(), rules, "yt", "shorts"))

    @Test fun noMatchWhenOtherIdsOnly() =
        assertFalse(Pure.matches(setOf("home_feed", "tab_bar"), rules, "yt", "shorts"))

    @Test fun negativeIdExemptsMatch() =
        assertFalse(Pure.matches(setOf("reel_recycler", "live_chat_content"), rules, "yt", "shorts"))

    @Test fun unknownRuleKeyNeverMatches() =
        assertFalse(Pure.matches(setOf("reel_recycler"), rules, "yt", "search"))

    @Test fun emptyRuleListNeverMatches() =
        assertFalse(Pure.matches(setOf("a"), mapOf("a/b" to emptyList()), "a", "b"))

    @Test fun featuresAreIndependent() {
        val seen = setOf("direct_thread_header")
        assertTrue(Pure.matches(seen, rules, "ig", "dm"))
        assertFalse(Pure.matches(seen, rules, "ig", "reels"))
    }

    // ---- sessiz saat ----
    @Test fun quietSameDayRange() {
        assertTrue(Pure.inQuiet(13 * 60, 12 * 60, 14 * 60))
        assertFalse(Pure.inQuiet(14 * 60, 12 * 60, 14 * 60))
        assertFalse(Pure.inQuiet(11 * 60, 12 * 60, 14 * 60))
    }

    @Test fun quietOvernightRange() {
        assertTrue(Pure.inQuiet(23 * 60, 22 * 60, 7 * 60))
        assertTrue(Pure.inQuiet(3 * 60, 22 * 60, 7 * 60))
        assertFalse(Pure.inQuiet(7 * 60, 22 * 60, 7 * 60))
        assertFalse(Pure.inQuiet(12 * 60, 22 * 60, 7 * 60))
        assertTrue(Pure.inQuiet(22 * 60, 22 * 60, 7 * 60))
    }

    @Test fun quietEqualBoundsIsOff() = assertFalse(Pure.inQuiet(5, 600, 600))

    // ---- süre limiti ----
    @Test fun warnWindow() {
        val min = 60_000L
        assertFalse(Pure.inWarnWindow(7 * min, 10, 80))
        assertTrue(Pure.inWarnWindow(8 * min, 10, 80))
        assertTrue(Pure.inWarnWindow(9 * min, 10, 80))
        assertFalse(Pure.inWarnWindow(10 * min, 10, 80))
        assertFalse(Pure.inWarnWindow(9 * min, 0, 80))
    }

    @Test fun limitReached() {
        assertFalse(Pure.limitReached(9 * 60_000L, 10))
        assertTrue(Pure.limitReached(10 * 60_000L, 10))
        assertFalse(Pure.limitReached(99 * 60_000L, 0))
    }

    // ---- saat çevirme ----
    @Test fun parseTimeValid() {
        assertEquals(9 * 60 + 30, Pure.parseTime("09:30"))
        assertEquals(9 * 60 + 30, Pure.parseTime(" 9.30 "))
        assertEquals(0, Pure.parseTime("0:00"))
        assertEquals(23 * 60 + 59, Pure.parseTime("23:59"))
    }

    @Test fun parseTimeInvalid() {
        assertNull(Pure.parseTime("24:00"))
        assertNull(Pure.parseTime("12:60"))
        assertNull(Pure.parseTime("abc"))
        assertNull(Pure.parseTime(""))
        assertNull(Pure.parseTime("9"))
    }

    @Test fun fmtTimeRoundTrip() {
        assertEquals("09:05", Pure.fmtTime(9 * 60 + 5))
        for (m in 0 until 1440 step 7) assertEquals(m, Pure.parseTime(Pure.fmtTime(m)))
    }

    // ---- emoji etiketi ----
    @Test fun taggedAddsAndReplacesTag() {
        val all = listOf("💼", "🎓")
        assertEquals("💼 Toplantı", Pure.tagged("Toplantı", "💼", all))
        assertEquals("🎓 Toplantı", Pure.tagged("💼 Toplantı", "🎓", all))
        assertEquals("🎓 Toplantı", Pure.tagged("🎓 Toplantı", "🎓", all))
    }

    // ---- alışkanlık serisi ----
    @Test fun streakCounts() {
        val today = LocalDate.of(2026, 10, 25)
        fun d(n: Long) = today.minusDays(n).toString()
        assertEquals(0, Pure.streak(emptySet(), today))
        assertEquals(3, Pure.streak(setOf(d(0), d(1), d(2)), today))
        assertEquals(2, Pure.streak(setOf(d(1), d(2)), today)) // bugün henüz yapılmadı, seri sürüyor
        assertEquals(0, Pure.streak(setOf(d(2), d(3)), today)) // dün atlandı, seri bitti
        assertEquals(1, Pure.streak(setOf(d(0), d(2)), today)) // arada boşluk
    }

    // ---- Snap eşleşmesi: id / desc: / text: ----
    @Test fun snapMatchesDescAndText() {
        val rules = mapOf("a/f" to listOf("desc:reels", "text:yalnızca"), "!a/f" to listOf("composer"))
        assertTrue(Pure.matches(Pure.Snap(emptySet(), setOf("open reels tab")), rules, "a", "f"))
        assertTrue(Pure.matches(Pure.Snap(emptySet(), emptySet(), setOf("yalnızca takip")), rules, "a", "f"))
        assertFalse(Pure.matches(Pure.Snap(setOf("x"), setOf("home")), rules, "a", "f"))
        // istisna kimliği engellemeyi kaldırır
        assertFalse(Pure.matches(Pure.Snap(setOf("composer"), setOf("reels")), rules, "a", "f"))
    }

    @Test fun snapDoesNotMatchEmptyPrefixEntries() {
        val rules = mapOf("a/f" to listOf("desc:", "text:", ""))
        assertFalse(Pure.matches(Pure.Snap(setOf("abc"), setOf("abc"), setOf("abc")), rules, "a", "f"))
    }

    @Test fun idOverloadStillWorks() {
        assertTrue(Pure.matches(setOf("reel_player"), mapOf("a/f" to listOf("reel_player")), "a", "f"))
    }

    // ---- kural türetme ----
    @Test fun deriveKeepsOnlyDistinctiveIds() {
        val pos = mapOf("clips_viewer" to 10, "toolbar" to 10, "rare_id" to 2, "ab" to 10)
        val out = Pure.derive(pos, 10, setOf("toolbar_main", "feed"))
        assertEquals(listOf("clips_viewer"), out) // toolbar dışarıda görüldü, rare_id seyrek, ab çok kısa
    }

    @Test fun deriveEmptyWhenNoScans() {
        assertTrue(Pure.derive(mapOf("x_long" to 1), 0, emptySet()).isEmpty())
    }

    @Test fun deriveLimitsCount() {
        val pos = (1..9).associate { "id_number_$it" to 10 }
        assertEquals(4, Pure.derive(pos, 10, emptySet()).size)
    }

    // ---- grafik yardımcıları ----
    @Test fun topSlicesMergesTail() {
        val v = listOf("a" to 50L, "b" to 40L, "c" to 30L, "d" to 20L, "e" to 10L, "z" to 0L)
        val s = Pure.topSlices(v, 3)
        assertEquals(listOf("a" to 50L, "b" to 40L, "" to 60L), s)
        assertEquals(5, Pure.topSlices(v, 9).size) // sıfırlar atılır
    }

    @Test fun pctChange() {
        assertNull(Pure.pctChange(0, 100))
        assertEquals(50, Pure.pctChange(100, 150))
        assertEquals(-25, Pure.pctChange(200, 150))
    }

    @Test fun deriveIgnoresBlankNegativeIds() {
        assertEquals(listOf("clips_viewer"), Pure.derive(mapOf("clips_viewer" to 5), 5, setOf("")))
    }

    // ---- günlük anahtar temizliği ----
    @Test fun staleDayKeys() {
        val today = LocalDate.of(2026, 10, 25)
        assertTrue(Pure.staleDayKey("fu:2026-09-01:yt:shorts", today))
        assertTrue(Pure.staleDayKey("warn:2026-10-01:instagram", today))
        assertTrue(Pure.staleDayKey("passn:2026-10-01", today))
        assertTrue(Pure.staleDayKey("bc:2026-09-30", today))
        assertFalse(Pure.staleDayKey("bc:2026-10-24", today))
        assertFalse(Pure.staleDayKey("fu:2026-10-20:yt:shorts", today))
        assertFalse(Pure.staleDayKey("limnote:2026-10-25:x", today))
        // ayar anahtarlarına asla dokunulmaz
        assertFalse(Pure.staleDayKey("app:instagram", today))
        assertFalse(Pure.staleDayKey("warn_on", today))
        assertFalse(Pure.staleDayKey("q:days", today))
        assertFalse(Pure.staleDayKey("alim:c:com.x", today))
    }

    @Test fun nameSearch() {
        assertTrue(Pure.nameMatches("YouTube Music", ""))
        assertTrue(Pure.nameMatches("YouTube Music", "  tube "))
        assertTrue(Pure.nameMatches("Clash Royale", "ROYALE"))
        assertFalse(Pure.nameMatches("Spotify", "tik"))
    }

    // ---- v0.39 özellikleri ----
    @Test fun nightAndPerUnlock() {
        val h = LongArray(24); h[0] = 10; h[4] = 5; h[5] = 100
        assertEquals(15L, Pure.nightMs(h))
        assertEquals(0L, Pure.perUnlockMs(1000, 0))
        assertEquals(250L, Pure.perUnlockMs(1000, 4))
    }

    @Test fun barFractionsNormalise() {
        assertEquals(listOf(0.5f, 1f, 0f), Pure.barFractions(listOf(5, 10, 0)))
        assertEquals(listOf(0f, 0f), Pure.barFractions(listOf(0, 0)))
        assertEquals(50, Pure.pct(1, 2)); assertEquals(0, Pure.pct(0, 0))
    }

    private fun k(done: Boolean, due: String?, prio: Int, t: String) = Pure.SortKey(done, due, prio, t)

    @Test fun todoOrderModes() {
        val l = listOf(k(false, "2026-10-30", 0, "b"), k(false, "2026-10-26", 2, "c"), k(true, null, 2, "a"), k(false, null, 1, "A2"))
        assertEquals(listOf(1, 0, 3, 2), Pure.todoOrder(l, 0)) // tarih sonra öncelik, yapılan sonda
        assertEquals(listOf(1, 3, 0, 2), Pure.todoOrder(l, 1)) // öncelik
        assertEquals(listOf(3, 0, 1, 2), Pure.todoOrder(l, 2)) // A-Z, yapılan sonda
        assertEquals(listOf(1, 0, 3, 2), Pure.todoOrder(l, 3)) // tarih
    }

    @Test fun overdueHelpers() {
        val today = LocalDate.of(2026, 10, 25)
        assertTrue(Pure.isOverdue("2026-10-24", false, today))
        assertFalse(Pure.isOverdue("2026-10-24", true, today))
        assertFalse(Pure.isOverdue("2026-10-25", false, today))
        assertFalse(Pure.isOverdue(null, false, today))
        assertEquals("2026-10-25", Pure.moveOverdue("2026-10-01", false, today))
        assertEquals("2026-10-01", Pure.moveOverdue("2026-10-01", true, today))
        assertNull(Pure.moveOverdue(null, false, today))
    }

    @Test fun quickDueParsing() {
        assertEquals("dersi çalış" to 1, Pure.parseQuickDue("yarın dersi çalış"))
        assertEquals("rapor yaz" to 0, Pure.parseQuickDue("rapor yaz Bugün"))
        assertEquals("buy milk" to 1, Pure.parseQuickDue("buy milk tomorrow"))
        assertEquals("yarın" to null, Pure.parseQuickDue("yarın")) // tek kelime başlık kalır
        assertEquals("yarından sonra" to null, Pure.parseQuickDue("yarından sonra"))
        assertEquals("a b" to null, Pure.parseQuickDue("  a b "))
    }

    @Test fun habitRates() {
        val today = LocalDate.of(2026, 10, 25)
        fun d(n: Long) = today.minusDays(n).toString()
        assertEquals(0, Pure.weekRate(emptySet(), today))
        assertEquals(42, Pure.weekRate(setOf(d(0), d(1), d(6)), today)) // 3/7
        assertEquals(14, Pure.weekRate(setOf(d(0), d(7)), today))       // 8 gün önce sayılmaz
        assertEquals(0, Pure.bestStreak(emptySet()))
        assertEquals(3, Pure.bestStreak(setOf(d(10), d(9), d(8), d(5), d(4))))
        assertEquals(1, Pure.bestStreak(setOf(d(3), "bozuk")))
    }

    @Test fun waterFractionClamps() {
        assertEquals(0.5f, Pure.waterFraction(4, 8))
        assertEquals(1f, Pure.waterFraction(12, 8))
        assertEquals(0f, Pure.waterFraction(3, 0))
    }

    @Test fun planOverlapAndFreeSlot() {
        assertTrue(Pure.overlaps(60, 60, 90, 30))
        assertFalse(Pure.overlaps(60, 60, 120, 30)) // bitiş = başlangıç çakışma değil
        assertFalse(Pure.overlaps(-1, 60, 0, 60))
        assertEquals(setOf(0, 1), Pure.conflictIndexes(listOf(60 to 60, 90 to 30, 300 to 30)))
        val busy = listOf(540 to 60, 600 to 60, 780 to 60)
        assertEquals(480, Pure.freeSlot(busy, 480, 1200, 30))
        assertEquals(660, Pure.freeSlot(busy, 540, 1200, 60))
        assertNull(Pure.freeSlot(listOf(0 to 1440), 0, 1440, 30))
        assertEquals(840, Pure.freeSlot(busy, 781, 1200, 30))
    }

    @Test fun totalsAndSummary() {
        assertEquals(90, Pure.totalPlanned(listOf(30, 60, -5, 0)))
        assertEquals("1h 30m", Pure.fmtDur(90)); assertEquals("45m", Pure.fmtDur(45))
        assertEquals("T\n• a\n• b", Pure.summaryText("T", listOf("a", "b")))
    }

    // ---- grafik ekseni ----
    @Test fun niceAxis() {
        assertEquals(5, Pure.niceStepMin(0))
        assertEquals(15, Pure.niceStepMin(50 * 60_000L))      // 50 dk -> 4 çizgi (15'er)
        assertEquals(60, Pure.niceStepMin(3 * 3_600_000L + 1)) // 3sa+ -> 60'ar
        assertEquals(60 * 60_000L, Pure.axisMaxMs(50 * 60_000L).coerceAtMost(60 * 60_000L)) // 60 dk'ya yuvarlanır
        assertEquals(240 * 60_000L, Pure.axisMaxMs(3 * 3_600_000L + 1))
        assertTrue(Pure.axisMaxMs(7 * 60_000L) >= 7 * 60_000L)
    }

    @Test fun slicePercent() {
        assertEquals(25, Pure.slicePct(1, 4)); assertEquals(0, Pure.slicePct(5, 0))
    }

    @Test fun landscapeDetection() {
        assertTrue(Pure.isLandscape(800, 360))
        assertFalse(Pure.isLandscape(360, 800))
        assertFalse(Pure.isLandscape(400, 400))
        assertFalse(Pure.isLandscape(470, 300)) // çok dar yatay: yan şerit açılmaz
        assertTrue(Pure.CONTENT_MAX_DP in 600..900)
    }

    @Test fun windowClasses() {
        assertEquals(Pure.WinClass.COMPACT, Pure.winClass(360))
        assertEquals(Pure.WinClass.MEDIUM, Pure.winClass(600))
        assertEquals(Pure.WinClass.MEDIUM, Pure.winClass(839))
        assertEquals(Pure.WinClass.EXPANDED, Pure.winClass(840))
        assertTrue(Pure.useRail(800, 1280))   // dik tablet/katlanır da şerit alır
        assertTrue(Pure.useRail(740, 360))    // yatay telefon
        assertFalse(Pure.useRail(360, 800))   // dik telefon
        assertEquals(720, Pure.contentMaxDp(800))
        assertEquals(880, Pure.contentMaxDp(1280))
    }

    @Test fun pomodoroLeft() {
        assertEquals(0L, Pure.pomoLeftMs(0, 5000))
        assertEquals(3000L, Pure.pomoLeftMs(8000, 5000))
        assertEquals(0L, Pure.pomoLeftMs(1000, 5000)) // süre dolmuş
    }

    @Test fun autoScaleGrowsWithScreen() {
        assertEquals(0.9f, Pure.autoScale(300, 600), 0f)
        assertEquals(1f, Pure.autoScale(411, 900), 0f)
        assertEquals(1f, Pure.autoScale(900, 411), 0f) // yatay: en küçük kenar
        assertEquals(1.12f, Pure.autoScale(640, 960), 0f)
        assertEquals(1.3f, Pure.autoScale(1000, 1600), 0f)
        assertEquals(1f, Pure.autoScale(0, 0), 0f)
    }

    @Test fun effectiveScaleManualOverridesAndClamps() {
        assertEquals(1.2f, Pure.effectiveScale(0f, 1.2f), 0f)
        assertEquals(1.5f, Pure.effectiveScale(1.5f, 1f), 0f)
        assertEquals(1.6f, Pure.effectiveScale(3f, 1f), 0f)
        assertEquals(0.7f, Pure.effectiveScale(0.1f, 1f), 0f)
    }

    @Test fun fillTplReplacesPlaceholders() {
        assertEquals("Instagram 5 dk", Pure.fillTpl(" {app} {min} dk ", mapOf("app" to "Instagram", "min" to "5")))
        assertEquals("{x} ok", Pure.fillTpl("{x} ok", mapOf("app" to "A")))
        assertEquals(200, Pure.fillTpl("a".repeat(500), emptyMap()).length)
    }

    @Test fun msgOrDefaultFallsBack() {
        assertEquals("def", Pure.msgOrDefault("", "def", emptyMap()))
        assertEquals("def", Pure.msgOrDefault("   ", "def", emptyMap()))
        assertEquals("Merhaba X", Pure.msgOrDefault("Merhaba {t}", "def", mapOf("t" to "X")))
    }
}
