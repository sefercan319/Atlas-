package com.odak.app

import com.odak.app.docs.DocKind
import com.odak.app.docs.DocParse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Belge okuyucu: gerçek zip/XML üretilerek sınanır. */
class DocParseTest {
    private fun zip(vararg f: Pair<String, String>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> for ((n, c) in f) { z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray()); z.closeEntry() } }
        return bo.toByteArray()
    }
    private val W = "<?xml version=\"1.0\"?><w:document><w:body>"
    private fun docx(body: String) = zip("word/document.xml" to "$W$body</w:body></w:document>", "[Content_Types].xml" to "<x/>")

    // ---- detect ----
    @Test fun detectByExtension() {
        assertEquals(DocKind.DOCX, DocParse.detect("a.DOCX", ByteArray(0)))
        assertEquals(DocKind.PPTX, DocParse.detect("a.ppsx", ByteArray(0)))
        assertEquals(DocKind.XLSX, DocParse.detect("a.xlsm", ByteArray(0)))
        assertEquals(DocKind.ODT, DocParse.detect("a.odt", ByteArray(0)))
        assertEquals(DocKind.LEGACY, DocParse.detect("a.one", ByteArray(0)))
        assertEquals(DocKind.LEGACY, DocParse.detect("a.pub", ByteArray(0)))
        assertEquals(DocKind.GOOGLE, DocParse.detect("a.gdoc", ByteArray(0)))
        assertEquals(DocKind.LEGACY, DocParse.detect("a.wps", ByteArray(0)))
        assertEquals(DocKind.LEGACY, DocParse.detect("a.et", ByteArray(0)))
        assertEquals(DocKind.LEGACY, DocParse.detect("a.dps", ByteArray(0)))
    }
    @Test fun detectPdfByMagicEvenWithWrongExtension() {
        assertEquals(DocKind.PDF, DocParse.detect("x.bin", "%PDF-1.7".toByteArray()))
    }
    @Test fun detectRtfByMagic() {
        assertEquals(DocKind.RTF, DocParse.detect("x.doc", "{\\rtf1\\ansi".toByteArray()))
    }
    @Test fun detectZipWithLegacyExtensionIsSniffedLater() {
        assertEquals(DocKind.UNKNOWN, DocParse.detect("x.wps", byteArrayOf(0x50, 0x4B, 3, 4)))
    }
    @Test fun extOf() {
        assertEquals("docx", DocParse.extOf("My.Report.DOCX"))
        assertEquals("", DocParse.extOf("noext"))
    }
    @Test fun allListedFormatsAreKnown() {
        val names = "pdf rtf wps dps et odt odp ods odg odf odb docx pptx xlsx doc ppt xls dotx potx ppsx pptm docm pub vsdx one gdoc gsheet gslides gform".split(" ")
        for (n in names) assertTrue(n, DocParse.detect("f.$n", ByteArray(0)) != DocKind.UNKNOWN)
    }

    // ---- DOCX ----
    @Test fun docxParagraphs() {
        val d = DocParse.parse("a.docx", docx("<w:p><w:r><w:t>Merhaba</w:t></w:r><w:r><w:t> dünya</w:t></w:r></w:p><w:p><w:r><w:t>İkinci</w:t></w:r></w:p>"))
        assertEquals(DocKind.DOCX, d.kind)
        assertEquals(listOf("Merhaba dünya", "İkinci"), d.pages[0].paragraphs)
    }
    @Test fun docxSkipsEmptyParagraphs() {
        val d = DocParse.parse("a.docx", docx("<w:p></w:p><w:p><w:r><w:t> </w:t></w:r></w:p><w:p><w:r><w:t>x</w:t></w:r></w:p>"))
        assertEquals(listOf("x"), d.pages[0].paragraphs)
    }
    @Test fun docxTabAndBreak() {
        val d = DocParse.parse("a.docx", docx("<w:p><w:r><w:t>a</w:t><w:tab/><w:t>b</w:t><w:br/><w:t>c</w:t></w:r></w:p>"))
        assertEquals("a\tb\nc", d.pages[0].paragraphs[0])
    }
    @Test fun docxTableRowsJoined() {
        val d = DocParse.parse("a.docx", docx("<w:tbl><w:tr><w:tc><w:p><w:r><w:t>A</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>B</w:t></w:r></w:p></w:tc></w:tr></w:tbl><w:p><w:r><w:t>after</w:t></w:r></w:p>"))
        assertEquals(listOf("A │ B", "after"), d.pages[0].paragraphs)
    }
    @Test fun docxTemplateExtensionWorks() {
        assertEquals(DocKind.DOCX, DocParse.parse("t.dotx", docx("<w:p><w:r><w:t>x</w:t></w:r></w:p>")).kind)
    }
    @Test fun docxMacroExtensionWorks() {
        assertEquals(listOf("m"), DocParse.parse("t.docm", docx("<w:p><w:r><w:t>m</w:t></w:r></w:p>")).pages[0].paragraphs)
    }
    @Test fun wpsThatIsActuallyDocxIsSniffed() {
        val d = DocParse.parse("t.wps", docx("<w:p><w:r><w:t>wps</w:t></w:r></w:p>"))
        assertEquals(DocKind.DOCX, d.kind)
        assertFalse(d.approx)
        assertEquals(listOf("wps"), d.pages[0].paragraphs)
    }

    // ---- PPTX ----
    private fun slide(vararg t: String) = "<p:sld>" + t.joinToString("") { "<a:p><a:r><a:t>$it</a:t></a:r></a:p>" } + "</p:sld>"
    @Test fun pptxSlidesInNumericOrder() {
        val b = zip(
            "ppt/slides/slide10.xml" to slide("on"),
            "ppt/slides/slide2.xml" to slide("iki"),
            "ppt/slides/slide1.xml" to slide("bir", "alt"),
            "ppt/presentation.xml" to "<p/>"
        )
        val d = DocParse.parse("a.pptx", b)
        assertEquals(3, d.pages.size)
        assertEquals(listOf("bir", "alt"), d.pages[0].paragraphs)
        assertEquals(listOf("iki"), d.pages[1].paragraphs)
        assertEquals(listOf("on"), d.pages[2].paragraphs)
    }
    @Test fun pptxNotesAreAppended() {
        val b = zip("ppt/slides/slide1.xml" to slide("s"), "ppt/notesSlides/notesSlide1.xml" to slide("not"), "ppt/presentation.xml" to "<p/>")
        assertEquals(listOf("s", "📝 not"), DocParse.parse("a.pptx", b).pages[0].paragraphs)
    }
    @Test fun ppsxAndPotxAreSlides() {
        val b = zip("ppt/slides/slide1.xml" to slide("x"), "ppt/presentation.xml" to "<p/>")
        assertEquals(DocKind.PPTX, DocParse.parse("a.ppsx", b).kind)
        assertEquals(DocKind.PPTX, DocParse.parse("a.potx", b).kind)
        assertEquals(DocKind.PPTX, DocParse.parse("a.pptm", b).kind)
    }

    // ---- XLSX ----
    private fun xlsx(sheetXml: String, shared: String = "<sst><si><t>Ad</t></si><si><t>Yaş</t></si><si><r><t>Ali</t></r><r><t> Veli</t></r></si></sst>") = zip(
        "xl/workbook.xml" to "<workbook><sheets><sheet name=\"Liste\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>",
        "xl/_rels/workbook.xml.rels" to "<Relationships><Relationship Id=\"rId1\" Target=\"worksheets/sheet1.xml\"/></Relationships>",
        "xl/sharedStrings.xml" to shared,
        "xl/worksheets/sheet1.xml" to sheetXml
    )
    @Test fun xlsxCellsAndSharedStrings() {
        val d = DocParse.parse("a.xlsx", xlsx("<worksheet><sheetData><row r=\"1\"><c r=\"A1\" t=\"s\"><v>0</v></c><c r=\"B1\" t=\"s\"><v>1</v></c></row><row r=\"2\"><c r=\"A2\" t=\"s\"><v>2</v></c><c r=\"B2\"><v>30</v></c></row></sheetData></worksheet>"))
        assertEquals("Liste", d.pages[0].title)
        assertEquals(listOf(listOf("Ad", "Yaş"), listOf("Ali Veli", "30")), d.pages[0].table)
    }
    @Test fun xlsxGapsAreFilled() {
        val d = DocParse.parse("a.xlsx", xlsx("<worksheet><sheetData><row r=\"1\"><c r=\"C1\"><v>5</v></c></row></sheetData></worksheet>"))
        assertEquals(listOf(listOf("", "", "5")), d.pages[0].table)
    }
    @Test fun xlsxBooleanAndInlineString() {
        val d = DocParse.parse("a.xlsx", xlsx("<worksheet><sheetData><row r=\"1\"><c r=\"A1\" t=\"b\"><v>1</v></c><c r=\"B1\" t=\"inlineStr\"><is><t>satır içi</t></is></c></row></sheetData></worksheet>"))
        assertEquals(listOf("TRUE", "satır içi"), d.pages[0].table!![0])
    }
    @Test fun xlsxSkipsEmptyRowsKeepsOrder() {
        val d = DocParse.parse("a.xlsx", xlsx("<worksheet><sheetData><row r=\"5\"><c r=\"A5\"><v>9</v></c></row><row r=\"2\"><c r=\"A2\"><v>1</v></c></row></sheetData></worksheet>"))
        assertEquals(listOf(listOf("1"), listOf("9")), d.pages[0].table)
    }
    @Test fun colIndexLetters() {
        assertEquals(0, DocParse.colIndex("A1"))
        assertEquals(25, DocParse.colIndex("Z9"))
        assertEquals(26, DocParse.colIndex("AA1"))
        assertEquals(27, DocParse.colIndex("AB10"))
    }

    // ---- ODF ----
    private fun odf(mime: String, content: String) = zip("mimetype" to mime, "content.xml" to content)
    @Test fun odtParagraphsAndHeadings() {
        val b = odf("application/vnd.oasis.opendocument.text", "<office:document-content><office:body><office:text><text:h>Başlık</text:h><text:p>Gövde<text:s text:c=\"2\"/>x<text:tab/>y</text:p></office:text></office:body></office:document-content>")
        val d = DocParse.parse("a.odt", b)
        assertEquals(DocKind.ODT, d.kind)
        assertEquals(listOf("Başlık", "Gövde  x\ty"), d.pages[0].paragraphs)
    }
    @Test fun odpSlides() {
        val b = odf("application/vnd.oasis.opendocument.presentation", "<c><draw:page draw:name=\"p1\"><text:p>bir</text:p></draw:page><draw:page draw:name=\"p2\"><text:p>iki</text:p></draw:page></c>")
        val d = DocParse.parse("a.odp", b)
        assertEquals(2, d.pages.size)
        assertEquals("p1", d.pages[0].title)
        assertEquals(listOf("iki"), d.pages[1].paragraphs)
    }
    @Test fun odsTableWithRepeatedCells() {
        val b = odf("application/vnd.oasis.opendocument.spreadsheet", "<c><table:table table:name=\"S1\"><table:table-row><table:table-cell table:number-columns-repeated=\"2\"/><table:table-cell><text:p>v</text:p></table:table-cell></table:table-row><table:table-row><table:table-cell><text:p>a</text:p></table:table-cell></table:table-row></table:table></c>")
        val d = DocParse.parse("a.ods", b)
        assertEquals("S1", d.pages[0].title)
        assertEquals(listOf("", "", "v"), d.pages[0].table!![0])
        assertEquals(listOf("a", "", ""), d.pages[0].table!![1])
    }
    @Test fun odsEmptyRowsSkipped() {
        val b = odf("application/vnd.oasis.opendocument.spreadsheet", "<c><table:table table:name=\"S\"><table:table-row table:number-rows-repeated=\"1000000\"><table:table-cell/></table:table-row><table:table-row><table:table-cell><text:p>x</text:p></table:table-cell></table:table-row></table:table></c>")
        assertEquals(1, DocParse.parse("a.ods", b).pages[0].table!!.size)
    }
    @Test fun odtAnnotationsAreIgnored() {
        val b = odf("application/vnd.oasis.opendocument.text", "<c><text:p>görünür<office:annotation><text:p>gizli not</text:p></office:annotation> devam</text:p></c>")
        assertEquals(listOf("görünür devam"), DocParse.parse("a.odt", b).pages[0].paragraphs)
    }
    @Test fun odgDrawingText() {
        val b = odf("application/vnd.oasis.opendocument.graphics", "<c><draw:page draw:name=\"g\"><draw:frame><draw:text-box><text:p>şekil</text:p></draw:text-box></draw:frame></draw:page></c>")
        assertEquals(listOf("şekil"), DocParse.parse("a.odg", b).pages[0].paragraphs)
    }
    @Test fun odfFormulaAnnotation() {
        val b = odf("application/vnd.oasis.opendocument.formula", "<math:math><math:semantics><math:mrow/><math:annotation encoding=\"StarMath 5.0\">x^2 + y^2 = z^2</math:annotation></math:semantics></math:math>")
        assertEquals(listOf("x^2 + y^2 = z^2"), DocParse.parse("a.odf", b).pages[0].paragraphs)
    }
    @Test fun odbIsDatabaseKind() {
        assertEquals(DocKind.ODB, DocParse.parse("a.odb", odf("application/vnd.oasis.opendocument.base", "<c/>")).kind)
    }
    @Test fun sniffZipRecognizesFamilies() {
        assertEquals(DocKind.DOCX, DocParse.sniffZip(mapOf("word/document.xml" to ByteArray(0))))
        assertEquals(DocKind.XLSX, DocParse.sniffZip(mapOf("xl/workbook.xml" to ByteArray(0))))
        assertEquals(DocKind.VSDX, DocParse.sniffZip(mapOf("visio/pages/page1.xml" to ByteArray(0))))
        assertEquals(DocKind.UNKNOWN, DocParse.sniffZip(emptyMap()))
    }

    // ---- VSDX ----
    @Test fun vsdxShapeText() {
        val b = zip("visio/pages/page1.xml" to "<PageContents><Shapes><Shape><Text>Başla</Text></Shape><Shape><Text>Bitir</Text></Shape></Shapes></PageContents>")
        val d = DocParse.parse("a.vsdx", b)
        assertEquals(listOf("Başla", "Bitir"), d.pages[0].paragraphs)
    }

    // ---- RTF ----
    @Test fun rtfBasicText() {
        val d = DocParse.parse("a.rtf", "{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0 Arial;}}\\pard Merhaba\\par D\\'fcnya\\par}".toByteArray())
        assertEquals(listOf("Merhaba", "Dünya"), d.pages[0].paragraphs)
    }
    @Test fun rtfHexEscapesCp1252() {
        assertEquals(listOf("café"), DocParse.rtfParas("{\\rtf1 caf\\'e9}"))
    }
    @Test fun rtfUnicodeEscape() {
        assertEquals(listOf("ş"), DocParse.rtfParas("{\\rtf1\\uc1\\u351?}"))
    }
    @Test fun rtfNegativeUnicode() {
        assertEquals(listOf("語"), DocParse.rtfParas("{\\rtf1\\u-30050?}"))
    }
    @Test fun rtfSkipsDestinationsAndFieldInstructions() {
        assertEquals(listOf("görünür"), DocParse.rtfParas("{\\rtf1{\\*\\generator Word;}{\\colortbl;\\red0;}görünür}"))
    }
    @Test fun rtfEscapedBraces() {
        assertEquals(listOf("{a}\\b"), DocParse.rtfParas("{\\rtf1 \\{a\\}\\\\b}"))
    }
    @Test fun rtfTabAndQuotes() {
        assertEquals(listOf("a\tb “q”"), DocParse.rtfParas("{\\rtf1 a\\tab b \\ldblquote q\\rdblquote }"))
    }

    // ---- Metin ----
    @Test fun textUtf8() {
        assertEquals(listOf("a", "ğ"), DocParse.parse("a.txt", "a\r\nğ".toByteArray()).pages[0].paragraphs)
    }
    @Test fun textUtf16Bom() {
        val b = byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + "hi".toByteArray(Charsets.UTF_16LE)
        assertEquals("hi", DocParse.decodeText(b))
    }
    @Test fun textWindows1254Fallback() {
        val b = byteArrayOf(0xDD.toByte(), 0xFE.toByte()) // İş
        assertEquals("İş", DocParse.decodeText(b))
    }
    @Test fun textBomStripped() {
        assertEquals("x", DocParse.decodeText(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte(), 'x'.code.toByte())))
    }

    // ---- Google ----
    @Test fun gdocLinkExtracted() {
        val d = DocParse.parse("a.gdoc", "{\"url\": \"https:\\/\\/docs.google.com\\/document\\/d\\/abc\\/edit\", \"doc_id\": \"abc\"}".toByteArray())
        assertEquals("https://docs.google.com/document/d/abc/edit", d.link)
    }
    @Test fun gdocRejectsForeignHosts() {
        assertNull(DocParse.parse("a.gdoc", "{\"url\": \"https://evil.com/x\"}".toByteArray()).link)
        assertNull(DocParse.parse("a.gdoc", "{\"url\": \"http://docs.google.com/x\"}".toByteArray()).link)
        assertNull(DocParse.parse("a.gdoc", "{\"url\": \"https://docs.google.com.evil.com/x\"}".toByteArray()).link)
    }
    @Test fun safeGoogleUrlCases() {
        assertTrue(DocParse.safeGoogleUrl("https://docs.google.com/a"))
        assertTrue(DocParse.safeGoogleUrl("https://google.com"))
        assertFalse(DocParse.safeGoogleUrl("https://notgoogle.com/a"))
        assertFalse(DocParse.safeGoogleUrl("https://google.com@evil.com/a"))
        assertFalse(DocParse.safeGoogleUrl("ftp://docs.google.com"))
    }

    // ---- Eski ikili ----
    @Test fun roughTextFindsAsciiAndUtf16Runs() {
        val b = ByteArray(40) + "Bu bir deneme cümlesidir".toByteArray(Charsets.ISO_8859_1) + ByteArray(10) + "Unicode satir metni".toByteArray(Charsets.UTF_16LE) + ByteArray(10)
        val r = DocParse.roughText(b)
        assertTrue(r.any { it.contains("deneme") })
        assertTrue(r.any { it.contains("Unicode satir metni") })
    }
    @Test fun roughTextDropsKnownJunkAndNoise() {
        val b = "Times New Roman".toByteArray() + ByteArray(5) + "Root Entry".toByteArray() + ByteArray(5) + "!!!!!!!!!!!".toByteArray()
        assertTrue(DocParse.roughText(b).isEmpty())
    }
    @Test fun legacyParseIsApproximate() {
        val b = byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte()) + ByteArray(30) + "Toplanti notlari burada".toByteArray() + ByteArray(8)
        val d = DocParse.parse("a.doc", b)
        assertTrue(d.approx)
        assertTrue(d.pages[0].paragraphs.any { it.contains("Toplanti") })
    }
    @Test fun opaqueFormatsHaveNoPages() {
        assertTrue(DocParse.parse("a.one", ByteArray(100)).pages.isEmpty())
        assertTrue(DocParse.parse("a.pub", ByteArray(100)).pages.isEmpty())
    }

    // ---- Dayanıklılık ----
    @Test fun corruptZipDoesNotThrow() {
        val d = DocParse.parse("a.docx", byteArrayOf(0x50, 0x4B, 3, 4, 1, 2, 3, 4, 5))
        assertTrue(d.pages.isEmpty() || d.pages.all { it.paragraphs.isEmpty() })
    }
    @Test fun corruptXmlDoesNotThrow() {
        val d = DocParse.parse("a.docx", zip("word/document.xml" to "<w:p><w:t>kırık"))
        assertEquals(DocKind.DOCX, d.kind)
    }
    @Test fun emptyInputDoesNotThrow() {
        for (n in listOf("a.docx", "a.xlsx", "a.odt", "a.rtf", "a.txt", "a.gdoc", "a.doc", "a.pptx")) DocParse.parse(n, ByteArray(0))
    }
    @Test fun doctypeIsNotExpanded() {
        val xml = "<?xml version=\"1.0\"?><!DOCTYPE x [<!ENTITY e SYSTEM \"file:///etc/passwd\">]><w:document><w:p><w:r><w:t>&e;</w:t></w:r></w:p></w:document>"
        val d = DocParse.parse("a.docx", zip("word/document.xml" to xml))
        assertFalse(d.pages.flatMap { it.paragraphs }.any { it.contains("root:") })
    }
    @Test fun oversizedInputIsRejected() {
        val d = DocParse.parse("a.txt", ByteArray(1001), 1000)
        assertTrue(d.pages.isEmpty())
    }

    // ---- Düzleştirme / son açılanlar ----
    private fun sampleDoc() = DocParse.parse("a.pptx", zip(
        "ppt/slides/slide1.xml" to slide("elma", "armut"), "ppt/slides/slide2.xml" to slide("kiraz"), "ppt/presentation.xml" to "<p/>"))
    @Test fun flattenAddsHeadersForMultiPage() {
        val l = DocParse.flatten(sampleDoc(), "") { p, i -> "S${p.title}" }
        assertEquals(listOf(0, 1, 1, 0, 1), l.map { it.kind })
        assertEquals("S1", l[0].text)
    }
    @Test fun flattenFiltersByQueryAndDropsEmptyPages() {
        val l = DocParse.flatten(sampleDoc(), "KIRAZ") { p, _ -> "S${p.title}" }
        assertEquals(listOf("S2", "kiraz"), l.map { it.text })
    }
    @Test fun flattenQueryNoMatchIsEmpty() {
        assertTrue(DocParse.flatten(sampleDoc(), "yok", { _, _ -> "h" }).isEmpty())
    }
    @Test fun flattenSinglePageHasNoHeader() {
        val d = DocParse.parse("a.docx", docx("<w:p><w:r><w:t>x</w:t></w:r></w:p>"))
        assertEquals(listOf(1), DocParse.flatten(d, "", { _, _ -> "H" }).map { it.kind })
    }
    @Test fun flattenTableRowsKind2() {
        val d = DocParse.parse("a.xlsx", xlsx("<worksheet><sheetData><row r=\"1\"><c r=\"A1\"><v>7</v></c></row></sheetData></worksheet>"))
        val l = DocParse.flatten(d, "", { p, _ -> p.title })
        assertEquals(listOf(0, 2), l.map { it.kind })
        assertEquals(listOf("7"), l[1].cells)
    }
    @Test fun recentsNewestFirstNoDuplicates() {
        val r = DocParse.addRecent(listOf("a" to "A", "b" to "B"), "b" to "B2")
        assertEquals(listOf("b" to "B2", "a" to "A"), r)
    }
    @Test fun recentsCapped() {
        var r = emptyList<Pair<String, String>>()
        for (i in 1..20) r = DocParse.addRecent(r, "u$i" to "n$i")
        assertEquals(8, r.size)
        assertEquals("u20", r[0].first)
    }
}
