package com.odak.app

import com.odak.app.theme.ColorMath
import com.odak.app.theme.Contrast
import com.odak.app.theme.EmojiSplit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.54: renk özelleştirme (HSV/hex/palet, arka plan + yazı rengi) ve koyu/açık modda emoji koruma. */
class ColorCustomTest {
    @Test fun hsvRoundTrip() {
        assertEquals(0xFFFF0000.toInt(), ColorMath.hsv(0f, 1f, 1f)); assertEquals(0xFF00FF00.toInt(), ColorMath.hsv(120f, 1f, 1f)); assertEquals(0xFF0000FF.toInt(), ColorMath.hsv(240f, 1f, 1f))
        assertEquals(0xFFFFFFFF.toInt(), ColorMath.hsv(0f, 0f, 1f)); assertEquals(0xFF000000.toInt(), ColorMath.hsv(200f, 0.5f, 0f))
        for (c in ColorMath.PALETTE) { val (h, s, v) = ColorMath.toHsv(c); val back = ColorMath.hsv(h, s, v)
            for (sh in listOf(16, 8, 0)) assertTrue("${ColorMath.toHex(c)}", Math.abs(((c shr sh) and 255) - ((back shr sh) and 255)) <= 1) }
        val (h, s, v) = ColorMath.toHsv(0xFF00E5FF.toInt()); assertTrue(h in 184f..188f && s > 0.99f && v > 0.99f)
    }
    @Test fun hexParse() {
        assertEquals(0xFF00E5FF.toInt(), ColorMath.parseHex("#00e5ff")); assertEquals(0xFF00E5FF.toInt(), ColorMath.parseHex("00E5FF")); assertEquals(0xFFAABBCC.toInt(), ColorMath.parseHex("#abc"))
        assertEquals(null, ColorMath.parseHex("#12")); assertEquals(null, ColorMath.parseHex("#GGGGGG")); assertEquals(null, ColorMath.parseHex(""))
        assertEquals("#00E5FF", ColorMath.toHex(0xFF00E5FF.toInt())); assertEquals("#000000", ColorMath.toHex(0xFF000000.toInt()))
    }
    @Test fun paletteHas32Distinct() { assertEquals(32, ColorMath.PALETTE.size); assertEquals(32, ColorMath.PALETTE.toSet().size) }
    @Test fun userBackgroundGivesReadableSurfaceAndText() {
        for (bg in listOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFEB3B.toInt(), 0xFF1B5E20.toInt(), 0xFF7C4DFF.toInt(), 0xFF9E9E9E.toInt())) {
            val surf = ColorMath.surfaceFor(bg)
            for (want in listOf(0xFF777777.toInt(), 0xFF111111.toInt(), 0xFFFFFFFF.toInt(), bg)) {
                val t = ColorMath.safeText(want, bg, surf)
                // sonuç ya istenen renk (iki zeminde de okunuyorsa) ya da siyah/beyaz; zeminde en az 4.5
                assertTrue("bg ${ColorMath.toHex(bg)} yazı ${ColorMath.toHex(want)}", Contrast.ratio(t, bg) >= 4.5)
                assertTrue(t == want || t == 0xFF000000.toInt() || t == 0xFFFFFFFF.toInt())
                assertTrue(Contrast.ratio(t, surf) >= 3.0)   // orta tonlu zeminde yüzeyde biraz düşebilir
            }
        }
        // açık zeminde yüzey daha açık, koyu zeminde biraz daha aydınlık
        assertTrue(Contrast.luminance(ColorMath.surfaceFor(0xFFFFEB3B.toInt())) > Contrast.luminance(0xFFFFEB3B.toInt()))
        assertTrue(Contrast.luminance(ColorMath.surfaceFor(0xFF000000.toInt())) > 0.0)
    }

    @Test fun emojiSplit() {
        assertTrue(!EmojiSplit.hasEmoji("Merhaba ş ğ ı")); assertTrue(!EmojiSplit.hasEmoji("☑ ⚙ ☰ ⏱ ✔"))   // metin görünümlü simgeler çevrilmez
        assertTrue(EmojiSplit.hasEmoji("📅 Plan")); assertTrue(EmojiSplit.hasEmoji("⛔ Engel")); assertTrue(EmojiSplit.hasEmoji("⚠️ uyarı"))
        val s = EmojiSplit.split("📝 Notlar 🗑")
        assertEquals(listOf("📝", " Notlar ", "🗑"), s.map { it.text }); assertEquals(listOf(true, false, true), s.map { it.emoji })
        // bileşik emoji tek parça (ZWJ, ten tonu, FE0F)
        assertEquals(1, EmojiSplit.split("👨‍💻").size); assertEquals(1, EmojiSplit.split("👍🏽").size)
        assertEquals("a📅b", EmojiSplit.split("a📅b").joinToString("") { it.text })
        assertEquals(emptyList<Any>(), EmojiSplit.split("").toList())
    }

    @Test fun wiring() {
        fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
        // tüm arayüz dosyaları sarmalı Text'i kullanır, material3 Text'i yalnız sarmalayıcıda kalır
        val all = File(TestFiles.code, "com/odak/app").walkTopDown().filter { it.extension == "kt" }.toList()
        val raw = all.filter { it.readText().contains("import androidx.compose.material3.Text\n") }
        assertTrue(raw.map { it.name }.toString(), raw.isEmpty())
        assertTrue(src("theme/EmojiText.kt").contains("modeInvert(true)") && src("theme/EmojiText.kt").contains("LocalInverted"))
        for (f in listOf("MainActivity.kt", "notes/NotesActivity.kt", "docs/DocActivity.kt", "block/BlockActivity.kt")) assertTrue(f, src(f).contains("LocalInverted provides"))
        assertTrue(src("theme/DesignStyle.kt").contains("ColorPrefs.backgroundOf") && src("theme/DesignStyle.kt").contains("ColorMath.safeText"))
        assertTrue(src("theme/ColorPrefs.kt").contains("setBackground") && src("theme/ColorPrefs.kt").contains("setText") && src("theme/ColorPrefs.kt").contains("fun clear("))
        assertTrue(src("theme/ThemedComponents.kt").contains("userBg") && src("theme/DarkMode.kt").contains("backgroundOf"))
        val st = src("settings/SettingsScreen.kt")
        assertTrue(st.contains("colors_background") && st.contains("colors_text") && st.contains("SwatchPalette"))
        assertTrue(src("settings/ColorPicker.kt").contains("Slider") && src("settings/ColorPicker.kt").contains("parseHex"))
    }
    @Test fun stringsInAllLanguages() {
        val res = File(TestFiles.main, "res")
        for (d in listOf("values", "values-tr", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az")) {
            val t = File(res, "$d/strings.xml").readText()
            for (k in listOf("colors_background", "colors_text", "colors_custom", "colors_auto_note", "colors_surface", "colors_button", "colors_button_text")) assertTrue("$d $k", Regex("<string name=\"$k\">[^<]+</string>").containsMatchIn(t))
        }
    }
}
