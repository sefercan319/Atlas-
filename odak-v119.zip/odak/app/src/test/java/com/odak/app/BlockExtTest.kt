package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.6: uygulama içi özellik engelleme — "sel:" (seçili sekme) kuralı, öğretme ve genişleyen katalog. */
class BlockExtTest {
    private val rules = TestFiles.parseRules(File(TestFiles.main, "assets/block_rules.json"))
    private val catalog = TestFiles.catalog()
    private fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    private fun snap(sel: Set<String> = emptySet(), ids: Set<String> = emptySet(), descs: Set<String> = emptySet()) = Pure.Snap(ids, descs, emptySet(), sel)

    @Test fun selMatchesSelectedLabelOnly() {
        val r = mapOf("a/f" to listOf("sel:reels"))
        assertTrue(Pure.matches(snap(sel = setOf("reels")), r, "a", "f"))
        assertTrue(Pure.matches(snap(sel = setOf("reels, tab 3 of 5")), r, "a", "f"))
        assertFalse(Pure.matches(snap(descs = setOf("reels")), r, "a", "f"))          // seçili olmayan sekme eşleşmez
        assertFalse(Pure.matches(snap(sel = setOf("home")), r, "a", "f"))
    }
    @Test fun selIsCaseInsensitiveAndEmptySelNeverMatches() {
        assertTrue(Pure.matches(snap(sel = setOf("shorts")), mapOf("a/f" to listOf("sel:SHORTS")), "a", "f"))
        assertFalse(Pure.matches(snap(sel = setOf("x")), mapOf("a/f" to listOf("sel:")), "a", "f"))
    }
    @Test fun selWorksWithExemptionAndMixedRules() {
        val r = mapOf("a/f" to listOf("sel:reels", "clips_viewer"), "!a/f" to listOf("composer"))
        assertTrue(Pure.matches(snap(sel = setOf("reels")), r, "a", "f"))
        assertTrue(Pure.matches(snap(ids = setOf("clips_viewer_pager")), r, "a", "f"))
        assertFalse(Pure.matches(snap(sel = setOf("reels"), ids = setOf("composer")), r, "a", "f"))
    }
    @Test fun oldSnapConstructorsStillWork() { assertTrue(Pure.matches(Pure.Snap(setOf("abc_def")), mapOf("a/f" to listOf("abc_")), "a", "f")); assertTrue(Pure.matches(setOf("abc_def"), mapOf("a/f" to listOf("abc_")), "a", "f")) }

    @Test fun deriveSelPicksFrequentLabelsNotSeenOutside() {
        val pos = mapOf("reels" to 9, "home" to 9, "kısa" to 2)
        assertEquals(listOf("sel:reels"), Pure.deriveSel(pos, 10, setOf("home")))
    }
    @Test fun deriveSelRespectsLimitsAndEmptyInput() {
        assertTrue(Pure.deriveSel(mapOf("reels" to 9), 0, emptySet()).isEmpty())
        assertTrue(Pure.deriveSel(mapOf("ab" to 9), 10, emptySet()).isEmpty())                                 // çok kısa
        assertTrue(Pure.deriveSel(mapOf("x".repeat(40) to 9), 10, emptySet()).isEmpty())                       // çok uzun
        assertEquals(2, Pure.deriveSel(mapOf("aaa" to 9, "bbb" to 8, "ccc" to 7), 10, emptySet()).size)
        assertTrue(Pure.deriveSel(mapOf("reels" to 9), 10, setOf("reels tab")).isEmpty())                      // dışarıda alt dizgi olarak görüldü
    }
    @Test fun deriveSelRuleIsUsableByMatcher() {
        val rule = Pure.deriveSel(mapOf("marketplace" to 8), 10, emptySet())
        assertTrue(Pure.matches(snap(sel = setOf("marketplace")), mapOf("a/f" to rule), "a", "f"))
    }

    @Test fun catalogGrew() { assertTrue("Katalog ${catalog.size}", catalog.size >= 290) }
    @Test fun newFeaturesRegistered() {
        assertTrue(catalog.first { it.id == "linkedin" }.features.containsAll(listOf("video", "jobs")))
        assertTrue(catalog.first { it.id == "netflix" }.features.contains("games"))
    }
    @Test fun newAppsPresentWithValidPackages() {
        for (id in listOf("bilibili", "kick", "doordash", "bip", "samsunginternet", "duckduckgo", "marvelsnap", "zzz", "okcupid", "plex", "pocketfm")) assertTrue(id, catalog.any { it.id == id })
    }
    @Test fun noTwoAppsShareAName() { val dup = catalog.groupBy { it.name.lowercase() }.filter { it.value.size > 1 }.keys; assertTrue("Tekrarlı ad: $dup", dup.isEmpty()) }

    @Test fun selRulesAreWellFormed() {
        val all = rules.filterKeys { !it.startsWith("_") }.flatMap { (k, v) -> v.filter { it.startsWith("sel:") }.map { k to it } }
        assertTrue("sel: kural sayısı ${all.size}", all.size >= 30)
        val bad = all.filter { (_, e) -> e != e.lowercase() || e.length < 7 || e.trim() != e }
        assertTrue("Biçimsiz sel: kuralları: $bad", bad.isEmpty())
    }
    @Test fun manyFeaturesHaveASelRule() {
        val with = rules.filterKeys { !it.startsWith("_") && !it.startsWith("!") }.filter { (_, v) -> v.any { it.startsWith("sel:") } }
        assertTrue("sel: kuralı olan özellik ${with.size}", with.size >= 15)
    }
    @Test fun tabFeaturesHaveSeveralLanguages() {
        for (k in listOf("facebook/marketplace", "x/dm", "snapchat/stories", "linkedin/jobs", "netflix/games", "facebook/groups")) assertTrue("$k dil sayısı", rules[k]!!.count { it.startsWith("sel:") } >= 4)
    }
    @Test fun verifiedRulesAreUntouchedByNewEntries() {
        assertEquals(listOf("youtube/shorts", "!youtube/shorts", "instagram/reels", "instagram/dm"), rules["_verified"])
        assertTrue(rules["youtube/shorts"]!!.containsAll(listOf("reel_player_page_container", "shorts_player")))
        assertTrue(rules["instagram/reels"]!!.contains("clips_viewer_view_pager"))
    }
    @Test fun youtubeLiveExemptionStillBeatsSel() {
        assertFalse(Pure.matches(snap(sel = setOf("shorts"), ids = setOf("live_chat_content")), rules, "youtube", "shorts"))
        assertTrue(Pure.matches(snap(sel = setOf("shorts")), rules, "youtube", "shorts"))
    }

    @Test fun serviceCollectsSelectedLabelsAndFeedsRuleLab() {
        val s = src("block/OdakAccessibilityService.kt")
        assertTrue(s.contains("n.isSelected")); assertTrue(s.contains("collectSelected")); assertTrue(s.contains("Snap(out, descs, texts, sel)")); assertTrue(s.contains("RuleLab.feed(seen, snap.sel)"))
        assertTrue(s.contains("count < 16"))      // seçili alt ağaç taraması sınırlı
    }
    @Test fun ruleLabWritesSelRules() { val r = src("block/RuleLab.kt"); assertTrue(r.contains("deriveSel")); assertTrue(r.contains("posSel")); assertTrue(r.contains("negSel")) }
    @Test fun newFeatureStringsExistInAllLanguages() {
        for (d in listOf("values", "values-tr", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az")) {
            val t = File(TestFiles.main, "res/$d/strings.xml").readText()
            assertTrue("$d feat_jobs", t.contains("name=\"feat_jobs\"")); assertTrue("$d feat_games", t.contains("name=\"feat_games\""))
        }
    }
}
