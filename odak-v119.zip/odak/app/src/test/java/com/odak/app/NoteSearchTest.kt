package com.odak.app

import com.odak.app.notes.Note
import com.odak.app.notes.NotePure
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Not araması: Türkçe harf toleransı, başlık/klasör/gövde kapsamı, kilitli not kuralı. */
class NoteSearchTest {
    private fun note(title: String = "", body: String = "", folder: String = "", locked: Boolean = false) =
        Note(id = "x", title = title, body = body, folder = folder, locked = locked)

    @Test fun blankQueryMatchesAll() {
        assertTrue(NotePure.matches(note(body = "abc"), "  "))
    }

    @Test fun titleFolderAndBodyAreSearched() {
        assertTrue(NotePure.matches(note(title = "Alışveriş"), "alisveris"))
        assertTrue(NotePure.matches(note(folder = "İş"), "is"))
        assertTrue(NotePure.matches(note(body = "toplantı notları"), "TOPLANTI"))
    }

    @Test fun turkishDotlessIAndAccentsMatch() {
        assertTrue(NotePure.matches(note(body = "Işık ve çiçek"), "isik"))
        assertTrue(NotePure.matches(note(body = "Işık ve çiçek"), "CICEK"))
        assertTrue(NotePure.matches(note(title = "Güneş"), "gunes"))
    }

    @Test fun lockedNoteBodyIsNotSearched() {
        assertFalse(NotePure.matches(note(body = "gizli içerik", locked = true), "gizli"))
        assertTrue(NotePure.matches(note(title = "Kilitli", body = "gizli", locked = true), "kilitli"))
    }

    @Test fun unrelatedQueryDoesNotMatch() {
        assertFalse(NotePure.matches(note(title = "Alışveriş", body = "süt"), "kitap"))
    }

    @Test fun searchUsesSharedFoldingAndIsWired() {
        val s = File(TestFiles.code, "com/odak/app/notes/NotePure.kt").readText()
        val fn = s.substringAfter("fun matches(n: Note").substringBefore("/** mode:")
        assertTrue(fn.contains("com.odak.app.logic.Pure.foldForSearch(n.body).contains(t)"))
        assertFalse(fn.contains("ignoreCase = true"))
    }
}
