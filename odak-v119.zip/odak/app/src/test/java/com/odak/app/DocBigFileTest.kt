package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** v0.56.2: bellekte tutulmayan büyük dosya yolu (ZipFile + ön ek okuma). */
class DocBigFileTest {
    private val doc = Doc(DocKind.DOCX, listOf(DocPage("", listOf("Büyük dosya içindeki yazı ğüş"), listOf(listOf("a", "b")))))

    /** Gerçek belgeye, sıkıştırılmış [mb] MB'lık sahte "medya" girdisi ekler (diskte küçük, mantıksal boyutu büyük). */
    private fun withMedia(src: ByteArray, mb: Long, dir: File): File {
        val out = File.createTempFile("big", ".docx", dir); out.deleteOnExit()
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            java.util.zip.ZipInputStream(src.inputStream()).use { zi -> while (true) { val e = zi.nextEntry ?: break; z.putNextEntry(ZipEntry(e.name)); z.write(zi.readBytes()); z.closeEntry() } }
            z.putNextEntry(ZipEntry("word/media/huge.bin"))
            val chunk = ByteArray(1 shl 20)
            for (i in 0 until mb) z.write(chunk)
            z.closeEntry()
        }
        return out
    }
    private val tmp = File(System.getProperty("java.io.tmpdir"))

    @Test fun bigZipReadsTextOnly() {
        val f = withMedia(DocWrite.docx(doc), 300, tmp)
        val d = DocParse.parseFile("x.docx", f)
        assertEquals(DocKind.DOCX, d.kind)
        assertTrue(d.pages.joinToString { it.paragraphs.joinToString() }.contains("Büyük dosya içindeki yazı ğüş"))
    }
    @Test fun parseFileMatchesParseOnSmall() {
        for (t in listOf(ConvTarget.DOCX, ConvTarget.XLSX, ConvTarget.PPTX, ConvTarget.ODT, ConvTarget.ODS, ConvTarget.ODP)) {
            val b = DocWrite.write(doc, t)!!
            val f = File.createTempFile("tst_s", "." + t.ext, tmp); f.deleteOnExit(); f.writeBytes(b)
            val a = DocParse.parse("x." + t.ext, b); val c = DocParse.parseFile("x." + t.ext, f)
            assertEquals(t.name, a.kind, c.kind)
            assertEquals(t.name, a.pages.map { it.paragraphs to it.table }, c.pages.map { it.paragraphs to it.table })
        }
    }
    @Test fun hugeXmlEntryRejected() {
        val f = File.createTempFile("tst_x", ".docx", tmp); f.deleteOnExit()
        ZipOutputStream(f.outputStream()).use { z -> z.putNextEntry(ZipEntry("word/document.xml")); val c = ByteArray(1 shl 20); for (i in 0 until 130) z.write(c); z.closeEntry() }
        val d = DocParse.parseFile("x.docx", f)
        assertTrue(d.pages.isEmpty())
    }
    @Test fun oversizedTextIsTruncatedAndFlagged() {
        val f = File.createTempFile("tst_t", ".txt", tmp); f.deleteOnExit()
        java.io.RandomAccessFile(f, "rw").use { r -> r.write("merhaba dünya\n".toByteArray()); r.setLength(DocParse.MAX_BYTES + 10L) }
        val d = DocParse.parseFile("t.txt", f, 1000)
        assertTrue(d.approx); assertTrue(d.pages[0].paragraphs[0].startsWith("merhaba dünya"))
    }
    @Test fun oversizedOpaqueOrLegacyRefused() {
        val f = File.createTempFile("tst_o", ".doc", tmp); f.deleteOnExit()
        java.io.RandomAccessFile(f, "rw").use { r -> r.write(byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte(), 0xA1.toByte(), 0xB1.toByte(), 0x1A, 0xE1.toByte())); r.setLength(DocParse.MAX_BYTES + 10L) }
        val d = DocParse.parseFile("o.doc", f)
        assertEquals(DocKind.UNKNOWN, d.kind); assertTrue(d.pages.isEmpty())
    }
    @Test fun pdfNotParsedHere() { val f = File.createTempFile("tst_p", ".pdf", tmp); f.deleteOnExit(); f.writeBytes("%PDF-1.4\n".toByteArray()); assertEquals(DocKind.PDF, DocParse.parseFile("p.pdf", f).kind) }
    @Test fun garbageNeverThrows() { val f = File.createTempFile("tst_g", ".docx", tmp); f.deleteOnExit(); f.writeBytes(byteArrayOf(0x50, 0x4B, 3, 4, 1, 2, 3)); DocParse.parseFile("g.docx", f) }
    @Test fun emptyFileNeverThrows() { val f = File.createTempFile("tst_e", ".txt", tmp); f.deleteOnExit(); DocParse.parseFile("e.txt", f) }

    private fun code(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    @Test fun uiRoutesBigFilesToFilePath() { val s = code("docs/DocActivity.kt"); assertTrue(s.contains("BIG_AT")); assertTrue(s.contains("/proc/self/fd/")); assertTrue(s.contains("DocParse.parseFile")); assertTrue(s.contains("bigdoc")) }
    @Test fun copyFallbackChecksFreeSpace() { assertTrue(code("docs/DocActivity.kt").contains("usableSpace")) }
    @Test fun bigTempCleanedUp() { assertTrue(code("docs/DocActivity.kt").contains("tmp.delete()")) }
}
