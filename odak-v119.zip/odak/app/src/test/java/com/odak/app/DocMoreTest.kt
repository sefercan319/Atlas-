package com.odak.app

import com.odak.app.docs.ConvTarget
import com.odak.app.docs.DocConvert
import com.odak.app.docs.DocKind
import com.odak.app.docs.DocMore
import com.odak.app.docs.DocParse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** v0.56.38: altı yeni belge türü — EML, MHTML, FB2, IPYNB, arşiv (ZIP/CBZ/JAR), biçimli JSON. */
class DocMoreTest {
    private fun all(d: com.odak.app.docs.Doc) = d.pages.flatMap { it.paragraphs }
    private fun zip(vararg e: Pair<String, ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bo.toByteArray()
    }

    // ---- genel: uzantı ve tür
    @Test fun extensionsMapToNewKinds() {
        val m = mapOf("a.eml" to DocKind.EML, "a.mht" to DocKind.MHTML, "a.mhtml" to DocKind.MHTML, "a.fb2" to DocKind.FB2,
            "a.ipynb" to DocKind.IPYNB, "a.zip" to DocKind.ARCHIVE, "a.cbz" to DocKind.ARCHIVE, "a.jar" to DocKind.ARCHIVE,
            "a.json" to DocKind.JSON, "a.geojson" to DocKind.JSON)
        for ((n, k) in m) assertEquals(n, k, DocParse.detect(n, ByteArray(8)))
    }

    // ---- JSON
    @Test fun jsonParsesAndPretty() {
        val v = DocMore.Json.parse("""{"a":1,"b":[true,null,"x"],"c":{}, "d":1.50}""")
        val p = DocMore.Json.pretty(v)
        assertEquals(listOf("{", "  \"a\": 1,", "  \"b\": [", "    true,", "    null,", "    \"x\"", "  ],", "  \"c\": {},", "  \"d\": 1.50", "}"), p)
    }
    @Test fun jsonEscapesAndUnicode() {
        val v = DocMore.Json.parse("\"a\\n\\\"b\\u00e7\\\\\"")
        assertEquals("a\n\"bç\\", v)
        assertEquals("\"a\\n\\\"bç\\\\\"", DocMore.Json.quote(v as String))
    }
    @Test fun jsonBadFallsBackToRawLines() {
        val d = DocMore.jsonDoc("{\"a\": 1,\n oops}")
        assertEquals(DocKind.JSON, d.kind); assertTrue(d.approx); assertEquals(2, all(d).size)
    }
    @Test fun jsonRejectsTrailingAndDeep() {
        assertFalse(runCatching { DocMore.Json.parse("{} x") }.isSuccess)
        assertFalse(runCatching { DocMore.Json.parse("[".repeat(500) + "]".repeat(500)) }.isSuccess)
        assertTrue(runCatching { DocMore.Json.parse("[".repeat(100) + "]".repeat(100)) }.isSuccess)
    }
    @Test fun jsonFileGetsIndentedThroughParse() {
        val d = DocParse.parse("x.json", "{\"k\":[1,2]}".toByteArray())
        assertEquals(DocKind.JSON, d.kind); assertEquals("  \"k\": [", all(d)[1]); assertFalse(d.approx)
    }
    @Test fun jsonBomAndEmptyContainers() {
        assertEquals(listOf("[]"), DocMore.Json.pretty(DocMore.Json.parse("﻿[]")))
        assertEquals(listOf("{}"), DocMore.Json.pretty(DocMore.Json.parse("{}")))
    }

    // ---- EML
    private val eml = ("From: =?UTF-8?B?w4dhxJ9sYXI=?= <a@b.c>\r\nTo: x@y.z\r\nSubject: =?iso-8859-9?Q?Toplant=FD_notu?=\r\nDate: Mon, 26 Oct 2026 10:00:00 +0300\r\n" +
        "MIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=\"BB\"\r\n\r\n--BB\r\nContent-Type: multipart/alternative; boundary=\"AA\"\r\n\r\n" +
        "--AA\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\nMerhaba =C5=9Fimdi\r\nikinci sat=\r\n=C4=B1r\r\n" +
        "--AA\r\nContent-Type: text/html; charset=utf-8\r\n\r\n<p>HTML <b>kopya</b></p>\r\n--AA--\r\n" +
        "--BB\r\nContent-Type: application/pdf; name=\"rapor.pdf\"\r\nContent-Disposition: attachment; filename=\"rapor.pdf\"\r\nContent-Transfer-Encoding: base64\r\n\r\nJVBERi0=\r\n--BB--\r\n")
    @Test fun emlHeadersBodyAndAttachment() {
        val d = DocParse.parse("m.eml", eml.toByteArray(Charsets.ISO_8859_1))
        assertEquals(DocKind.EML, d.kind)
        val t = all(d)
        assertEquals("Subject: Toplantı notu", t[0])
        assertTrue(t.contains("From: Çağlar <a@b.c>"))
        assertTrue(t.contains("To: x@y.z")); assertTrue(t.contains("Date: Mon, 26 Oct 2026 10:00:00 +0300"))
        assertTrue(t.contains("Merhaba şimdi"))
        assertTrue(t.contains("ikinci satır"))
        assertFalse(t.any { it.contains("HTML") }) // düz metin varken HTML kopyası eklenmez
        assertEquals("📎 rapor.pdf", t.last())
    }
    @Test fun emlHtmlOnlyUsesHtmlText() {
        val m = "Subject: S\n\nContent-Type: x\n".toByteArray()
        val h = "Subject: Web\nContent-Type: text/html; charset=utf-8\n\n<html><body><p>Selam <i>dünya</i></p></body></html>"
        val d = DocMore.emlDoc(h.toByteArray())
        assertTrue(all(d).contains("Selam dünya")); assertNotNull(m)
    }
    @Test fun emlBase64Body() {
        val body = java.util.Base64.getMimeEncoder().encodeToString("Gövde metni".toByteArray())
        val d = DocMore.emlDoc("Subject: B\nContent-Type: text/plain; charset=utf-8\nContent-Transfer-Encoding: base64\n\n$body".toByteArray())
        assertTrue(all(d).contains("Gövde metni"))
    }
    @Test fun emlBrokenNeverThrows() {
        for (s in listOf("", "\n\n", "Content-Type: multipart/mixed; boundary=X\n\n--X\n", "Subject", "=?utf-8?B?***?=")) {
            val d = DocMore.emlDoc(s.toByteArray()); assertEquals(DocKind.EML, d.kind)
        }
    }
    @Test fun rfc2047AdjacentWordsJoin() {
        assertEquals("Çağlar Gül", DocMore.decodeWords("=?UTF-8?Q?=C3=87a=C4=9Flar?= =?UTF-8?Q?_G=C3=BCl?="))
        assertEquals("plain", DocMore.decodeWords("plain"))
    }
    @Test fun nestedMessageAndDepthCap() {
        var m = "Content-Type: text/plain\n\nSon"
        repeat(30) { m = "Content-Type: message/rfc822\n\n$m" }
        assertEquals(DocKind.EML, DocMore.emlDoc(m.toByteArray()).kind) // sınır aşılınca sessizce keser, çökmez
    }
    @Test fun paramParsing() {
        assertEquals("utf-8", DocMore.param("text/plain; charset=\"utf-8\"", "charset"))
        assertEquals("BB", DocMore.param("multipart/mixed; boundary=BB; x=y", "boundary"))
        assertEquals(null, DocMore.param("text/plain", "charset"))
    }

    // ---- MHTML
    @Test fun mhtmlReadsHtmlPart() {
        val s = "From: <saved>\nSubject: Sayfa\nContent-Type: multipart/related; boundary=\"B\"\n\n--B\nContent-Type: text/html; charset=utf-8\nContent-Transfer-Encoding: quoted-printable\n\n<h1>Ba=C5=9Fl=C4=B1k</h1><p>Metin</p>\n--B\nContent-Type: image/png\nContent-Transfer-Encoding: base64\nContent-Location: a.png\n\niVBORw0=\n--B--\n"
        val d = DocParse.parse("x.mhtml", s.toByteArray())
        assertEquals(DocKind.MHTML, d.kind)
        val t = all(d); assertEquals("Sayfa", t[0]); assertTrue(t.contains("Başlık")); assertTrue(t.contains("Metin"))
        assertFalse(t.any { it.contains("iVBOR") })
    }

    // ---- FB2
    private val fb2 = """<?xml version="1.0" encoding="windows-1254"?><FictionBook><description><title-info><author><first-name>Sait</first-name><last-name>Faik</last-name></author><book-title>Semaver</book-title></title-info></description>
<body><section><title><p>Birinci</p></title><p>Ilk <strong>satır</strong> &amp; devam.</p><empty-line/><p>İkinci.</p></section>
<section><title><p>İkinci Bölüm</p></title><poem><stanza><v>dize bir</v><v>dize iki</v></stanza></poem></section></body><binary id="a" content-type="image/png">AAAA</binary></FictionBook>"""
    @Test fun fb2SectionsAndMeta() {
        val d = DocParse.parse("k.fb2", fb2.toByteArray(charset("windows-1254")))
        assertEquals(DocKind.FB2, d.kind)
        assertEquals(listOf("Semaver", "Sait Faik"), d.pages[0].paragraphs)
        assertEquals("Birinci", d.pages[1].title); assertEquals(listOf("Ilk satır & devam.", "", "İkinci."), d.pages[1].paragraphs)
        assertEquals("İkinci Bölüm", d.pages[2].title); assertEquals(listOf("dize bir", "dize iki"), d.pages[2].paragraphs)
        assertEquals(3, d.pages.size); assertFalse(d.pages.any { p -> p.paragraphs.any { it.contains("AAAA") } })
    }
    @Test fun fb2BrokenOrEmpty() {
        assertEquals(0, DocMore.fb2Doc("<FictionBook></FictionBook>".toByteArray()).pages.size)
        assertEquals(DocKind.FB2, DocMore.fb2Doc(ByteArray(0)).kind)
    }

    // ---- IPYNB
    @Test fun ipynbCellsAndOutputs() {
        val nb = """{"cells":[{"cell_type":"markdown","source":["# Başlık\n","metin"]},{"cell_type":"code","execution_count":3,"source":"print(1)\nx=2","outputs":[{"output_type":"stream","text":["1\n"]},{"output_type":"execute_result","data":{"text/plain":["2"]}}]},{"cell_type":"code","source":[],"outputs":[{"output_type":"error","traceback":["\u001b[0;31mHata\u001b[0m"]}]}],"nbformat":4}"""
        val d = DocParse.parse("n.ipynb", nb.toByteArray())
        assertEquals(DocKind.IPYNB, d.kind)
        val t = all(d)
        assertEquals("# Başlık", t[0]); assertEquals("metin", t[1])
        assertTrue(t.contains("In [3]:")); assertTrue(t.contains("    print(1)")); assertTrue(t.contains("  ⇒ 1")); assertTrue(t.contains("  ⇒ 2"))
        assertTrue(t.contains("  ⇒ Hata")); assertFalse(t.any { it.contains("\u001b") })
    }
    @Test fun ipynbNotANotebook() {
        assertEquals(0, DocMore.ipynbDoc("{}").pages.size); assertEquals(0, DocMore.ipynbDoc("not json").pages.size)
        assertEquals(0, DocMore.ipynbDoc("{\"cells\":[]}").pages.size)
    }

    // ---- Arşiv
    @Test fun archiveListsEntriesFromBytes() {
        val d = DocParse.parse("p.zip", zip("a.txt" to ByteArray(10), "dir/b.bin" to ByteArray(2048)))
        assertEquals(DocKind.ARCHIVE, d.kind)
        val tb = d.pages[0].table!!
        assertEquals(listOf("Name", "Size"), tb[0]); assertEquals(listOf("a.txt", "10 B"), tb[1]); assertEquals(listOf("dir/b.bin", "2.0 KB"), tb[2])
        assertEquals("2 files, 2.0 KB", d.pages[0].paragraphs[0])
    }
    @Test fun archiveListsEntriesFromFile() {
        val f = File.createTempFile("tst", ".cbz"); f.writeBytes(zip("1.jpg" to ByteArray(5), "2.jpg" to ByteArray(7)))
        try {
            val d = DocParse.parseFile("c.cbz", f)
            assertEquals(DocKind.ARCHIVE, d.kind); assertEquals(3, d.pages[0].table!!.size); assertEquals("2 files, 12 B", d.pages[0].paragraphs[0])
        } finally { f.delete() }
    }
    @Test fun zipWithOfficeContentIsStillOffice() {
        val d = DocParse.parse("renamed.zip", zip("word/document.xml" to "<w:document xmlns:w=\"x\"><w:body><w:p><w:r><w:t>Merhaba</w:t></w:r></w:p></w:body></w:document>".toByteArray()))
        assertEquals(DocKind.DOCX, d.kind); assertTrue(all(d).contains("Merhaba"))
    }
    @Test fun unknownExtensionZipIsListedNotEmpty() {
        val d = DocParse.parse("noext", zip("x" to ByteArray(1)))
        assertEquals(DocKind.ARCHIVE, d.kind); assertEquals(2, d.pages[0].table!!.size)
    }
    @Test fun humanSizes() {
        assertEquals("0 B", DocMore.humanSize(0)); assertEquals("1.0 KB", DocMore.humanSize(1024)); assertEquals("1.5 MB", DocMore.humanSize(1572864))
        assertEquals("2.00 GB", DocMore.humanSize(2L * 1024 * 1024 * 1024)); assertEquals("?", DocMore.humanSize(-1))
    }
    @Test fun emptyOrBrokenZipDoesNotThrow() {
        assertEquals(DocKind.ARCHIVE, DocParse.parse("a.zip", zip()).kind.let { if (it == DocKind.UNKNOWN) DocKind.ARCHIVE else it })
        DocParse.parse("b.zip", byteArrayOf(0x50, 0x4B, 3, 4, 1, 2, 3))
    }

    // ---- Dönüştürme
    @Test fun newKindsAreConvertible() {
        for (k in listOf(DocKind.EML, DocKind.MHTML, DocKind.FB2, DocKind.IPYNB, DocKind.ARCHIVE, DocKind.JSON)) {
            val t = DocConvert.targetsFor(k, true)
            assertTrue(k.name, ConvTarget.TXT in t && ConvTarget.DOCX in t && ConvTarget.PDF in t && ConvTarget.PNG_ZIP !in t)
            assertTrue(k.name, DocConvert.targetsFor(k, false).isEmpty())
        }
    }

    // ---- Arayüz bağlantıları
    @Test fun manifestListsNewMimeTypes() {
        val m = File(TestFiles.main, "AndroidManifest.xml").readText()
        for (t in listOf("message/rfc822", "application/x-fictionbook+xml", "application/x-ipynb+json", "application/json", "application/zip", "application/vnd.comicbook+zip", "application/x-mimearchive"))
            assertTrue(t, m.contains("android:mimeType=\"$t\""))
    }
    @Test fun hugeJsonStillPreviewsAsText() {
        val p = File(TestFiles.code, "com/odak/app/docs/DocParse.kt").readText()
        assertTrue(p.contains("isTextKind(kind)") && p.contains("k == DocKind.TEXT || k == DocKind.JSON"))
        assertTrue(File(TestFiles.code, "com/odak/app/docs/DocActivity.kt").readText().contains("DocParse.isTextKind(kind)"))
    }
    @Test fun fb2PagesUseSectionLabels() {
        assertTrue(File(TestFiles.code, "com/odak/app/docs/DocActivity.kt").readText().contains("DocKind.EPUB, DocKind.FB2, DocKind.MOBI ->"))
    }
}
