package com.odak.app

import com.odak.app.settings.MoreLayout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.34: "Diğer" bölümlü kartlar; Ekran süresi 3 sekme. */
class MoreHubTest {
    private fun code(rel: String) = File(TestFiles.code, "com/odak/app/$rel").readText()
    private fun everyLocale(vararg keys: String) {
        for (d in TestFiles.res.listFiles { f -> f.isDirectory && f.name.startsWith("values") }!!) {
            val f = File(d, "strings.xml"); if (!f.exists()) continue
            val t = f.readText(); for (k in keys) assertTrue("${d.name}:$k", t.contains("name=\"$k\""))
        }
    }

    @Test fun everyEntryInExactlyOneSection() {
        val names = Regex("^\\s+([A-Z_]+)\\(\"", RegexOption.MULTILINE).findAll(code("settings/MoreScreen.kt").substringAfter("enum class MoreEntry").substringBefore("}")).map { it.groupValues[1] }.toList()
        assertEquals(names.sorted(), MoreLayout.allEntries().sorted())
        assertEquals(MoreLayout.allEntries().size, MoreLayout.allEntries().distinct().size)
    }

    @Test fun rowsHaveAtMostTwoColumns() {
        assertEquals(listOf(listOf("a", "b"), listOf("c")), MoreLayout.rows(listOf("a", "b", "c")))
        assertTrue(MoreLayout.rows(MoreLayout.allEntries()).all { it.size <= MoreLayout.COLUMNS })
        assertEquals(2, MoreLayout.sections.size)
    }

    @Test fun hubUsesSectionsAndTiles() {
        val t = code("settings/MoreScreen.kt")
        assertTrue(t.contains("MoreLayout.sections.forEach") && t.contains("MoreLayout.rows(names)") && t.contains("e.descRes"))
    }

    @Test fun screenTimeHasThreeTabs() {
        val t = code("block/ScreenTimeScreen.kt")
        assertTrue(t.contains("R.string.st_tab_sum, R.string.st_tab_charts, R.string.st_tab_apps"))
        assertTrue(t.contains("when (tab) { 0 -> summaryPane(); 1 -> chartsPane(); else -> appsPane() }"))
        for (p in listOf("headPane", "summaryPane", "chartsPane", "appsPane")) assertEquals(p, 1, Regex("val $p:").findAll(t).count())
        // yatayda iki bölme korunur, sekme yok
        assertTrue(t.contains("headPane(); summaryPane()") && t.contains("chartsPane(); appsPane()"))
    }

    @Test fun stringsInAllLocales() {
        everyLocale("st_tab_sum", "st_tab_charts", "st_tab_apps", "more_sec_tools", "more_sec_app", "more_d_screen", "more_d_docs", "more_d_settings")
    }
}
