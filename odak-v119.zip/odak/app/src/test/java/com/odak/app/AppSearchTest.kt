package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Uygulama arama: Türkçe harf/aksan toleransı, paket adıyla arama, boş sorgu, seçici bağlantısı. */
class AppSearchTest {
    @Test fun blankQueryMatchesEverything() {
        assertTrue(Pure.nameMatches("Instagram", "   "))
        assertTrue(Pure.nameMatches("Instagram", ""))
    }

    @Test fun caseInsensitive() {
        assertTrue(Pure.nameMatches("WhatsApp", "whats"))
        assertTrue(Pure.nameMatches("whatsapp", "WHATS"))
    }

    @Test fun turkishDotlessAndAccentsAreTolerated() {
        assertTrue(Pure.nameMatches("Işık Uygulaması", "isik"))
        assertTrue(Pure.nameMatches("isik", "IŞIK"))
        assertTrue(Pure.nameMatches("Çiçek", "cicek"))
        assertTrue(Pure.nameMatches("Güneş", "gunes"))
        assertTrue(Pure.nameMatches("Şarkı", "sarki"))
    }

    @Test fun turkishCapitalIWithDotFolds() {
        assertEquals("istanbul", Pure.foldForSearch("İSTANBUL"))
        assertFalse(Pure.foldForSearch("İSTANBUL").contains('\u0307'))
    }

    @Test fun packageNameIsSearchable() {
        assertTrue(Pure.nameMatches("Mesajlar", "whatsapp", "com.whatsapp"))
        assertTrue(Pure.nameMatches("Mesajlar", "com.whats", "com.whatsapp"))
        assertFalse(Pure.nameMatches("Mesajlar", "telegram", "com.whatsapp"))
    }

    @Test fun oldTwoArgumentCallStillWorks() {
        assertTrue(Pure.nameMatches("Instagram", "insta"))
        assertFalse(Pure.nameMatches("Instagram", "tiktok"))
    }

    @Test fun pickerUsesSharedSearchAndShowsPackageAndEmptyState() {
        val s = File(TestFiles.code, "com/odak/app/block/Extras.kt").readText()
        val picker = s.substringAfter("fun CustomAppPicker").substringBefore("/** ")
        assertTrue(picker.contains("Pure.nameMatches(it.label, q, it.pkg)"))
        assertTrue(picker.contains("a.label + \"\\n\" + a.pkg"))
        assertTrue(picker.contains("R.string.custom_app_none"))
        assertFalse(picker.contains("ignoreCase = true"))
    }

    @Test fun blockScreenSearchStillUsesSharedMatcher() {
        val s = File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()
        assertTrue(s.contains("com.odak.app.logic.Pure.nameMatches(it.name, appQ)"))
    }

    @Test fun emptyStateStringExistsInEveryLocale() {
        for (d in listOf("values", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az", "values-tr")) {
            assertTrue(d, File(TestFiles.res, "$d/strings.xml").readText().contains("name=\"custom_app_none\">"))
        }
    }
}
