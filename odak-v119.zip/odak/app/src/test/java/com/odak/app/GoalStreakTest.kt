package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Hedef serisi (🔥): saf mantık ve ekran bağlantısı. Son eleman bugündür ve sayılmaz. */
class GoalStreakTest {
    private val goal = 60L * 60_000L // 60 dk

    @Test fun emptyHistoryHasNoStreak() {
        assertEquals(0, Pure.goalStreak(emptyList(), goal))
        assertEquals(0, Pure.goalStreak(listOf(10L), goal))
    }

    @Test fun zeroOrNegativeGoalMeansNoStreak() {
        assertEquals(0, Pure.goalStreak(listOf(1L, 2L, 3L), 0L))
        assertEquals(0, Pure.goalStreak(listOf(1L, 2L, 3L), -5L))
    }

    @Test fun allDaysUnderGoalCountsEveryPastDayNotToday() {
        val hist = List(10) { 10 * 60_000L } // bugün dahil 10 gün, hepsi altında
        assertEquals(9, Pure.goalStreak(hist, goal))
    }

    @Test fun todayOverGoalDoesNotBreakStreak() {
        val hist = listOf(10L, 10L, 10L, 999L * 60_000L) // bugün aşıldı, dünkü seri sayılır
        assertEquals(3, Pure.goalStreak(hist, goal))
    }

    @Test fun firstOverDayWalkingBackBreaksStreak() {
        val over = 120 * 60_000L
        // eskiden yeniye: ..., aşım, 10, 10, 10(bugün). Dünden geriye 2 gün altında, sonra aşım.
        val hist = listOf(over, 10L, 10L, 10L)
        assertEquals(2, Pure.goalStreak(hist, goal))
    }

    @Test fun exactlyAtGoalCountsAsUnder() {
        assertEquals(2, Pure.goalStreak(listOf(goal, goal, goal), goal))
    }

    @Test fun longStreakOverSixtyDaysIsNotCapped() {
        val hist = List(61) { 5 * 60_000L }
        assertEquals(60, Pure.goalStreak(hist, goal))
    }

    @Test fun screenUsesFullHistoryNotSevenOrThirteenDays() {
        val s = File(TestFiles.code, "com/odak/app/block/ScreenTimeScreen.kt").readText()
        assertTrue(s.contains("Pure.goalStreak(week.map { it.second }, goal * 60_000L)"))
        assertTrue(!s.contains("takeWhile { it.second <= goal * 60_000L }"))
        assertTrue(s.contains("weekTotals(ctx, STREAK_WINDOW_DAYS)"))
        assertTrue(s.contains("private const val STREAK_WINDOW_DAYS = 60"))
        assertTrue(s.contains("(days - 1 downTo 0).map"))
    }
}
