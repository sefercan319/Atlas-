package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Öğrenilen kurallar: anahtar biçimi, kayıtlı sayısı, silme onayı ve engel bekleme kuralı. */
class LearnedRuleTest {
    @Test fun ruleKeyFormatMatchesFileLayout() {
        assertEquals("instagram/reels", Pure.ruleKey("instagram", "reels"))
    }

    @Test fun deleteButtonHiddenWhileFeatureIsBlocked() {
        val s = File(TestFiles.code, "com/odak/app/block/Extras.kt").readText()
        val dlg = s.substringAfter("fun RuleLabDialog").substringBefore("\n}\n")
        assertTrue(dlg.contains("if (!BlockStore.isFeatureBlocked(ctx, appId, featId))"))
    }

    @Test fun deleteNeedsTwoTapsAndNeverTogglesBlockOff() {
        val s = File(TestFiles.code, "com/odak/app/block/Extras.kt").readText()
        val dlg = s.substringAfter("fun RuleLabDialog").substringBefore("\n}\n")
        assertTrue(dlg.contains("if (!confirmDel) confirmDel = true"))
        assertTrue(dlg.contains("RuleLab.removeSaved(ctx, appId, featId)"))
        assertFalse(dlg.contains("setFeatureBlocked(ctx, appId, featId, false)"))
    }

    @Test fun savedCountShownAndRefreshedAfterMake() {
        val s = File(TestFiles.code, "com/odak/app/block/Extras.kt").readText()
        val dlg = s.substringAfter("fun RuleLabDialog").substringBefore("\n}\n")
        assertTrue(dlg.contains("var savedN by remember { mutableStateOf(RuleLab.savedCount(ctx, appId, featId)) }"))
        assertTrue(dlg.contains("savedN = RuleLab.savedCount(ctx, appId, featId)"))
        assertTrue(dlg.contains("R.string.rl_saved_n, savedN"))
    }

    @Test fun ruleLabHasSavedCountAndRemove() {
        val s = File(TestFiles.code, "com/odak/app/block/RuleLab.kt").readText()
        assertTrue(s.contains("fun savedCount(c: Context, app: String, feat: String): Int"))
        assertTrue(s.contains("fun removeSaved(c: Context, app: String, feat: String): Boolean"))
        assertTrue(s.contains("Pure.ruleKey(app, feat)"))
    }

    @Test fun newStringsExistInEveryLocale() {
        for (d in listOf("values", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az", "values-tr")) {
            val s = File(TestFiles.res, "$d/strings.xml").readText()
            for (k in listOf("rl_saved_n", "rl_del", "rl_del_confirm")) assertTrue("$d $k", s.contains("name=\"$k\">"))
        }
    }
}
