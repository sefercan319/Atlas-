package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.52: yeni özellikler için tablo tabanlı testler (beklenen değerler bağımsız Python hesabından). */
class TplGenTest {
    @Test fun fill_0() { assertEquals("Merhaba Ders", Pure.fillTpl("Merhaba {title}", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_1() { assertEquals("Merhaba Ders", Pure.msgOrDefault("Merhaba {title}", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_2() { assertEquals("Merhaba {time}", Pure.fillTpl("Merhaba {title}", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_3() { assertEquals("Merhaba {time}", Pure.msgOrDefault("Merhaba {title}", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_4() { assertEquals("Merhaba {title}", Pure.fillTpl("Merhaba {title}", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_5() { assertEquals("Merhaba {title}", Pure.msgOrDefault("Merhaba {title}", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_6() { assertEquals("Merhaba {title}", Pure.fillTpl("Merhaba {title}", emptyMap())) }
    @Test fun msgDef_7() { assertEquals("Merhaba {title}", Pure.msgOrDefault("Merhaba {title}", "Varsayılan", emptyMap())) }
    @Test fun fill_8() { assertEquals("Merhaba a\$b", Pure.fillTpl("Merhaba {title}", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_9() { assertEquals("Merhaba a\$b", Pure.msgOrDefault("Merhaba {title}", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_10() { assertEquals("Merhaba {title}", Pure.fillTpl("Merhaba {title}", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_11() { assertEquals("Merhaba {title}", Pure.msgOrDefault("Merhaba {title}", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_12() { assertEquals("Ders saat 09:30", Pure.fillTpl("{title} saat {time}", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_13() { assertEquals("Ders saat 09:30", Pure.msgOrDefault("{title} saat {time}", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_14() { assertEquals("{time} saat x", Pure.fillTpl("{title} saat {time}", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_15() { assertEquals("{time} saat x", Pure.msgOrDefault("{title} saat {time}", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_16() { assertEquals("{title} saat {time}", Pure.fillTpl("{title} saat {time}", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_17() { assertEquals("{title} saat {time}", Pure.msgOrDefault("{title} saat {time}", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_18() { assertEquals("{title} saat {time}", Pure.fillTpl("{title} saat {time}", emptyMap())) }
    @Test fun msgDef_19() { assertEquals("{title} saat {time}", Pure.msgOrDefault("{title} saat {time}", "Varsayılan", emptyMap())) }
    @Test fun fill_20() { assertEquals("a\$b saat \\1", Pure.fillTpl("{title} saat {time}", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_21() { assertEquals("a\$b saat \\1", Pure.msgOrDefault("{title} saat {time}", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_22() { assertEquals("{title} saat {time}", Pure.fillTpl("{title} saat {time}", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_23() { assertEquals("{title} saat {time}", Pure.msgOrDefault("{title} saat {time}", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_24() { assertEquals("{app} için {min} dk kaldı", Pure.fillTpl("{app} için {min} dk kaldı", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_25() { assertEquals("{app} için {min} dk kaldı", Pure.msgOrDefault("{app} için {min} dk kaldı", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_26() { assertEquals("{app} için {min} dk kaldı", Pure.fillTpl("{app} için {min} dk kaldı", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_27() { assertEquals("{app} için {min} dk kaldı", Pure.msgOrDefault("{app} için {min} dk kaldı", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_28() { assertEquals("YouTube için 5 dk kaldı", Pure.fillTpl("{app} için {min} dk kaldı", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_29() { assertEquals("YouTube için 5 dk kaldı", Pure.msgOrDefault("{app} için {min} dk kaldı", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_30() { assertEquals("{app} için {min} dk kaldı", Pure.fillTpl("{app} için {min} dk kaldı", emptyMap())) }
    @Test fun msgDef_31() { assertEquals("{app} için {min} dk kaldı", Pure.msgOrDefault("{app} için {min} dk kaldı", "Varsayılan", emptyMap())) }
    @Test fun fill_32() { assertEquals("{app} için {min} dk kaldı", Pure.fillTpl("{app} için {min} dk kaldı", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_33() { assertEquals("{app} için {min} dk kaldı", Pure.msgOrDefault("{app} için {min} dk kaldı", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_34() { assertEquals("{app} için {min} dk kaldı", Pure.fillTpl("{app} için {min} dk kaldı", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_35() { assertEquals("{app} için {min} dk kaldı", Pure.msgOrDefault("{app} için {min} dk kaldı", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_36() { assertEquals("{app}", Pure.fillTpl("{app}", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_37() { assertEquals("{app}", Pure.msgOrDefault("{app}", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_38() { assertEquals("{app}", Pure.fillTpl("{app}", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_39() { assertEquals("{app}", Pure.msgOrDefault("{app}", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_40() { assertEquals("YouTube", Pure.fillTpl("{app}", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_41() { assertEquals("YouTube", Pure.msgOrDefault("{app}", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_42() { assertEquals("{app}", Pure.fillTpl("{app}", emptyMap())) }
    @Test fun msgDef_43() { assertEquals("{app}", Pure.msgOrDefault("{app}", "Varsayılan", emptyMap())) }
    @Test fun fill_44() { assertEquals("{app}", Pure.fillTpl("{app}", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_45() { assertEquals("{app}", Pure.msgOrDefault("{app}", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_46() { assertEquals("{app}", Pure.fillTpl("{app}", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_47() { assertEquals("{app}", Pure.msgOrDefault("{app}", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_48() { assertEquals("{x} Ders", Pure.fillTpl("{x} {title}", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_49() { assertEquals("{x} Ders", Pure.msgOrDefault("{x} {title}", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_50() { assertEquals("{x} {time}", Pure.fillTpl("{x} {title}", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_51() { assertEquals("{x} {time}", Pure.msgOrDefault("{x} {title}", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_52() { assertEquals("{x} {title}", Pure.fillTpl("{x} {title}", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_53() { assertEquals("{x} {title}", Pure.msgOrDefault("{x} {title}", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_54() { assertEquals("{x} {title}", Pure.fillTpl("{x} {title}", emptyMap())) }
    @Test fun msgDef_55() { assertEquals("{x} {title}", Pure.msgOrDefault("{x} {title}", "Varsayılan", emptyMap())) }
    @Test fun fill_56() { assertEquals("{x} a\$b", Pure.fillTpl("{x} {title}", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_57() { assertEquals("{x} a\$b", Pure.msgOrDefault("{x} {title}", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_58() { assertEquals("{x} {title}", Pure.fillTpl("{x} {title}", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_59() { assertEquals("{x} {title}", Pure.msgOrDefault("{x} {title}", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_60() { assertEquals("{Ders}", Pure.fillTpl("{{title}}", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_61() { assertEquals("{Ders}", Pure.msgOrDefault("{{title}}", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_62() { assertEquals("{{time}}", Pure.fillTpl("{{title}}", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_63() { assertEquals("{{time}}", Pure.msgOrDefault("{{title}}", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_64() { assertEquals("{{title}}", Pure.fillTpl("{{title}}", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_65() { assertEquals("{{title}}", Pure.msgOrDefault("{{title}}", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_66() { assertEquals("{{title}}", Pure.fillTpl("{{title}}", emptyMap())) }
    @Test fun msgDef_67() { assertEquals("{{title}}", Pure.msgOrDefault("{{title}}", "Varsayılan", emptyMap())) }
    @Test fun fill_68() { assertEquals("{a\$b}", Pure.fillTpl("{{title}}", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_69() { assertEquals("{a\$b}", Pure.msgOrDefault("{{title}}", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_70() { assertEquals("{{title}}", Pure.fillTpl("{{title}}", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_71() { assertEquals("{{title}}", Pure.msgOrDefault("{{title}}", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_72() { assertEquals("DersDers", Pure.fillTpl("{title}{title}", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_73() { assertEquals("DersDers", Pure.msgOrDefault("{title}{title}", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_74() { assertEquals("{time}{time}", Pure.fillTpl("{title}{title}", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_75() { assertEquals("{time}{time}", Pure.msgOrDefault("{title}{title}", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_76() { assertEquals("{title}{title}", Pure.fillTpl("{title}{title}", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_77() { assertEquals("{title}{title}", Pure.msgOrDefault("{title}{title}", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_78() { assertEquals("{title}{title}", Pure.fillTpl("{title}{title}", emptyMap())) }
    @Test fun msgDef_79() { assertEquals("{title}{title}", Pure.msgOrDefault("{title}{title}", "Varsayılan", emptyMap())) }
    @Test fun fill_80() { assertEquals("a\$ba\$b", Pure.fillTpl("{title}{title}", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_81() { assertEquals("a\$ba\$b", Pure.msgOrDefault("{title}{title}", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_82() { assertEquals("{title}{title}", Pure.fillTpl("{title}{title}", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_83() { assertEquals("{title}{title}", Pure.msgOrDefault("{title}{title}", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_84() { assertEquals("boşluk 09:30", Pure.fillTpl("  boşluk {time}  ", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_85() { assertEquals("boşluk 09:30", Pure.msgOrDefault("  boşluk {time}  ", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_86() { assertEquals("boşluk x", Pure.fillTpl("  boşluk {time}  ", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_87() { assertEquals("boşluk x", Pure.msgOrDefault("  boşluk {time}  ", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_88() { assertEquals("boşluk {time}", Pure.fillTpl("  boşluk {time}  ", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_89() { assertEquals("boşluk {time}", Pure.msgOrDefault("  boşluk {time}  ", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_90() { assertEquals("boşluk {time}", Pure.fillTpl("  boşluk {time}  ", emptyMap())) }
    @Test fun msgDef_91() { assertEquals("boşluk {time}", Pure.msgOrDefault("  boşluk {time}  ", "Varsayılan", emptyMap())) }
    @Test fun fill_92() { assertEquals("boşluk \\1", Pure.fillTpl("  boşluk {time}  ", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_93() { assertEquals("boşluk \\1", Pure.msgOrDefault("  boşluk {time}  ", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_94() { assertEquals("boşluk {time}", Pure.fillTpl("  boşluk {time}  ", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_95() { assertEquals("boşluk {time}", Pure.msgOrDefault("  boşluk {time}  ", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_96() { assertEquals("", Pure.fillTpl("", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_97() { assertEquals("Varsayılan", Pure.msgOrDefault("", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_98() { assertEquals("", Pure.fillTpl("", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_99() { assertEquals("Varsayılan", Pure.msgOrDefault("", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_100() { assertEquals("", Pure.fillTpl("", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_101() { assertEquals("Varsayılan", Pure.msgOrDefault("", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_102() { assertEquals("", Pure.fillTpl("", emptyMap())) }
    @Test fun msgDef_103() { assertEquals("Varsayılan", Pure.msgOrDefault("", "Varsayılan", emptyMap())) }
    @Test fun fill_104() { assertEquals("", Pure.fillTpl("", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_105() { assertEquals("Varsayılan", Pure.msgOrDefault("", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_106() { assertEquals("", Pure.fillTpl("", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_107() { assertEquals("Varsayılan", Pure.msgOrDefault("", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_108() { assertEquals("{TITLE}", Pure.fillTpl("{TITLE}", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_109() { assertEquals("{TITLE}", Pure.msgOrDefault("{TITLE}", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_110() { assertEquals("{TITLE}", Pure.fillTpl("{TITLE}", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_111() { assertEquals("{TITLE}", Pure.msgOrDefault("{TITLE}", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_112() { assertEquals("{TITLE}", Pure.fillTpl("{TITLE}", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_113() { assertEquals("{TITLE}", Pure.msgOrDefault("{TITLE}", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_114() { assertEquals("{TITLE}", Pure.fillTpl("{TITLE}", emptyMap())) }
    @Test fun msgDef_115() { assertEquals("{TITLE}", Pure.msgOrDefault("{TITLE}", "Varsayılan", emptyMap())) }
    @Test fun fill_116() { assertEquals("{TITLE}", Pure.fillTpl("{TITLE}", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_117() { assertEquals("{TITLE}", Pure.msgOrDefault("{TITLE}", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_118() { assertEquals("{TITLE}", Pure.fillTpl("{TITLE}", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_119() { assertEquals("{TITLE}", Pure.msgOrDefault("{TITLE}", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_120() { assertEquals("{ title }", Pure.fillTpl("{ title }", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_121() { assertEquals("{ title }", Pure.msgOrDefault("{ title }", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_122() { assertEquals("{ title }", Pure.fillTpl("{ title }", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_123() { assertEquals("{ title }", Pure.msgOrDefault("{ title }", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_124() { assertEquals("{ title }", Pure.fillTpl("{ title }", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_125() { assertEquals("{ title }", Pure.msgOrDefault("{ title }", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_126() { assertEquals("{ title }", Pure.fillTpl("{ title }", emptyMap())) }
    @Test fun msgDef_127() { assertEquals("{ title }", Pure.msgOrDefault("{ title }", "Varsayılan", emptyMap())) }
    @Test fun fill_128() { assertEquals("{ title }", Pure.fillTpl("{ title }", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_129() { assertEquals("{ title }", Pure.msgOrDefault("{ title }", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_130() { assertEquals("{ title }", Pure.fillTpl("{ title }", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_131() { assertEquals("{ title }", Pure.msgOrDefault("{ title }", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_132() { assertEquals("Bitti: {done}/{total}", Pure.fillTpl("Bitti: {done}/{total}", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_133() { assertEquals("Bitti: {done}/{total}", Pure.msgOrDefault("Bitti: {done}/{total}", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_134() { assertEquals("Bitti: {done}/{total}", Pure.fillTpl("Bitti: {done}/{total}", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_135() { assertEquals("Bitti: {done}/{total}", Pure.msgOrDefault("Bitti: {done}/{total}", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_136() { assertEquals("Bitti: {done}/{total}", Pure.fillTpl("Bitti: {done}/{total}", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_137() { assertEquals("Bitti: {done}/{total}", Pure.msgOrDefault("Bitti: {done}/{total}", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_138() { assertEquals("Bitti: {done}/{total}", Pure.fillTpl("Bitti: {done}/{total}", emptyMap())) }
    @Test fun msgDef_139() { assertEquals("Bitti: {done}/{total}", Pure.msgOrDefault("Bitti: {done}/{total}", "Varsayılan", emptyMap())) }
    @Test fun fill_140() { assertEquals("Bitti: {done}/{total}", Pure.fillTpl("Bitti: {done}/{total}", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_141() { assertEquals("Bitti: {done}/{total}", Pure.msgOrDefault("Bitti: {done}/{total}", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_142() { assertEquals("Bitti: 3/7", Pure.fillTpl("Bitti: {done}/{total}", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_143() { assertEquals("Bitti: 3/7", Pure.msgOrDefault("Bitti: {done}/{total}", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_144() { assertEquals("{plans} plan, {tasks} görev, {overdue} gecikmiş", Pure.fillTpl("{plans} plan, {tasks} görev, {overdue} gecikmiş", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_145() { assertEquals("{plans} plan, {tasks} görev, {overdue} gecikmiş", Pure.msgOrDefault("{plans} plan, {tasks} görev, {overdue} gecikmiş", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_146() { assertEquals("{plans} plan, {tasks} görev, {overdue} gecikmiş", Pure.fillTpl("{plans} plan, {tasks} görev, {overdue} gecikmiş", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_147() { assertEquals("{plans} plan, {tasks} görev, {overdue} gecikmiş", Pure.msgOrDefault("{plans} plan, {tasks} görev, {overdue} gecikmiş", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_148() { assertEquals("{plans} plan, {tasks} görev, {overdue} gecikmiş", Pure.fillTpl("{plans} plan, {tasks} görev, {overdue} gecikmiş", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_149() { assertEquals("{plans} plan, {tasks} görev, {overdue} gecikmiş", Pure.msgOrDefault("{plans} plan, {tasks} görev, {overdue} gecikmiş", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_150() { assertEquals("{plans} plan, {tasks} görev, {overdue} gecikmiş", Pure.fillTpl("{plans} plan, {tasks} görev, {overdue} gecikmiş", emptyMap())) }
    @Test fun msgDef_151() { assertEquals("{plans} plan, {tasks} görev, {overdue} gecikmiş", Pure.msgOrDefault("{plans} plan, {tasks} görev, {overdue} gecikmiş", "Varsayılan", emptyMap())) }
    @Test fun fill_152() { assertEquals("{plans} plan, {tasks} görev, {overdue} gecikmiş", Pure.fillTpl("{plans} plan, {tasks} görev, {overdue} gecikmiş", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_153() { assertEquals("{plans} plan, {tasks} görev, {overdue} gecikmiş", Pure.msgOrDefault("{plans} plan, {tasks} görev, {overdue} gecikmiş", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_154() { assertEquals("2 plan, 4 görev, 1 gecikmiş", Pure.fillTpl("{plans} plan, {tasks} görev, {overdue} gecikmiş", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_155() { assertEquals("2 plan, 4 görev, 1 gecikmiş", Pure.msgOrDefault("{plans} plan, {tasks} görev, {overdue} gecikmiş", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fill_156() { assertEquals("ğüşiöçİ Ders ✓", Pure.fillTpl("ğüşiöçİ {title} ✓", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun msgDef_157() { assertEquals("ğüşiöçİ Ders ✓", Pure.msgOrDefault("ğüşiöçİ {title} ✓", "Varsayılan", mapOf("title" to "Ders","time" to "09:30"))) }
    @Test fun fill_158() { assertEquals("ğüşiöçİ {time} ✓", Pure.fillTpl("ğüşiöçİ {title} ✓", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun msgDef_159() { assertEquals("ğüşiöçİ {time} ✓", Pure.msgOrDefault("ğüşiöçİ {title} ✓", "Varsayılan", mapOf("title" to "{time}","time" to "x"))) }
    @Test fun fill_160() { assertEquals("ğüşiöçİ {title} ✓", Pure.fillTpl("ğüşiöçİ {title} ✓", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun msgDef_161() { assertEquals("ğüşiöçİ {title} ✓", Pure.msgOrDefault("ğüşiöçİ {title} ✓", "Varsayılan", mapOf("app" to "YouTube","min" to "5"))) }
    @Test fun fill_162() { assertEquals("ğüşiöçİ {title} ✓", Pure.fillTpl("ğüşiöçİ {title} ✓", emptyMap())) }
    @Test fun msgDef_163() { assertEquals("ğüşiöçİ {title} ✓", Pure.msgOrDefault("ğüşiöçİ {title} ✓", "Varsayılan", emptyMap())) }
    @Test fun fill_164() { assertEquals("ğüşiöçİ a\$b ✓", Pure.fillTpl("ğüşiöçİ {title} ✓", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun msgDef_165() { assertEquals("ğüşiöçİ a\$b ✓", Pure.msgOrDefault("ğüşiöçİ {title} ✓", "Varsayılan", mapOf("title" to "a\$b","time" to "\\1"))) }
    @Test fun fill_166() { assertEquals("ğüşiöçİ {title} ✓", Pure.fillTpl("ğüşiöçİ {title} ✓", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun msgDef_167() { assertEquals("ğüşiöçİ {title} ✓", Pure.msgOrDefault("ğüşiöçİ {title} ✓", "Varsayılan", mapOf("done" to "3","total" to "7","plans" to "2","tasks" to "4","overdue" to "1"))) }
    @Test fun fillLen_168() { assertEquals(150, Pure.fillTpl("a".repeat(150), emptyMap()).length) }
    @Test fun fillLen_169() { assertEquals(199, Pure.fillTpl("a".repeat(199), emptyMap()).length) }
    @Test fun fillLen_170() { assertEquals(200, Pure.fillTpl("a".repeat(200), emptyMap()).length) }
    @Test fun fillLen_171() { assertEquals(200, Pure.fillTpl("a".repeat(201), emptyMap()).length) }
    @Test fun fillLen_172() { assertEquals(200, Pure.fillTpl("a".repeat(250), emptyMap()).length) }
    @Test fun fillLen_173() { assertEquals(200, Pure.fillTpl("a".repeat(400), emptyMap()).length) }
    @Test fun fillSurrogate() { val r = Pure.fillTpl("a".repeat(199) + "\uD83D\uDE00", emptyMap()); assertEquals(199, r.length) }
}
