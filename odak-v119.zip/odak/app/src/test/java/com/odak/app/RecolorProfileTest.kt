package com.odak.app

import com.odak.app.theme.Recolor
import com.odak.app.theme.RecolorProfiles
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RecolorProfileTest {
    private val targets = listOf(0xFF000000.toInt(), 0xFF0B0B1A.toInt(), 0xFF7C4DFF.toInt(), 0xFFFFC107.toInt(), 0xFFF5F5F5.toInt(), 0xFFFFFFFF.toInt())

    @Test fun everyStyleHasProfiles() {
        assertEquals(17, RecolorProfiles.STYLE_KEYS.size)
        for (k in RecolorProfiles.STYLE_KEYS) for (p in RecolorProfiles.Part.values()) RecolorProfiles.forStyle(k, p)
    }

    @Test fun darkAndLightTargetsKeepDetail() {
        for (k in RecolorProfiles.STYLE_KEYS) for (part in RecolorProfiles.Part.values()) {
            val pr = RecolorProfiles.forStyle(k, part)
            if (pr.hi - pr.lo < 8f) continue
            for (t in targets) {
                val base = ((pr.lo + pr.hi) / 2).toInt().let { (0xFF shl 24) or (it shl 16) or (it shl 8) or it }
                val lo = Recolor.luma(Recolor.apply(Recolor.matrix(t, base, pr), (0xFF shl 24) or (pr.lo.toInt() * 0x010101)))
                val hi = Recolor.luma(Recolor.apply(Recolor.matrix(t, base, pr), (0xFF shl 24) or (pr.hi.toInt() * 0x010101)))
                val want = (pr.hi - pr.lo) * 0.8f
                assertTrue("$k $part ${Integer.toHexString(t)} detail ${hi - lo} < $want", hi - lo >= minOf(want, 255f - 8f) - 3f)
            }
        }
    }

    @Test fun glossyKeepsWhiteHighlight() {
        val pr = RecolorProfiles.forStyle("frutiger_aero", RecolorProfiles.Part.BUTTON)
        val white = Recolor.applyWithSpec(0xFF7C4DFF.toInt(), 0xFF70A0E0.toInt(), pr, 0xFFFFFFFF.toInt())
        val mid = Recolor.applyWithSpec(0xFF7C4DFF.toInt(), 0xFF70A0E0.toInt(), pr, 0xFF70A0E0.toInt())
        assertTrue(Recolor.luma(white) > Recolor.luma(mid) + 60f)
    }

    @Test fun matteHasNoHighlightLayer() {
        assertEquals(0f, RecolorProfiles.forStyle("claymorphism", RecolorProfiles.Part.CARD).spec, 0f)
        assertEquals(0f, RecolorProfiles.forStyle("minimal", RecolorProfiles.Part.BACKGROUND).spec, 0f)
    }

    @Test fun midTargetStillExact() {
        val pr = RecolorProfiles.forStyle("aurora", RecolorProfiles.Part.BACKGROUND)
        val base = 0xFF303060.toInt()
        val out = Recolor.apply(Recolor.matrix(0xFF7C4DFF.toInt(), base, pr), base)
        assertEquals(0x7C, (out shr 16) and 255)
    }
}
