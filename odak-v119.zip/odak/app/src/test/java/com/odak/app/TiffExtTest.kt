package com.odak.app

import com.odak.app.docs.Ccitt
import com.odak.app.docs.TiffDecoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import javax.imageio.ImageIO
import kotlin.random.Random

/** v0.56.5: BigTIFF, CCITT (MH/G3/G4) ve JPEG-içi-TIFF — PIL/ImageMagick/libtiff'in ürettiği gerçek dosyalara karşı. */
class TiffExtTest {
    private val dir: File = listOf(File("src/test/resources/tiff2"), File("app/src/test/resources/tiff2")).first { it.exists() }
    private fun names(prefix: String) = dir.listFiles()!!.filter { it.name.startsWith(prefix) && it.name.endsWith(".tif") }.sortedBy { it.name }
    private fun expected(f: File): IntArray {
        val b = File(dir, f.name.removeSuffix(".tif") + ".rgba").readBytes()
        return IntArray(b.size / 4) { i -> ((b[4 * i + 3].toInt() and 0xFF) shl 24) or ((b[4 * i].toInt() and 0xFF) shl 16) or ((b[4 * i + 1].toInt() and 0xFF) shl 8) or (b[4 * i + 2].toInt() and 0xFF) }
    }
    private val jpegViaImageIo: (ByteArray) -> TiffDecoder.Img? = { b ->
        val bi = ImageIO.read(ByteArrayInputStream(b))
        if (bi == null) null
        else if (bi.type == java.awt.image.BufferedImage.TYPE_BYTE_GRAY) TiffDecoder.Img(bi.width, bi.height, IntArray(bi.width * bi.height) { val g = bi.raster.getSample(it % bi.width, it / bi.width, 0); (0xFF shl 24) or (g shl 16) or (g shl 8) or g })
        else TiffDecoder.Img(bi.width, bi.height, IntArray(bi.width * bi.height) { bi.getRGB(it % bi.width, it / bi.width) })
    }
    private fun diff(a: IntArray, b: IntArray): Double { var s = 0L; for (i in a.indices) for (sh in intArrayOf(0, 8, 16)) s += Math.abs(((a[i] shr sh) and 0xFF) - ((b[i] shr sh) and 0xFF)); return s.toDouble() / (a.size * 3) }

    @Test fun ccittFixturesAreExact() {
        val fs = names("ccitt_"); assertTrue(fs.size >= 8)
        for (f in fs) { val img = TiffDecoder.decode(f.readBytes(), 4096); assertNotNull(f.name, img); val e = expected(f); assertEquals(f.name, e.size, img!!.w * img.h); var bad = 0; for (i in e.indices) if (e[i] != img.argb[i]) bad++; assertEquals(f.name + " farklı piksel", 0, bad) }
    }
    @Test fun ccittCoversLongRunsAndTwoDimensional() { val n = names("ccitt_").map { it.name }; assertTrue(n.any { it.contains("b3000x9") }); assertTrue(n.any { it.contains("group4") }); assertTrue(n.any { it.contains("group3_2d") }); assertTrue(n.any { it.contains("strips") }) }
    @Test fun bigTiffFixturesAreExact() {
        val fs = names("big_"); assertTrue(fs.size >= 5)
        for (f in fs) { val raw = f.readBytes(); assertTrue(TiffDecoder.isTiff(raw)); val img = TiffDecoder.decode(raw); assertNotNull(f.name, img); val e = expected(f); assertEquals(f.name, e.size, img!!.w * img.h); var bad = 0; for (i in e.indices) if (e[i] != img.argb[i]) bad++; assertEquals(f.name + " farklı piksel", 0, bad) }
    }
    @Test fun jpegInTiffMatchesReference() {
        val fs = names("jpeg_"); assertTrue(fs.size >= 4)
        for (f in fs) { val img = TiffDecoder.decode(f.readBytes(), 2048, jpegViaImageIo); assertNotNull(f.name, img); val e = expected(f); assertEquals(f.name, e.size, img!!.w * img.h); val d = diff(e, img.argb); assertTrue(f.name + " ort. fark $d", d < 8.0) }
    }
    @Test fun jpegInTiffWithoutDecoderIsNullNotCrash() { for (f in names("jpeg_")) assertNull(TiffDecoder.decode(f.readBytes())) }
    @Test fun jpegCallbackThrowingIsHandled() { for (f in names("jpeg_")) { val img = TiffDecoder.decode(f.readBytes(), 2048) { throw IllegalStateException("x") }; assertNotNull(img) } }
    @Test fun jpegDownscaleKeepsAspect() { val f = names("jpeg_tiled").first(); val img = TiffDecoder.decode(f.readBytes(), 40, jpegViaImageIo)!!; assertTrue(img.w <= 40 && img.h <= 40 && img.w >= 20) }
    @Test fun fuzzedFilesNeverThrow() {
        val r = Random(5)
        for (f in names("")) {
            val good = f.readBytes()
            repeat(40) { val b = good.copyOf(); repeat(r.nextInt(1, 30)) { b[r.nextInt(b.size)] = r.nextInt().toByte() }; TiffDecoder.decode(b, 512, jpegViaImageIo) }
            repeat(15) { TiffDecoder.decode(good.copyOf(r.nextInt(1, good.size)), 512, jpegViaImageIo) }
        }
    }

    // ---- Ccitt doğrudan
    @Test fun ccittG4AllWhiteAndAllBlack() {
        // 8x2 tamamen beyaz: V0 V0 (1 1); satır2 de aynı → "1111" + EOFB
        val white = Ccitt.decode(byteArrayOf(0xF0.toByte(), 0x00, 0x10, 0x01), 8, 2, 4)
        assertEquals(listOf<Byte>(0, 0), white.toList())
        // 8x1 tamamen siyah: H (001) beyaz0 (00110101) siyah8 (000101) → 001 00110101 000101
        val bits = "001" + "00110101" + "000101"; val by = ByteArray((bits.length + 7) / 8) { i -> bits.padEnd(by(bits), '0').substring(8 * i, 8 * i + 8).toInt(2).toByte() }
        assertEquals(0xFF.toByte(), Ccitt.decode(by, 8, 1, 4)[0])
    }
    private fun by(s: String) = (s.length + 7) / 8 * 8
    @Test fun ccittOneDimensionalRuns() {
        // MH: beyaz3 (1000) siyah2 (11) beyaz3 (1000) → ...XX... ; 8 piksel
        val bits = "1000" + "11" + "1000"
        val by = ByteArray(2) { i -> bits.padEnd(16, '0').substring(8 * i, 8 * i + 8).toInt(2).toByte() }
        assertEquals(0x18.toByte(), Ccitt.decode(by, 8, 1, 2)[0])
    }
    @Test fun ccittGarbageNeverThrows() { val r = Random(3); repeat(300) { val d = ByteArray(r.nextInt(0, 200)) { r.nextInt().toByte() }; for (c in 2..4) { Ccitt.decode(d, r.nextInt(1, 300), r.nextInt(1, 40), c, r.nextInt(0, 8), r.nextBoolean()) } } }
    @Test fun ccittRejectsAbsurdSizes() { assertEquals(0, Ccitt.decode(ByteArray(4), 0, 5, 4).size); assertEquals(0, Ccitt.decode(ByteArray(4), 500000, 5, 4).size) }
    @Test fun sourceWiresCcittAndJpegCallback() {
        val t = File(TestFiles.code, "com/odak/app/docs/TiffDecoder.kt").readText(); assertTrue(t.contains("Ccitt.decode")); assertTrue(t.contains("jtables"))
        val u = File(TestFiles.code, "com/odak/app/docs/DocVisualUi.kt").readText(); assertTrue(u.contains("BitmapFactory.decodeByteArray")); assertTrue(u.contains("TiffDecoder.decode(bytes, maxSide"))
    }
}
