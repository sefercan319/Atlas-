package com.odak.app

import com.odak.app.docs.Metafile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.random.Random

/** v0.56.5: EMF/WMF eklentileri — RLE, kırpma, desen/gradyan fırça, çizgi stili ve EMF+ (elle üretilmiş kayıtlar). */
class MetafileExtTest {
    private class W { val o = ByteArrayOutputStream()
        fun i(v: Int) = apply { o.write(v and 0xFF); o.write((v shr 8) and 0xFF); o.write((v shr 16) and 0xFF); o.write((v shr 24) and 0xFF) }
        fun s(v: Int) = apply { o.write(v and 0xFF); o.write((v shr 8) and 0xFF) }
        fun f(v: Float) = i(java.lang.Float.floatToIntBits(v))
        fun b(v: ByteArray) = apply { o.write(v) }
        fun by(vararg v: Int) = apply { v.forEach { o.write(it) } }
        fun bytes() = o.toByteArray() }
    private fun rec(type: Int, vararg ints: Int): ByteArray { val w = W().i(type).i(8 + 4 * ints.size); for (v in ints) w.i(v); return w.bytes() }
    private fun recBytes(type: Int, body: ByteArray): ByteArray { val pad = (4 - body.size % 4) % 4; return W().i(type).i(8 + body.size + pad).b(body).b(ByteArray(pad)).bytes() }
    private fun emf(bounds: IntArray, vararg recs: ByteArray): ByteArray {
        val hdr = W().i(bounds[0]).i(bounds[1]).i(bounds[2]).i(bounds[3]).i(0).i(0).i(100).i(100).i(0x464D4520).i(0x10000).i(0).i(0).i(0).i(0).i(0).i(0).i(0).i(0).bytes()
        val all = ByteArrayOutputStream(); all.write(recBytes(1, hdr)); for (r in recs) all.write(r); all.write(rec(14, 0, 0, 0)); return all.toByteArray()
    }
    private fun dibHeader(w: Int, h: Int, bpp: Int, clr: Int = 0, comp: Int = 0) = W().i(40).i(w).i(h).s(1).s(bpp).i(comp).i(0).i(0).i(0).i(clr).i(0)
    private val RED = 0xFFFF0000.toInt(); private val GREEN = 0xFF00FF00.toInt(); private val BLUE = 0xFF0000FF.toInt(); private val BLACK = 0xFF000000.toInt(); private val WHITE = 0xFFFFFFFF.toInt()
    private fun parse(b: ByteArray) = Metafile.parse(b)!!
    private fun polys(m: Metafile.Meta) = m.ops.filterIsInstance<Metafile.Poly>()

    // ---------------- RLE
    @Test fun rle8Absolute() {
        val raw = dibHeader(4, 2, 8, 4, 1).b(byteArrayOf(0, 0, 0, 0, 0, 0, 255.toByte(), 0, 0, 255.toByte(), 0, 0, 255.toByte(), 0, 0, 0))   // siyah, kırmızı, yeşil, mavi (BGR0)
            .by(3, 1, 1, 0, 0, 0).by(0, 4, 2, 3, 2, 3, 0, 1).bytes()
        val d = Metafile.dib(raw, 0, raw.size, 0, 0)!!
        assertEquals(listOf(GREEN, BLUE, GREEN, BLUE, RED, RED, RED, BLACK), d.argb.toList())
    }
    @Test fun rle8DeltaLeavesTransparent() {
        val raw = dibHeader(4, 2, 8, 3, 1).b(byteArrayOf(0, 0, 0, 0, 0, 0, 255.toByte(), 0, 0, 255.toByte(), 0, 0)).by(2, 1, 0, 2, 1, 1, 1, 2, 0, 1).bytes()
        val d = Metafile.dib(raw, 0, raw.size, 0, 0)!!
        assertEquals(listOf(0, 0, 0, GREEN, RED, RED, 0, 0), d.argb.toList())
    }
    @Test fun rle4Runs() {
        val raw = dibHeader(4, 1, 4, 2, 2).b(byteArrayOf(0, 0, 0, 0, 255.toByte(), 255.toByte(), 255.toByte(), 0)).by(4, 0x01, 0, 1).bytes()
        assertEquals(listOf(BLACK, WHITE, BLACK, WHITE), Metafile.dib(raw, 0, raw.size, 0, 0)!!.argb.toList())
    }
    @Test fun rle4Absolute() {
        val raw = dibHeader(3, 1, 4, 2, 2).b(byteArrayOf(0, 0, 0, 0, 255.toByte(), 255.toByte(), 255.toByte(), 0)).by(0, 3, 0x10, 0x10, 0, 1).bytes()
        assertEquals(listOf(WHITE, BLACK, WHITE), Metafile.dib(raw, 0, raw.size, 0, 0)!!.argb.toList())
    }
    @Test fun rleRejectsTopDownAndWrongDepth() {
        assertNull(Metafile.dib(dibHeader(2, -2, 8, 2, 1).b(ByteArray(16)).bytes(), 0, 56, 0, 0))
        assertNull(Metafile.dib(dibHeader(2, 2, 24, 0, 1).b(ByteArray(16)).bytes(), 0, 56, 0, 0))
    }
    @Test fun rleGarbageNeverThrows() { val r = Random(9); repeat(300) { val raw = dibHeader(r.nextInt(1, 40), r.nextInt(1, 40), if (r.nextBoolean()) 8 else 4, 4, if (r.nextBoolean()) 1 else 2).b(ByteArray(r.nextInt(0, 200)) { r.nextInt().toByte() }).bytes(); Metafile.dib(raw, 0, raw.size, 0, 0) } }

    // ---------------- kırpma ve DC kaydet/geri yükle
    @Test fun clipRectInsideSaveRestore() {
        val m = parse(emf(intArrayOf(0, 0, 99, 99), rec(33), rec(30, 10, 10, 50, 40), rec(43, 0, 0, 100, 100), rec(34, -1)))
        assertEquals(listOf("Save", "Clip", "Poly", "Restore"), m.ops.map { it::class.simpleName })
        val c = m.ops.filterIsInstance<Metafile.Clip>().single(); assertFalse(c.exclude); assertEquals(listOf(10.0, 10.0, 50.0, 10.0, 50.0, 40.0, 10.0, 40.0), c.subs[0].pts.toList())
    }
    @Test fun excludeClipRect() { val m = parse(emf(intArrayOf(0, 0, 99, 99), rec(29, 10, 10, 20, 20), rec(43, 0, 0, 5, 5))); assertTrue(m.ops.filterIsInstance<Metafile.Clip>().single().exclude) }
    @Test fun clipRectUsesMapping() {
        val m = parse(emf(intArrayOf(0, 0, 199, 199), rec(17, 8), rec(9, 100, 100), rec(11, 200, 200), rec(30, 10, 10, 20, 20), rec(43, 0, 0, 1, 1)))
        assertEquals(listOf(20.0, 20.0, 40.0, 20.0, 40.0, 40.0, 20.0, 40.0), m.ops.filterIsInstance<Metafile.Clip>().single().subs[0].pts.toList())
    }
    @Test fun selectClipPath() {
        val m = parse(emf(intArrayOf(0, 0, 99, 99), rec(59), rec(27, 0, 0), rec(54, 50, 0), rec(54, 50, 50), rec(61), rec(60), rec(67, 1), rec(43, 0, 0, 5, 5)))
        val c = m.ops.filterIsInstance<Metafile.Clip>().single(); assertTrue(c.subs[0].closed); assertFalse(c.exclude)
        assertEquals(1, polys(m).size)   // yol çizilmez, yalnız kırpma olur
    }
    @Test fun selectClipPathDiffIsExclude() { val m = parse(emf(intArrayOf(0, 0, 99, 99), rec(59), rec(27, 0, 0), rec(54, 50, 0), rec(54, 50, 50), rec(61), rec(60), rec(67, 4), rec(43, 0, 0, 5, 5))); assertTrue(m.ops.filterIsInstance<Metafile.Clip>().single().exclude) }
    @Test fun extSelectClipRgnRects() {
        val rgn = W().i(32).i(1).i(2).i(32).i(0).i(0).i(100).i(100).i(0).i(0).i(10).i(10).i(20).i(0).i(30).i(5).bytes()
        val m = parse(emf(intArrayOf(0, 0, 99, 99), recBytes(75, W().i(rgn.size).i(1).b(rgn).bytes()), rec(43, 0, 0, 5, 5)))
        val c = m.ops.filterIsInstance<Metafile.Clip>().single(); assertEquals(2, c.subs.size); assertEquals(listOf(0.0, 0.0, 10.0, 0.0, 10.0, 10.0, 0.0, 10.0), c.subs[0].pts.toList())
    }
    @Test fun restoreWithoutSaveIsHarmless() { val m = parse(emf(intArrayOf(0, 0, 99, 99), rec(34, -3), rec(43, 0, 0, 5, 5))); assertEquals(1, m.ops.size) }
    @Test fun clipOnlyFileIsNull() { assertNull(Metafile.parse(emf(intArrayOf(0, 0, 99, 99), rec(30, 0, 0, 5, 5)))) }

    // ---------------- fırçalar
    @Test fun hatchBrushHorizontal() {
        val m = parse(emf(intArrayOf(0, 0, 99, 99), rec(39, 1, 2, 0x0000FF, 0), rec(37, 1), rec(43, 0, 0, 40, 40)))
        val t = polys(m).single().shade as Metafile.Tile; assertEquals(8, t.w); assertEquals(RED, t.argb[3 * 8 + 5]); assertEquals(0, t.argb[0]); assertEquals(RED, polys(m).single().fill)
    }
    @Test fun hatchBrushDiagonals() {
        fun tile(h: Int) = (polys(parse(emf(intArrayOf(0, 0, 99, 99), rec(39, 1, 2, 0x0000FF, h), rec(37, 1), rec(43, 0, 0, 40, 40)))).single().shade as Metafile.Tile)
        assertEquals(RED, tile(2).argb[0]); assertEquals(RED, tile(3).argb[7]); assertEquals(RED, tile(1).argb[3]); assertEquals(RED, tile(4).argb[3]); assertEquals(RED, tile(5).argb[0]); assertEquals(RED, tile(5).argb[7])
    }
    @Test fun dibPatternBrush() {
        val dib = dibHeader(2, 2, 24).b(byteArrayOf(0, 0, 255.toByte(), 0, 255.toByte(), 0, 0, 0)).b(byteArrayOf(255.toByte(), 0, 0, 255.toByte(), 255.toByte(), 255.toByte(), 0, 0)).bytes()
        val body = W().i(94).i(32 + dib.size).i(1).i(0).i(32).i(40).i(72).i(dib.size - 40).b(dib).bytes()
        val m = parse(emf(intArrayOf(0, 0, 99, 99), body, rec(37, 1), rec(43, 0, 0, 40, 40)))
        val t = polys(m).single().shade as Metafile.Tile; assertEquals(2, t.w); assertEquals(2, t.h)
        assertEquals(listOf(BLUE, WHITE, RED, GREEN), t.argb.toList())    // alt satır önce saklanır
    }
    @Test fun monoBrushUsesPalette() {
        val dib = dibHeader(8, 1, 1, 2).b(byteArrayOf(0, 0, 0, 0, 255.toByte(), 255.toByte(), 255.toByte(), 0)).b(byteArrayOf(0xF0.toByte(), 0, 0, 0)).bytes()
        val body = W().i(93).i(32 + dib.size).i(1).i(0).i(32).i(48).i(80).i(4).b(dib).bytes()
        val t = polys(parse(emf(intArrayOf(0, 0, 99, 99), body, rec(37, 1), rec(43, 0, 0, 40, 40)))).single().shade as Metafile.Tile
        assertEquals(listOf(WHITE, WHITE, WHITE, WHITE, BLACK, BLACK, BLACK, BLACK), t.argb.toList())
    }
    @Test fun solidBrushHasNoShade() { assertNull(polys(parse(emf(intArrayOf(0, 0, 99, 99), rec(39, 1, 0, 0x00FF00, 0), rec(37, 1), rec(43, 0, 0, 5, 5)))).single().shade) }
    @Test fun gradientFillRectHorizontalAndVertical() {
        fun rect(mode: Int): ByteArray {
            val v = W().i(10).i(20).s(0xFFFF).s(0).s(0).s(0xFF00).i(110).i(120).s(0).s(0).s(0xFFFF).s(0xFF00).bytes()    // v0 kırmızı, v1 mavi (16-bit kanal)
            val body = W().i(0).i(0).i(100).i(100).i(2).i(1).i(mode).b(v).i(0).i(1).bytes()
            return recBytes(118, body)
        }
        val h = polys(parse(emf(intArrayOf(0, 0, 199, 199), rect(0)))).single().shade as Metafile.Linear
        assertEquals(10.0, h.x0, 1e-9); assertEquals(20.0, h.y0, 1e-9); assertEquals(110.0, h.x1, 1e-9); assertEquals(20.0, h.y1, 1e-9); assertEquals(RED, h.colors[0]); assertEquals(BLUE, h.colors[1])
        val v = polys(parse(emf(intArrayOf(0, 0, 199, 199), rect(1)))).single().shade as Metafile.Linear
        assertEquals(10.0, v.x0, 1e-9); assertEquals(20.0, v.y0, 1e-9); assertEquals(10.0, v.x1, 1e-9); assertEquals(120.0, v.y1, 1e-9)
    }
    @Test fun gradientTriangleAveragesColours() {
        val v = W().i(0).i(0).s(0xFFFF).s(0).s(0).s(0xFF00).i(50).i(0).s(0).s(0xFFFF).s(0).s(0xFF00).i(0).i(50).s(0).s(0).s(0xFFFF).s(0xFF00).bytes()
        val m = parse(emf(intArrayOf(0, 0, 99, 99), recBytes(118, W().i(0).i(0).i(50).i(50).i(3).i(1).i(2).b(v).i(0).i(1).i(2).bytes())))
        val p = polys(m).single(); assertEquals(3, p.subs[0].pts.size / 2); assertEquals(0xFF555555.toInt(), p.fill)
    }
    @Test fun dashedPenStyles() { for (st in 1..4) assertEquals(st, polys(parse(emf(intArrayOf(0, 0, 99, 99), rec(38, 1, st, 1, 0, 0x0000FF), rec(37, 1), rec(43, 0, 0, 5, 5)))).single().dash) }
    @Test fun solidPenHasNoDash() { assertEquals(0, polys(parse(emf(intArrayOf(0, 0, 99, 99), rec(38, 1, 0, 1, 0, 0), rec(37, 1), rec(43, 0, 0, 5, 5)))).single().dash) }

    // ---------------- WMF
    private fun wrec(fn: Int, vararg p: Int): ByteArray { val w = W().i(3 + p.size).s(fn); p.forEach { w.s(it) }; return w.bytes() }
    private fun wmf(vararg recs: ByteArray): ByteArray { val w = W(); w.s(1).s(9).s(0x300).i(0).s(0).i(0).s(0); for (r in recs) w.b(r); w.b(wrec(0)); return w.bytes() }
    @Test fun wmfClipAndSaveRestore() {
        val m = parse(wmf(wrec(0x020C, 100, 100), wrec(0x020B, 0, 0), wrec(0x001E), wrec(0x0416, 40, 50, 10, 20), wrec(0x041B, 90, 90, 0, 0), wrec(0x0127, -1 and 0xFFFF)))
        assertEquals(listOf("Save", "Clip", "Poly", "Restore"), m.ops.map { it::class.simpleName })
        assertEquals(listOf(20.0, 10.0, 50.0, 10.0, 50.0, 40.0, 20.0, 40.0), m.ops.filterIsInstance<Metafile.Clip>().single().subs[0].pts.toList())
    }
    @Test fun wmfRestoreBringsBackBrush() {
        val m = parse(wmf(wrec(0x020C, 100, 100), wrec(0x020B, 0, 0), W().i(5 + 2).s(0x02FC).s(0).i(0x0000FF).s(0).bytes(), wrec(0x001E), wrec(0x012D, 0), wrec(0x041B, 9, 9, 1, 1), wrec(0x0127, -1 and 0xFFFF), wrec(0x041B, 20, 20, 10, 10)))
        val ps = polys(m); assertEquals(RED, ps[0].fill); assertEquals(WHITE, ps[1].fill)
    }
    @Test fun wmfHatchBrush() {
        val m = parse(wmf(wrec(0x020C, 100, 100), wrec(0x020B, 0, 0), W().i(5 + 2).s(0x02FC).s(2).i(0x0000FF).s(1).bytes(), wrec(0x012D, 0), wrec(0x041B, 9, 9, 1, 1)))
        val t = polys(m).single().shade as Metafile.Tile; assertEquals(RED, t.argb[3])
    }
    @Test fun wmfDibPatternBrush() {
        val dib = dibHeader(1, 1, 24).b(byteArrayOf(0, 0, 255.toByte(), 0)).bytes()
        val body = W().s(0).s(0).b(dib).bytes()
        val r = W().i(3 + body.size / 2).s(0x0142).b(body).bytes()
        val m = parse(wmf(wrec(0x020C, 100, 100), wrec(0x020B, 0, 0), r, wrec(0x012D, 0), wrec(0x041B, 9, 9, 1, 1)))
        assertEquals(RED, (polys(m).single().shade as Metafile.Tile).argb[0])
    }

    // ---------------- EMF+
    private val PV = 0xDBC01002.toInt()
    private fun prec(type: Int, flags: Int, data: ByteArray): ByteArray { val pad = (4 - data.size % 4) % 4; return W().s(type).s(flags).i(12 + data.size + pad).i(data.size + pad).b(data).b(ByteArray(pad)).bytes() }
    private fun plusHeader(dual: Boolean) = prec(0x4001, if (dual) 1 else 0, W().i(PV).i(if (dual) 1 else 0).i(96).i(96).bytes())
    private fun comment(vararg recs: ByteArray): ByteArray { val r = ByteArrayOutputStream(); recs.forEach { r.write(it) }; val rb = r.toByteArray(); return recBytes(70, W().i(4 + rb.size).b("EMF+".toByteArray()).b(rb).bytes()) }
    private fun plus(vararg recs: ByteArray, dual: Boolean = false) = emf(intArrayOf(0, 0, 199, 199), comment(plusHeader(dual), *recs))
    private fun solidBrushObj(id: Int, argb: Int) = prec(0x4008, (1 shl 8) or id, W().i(PV).i(0).i(argb).bytes())
    private fun penObj(id: Int, width: Float, argb: Int, flags: Int = 0, vararg extra: Int) = prec(0x4008, (2 shl 8) or id, W().i(PV).i(0).i(flags).i(0).f(width).also { w -> extra.forEach { w.i(it) } }.i(PV).i(0).i(argb).bytes())
    private fun rectF(x: Float, y: Float, w: Float, h: Float) = W().f(x).f(y).f(w).f(h).bytes()
    private val A_RED = 0xFFFF0000.toInt(); private val A_GREEN = 0xFF00FF00.toInt(); private val A_BLUE = 0xFF0000FF.toInt()

    @Test fun plusOnlyFillRectsSolidColour() {
        val m = parse(plus(prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(10f, 20f, 30f, 40f)).bytes())))
        val p = polys(m).single(); assertEquals(A_RED, p.fill); assertEquals(listOf(10.0, 20.0, 40.0, 20.0, 40.0, 60.0, 10.0, 60.0), p.subs[0].pts.toList())
    }
    @Test fun plusFillRectsCompressedAndBrushObject() {
        val m = parse(plus(solidBrushObj(3, A_GREEN), prec(0x400A, 0x4000, W().i(3).i(2).b(W().s(1).s(2).s(10).s(20).bytes()).b(W().s(50).s(60).s(5).s(5).bytes()).bytes())))
        val p = polys(m).single(); assertEquals(A_GREEN, p.fill); assertEquals(2, p.subs.size); assertEquals(listOf(1.0, 2.0, 11.0, 2.0, 11.0, 22.0, 1.0, 22.0), p.subs[0].pts.toList())
    }
    @Test fun plusDrawRectsUsesPenWidthAndColour() {
        val m = parse(plus(penObj(1, 4f, A_BLUE), prec(0x400B, 1, W().i(1).b(rectF(0f, 0f, 50f, 50f)).bytes())))
        val p = polys(m).single(); assertEquals(A_BLUE, p.stroke); assertEquals(4.0, p.sw, 1e-6); assertNull(p.fill)
    }
    @Test fun plusPenDashAndOptionalFieldsAreSkipped() {
        // PenDataFlags: StartCap(0x2) + LineStyle(0x20)
        val m = parse(plus(penObj(0, 2f, A_RED, 0x22, 0, 2), prec(0x400B, 0, W().i(1).b(rectF(0f, 0f, 9f, 9f)).bytes())))
        val p = polys(m).single(); assertEquals(2, p.dash); assertEquals(A_RED, p.stroke)
    }
    @Test fun plusFillPolygonAndDrawLinesClosed() {
        val pts = W().f(0f).f(0f).f(10f).f(0f).f(10f).f(10f).bytes()
        val m = parse(plus(penObj(0, 1f, A_BLUE), prec(0x400C, 0x8000, W().i(A_GREEN).i(3).b(pts).bytes()), prec(0x400D, 0x2000, W().i(3).b(pts).bytes())))
        val ps = polys(m); assertEquals(A_GREEN, ps[0].fill); assertTrue(ps[0].subs[0].closed); assertTrue(ps[1].subs[0].closed); assertEquals(A_BLUE, ps[1].stroke)
    }
    @Test fun plusDrawLinesOpenAndCompressed() {
        val m = parse(plus(penObj(0, 1f, A_BLUE), prec(0x400D, 0x4000, W().i(2).s(1).s(2).s(30).s(40).bytes())))
        val s = polys(m).single().subs[0]; assertFalse(s.closed); assertEquals(listOf(1.0, 2.0, 30.0, 40.0), s.pts.toList())
    }
    @Test fun plusEllipsePieArc() {
        val m = parse(plus(penObj(0, 1f, A_BLUE),
            prec(0x400E, 0x8000, W().i(A_RED).b(rectF(0f, 0f, 40f, 20f)).bytes()),
            prec(0x4010, 0x8000, W().i(A_GREEN).f(0f).f(90f).b(rectF(0f, 0f, 40f, 40f)).bytes()),
            prec(0x4012, 0, W().f(0f).f(90f).b(rectF(0f, 0f, 40f, 40f)).bytes())))
        val ps = polys(m); assertEquals(3, ps.size)
        val e = ps[0].subs[0].pts; var i = 0; while (i < e.size) { assertTrue(e[i] in -0.01..40.01 && e[i + 1] in -0.01..20.01); i += 2 }
        val pie = ps[1].subs[0].pts; assertEquals(20.0, pie[0], 1e-9); assertEquals(20.0, pie[1], 1e-9)         // merkez
        assertEquals(40.0, pie[2], 1e-6); assertEquals(20.0, pie[3], 1e-6)                                           // 0° = sağ
        assertEquals(20.0, pie[pie.size - 2], 1e-6); assertEquals(40.0, pie[pie.size - 1], 1e-6)                    // +90° saat yönünde = aşağı (y aşağı)
        assertFalse(ps[2].subs[0].closed)
    }
    private fun pathObj(id: Int, pts: DoubleArray, types: IntArray, compressed: Boolean = false): ByteArray {
        val w = W().i(PV).i(types.size).i(if (compressed) 0x4000 else 0)
        for (v in pts) if (compressed) w.s(v.toInt()) else w.f(v.toFloat())
        types.forEach { w.by(it) }
        return prec(0x4008, (3 shl 8) or id, w.bytes())
    }
    @Test fun plusPathFillAndStroke() {
        val path = pathObj(2, doubleArrayOf(0.0, 0.0, 50.0, 0.0, 50.0, 50.0), intArrayOf(0, 1, 0x81))
        val m = parse(plus(penObj(0, 1f, A_BLUE), path, prec(0x4014, 2 or 0x8000, W().i(A_GREEN).bytes()), prec(0x4015, 2, W().i(0).bytes())))
        val ps = polys(m); assertEquals(A_GREEN, ps[0].fill); assertTrue(ps[0].subs[0].closed); assertEquals(A_BLUE, ps[1].stroke); assertEquals(6, ps[1].subs[0].pts.size)
    }
    @Test fun plusPathBezierAndSubpaths() {
        val path = pathObj(0, doubleArrayOf(0.0, 0.0, 10.0, 40.0, 30.0, 40.0, 40.0, 0.0, 60.0, 60.0, 70.0, 70.0), intArrayOf(0, 3, 3, 3, 0, 1), compressed = true)
        val m = parse(plus(penObj(1, 1f, A_BLUE), path, prec(0x4015, 0, W().i(1).bytes())))
        val s = polys(m).single().subs; assertEquals(2, s.size); assertTrue(s[0].pts.size > 20); assertEquals(40.0, s[0].pts[s[0].pts.size - 2], 1e-9); assertEquals(listOf(60.0, 60.0, 70.0, 70.0), s[1].pts.toList())
    }
    @Test fun plusBeziersAndCurves() {
        val pts = W().f(0f).f(0f).f(10f).f(30f).f(30f).f(30f).f(40f).f(0f).bytes()
        val m = parse(plus(penObj(0, 1f, A_BLUE), prec(0x4019, 0, W().i(4).b(pts).bytes()), prec(0x4018, 0, W().f(0.5f).i(0).i(3).i(4).b(pts).bytes()), prec(0x4017, 0, W().f(0.5f).i(4).b(pts).bytes()), prec(0x4016, 0x8000, W().i(A_RED).f(0.5f).i(4).b(pts).bytes())))
        val ps = polys(m); assertEquals(4, ps.size); assertTrue(ps[0].subs[0].pts.size > 20); assertEquals(40.0, ps[0].subs[0].pts[ps[0].subs[0].pts.size - 2], 1e-9)
        assertEquals(0.0, ps[1].subs[0].pts[0], 1e-9); assertEquals(40.0, ps[1].subs[0].pts[ps[1].subs[0].pts.size - 2], 1e-9); assertTrue(ps[2].subs[0].closed); assertEquals(A_RED, ps[3].fill)
    }
    @Test fun plusWorldTransformOrdering() {
        // Translate(10,0) ardından Scale(2,2) — prepend: yeni önce uygulanır → (x*2)+10 değil (x+..)
        val translate = prec(0x402D, 0, W().f(10f).f(0f).bytes()); val scale = prec(0x402E, 0, W().f(2f).f(2f).bytes())
        val rect = prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(1f, 1f, 1f, 1f)).bytes())
        val pre = polys(parse(plus(translate, scale, rect))).single().subs[0].pts      // dünya = scale × translate: p → (2p) + 10
        assertEquals(12.0, pre[0], 1e-6); assertEquals(2.0, pre[1], 1e-6)
        val scaleA = prec(0x402E, 0x2000, W().f(2f).f(2f).bytes())
        val app = polys(parse(plus(translate, scaleA, rect))).single().subs[0].pts     // append: (p + 10) * 2
        assertEquals(22.0, app[0], 1e-6); assertEquals(2.0, app[1], 1e-6)
    }
    @Test fun plusSetAndResetWorldTransform() {
        val set = prec(0x402A, 0, W().f(1f).f(0f).f(0f).f(1f).f(5f).f(7f).bytes())
        val rect = prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(0f, 0f, 1f, 1f)).bytes())
        val ps = polys(parse(plus(set, rect, prec(0x402B, 0, ByteArray(0)), rect)))
        assertEquals(5.0, ps[0].subs[0].pts[0], 1e-9); assertEquals(7.0, ps[0].subs[0].pts[1], 1e-9); assertEquals(0.0, ps[1].subs[0].pts[0], 1e-9)
    }
    @Test fun plusPageUnitScalesToDevice() {
        val m = polys(parse(plus(prec(0x4030, 4, W().f(1f).bytes()), prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(1f, 0f, 1f, 1f)).bytes())))).single().subs[0].pts
        assertEquals(96.0, m[0], 1e-6)   // 1 inç = 96 piksel
    }
    @Test fun plusSaveRestoreRestoresTransform() {
        val tr = prec(0x402D, 0, W().f(100f).f(0f).bytes()); val rect = prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(0f, 0f, 1f, 1f)).bytes())
        val m = parse(plus(prec(0x4025, 0, W().i(7).bytes()), tr, rect, prec(0x4026, 0, W().i(7).bytes()), rect))
        val ps = polys(m); assertEquals(100.0, ps[0].subs[0].pts[0], 1e-9); assertEquals(0.0, ps[1].subs[0].pts[0], 1e-9)
        assertEquals(listOf("Save", "Poly", "Restore", "Poly"), m.ops.map { it::class.simpleName })
    }
    @Test fun plusClipRectAndPath() {
        val m = parse(plus(prec(0x4025, 0, W().i(1).bytes()), prec(0x4032, 0x0100, rectF(5f, 5f, 20f, 20f)), prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(0f, 0f, 99f, 99f)).bytes()), prec(0x4026, 0, W().i(1).bytes())))
        assertEquals(listOf("Save", "Clip", "Poly", "Restore"), m.ops.map { it::class.simpleName })
        assertEquals(listOf(5.0, 5.0, 25.0, 5.0, 25.0, 25.0, 5.0, 25.0), m.ops.filterIsInstance<Metafile.Clip>().single().subs[0].pts.toList())
        val ex = parse(plus(prec(0x4032, 0x0400, rectF(5f, 5f, 20f, 20f)), prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(0f, 0f, 99f, 99f)).bytes())))
        assertTrue(ex.ops.filterIsInstance<Metafile.Clip>().single().exclude)
        val pa = pathObj(4, doubleArrayOf(0.0, 0.0, 9.0, 0.0, 9.0, 9.0), intArrayOf(0, 1, 0x81))
        val cp = parse(plus(pa, prec(0x4033, 0x0100 or 4, ByteArray(0)), prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(0f, 0f, 99f, 99f)).bytes())))
        assertEquals(1, cp.ops.filterIsInstance<Metafile.Clip>().size)
    }
    @Test fun plusLinearGradientBrush() {
        val obj = prec(0x4008, (1 shl 8) or 5, W().i(PV).i(4).i(0).i(0).f(10f).f(20f).f(100f).f(50f).i(A_RED).i(A_BLUE).i(0).i(0).bytes())
        val m = parse(plus(obj, prec(0x400A, 0, W().i(5).i(1).b(rectF(10f, 20f, 100f, 50f)).bytes())))
        val l = polys(m).single().shade as Metafile.Linear
        assertEquals(10.0, l.x0, 1e-6); assertEquals(45.0, l.y0, 1e-6); assertEquals(110.0, l.x1, 1e-6); assertEquals(45.0, l.y1, 1e-6); assertEquals(A_RED, l.colors[0]); assertEquals(A_BLUE, l.colors[1])
    }
    @Test fun plusLinearGradientPresetColorsAndTransform() {
        val mat = W().f(0f).f(1f).f(-1f).f(0f).f(0f).f(0f).bytes()      // 90° döndürme
        val pre = W().i(3).f(0f).f(0.5f).f(1f).i(A_RED).i(A_GREEN).i(A_BLUE).bytes()
        val obj = prec(0x4008, (1 shl 8) or 5, W().i(PV).i(4).i(0x2 or 0x4).i(0).f(0f).f(0f).f(10f).f(10f).i(A_RED).i(A_BLUE).i(0).i(0).b(mat).b(pre).bytes())
        val l = polys(parse(plus(obj, prec(0x400A, 0, W().i(5).i(1).b(rectF(0f, 0f, 10f, 10f)).bytes())))).single().shade as Metafile.Linear
        assertEquals(3, l.colors.size); assertEquals(0.5, l.pos[1], 1e-6); assertEquals(A_GREEN, l.colors[1])
        assertEquals(-5.0, l.x0, 1e-6); assertEquals(0.0, l.y0, 1e-6); assertEquals(-5.0, l.x1, 1e-6); assertEquals(10.0, l.y1, 1e-6)
    }
    @Test fun plusHatchBrush() {
        val obj = prec(0x4008, (1 shl 8) or 2, W().i(PV).i(1).i(0).i(A_RED).i(A_BLUE).bytes())
        val t = polys(parse(plus(obj, prec(0x400A, 0, W().i(2).i(1).b(rectF(0f, 0f, 9f, 9f)).bytes())))).single().shade as Metafile.Tile
        assertEquals(A_RED, t.argb[3 * 8]); assertEquals(A_BLUE, t.argb[0])
    }
    @Test fun plusDrawString() {
        val s = "Merhaba İ"
        val font = prec(0x4008, (6 shl 8) or 1, W().i(PV).f(20f).i(2).i(1).i(0).i(3).b("Ari".toByteArray(Charsets.UTF_16LE)).bytes())
        val draw = prec(0x401C, 0x8001, W().i(A_RED).i(-1).i(s.length).b(rectF(15f, 25f, 100f, 30f)).b(s.toByteArray(Charsets.UTF_16LE)).bytes())
        val t = parse(plus(font, draw)).ops.filterIsInstance<Metafile.Text>().single()
        assertEquals(s, t.s); assertEquals(15.0, t.x, 1e-6); assertEquals(25.0, t.y, 1e-6); assertEquals(20.0, t.size, 1e-6); assertTrue(t.bold); assertFalse(t.italic); assertEquals(A_RED, t.color)
    }
    @Test fun plusFontPointsUnitScalesByDpi() {
        val font = prec(0x4008, (6 shl 8) or 0, W().i(PV).f(12f).i(3).i(0).i(0).i(1).b("A".toByteArray(Charsets.UTF_16LE)).bytes())
        val draw = prec(0x401C, 0x8000, W().i(A_RED).i(-1).i(1).b(rectF(0f, 0f, 10f, 10f)).b("A".toByteArray(Charsets.UTF_16LE)).bytes())
        assertEquals(16.0, parse(plus(font, draw)).ops.filterIsInstance<Metafile.Text>().single().size, 1e-6)    // 12 pt @ 96 dpi
    }
    private fun bitmapObj(id: Int, w: Int, h: Int, pf: Int, px: ByteArray, stride: Int) = prec(0x4008, (5 shl 8) or id, W().i(PV).i(1).i(w).i(h).i(stride).i(pf).i(0).b(px).bytes())
    @Test fun plusDrawImagePixels() {
        val px = W().i(0xFF102030.toInt()).i(0x80FFFFFF.toInt()).i(0xFF000000.toInt()).i(0xFFAABBCC.toInt()).bytes()       // 2x2 ARGB
        val obj = bitmapObj(0, 2, 2, 0x0026200A, px, 8)
        val m = parse(plus(obj, prec(0x401A, 0, W().i(0).i(2).b(rectF(0f, 0f, 2f, 2f)).b(rectF(10f, 10f, 40f, 40f)).bytes())))
        val b = m.ops.filterIsInstance<Metafile.Bmp>().single(); assertEquals(2, b.pw); assertEquals(0xFF102030.toInt(), b.argb[0]); assertEquals(0x80FFFFFF.toInt(), b.argb[1]); assertEquals(10.0, b.x, 1e-9); assertEquals(40.0, b.w, 1e-9)
    }
    @Test fun plusDrawImageSourceRectCrops() {
        val px = W().i(1 or 0xFF000000.toInt()).i(2 or 0xFF000000.toInt()).i(3 or 0xFF000000.toInt()).i(4 or 0xFF000000.toInt()).bytes()
        val obj = bitmapObj(0, 2, 2, 0x0026200A, px, 8)
        val b = parse(plus(obj, prec(0x401A, 0, W().i(0).i(2).b(rectF(1f, 0f, 1f, 2f)).b(rectF(0f, 0f, 9f, 9f)).bytes()))).ops.filterIsInstance<Metafile.Bmp>().single()
        assertEquals(1, b.pw); assertEquals(2, b.ph); assertEquals(listOf(2 or 0xFF000000.toInt(), 4 or 0xFF000000.toInt()), b.argb.toList())
    }
    @Test fun plusRgb24AndPremultiplied() {
        val px = byteArrayOf(0x30, 0x20, 0x10, 0, 0, 0)
        val b24 = parse(plus(bitmapObj(0, 1, 1, 0x00021808, px, 4), prec(0x401A, 0, W().i(0).i(2).b(rectF(0f, 0f, 1f, 1f)).b(rectF(0f, 0f, 9f, 9f)).bytes()))).ops.filterIsInstance<Metafile.Bmp>().single()
        assertEquals(0xFF102030.toInt(), b24.argb[0])
        val pm = parse(plus(bitmapObj(0, 1, 1, 0x000E200B, W().i(0x80404040.toInt()).bytes(), 4), prec(0x401A, 0, W().i(0).i(2).b(rectF(0f, 0f, 1f, 1f)).b(rectF(0f, 0f, 9f, 9f)).bytes()))).ops.filterIsInstance<Metafile.Bmp>().single()
        assertEquals(0x807F7F7F.toInt(), pm.argb[0])
    }
    @Test fun plusCompressedImageKeepsBytes() {
        val png = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 1, 2, 3, 4, 5, 6, 7, 8)
        val obj = prec(0x4008, (5 shl 8) or 0, W().i(PV).i(1).i(4).i(4).i(0).i(0x0026200A).i(1).b(png).bytes())
        val m = parse(plus(obj, prec(0x401A, 0, W().i(0).i(2).b(rectF(0f, 0f, 4f, 4f)).b(rectF(3f, 4f, 50f, 60f)).bytes())))
        val im = m.ops.filterIsInstance<Metafile.Img>().single(); assertEquals(3.0, im.x, 1e-9); assertEquals(60.0, im.h, 1e-9); assertTrue(im.data.size >= png.size && im.data[0] == 0x89.toByte())
    }
    @Test fun plusDrawImagePointsParallelogramBox() {
        val px = W().i(0xFF000000.toInt()).bytes()
        val pts = W().f(10f).f(10f).f(50f).f(10f).f(10f).f(30f).bytes()
        val m = parse(plus(bitmapObj(0, 1, 1, 0x0026200A, px, 4), prec(0x401B, 0, W().i(0).i(2).b(rectF(0f, 0f, 1f, 1f)).i(3).b(pts).bytes())))
        val b = m.ops.filterIsInstance<Metafile.Bmp>().single(); assertEquals(10.0, b.x, 1e-9); assertEquals(40.0, b.w, 1e-9); assertEquals(20.0, b.h, 1e-9)
    }
    @Test fun plusContinuedObjectIsReassembled() {
        val path = pathObj(2, doubleArrayOf(0.0, 0.0, 50.0, 0.0, 50.0, 50.0), intArrayOf(0, 1, 0x81))
        val data = path.copyOfRange(12, path.size)           // nesne verisi (üstbilgisiz)
        val half = 16
        val first = prec(0x4008, 0x8000 or (3 shl 8) or 2, W().i(data.size).b(data.copyOfRange(0, half)).bytes())
        val second = prec(0x4008, 0x8000 or (3 shl 8) or 2, data.copyOfRange(half, data.size))
        val m = parse(plus(first, second, prec(0x4014, 2 or 0x8000, W().i(A_GREEN).bytes())))
        assertEquals(A_GREEN, polys(m).single().fill)
    }
    @Test fun dualFileUsesEmfRecordsOnly() {
        val m = parse(plus(prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(0f, 0f, 50f, 50f)).bytes()), dual = true).let { raw -> emf(intArrayOf(0, 0, 199, 199), comment(plusHeader(true), prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(0f, 0f, 50f, 50f)).bytes())), rec(43, 0, 0, 10, 10)) })
        assertEquals(1, polys(m).size); assertEquals(listOf(0.0, 0.0, 10.0, 0.0, 10.0, 10.0, 0.0, 10.0), polys(m)[0].subs[0].pts.toList())
    }
    @Test fun plusOnlyIgnoresEmfFallbackRecords() {
        val m = parse(emf(intArrayOf(0, 0, 199, 199), comment(plusHeader(false), prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(0f, 0f, 50f, 50f)).bytes())), rec(43, 0, 0, 10, 10)))
        assertEquals(1, polys(m).size); assertEquals(A_RED, polys(m)[0].fill)
    }
    @Test fun plusRecordsSplitAcrossComments() {
        val m = parse(emf(intArrayOf(0, 0, 199, 199), comment(plusHeader(false), penObj(1, 2f, A_BLUE)), comment(prec(0x400B, 1, W().i(1).b(rectF(0f, 0f, 9f, 9f)).bytes()))))
        assertEquals(A_BLUE, polys(m).single().stroke)
    }
    @Test fun plusUnknownRecordsAndMissingObjectsAreIgnored() {
        val m = parse(plus(prec(0x7777, 0, ByteArray(8)), prec(0x400B, 9, W().i(1).b(rectF(0f, 0f, 9f, 9f)).bytes()), prec(0x4014, 7, W().i(3).bytes()), prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(0f, 0f, 5f, 5f)).bytes())))
        assertEquals(1, polys(m).size)
    }
    @Test fun plusOnlyWithoutDrawingIsNull() { assertNull(Metafile.parse(plus())) }
    @Test fun plusFuzzNeverThrows() {
        val good = plus(solidBrushObj(3, A_GREEN), penObj(1, 4f, A_BLUE), pathObj(2, doubleArrayOf(0.0, 0.0, 50.0, 0.0, 50.0, 50.0), intArrayOf(0, 1, 0x81)), prec(0x4014, 2 or 0x8000, W().i(A_GREEN).bytes()), prec(0x400A, 0x8000, W().i(A_RED).i(1).b(rectF(10f, 20f, 30f, 40f)).bytes()),
            prec(0x4008, (1 shl 8) or 5, W().i(PV).i(4).i(0x6).i(0).f(10f).f(20f).f(100f).f(50f).i(A_RED).i(A_BLUE).i(0).i(0).bytes()), bitmapObj(0, 1, 1, 0x0026200A, W().i(0).bytes(), 4))
        val r = Random(13)
        repeat(400) { val b = good.copyOf(); repeat(r.nextInt(1, 25)) { b[r.nextInt(b.size)] = r.nextInt().toByte() }; Metafile.parse(b) }
        repeat(100) { Metafile.parse(good.copyOf(r.nextInt(1, good.size))) }
    }

    // ---------------- LibreOffice çıktısıyla gerilemesiz
    @Test fun realLibreOfficeEmfStillParsesWithClipsAndSaves() {
        val dir = listOf(File("src/test/resources/meta"), File("app/src/test/resources/meta")).first { it.exists() }
        val m = Metafile.parse(File(dir, "s.emf").readBytes())!!
        assertTrue(m.ops.any { it is Metafile.Save }); assertTrue(m.ops.any { it is Metafile.Clip }); assertEquals(m.ops.count { it === Metafile.Save }, m.ops.count { it === Metafile.Restore })
        assertTrue(m.ops.filterIsInstance<Metafile.Text>().single().s.startsWith("Merhaba"))
    }
    @Test fun sourceChecksForRendererAndSegment() {
        val r = File(TestFiles.code, "com/odak/app/docs/MetaRender.kt").readText()
        for (k in listOf("is Metafile.Clip", "clipOutPath", "BitmapShader", "LinearGradient", "DashPathEffect", "is Metafile.Img", "is Metafile.Save", "is Metafile.Restore")) assertTrue(k, r.contains(k))
    }
}
