package com.odak.app

import com.odak.app.notes.Note
import com.odak.app.notes.NoteAudio
import com.odak.app.notes.NoteImg
import com.odak.app.notes.NotePure
import com.odak.app.notes.Pt
import com.odak.app.notes.Stroke
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.55: ek/basınç/PDF yerleşimi için üretilmiş testler (beklenen değerler Python hesabından). */
class NoteMediaGenTest {
    private fun rnd(seed: Long): Note {
        val r = java.util.Random(seed)
        val strokes = List(1 + r.nextInt(4)) { Stroke(r.nextInt(3), r.nextInt(), 1f + r.nextInt(40) / 4f, List(1 + r.nextInt(8)) { Pt(r.nextInt(10000) / 3333f, r.nextInt(30000) / 3333f, r.nextInt(101) / 100f) }) }
        val imgs = List(r.nextInt(4)) { NoteImg("i" + it + "_" + seed + ".jpg", r.nextInt(50) / 100f, r.nextInt(300) / 100f, 0.1f + r.nextInt(90) / 100f, 0.1f + r.nextInt(200) / 100f) }
        val auds = List(r.nextInt(4)) { NoteAudio("a" + it + "_" + seed + ".m4a", r.nextInt(600000).toLong(), r.nextInt(100000).toLong()) }
        return Note(id = "m" + seed, strokes = strokes, images = imgs, audios = auds, pdf = if (r.nextBoolean()) "p" + seed + ".pdf" else "")
    }
    @Test fun mediaRoundTrip_1() {
        val a = rnd(1L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_2() {
        val a = rnd(2L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_3() {
        val a = rnd(3L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_4() {
        val a = rnd(4L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_5() {
        val a = rnd(5L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_6() {
        val a = rnd(6L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_7() {
        val a = rnd(7L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_8() {
        val a = rnd(8L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_9() {
        val a = rnd(9L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_10() {
        val a = rnd(10L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_11() {
        val a = rnd(11L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_12() {
        val a = rnd(12L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_13() {
        val a = rnd(13L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_14() {
        val a = rnd(14L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_15() {
        val a = rnd(15L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_16() {
        val a = rnd(16L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_17() {
        val a = rnd(17L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_18() {
        val a = rnd(18L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_19() {
        val a = rnd(19L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_20() {
        val a = rnd(20L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_21() {
        val a = rnd(21L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_22() {
        val a = rnd(22L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_23() {
        val a = rnd(23L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_24() {
        val a = rnd(24L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_25() {
        val a = rnd(25L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_26() {
        val a = rnd(26L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_27() {
        val a = rnd(27L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_28() {
        val a = rnd(28L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_29() {
        val a = rnd(29L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_30() {
        val a = rnd(30L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_31() {
        val a = rnd(31L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_32() {
        val a = rnd(32L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_33() {
        val a = rnd(33L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_34() {
        val a = rnd(34L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_35() {
        val a = rnd(35L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_36() {
        val a = rnd(36L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_37() {
        val a = rnd(37L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_38() {
        val a = rnd(38L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_39() {
        val a = rnd(39L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_40() {
        val a = rnd(40L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_41() {
        val a = rnd(41L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_42() {
        val a = rnd(42L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_43() {
        val a = rnd(43L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_44() {
        val a = rnd(44L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_45() {
        val a = rnd(45L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_46() {
        val a = rnd(46L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_47() {
        val a = rnd(47L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_48() {
        val a = rnd(48L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_49() {
        val a = rnd(49L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_50() {
        val a = rnd(50L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_51() {
        val a = rnd(51L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_52() {
        val a = rnd(52L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_53() {
        val a = rnd(53L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_54() {
        val a = rnd(54L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_55() {
        val a = rnd(55L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_56() {
        val a = rnd(56L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_57() {
        val a = rnd(57L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_58() {
        val a = rnd(58L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_59() {
        val a = rnd(59L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_60() {
        val a = rnd(60L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_61() {
        val a = rnd(61L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_62() {
        val a = rnd(62L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_63() {
        val a = rnd(63L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_64() {
        val a = rnd(64L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_65() {
        val a = rnd(65L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_66() {
        val a = rnd(66L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_67() {
        val a = rnd(67L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_68() {
        val a = rnd(68L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_69() {
        val a = rnd(69L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_70() {
        val a = rnd(70L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_71() {
        val a = rnd(71L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_72() {
        val a = rnd(72L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_73() {
        val a = rnd(73L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_74() {
        val a = rnd(74L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_75() {
        val a = rnd(75L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_76() {
        val a = rnd(76L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_77() {
        val a = rnd(77L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_78() {
        val a = rnd(78L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_79() {
        val a = rnd(79L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_80() {
        val a = rnd(80L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_81() {
        val a = rnd(81L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_82() {
        val a = rnd(82L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_83() {
        val a = rnd(83L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_84() {
        val a = rnd(84L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_85() {
        val a = rnd(85L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_86() {
        val a = rnd(86L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_87() {
        val a = rnd(87L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_88() {
        val a = rnd(88L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_89() {
        val a = rnd(89L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_90() {
        val a = rnd(90L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_91() {
        val a = rnd(91L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_92() {
        val a = rnd(92L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_93() {
        val a = rnd(93L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_94() {
        val a = rnd(94L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_95() {
        val a = rnd(95L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_96() {
        val a = rnd(96L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_97() {
        val a = rnd(97L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_98() {
        val a = rnd(98L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_99() {
        val a = rnd(99L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_100() {
        val a = rnd(100L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_101() {
        val a = rnd(101L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_102() {
        val a = rnd(102L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_103() {
        val a = rnd(103L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_104() {
        val a = rnd(104L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_105() {
        val a = rnd(105L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_106() {
        val a = rnd(106L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_107() {
        val a = rnd(107L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_108() {
        val a = rnd(108L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_109() {
        val a = rnd(109L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_110() {
        val a = rnd(110L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_111() {
        val a = rnd(111L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_112() {
        val a = rnd(112L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_113() {
        val a = rnd(113L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_114() {
        val a = rnd(114L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_115() {
        val a = rnd(115L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_116() {
        val a = rnd(116L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_117() {
        val a = rnd(117L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_118() {
        val a = rnd(118L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_119() {
        val a = rnd(119L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_120() {
        val a = rnd(120L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_121() {
        val a = rnd(121L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_122() {
        val a = rnd(122L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_123() {
        val a = rnd(123L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_124() {
        val a = rnd(124L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_125() {
        val a = rnd(125L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_126() {
        val a = rnd(126L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_127() {
        val a = rnd(127L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_128() {
        val a = rnd(128L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_129() {
        val a = rnd(129L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_130() {
        val a = rnd(130L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_131() {
        val a = rnd(131L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_132() {
        val a = rnd(132L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_133() {
        val a = rnd(133L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_134() {
        val a = rnd(134L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_135() {
        val a = rnd(135L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_136() {
        val a = rnd(136L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_137() {
        val a = rnd(137L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_138() {
        val a = rnd(138L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_139() {
        val a = rnd(139L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_140() {
        val a = rnd(140L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_141() {
        val a = rnd(141L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_142() {
        val a = rnd(142L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_143() {
        val a = rnd(143L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_144() {
        val a = rnd(144L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_145() {
        val a = rnd(145L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_146() {
        val a = rnd(146L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_147() {
        val a = rnd(147L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_148() {
        val a = rnd(148L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_149() {
        val a = rnd(149L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_150() {
        val a = rnd(150L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_151() {
        val a = rnd(151L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_152() {
        val a = rnd(152L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_153() {
        val a = rnd(153L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_154() {
        val a = rnd(154L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_155() {
        val a = rnd(155L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_156() {
        val a = rnd(156L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_157() {
        val a = rnd(157L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_158() {
        val a = rnd(158L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_159() {
        val a = rnd(159L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_160() {
        val a = rnd(160L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_161() {
        val a = rnd(161L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_162() {
        val a = rnd(162L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_163() {
        val a = rnd(163L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_164() {
        val a = rnd(164L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_165() {
        val a = rnd(165L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_166() {
        val a = rnd(166L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_167() {
        val a = rnd(167L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_168() {
        val a = rnd(168L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_169() {
        val a = rnd(169L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_170() {
        val a = rnd(170L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_171() {
        val a = rnd(171L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_172() {
        val a = rnd(172L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_173() {
        val a = rnd(173L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_174() {
        val a = rnd(174L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_175() {
        val a = rnd(175L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_176() {
        val a = rnd(176L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_177() {
        val a = rnd(177L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_178() {
        val a = rnd(178L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_179() {
        val a = rnd(179L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_180() {
        val a = rnd(180L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_181() {
        val a = rnd(181L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_182() {
        val a = rnd(182L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_183() {
        val a = rnd(183L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_184() {
        val a = rnd(184L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_185() {
        val a = rnd(185L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_186() {
        val a = rnd(186L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_187() {
        val a = rnd(187L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_188() {
        val a = rnd(188L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_189() {
        val a = rnd(189L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_190() {
        val a = rnd(190L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_191() {
        val a = rnd(191L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_192() {
        val a = rnd(192L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_193() {
        val a = rnd(193L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_194() {
        val a = rnd(194L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_195() {
        val a = rnd(195L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_196() {
        val a = rnd(196L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_197() {
        val a = rnd(197L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_198() {
        val a = rnd(198L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_199() {
        val a = rnd(199L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_200() {
        val a = rnd(200L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_201() {
        val a = rnd(201L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_202() {
        val a = rnd(202L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_203() {
        val a = rnd(203L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_204() {
        val a = rnd(204L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_205() {
        val a = rnd(205L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_206() {
        val a = rnd(206L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_207() {
        val a = rnd(207L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_208() {
        val a = rnd(208L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_209() {
        val a = rnd(209L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_210() {
        val a = rnd(210L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_211() {
        val a = rnd(211L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_212() {
        val a = rnd(212L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_213() {
        val a = rnd(213L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_214() {
        val a = rnd(214L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_215() {
        val a = rnd(215L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_216() {
        val a = rnd(216L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_217() {
        val a = rnd(217L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_218() {
        val a = rnd(218L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_219() {
        val a = rnd(219L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_220() {
        val a = rnd(220L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_221() {
        val a = rnd(221L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_222() {
        val a = rnd(222L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_223() {
        val a = rnd(223L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_224() {
        val a = rnd(224L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_225() {
        val a = rnd(225L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_226() {
        val a = rnd(226L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_227() {
        val a = rnd(227L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_228() {
        val a = rnd(228L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_229() {
        val a = rnd(229L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_230() {
        val a = rnd(230L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_231() {
        val a = rnd(231L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_232() {
        val a = rnd(232L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_233() {
        val a = rnd(233L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_234() {
        val a = rnd(234L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_235() {
        val a = rnd(235L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_236() {
        val a = rnd(236L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_237() {
        val a = rnd(237L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_238() {
        val a = rnd(238L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_239() {
        val a = rnd(239L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_240() {
        val a = rnd(240L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_241() {
        val a = rnd(241L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_242() {
        val a = rnd(242L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_243() {
        val a = rnd(243L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_244() {
        val a = rnd(244L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_245() {
        val a = rnd(245L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_246() {
        val a = rnd(246L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_247() {
        val a = rnd(247L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_248() {
        val a = rnd(248L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_249() {
        val a = rnd(249L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_250() {
        val a = rnd(250L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_251() {
        val a = rnd(251L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_252() {
        val a = rnd(252L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_253() {
        val a = rnd(253L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_254() {
        val a = rnd(254L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_255() {
        val a = rnd(255L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_256() {
        val a = rnd(256L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_257() {
        val a = rnd(257L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_258() {
        val a = rnd(258L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_259() {
        val a = rnd(259L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_260() {
        val a = rnd(260L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_261() {
        val a = rnd(261L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_262() {
        val a = rnd(262L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_263() {
        val a = rnd(263L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_264() {
        val a = rnd(264L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_265() {
        val a = rnd(265L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_266() {
        val a = rnd(266L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_267() {
        val a = rnd(267L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_268() {
        val a = rnd(268L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_269() {
        val a = rnd(269L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_270() {
        val a = rnd(270L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_271() {
        val a = rnd(271L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_272() {
        val a = rnd(272L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_273() {
        val a = rnd(273L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_274() {
        val a = rnd(274L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_275() {
        val a = rnd(275L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_276() {
        val a = rnd(276L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_277() {
        val a = rnd(277L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_278() {
        val a = rnd(278L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_279() {
        val a = rnd(279L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_280() {
        val a = rnd(280L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_281() {
        val a = rnd(281L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_282() {
        val a = rnd(282L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_283() {
        val a = rnd(283L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_284() {
        val a = rnd(284L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_285() {
        val a = rnd(285L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_286() {
        val a = rnd(286L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_287() {
        val a = rnd(287L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_288() {
        val a = rnd(288L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_289() {
        val a = rnd(289L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_290() {
        val a = rnd(290L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_291() {
        val a = rnd(291L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_292() {
        val a = rnd(292L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_293() {
        val a = rnd(293L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_294() {
        val a = rnd(294L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_295() {
        val a = rnd(295L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_296() {
        val a = rnd(296L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_297() {
        val a = rnd(297L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_298() {
        val a = rnd(298L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_299() {
        val a = rnd(299L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun mediaRoundTrip_300() {
        val a = rnd(300L); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.pdf, b.pdf); assertEquals(a.images.size, b.images.size); assertEquals(a.audios, b.audios)
        for (i in a.images.indices) { assertEquals(a.images[i].file, b.images[i].file); assertEquals(a.images[i].x, b.images[i].x, 0.0002f); assertEquals(a.images[i].w, b.images[i].w, 0.0002f); assertEquals(a.images[i].a, b.images[i].a, 0.0002f) }
        for (i in a.strokes.indices) for (j in a.strokes[i].pts.indices) assertEquals(a.strokes[i].pts[j].p, b.strokes[i].pts[j].p, 0.0002f)
    }
    @Test fun pressW_0() { assertEquals(7.01796f, NotePure.pressW(9.32f, 0.62f), 0.0005f) }
    @Test fun pressW_1() { assertEquals(11.658339999999999f, NotePure.pressW(18.52f, 0.43f), 0.0005f) }
    @Test fun pressW_2() { assertEquals(8.169200000000002f, NotePure.pressW(10.4f, 0.67f), 0.0005f) }
    @Test fun pressW_3() { assertEquals(2.8207999999999993f, NotePure.pressW(4.1f, 0.52f), 0.0005f) }
    @Test fun pressW_4() { assertEquals(12.78f, NotePure.pressW(12.78f, 1.09f), 0.0005f) }
    @Test fun pressW_5() { assertEquals(0.9863099999999999f, NotePure.pressW(2.34f, 0.11f), 0.0005f) }
    @Test fun pressW_6() { assertEquals(2.27f, NotePure.pressW(2.27f, 1.12f), 0.0005f) }
    @Test fun pressW_7() { assertEquals(4.906999999999999f, NotePure.pressW(14.02f, -0.42f), 0.0005f) }
    @Test fun pressW_8() { assertEquals(19.65f, NotePure.pressW(19.65f, 1.43f), 0.0005f) }
    @Test fun pressW_9() { assertEquals(10.924625f, NotePure.pressW(13.25f, 0.73f), 0.0005f) }
    @Test fun pressW_10() { assertEquals(1.2494999999999998f, NotePure.pressW(3.57f, -0.47f), 0.0005f) }
    @Test fun pressW_11() { assertEquals(3.78f, NotePure.pressW(10.8f, -0.38f), 0.0005f) }
    @Test fun pressW_12() { assertEquals(1.4734999999999998f, NotePure.pressW(4.21f, -0.02f), 0.0005f) }
    @Test fun pressW_13() { assertEquals(0.686155f, NotePure.pressW(1.09f, 0.43f), 0.0005f) }
    @Test fun pressW_14() { assertEquals(9.09f, NotePure.pressW(9.09f, 1.18f), 0.0005f) }
    @Test fun pressW_15() { assertEquals(9.101339999999999f, NotePure.pressW(10.62f, 0.78f), 0.0005f) }
    @Test fun pressW_16() { assertEquals(9.05075f, NotePure.pressW(10.25f, 0.82f), 0.0005f) }
    @Test fun pressW_17() { assertEquals(3.6643799999999995f, NotePure.pressW(9.42f, 0.06f), 0.0005f) }
    @Test fun pressW_18() { assertEquals(19.95f, NotePure.pressW(19.95f, 1.49f), 0.0005f) }
    @Test fun pressW_19() { assertEquals(16.00224f, NotePure.pressW(16.88f, 0.92f), 0.0005f) }
    @Test fun pressW_20() { assertEquals(2.3275f, NotePure.pressW(6.65f, -0.04f), 0.0005f) }
    @Test fun pressW_21() { assertEquals(2.1489999999999996f, NotePure.pressW(6.14f, -0.36f), 0.0005f) }
    @Test fun pressW_22() { assertEquals(8.414799999999998f, NotePure.pressW(15.44f, 0.3f), 0.0005f) }
    @Test fun pressW_23() { assertEquals(8.938755f, NotePure.pressW(17.01f, 0.27f), 0.0005f) }
    @Test fun pressW_24() { assertEquals(19.18f, NotePure.pressW(19.18f, 1.19f), 0.0005f) }
    @Test fun pressW_25() { assertEquals(0.1785f, NotePure.pressW(0.51f, -0.08f), 0.0005f) }
    @Test fun pressW_26() { assertEquals(11.607f, NotePure.pressW(18.25f, 0.44f), 0.0005f) }
    @Test fun pressW_27() { assertEquals(10.56537f, NotePure.pressW(19.62f, 0.29f), 0.0005f) }
    @Test fun pressW_28() { assertEquals(1.6204800000000001f, NotePure.pressW(1.92f, 0.76f), 0.0005f) }
    @Test fun pressW_29() { assertEquals(5.89568f, NotePure.pressW(15.68f, 0.04f), 0.0005f) }
    @Test fun pressW_30() { assertEquals(1.0131000000000001f, NotePure.pressW(2.2f, 0.17f), 0.0005f) }
    @Test fun pressW_31() { assertEquals(19.3f, NotePure.pressW(19.3f, 1.02f), 0.0005f) }
    @Test fun pressW_32() { assertEquals(0.9799999999999999f, NotePure.pressW(2.8f, -0.01f), 0.0005f) }
    @Test fun pressW_33() { assertEquals(0.8645f, NotePure.pressW(2.47f, -0.38f), 0.0005f) }
    @Test fun pressW_34() { assertEquals(5.613999999999999f, NotePure.pressW(16.04f, -0.14f), 0.0005f) }
    @Test fun pressW_35() { assertEquals(6.885934999999999f, NotePure.pressW(11.41f, 0.39f), 0.0005f) }
    @Test fun pressW_36() { assertEquals(4.1102799999999995f, NotePure.pressW(4.22f, 0.96f), 0.0005f) }
    @Test fun pressW_37() { assertEquals(2.6336749999999998f, NotePure.pressW(3.05f, 0.79f), 0.0005f) }
    @Test fun pressW_38() { assertEquals(1.58167f, NotePure.pressW(2.77f, 0.34f), 0.0005f) }
    @Test fun pressW_39() { assertEquals(1.7484000000000002f, NotePure.pressW(4.65f, 0.04f), 0.0005f) }
    @Test fun pressW_40() { assertEquals(19.43f, NotePure.pressW(19.43f, 1.11f), 0.0005f) }
    @Test fun pressW_41() { assertEquals(6.43f, NotePure.pressW(6.43f, 1.27f), 0.0005f) }
    @Test fun pressW_42() { assertEquals(2.482485f, NotePure.pressW(4.61f, 0.29f), 0.0005f) }
    @Test fun pressW_43() { assertEquals(14.70612f, NotePure.pressW(17.16f, 0.78f), 0.0005f) }
    @Test fun pressW_44() { assertEquals(2.46f, NotePure.pressW(2.46f, 1.48f), 0.0005f) }
    @Test fun pressW_45() { assertEquals(1.69158f, NotePure.pressW(4.66f, 0.02f), 0.0005f) }
    @Test fun pressW_46() { assertEquals(7.068779999999999f, NotePure.pressW(15.57f, 0.16f), 0.0005f) }
    @Test fun pressW_47() { assertEquals(2.198f, NotePure.pressW(6.28f, -0.35f), 0.0005f) }
    @Test fun pressW_48() { assertEquals(1.77523f, NotePure.pressW(2.26f, 0.67f), 0.0005f) }
    @Test fun pressW_49() { assertEquals(4.2181999999999995f, NotePure.pressW(5.24f, 0.7f), 0.0005f) }
    @Test fun pressW_50() { assertEquals(4.777875000000001f, NotePure.pressW(7.75f, 0.41f), 0.0005f) }
    @Test fun pressW_51() { assertEquals(12.5856f, NotePure.pressW(19.2f, 0.47f), 0.0005f) }
    @Test fun pressW_52() { assertEquals(11.7f, NotePure.pressW(11.7f, 1.23f), 0.0005f) }
    @Test fun pressW_53() { assertEquals(1.4245f, NotePure.pressW(4.07f, -0.19f), 0.0005f) }
    @Test fun pressW_54() { assertEquals(18.21f, NotePure.pressW(18.21f, 1.14f), 0.0005f) }
    @Test fun pressW_55() { assertEquals(1.8795f, NotePure.pressW(5.37f, -0.12f), 0.0005f) }
    @Test fun pressW_56() { assertEquals(14.92f, NotePure.pressW(14.92f, 1.38f), 0.0005f) }
    @Test fun pressW_57() { assertEquals(4.33f, NotePure.pressW(4.33f, 1.4f), 0.0005f) }
    @Test fun pressW_58() { assertEquals(14.363549999999998f, NotePure.pressW(17.7f, 0.71f), 0.0005f) }
    @Test fun pressW_59() { assertEquals(3.052f, NotePure.pressW(8.72f, -0.29f), 0.0005f) }
    @Test fun pressW_60() { assertEquals(1.25f, NotePure.pressW(1.25f, 1.43f), 0.0005f) }
    @Test fun pressW_61() { assertEquals(4.848725f, NotePure.pressW(5.15f, 0.91f), 0.0005f) }
    @Test fun pressW_62() { assertEquals(5.51f, NotePure.pressW(5.51f, 1.15f), 0.0005f) }
    @Test fun pressW_63() { assertEquals(4.955105f, NotePure.pressW(12.13f, 0.09f), 0.0005f) }
    @Test fun pressW_64() { assertEquals(3.76712f, NotePure.pressW(3.92f, 0.94f), 0.0005f) }
    @Test fun pressW_65() { assertEquals(0.644f, NotePure.pressW(1.84f, -0.04f), 0.0005f) }
    @Test fun pressW_66() { assertEquals(11.41f, NotePure.pressW(11.41f, 1.2f), 0.0005f) }
    @Test fun pressW_67() { assertEquals(4.8547199999999995f, NotePure.pressW(12.48f, 0.06f), 0.0005f) }
    @Test fun pressW_68() { assertEquals(6.4365f, NotePure.pressW(18.39f, -0.09f), 0.0005f) }
    @Test fun pressW_69() { assertEquals(0.30832f, NotePure.pressW(0.82f, 0.04f), 0.0005f) }
    @Test fun pressW_70() { assertEquals(3.2164999999999995f, NotePure.pressW(9.19f, -0.38f), 0.0005f) }
    @Test fun pressW_71() { assertEquals(1.99364f, NotePure.pressW(3.94f, 0.24f), 0.0005f) }
    @Test fun pressW_72() { assertEquals(4.0809999999999995f, NotePure.pressW(11.66f, -0.24f), 0.0005f) }
    @Test fun pressW_73() { assertEquals(7.56f, NotePure.pressW(7.56f, 1.28f), 0.0005f) }
    @Test fun pressW_74() { assertEquals(17.196930000000002f, NotePure.pressW(19.62f, 0.81f), 0.0005f) }
    @Test fun pressW_75() { assertEquals(10.981290000000001f, NotePure.pressW(13.98f, 0.67f), 0.0005f) }
    @Test fun pressW_76() { assertEquals(1.134f, NotePure.pressW(3.24f, -0.43f), 0.0005f) }
    @Test fun pressW_77() { assertEquals(0.85f, NotePure.pressW(0.85f, 1.32f), 0.0005f) }
    @Test fun pressW_78() { assertEquals(14.17f, NotePure.pressW(14.17f, 1.43f), 0.0005f) }
    @Test fun pressW_79() { assertEquals(0.7739550000000001f, NotePure.pressW(0.91f, 0.77f), 0.0005f) }
    @Test fun pressW_80() { assertEquals(9.6426f, NotePure.pressW(9.9f, 0.96f), 0.0005f) }
    @Test fun pressW_81() { assertEquals(6.72f, NotePure.pressW(6.72f, 1.5f), 0.0005f) }
    @Test fun pressW_82() { assertEquals(1.444995f, NotePure.pressW(1.97f, 0.59f), 0.0005f) }
    @Test fun pressW_83() { assertEquals(14.87f, NotePure.pressW(14.87f, 1.3f), 0.0005f) }
    @Test fun pressW_84() { assertEquals(14.000105f, NotePure.pressW(14.87f, 0.91f), 0.0005f) }
    @Test fun pressW_85() { assertEquals(15.97f, NotePure.pressW(15.97f, 1.33f), 0.0005f) }
    @Test fun pressW_86() { assertEquals(6.73808f, NotePure.pressW(7.36f, 0.87f), 0.0005f) }
    @Test fun pressW_87() { assertEquals(18.07f, NotePure.pressW(18.07f, 1.24f), 0.0005f) }
    @Test fun pressW_88() { assertEquals(8.63f, NotePure.pressW(8.63f, 1.08f), 0.0005f) }
    @Test fun pressW_89() { assertEquals(13.39515f, NotePure.pressW(17.34f, 0.65f), 0.0005f) }
    @Test fun pressW_90() { assertEquals(6.58611f, NotePure.pressW(12.69f, 0.26f), 0.0005f) }
    @Test fun pressW_91() { assertEquals(9.701479999999998f, NotePure.pressW(11.86f, 0.72f), 0.0005f) }
    @Test fun pressW_92() { assertEquals(1.76542f, NotePure.pressW(2.06f, 0.78f), 0.0005f) }
    @Test fun pressW_93() { assertEquals(19.87f, NotePure.pressW(19.87f, 1.26f), 0.0005f) }
    @Test fun pressW_94() { assertEquals(7.8204f, NotePure.pressW(14.7f, 0.28f), 0.0005f) }
    @Test fun pressW_95() { assertEquals(11.552570000000001f, NotePure.pressW(14.83f, 0.66f), 0.0005f) }
    @Test fun pressW_96() { assertEquals(9.09f, NotePure.pressW(9.09f, 1.18f), 0.0005f) }
    @Test fun pressW_97() { assertEquals(2.13f, NotePure.pressW(2.13f, 1.0f), 0.0005f) }
    @Test fun pressW_98() { assertEquals(0.8694f, NotePure.pressW(1.08f, 0.7f), 0.0005f) }
    @Test fun pressW_99() { assertEquals(3.458f, NotePure.pressW(9.88f, -0.04f), 0.0005f) }
    @Test fun pressW_100() { assertEquals(9.439219999999999f, NotePure.pressW(14.12f, 0.49f), 0.0005f) }
    @Test fun pressW_101() { assertEquals(12.48f, NotePure.pressW(12.48f, 1.34f), 0.0005f) }
    @Test fun pressW_102() { assertEquals(1.9215f, NotePure.pressW(5.49f, -0.48f), 0.0005f) }
    @Test fun pressW_103() { assertEquals(5.79033f, NotePure.pressW(6.37f, 0.86f), 0.0005f) }
    @Test fun pressW_104() { assertEquals(1.5574999999999999f, NotePure.pressW(4.45f, -0.16f), 0.0005f) }
    @Test fun pressW_105() { assertEquals(16.03528f, NotePure.pressW(18.16f, 0.82f), 0.0005f) }
    @Test fun pressW_106() { assertEquals(9.12f, NotePure.pressW(9.12f, 1.28f), 0.0005f) }
    @Test fun pressW_107() { assertEquals(6.119759999999999f, NotePure.pressW(6.88f, 0.83f), 0.0005f) }
    @Test fun pressW_108() { assertEquals(2.5520799999999997f, NotePure.pressW(4.37f, 0.36f), 0.0005f) }
    @Test fun pressW_109() { assertEquals(16.22f, NotePure.pressW(16.22f, 1.33f), 0.0005f) }
    @Test fun pressW_110() { assertEquals(9.285585000000001f, NotePure.pressW(17.67f, 0.27f), 0.0005f) }
    @Test fun pressW_111() { assertEquals(5.157515f, NotePure.pressW(11.87f, 0.13f), 0.0005f) }
    @Test fun pressW_112() { assertEquals(2.11246f, NotePure.pressW(3.16f, 0.49f), 0.0005f) }
    @Test fun pressW_113() { assertEquals(16.82f, NotePure.pressW(16.82f, 1.2f), 0.0005f) }
    @Test fun pressW_114() { assertEquals(14.37f, NotePure.pressW(14.37f, 1.4f), 0.0005f) }
    @Test fun pressW_115() { assertEquals(2.065f, NotePure.pressW(5.9f, -0.16f), 0.0005f) }
    @Test fun pressW_116() { assertEquals(3.5534249999999994f, NotePure.pressW(9.29f, 0.05f), 0.0005f) }
    @Test fun pressW_117() { assertEquals(2.636215f, NotePure.pressW(4.67f, 0.33f), 0.0005f) }
    @Test fun pressW_118() { assertEquals(8.489949999999999f, NotePure.pressW(12.7f, 0.49f), 0.0005f) }
    @Test fun pressW_119() { assertEquals(6.65f, NotePure.pressW(6.65f, 1.18f), 0.0005f) }
    @Test fun fit_0() { assertEquals(800 to 53, NotePure.fitSize(12000, 800, 800)) }
    @Test fun fit_1() { assertEquals(1 to 100, NotePure.fitSize(1, 9000, 100)) }
    @Test fun fit_2() { assertEquals(142 to 1600, NotePure.fitSize(800, 9000, 1600)) }
    @Test fun fit_3() { assertEquals(1 to 1, NotePure.fitSize(0, 5000, 1600)) }
    @Test fun fit_4() { assertEquals(320 to 800, NotePure.fitSize(800, 2000, 800)) }
    @Test fun fit_6() { assertEquals(1 to 1, NotePure.fitSize(0, 5000, 100)) }
    @Test fun fit_7() { assertEquals(100 to 50, NotePure.fitSize(1600, 800, 100)) }
    @Test fun fit_8() { assertEquals(1 to 1, NotePure.fitSize(0, 9000, 800)) }
    @Test fun fit_9() { assertEquals(8 to 100, NotePure.fitSize(799, 9000, 100)) }
    @Test fun fit_10() { assertEquals(1 to 1, NotePure.fitSize(0, 5000, 100)) }
    @Test fun fit_11() { assertEquals(1 to 1, NotePure.fitSize(3000, 0, 1600)) }
    @Test fun fit_13() { assertEquals(1 to 1, NotePure.fitSize(801, 0, 1600)) }
    @Test fun fit_14() { assertEquals(799 to 1, NotePure.fitSize(799, 1, 800)) }
    @Test fun fit_15() { assertEquals(800 to 1, NotePure.fitSize(800, 1, 1600)) }
    @Test fun fit_16() { assertEquals(1 to 1, NotePure.fitSize(0, 9000, 800)) }
    @Test fun fit_18() { assertEquals(50 to 1, NotePure.fitSize(50, 1, 800)) }
    @Test fun fit_19() { assertEquals(640 to 1600, NotePure.fitSize(801, 2000, 1600)) }
    @Test fun fit_20() { assertEquals(1600 to 800, NotePure.fitSize(4000, 2000, 1600)) }
    @Test fun fit_21() { assertEquals(50 to 800, NotePure.fitSize(50, 800, 1600)) }
    @Test fun fit_22() { assertEquals(1 to 1, NotePure.fitSize(799, 0, 800)) }
    @Test fun fit_23() { assertEquals(800 to 1, NotePure.fitSize(1600, 1, 800)) }
    @Test fun fit_24() { assertEquals(1600 to 1, NotePure.fitSize(3000, 1, 1600)) }
    @Test fun fit_25() { assertEquals(1 to 1, NotePure.fitSize(0, 800, 1600)) }
    @Test fun fit_26() { assertEquals(1600 to 666, NotePure.fitSize(12000, 5000, 1600)) }
    @Test fun fit_27() { assertEquals(800 to 799, NotePure.fitSize(801, 800, 800)) }
    @Test fun fit_28() { assertEquals(1 to 1, NotePure.fitSize(799, 0, 1600)) }
    @Test fun fit_29() { assertEquals(1 to 1, NotePure.fitSize(1, 1, 100)) }
    @Test fun fit_30() { assertEquals(1 to 1, NotePure.fitSize(1600, 0, 800)) }
    @Test fun fit_31() { assertEquals(355 to 800, NotePure.fitSize(4000, 9000, 800)) }
    @Test fun fit_33() { assertEquals(40 to 100, NotePure.fitSize(801, 2000, 100)) }
    @Test fun fit_34() { assertEquals(1 to 1, NotePure.fitSize(0, 800, 800)) }
    @Test fun fit_35() { assertEquals(800 to 160, NotePure.fitSize(4000, 800, 800)) }
    @Test fun fit_36() { assertEquals(1 to 1, NotePure.fitSize(3000, 0, 100)) }
    @Test fun fit_37() { assertEquals(1 to 100, NotePure.fitSize(1, 800, 100)) }
    @Test fun fit_38() { assertEquals(20 to 800, NotePure.fitSize(50, 2000, 800)) }
    @Test fun fit_39() { assertEquals(6 to 100, NotePure.fitSize(50, 800, 100)) }
    @Test fun fit_41() { assertEquals(1600 to 426, NotePure.fitSize(3000, 800, 1600)) }
    @Test fun fit_42() { assertEquals(1 to 100, NotePure.fitSize(1, 9000, 100)) }
    @Test fun fit_43() { assertEquals(1600 to 1066, NotePure.fitSize(3000, 2000, 1600)) }
    @Test fun fit_44() { assertEquals(142 to 1600, NotePure.fitSize(800, 9000, 1600)) }
    @Test fun fit_46() { assertEquals(1600 to 800, NotePure.fitSize(4000, 2000, 1600)) }
    @Test fun fit_47() { assertEquals(800 to 33, NotePure.fitSize(800, 33, 1600)) }
    @Test fun fit_48() { assertEquals(284 to 1600, NotePure.fitSize(1600, 9000, 1600)) }
    @Test fun fit_49() { assertEquals(100 to 4, NotePure.fitSize(799, 33, 100)) }
    @Test fun fit_50() { assertEquals(800 to 400, NotePure.fitSize(4000, 2000, 800)) }
    @Test fun fit_51() { assertEquals(100 to 6, NotePure.fitSize(12000, 800, 100)) }
    @Test fun fit_52() { assertEquals(80 to 100, NotePure.fitSize(1600, 2000, 100)) }
    @Test fun fit_53() { assertEquals(1 to 1, NotePure.fitSize(4000, 0, 1600)) }
    @Test fun fit_54() { assertEquals(1 to 1, NotePure.fitSize(1600, 0, 1600)) }
    @Test fun fit_55() { assertEquals(1 to 1, NotePure.fitSize(0, 2000, 800)) }
    @Test fun fit_56() { assertEquals(711 to 1600, NotePure.fitSize(4000, 9000, 1600)) }
    @Test fun fit_57() { assertEquals(1 to 100, NotePure.fitSize(1, 800, 100)) }
    @Test fun fit_58() { assertEquals(1 to 1, NotePure.fitSize(50, 0, 1600)) }
    @Test fun fit_59() { assertEquals(800 to 213, NotePure.fitSize(3000, 800, 800)) }
    @Test fun fit_60() { assertEquals(800 to 1, NotePure.fitSize(800, 1, 800)) }
    @Test fun fit_61() { assertEquals(800 to 1, NotePure.fitSize(3000, 1, 800)) }
    @Test fun fit_62() { assertEquals(142 to 800, NotePure.fitSize(1600, 9000, 800)) }
    @Test fun fit_63() { assertEquals(100 to 1, NotePure.fitSize(4000, 33, 100)) }
    @Test fun fit_64() { assertEquals(799 to 800, NotePure.fitSize(799, 800, 1600)) }
    @Test fun fit_65() { assertEquals(1 to 1, NotePure.fitSize(0, 33, 100)) }
    @Test fun fit_66() { assertEquals(1 to 1, NotePure.fitSize(0, 0, 100)) }
    @Test fun fit_67() { assertEquals(50 to 1, NotePure.fitSize(50, 1, 100)) }
    @Test fun fit_68() { assertEquals(800 to 33, NotePure.fitSize(800, 33, 1600)) }
    @Test fun fit_69() { assertEquals(801 to 1, NotePure.fitSize(801, 1, 1600)) }
    @Test fun fit_70() { assertEquals(1 to 1, NotePure.fitSize(3000, 0, 800)) }
    @Test fun fit_71() { assertEquals(1 to 1, NotePure.fitSize(12000, 0, 1600)) }
    @Test fun fit_72() { assertEquals(1600 to 4, NotePure.fitSize(12000, 33, 1600)) }
    @Test fun fit_74() { assertEquals(1 to 1, NotePure.fitSize(1600, 0, 800)) }
    @Test fun fit_75() { assertEquals(284 to 1600, NotePure.fitSize(1600, 9000, 1600)) }
    @Test fun fit_76() { assertEquals(1600 to 1, NotePure.fitSize(12000, 1, 1600)) }
    @Test fun fit_77() { assertEquals(142 to 1600, NotePure.fitSize(799, 9000, 1600)) }
    @Test fun fit_79() { assertEquals(1600 to 1, NotePure.fitSize(4000, 1, 1600)) }
    @Test fun fit_80() { assertEquals(100 to 16, NotePure.fitSize(12000, 2000, 100)) }
    @Test fun fit_82() { assertEquals(800 to 1, NotePure.fitSize(801, 1, 800)) }
    @Test fun fit_83() { assertEquals(100 to 1, NotePure.fitSize(12000, 33, 100)) }
    @Test fun fit_84() { assertEquals(8 to 100, NotePure.fitSize(799, 9000, 100)) }
    @Test fun fit_85() { assertEquals(1 to 1, NotePure.fitSize(1, 1, 100)) }
    @Test fun fit_87() { assertEquals(100 to 100, NotePure.fitSize(800, 800, 100)) }
    @Test fun fit_88() { assertEquals(142 to 800, NotePure.fitSize(1600, 9000, 800)) }
    @Test fun fit_89() { assertEquals(711 to 1600, NotePure.fitSize(4000, 9000, 1600)) }
    @Test fun fit_90() { assertEquals(50 to 1, NotePure.fitSize(50, 1, 800)) }
    @Test fun fit_91() { assertEquals(1 to 1, NotePure.fitSize(0, 0, 100)) }
    @Test fun fit_92() { assertEquals(800 to 333, NotePure.fitSize(12000, 5000, 800)) }
    @Test fun fit_93() { assertEquals(1 to 1, NotePure.fitSize(801, 0, 1600)) }
    @Test fun fit_96() { assertEquals(1 to 100, NotePure.fitSize(1, 800, 100)) }
    @Test fun fit_97() { assertEquals(1 to 1, NotePure.fitSize(0, 0, 1600)) }
    @Test fun fit_98() { assertEquals(1600 to 266, NotePure.fitSize(12000, 2000, 1600)) }
    @Test fun fit_99() { assertEquals(100 to 1, NotePure.fitSize(3000, 1, 100)) }
    @Test fun fit_100() { assertEquals(1 to 1, NotePure.fitSize(50, 0, 100)) }
    @Test fun fit_101() { assertEquals(1 to 100, NotePure.fitSize(50, 9000, 100)) }
    @Test fun fit_103() { assertEquals(1 to 1, NotePure.fitSize(12000, 0, 100)) }
    @Test fun fit_104() { assertEquals(1 to 1, NotePure.fitSize(3000, 0, 100)) }
    @Test fun fit_105() { assertEquals(800 to 799, NotePure.fitSize(801, 800, 800)) }
    @Test fun fit_106() { assertEquals(640 to 800, NotePure.fitSize(1600, 2000, 800)) }
    @Test fun fit_107() { assertEquals(1600 to 1, NotePure.fitSize(1600, 1, 1600)) }
    @Test fun fit_108() { assertEquals(1 to 1, NotePure.fitSize(801, 0, 1600)) }
    @Test fun fit_109() { assertEquals(1 to 1, NotePure.fitSize(0, 9000, 100)) }
    @Test fun fit_110() { assertEquals(50 to 800, NotePure.fitSize(50, 800, 800)) }
    @Test fun fit_112() { assertEquals(1600 to 1, NotePure.fitSize(1600, 1, 1600)) }
    @Test fun fit_113() { assertEquals(1 to 1, NotePure.fitSize(50, 0, 1600)) }
    @Test fun fit_114() { assertEquals(1 to 1, NotePure.fitSize(0, 33, 100)) }
    @Test fun fit_115() { assertEquals(1280 to 1600, NotePure.fitSize(1600, 2000, 1600)) }
    @Test fun fit_116() { assertEquals(639 to 1600, NotePure.fitSize(799, 2000, 1600)) }
    @Test fun fit_117() { assertEquals(71 to 800, NotePure.fitSize(801, 9000, 800)) }
    @Test fun fit_118() { assertEquals(1 to 1, NotePure.fitSize(800, 0, 1600)) }
    @Test fun fit_119() { assertEquals(4 to 800, NotePure.fitSize(50, 9000, 800)) }
    @Test fun fit_120() { assertEquals(50 to 33, NotePure.fitSize(50, 33, 1600)) }
    @Test fun fit_121() { assertEquals(71 to 800, NotePure.fitSize(801, 9000, 800)) }
    @Test fun fit_122() { assertEquals(6 to 100, NotePure.fitSize(50, 800, 100)) }
    @Test fun fit_123() { assertEquals(1 to 1, NotePure.fitSize(50, 0, 800)) }
    @Test fun fit_124() { assertEquals(100 to 100, NotePure.fitSize(800, 800, 100)) }
    @Test fun fit_125() { assertEquals(1 to 1, NotePure.fitSize(0, 33, 1600)) }
    @Test fun fit_126() { assertEquals(1 to 1, NotePure.fitSize(12000, 0, 100)) }
    @Test fun fit_128() { assertEquals(801 to 1, NotePure.fitSize(801, 1, 1600)) }
    @Test fun fit_129() { assertEquals(80 to 100, NotePure.fitSize(1600, 2000, 100)) }
    @Test fun fit_130() { assertEquals(1 to 1, NotePure.fitSize(4000, 0, 800)) }
    @Test fun fit_131() { assertEquals(1600 to 320, NotePure.fitSize(4000, 800, 1600)) }
    @Test fun fit_133() { assertEquals(80 to 100, NotePure.fitSize(1600, 2000, 100)) }
    @Test fun fit_134() { assertEquals(1 to 100, NotePure.fitSize(1, 2000, 100)) }
    @Test fun fit_135() { assertEquals(799 to 33, NotePure.fitSize(799, 33, 800)) }
    @Test fun fit_136() { assertEquals(80 to 100, NotePure.fitSize(1600, 2000, 100)) }
    @Test fun fit_138() { assertEquals(1 to 1, NotePure.fitSize(0, 0, 800)) }
    @Test fun fit_139() { assertEquals(800 to 33, NotePure.fitSize(800, 33, 800)) }
    @Test fun fit_140() { assertEquals(1600 to 800, NotePure.fitSize(4000, 2000, 1600)) }
    @Test fun fit_141() { assertEquals(1280 to 1600, NotePure.fitSize(1600, 2000, 1600)) }
    @Test fun fit_143() { assertEquals(1 to 1600, NotePure.fitSize(1, 2000, 1600)) }
    @Test fun fit_144() { assertEquals(1 to 1, NotePure.fitSize(0, 800, 100)) }
    @Test fun fit_145() { assertEquals(100 to 50, NotePure.fitSize(1600, 800, 100)) }
    @Test fun fit_146() { assertEquals(1600 to 1066, NotePure.fitSize(3000, 2000, 1600)) }
    @Test fun fit_147() { assertEquals(1 to 1, NotePure.fitSize(12000, 0, 800)) }
    @Test fun fit_148() { assertEquals(800 to 213, NotePure.fitSize(3000, 800, 800)) }
    @Test fun fit_149() { assertEquals(1600 to 320, NotePure.fitSize(4000, 800, 1600)) }
    @Test fun dur_0() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_1() { assertEquals("0:01", NotePure.fmtDur(1000L)) }
    @Test fun dur_2() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_3() { assertEquals("2:05", NotePure.fmtDur(125999L)) }
    @Test fun dur_4() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_5() { assertEquals("0:00", NotePure.fmtDur(-1000L)) }
    @Test fun dur_6() { assertEquals("0:00", NotePure.fmtDur(999L)) }
    @Test fun dur_7() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_8() { assertEquals("1:00", NotePure.fmtDur(60000L)) }
    @Test fun dur_9() { assertEquals("0:00", NotePure.fmtDur(-1000L)) }
    @Test fun dur_10() { assertEquals("88:07", NotePure.fmtDur(5287239L)) }
    @Test fun dur_11() { assertEquals("0:00", NotePure.fmtDur(-1000L)) }
    @Test fun dur_12() { assertEquals("0:00", NotePure.fmtDur(0L)) }
    @Test fun dur_13() { assertEquals("1:00", NotePure.fmtDur(60000L)) }
    @Test fun dur_14() { assertEquals("0:01", NotePure.fmtDur(1000L)) }
    @Test fun dur_15() { assertEquals("0:00", NotePure.fmtDur(-1000L)) }
    @Test fun dur_16() { assertEquals("0:00", NotePure.fmtDur(0L)) }
    @Test fun dur_17() { assertEquals("0:00", NotePure.fmtDur(1L)) }
    @Test fun dur_18() { assertEquals("59:59", NotePure.fmtDur(3599000L)) }
    @Test fun dur_19() { assertEquals("0:00", NotePure.fmtDur(-1000L)) }
    @Test fun dur_20() { assertEquals("1:01", NotePure.fmtDur(61000L)) }
    @Test fun dur_21() { assertEquals("0:00", NotePure.fmtDur(999L)) }
    @Test fun dur_22() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_23() { assertEquals("0:00", NotePure.fmtDur(1L)) }
    @Test fun dur_24() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_25() { assertEquals("0:00", NotePure.fmtDur(1L)) }
    @Test fun dur_26() { assertEquals("1:01", NotePure.fmtDur(61000L)) }
    @Test fun dur_27() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_28() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_29() { assertEquals("0:00", NotePure.fmtDur(1L)) }
    @Test fun dur_30() { assertEquals("81:07", NotePure.fmtDur(4867558L)) }
    @Test fun dur_31() { assertEquals("0:00", NotePure.fmtDur(999L)) }
    @Test fun dur_32() { assertEquals("0:00", NotePure.fmtDur(0L)) }
    @Test fun dur_33() { assertEquals("0:01", NotePure.fmtDur(1000L)) }
    @Test fun dur_34() { assertEquals("59:59", NotePure.fmtDur(3599000L)) }
    @Test fun dur_35() { assertEquals("0:01", NotePure.fmtDur(1000L)) }
    @Test fun dur_36() { assertEquals("59:59", NotePure.fmtDur(3599000L)) }
    @Test fun dur_37() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_38() { assertEquals("0:00", NotePure.fmtDur(999L)) }
    @Test fun dur_39() { assertEquals("0:00", NotePure.fmtDur(999L)) }
    @Test fun dur_40() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_41() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_42() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_43() { assertEquals("0:00", NotePure.fmtDur(-1000L)) }
    @Test fun dur_44() { assertEquals("0:01", NotePure.fmtDur(1000L)) }
    @Test fun dur_45() { assertEquals("0:00", NotePure.fmtDur(-1000L)) }
    @Test fun dur_46() { assertEquals("0:00", NotePure.fmtDur(0L)) }
    @Test fun dur_47() { assertEquals("2:05", NotePure.fmtDur(125999L)) }
    @Test fun dur_48() { assertEquals("0:00", NotePure.fmtDur(0L)) }
    @Test fun dur_49() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_50() { assertEquals("2:05", NotePure.fmtDur(125999L)) }
    @Test fun dur_51() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_52() { assertEquals("1:01", NotePure.fmtDur(61000L)) }
    @Test fun dur_53() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_54() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_55() { assertEquals("1:01", NotePure.fmtDur(61000L)) }
    @Test fun dur_56() { assertEquals("0:00", NotePure.fmtDur(0L)) }
    @Test fun dur_57() { assertEquals("1:01", NotePure.fmtDur(61000L)) }
    @Test fun dur_58() { assertEquals("1:01", NotePure.fmtDur(61000L)) }
    @Test fun dur_59() { assertEquals("118:39", NotePure.fmtDur(7119584L)) }
    @Test fun dur_60() { assertEquals("1:00", NotePure.fmtDur(60000L)) }
    @Test fun dur_61() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_62() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_63() { assertEquals("0:01", NotePure.fmtDur(1000L)) }
    @Test fun dur_64() { assertEquals("1:00", NotePure.fmtDur(60000L)) }
    @Test fun dur_65() { assertEquals("59:59", NotePure.fmtDur(3599000L)) }
    @Test fun dur_66() { assertEquals("1:01", NotePure.fmtDur(61000L)) }
    @Test fun dur_67() { assertEquals("0:00", NotePure.fmtDur(0L)) }
    @Test fun dur_68() { assertEquals("1:00", NotePure.fmtDur(60000L)) }
    @Test fun dur_69() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_70() { assertEquals("0:01", NotePure.fmtDur(1000L)) }
    @Test fun dur_71() { assertEquals("0:00", NotePure.fmtDur(0L)) }
    @Test fun dur_72() { assertEquals("0:00", NotePure.fmtDur(999L)) }
    @Test fun dur_73() { assertEquals("22:50", NotePure.fmtDur(1370848L)) }
    @Test fun dur_74() { assertEquals("1:01", NotePure.fmtDur(61000L)) }
    @Test fun dur_75() { assertEquals("0:01", NotePure.fmtDur(1000L)) }
    @Test fun dur_76() { assertEquals("0:00", NotePure.fmtDur(999L)) }
    @Test fun dur_77() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_78() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_79() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_80() { assertEquals("59:59", NotePure.fmtDur(3599000L)) }
    @Test fun dur_81() { assertEquals("1:01", NotePure.fmtDur(61000L)) }
    @Test fun dur_82() { assertEquals("0:01", NotePure.fmtDur(1000L)) }
    @Test fun dur_83() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_84() { assertEquals("1:00", NotePure.fmtDur(60000L)) }
    @Test fun dur_85() { assertEquals("0:00", NotePure.fmtDur(999L)) }
    @Test fun dur_86() { assertEquals("0:59", NotePure.fmtDur(59999L)) }
    @Test fun dur_87() { assertEquals("0:00", NotePure.fmtDur(-1000L)) }
    @Test fun dur_88() { assertEquals("61:01", NotePure.fmtDur(3661000L)) }
    @Test fun dur_89() { assertEquals("59:59", NotePure.fmtDur(3599000L)) }
    @Test fun dur_90() { assertEquals("0:00", NotePure.fmtDur(999L)) }
    @Test fun dur_91() { assertEquals("1:00", NotePure.fmtDur(60000L)) }
    @Test fun dur_92() { assertEquals("59:59", NotePure.fmtDur(3599000L)) }
    @Test fun dur_93() { assertEquals("0:00", NotePure.fmtDur(1L)) }
    @Test fun dur_94() { assertEquals("1:01", NotePure.fmtDur(61000L)) }
    @Test fun dur_95() { assertEquals("0:00", NotePure.fmtDur(-1000L)) }
    @Test fun dur_96() { assertEquals("2:05", NotePure.fmtDur(125999L)) }
    @Test fun dur_97() { assertEquals("2:05", NotePure.fmtDur(125999L)) }
    @Test fun dur_98() { assertEquals("59:59", NotePure.fmtDur(3599000L)) }
    @Test fun dur_99() { assertEquals("0:00", NotePure.fmtDur(-1000L)) }
    @Test fun pdfTotal_0() { assertEquals(6.5600000000000005f, NotePure.pdfTotal(listOf(0.6f,1.32f,1.68f,0.63f,0.62f,1.61f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(0.6f,1.32f,1.68f,0.63f,0.62f,1.61f)).size) }
    @Test fun pdfPage_0() { assertEquals(5, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.6f,1.32f,1.68f,0.63f,0.62f,1.61f)), 6.747f)) }
    @Test fun pdfTotal_1() { assertEquals(0.54f, NotePure.pdfTotal(listOf(0.54f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(0.54f)).size) }
    @Test fun pdfPage_1() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.54f)), 0.833f)) }
    @Test fun pdfTotal_2() { assertEquals(1.62f, NotePure.pdfTotal(listOf(1.62f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.62f)).size) }
    @Test fun pdfPage_2() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.62f)), 1.525f)) }
    @Test fun pdfTotal_3() { assertEquals(4.7f, NotePure.pdfTotal(listOf(1.57f,1.23f,1.86f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.57f,1.23f,1.86f)).size) }
    @Test fun pdfPage_3() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.57f,1.23f,1.86f)), 1.597f)) }
    @Test fun pdfTotal_4() { assertEquals(9.81f, NotePure.pdfTotal(listOf(1.09f,1.01f,1.95f,1.51f,1.24f,1.31f,1.58f)), 0.001f); assertEquals(7, NotePure.pdfTops(listOf(1.09f,1.01f,1.95f,1.51f,1.24f,1.31f,1.58f)).size) }
    @Test fun pdfPage_4() { assertEquals(5, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.09f,1.01f,1.95f,1.51f,1.24f,1.31f,1.58f)), 7.509f)) }
    @Test fun pdfTotal_5() { assertEquals(0.0f, NotePure.pdfTotal(emptyList<Float>()), 0.001f); assertEquals(0, NotePure.pdfTops(emptyList<Float>()).size) }
    @Test fun pdfTotal_6() { assertEquals(6.95f, NotePure.pdfTotal(listOf(1.64f,1.98f,1.02f,0.51f,1.07f,0.63f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(1.64f,1.98f,1.02f,0.51f,1.07f,0.63f)).size) }
    @Test fun pdfPage_6() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.64f,1.98f,1.02f,0.51f,1.07f,0.63f)), 3.426f)) }
    @Test fun pdfTotal_7() { assertEquals(10.75f, NotePure.pdfTotal(listOf(1.46f,1.29f,1.57f,1.7f,1.13f,1.13f,0.72f,1.61f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(1.46f,1.29f,1.57f,1.7f,1.13f,1.13f,0.72f,1.61f)).size) }
    @Test fun pdfPage_7() { assertEquals(7, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.46f,1.29f,1.57f,1.7f,1.13f,1.13f,0.72f,1.61f)), 11.64f)) }
    @Test fun pdfTotal_8() { assertEquals(7.72f, NotePure.pdfTotal(listOf(1.53f,0.98f,1.08f,1.29f,0.91f,1.83f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(1.53f,0.98f,1.08f,1.29f,0.91f,1.83f)).size) }
    @Test fun pdfPage_8() { assertEquals(3, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.53f,0.98f,1.08f,1.29f,0.91f,1.83f)), 3.847f)) }
    @Test fun pdfTotal_9() { assertEquals(0.96f, NotePure.pdfTotal(listOf(0.96f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(0.96f)).size) }
    @Test fun pdfPage_9() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.96f)), -0.117f)) }
    @Test fun pdfTotal_10() { assertEquals(3.52f, NotePure.pdfTotal(listOf(1.87f,1.63f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(1.87f,1.63f)).size) }
    @Test fun pdfPage_10() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.87f,1.63f)), -0.414f)) }
    @Test fun pdfTotal_11() { assertEquals(7.23f, NotePure.pdfTotal(listOf(1.86f,0.55f,0.66f,0.78f,0.83f,0.85f,1.58f)), 0.001f); assertEquals(7, NotePure.pdfTops(listOf(1.86f,0.55f,0.66f,0.78f,0.83f,0.85f,1.58f)).size) }
    @Test fun pdfPage_11() { assertEquals(4, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.86f,0.55f,0.66f,0.78f,0.83f,0.85f,1.58f)), 4.692f)) }
    @Test fun pdfTotal_12() { assertEquals(4.140000000000001f, NotePure.pdfTotal(listOf(1.16f,1.84f,1.1f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.16f,1.84f,1.1f)).size) }
    @Test fun pdfPage_12() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.16f,1.84f,1.1f)), 4.636f)) }
    @Test fun pdfTotal_13() { assertEquals(6.5200000000000005f, NotePure.pdfTotal(listOf(1.44f,1.91f,1.33f,1.78f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(1.44f,1.91f,1.33f,1.78f)).size) }
    @Test fun pdfPage_13() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.44f,1.91f,1.33f,1.78f)), 3.388f)) }
    @Test fun pdfTotal_14() { assertEquals(8.29f, NotePure.pdfTotal(listOf(1.87f,1.01f,1.32f,1.94f,1.22f,0.83f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(1.87f,1.01f,1.32f,1.94f,1.22f,0.83f)).size) }
    @Test fun pdfPage_14() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.87f,1.01f,1.32f,1.94f,1.22f,0.83f)), -0.013f)) }
    @Test fun pdfTotal_15() { assertEquals(2.8f, NotePure.pdfTotal(listOf(1.7f,1.08f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(1.7f,1.08f)).size) }
    @Test fun pdfPage_15() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.7f,1.08f)), 1.769f)) }
    @Test fun pdfTotal_16() { assertEquals(12.65f, NotePure.pdfTotal(listOf(1.66f,1.68f,0.59f,1.89f,1.84f,1.81f,1.86f,1.18f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(1.66f,1.68f,0.59f,1.89f,1.84f,1.81f,1.86f,1.18f)).size) }
    @Test fun pdfPage_16() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.66f,1.68f,0.59f,1.89f,1.84f,1.81f,1.86f,1.18f)), 2.989f)) }
    @Test fun pdfTotal_17() { assertEquals(6.66f, NotePure.pdfTotal(listOf(1.41f,0.74f,0.74f,0.98f,0.89f,1.8f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(1.41f,0.74f,0.74f,0.98f,0.89f,1.8f)).size) }
    @Test fun pdfPage_17() { assertEquals(3, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.41f,0.74f,0.74f,0.98f,0.89f,1.8f)), 3.712f)) }
    @Test fun pdfTotal_18() { assertEquals(4.040000000000001f, NotePure.pdfTotal(listOf(1.27f,0.58f,1.36f,0.77f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(1.27f,0.58f,1.36f,0.77f)).size) }
    @Test fun pdfPage_18() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.27f,0.58f,1.36f,0.77f)), 0.632f)) }
    @Test fun pdfTotal_19() { assertEquals(2.37f, NotePure.pdfTotal(listOf(1.73f,0.62f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(1.73f,0.62f)).size) }
    @Test fun pdfPage_19() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.73f,0.62f)), 0.545f)) }
    @Test fun pdfTotal_20() { assertEquals(10.950000000000001f, NotePure.pdfTotal(listOf(0.65f,1.22f,1.2f,1.93f,1.38f,1.79f,0.96f,1.68f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(0.65f,1.22f,1.2f,1.93f,1.38f,1.79f,0.96f,1.68f)).size) }
    @Test fun pdfPage_20() { assertEquals(3, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.65f,1.22f,1.2f,1.93f,1.38f,1.79f,0.96f,1.68f)), 4.691f)) }
    @Test fun pdfTotal_21() { assertEquals(1.67f, NotePure.pdfTotal(listOf(1.67f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.67f)).size) }
    @Test fun pdfPage_21() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.67f)), 0.895f)) }
    @Test fun pdfTotal_22() { assertEquals(0.0f, NotePure.pdfTotal(emptyList<Float>()), 0.001f); assertEquals(0, NotePure.pdfTops(emptyList<Float>()).size) }
    @Test fun pdfTotal_23() { assertEquals(11.78f, NotePure.pdfTotal(listOf(1.12f,1.24f,1.92f,1.95f,0.97f,1.11f,1.33f,2.0f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(1.12f,1.24f,1.92f,1.95f,0.97f,1.11f,1.33f,2.0f)).size) }
    @Test fun pdfPage_23() { assertEquals(5, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.12f,1.24f,1.92f,1.95f,0.97f,1.11f,1.33f,2.0f)), 8.36f)) }
    @Test fun pdfTotal_24() { assertEquals(1.04f, NotePure.pdfTotal(listOf(1.04f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.04f)).size) }
    @Test fun pdfPage_24() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.04f)), 1.245f)) }
    @Test fun pdfTotal_25() { assertEquals(1.5f, NotePure.pdfTotal(listOf(1.5f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.5f)).size) }
    @Test fun pdfPage_25() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.5f)), 1.528f)) }
    @Test fun pdfTotal_26() { assertEquals(1.48f, NotePure.pdfTotal(listOf(1.48f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.48f)).size) }
    @Test fun pdfPage_26() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.48f)), -0.463f)) }
    @Test fun pdfTotal_27() { assertEquals(7.930000000000001f, NotePure.pdfTotal(listOf(1.57f,1.21f,0.94f,0.67f,1.66f,1.78f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(1.57f,1.21f,0.94f,0.67f,1.66f,1.78f)).size) }
    @Test fun pdfPage_27() { assertEquals(5, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.57f,1.21f,0.94f,0.67f,1.66f,1.78f)), 7.464f)) }
    @Test fun pdfTotal_28() { assertEquals(4.0600000000000005f, NotePure.pdfTotal(listOf(1.85f,0.73f,1.44f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.85f,0.73f,1.44f)).size) }
    @Test fun pdfPage_28() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.85f,0.73f,1.44f)), 4.712f)) }
    @Test fun pdfTotal_29() { assertEquals(5.579999999999999f, NotePure.pdfTotal(listOf(1.93f,1.63f,1.33f,0.63f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(1.93f,1.63f,1.33f,0.63f)).size) }
    @Test fun pdfPage_29() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.93f,1.63f,1.33f,0.63f)), 0.836f)) }
    @Test fun pdfTotal_30() { assertEquals(8.540000000000001f, NotePure.pdfTotal(listOf(1.6f,0.99f,1.92f,1.34f,1.59f,1.0f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(1.6f,0.99f,1.92f,1.34f,1.59f,1.0f)).size) }
    @Test fun pdfPage_30() { assertEquals(5, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.6f,0.99f,1.92f,1.34f,1.59f,1.0f)), 7.802f)) }
    @Test fun pdfTotal_31() { assertEquals(0.65f, NotePure.pdfTotal(listOf(0.65f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(0.65f)).size) }
    @Test fun pdfPage_31() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.65f)), 0.837f)) }
    @Test fun pdfTotal_32() { assertEquals(3.1f, NotePure.pdfTotal(listOf(1.52f,1.56f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(1.52f,1.56f)).size) }
    @Test fun pdfPage_32() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.52f,1.56f)), 0.327f)) }
    @Test fun pdfTotal_33() { assertEquals(6.58f, NotePure.pdfTotal(listOf(0.55f,1.19f,1.56f,0.65f,0.55f,1.98f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(0.55f,1.19f,1.56f,0.65f,0.55f,1.98f)).size) }
    @Test fun pdfPage_33() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.55f,1.19f,1.56f,0.65f,0.55f,1.98f)), 3.005f)) }
    @Test fun pdfTotal_34() { assertEquals(1.01f, NotePure.pdfTotal(listOf(1.01f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.01f)).size) }
    @Test fun pdfPage_34() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.01f)), 1.566f)) }
    @Test fun pdfTotal_35() { assertEquals(10.04f, NotePure.pdfTotal(listOf(0.71f,0.81f,0.72f,1.54f,1.22f,1.88f,1.43f,1.59f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(0.71f,0.81f,0.72f,1.54f,1.22f,1.88f,1.43f,1.59f)).size) }
    @Test fun pdfPage_35() { assertEquals(5, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.71f,0.81f,0.72f,1.54f,1.22f,1.88f,1.43f,1.59f)), 6.575f)) }
    @Test fun pdfTotal_36() { assertEquals(7.16f, NotePure.pdfTotal(listOf(1.97f,1.68f,1.49f,1.41f,0.53f)), 0.001f); assertEquals(5, NotePure.pdfTops(listOf(1.97f,1.68f,1.49f,1.41f,0.53f)).size) }
    @Test fun pdfPage_36() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.97f,1.68f,1.49f,1.41f,0.53f)), 2.367f)) }
    @Test fun pdfTotal_37() { assertEquals(5.3500000000000005f, NotePure.pdfTotal(listOf(0.96f,1.16f,1.34f,0.81f,1.0f)), 0.001f); assertEquals(5, NotePure.pdfTops(listOf(0.96f,1.16f,1.34f,0.81f,1.0f)).size) }
    @Test fun pdfPage_37() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.96f,1.16f,1.34f,0.81f,1.0f)), 1.51f)) }
    @Test fun pdfTotal_38() { assertEquals(1.42f, NotePure.pdfTotal(listOf(1.42f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.42f)).size) }
    @Test fun pdfPage_38() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.42f)), -0.038f)) }
    @Test fun pdfTotal_39() { assertEquals(11.12f, NotePure.pdfTotal(listOf(1.85f,1.32f,1.03f,1.25f,0.71f,1.57f,1.98f,1.27f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(1.85f,1.32f,1.03f,1.25f,0.71f,1.57f,1.98f,1.27f)).size) }
    @Test fun pdfPage_39() { assertEquals(6, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.85f,1.32f,1.03f,1.25f,0.71f,1.57f,1.98f,1.27f)), 8.528f)) }
    @Test fun pdfTotal_40() { assertEquals(3.42f, NotePure.pdfTotal(listOf(1.35f,0.54f,1.49f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.35f,0.54f,1.49f)).size) }
    @Test fun pdfPage_40() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.35f,0.54f,1.49f)), 3.321f)) }
    @Test fun pdfTotal_41() { assertEquals(2.25f, NotePure.pdfTotal(listOf(0.87f,1.36f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(0.87f,1.36f)).size) }
    @Test fun pdfPage_41() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.87f,1.36f)), 2.114f)) }
    @Test fun pdfTotal_42() { assertEquals(6.43f, NotePure.pdfTotal(listOf(0.64f,1.81f,0.9f,1.82f,1.18f)), 0.001f); assertEquals(5, NotePure.pdfTops(listOf(0.64f,1.81f,0.9f,1.82f,1.18f)).size) }
    @Test fun pdfPage_42() { assertEquals(4, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.64f,1.81f,0.9f,1.82f,1.18f)), 5.287f)) }
    @Test fun pdfTotal_43() { assertEquals(4.5600000000000005f, NotePure.pdfTotal(listOf(1.86f,1.32f,1.34f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.86f,1.32f,1.34f)).size) }
    @Test fun pdfPage_43() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.86f,1.32f,1.34f)), 2.896f)) }
    @Test fun pdfTotal_44() { assertEquals(5.28f, NotePure.pdfTotal(listOf(0.75f,1.62f,1.85f,1.0f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(0.75f,1.62f,1.85f,1.0f)).size) }
    @Test fun pdfPage_44() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.75f,1.62f,1.85f,1.0f)), 0.487f)) }
    @Test fun pdfTotal_45() { assertEquals(0.0f, NotePure.pdfTotal(emptyList<Float>()), 0.001f); assertEquals(0, NotePure.pdfTops(emptyList<Float>()).size) }
    @Test fun pdfTotal_46() { assertEquals(5.32f, NotePure.pdfTotal(listOf(1.53f,1.05f,1.64f,1.04f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(1.53f,1.05f,1.64f,1.04f)).size) }
    @Test fun pdfPage_46() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.53f,1.05f,1.64f,1.04f)), 0.631f)) }
    @Test fun pdfTotal_47() { assertEquals(12.05f, NotePure.pdfTotal(listOf(1.72f,1.18f,1.11f,1.67f,1.89f,2.0f,0.71f,1.63f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(1.72f,1.18f,1.11f,1.67f,1.89f,2.0f,0.71f,1.63f)).size) }
    @Test fun pdfPage_47() { assertEquals(7, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.72f,1.18f,1.11f,1.67f,1.89f,2.0f,0.71f,1.63f)), 10.982f)) }
    @Test fun pdfTotal_48() { assertEquals(7.03f, NotePure.pdfTotal(listOf(1.42f,1.46f,1.64f,0.74f,1.12f,0.55f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(1.42f,1.46f,1.64f,0.74f,1.12f,0.55f)).size) }
    @Test fun pdfPage_48() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.42f,1.46f,1.64f,0.74f,1.12f,0.55f)), 4.003f)) }
    @Test fun pdfTotal_49() { assertEquals(1.35f, NotePure.pdfTotal(listOf(1.35f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.35f)).size) }
    @Test fun pdfPage_49() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.35f)), -0.005f)) }
    @Test fun pdfTotal_50() { assertEquals(10.229999999999999f, NotePure.pdfTotal(listOf(0.7f,0.87f,1.9f,0.58f,1.68f,1.58f,1.68f,1.1f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(0.7f,0.87f,1.9f,0.58f,1.68f,1.58f,1.68f,1.1f)).size) }
    @Test fun pdfPage_50() { assertEquals(4, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.7f,0.87f,1.9f,0.58f,1.68f,1.58f,1.68f,1.1f)), 5.336f)) }
    @Test fun pdfTotal_51() { assertEquals(1.2f, NotePure.pdfTotal(listOf(1.2f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.2f)).size) }
    @Test fun pdfPage_51() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.2f)), 0.611f)) }
    @Test fun pdfTotal_52() { assertEquals(9.6f, NotePure.pdfTotal(listOf(1.63f,1.23f,1.99f,1.76f,1.78f,1.11f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(1.63f,1.23f,1.99f,1.76f,1.78f,1.11f)).size) }
    @Test fun pdfPage_52() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.63f,1.23f,1.99f,1.76f,1.78f,1.11f)), 4.317f)) }
    @Test fun pdfTotal_53() { assertEquals(1.86f, NotePure.pdfTotal(listOf(1.86f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.86f)).size) }
    @Test fun pdfPage_53() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.86f)), 1.267f)) }
    @Test fun pdfTotal_54() { assertEquals(9.520000000000001f, NotePure.pdfTotal(listOf(1.28f,1.13f,0.54f,1.86f,0.94f,1.42f,1.15f,1.06f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(1.28f,1.13f,0.54f,1.86f,0.94f,1.42f,1.15f,1.06f)).size) }
    @Test fun pdfPage_54() { assertEquals(3, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.28f,1.13f,0.54f,1.86f,0.94f,1.42f,1.15f,1.06f)), 3.047f)) }
    @Test fun pdfTotal_55() { assertEquals(6.34f, NotePure.pdfTotal(listOf(1.82f,1.82f,0.87f,1.77f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(1.82f,1.82f,0.87f,1.77f)).size) }
    @Test fun pdfPage_55() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.82f,1.82f,0.87f,1.77f)), 1.4f)) }
    @Test fun pdfTotal_56() { assertEquals(8.6f, NotePure.pdfTotal(listOf(1.96f,1.21f,0.66f,1.86f,1.32f,1.49f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(1.96f,1.21f,0.66f,1.86f,1.32f,1.49f)).size) }
    @Test fun pdfPage_56() { assertEquals(5, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.96f,1.21f,0.66f,1.86f,1.32f,1.49f)), 8.996f)) }
    @Test fun pdfTotal_57() { assertEquals(2.0f, NotePure.pdfTotal(listOf(2.0f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(2.0f)).size) }
    @Test fun pdfPage_57() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(2.0f)), 2.058f)) }
    @Test fun pdfTotal_58() { assertEquals(7.169999999999999f, NotePure.pdfTotal(listOf(1.8f,1.13f,1.71f,0.83f,1.62f)), 0.001f); assertEquals(5, NotePure.pdfTops(listOf(1.8f,1.13f,1.71f,0.83f,1.62f)).size) }
    @Test fun pdfPage_58() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.8f,1.13f,1.71f,0.83f,1.62f)), 4.414f)) }
    @Test fun pdfTotal_59() { assertEquals(0.65f, NotePure.pdfTotal(listOf(0.65f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(0.65f)).size) }
    @Test fun pdfPage_59() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.65f)), 1.204f)) }
    @Test fun pdfTotal_60() { assertEquals(1.82f, NotePure.pdfTotal(listOf(1.82f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(1.82f)).size) }
    @Test fun pdfPage_60() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.82f)), 1.412f)) }
    @Test fun pdfTotal_61() { assertEquals(7.579999999999999f, NotePure.pdfTotal(listOf(0.5f,0.87f,0.95f,0.99f,0.59f,1.84f,1.72f)), 0.001f); assertEquals(7, NotePure.pdfTops(listOf(0.5f,0.87f,0.95f,0.99f,0.59f,1.84f,1.72f)).size) }
    @Test fun pdfPage_61() { assertEquals(3, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.5f,0.87f,0.95f,0.99f,0.59f,1.84f,1.72f)), 3.107f)) }
    @Test fun pdfTotal_62() { assertEquals(5.58f, NotePure.pdfTotal(listOf(1.54f,0.85f,0.96f,1.18f,0.97f)), 0.001f); assertEquals(5, NotePure.pdfTops(listOf(1.54f,0.85f,0.96f,1.18f,0.97f)).size) }
    @Test fun pdfPage_62() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.54f,0.85f,0.96f,1.18f,0.97f)), 1.796f)) }
    @Test fun pdfTotal_63() { assertEquals(3.8899999999999997f, NotePure.pdfTotal(listOf(1.9f,1.97f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(1.9f,1.97f)).size) }
    @Test fun pdfPage_63() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.9f,1.97f)), 2.048f)) }
    @Test fun pdfTotal_64() { assertEquals(4.17f, NotePure.pdfTotal(listOf(0.8f,1.79f,1.54f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(0.8f,1.79f,1.54f)).size) }
    @Test fun pdfPage_64() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.8f,1.79f,1.54f)), -0.166f)) }
    @Test fun pdfTotal_65() { assertEquals(6.660000000000001f, NotePure.pdfTotal(listOf(1.76f,1.03f,1.21f,0.76f,1.82f)), 0.001f); assertEquals(5, NotePure.pdfTops(listOf(1.76f,1.03f,1.21f,0.76f,1.82f)).size) }
    @Test fun pdfPage_65() { assertEquals(4, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.76f,1.03f,1.21f,0.76f,1.82f)), 7.622f)) }
    @Test fun pdfTotal_66() { assertEquals(4.109999999999999f, NotePure.pdfTotal(listOf(1.3f,0.85f,1.92f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.3f,0.85f,1.92f)).size) }
    @Test fun pdfPage_66() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.3f,0.85f,1.92f)), 4.977f)) }
    @Test fun pdfTotal_67() { assertEquals(0.96f, NotePure.pdfTotal(listOf(0.96f)), 0.001f); assertEquals(1, NotePure.pdfTops(listOf(0.96f)).size) }
    @Test fun pdfPage_67() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.96f)), 1.512f)) }
    @Test fun pdfTotal_68() { assertEquals(5.67f, NotePure.pdfTotal(listOf(1.8f,1.57f,0.7f,1.54f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(1.8f,1.57f,0.7f,1.54f)).size) }
    @Test fun pdfPage_68() { assertEquals(3, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.8f,1.57f,0.7f,1.54f)), 6.224f)) }
    @Test fun pdfTotal_69() { assertEquals(8.48f, NotePure.pdfTotal(listOf(1.12f,0.75f,1.79f,0.68f,1.54f,0.9f,1.58f)), 0.001f); assertEquals(7, NotePure.pdfTops(listOf(1.12f,0.75f,1.79f,0.68f,1.54f,0.9f,1.58f)).size) }
    @Test fun pdfPage_69() { assertEquals(4, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.12f,0.75f,1.79f,0.68f,1.54f,0.9f,1.58f)), 4.504f)) }
    @Test fun pdfTotal_70() { assertEquals(6.13f, NotePure.pdfTotal(listOf(1.69f,1.06f,1.49f,1.83f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(1.69f,1.06f,1.49f,1.83f)).size) }
    @Test fun pdfPage_70() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.69f,1.06f,1.49f,1.83f)), 4.001f)) }
    @Test fun pdfTotal_71() { assertEquals(4.62f, NotePure.pdfTotal(listOf(1.97f,1.84f,0.77f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.97f,1.84f,0.77f)).size) }
    @Test fun pdfPage_71() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.97f,1.84f,0.77f)), 0.883f)) }
    @Test fun pdfTotal_72() { assertEquals(2.11f, NotePure.pdfTotal(listOf(1.46f,0.63f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(1.46f,0.63f)).size) }
    @Test fun pdfPage_72() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.46f,0.63f)), 3.049f)) }
    @Test fun pdfTotal_73() { assertEquals(8.81f, NotePure.pdfTotal(listOf(1.88f,0.61f,1.86f,0.51f,1.38f,1.31f,1.14f)), 0.001f); assertEquals(7, NotePure.pdfTops(listOf(1.88f,0.61f,1.86f,0.51f,1.38f,1.31f,1.14f)).size) }
    @Test fun pdfPage_73() { assertEquals(4, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.88f,0.61f,1.86f,0.51f,1.38f,1.31f,1.14f)), 5.362f)) }
    @Test fun pdfTotal_74() { assertEquals(2.58f, NotePure.pdfTotal(listOf(0.93f,1.63f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(0.93f,1.63f)).size) }
    @Test fun pdfPage_74() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.93f,1.63f)), 0.503f)) }
    @Test fun pdfTotal_75() { assertEquals(4.62f, NotePure.pdfTotal(listOf(1.6f,0.54f,1.69f,0.73f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(1.6f,0.54f,1.69f,0.73f)).size) }
    @Test fun pdfPage_75() { assertEquals(3, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.6f,0.54f,1.69f,0.73f)), 4.995f)) }
    @Test fun pdfTotal_76() { assertEquals(8.57f, NotePure.pdfTotal(listOf(1.87f,1.38f,0.5f,1.84f,0.59f,0.6f,1.67f)), 0.001f); assertEquals(7, NotePure.pdfTops(listOf(1.87f,1.38f,0.5f,1.84f,0.59f,0.6f,1.67f)).size) }
    @Test fun pdfPage_76() { assertEquals(6, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.87f,1.38f,0.5f,1.84f,0.59f,0.6f,1.67f)), 8.661f)) }
    @Test fun pdfTotal_77() { assertEquals(7.550000000000001f, NotePure.pdfTotal(listOf(1.49f,1.67f,1.28f,1.26f,1.77f)), 0.001f); assertEquals(5, NotePure.pdfTops(listOf(1.49f,1.67f,1.28f,1.26f,1.77f)).size) }
    @Test fun pdfPage_77() { assertEquals(3, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.49f,1.67f,1.28f,1.26f,1.77f)), 5.693f)) }
    @Test fun pdfTotal_78() { assertEquals(10.75f, NotePure.pdfTotal(listOf(1.62f,1.3f,1.39f,1.66f,0.67f,1.15f,1.5f,1.32f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(1.62f,1.3f,1.39f,1.66f,0.67f,1.15f,1.5f,1.32f)).size) }
    @Test fun pdfPage_78() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.62f,1.3f,1.39f,1.66f,0.67f,1.15f,1.5f,1.32f)), 2.638f)) }
    @Test fun pdfTotal_79() { assertEquals(4.03f, NotePure.pdfTotal(listOf(0.89f,1.32f,1.78f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(0.89f,1.32f,1.78f)).size) }
    @Test fun pdfPage_79() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.89f,1.32f,1.78f)), 2.836f)) }
    @Test fun pdfTotal_80() { assertEquals(4.94f, NotePure.pdfTotal(listOf(0.55f,1.4f,1.57f,1.36f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(0.55f,1.4f,1.57f,1.36f)).size) }
    @Test fun pdfPage_80() { assertEquals(3, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.55f,1.4f,1.57f,1.36f)), 5.121f)) }
    @Test fun pdfTotal_81() { assertEquals(2.42f, NotePure.pdfTotal(listOf(0.99f,1.41f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(0.99f,1.41f)).size) }
    @Test fun pdfPage_81() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.99f,1.41f)), 1.886f)) }
    @Test fun pdfTotal_82() { assertEquals(6.720000000000001f, NotePure.pdfTotal(listOf(1.26f,1.58f,1.79f,0.55f,0.67f,0.77f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(1.26f,1.58f,1.79f,0.55f,0.67f,0.77f)).size) }
    @Test fun pdfPage_82() { assertEquals(3, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.26f,1.58f,1.79f,0.55f,0.67f,0.77f)), 4.76f)) }
    @Test fun pdfTotal_83() { assertEquals(3.1899999999999995f, NotePure.pdfTotal(listOf(1.43f,0.58f,1.14f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.43f,0.58f,1.14f)).size) }
    @Test fun pdfPage_83() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.43f,0.58f,1.14f)), 2.763f)) }
    @Test fun pdfTotal_84() { assertEquals(10.65f, NotePure.pdfTotal(listOf(1.67f,1.65f,1.25f,1.48f,1.27f,1.07f,0.87f,1.25f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(1.67f,1.65f,1.25f,1.48f,1.27f,1.07f,0.87f,1.25f)).size) }
    @Test fun pdfPage_84() { assertEquals(5, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.67f,1.65f,1.25f,1.48f,1.27f,1.07f,0.87f,1.25f)), 7.507f)) }
    @Test fun pdfTotal_85() { assertEquals(7.450000000000001f, NotePure.pdfTotal(listOf(0.59f,1.12f,1.05f,0.82f,1.96f,0.56f,1.23f)), 0.001f); assertEquals(7, NotePure.pdfTops(listOf(0.59f,1.12f,1.05f,0.82f,1.96f,0.56f,1.23f)).size) }
    @Test fun pdfPage_85() { assertEquals(6, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.59f,1.12f,1.05f,0.82f,1.96f,0.56f,1.23f)), 6.313f)) }
    @Test fun pdfTotal_86() { assertEquals(1.92f, NotePure.pdfTotal(listOf(0.72f,1.18f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(0.72f,1.18f)).size) }
    @Test fun pdfPage_86() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.72f,1.18f)), 2.048f)) }
    @Test fun pdfTotal_87() { assertEquals(0.0f, NotePure.pdfTotal(emptyList<Float>()), 0.001f); assertEquals(0, NotePure.pdfTops(emptyList<Float>()).size) }
    @Test fun pdfTotal_88() { assertEquals(0.0f, NotePure.pdfTotal(emptyList<Float>()), 0.001f); assertEquals(0, NotePure.pdfTops(emptyList<Float>()).size) }
    @Test fun pdfTotal_89() { assertEquals(3.0800000000000005f, NotePure.pdfTotal(listOf(1.11f,1.29f,0.64f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.11f,1.29f,0.64f)).size) }
    @Test fun pdfPage_89() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.11f,1.29f,0.64f)), 2.047f)) }
    @Test fun pdfTotal_90() { assertEquals(8.49f, NotePure.pdfTotal(listOf(1.14f,0.61f,0.55f,1.99f,1.64f,1.6f,0.84f)), 0.001f); assertEquals(7, NotePure.pdfTops(listOf(1.14f,0.61f,0.55f,1.99f,1.64f,1.6f,0.84f)).size) }
    @Test fun pdfPage_90() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.14f,0.61f,0.55f,1.99f,1.64f,1.6f,0.84f)), 2.03f)) }
    @Test fun pdfTotal_91() { assertEquals(10.11f, NotePure.pdfTotal(listOf(1.78f,1.13f,0.63f,0.84f,0.96f,1.92f,1.88f,0.83f)), 0.001f); assertEquals(8, NotePure.pdfTops(listOf(1.78f,1.13f,0.63f,0.84f,0.96f,1.92f,1.88f,0.83f)).size) }
    @Test fun pdfPage_91() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.78f,1.13f,0.63f,0.84f,0.96f,1.92f,1.88f,0.83f)), 1.362f)) }
    @Test fun pdfTotal_92() { assertEquals(0.0f, NotePure.pdfTotal(emptyList<Float>()), 0.001f); assertEquals(0, NotePure.pdfTops(emptyList<Float>()).size) }
    @Test fun pdfTotal_93() { assertEquals(7.790000000000001f, NotePure.pdfTotal(listOf(1.35f,1.87f,1.83f,1.89f,0.77f)), 0.001f); assertEquals(5, NotePure.pdfTops(listOf(1.35f,1.87f,1.83f,1.89f,0.77f)).size) }
    @Test fun pdfPage_93() { assertEquals(4, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.35f,1.87f,1.83f,1.89f,0.77f)), 7.489f)) }
    @Test fun pdfTotal_94() { assertEquals(3.6f, NotePure.pdfTotal(listOf(1.07f,1.67f,0.82f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.07f,1.67f,0.82f)).size) }
    @Test fun pdfPage_94() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.07f,1.67f,0.82f)), 1.272f)) }
    @Test fun pdfTotal_95() { assertEquals(3.42f, NotePure.pdfTotal(listOf(1.69f,1.71f)), 0.001f); assertEquals(2, NotePure.pdfTops(listOf(1.69f,1.71f)).size) }
    @Test fun pdfPage_95() { assertEquals(1, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.69f,1.71f)), 1.863f)) }
    @Test fun pdfTotal_96() { assertEquals(7.76f, NotePure.pdfTotal(listOf(0.82f,1.2f,0.96f,1.17f,1.99f,1.52f)), 0.001f); assertEquals(6, NotePure.pdfTops(listOf(0.82f,1.2f,0.96f,1.17f,1.99f,1.52f)).size) }
    @Test fun pdfPage_96() { assertEquals(5, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.82f,1.2f,0.96f,1.17f,1.99f,1.52f)), 7.489f)) }
    @Test fun pdfTotal_97() { assertEquals(3.05f, NotePure.pdfTotal(listOf(1.31f,1.13f,0.57f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(1.31f,1.13f,0.57f)).size) }
    @Test fun pdfPage_97() { assertEquals(0, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.31f,1.13f,0.57f)), 0.758f)) }
    @Test fun pdfTotal_98() { assertEquals(5.65f, NotePure.pdfTotal(listOf(1.43f,1.28f,1.61f,1.27f)), 0.001f); assertEquals(4, NotePure.pdfTops(listOf(1.43f,1.28f,1.61f,1.27f)).size) }
    @Test fun pdfPage_98() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(1.43f,1.28f,1.61f,1.27f)), 3.557f)) }
    @Test fun pdfTotal_99() { assertEquals(2.71f, NotePure.pdfTotal(listOf(0.9f,1.04f,0.73f)), 0.001f); assertEquals(3, NotePure.pdfTops(listOf(0.9f,1.04f,0.73f)).size) }
    @Test fun pdfPage_99() { assertEquals(2, NotePure.pdfPageAt(NotePure.pdfTops(listOf(0.9f,1.04f,0.73f)), 3.443f)) }
    @Test fun moveImg_0() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.22f, 2.17f, 0.33f, 1.84f), -0.96f, -0.71f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.46f, m.y, 0.001f) }
    @Test fun scaleImg_0() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.22f, 2.17f, 0.33f, 1.84f), 1.34f); assertEquals(0.44220000000000004f, m.w, 0.001f); assertEquals(0.22f, m.x, 0.001f) }
    @Test fun moveImg_1() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.05f, 0.98f, 0.36f, 1.61f), 0.04f, -1.78f); assertEquals(0.09f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_1() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.05f, 0.98f, 0.36f, 1.61f), 1.36f); assertEquals(0.48960000000000004f, m.w, 0.001f); assertEquals(0.05f, m.x, 0.001f) }
    @Test fun moveImg_2() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.14f, 0.45f, 0.11f, 1.31f), -0.94f, -0.75f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_2() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.14f, 0.45f, 0.11f, 1.31f), 1.44f); assertEquals(0.15839999999999999f, m.w, 0.001f); assertEquals(0.14f, m.x, 0.001f) }
    @Test fun moveImg_3() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.33f, 2.12f, 0.14f, 0.74f), 0.45f, 0.66f); assertEquals(0.78f, m.x, 0.001f); assertEquals(2.7800000000000002f, m.y, 0.001f) }
    @Test fun scaleImg_3() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.33f, 2.12f, 0.14f, 0.74f), 0.7f); assertEquals(0.1f, m.w, 0.001f); assertEquals(0.33f, m.x, 0.001f) }
    @Test fun moveImg_4() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.12f, 2.14f, 0.18f, 0.99f), -0.23f, 1.46f); assertEquals(0.0f, m.x, 0.001f); assertEquals(3.6f, m.y, 0.001f) }
    @Test fun scaleImg_4() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.12f, 2.14f, 0.18f, 0.99f), 0.91f); assertEquals(0.1638f, m.w, 0.001f); assertEquals(0.12f, m.x, 0.001f) }
    @Test fun moveImg_5() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.18f, 0.65f, 0.2f, 0.37f), -0.95f, 0.52f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.17f, m.y, 0.001f) }
    @Test fun scaleImg_5() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.18f, 0.65f, 0.2f, 0.37f), 1.83f); assertEquals(0.36600000000000005f, m.w, 0.001f); assertEquals(0.18f, m.x, 0.001f) }
    @Test fun moveImg_6() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.49f, 0.89f, 0.39f, 1.44f), 0.84f, -1.14f); assertEquals(0.61f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_6() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.49f, 0.89f, 0.39f, 1.44f), 2.16f); assertEquals(0.8424f, m.w, 0.001f); assertEquals(0.15759999999999996f, m.x, 0.001f) }
    @Test fun moveImg_7() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.4f, 2.61f, 0.39f, 0.7f), 0.27f, -1.64f); assertEquals(0.61f, m.x, 0.001f); assertEquals(0.97f, m.y, 0.001f) }
    @Test fun scaleImg_7() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.4f, 2.61f, 0.39f, 0.7f), 1.45f); assertEquals(0.5655f, m.w, 0.001f); assertEquals(0.4f, m.x, 0.001f) }
    @Test fun moveImg_8() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.24f, 1.15f, 0.12f, 0.86f), -0.01f, -0.88f); assertEquals(0.22999999999999998f, m.x, 0.001f); assertEquals(0.2699999999999999f, m.y, 0.001f) }
    @Test fun scaleImg_8() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.24f, 1.15f, 0.12f, 0.86f), 0.73f); assertEquals(0.1f, m.w, 0.001f); assertEquals(0.24f, m.x, 0.001f) }
    @Test fun moveImg_9() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.24f, 0.5f, 0.24f, 1.43f), -0.52f, -1.63f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_9() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.24f, 0.5f, 0.24f, 1.43f), 1.22f); assertEquals(0.2928f, m.w, 0.001f); assertEquals(0.24f, m.x, 0.001f) }
    @Test fun moveImg_10() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.25f, 1.75f, 0.15f, 1.49f), 0.11f, 0.8f); assertEquals(0.36f, m.x, 0.001f); assertEquals(2.55f, m.y, 0.001f) }
    @Test fun scaleImg_10() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.25f, 1.75f, 0.15f, 1.49f), 0.36f); assertEquals(0.1f, m.w, 0.001f); assertEquals(0.25f, m.x, 0.001f) }
    @Test fun moveImg_11() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.23f, 0.19f, 0.21f, 0.99f), -0.89f, -0.02f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.17f, m.y, 0.001f) }
    @Test fun scaleImg_11() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.23f, 0.19f, 0.21f, 0.99f), 1.88f); assertEquals(0.3948f, m.w, 0.001f); assertEquals(0.23f, m.x, 0.001f) }
    @Test fun moveImg_12() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.28f, 0.76f, 0.2f, 0.34f), -0.31f, 1.57f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.33f, m.y, 0.001f) }
    @Test fun scaleImg_12() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.28f, 0.76f, 0.2f, 0.34f), 1.83f); assertEquals(0.36600000000000005f, m.w, 0.001f); assertEquals(0.28f, m.x, 0.001f) }
    @Test fun moveImg_13() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.16f, 0.56f, 0.3f, 1.1f), 0.23f, 1.82f); assertEquals(0.39f, m.x, 0.001f); assertEquals(2.38f, m.y, 0.001f) }
    @Test fun scaleImg_13() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.16f, 0.56f, 0.3f, 1.1f), 1.28f); assertEquals(0.384f, m.w, 0.001f); assertEquals(0.16f, m.x, 0.001f) }
    @Test fun moveImg_14() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.35f, 2.31f, 0.38f, 1.37f), 0.24f, -0.36f); assertEquals(0.59f, m.x, 0.001f); assertEquals(1.9500000000000002f, m.y, 0.001f) }
    @Test fun scaleImg_14() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.35f, 2.31f, 0.38f, 1.37f), 1.42f); assertEquals(0.5396f, m.w, 0.001f); assertEquals(0.35f, m.x, 0.001f) }
    @Test fun moveImg_15() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.17f, 2.64f, 0.35f, 0.95f), 0.82f, -1.85f); assertEquals(0.65f, m.x, 0.001f); assertEquals(0.79f, m.y, 0.001f) }
    @Test fun scaleImg_15() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.17f, 2.64f, 0.35f, 0.95f), 0.67f); assertEquals(0.2345f, m.w, 0.001f); assertEquals(0.17f, m.x, 0.001f) }
    @Test fun moveImg_16() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.3f, 1.08f, 0.19f, 1.96f), -0.7f, -1.23f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_16() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.3f, 1.08f, 0.19f, 1.96f), 0.92f); assertEquals(0.1748f, m.w, 0.001f); assertEquals(0.3f, m.x, 0.001f) }
    @Test fun moveImg_17() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.41f, 0.0f, 0.17f, 1.22f), -0.21f, -1.04f); assertEquals(0.19999999999999998f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_17() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.41f, 0.0f, 0.17f, 1.22f), 1.63f); assertEquals(0.2771f, m.w, 0.001f); assertEquals(0.41f, m.x, 0.001f) }
    @Test fun moveImg_18() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.39f, 1.87f, 0.26f, 1.25f), 0.66f, 1.88f); assertEquals(0.74f, m.x, 0.001f); assertEquals(3.75f, m.y, 0.001f) }
    @Test fun scaleImg_18() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.39f, 1.87f, 0.26f, 1.25f), 1.2f); assertEquals(0.312f, m.w, 0.001f); assertEquals(0.39f, m.x, 0.001f) }
    @Test fun moveImg_19() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.21f, 0.94f, 0.37f, 1.52f), 0.39f, 0.75f); assertEquals(0.6f, m.x, 0.001f); assertEquals(1.69f, m.y, 0.001f) }
    @Test fun scaleImg_19() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.21f, 0.94f, 0.37f, 1.52f), 2.9f); assertEquals(1.0f, m.w, 0.001f); assertEquals(0.0f, m.x, 0.001f) }
    @Test fun moveImg_20() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.49f, 1.86f, 0.15f, 1.13f), 0.13f, -0.52f); assertEquals(0.62f, m.x, 0.001f); assertEquals(1.34f, m.y, 0.001f) }
    @Test fun scaleImg_20() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.49f, 1.86f, 0.15f, 1.13f), 1.07f); assertEquals(0.1605f, m.w, 0.001f); assertEquals(0.49f, m.x, 0.001f) }
    @Test fun moveImg_21() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.45f, 0.71f, 0.26f, 0.72f), -0.35f, -1.29f); assertEquals(0.10000000000000003f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_21() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.45f, 0.71f, 0.26f, 0.72f), 1.69f); assertEquals(0.4394f, m.w, 0.001f); assertEquals(0.45f, m.x, 0.001f) }
    @Test fun moveImg_22() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.08f, 0.21f, 0.12f, 0.47f), 0.41f, -1.55f); assertEquals(0.49f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_22() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.08f, 0.21f, 0.12f, 0.47f), 1.52f); assertEquals(0.1824f, m.w, 0.001f); assertEquals(0.08f, m.x, 0.001f) }
    @Test fun moveImg_23() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.46f, 0.49f, 0.24f, 1.77f), 0.74f, -1.79f); assertEquals(0.76f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_23() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.46f, 0.49f, 0.24f, 1.77f), 0.99f); assertEquals(0.23759999999999998f, m.w, 0.001f); assertEquals(0.46f, m.x, 0.001f) }
    @Test fun moveImg_24() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.3f, 1.18f, 0.34f, 1.52f), -0.5f, 0.86f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.04f, m.y, 0.001f) }
    @Test fun scaleImg_24() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.3f, 1.18f, 0.34f, 1.52f), 1.18f); assertEquals(0.4012f, m.w, 0.001f); assertEquals(0.3f, m.x, 0.001f) }
    @Test fun moveImg_25() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.2f, 2.53f, 0.33f, 1.71f), 0.13f, -0.32f); assertEquals(0.33f, m.x, 0.001f); assertEquals(2.21f, m.y, 0.001f) }
    @Test fun scaleImg_25() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.2f, 2.53f, 0.33f, 1.71f), 2.21f); assertEquals(0.7293000000000001f, m.w, 0.001f); assertEquals(0.2f, m.x, 0.001f) }
    @Test fun moveImg_26() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.37f, 2.4f, 0.35f, 0.51f), -0.25f, 0.68f); assertEquals(0.12f, m.x, 0.001f); assertEquals(3.08f, m.y, 0.001f) }
    @Test fun scaleImg_26() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.37f, 2.4f, 0.35f, 0.51f), 0.92f); assertEquals(0.322f, m.w, 0.001f); assertEquals(0.37f, m.x, 0.001f) }
    @Test fun moveImg_27() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.11f, 1.76f, 0.1f, 1.9f), 0.94f, -1.47f); assertEquals(0.9f, m.x, 0.001f); assertEquals(0.29000000000000004f, m.y, 0.001f) }
    @Test fun scaleImg_27() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.11f, 1.76f, 0.1f, 1.9f), 2.16f); assertEquals(0.21600000000000003f, m.w, 0.001f); assertEquals(0.11f, m.x, 0.001f) }
    @Test fun moveImg_28() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.25f, 1.19f, 0.29f, 1.89f), 0.98f, -1.81f); assertEquals(0.71f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_28() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.25f, 1.19f, 0.29f, 1.89f), 2.23f); assertEquals(0.6466999999999999f, m.w, 0.001f); assertEquals(0.25f, m.x, 0.001f) }
    @Test fun moveImg_29() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.07f, 0.86f, 0.11f, 1.54f), 0.99f, -1.52f); assertEquals(0.89f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_29() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.07f, 0.86f, 0.11f, 1.54f), 1.19f); assertEquals(0.1309f, m.w, 0.001f); assertEquals(0.07f, m.x, 0.001f) }
    @Test fun moveImg_30() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.02f, 1.45f, 0.26f, 0.93f), -0.38f, 1.2f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.65f, m.y, 0.001f) }
    @Test fun scaleImg_30() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.02f, 1.45f, 0.26f, 0.93f), 2.56f); assertEquals(0.6656000000000001f, m.w, 0.001f); assertEquals(0.02f, m.x, 0.001f) }
    @Test fun moveImg_31() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.17f, 1.85f, 0.22f, 1.6f), 0.96f, -0.44f); assertEquals(0.78f, m.x, 0.001f); assertEquals(1.4100000000000001f, m.y, 0.001f) }
    @Test fun scaleImg_31() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.17f, 1.85f, 0.22f, 1.6f), 2.17f); assertEquals(0.4774f, m.w, 0.001f); assertEquals(0.17f, m.x, 0.001f) }
    @Test fun moveImg_32() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.33f, 0.44f, 0.34f, 0.6f), -0.79f, 1.73f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.17f, m.y, 0.001f) }
    @Test fun scaleImg_32() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.33f, 0.44f, 0.34f, 0.6f), 0.98f); assertEquals(0.3332f, m.w, 0.001f); assertEquals(0.33f, m.x, 0.001f) }
    @Test fun moveImg_33() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.29f, 0.97f, 0.14f, 0.33f), 0.13f, -1.43f); assertEquals(0.42f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_33() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.29f, 0.97f, 0.14f, 0.33f), 1.99f); assertEquals(0.2786f, m.w, 0.001f); assertEquals(0.29f, m.x, 0.001f) }
    @Test fun moveImg_34() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.16f, 1.45f, 0.17f, 0.92f), -0.48f, -1.8f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_34() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.16f, 1.45f, 0.17f, 0.92f), 0.47f); assertEquals(0.1f, m.w, 0.001f); assertEquals(0.16f, m.x, 0.001f) }
    @Test fun moveImg_35() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.54f, 0.24f, 0.19f, 0.61f), -0.03f, 1.99f); assertEquals(0.51f, m.x, 0.001f); assertEquals(2.23f, m.y, 0.001f) }
    @Test fun scaleImg_35() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.54f, 0.24f, 0.19f, 0.61f), 0.85f); assertEquals(0.1615f, m.w, 0.001f); assertEquals(0.54f, m.x, 0.001f) }
    @Test fun moveImg_36() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.52f, 1.24f, 0.25f, 1.67f), -0.21f, -1.77f); assertEquals(0.31000000000000005f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_36() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.52f, 1.24f, 0.25f, 1.67f), 1.79f); assertEquals(0.4475f, m.w, 0.001f); assertEquals(0.52f, m.x, 0.001f) }
    @Test fun moveImg_37() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.39f, 0.83f, 0.29f, 1.9f), 0.73f, 1.98f); assertEquals(0.71f, m.x, 0.001f); assertEquals(2.81f, m.y, 0.001f) }
    @Test fun scaleImg_37() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.39f, 0.83f, 0.29f, 1.9f), 1.5f); assertEquals(0.43499999999999994f, m.w, 0.001f); assertEquals(0.39f, m.x, 0.001f) }
    @Test fun moveImg_38() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.5f, 0.53f, 0.32f, 0.35f), -0.66f, -1.52f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_38() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.5f, 0.53f, 0.32f, 0.35f), 0.5f); assertEquals(0.16f, m.w, 0.001f); assertEquals(0.5f, m.x, 0.001f) }
    @Test fun moveImg_39() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.22f, 0.93f, 0.33f, 1.17f), -0.98f, -1.16f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_39() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.22f, 0.93f, 0.33f, 1.17f), 2.89f); assertEquals(0.9537000000000001f, m.w, 0.001f); assertEquals(0.0462999999999999f, m.x, 0.001f) }
    @Test fun moveImg_40() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.01f, 2.43f, 0.26f, 1.65f), 0.47f, -0.4f); assertEquals(0.48f, m.x, 0.001f); assertEquals(2.0300000000000002f, m.y, 0.001f) }
    @Test fun scaleImg_40() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.01f, 2.43f, 0.26f, 1.65f), 2.47f); assertEquals(0.6422000000000001f, m.w, 0.001f); assertEquals(0.01f, m.x, 0.001f) }
    @Test fun moveImg_41() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.5f, 2.96f, 0.33f, 0.47f), 0.9f, -0.39f); assertEquals(0.6699999999999999f, m.x, 0.001f); assertEquals(2.57f, m.y, 0.001f) }
    @Test fun scaleImg_41() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.5f, 2.96f, 0.33f, 0.47f), 2.2f); assertEquals(0.7260000000000001f, m.w, 0.001f); assertEquals(0.2739999999999999f, m.x, 0.001f) }
    @Test fun moveImg_42() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.15f, 0.07f, 0.37f, 1.28f), -0.55f, -0.45f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_42() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.15f, 0.07f, 0.37f, 1.28f), 1.3f); assertEquals(0.481f, m.w, 0.001f); assertEquals(0.15f, m.x, 0.001f) }
    @Test fun moveImg_43() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.39f, 1.09f, 0.34f, 1.38f), -0.29f, -0.88f); assertEquals(0.10000000000000003f, m.x, 0.001f); assertEquals(0.21000000000000008f, m.y, 0.001f) }
    @Test fun scaleImg_43() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.39f, 1.09f, 0.34f, 1.38f), 2.74f); assertEquals(0.9316000000000001f, m.w, 0.001f); assertEquals(0.0683999999999999f, m.x, 0.001f) }
    @Test fun moveImg_44() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.19f, 1.0f, 0.13f, 1.56f), -0.58f, 0.97f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.97f, m.y, 0.001f) }
    @Test fun scaleImg_44() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.19f, 1.0f, 0.13f, 1.56f), 1.77f); assertEquals(0.2301f, m.w, 0.001f); assertEquals(0.19f, m.x, 0.001f) }
    @Test fun moveImg_45() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.41f, 0.32f, 0.15f, 0.54f), -0.3f, -0.28f); assertEquals(0.10999999999999999f, m.x, 0.001f); assertEquals(0.03999999999999998f, m.y, 0.001f) }
    @Test fun scaleImg_45() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.41f, 0.32f, 0.15f, 0.54f), 0.33f); assertEquals(0.1f, m.w, 0.001f); assertEquals(0.41f, m.x, 0.001f) }
    @Test fun moveImg_46() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.3f, 0.96f, 0.22f, 1.21f), 0.9f, -1.18f); assertEquals(0.78f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_46() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.3f, 0.96f, 0.22f, 1.21f), 2.68f); assertEquals(0.5896f, m.w, 0.001f); assertEquals(0.3f, m.x, 0.001f) }
    @Test fun moveImg_47() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.19f, 0.33f, 0.33f, 1.98f), -0.14f, 1.85f); assertEquals(0.04999999999999999f, m.x, 0.001f); assertEquals(2.18f, m.y, 0.001f) }
    @Test fun scaleImg_47() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.19f, 0.33f, 0.33f, 1.98f), 0.89f); assertEquals(0.2937f, m.w, 0.001f); assertEquals(0.19f, m.x, 0.001f) }
    @Test fun moveImg_48() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.24f, 0.53f, 0.31f, 0.76f), 0.35f, 1.79f); assertEquals(0.59f, m.x, 0.001f); assertEquals(2.3200000000000003f, m.y, 0.001f) }
    @Test fun scaleImg_48() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.24f, 0.53f, 0.31f, 0.76f), 1.17f); assertEquals(0.36269999999999997f, m.w, 0.001f); assertEquals(0.24f, m.x, 0.001f) }
    @Test fun moveImg_49() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.11f, 2.97f, 0.21f, 0.55f), 0.27f, -0.49f); assertEquals(0.38f, m.x, 0.001f); assertEquals(2.4800000000000004f, m.y, 0.001f) }
    @Test fun scaleImg_49() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.11f, 2.97f, 0.21f, 0.55f), 2.04f); assertEquals(0.4284f, m.w, 0.001f); assertEquals(0.11f, m.x, 0.001f) }
    @Test fun moveImg_50() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.13f, 2.66f, 0.28f, 1.76f), 0.26f, 0.02f); assertEquals(0.39f, m.x, 0.001f); assertEquals(2.68f, m.y, 0.001f) }
    @Test fun scaleImg_50() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.13f, 2.66f, 0.28f, 1.76f), 1.83f); assertEquals(0.5124000000000001f, m.w, 0.001f); assertEquals(0.13f, m.x, 0.001f) }
    @Test fun moveImg_51() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.07f, 2.07f, 0.35f, 1.07f), 0.33f, -0.32f); assertEquals(0.4f, m.x, 0.001f); assertEquals(1.7499999999999998f, m.y, 0.001f) }
    @Test fun scaleImg_51() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.07f, 2.07f, 0.35f, 1.07f), 1.34f); assertEquals(0.469f, m.w, 0.001f); assertEquals(0.07f, m.x, 0.001f) }
    @Test fun moveImg_52() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.14f, 1.72f, 0.28f, 1.18f), -0.94f, 0.51f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.23f, m.y, 0.001f) }
    @Test fun scaleImg_52() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.14f, 1.72f, 0.28f, 1.18f), 1.51f); assertEquals(0.42280000000000006f, m.w, 0.001f); assertEquals(0.14f, m.x, 0.001f) }
    @Test fun moveImg_53() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.36f, 2.79f, 0.28f, 0.56f), -0.06f, 1.97f); assertEquals(0.3f, m.x, 0.001f); assertEquals(4.76f, m.y, 0.001f) }
    @Test fun scaleImg_53() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.36f, 2.79f, 0.28f, 0.56f), 2.29f); assertEquals(0.6412000000000001f, m.w, 0.001f); assertEquals(0.3587999999999999f, m.x, 0.001f) }
    @Test fun moveImg_54() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.19f, 2.97f, 0.32f, 0.98f), 0.73f, -1.49f); assertEquals(0.6799999999999999f, m.x, 0.001f); assertEquals(1.4800000000000002f, m.y, 0.001f) }
    @Test fun scaleImg_54() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.19f, 2.97f, 0.32f, 0.98f), 2.97f); assertEquals(0.9504000000000001f, m.w, 0.001f); assertEquals(0.049599999999999866f, m.x, 0.001f) }
    @Test fun moveImg_55() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.29f, 2.52f, 0.17f, 1.4f), 0.88f, 1.32f); assertEquals(0.83f, m.x, 0.001f); assertEquals(3.84f, m.y, 0.001f) }
    @Test fun scaleImg_55() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.29f, 2.52f, 0.17f, 1.4f), 2.45f); assertEquals(0.41650000000000004f, m.w, 0.001f); assertEquals(0.29f, m.x, 0.001f) }
    @Test fun moveImg_56() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.31f, 0.19f, 0.4f, 1.78f), 0.42f, -1.0f); assertEquals(0.6f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_56() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.31f, 0.19f, 0.4f, 1.78f), 2.48f); assertEquals(0.992f, m.w, 0.001f); assertEquals(0.008000000000000007f, m.x, 0.001f) }
    @Test fun moveImg_57() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.27f, 2.6f, 0.26f, 0.63f), -0.44f, 0.57f); assertEquals(0.0f, m.x, 0.001f); assertEquals(3.17f, m.y, 0.001f) }
    @Test fun scaleImg_57() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.27f, 2.6f, 0.26f, 0.63f), 0.5f); assertEquals(0.13f, m.w, 0.001f); assertEquals(0.27f, m.x, 0.001f) }
    @Test fun moveImg_58() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.33f, 1.47f, 0.34f, 0.71f), 0.6f, 1.42f); assertEquals(0.6599999999999999f, m.x, 0.001f); assertEquals(2.8899999999999997f, m.y, 0.001f) }
    @Test fun scaleImg_58() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.33f, 1.47f, 0.34f, 0.71f), 2.38f); assertEquals(0.8092f, m.w, 0.001f); assertEquals(0.19079999999999997f, m.x, 0.001f) }
    @Test fun moveImg_59() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.33f, 2.39f, 0.37f, 0.56f), -0.27f, -1.6f); assertEquals(0.06f, m.x, 0.001f); assertEquals(0.79f, m.y, 0.001f) }
    @Test fun scaleImg_59() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.33f, 2.39f, 0.37f, 0.56f), 0.4f); assertEquals(0.148f, m.w, 0.001f); assertEquals(0.33f, m.x, 0.001f) }
    @Test fun moveImg_60() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.21f, 2.5f, 0.36f, 0.5f), -0.64f, -0.45f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.05f, m.y, 0.001f) }
    @Test fun scaleImg_60() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.21f, 2.5f, 0.36f, 0.5f), 2.59f); assertEquals(0.9323999999999999f, m.w, 0.001f); assertEquals(0.0676000000000001f, m.x, 0.001f) }
    @Test fun moveImg_61() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.37f, 0.22f, 0.37f, 1.98f), -0.59f, 0.52f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.74f, m.y, 0.001f) }
    @Test fun scaleImg_61() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.37f, 0.22f, 0.37f, 1.98f), 2.67f); assertEquals(0.9879f, m.w, 0.001f); assertEquals(0.0121f, m.x, 0.001f) }
    @Test fun moveImg_62() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.44f, 2.01f, 0.16f, 1.03f), -0.97f, -0.64f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.3699999999999997f, m.y, 0.001f) }
    @Test fun scaleImg_62() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.44f, 2.01f, 0.16f, 1.03f), 1.15f); assertEquals(0.184f, m.w, 0.001f); assertEquals(0.44f, m.x, 0.001f) }
    @Test fun moveImg_63() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.38f, 1.81f, 0.18f, 1.48f), -0.64f, -1.49f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.32000000000000006f, m.y, 0.001f) }
    @Test fun scaleImg_63() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.38f, 1.81f, 0.18f, 1.48f), 2.17f); assertEquals(0.39059999999999995f, m.w, 0.001f); assertEquals(0.38f, m.x, 0.001f) }
    @Test fun moveImg_64() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.28f, 0.35f, 0.14f, 1.9f), 0.22f, -0.57f); assertEquals(0.5f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_64() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.28f, 0.35f, 0.14f, 1.9f), 0.83f); assertEquals(0.11620000000000001f, m.w, 0.001f); assertEquals(0.28f, m.x, 0.001f) }
    @Test fun moveImg_65() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.6f, 2.21f, 0.31f, 0.91f), -0.38f, -0.37f); assertEquals(0.21999999999999997f, m.x, 0.001f); assertEquals(1.8399999999999999f, m.y, 0.001f) }
    @Test fun scaleImg_65() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.6f, 2.21f, 0.31f, 0.91f), 0.69f); assertEquals(0.21389999999999998f, m.w, 0.001f); assertEquals(0.6f, m.x, 0.001f) }
    @Test fun moveImg_66() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.38f, 2.46f, 0.23f, 1.0f), -0.09f, 0.03f); assertEquals(0.29000000000000004f, m.x, 0.001f); assertEquals(2.4899999999999998f, m.y, 0.001f) }
    @Test fun scaleImg_66() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.38f, 2.46f, 0.23f, 1.0f), 2.84f); assertEquals(0.6532f, m.w, 0.001f); assertEquals(0.3468f, m.x, 0.001f) }
    @Test fun moveImg_67() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.21f, 0.71f, 0.31f, 1.28f), -0.43f, 1.49f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.2f, m.y, 0.001f) }
    @Test fun scaleImg_67() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.21f, 0.71f, 0.31f, 1.28f), 1.07f); assertEquals(0.3317f, m.w, 0.001f); assertEquals(0.21f, m.x, 0.001f) }
    @Test fun moveImg_68() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.51f, 1.36f, 0.3f, 1.89f), -0.22f, 0.97f); assertEquals(0.29000000000000004f, m.x, 0.001f); assertEquals(2.33f, m.y, 0.001f) }
    @Test fun scaleImg_68() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.51f, 1.36f, 0.3f, 1.89f), 1.92f); assertEquals(0.576f, m.w, 0.001f); assertEquals(0.42400000000000004f, m.x, 0.001f) }
    @Test fun moveImg_69() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.27f, 1.26f, 0.12f, 0.78f), -0.12f, 1.82f); assertEquals(0.15000000000000002f, m.x, 0.001f); assertEquals(3.08f, m.y, 0.001f) }
    @Test fun scaleImg_69() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.27f, 1.26f, 0.12f, 0.78f), 1.09f); assertEquals(0.1308f, m.w, 0.001f); assertEquals(0.27f, m.x, 0.001f) }
    @Test fun moveImg_70() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.42f, 0.73f, 0.3f, 1.0f), -0.74f, 1.58f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.31f, m.y, 0.001f) }
    @Test fun scaleImg_70() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.42f, 0.73f, 0.3f, 1.0f), 0.98f); assertEquals(0.294f, m.w, 0.001f); assertEquals(0.42f, m.x, 0.001f) }
    @Test fun moveImg_71() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.25f, 2.46f, 0.2f, 1.75f), 0.18f, 0.18f); assertEquals(0.43f, m.x, 0.001f); assertEquals(2.64f, m.y, 0.001f) }
    @Test fun scaleImg_71() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.25f, 2.46f, 0.2f, 1.75f), 0.57f); assertEquals(0.11399999999999999f, m.w, 0.001f); assertEquals(0.25f, m.x, 0.001f) }
    @Test fun moveImg_72() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.54f, 1.09f, 0.13f, 0.94f), 0.45f, 0.68f); assertEquals(0.87f, m.x, 0.001f); assertEquals(1.77f, m.y, 0.001f) }
    @Test fun scaleImg_72() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.54f, 1.09f, 0.13f, 0.94f), 1.23f); assertEquals(0.15990000000000001f, m.w, 0.001f); assertEquals(0.54f, m.x, 0.001f) }
    @Test fun moveImg_73() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.54f, 0.07f, 0.38f, 1.38f), -0.06f, -0.55f); assertEquals(0.48000000000000004f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_73() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.54f, 0.07f, 0.38f, 1.38f), 1.56f); assertEquals(0.5928f, m.w, 0.001f); assertEquals(0.4072f, m.x, 0.001f) }
    @Test fun moveImg_74() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.19f, 1.82f, 0.3f, 1.95f), 0.95f, 1.97f); assertEquals(0.7f, m.x, 0.001f); assertEquals(3.79f, m.y, 0.001f) }
    @Test fun scaleImg_74() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.19f, 1.82f, 0.3f, 1.95f), 1.37f); assertEquals(0.41100000000000003f, m.w, 0.001f); assertEquals(0.19f, m.x, 0.001f) }
    @Test fun moveImg_75() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.5f, 2.1f, 0.29f, 2.0f), -0.87f, -0.15f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.9500000000000002f, m.y, 0.001f) }
    @Test fun scaleImg_75() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.5f, 2.1f, 0.29f, 2.0f), 1.38f); assertEquals(0.40019999999999994f, m.w, 0.001f); assertEquals(0.5f, m.x, 0.001f) }
    @Test fun moveImg_76() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.39f, 2.97f, 0.17f, 0.66f), -0.26f, -1.43f); assertEquals(0.13f, m.x, 0.001f); assertEquals(1.5400000000000003f, m.y, 0.001f) }
    @Test fun scaleImg_76() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.39f, 2.97f, 0.17f, 0.66f), 1.37f); assertEquals(0.23290000000000002f, m.w, 0.001f); assertEquals(0.39f, m.x, 0.001f) }
    @Test fun moveImg_77() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.45f, 0.5f, 0.13f, 1.4f), 0.25f, 0.97f); assertEquals(0.7f, m.x, 0.001f); assertEquals(1.47f, m.y, 0.001f) }
    @Test fun scaleImg_77() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.45f, 0.5f, 0.13f, 1.4f), 0.98f); assertEquals(0.1274f, m.w, 0.001f); assertEquals(0.45f, m.x, 0.001f) }
    @Test fun moveImg_78() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.49f, 2.33f, 0.32f, 0.5f), -0.06f, -1.94f); assertEquals(0.43f, m.x, 0.001f); assertEquals(0.3900000000000001f, m.y, 0.001f) }
    @Test fun scaleImg_78() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.49f, 2.33f, 0.32f, 0.5f), 2.62f); assertEquals(0.8384f, m.w, 0.001f); assertEquals(0.16159999999999997f, m.x, 0.001f) }
    @Test fun moveImg_79() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.57f, 0.07f, 0.37f, 0.9f), 0.07f, 0.13f); assertEquals(0.63f, m.x, 0.001f); assertEquals(0.2f, m.y, 0.001f) }
    @Test fun scaleImg_79() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.57f, 0.07f, 0.37f, 0.9f), 0.6f); assertEquals(0.222f, m.w, 0.001f); assertEquals(0.57f, m.x, 0.001f) }
    @Test fun moveImg_80() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.47f, 1.52f, 0.19f, 0.51f), 0.14f, -1.48f); assertEquals(0.61f, m.x, 0.001f); assertEquals(0.040000000000000036f, m.y, 0.001f) }
    @Test fun scaleImg_80() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.47f, 1.52f, 0.19f, 0.51f), 0.54f); assertEquals(0.10260000000000001f, m.w, 0.001f); assertEquals(0.47f, m.x, 0.001f) }
    @Test fun moveImg_81() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.31f, 2.33f, 0.19f, 0.72f), -0.17f, -1.78f); assertEquals(0.13999999999999999f, m.x, 0.001f); assertEquals(0.55f, m.y, 0.001f) }
    @Test fun scaleImg_81() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.31f, 2.33f, 0.19f, 0.72f), 0.89f); assertEquals(0.1691f, m.w, 0.001f); assertEquals(0.31f, m.x, 0.001f) }
    @Test fun moveImg_82() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.27f, 1.38f, 0.27f, 1.75f), -0.79f, 1.4f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.78f, m.y, 0.001f) }
    @Test fun scaleImg_82() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.27f, 1.38f, 0.27f, 1.75f), 0.72f); assertEquals(0.19440000000000002f, m.w, 0.001f); assertEquals(0.27f, m.x, 0.001f) }
    @Test fun moveImg_83() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.58f, 1.22f, 0.26f, 1.34f), 0.73f, 1.86f); assertEquals(0.74f, m.x, 0.001f); assertEquals(3.08f, m.y, 0.001f) }
    @Test fun scaleImg_83() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.58f, 1.22f, 0.26f, 1.34f), 1.42f); assertEquals(0.3692f, m.w, 0.001f); assertEquals(0.58f, m.x, 0.001f) }
    @Test fun moveImg_84() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.01f, 2.46f, 0.15f, 1.55f), 0.43f, -1.37f); assertEquals(0.44f, m.x, 0.001f); assertEquals(1.0899999999999999f, m.y, 0.001f) }
    @Test fun scaleImg_84() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.01f, 2.46f, 0.15f, 1.55f), 1.73f); assertEquals(0.2595f, m.w, 0.001f); assertEquals(0.01f, m.x, 0.001f) }
    @Test fun moveImg_85() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.02f, 0.9f, 0.13f, 1.94f), 0.29f, 1.39f); assertEquals(0.31f, m.x, 0.001f); assertEquals(2.29f, m.y, 0.001f) }
    @Test fun scaleImg_85() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.02f, 0.9f, 0.13f, 1.94f), 0.42f); assertEquals(0.1f, m.w, 0.001f); assertEquals(0.02f, m.x, 0.001f) }
    @Test fun moveImg_86() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.25f, 0.78f, 0.12f, 0.49f), 0.84f, -0.68f); assertEquals(0.88f, m.x, 0.001f); assertEquals(0.09999999999999998f, m.y, 0.001f) }
    @Test fun scaleImg_86() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.25f, 0.78f, 0.12f, 0.49f), 1.62f); assertEquals(0.19440000000000002f, m.w, 0.001f); assertEquals(0.25f, m.x, 0.001f) }
    @Test fun moveImg_87() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.39f, 2.84f, 0.37f, 1.27f), 0.0f, 1.62f); assertEquals(0.39f, m.x, 0.001f); assertEquals(4.46f, m.y, 0.001f) }
    @Test fun scaleImg_87() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.39f, 2.84f, 0.37f, 1.27f), 1.37f); assertEquals(0.5069f, m.w, 0.001f); assertEquals(0.39f, m.x, 0.001f) }
    @Test fun moveImg_88() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.18f, 0.77f, 0.32f, 0.93f), -0.14f, -0.09f); assertEquals(0.03999999999999998f, m.x, 0.001f); assertEquals(0.68f, m.y, 0.001f) }
    @Test fun scaleImg_88() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.18f, 0.77f, 0.32f, 0.93f), 1.27f); assertEquals(0.40640000000000004f, m.w, 0.001f); assertEquals(0.18f, m.x, 0.001f) }
    @Test fun moveImg_89() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.26f, 0.15f, 0.24f, 1.72f), -0.88f, 0.11f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.26f, m.y, 0.001f) }
    @Test fun scaleImg_89() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.26f, 0.15f, 0.24f, 1.72f), 1.78f); assertEquals(0.42719999999999997f, m.w, 0.001f); assertEquals(0.26f, m.x, 0.001f) }
    @Test fun moveImg_90() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.24f, 0.3f, 0.17f, 0.93f), -0.37f, -0.06f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.24f, m.y, 0.001f) }
    @Test fun scaleImg_90() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.24f, 0.3f, 0.17f, 0.93f), 0.92f); assertEquals(0.1564f, m.w, 0.001f); assertEquals(0.24f, m.x, 0.001f) }
    @Test fun moveImg_91() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.45f, 0.03f, 0.25f, 0.99f), 0.93f, -1.97f); assertEquals(0.75f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_91() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.45f, 0.03f, 0.25f, 0.99f), 1.9f); assertEquals(0.475f, m.w, 0.001f); assertEquals(0.45f, m.x, 0.001f) }
    @Test fun moveImg_92() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.58f, 1.79f, 0.21f, 0.93f), -0.4f, 0.44f); assertEquals(0.17999999999999994f, m.x, 0.001f); assertEquals(2.23f, m.y, 0.001f) }
    @Test fun scaleImg_92() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.58f, 1.79f, 0.21f, 0.93f), 1.89f); assertEquals(0.3969f, m.w, 0.001f); assertEquals(0.58f, m.x, 0.001f) }
    @Test fun moveImg_93() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.19f, 1.55f, 0.25f, 1.58f), -0.89f, -1.63f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_93() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.19f, 1.55f, 0.25f, 1.58f), 0.98f); assertEquals(0.245f, m.w, 0.001f); assertEquals(0.19f, m.x, 0.001f) }
    @Test fun moveImg_94() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.16f, 1.28f, 0.34f, 1.76f), -0.2f, -0.86f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.42000000000000004f, m.y, 0.001f) }
    @Test fun scaleImg_94() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.16f, 1.28f, 0.34f, 1.76f), 2.14f); assertEquals(0.7276000000000001f, m.w, 0.001f); assertEquals(0.16f, m.x, 0.001f) }
    @Test fun moveImg_95() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.05f, 2.49f, 0.4f, 0.86f), -0.37f, 1.28f); assertEquals(0.0f, m.x, 0.001f); assertEquals(3.7700000000000005f, m.y, 0.001f) }
    @Test fun scaleImg_95() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.05f, 2.49f, 0.4f, 0.86f), 2.43f); assertEquals(0.9720000000000001f, m.w, 0.001f); assertEquals(0.027999999999999914f, m.x, 0.001f) }
    @Test fun moveImg_96() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.39f, 2.29f, 0.12f, 0.38f), 0.25f, 0.21f); assertEquals(0.64f, m.x, 0.001f); assertEquals(2.5f, m.y, 0.001f) }
    @Test fun scaleImg_96() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.39f, 2.29f, 0.12f, 0.38f), 2.8f); assertEquals(0.33599999999999997f, m.w, 0.001f); assertEquals(0.39f, m.x, 0.001f) }
    @Test fun moveImg_97() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.38f, 2.8f, 0.11f, 1.58f), 0.16f, -1.98f); assertEquals(0.54f, m.x, 0.001f); assertEquals(0.8199999999999998f, m.y, 0.001f) }
    @Test fun scaleImg_97() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.38f, 2.8f, 0.11f, 1.58f), 2.29f); assertEquals(0.2519f, m.w, 0.001f); assertEquals(0.38f, m.x, 0.001f) }
    @Test fun moveImg_98() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.25f, 2.95f, 0.3f, 1.86f), -0.85f, 1.13f); assertEquals(0.0f, m.x, 0.001f); assertEquals(4.08f, m.y, 0.001f) }
    @Test fun scaleImg_98() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.25f, 2.95f, 0.3f, 1.86f), 1.49f); assertEquals(0.447f, m.w, 0.001f); assertEquals(0.25f, m.x, 0.001f) }
    @Test fun moveImg_99() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.45f, 1.34f, 0.21f, 1.04f), -0.76f, -0.72f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.6200000000000001f, m.y, 0.001f) }
    @Test fun scaleImg_99() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.45f, 1.34f, 0.21f, 1.04f), 2.28f); assertEquals(0.47879999999999995f, m.w, 0.001f); assertEquals(0.45f, m.x, 0.001f) }
    @Test fun moveImg_100() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.04f, 2.5f, 0.13f, 1.43f), 0.1f, -1.55f); assertEquals(0.14f, m.x, 0.001f); assertEquals(0.95f, m.y, 0.001f) }
    @Test fun scaleImg_100() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.04f, 2.5f, 0.13f, 1.43f), 0.62f); assertEquals(0.1f, m.w, 0.001f); assertEquals(0.04f, m.x, 0.001f) }
    @Test fun moveImg_101() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.19f, 1.68f, 0.39f, 1.87f), -0.58f, -0.34f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.3399999999999999f, m.y, 0.001f) }
    @Test fun scaleImg_101() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.19f, 1.68f, 0.39f, 1.87f), 1.75f); assertEquals(0.6825f, m.w, 0.001f); assertEquals(0.19f, m.x, 0.001f) }
    @Test fun moveImg_102() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.5f, 2.62f, 0.14f, 1.1f), -0.94f, -0.27f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.35f, m.y, 0.001f) }
    @Test fun scaleImg_102() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.5f, 2.62f, 0.14f, 1.1f), 1.32f); assertEquals(0.18480000000000002f, m.w, 0.001f); assertEquals(0.5f, m.x, 0.001f) }
    @Test fun moveImg_103() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.4f, 1.48f, 0.38f, 1.47f), -0.22f, 1.11f); assertEquals(0.18000000000000002f, m.x, 0.001f); assertEquals(2.59f, m.y, 0.001f) }
    @Test fun scaleImg_103() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.4f, 1.48f, 0.38f, 1.47f), 0.58f); assertEquals(0.22039999999999998f, m.w, 0.001f); assertEquals(0.4f, m.x, 0.001f) }
    @Test fun moveImg_104() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.45f, 1.76f, 0.15f, 0.64f), -0.31f, -1.34f); assertEquals(0.14f, m.x, 0.001f); assertEquals(0.41999999999999993f, m.y, 0.001f) }
    @Test fun scaleImg_104() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.45f, 1.76f, 0.15f, 0.64f), 1.24f); assertEquals(0.186f, m.w, 0.001f); assertEquals(0.45f, m.x, 0.001f) }
    @Test fun moveImg_105() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.35f, 1.17f, 0.26f, 1.28f), 0.68f, -0.57f); assertEquals(0.74f, m.x, 0.001f); assertEquals(0.6f, m.y, 0.001f) }
    @Test fun scaleImg_105() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.35f, 1.17f, 0.26f, 1.28f), 1.88f); assertEquals(0.4888f, m.w, 0.001f); assertEquals(0.35f, m.x, 0.001f) }
    @Test fun moveImg_106() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.29f, 0.98f, 0.39f, 1.49f), -0.53f, -0.95f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.030000000000000027f, m.y, 0.001f) }
    @Test fun scaleImg_106() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.29f, 0.98f, 0.39f, 1.49f), 2.27f); assertEquals(0.8853000000000001f, m.w, 0.001f); assertEquals(0.11469999999999991f, m.x, 0.001f) }
    @Test fun moveImg_107() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.34f, 0.19f, 0.18f, 1.7f), -0.24f, 0.87f); assertEquals(0.10000000000000003f, m.x, 0.001f); assertEquals(1.06f, m.y, 0.001f) }
    @Test fun scaleImg_107() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.34f, 0.19f, 0.18f, 1.7f), 1.47f); assertEquals(0.2646f, m.w, 0.001f); assertEquals(0.34f, m.x, 0.001f) }
    @Test fun moveImg_108() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.37f, 2.93f, 0.27f, 1.85f), -0.09f, -0.05f); assertEquals(0.28f, m.x, 0.001f); assertEquals(2.8800000000000003f, m.y, 0.001f) }
    @Test fun scaleImg_108() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.37f, 2.93f, 0.27f, 1.85f), 0.92f); assertEquals(0.24840000000000004f, m.w, 0.001f); assertEquals(0.37f, m.x, 0.001f) }
    @Test fun moveImg_109() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.45f, 0.92f, 0.13f, 1.74f), -0.93f, 0.79f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.71f, m.y, 0.001f) }
    @Test fun scaleImg_109() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.45f, 0.92f, 0.13f, 1.74f), 1.83f); assertEquals(0.23790000000000003f, m.w, 0.001f); assertEquals(0.45f, m.x, 0.001f) }
    @Test fun moveImg_110() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.33f, 0.45f, 0.2f, 1.92f), 0.53f, 1.22f); assertEquals(0.8f, m.x, 0.001f); assertEquals(1.67f, m.y, 0.001f) }
    @Test fun scaleImg_110() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.33f, 0.45f, 0.2f, 1.92f), 0.56f); assertEquals(0.11200000000000002f, m.w, 0.001f); assertEquals(0.33f, m.x, 0.001f) }
    @Test fun moveImg_111() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.47f, 0.6f, 0.17f, 1.21f), 0.22f, -1.52f); assertEquals(0.69f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_111() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.47f, 0.6f, 0.17f, 1.21f), 2.37f); assertEquals(0.40290000000000004f, m.w, 0.001f); assertEquals(0.47f, m.x, 0.001f) }
    @Test fun moveImg_112() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.35f, 2.77f, 0.37f, 1.47f), -0.27f, 1.8f); assertEquals(0.07999999999999996f, m.x, 0.001f); assertEquals(4.57f, m.y, 0.001f) }
    @Test fun scaleImg_112() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.35f, 2.77f, 0.37f, 1.47f), 2.24f); assertEquals(0.8288000000000001f, m.w, 0.001f); assertEquals(0.1711999999999999f, m.x, 0.001f) }
    @Test fun moveImg_113() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.17f, 2.18f, 0.36f, 0.75f), -0.5f, -1.92f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.26000000000000023f, m.y, 0.001f) }
    @Test fun scaleImg_113() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.17f, 2.18f, 0.36f, 0.75f), 1.75f); assertEquals(0.63f, m.w, 0.001f); assertEquals(0.17f, m.x, 0.001f) }
    @Test fun moveImg_114() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.15f, 0.76f, 0.19f, 0.52f), -0.03f, -0.91f); assertEquals(0.12f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_114() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.15f, 0.76f, 0.19f, 0.52f), 1.07f); assertEquals(0.2033f, m.w, 0.001f); assertEquals(0.15f, m.x, 0.001f) }
    @Test fun moveImg_115() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.17f, 2.62f, 0.25f, 0.57f), 0.72f, 1.42f); assertEquals(0.75f, m.x, 0.001f); assertEquals(4.04f, m.y, 0.001f) }
    @Test fun scaleImg_115() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.17f, 2.62f, 0.25f, 0.57f), 1.95f); assertEquals(0.4875f, m.w, 0.001f); assertEquals(0.17f, m.x, 0.001f) }
    @Test fun moveImg_116() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.33f, 1.6f, 0.32f, 1.42f), 0.84f, 1.1f); assertEquals(0.6799999999999999f, m.x, 0.001f); assertEquals(2.7f, m.y, 0.001f) }
    @Test fun scaleImg_116() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.33f, 1.6f, 0.32f, 1.42f), 1.0f); assertEquals(0.32f, m.w, 0.001f); assertEquals(0.33f, m.x, 0.001f) }
    @Test fun moveImg_117() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.03f, 1.09f, 0.38f, 1.64f), -0.53f, -0.19f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.9000000000000001f, m.y, 0.001f) }
    @Test fun scaleImg_117() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.03f, 1.09f, 0.38f, 1.64f), 1.3f); assertEquals(0.49400000000000005f, m.w, 0.001f); assertEquals(0.03f, m.x, 0.001f) }
    @Test fun moveImg_118() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.44f, 1.52f, 0.38f, 1.26f), -0.3f, -1.07f); assertEquals(0.14f, m.x, 0.001f); assertEquals(0.44999999999999996f, m.y, 0.001f) }
    @Test fun scaleImg_118() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.44f, 1.52f, 0.38f, 1.26f), 2.86f); assertEquals(1.0f, m.w, 0.001f); assertEquals(0.0f, m.x, 0.001f) }
    @Test fun moveImg_119() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.07f, 1.97f, 0.38f, 0.42f), 0.8f, -1.59f); assertEquals(0.62f, m.x, 0.001f); assertEquals(0.3799999999999999f, m.y, 0.001f) }
    @Test fun scaleImg_119() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.07f, 1.97f, 0.38f, 0.42f), 1.83f); assertEquals(0.6954f, m.w, 0.001f); assertEquals(0.07f, m.x, 0.001f) }
    @Test fun moveImg_120() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.07f, 0.93f, 0.4f, 1.78f), -0.88f, 0.67f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.6f, m.y, 0.001f) }
    @Test fun scaleImg_120() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.07f, 0.93f, 0.4f, 1.78f), 0.48f); assertEquals(0.192f, m.w, 0.001f); assertEquals(0.07f, m.x, 0.001f) }
    @Test fun moveImg_121() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.02f, 2.95f, 0.27f, 1.46f), 0.71f, 1.14f); assertEquals(0.73f, m.x, 0.001f); assertEquals(4.09f, m.y, 0.001f) }
    @Test fun scaleImg_121() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.02f, 2.95f, 0.27f, 1.46f), 1.71f); assertEquals(0.4617f, m.w, 0.001f); assertEquals(0.02f, m.x, 0.001f) }
    @Test fun moveImg_122() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.05f, 0.55f, 0.26f, 1.2f), -0.29f, -0.0f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.55f, m.y, 0.001f) }
    @Test fun scaleImg_122() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.05f, 0.55f, 0.26f, 1.2f), 0.83f); assertEquals(0.2158f, m.w, 0.001f); assertEquals(0.05f, m.x, 0.001f) }
    @Test fun moveImg_123() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.42f, 1.46f, 0.23f, 0.43f), -0.03f, 0.23f); assertEquals(0.39f, m.x, 0.001f); assertEquals(1.69f, m.y, 0.001f) }
    @Test fun scaleImg_123() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.42f, 1.46f, 0.23f, 0.43f), 2.93f); assertEquals(0.6739f, m.w, 0.001f); assertEquals(0.32609999999999995f, m.x, 0.001f) }
    @Test fun moveImg_124() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.34f, 0.9f, 0.14f, 0.87f), 0.4f, 1.76f); assertEquals(0.74f, m.x, 0.001f); assertEquals(2.66f, m.y, 0.001f) }
    @Test fun scaleImg_124() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.34f, 0.9f, 0.14f, 0.87f), 2.94f); assertEquals(0.4116f, m.w, 0.001f); assertEquals(0.34f, m.x, 0.001f) }
    @Test fun moveImg_125() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.57f, 2.58f, 0.38f, 1.89f), -0.96f, -0.04f); assertEquals(0.0f, m.x, 0.001f); assertEquals(2.54f, m.y, 0.001f) }
    @Test fun scaleImg_125() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.57f, 2.58f, 0.38f, 1.89f), 1.89f); assertEquals(0.7182f, m.w, 0.001f); assertEquals(0.28180000000000005f, m.x, 0.001f) }
    @Test fun moveImg_126() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.41f, 1.84f, 0.28f, 1.89f), -0.83f, 0.08f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.9200000000000002f, m.y, 0.001f) }
    @Test fun scaleImg_126() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.41f, 1.84f, 0.28f, 1.89f), 2.89f); assertEquals(0.8092000000000001f, m.w, 0.001f); assertEquals(0.19079999999999986f, m.x, 0.001f) }
    @Test fun moveImg_127() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.02f, 2.61f, 0.13f, 1.93f), -0.95f, -1.87f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.7399999999999998f, m.y, 0.001f) }
    @Test fun scaleImg_127() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.02f, 2.61f, 0.13f, 1.93f), 2.54f); assertEquals(0.3302f, m.w, 0.001f); assertEquals(0.02f, m.x, 0.001f) }
    @Test fun moveImg_128() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.41f, 1.74f, 0.26f, 1.59f), 0.62f, -2.0f); assertEquals(0.74f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_128() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.41f, 1.74f, 0.26f, 1.59f), 0.48f); assertEquals(0.1248f, m.w, 0.001f); assertEquals(0.41f, m.x, 0.001f) }
    @Test fun moveImg_129() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.48f, 2.5f, 0.39f, 0.99f), -0.33f, -0.61f); assertEquals(0.14999999999999997f, m.x, 0.001f); assertEquals(1.8900000000000001f, m.y, 0.001f) }
    @Test fun scaleImg_129() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.48f, 2.5f, 0.39f, 0.99f), 0.34f); assertEquals(0.13260000000000002f, m.w, 0.001f); assertEquals(0.48f, m.x, 0.001f) }
    @Test fun moveImg_130() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.46f, 1.76f, 0.18f, 1.19f), -0.33f, 0.7f); assertEquals(0.13f, m.x, 0.001f); assertEquals(2.46f, m.y, 0.001f) }
    @Test fun scaleImg_130() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.46f, 1.76f, 0.18f, 1.19f), 1.53f); assertEquals(0.2754f, m.w, 0.001f); assertEquals(0.46f, m.x, 0.001f) }
    @Test fun moveImg_131() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.14f, 0.53f, 0.36f, 0.55f), -0.49f, -0.08f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.45f, m.y, 0.001f) }
    @Test fun scaleImg_131() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.14f, 0.53f, 0.36f, 0.55f), 2.42f); assertEquals(0.8712f, m.w, 0.001f); assertEquals(0.12880000000000003f, m.x, 0.001f) }
    @Test fun moveImg_132() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.2f, 1.96f, 0.17f, 0.74f), 0.05f, -0.98f); assertEquals(0.25f, m.x, 0.001f); assertEquals(0.98f, m.y, 0.001f) }
    @Test fun scaleImg_132() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.2f, 1.96f, 0.17f, 0.74f), 2.67f); assertEquals(0.4539f, m.w, 0.001f); assertEquals(0.2f, m.x, 0.001f) }
    @Test fun moveImg_133() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.11f, 0.9f, 0.17f, 0.86f), 0.45f, 0.7f); assertEquals(0.56f, m.x, 0.001f); assertEquals(1.6f, m.y, 0.001f) }
    @Test fun scaleImg_133() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.11f, 0.9f, 0.17f, 0.86f), 2.43f); assertEquals(0.4131000000000001f, m.w, 0.001f); assertEquals(0.11f, m.x, 0.001f) }
    @Test fun moveImg_134() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.32f, 2.29f, 0.12f, 0.72f), -0.56f, -0.34f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.95f, m.y, 0.001f) }
    @Test fun scaleImg_134() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.32f, 2.29f, 0.12f, 0.72f), 2.97f); assertEquals(0.3564f, m.w, 0.001f); assertEquals(0.32f, m.x, 0.001f) }
    @Test fun moveImg_135() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.22f, 2.73f, 0.21f, 1.98f), -0.23f, -1.46f); assertEquals(0.0f, m.x, 0.001f); assertEquals(1.27f, m.y, 0.001f) }
    @Test fun scaleImg_135() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.22f, 2.73f, 0.21f, 1.98f), 2.43f); assertEquals(0.5103f, m.w, 0.001f); assertEquals(0.22f, m.x, 0.001f) }
    @Test fun moveImg_136() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.47f, 2.37f, 0.2f, 0.95f), -0.43f, 0.37f); assertEquals(0.03999999999999998f, m.x, 0.001f); assertEquals(2.74f, m.y, 0.001f) }
    @Test fun scaleImg_136() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.47f, 2.37f, 0.2f, 0.95f), 2.3f); assertEquals(0.45999999999999996f, m.w, 0.001f); assertEquals(0.47f, m.x, 0.001f) }
    @Test fun moveImg_137() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.29f, 0.04f, 0.35f, 1.15f), -0.24f, -1.74f); assertEquals(0.04999999999999999f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_137() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.29f, 0.04f, 0.35f, 1.15f), 2.77f); assertEquals(0.9694999999999999f, m.w, 0.001f); assertEquals(0.030500000000000083f, m.x, 0.001f) }
    @Test fun moveImg_138() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.09f, 2.63f, 0.16f, 1.93f), 0.86f, -0.63f); assertEquals(0.84f, m.x, 0.001f); assertEquals(2.0f, m.y, 0.001f) }
    @Test fun scaleImg_138() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.09f, 2.63f, 0.16f, 1.93f), 2.81f); assertEquals(0.4496f, m.w, 0.001f); assertEquals(0.09f, m.x, 0.001f) }
    @Test fun moveImg_139() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.09f, 2.84f, 0.31f, 0.63f), -0.73f, 0.71f); assertEquals(0.0f, m.x, 0.001f); assertEquals(3.55f, m.y, 0.001f) }
    @Test fun scaleImg_139() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.09f, 2.84f, 0.31f, 0.63f), 2.68f); assertEquals(0.8308000000000001f, m.w, 0.001f); assertEquals(0.09f, m.x, 0.001f) }
    @Test fun moveImg_140() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.44f, 1.36f, 0.38f, 0.93f), -0.76f, -0.91f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.45000000000000007f, m.y, 0.001f) }
    @Test fun scaleImg_140() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.44f, 1.36f, 0.38f, 0.93f), 2.83f); assertEquals(1.0f, m.w, 0.001f); assertEquals(0.0f, m.x, 0.001f) }
    @Test fun moveImg_141() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.04f, 1.04f, 0.16f, 0.38f), -0.39f, -1.27f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_141() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.04f, 1.04f, 0.16f, 0.38f), 0.63f); assertEquals(0.1008f, m.w, 0.001f); assertEquals(0.04f, m.x, 0.001f) }
    @Test fun moveImg_142() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.32f, 1.7f, 0.26f, 1.6f), 0.05f, 1.79f); assertEquals(0.37f, m.x, 0.001f); assertEquals(3.49f, m.y, 0.001f) }
    @Test fun scaleImg_142() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.32f, 1.7f, 0.26f, 1.6f), 0.52f); assertEquals(0.13520000000000001f, m.w, 0.001f); assertEquals(0.32f, m.x, 0.001f) }
    @Test fun moveImg_143() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.13f, 0.93f, 0.12f, 1.59f), 0.85f, 0.02f); assertEquals(0.88f, m.x, 0.001f); assertEquals(0.9500000000000001f, m.y, 0.001f) }
    @Test fun scaleImg_143() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.13f, 0.93f, 0.12f, 1.59f), 0.73f); assertEquals(0.1f, m.w, 0.001f); assertEquals(0.13f, m.x, 0.001f) }
    @Test fun moveImg_144() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.2f, 0.88f, 0.27f, 1.65f), 0.95f, -0.16f); assertEquals(0.73f, m.x, 0.001f); assertEquals(0.72f, m.y, 0.001f) }
    @Test fun scaleImg_144() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.2f, 0.88f, 0.27f, 1.65f), 1.93f); assertEquals(0.5211f, m.w, 0.001f); assertEquals(0.2f, m.x, 0.001f) }
    @Test fun moveImg_145() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.51f, 0.57f, 0.24f, 1.9f), 0.96f, -1.9f); assertEquals(0.76f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_145() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.51f, 0.57f, 0.24f, 1.9f), 2.36f); assertEquals(0.5663999999999999f, m.w, 0.001f); assertEquals(0.4336000000000001f, m.x, 0.001f) }
    @Test fun moveImg_146() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.24f, 0.49f, 0.12f, 0.59f), 0.47f, -1.15f); assertEquals(0.71f, m.x, 0.001f); assertEquals(0.0f, m.y, 0.001f) }
    @Test fun scaleImg_146() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.24f, 0.49f, 0.12f, 0.59f), 0.35f); assertEquals(0.1f, m.w, 0.001f); assertEquals(0.24f, m.x, 0.001f) }
    @Test fun moveImg_147() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.13f, 1.5f, 0.34f, 1.41f), -0.07f, -1.27f); assertEquals(0.06f, m.x, 0.001f); assertEquals(0.22999999999999998f, m.y, 0.001f) }
    @Test fun scaleImg_147() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.13f, 1.5f, 0.34f, 1.41f), 0.34f); assertEquals(0.11560000000000002f, m.w, 0.001f); assertEquals(0.13f, m.x, 0.001f) }
    @Test fun moveImg_148() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.18f, 0.78f, 0.11f, 1.35f), -0.26f, -0.11f); assertEquals(0.0f, m.x, 0.001f); assertEquals(0.67f, m.y, 0.001f) }
    @Test fun scaleImg_148() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.18f, 0.78f, 0.11f, 1.35f), 1.98f); assertEquals(0.2178f, m.w, 0.001f); assertEquals(0.18f, m.x, 0.001f) }
    @Test fun moveImg_149() { val m = NotePure.moveImg(NoteImg("a.jpg", 0.19f, 2.65f, 0.21f, 1.29f), -0.17f, 0.16f); assertEquals(0.01999999999999999f, m.x, 0.001f); assertEquals(2.81f, m.y, 0.001f) }
    @Test fun scaleImg_149() { val m = NotePure.scaleImg(NoteImg("a.jpg", 0.19f, 2.65f, 0.21f, 1.29f), 1.54f); assertEquals(0.3234f, m.w, 0.001f); assertEquals(0.19f, m.x, 0.001f) }
    @Test fun safe_0() { assertTrue(NotePure.safeFile("a.jpg")) }
    @Test fun safe_1() { assertFalse(NotePure.safeFile("a b")) }
    @Test fun safe_2() { assertFalse(NotePure.safeFile("..")) }
    @Test fun safe_3() { assertFalse(NotePure.safeFile("x..y")) }
    @Test fun safe_4() { assertFalse(NotePure.safeFile(".h")) }
    @Test fun safe_5() { assertTrue(NotePure.safeFile("ok_1-2.png")) }
    @Test fun safe_6() { assertFalse(NotePure.safeFile("ğ")) }
    @Test fun safe_7() { assertFalse(NotePure.safeFile("a/b")) }
    @Test fun safe_8() { assertFalse(NotePure.safeFile("")) }
    @Test fun safe_9() { assertTrue(NotePure.safeFile("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")) }
    @Test fun safe_10() { assertFalse(NotePure.safeFile("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")) }
    @Test fun safe_11() { assertFalse(NotePure.safeFile("a\\b")) }
    @Test fun safe_12() { assertTrue(NotePure.safeFile("name.m4a")) }
    @Test fun safe_13() { assertTrue(NotePure.safeFile("p_1.pdf")) }
    @Test fun safe_14() { assertFalse(NotePure.safeFile("a:b")) }
    @Test fun safe_15() { assertFalse(NotePure.safeFile("a%2e")) }
}
