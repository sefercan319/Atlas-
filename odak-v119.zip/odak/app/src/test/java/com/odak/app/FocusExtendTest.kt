package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Odak modu uzatma: saf mantık, kaynak dizgileri ve ekran bağlantısı. */
class FocusExtendTest {
    private val min = 60_000L

    @Test fun activeSessionExtendsFromCurrentEnd() {
        val until = 10 * min; val now = 2 * min
        assertEquals(until + 10 * min, Pure.focusExtend(until, now, 10))
    }

    @Test fun expiredSessionExtendsFromNow() {
        val until = 5 * min; val now = 20 * min
        assertEquals(now + 10 * min, Pure.focusExtend(until, now, 10))
    }

    @Test fun defaultStepIsTenMinutes() {
        assertEquals(10, Pure.FOCUS_EXTEND_MIN)
    }

    @Test fun extensionNeverMovesEndBackwards() {
        val until = 30 * min; val now = 1 * min
        assertTrue(Pure.focusExtend(until, now, 1) > until)
    }

    @Test fun newStringsExistInEveryLocale() {
        val res = TestFiles.res
        for (d in listOf("values", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az", "values-tr")) {
            val s = File(res, "$d/strings.xml").readText()
            assertTrue("$d focus_extend", s.contains("name=\"focus_extend\">"))
            assertTrue("$d focus_ends", s.contains("name=\"focus_ends\">"))
        }
    }

    @Test fun blockScreenWiresExtendButtonAndEndTime() {
        val s = File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()
        assertTrue(s.contains("Pure.focusExtend(until, System.currentTimeMillis(), com.odak.app.logic.Pure.FOCUS_EXTEND_MIN)"))
        assertTrue(s.contains("scheduleAt(ctx, \"focus_end\""))
        assertTrue(s.contains("R.string.focus_ends"))
    }
}
