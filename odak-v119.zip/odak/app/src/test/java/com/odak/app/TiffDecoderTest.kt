package com.odak.app

import com.odak.app.docs.TiffDecoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.4: TIFF çözücü — PIL/ImageMagick'in ürettiği gerçek dosyalara karşı. */
class TiffDecoderTest {
    private val dir: File = listOf(File("src/test/resources/tiff"), File("app/src/test/resources/tiff")).first { it.exists() }
    private fun cases() = dir.listFiles()!!.filter { it.name.endsWith(".tif") }.sortedBy { it.name }

    private fun expected(f: File): IntArray? {
        val e = File(dir, f.name.removeSuffix(".tif") + ".rgba"); if (!e.exists()) return null
        val b = e.readBytes()
        return IntArray(b.size / 4) { i -> ((b[4 * i + 3].toInt() and 0xFF) shl 24) or ((b[4 * i].toInt() and 0xFF) shl 16) or ((b[4 * i + 1].toInt() and 0xFF) shl 8) or (b[4 * i + 2].toInt() and 0xFF) }
    }

    @Test fun everyFixtureDecodesToExpectedPixels() {
        var checked = 0
        for (f in cases()) {
            val exp = expected(f) ?: continue
            val img = TiffDecoder.decode(f.readBytes())
            assertNotNull(f.name, img)
            assertEquals(f.name + " size", exp.size, img!!.w * img.h)
            var bad = 0
            for (i in exp.indices) if (exp[i] != img.argb[i]) bad++
            assertEquals(f.name + " farklı piksel", 0, bad)
            checked++
        }
        assertTrue(checked >= 15)
    }
    @Test fun cmykWhiteAndColour() { val img = TiffDecoder.decode(File(dir, "cmyk_raw_120x90.tif").readBytes())!!; assertEquals(120, img.w); assertEquals(90, img.h); assertTrue(img.argb.all { (it ushr 24) == 0xFF }) }
    @Test fun downscalesLargeImages() {
        val f = File(dir, "rgb_raw_120x90.tif").readBytes()
        val full = TiffDecoder.decode(f, 2048)!!; val small = TiffDecoder.decode(f, 30)!!
        assertEquals(120, full.w); assertTrue(small.w <= 30 && small.h <= 30 && small.w >= 15)
        // alt örneklenen piksel, tam çözümlü görüntünün ilgili pikseliyle aynı olmalı
        val step = (120 + 29) / 30
        for (y in 0 until small.h) for (x in 0 until small.w) assertEquals(full.argb[y * step * 120 + x * step], small.argb[y * small.w + x])
    }
    @Test fun downscaleWorksForTilesAndStrips() {
        for (n in listOf("rgb_tiled_lzw_120x90", "rgb_strips5_packbits_120x90", "rgb_lzw_pred_120x90")) {
            val b = File(dir, "$n.tif").readBytes(); val full = TiffDecoder.decode(b, 2048)!!; val small = TiffDecoder.decode(b, 40)!!
            val step = (120 + 39) / 40
            for (y in 0 until small.h) for (x in 0 until small.w) assertEquals(n, full.argb[y * step * 120 + x * step], small.argb[y * small.w + x])
        }
    }
    @Test fun isTiffMagic() { assertTrue(TiffDecoder.isTiff(byteArrayOf('I'.code.toByte(), 'I'.code.toByte(), 42, 0, 8, 0, 0, 0))); assertTrue(TiffDecoder.isTiff(byteArrayOf('M'.code.toByte(), 'M'.code.toByte(), 0, 42, 0, 0, 0, 8))); assertTrue(!TiffDecoder.isTiff(ByteArray(8))); assertTrue(!TiffDecoder.isTiff(ByteArray(3))) }
    @Test fun garbageNeverThrows() {
        assertNull(TiffDecoder.decode(ByteArray(0))); assertNull(TiffDecoder.decode(ByteArray(100))); assertNull(TiffDecoder.decode("II*\u0000\u0008\u0000\u0000\u0000".toByteArray()))
        val good = File(dir, "rgb_tiff_lzw_120x90.tif").readBytes()
        val r = kotlin.random.Random(3)
        repeat(200) { val b = good.copyOf(); repeat(r.nextInt(1, 30)) { b[r.nextInt(b.size)] = r.nextInt().toByte() }; TiffDecoder.decode(b) }
        repeat(50) { TiffDecoder.decode(good.copyOf(r.nextInt(8, good.size))) }
    }
    @Test fun unsupportedCompressionReturnsNull() {
        val b = File(dir, "rgb_raw_120x90.tif").readBytes()
        // Compression etiketini (259) CCITT G4 (4) yap
        val le = b[0] == 'I'.code.toByte(); val ifd = (b[4].toInt() and 0xFF) or ((b[5].toInt() and 0xFF) shl 8) or ((b[6].toInt() and 0xFF) shl 16) or ((b[7].toInt() and 0xFF) shl 24)
        val n = (b[ifd].toInt() and 0xFF) or ((b[ifd + 1].toInt() and 0xFF) shl 8)
        for (i in 0 until n) { val o = ifd + 2 + i * 12; val id = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8); if (id == 259) { b[o + 8] = 4; b[o + 9] = 0 } }
        assertTrue(le); assertNull(TiffDecoder.decode(b))
    }
    @Test fun packBitsUnit() { assertEquals(listOf<Byte>(1, 2, 3, 9, 9, 9), TiffDecoder.packBits(byteArrayOf(2, 1, 2, 3, -2, 9), 6).toList()) ; assertEquals(0, TiffDecoder.packBits(byteArrayOf(-128), 5).size) }
    @Test fun inflateUnit() { val d = java.util.zip.Deflater(); val src = ByteArray(1000) { (it % 7).toByte() }; d.setInput(src); d.finish(); val buf = ByteArray(2000); val n = d.deflate(buf); assertEquals(src.toList(), TiffDecoder.inflate(buf.copyOf(n), 1000).toList()) }
    @Test fun lzwHandlesKwKwK() { // "aaaaaaaa" → klasik KwKwK durumu: 256(clear),97,258,259,... kodlayıcı PIL ile doğrulandı (fixture testleri); burada boş girdiyi dene
        assertEquals(0, TiffDecoder.lzw(ByteArray(0), 10).size) }
}
