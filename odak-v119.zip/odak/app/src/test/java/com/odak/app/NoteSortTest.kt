package com.odak.app

import com.odak.app.notes.Note
import com.odak.app.notes.NotePure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Not sıralama: üç mod, sabitlenenler üstte, Türkçe alfabe, kayıtlı tercih güvenliği, ekran bağlantısı. */
class NoteSortTest {
    private fun n(title: String, created: Long, updated: Long, pinned: Boolean = false) =
        Note(id = title, title = title, created = created, updated = updated, pinned = pinned)

    private val a = n("Bilet", created = 1, updated = 30)
    private val b = n("Ajanda", created = 3, updated = 10)
    private val c = n("Çay", created = 2, updated = 20)

    @Test fun updatedModeNewestFirst() {
        assertEquals(listOf("Bilet", "Çay", "Ajanda"), NotePure.sorted(listOf(b, c, a), NotePure.SORT_UPDATED).map { it.title })
    }

    @Test fun createdModeNewestFirst() {
        assertEquals(listOf("Ajanda", "Çay", "Bilet"), NotePure.sorted(listOf(a, b, c), NotePure.SORT_CREATED).map { it.title })
    }

    @Test fun alphaModeUsesTurkishAlphabet() {
        val list = listOf("Şeker", "Zeytin", "Çay", "Ağaç", "Ilık", "Ütü").map { n(it, 0, 0) }
        assertEquals(listOf("Ağaç", "Çay", "Ilık", "Şeker", "Ütü", "Zeytin"), NotePure.sorted(list, NotePure.SORT_ALPHA).map { it.title })
    }

    @Test fun pinnedAlwaysOnTopInEveryMode() {
        val p = n("Zz", created = 0, updated = 0, pinned = true)
        for (m in listOf(NotePure.SORT_UPDATED, NotePure.SORT_CREATED, NotePure.SORT_ALPHA)) {
            assertEquals("Zz", NotePure.sorted(listOf(a, b, p), m).first().title)
        }
    }

    @Test fun unknownSavedValueFallsBackToUpdated() {
        assertEquals(NotePure.SORT_UPDATED, NotePure.sortMode(-1))
        assertEquals(NotePure.SORT_UPDATED, NotePure.sortMode(7))
        assertEquals(NotePure.SORT_ALPHA, NotePure.sortMode(2))
        assertEquals(NotePure.sorted(listOf(a, b, c), NotePure.SORT_UPDATED), NotePure.sorted(listOf(a, b, c), 99))
    }

    @Test fun listUsesChosenSortAndPersistsIt() {
        val s = File(TestFiles.code, "com/odak/app/notes/NotesList.kt").readText()
        assertTrue(s.contains("NotePure.sorted(NotePure.byColor(NotePure.visible(notes, folder, trash, query), activeColor), sort)"))
        assertTrue(s.contains("prefs.edit().putInt(\"sort\", mode).apply()"))
        assertTrue(s.contains("NotePure.sortMode(prefs.getInt(\"sort\", NotePure.SORT_UPDATED))"))
        assertTrue(s.contains("NotePure.SORT_ALPHA to R.string.notes_sort_alpha"))
    }

    @Test fun sortStringsExistInEveryLocale() {
        for (d in listOf("values", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az", "values-tr")) {
            val s = File(TestFiles.res, "$d/strings.xml").readText()
            for (k in listOf("notes_sort_updated", "notes_sort_created", "notes_sort_alpha")) assertTrue("$d $k", s.contains("name=\"$k\">"))
        }
    }
}
