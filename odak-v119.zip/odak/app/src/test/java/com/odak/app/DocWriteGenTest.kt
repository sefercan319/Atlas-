package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import kotlin.random.Random

/** Rastgele belgeler × her yazıcı: geri okununca metin korunur, tüm XML geçerli. */
class DocWriteGenTest {
    private val words = listOf("elma", "Çiçek", "ğüşiöç", "İstanbul", "a&b", "x<y", "\"q\"", "12", "3.5", "😀", "tab", "uzun_sözcük_burada", "Ünite")
    private fun squash(s: String) = s.filterNot { it.isWhitespace() }
    private fun doc(r: Random): Doc {
        val pages = List(1 + r.nextInt(4)) { i ->
            val paras = List(r.nextInt(5)) { List(1 + r.nextInt(8)) { words[r.nextInt(words.size)] }.joinToString(" ") }
            val tbl = if (r.nextBoolean()) List(1 + r.nextInt(4)) { List(1 + r.nextInt(4)) { words[r.nextInt(words.size)] } } else null
            DocPage("Başlık${i}x", paras.ifEmpty { listOf("boş") }, tbl)
        }
        return Doc(DocKind.TEXT, pages)
    }
    private fun wf(b: ByteArray) { val f = javax.xml.parsers.DocumentBuilderFactory.newInstance(); f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); f.newDocumentBuilder().parse(ByteArrayInputStream(b)) }
    private fun text(d: Doc) = squash(d.pages.joinToString("") { p -> p.paragraphs.joinToString("") + (p.table ?: emptyList()).joinToString("") { it.joinToString("") } })

    @Test fun roundTripEveryFormat() {
        val r = Random(56)
        repeat(60) { n ->
            val d = doc(r); val want = text(d)
            for (t in listOf(ConvTarget.TXT, ConvTarget.DOCX, ConvTarget.XLSX, ConvTarget.PPTX, ConvTarget.ODT, ConvTarget.ODS, ConvTarget.ODP, ConvTarget.RTF)) {
                val got = text(DocParse.parse("x." + t.ext, DocWrite.write(d, t)!!))
                // metin sırası korunmalı; XLSX/ODS/PPTX/ODP'de başlık satırı eklenebilir
                assertTrue("#$n $t eksik", want.all { true } && containsInOrder(got, d))
            }
        }
    }
    private fun containsInOrder(got: String, d: Doc): Boolean {
        var from = 0
        for (p in d.pages) for (s in p.paragraphs + (p.table ?: emptyList()).flatten()) {
            val k = squash(s); if (k.isEmpty()) continue
            val i = got.indexOf(k, from); if (i < 0) return false; from = i + k.length
        }
        return true
    }
    @Test fun everyXmlPartWellFormed() {
        val r = Random(7)
        repeat(40) {
            val d = doc(r)
            for (t in listOf(ConvTarget.DOCX, ConvTarget.XLSX, ConvTarget.PPTX, ConvTarget.ODT, ConvTarget.ODS, ConvTarget.ODP))
                ZipInputStream(ByteArrayInputStream(DocWrite.write(d, t)!!)).use { z -> while (true) { val e = z.nextEntry ?: break; val b = z.readBytes(); if (e.name != "mimetype") wf(b) } }
        }
    }
    @Test fun htmlAndCsvNeverThrow() { val r = Random(3); repeat(100) { val d = doc(r); DocWrite.write(d, ConvTarget.HTML)!!; DocWrite.write(d, ConvTarget.CSV)!!; DocWrite.write(d, ConvTarget.MD)!! } }
    @Test fun controlCharsNeverBreakXml() {
        val d = Doc(DocKind.TEXT, listOf(DocPage("t\u0000\u0001", listOf("a\u0002b\uD800c\uFFFFd"), listOf(listOf("\u0003", "ok")))))
        for (t in listOf(ConvTarget.DOCX, ConvTarget.XLSX, ConvTarget.PPTX, ConvTarget.ODT, ConvTarget.ODS, ConvTarget.ODP))
            ZipInputStream(ByteArrayInputStream(DocWrite.write(d, t)!!)).use { z -> while (true) { val e = z.nextEntry ?: break; val b = z.readBytes(); if (e.name != "mimetype") wf(b) } }
    }
}
