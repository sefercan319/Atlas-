package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.45: geniş kapsamlı tablo tabanlı testler (saf mantık + dil dosyaları). */
class BulkLogicTest {
    @Test fun parseTimeValidHour00() { assertEquals(30, Pure.parseTime("00:30")) }
    @Test fun parseTimeValidHour01() { assertEquals(90, Pure.parseTime("01:30")) }
    @Test fun parseTimeValidHour02() { assertEquals(150, Pure.parseTime("02:30")) }
    @Test fun parseTimeValidHour03() { assertEquals(210, Pure.parseTime("03:30")) }
    @Test fun parseTimeValidHour04() { assertEquals(270, Pure.parseTime("04:30")) }
    @Test fun parseTimeValidHour05() { assertEquals(330, Pure.parseTime("05:30")) }
    @Test fun parseTimeValidHour06() { assertEquals(390, Pure.parseTime("06:30")) }
    @Test fun parseTimeValidHour07() { assertEquals(450, Pure.parseTime("07:30")) }
    @Test fun parseTimeValidHour08() { assertEquals(510, Pure.parseTime("08:30")) }
    @Test fun parseTimeValidHour09() { assertEquals(570, Pure.parseTime("09:30")) }
    @Test fun parseTimeValidHour10() { assertEquals(630, Pure.parseTime("10:30")) }
    @Test fun parseTimeValidHour11() { assertEquals(690, Pure.parseTime("11:30")) }
    @Test fun parseTimeValidHour12() { assertEquals(750, Pure.parseTime("12:30")) }
    @Test fun parseTimeValidHour13() { assertEquals(810, Pure.parseTime("13:30")) }
    @Test fun parseTimeValidHour14() { assertEquals(870, Pure.parseTime("14:30")) }
    @Test fun parseTimeValidHour15() { assertEquals(930, Pure.parseTime("15:30")) }
    @Test fun parseTimeValidHour16() { assertEquals(990, Pure.parseTime("16:30")) }
    @Test fun parseTimeValidHour17() { assertEquals(1050, Pure.parseTime("17:30")) }
    @Test fun parseTimeValidHour18() { assertEquals(1110, Pure.parseTime("18:30")) }
    @Test fun parseTimeValidHour19() { assertEquals(1170, Pure.parseTime("19:30")) }
    @Test fun parseTimeValidHour20() { assertEquals(1230, Pure.parseTime("20:30")) }
    @Test fun parseTimeValidHour21() { assertEquals(1290, Pure.parseTime("21:30")) }
    @Test fun parseTimeValidHour22() { assertEquals(1350, Pure.parseTime("22:30")) }
    @Test fun parseTimeValidHour23() { assertEquals(1410, Pure.parseTime("23:30")) }
    @Test fun parseTimeInvalid0() { assertNull(Pure.parseTime("24:00")) }
    @Test fun parseTimeInvalid1() { assertNull(Pure.parseTime("12:60")) }
    @Test fun parseTimeInvalid2() { assertNull(Pure.parseTime("abc")) }
    @Test fun parseTimeInvalid3() { assertNull(Pure.parseTime("")) }
    @Test fun parseTimeInvalid4() { assertNull(Pure.parseTime("1230")) }
    @Test fun parseTimeInvalid5() { assertNull(Pure.parseTime("12:5")) }
    @Test fun parseTimeInvalid6() { assertNull(Pure.parseTime("-1:00")) }
    @Test fun parseTimeInvalid7() { assertNull(Pure.parseTime("12:")) }
    @Test fun parseTimeInvalid8() { assertNull(Pure.parseTime("99:99")) }
    @Test fun parseTimeInvalid9() { assertNull(Pure.parseTime("1:2:3")) }
    @Test fun parseTimeDotSeparator() { assertEquals(545, Pure.parseTime("9.05")) }
    @Test fun parseTimeTrimsSpaces() { assertEquals(60, Pure.parseTime("  01:00 ")) }
    @Test fun fmtTime0() { assertEquals("00:00", Pure.fmtTime(0)) }
    @Test fun fmtTime5() { assertEquals("00:05", Pure.fmtTime(5)) }
    @Test fun fmtTime59() { assertEquals("00:59", Pure.fmtTime(59)) }
    @Test fun fmtTime60() { assertEquals("01:00", Pure.fmtTime(60)) }
    @Test fun fmtTime61() { assertEquals("01:01", Pure.fmtTime(61)) }
    @Test fun fmtTime599() { assertEquals("09:59", Pure.fmtTime(599)) }
    @Test fun fmtTime600() { assertEquals("10:00", Pure.fmtTime(600)) }
    @Test fun fmtTime725() { assertEquals("12:05", Pure.fmtTime(725)) }
    @Test fun fmtTime1000() { assertEquals("16:40", Pure.fmtTime(1000)) }
    @Test fun fmtTime1380() { assertEquals("23:00", Pure.fmtTime(1380)) }
    @Test fun fmtTime1439() { assertEquals("23:59", Pure.fmtTime(1439)) }
    @Test fun fmtTime720() { assertEquals("12:00", Pure.fmtTime(720)) }
    @Test fun inQuietCase0() { assertTrue(Pure.inQuiet(0, 1380, 420)) }
    @Test fun inQuietCase1() { assertTrue(Pure.inQuiet(1400, 1380, 420)) }
    @Test fun inQuietCase2() { assertFalse(Pure.inQuiet(430, 1380, 420)) }
    @Test fun inQuietCase3() { assertTrue(Pure.inQuiet(419, 1380, 420)) }
    @Test fun inQuietCase4() { assertFalse(Pure.inQuiet(420, 1380, 420)) }
    @Test fun inQuietCase5() { assertFalse(Pure.inQuiet(1379, 1380, 420)) }
    @Test fun inQuietCase6() { assertFalse(Pure.inQuiet(600, 0, 0)) }
    @Test fun inQuietCase7() { assertTrue(Pure.inQuiet(600, 600, 601)) }
    @Test fun inQuietCase8() { assertFalse(Pure.inQuiet(601, 600, 601)) }
    @Test fun inQuietCase9() { assertFalse(Pure.inQuiet(30, 60, 120)) }
    @Test fun inQuietCase10() { assertTrue(Pure.inQuiet(60, 60, 120)) }
    @Test fun inQuietCase11() { assertTrue(Pure.inQuiet(119, 60, 120)) }
    @Test fun inQuietCase12() { assertFalse(Pure.inQuiet(120, 60, 120)) }
    @Test fun inQuietCase13() { assertTrue(Pure.inQuiet(0, 0, 60)) }
    @Test fun inQuietCase14() { assertTrue(Pure.inQuiet(1439, 1380, 0)) }
    @Test fun inQuietCase15() { assertFalse(Pure.inQuiet(0, 1380, 0)) }
    @Test fun inQuietCase16() { assertTrue(Pure.inQuiet(5, 1439, 10)) }
    @Test fun inQuietCase17() { assertTrue(Pure.inQuiet(1439, 1439, 10)) }
    @Test fun inQuietCase18() { assertFalse(Pure.inQuiet(11, 1439, 10)) }
    @Test fun inQuietCase19() { assertFalse(Pure.inQuiet(300, 300, 300)) }
    @Test fun autoScaleCase0() { assertEquals(0.9f, Pure.autoScale(280, 500), 0.0001f) }
    @Test fun autoScaleCase1() { assertEquals(0.9f, Pure.autoScale(319, 640), 0.0001f) }
    @Test fun autoScaleCase2() { assertEquals(0.95f, Pure.autoScale(320, 640), 0.0001f) }
    @Test fun autoScaleCase3() { assertEquals(0.95f, Pure.autoScale(359, 700), 0.0001f) }
    @Test fun autoScaleCase4() { assertEquals(1.0f, Pure.autoScale(360, 800), 0.0001f) }
    @Test fun autoScaleCase5() { assertEquals(1.0f, Pure.autoScale(411, 914), 0.0001f) }
    @Test fun autoScaleCase6() { assertEquals(1.0f, Pure.autoScale(479, 900), 0.0001f) }
    @Test fun autoScaleCase7() { assertEquals(1.05f, Pure.autoScale(480, 900), 0.0001f) }
    @Test fun autoScaleCase8() { assertEquals(1.05f, Pure.autoScale(599, 960), 0.0001f) }
    @Test fun autoScaleCase9() { assertEquals(1.12f, Pure.autoScale(600, 1000), 0.0001f) }
    @Test fun autoScaleCase10() { assertEquals(1.12f, Pure.autoScale(719, 1200), 0.0001f) }
    @Test fun autoScaleCase11() { assertEquals(1.2f, Pure.autoScale(720, 1280), 0.0001f) }
    @Test fun autoScaleCase12() { assertEquals(1.2f, Pure.autoScale(839, 1300), 0.0001f) }
    @Test fun autoScaleCase13() { assertEquals(1.3f, Pure.autoScale(840, 1400), 0.0001f) }
    @Test fun autoScaleCase14() { assertEquals(1.3f, Pure.autoScale(1000, 1600), 0.0001f) }
    @Test fun autoScaleCase15() { assertEquals(1.3f, Pure.autoScale(1440, 2560), 0.0001f) }
    @Test fun autoScaleCase16() { assertEquals(1.3f, Pure.autoScale(2560, 1440), 0.0001f) }
    @Test fun autoScaleCase17() { assertEquals(1.0f, Pure.autoScale(0, 0), 0.0001f) }
    @Test fun autoScaleCase18() { assertEquals(1.0f, Pure.autoScale(-5, 100), 0.0001f) }
    @Test fun autoScaleCase19() { assertEquals(1.0f, Pure.autoScale(900, 411), 0.0001f) }
    @Test fun effectiveScaleCase0() { assertEquals(1.2f, Pure.effectiveScale(0.0f, 1.2f), 0.0001f) }
    @Test fun effectiveScaleCase1() { assertEquals(1.05f, Pure.effectiveScale(-1.0f, 1.05f), 0.0001f) }
    @Test fun effectiveScaleCase2() { assertEquals(0.7f, Pure.effectiveScale(0.5f, 1.0f), 0.0001f) }
    @Test fun effectiveScaleCase3() { assertEquals(0.7f, Pure.effectiveScale(0.7f, 1.0f), 0.0001f) }
    @Test fun effectiveScaleCase4() { assertEquals(1.0f, Pure.effectiveScale(1.0f, 1.3f), 0.0001f) }
    @Test fun effectiveScaleCase5() { assertEquals(1.6f, Pure.effectiveScale(1.6f, 1.0f), 0.0001f) }
    @Test fun effectiveScaleCase6() { assertEquals(1.6f, Pure.effectiveScale(2.0f, 1.0f), 0.0001f) }
    @Test fun effectiveScaleCase7() { assertEquals(1.15f, Pure.effectiveScale(1.15f, 0.9f), 0.0001f) }
    @Test fun pctCase0() { assertEquals(0, Pure.pct(0, 0)) }
    @Test fun pctCase1() { assertEquals(0, Pure.pct(0, 5)) }
    @Test fun pctCase2() { assertEquals(33, Pure.pct(1, 3)) }
    @Test fun pctCase3() { assertEquals(66, Pure.pct(2, 3)) }
    @Test fun pctCase4() { assertEquals(100, Pure.pct(3, 3)) }
    @Test fun pctCase5() { assertEquals(50, Pure.pct(5, 10)) }
    @Test fun pctCase6() { assertEquals(77, Pure.pct(7, 9)) }
    @Test fun pctCase7() { assertEquals(1, Pure.pct(1, 100)) }
    @Test fun pctCase8() { assertEquals(99, Pure.pct(99, 100)) }
    @Test fun pctCase9() { assertEquals(0, Pure.pct(0, 1)) }
    @Test fun pctCase10() { assertEquals(100, Pure.pct(1, 1)) }
    @Test fun pctCase11() { assertEquals(0, Pure.pct(50, -1)) }
    @Test fun slicePctCase0() { assertEquals(0, Pure.slicePct(0L, 0L)) }
    @Test fun slicePctCase1() { assertEquals(33, Pure.slicePct(1L, 3L)) }
    @Test fun slicePctCase2() { assertEquals(66, Pure.slicePct(2L, 3L)) }
    @Test fun slicePctCase3() { assertEquals(25, Pure.slicePct(50L, 200L)) }
    @Test fun slicePctCase4() { assertEquals(100, Pure.slicePct(200L, 200L)) }
    @Test fun slicePctCase5() { assertEquals(0, Pure.slicePct(1L, 1000L)) }
    @Test fun slicePctCase6() { assertEquals(99, Pure.slicePct(999L, 1000L)) }
    @Test fun slicePctCase7() { assertEquals(0, Pure.slicePct(5L, 0L)) }
    @Test fun perUnlockCase0() { assertEquals(0L, Pure.perUnlockMs(1000L, 0)) }
    @Test fun perUnlockCase1() { assertEquals(1000L, Pure.perUnlockMs(1000L, 1)) }
    @Test fun perUnlockCase2() { assertEquals(333L, Pure.perUnlockMs(1000L, 3)) }
    @Test fun perUnlockCase3() { assertEquals(0L, Pure.perUnlockMs(0L, 5)) }
    @Test fun perUnlockCase4() { assertEquals(85714L, Pure.perUnlockMs(600000L, 7)) }
    @Test fun perUnlockCase5() { assertEquals(0L, Pure.perUnlockMs(5L, -2)) }
    @Test fun nightMsCase0() { assertEquals(0L, Pure.nightMs(longArrayOf())) }
    @Test fun nightMsCase1() { assertEquals(1L, Pure.nightMs(longArrayOf(1L))) }
    @Test fun nightMsCase2() { assertEquals(15L, Pure.nightMs(longArrayOf(1L,2L,3L,4L,5L,6L))) }
    @Test fun nightMsCase3() { assertEquals(0L, Pure.nightMs(longArrayOf(0L,0L,0L,0L,0L,9L))) }
    @Test fun nightMsCase4() { assertEquals(50L, Pure.nightMs(longArrayOf(10L,10L,10L,10L,10L,10L,10L))) }
    @Test fun nightMsCase5() { assertEquals(20L, Pure.nightMs(longArrayOf(5L,5L,5L,5L))) }
    @Test fun barFractionsEmpty() { assertEquals(0, Pure.barFractions(emptyList()).size) }
    @Test fun barFractionsAllZero() { assertEquals(listOf(0f, 0f), Pure.barFractions(listOf(0L, 0L))) }
    @Test fun barFractionsMaxIsOne() { assertEquals(1f, Pure.barFractions(listOf(5L, 10L, 2L))[1], 0.0001f) }
    @Test fun barFractionsHalf() { assertEquals(0.5f, Pure.barFractions(listOf(5L, 10L))[0], 0.0001f) }
    @Test fun barFractionsSingle() { assertEquals(listOf(1f), Pure.barFractions(listOf(7L))) }
    @Test fun barFractionsSizeKept() { assertEquals(4, Pure.barFractions(listOf(1L, 2L, 3L, 4L)).size) }
    @Test fun winClassCase0() { assertEquals(Pure.WinClass.COMPACT, Pure.winClass(0)) }
    @Test fun winClassCase1() { assertEquals(Pure.WinClass.COMPACT, Pure.winClass(320)) }
    @Test fun winClassCase2() { assertEquals(Pure.WinClass.COMPACT, Pure.winClass(411)) }
    @Test fun winClassCase3() { assertEquals(Pure.WinClass.COMPACT, Pure.winClass(599)) }
    @Test fun winClassCase4() { assertEquals(Pure.WinClass.MEDIUM, Pure.winClass(600)) }
    @Test fun winClassCase5() { assertEquals(Pure.WinClass.MEDIUM, Pure.winClass(700)) }
    @Test fun winClassCase6() { assertEquals(Pure.WinClass.MEDIUM, Pure.winClass(839)) }
    @Test fun winClassCase7() { assertEquals(Pure.WinClass.EXPANDED, Pure.winClass(840)) }
    @Test fun winClassCase8() { assertEquals(Pure.WinClass.EXPANDED, Pure.winClass(1000)) }
    @Test fun winClassCase9() { assertEquals(Pure.WinClass.EXPANDED, Pure.winClass(2000)) }
    @Test fun isLandscapeCase0() { assertFalse(Pure.isLandscape(411, 914)) }
    @Test fun useRailCase0() { assertFalse(Pure.useRail(411, 914)) }
    @Test fun isLandscapeCase1() { assertTrue(Pure.isLandscape(914, 411)) }
    @Test fun useRailCase1() { assertTrue(Pure.useRail(914, 411)) }
    @Test fun isLandscapeCase2() { assertTrue(Pure.isLandscape(480, 479)) }
    @Test fun useRailCase2() { assertTrue(Pure.useRail(480, 479)) }
    @Test fun isLandscapeCase3() { assertFalse(Pure.isLandscape(479, 478)) }
    @Test fun useRailCase3() { assertFalse(Pure.useRail(479, 478)) }
    @Test fun isLandscapeCase4() { assertFalse(Pure.isLandscape(500, 500)) }
    @Test fun useRailCase4() { assertFalse(Pure.useRail(500, 500)) }
    @Test fun isLandscapeCase5() { assertTrue(Pure.isLandscape(1000, 600)) }
    @Test fun useRailCase5() { assertTrue(Pure.useRail(1000, 600)) }
    @Test fun isLandscapeCase6() { assertFalse(Pure.isLandscape(600, 1000)) }
    @Test fun useRailCase6() { assertTrue(Pure.useRail(600, 1000)) }
    @Test fun isLandscapeCase7() { assertTrue(Pure.isLandscape(480, 300)) }
    @Test fun useRailCase7() { assertTrue(Pure.useRail(480, 300)) }
    @Test fun contentMaxCase0() { assertEquals(720, Pure.contentMaxDp(360)) }
    @Test fun contentMaxCase1() { assertEquals(720, Pure.contentMaxDp(720)) }
    @Test fun contentMaxCase2() { assertEquals(720, Pure.contentMaxDp(999)) }
    @Test fun contentMaxCase3() { assertEquals(880, Pure.contentMaxDp(1000)) }
    @Test fun contentMaxCase4() { assertEquals(880, Pure.contentMaxDp(1600)) }
    @Test fun niceStepCase0() { assertEquals(5, Pure.niceStepMin(0L)) }
    @Test fun axisMaxCase0() { assertEquals(300000L, Pure.axisMaxMs(0L)) }
    @Test fun niceStepCase1() { assertEquals(5, Pure.niceStepMin(60000L)) }
    @Test fun axisMaxCase1() { assertEquals(300000L, Pure.axisMaxMs(60000L)) }
    @Test fun niceStepCase2() { assertEquals(5, Pure.niceStepMin(1200000L)) }
    @Test fun axisMaxCase2() { assertEquals(1200000L, Pure.axisMaxMs(1200000L)) }
    @Test fun niceStepCase3() { assertEquals(10, Pure.niceStepMin(1260000L)) }
    @Test fun axisMaxCase3() { assertEquals(1800000L, Pure.axisMaxMs(1260000L)) }
    @Test fun niceStepCase4() { assertEquals(10, Pure.niceStepMin(2400000L)) }
    @Test fun axisMaxCase4() { assertEquals(2400000L, Pure.axisMaxMs(2400000L)) }
    @Test fun niceStepCase5() { assertEquals(30, Pure.niceStepMin(3660000L)) }
    @Test fun axisMaxCase5() { assertEquals(5400000L, Pure.axisMaxMs(3660000L)) }
    @Test fun niceStepCase6() { assertEquals(30, Pure.niceStepMin(7200000L)) }
    @Test fun axisMaxCase6() { assertEquals(7200000L, Pure.axisMaxMs(7200000L)) }
    @Test fun niceStepCase7() { assertEquals(120, Pure.niceStepMin(18000000L)) }
    @Test fun axisMaxCase7() { assertEquals(21600000L, Pure.axisMaxMs(18000000L)) }
    @Test fun niceStepCase8() { assertEquals(180, Pure.niceStepMin(36000000L)) }
    @Test fun axisMaxCase8() { assertEquals(43200000L, Pure.axisMaxMs(36000000L)) }
    @Test fun niceStepCase9() { assertEquals(480, Pure.niceStepMin(90000000L)) }
    @Test fun axisMaxCase9() { assertEquals(115200000L, Pure.axisMaxMs(90000000L)) }
    @Test fun fmtDur0() { assertEquals("0m", Pure.fmtDur(0)) }
    @Test fun fmtDur1() { assertEquals("1m", Pure.fmtDur(1)) }
    @Test fun fmtDur59() { assertEquals("59m", Pure.fmtDur(59)) }
    @Test fun fmtDur60() { assertEquals("1h 00m", Pure.fmtDur(60)) }
    @Test fun fmtDur61() { assertEquals("1h 01m", Pure.fmtDur(61)) }
    @Test fun fmtDur90() { assertEquals("1h 30m", Pure.fmtDur(90)) }
    @Test fun fmtDur125() { assertEquals("2h 05m", Pure.fmtDur(125)) }
    @Test fun fmtDur600() { assertEquals("10h 00m", Pure.fmtDur(600)) }
    @Test fun totalPlannedCase0() { assertEquals(0, Pure.totalPlanned(listOf())) }
    @Test fun totalPlannedCase1() { assertEquals(30, Pure.totalPlanned(listOf(30))) }
    @Test fun totalPlannedCase2() { assertEquals(90, Pure.totalPlanned(listOf(30,-5,60))) }
    @Test fun totalPlannedCase3() { assertEquals(0, Pure.totalPlanned(listOf(0,0))) }
    @Test fun totalPlannedCase4() { assertEquals(45, Pure.totalPlanned(listOf(15,15,15))) }
    @Test fun overlapsCase0() { assertFalse(Pure.overlaps(0, 60, 60, 60)) }
    @Test fun overlapsCase1() { assertTrue(Pure.overlaps(0, 60, 59, 60)) }
    @Test fun overlapsCase2() { assertTrue(Pure.overlaps(30, 30, 0, 31)) }
    @Test fun overlapsCase3() { assertFalse(Pure.overlaps(-1, 60, 0, 60)) }
    @Test fun overlapsCase4() { assertFalse(Pure.overlaps(0, 60, -1, 60)) }
    @Test fun overlapsCase5() { assertTrue(Pure.overlaps(100, 10, 100, 10)) }
    @Test fun overlapsCase6() { assertFalse(Pure.overlaps(100, 10, 110, 10)) }
    @Test fun overlapsCase7() { assertFalse(Pure.overlaps(100, 0, 100, 10)) }
    @Test fun overlapsCase8() { assertTrue(Pure.overlaps(10, 50, 20, 5)) }
    @Test fun overlapsCase9() { assertFalse(Pure.overlaps(500, 60, 0, 30)) }
    @Test fun nameMatchesCase0() { assertTrue(Pure.nameMatches("Instagram", "insta")) }
    @Test fun nameMatchesCase1() { assertTrue(Pure.nameMatches("Instagram", "")) }
    @Test fun nameMatchesCase2() { assertTrue(Pure.nameMatches("Instagram", "  ")) }
    @Test fun nameMatchesCase3() { assertTrue(Pure.nameMatches("Instagram", "gram")) }
    @Test fun nameMatchesCase4() { assertFalse(Pure.nameMatches("Instagram", "x")) }
    @Test fun nameMatchesCase5() { assertTrue(Pure.nameMatches("YouTube", "TUBE")) }
    @Test fun nameMatchesCase6() { assertFalse(Pure.nameMatches("TikTok", "tok tok")) }
    @Test fun nameMatchesCase7() { assertTrue(Pure.nameMatches("WhatsApp", " whats ")) }
    @Test fun nameMatchesCase8() { assertTrue(Pure.nameMatches("Çay", "çay")) }
    @Test fun nameMatchesCase9() { assertFalse(Pure.nameMatches("Netflix", "netflix2")) }
    @Test fun fillTplTwoVars() { assertEquals("a-b", Pure.fillTpl("{x}-{y}", mapOf("x" to "a", "y" to "b"))) }
    @Test fun fillTplRepeated() { assertEquals("aa", Pure.fillTpl("{x}{x}", mapOf("x" to "a"))) }
    @Test fun fillTplEmptyTemplate() { assertEquals("", Pure.fillTpl("", mapOf("x" to "a"))) }
    @Test fun fillTplNoVars() { assertEquals("hello", Pure.fillTpl(" hello ", emptyMap())) }
    @Test fun fillTplUnknownKept() { assertEquals("{z}", Pure.fillTpl("{z}", mapOf("x" to "a"))) }
    @Test fun fillTplExactly200() { assertEquals(200, Pure.fillTpl("b".repeat(200), emptyMap()).length) }
    @Test fun fillTpl201Cut() { assertEquals(200, Pure.fillTpl("b".repeat(201), emptyMap()).length) }
    @Test fun msgOrDefaultBlank() { assertEquals("d", Pure.msgOrDefault("", "d", emptyMap())) }
    @Test fun msgOrDefaultUsesCustom() { assertEquals("c", Pure.msgOrDefault("c", "d", emptyMap())) }
    @Test fun msgOrDefaultEmptyAfterFill() { assertEquals("d", Pure.msgOrDefault("{a}", "d", mapOf("a" to ""))) }
    @Test fun waterFractionCase0() { assertEquals(0.0f, Pure.waterFraction(0, 8), 0.0001f) }
    @Test fun waterFractionCase1() { assertEquals(0.5f, Pure.waterFraction(4, 8), 0.0001f) }
    @Test fun waterFractionCase2() { assertEquals(1.0f, Pure.waterFraction(8, 8), 0.0001f) }
    @Test fun waterFractionCase3() { assertEquals(1.0f, Pure.waterFraction(12, 8), 0.0001f) }
    @Test fun waterFractionCase4() { assertEquals(0.0f, Pure.waterFraction(3, 0), 0.0001f) }
    @Test fun waterFractionCase5() { assertEquals(0.0f, Pure.waterFraction(-1, 8), 0.0001f) }
    @Test fun inWarnWindowCase0() { assertFalse(Pure.inWarnWindow(0L, 60, 80)) }
    @Test fun limitReachedCase0() { assertFalse(Pure.limitReached(0L, 60)) }
    @Test fun inWarnWindowCase1() { assertFalse(Pure.inWarnWindow(2820000L, 60, 80)) }
    @Test fun limitReachedCase1() { assertFalse(Pure.limitReached(2820000L, 60)) }
    @Test fun inWarnWindowCase2() { assertTrue(Pure.inWarnWindow(2880000L, 60, 80)) }
    @Test fun limitReachedCase2() { assertFalse(Pure.limitReached(2880000L, 60)) }
    @Test fun inWarnWindowCase3() { assertTrue(Pure.inWarnWindow(3540000L, 60, 80)) }
    @Test fun limitReachedCase3() { assertFalse(Pure.limitReached(3540000L, 60)) }
    @Test fun inWarnWindowCase4() { assertFalse(Pure.inWarnWindow(3600000L, 60, 80)) }
    @Test fun limitReachedCase4() { assertTrue(Pure.limitReached(3600000L, 60)) }
    @Test fun inWarnWindowCase5() { assertFalse(Pure.inWarnWindow(10L, 0, 80)) }
    @Test fun limitReachedCase5() { assertFalse(Pure.limitReached(10L, 0)) }
    @Test fun inWarnWindowCase6() { assertTrue(Pure.inWarnWindow(1800000L, 60, 50)) }
    @Test fun limitReachedCase6() { assertFalse(Pure.limitReached(1800000L, 60)) }
    @Test fun inWarnWindowCase7() { assertFalse(Pure.inWarnWindow(1740000L, 60, 50)) }
    @Test fun limitReachedCase7() { assertFalse(Pure.limitReached(1740000L, 60)) }
    @Test fun staleDayKeyCase0() { assertFalse(Pure.staleDayKey("fu:2026-10-25", java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun staleDayKeyCase1() { assertFalse(Pure.staleDayKey("fu:2026-10-11", java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun staleDayKeyCase2() { assertTrue(Pure.staleDayKey("fu:2026-10-10", java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun staleDayKeyCase3() { assertTrue(Pure.staleDayKey("warn:2026-01-01:app", java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun staleDayKeyCase4() { assertFalse(Pure.staleDayKey("limnote:2026-10-24:x", java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun staleDayKeyCase5() { assertTrue(Pure.staleDayKey("passn:2020-01-01", java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun staleDayKeyCase6() { assertFalse(Pure.staleDayKey("other:2020-01-01", java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun staleDayKeyCase7() { assertTrue(Pure.staleDayKey("bc:2026-09-01", java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun staleDayKeyCase8() { assertFalse(Pure.staleDayKey("fu:xxxx", java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun staleDayKeyCase9() { assertTrue(Pure.staleDayKey("fu:2026-13-45", java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun pomoLeftCase0() { assertEquals(0L, Pure.pomoLeftMs(0L, 5L)) }
    @Test fun pomoLeftCase1() { assertEquals(0L, Pure.pomoLeftMs(-3L, 5L)) }
    @Test fun pomoLeftCase2() { assertEquals(60L, Pure.pomoLeftMs(100L, 40L)) }
    @Test fun pomoLeftCase3() { assertEquals(0L, Pure.pomoLeftMs(100L, 100L)) }
    @Test fun pomoLeftCase4() { assertEquals(0L, Pure.pomoLeftMs(100L, 200L)) }
    @Test fun pctChangeCase0() { assertNull(Pure.pctChange(0L, 5L)) }
    @Test fun pctChangeCase1() { assertNull(Pure.pctChange(-1L, 5L)) }
    @Test fun pctChangeCase2() { assertEquals(50, Pure.pctChange(100L, 150L)) }
    @Test fun pctChangeCase3() { assertEquals(-50, Pure.pctChange(100L, 50L)) }
    @Test fun pctChangeCase4() { assertEquals(0, Pure.pctChange(100L, 100L)) }
    @Test fun pctChangeCase5() { assertEquals(233, Pure.pctChange(3L, 10L)) }
    @Test fun streakCase0() { assertEquals(0, Pure.streak(setOf<String>(), java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun streakCase1() { assertEquals(1, Pure.streak(setOf<String>("2026-10-25"), java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun streakCase2() { assertEquals(1, Pure.streak(setOf<String>("2026-10-24"), java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun streakCase3() { assertEquals(0, Pure.streak(setOf<String>("2026-10-23"), java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun streakCase4() { assertEquals(3, Pure.streak(setOf<String>("2026-10-25","2026-10-24","2026-10-23"), java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun streakCase5() { assertEquals(1, Pure.streak(setOf<String>("2026-10-25","2026-10-23"), java.time.LocalDate.of(2026, 10, 25))) }
    @Test fun freeSlotCase0() { assertEquals(480, Pure.freeSlot(listOf<Pair<Int, Int>>(), 480, 540, 30)) }
    @Test fun freeSlotCase1() { assertEquals(540, Pure.freeSlot(listOf<Pair<Int, Int>>(480 to 60), 480, 600, 30)) }
    @Test fun freeSlotCase2() { assertNull(Pure.freeSlot(listOf<Pair<Int, Int>>(480 to 60), 480, 540, 30)) }
    @Test fun freeSlotCase3() { assertEquals(480, Pure.freeSlot(listOf<Pair<Int, Int>>(500 to 30), 480, 600, 20)) }
    @Test fun freeSlotCase4() { assertEquals(540, Pure.freeSlot(listOf<Pair<Int, Int>>(480 to 30,510 to 30), 480, 600, 30)) }
    @Test fun freeSlotCase5() { assertEquals(480, Pure.freeSlot(listOf<Pair<Int, Int>>(-1 to 60), 480, 540, 30)) }
    @Test fun summaryTextBullets() { assertEquals("T\n• a\n• b", Pure.summaryText("T", listOf("a", "b"))) }
    @Test fun summaryTextNoLines() { assertEquals("T\n", Pure.summaryText("T", emptyList())) }
    @Test fun conflictIndexesNone() { assertEquals(emptySet<Int>(), Pure.conflictIndexes(listOf(0 to 30, 30 to 30))) }
    @Test fun conflictIndexesTwo() { assertEquals(setOf(0, 1), Pure.conflictIndexes(listOf(0 to 40, 30 to 30, 100 to 10))) }
    @Test fun taggedReplacesOld() { assertEquals("B Title", Pure.tagged("A Title", "B", listOf("A", "B"))) }
    @Test fun taggedAddsNew() { assertEquals("B Title", Pure.tagged("Title", "B", listOf("A"))) }
    @Test fun strings_default_wellFormedXml() { val t = File(TestFiles.main, "res/values/strings.xml").readText(); assertTrue(t.trim().startsWith("<?xml") || t.trim().startsWith("<resources")); assertTrue(t.trim().endsWith("</resources>")) }
    @Test fun strings_default_hasScaleTitle() { assertTrue(File(TestFiles.main, "res/values/strings.xml").readText().contains("name=\"ui_scale_title\"")) }
    @Test fun strings_default_hasMsgKeys() { val t = File(TestFiles.main, "res/values/strings.xml").readText(); for (k in listOf("msg_title", "msg_hint", "msg_vars")) assertTrue(k, t.contains("name=\"$k\"")) }
    @Test fun strings_default_noEmptyStrings() { assertFalse(Regex("<string name=\"[a-z_0-9]+\"[^>]*></string>").containsMatchIn(File(TestFiles.main, "res/values/strings.xml").readText())) }
    @Test fun strings_default_noUnescapedApostropheInMsgs() { val t = File(TestFiles.main, "res/values/strings.xml").readText(); val m = Regex("<string name=\"msg_[a-z_]+\">(.*?)</string>").findAll(t).map { it.groupValues[1] }.toList(); for (x in m) assertFalse(x, Regex("(?<!\\\\)\\u0027|(?<!\\\\)'").containsMatchIn(x)) }
    @Test fun strings_ar_wellFormedXml() { val t = File(TestFiles.main, "res/values-ar/strings.xml").readText(); assertTrue(t.trim().startsWith("<?xml") || t.trim().startsWith("<resources")); assertTrue(t.trim().endsWith("</resources>")) }
    @Test fun strings_ar_hasScaleTitle() { assertTrue(File(TestFiles.main, "res/values-ar/strings.xml").readText().contains("name=\"ui_scale_title\"")) }
    @Test fun strings_ar_hasMsgKeys() { val t = File(TestFiles.main, "res/values-ar/strings.xml").readText(); for (k in listOf("msg_title", "msg_hint", "msg_vars")) assertTrue(k, t.contains("name=\"$k\"")) }
    @Test fun strings_ar_noEmptyStrings() { assertFalse(Regex("<string name=\"[a-z_0-9]+\"[^>]*></string>").containsMatchIn(File(TestFiles.main, "res/values-ar/strings.xml").readText())) }
    @Test fun strings_ar_noUnescapedApostropheInMsgs() { val t = File(TestFiles.main, "res/values-ar/strings.xml").readText(); val m = Regex("<string name=\"msg_[a-z_]+\">(.*?)</string>").findAll(t).map { it.groupValues[1] }.toList(); for (x in m) assertFalse(x, Regex("(?<!\\\\)\\u0027|(?<!\\\\)'").containsMatchIn(x)) }
    @Test fun strings_az_wellFormedXml() { val t = File(TestFiles.main, "res/values-az/strings.xml").readText(); assertTrue(t.trim().startsWith("<?xml") || t.trim().startsWith("<resources")); assertTrue(t.trim().endsWith("</resources>")) }
    @Test fun strings_az_hasScaleTitle() { assertTrue(File(TestFiles.main, "res/values-az/strings.xml").readText().contains("name=\"ui_scale_title\"")) }
    @Test fun strings_az_hasMsgKeys() { val t = File(TestFiles.main, "res/values-az/strings.xml").readText(); for (k in listOf("msg_title", "msg_hint", "msg_vars")) assertTrue(k, t.contains("name=\"$k\"")) }
    @Test fun strings_az_noEmptyStrings() { assertFalse(Regex("<string name=\"[a-z_0-9]+\"[^>]*></string>").containsMatchIn(File(TestFiles.main, "res/values-az/strings.xml").readText())) }
    @Test fun strings_az_noUnescapedApostropheInMsgs() { val t = File(TestFiles.main, "res/values-az/strings.xml").readText(); val m = Regex("<string name=\"msg_[a-z_]+\">(.*?)</string>").findAll(t).map { it.groupValues[1] }.toList(); for (x in m) assertFalse(x, Regex("(?<!\\\\)\\u0027|(?<!\\\\)'").containsMatchIn(x)) }
    @Test fun strings_de_wellFormedXml() { val t = File(TestFiles.main, "res/values-de/strings.xml").readText(); assertTrue(t.trim().startsWith("<?xml") || t.trim().startsWith("<resources")); assertTrue(t.trim().endsWith("</resources>")) }
    @Test fun strings_de_hasScaleTitle() { assertTrue(File(TestFiles.main, "res/values-de/strings.xml").readText().contains("name=\"ui_scale_title\"")) }
    @Test fun strings_de_hasMsgKeys() { val t = File(TestFiles.main, "res/values-de/strings.xml").readText(); for (k in listOf("msg_title", "msg_hint", "msg_vars")) assertTrue(k, t.contains("name=\"$k\"")) }
    @Test fun strings_de_noEmptyStrings() { assertFalse(Regex("<string name=\"[a-z_0-9]+\"[^>]*></string>").containsMatchIn(File(TestFiles.main, "res/values-de/strings.xml").readText())) }
    @Test fun strings_de_noUnescapedApostropheInMsgs() { val t = File(TestFiles.main, "res/values-de/strings.xml").readText(); val m = Regex("<string name=\"msg_[a-z_]+\">(.*?)</string>").findAll(t).map { it.groupValues[1] }.toList(); for (x in m) assertFalse(x, Regex("(?<!\\\\)\\u0027|(?<!\\\\)'").containsMatchIn(x)) }
    @Test fun strings_en_wellFormedXml() { val t = File(TestFiles.main, "res/values-en/strings.xml").readText(); assertTrue(t.trim().startsWith("<?xml") || t.trim().startsWith("<resources")); assertTrue(t.trim().endsWith("</resources>")) }
    @Test fun strings_en_hasScaleTitle() { assertTrue(File(TestFiles.main, "res/values-en/strings.xml").readText().contains("name=\"ui_scale_title\"")) }
    @Test fun strings_en_hasMsgKeys() { val t = File(TestFiles.main, "res/values-en/strings.xml").readText(); for (k in listOf("msg_title", "msg_hint", "msg_vars")) assertTrue(k, t.contains("name=\"$k\"")) }
    @Test fun strings_en_noEmptyStrings() { assertFalse(Regex("<string name=\"[a-z_0-9]+\"[^>]*></string>").containsMatchIn(File(TestFiles.main, "res/values-en/strings.xml").readText())) }
    @Test fun strings_en_noUnescapedApostropheInMsgs() { val t = File(TestFiles.main, "res/values-en/strings.xml").readText(); val m = Regex("<string name=\"msg_[a-z_]+\">(.*?)</string>").findAll(t).map { it.groupValues[1] }.toList(); for (x in m) assertFalse(x, Regex("(?<!\\\\)\\u0027|(?<!\\\\)'").containsMatchIn(x)) }
    @Test fun strings_es_wellFormedXml() { val t = File(TestFiles.main, "res/values-es/strings.xml").readText(); assertTrue(t.trim().startsWith("<?xml") || t.trim().startsWith("<resources")); assertTrue(t.trim().endsWith("</resources>")) }
    @Test fun strings_es_hasScaleTitle() { assertTrue(File(TestFiles.main, "res/values-es/strings.xml").readText().contains("name=\"ui_scale_title\"")) }
    @Test fun strings_es_hasMsgKeys() { val t = File(TestFiles.main, "res/values-es/strings.xml").readText(); for (k in listOf("msg_title", "msg_hint", "msg_vars")) assertTrue(k, t.contains("name=\"$k\"")) }
    @Test fun strings_es_noEmptyStrings() { assertFalse(Regex("<string name=\"[a-z_0-9]+\"[^>]*></string>").containsMatchIn(File(TestFiles.main, "res/values-es/strings.xml").readText())) }
    @Test fun strings_es_noUnescapedApostropheInMsgs() { val t = File(TestFiles.main, "res/values-es/strings.xml").readText(); val m = Regex("<string name=\"msg_[a-z_]+\">(.*?)</string>").findAll(t).map { it.groupValues[1] }.toList(); for (x in m) assertFalse(x, Regex("(?<!\\\\)\\u0027|(?<!\\\\)'").containsMatchIn(x)) }
    @Test fun strings_fr_wellFormedXml() { val t = File(TestFiles.main, "res/values-fr/strings.xml").readText(); assertTrue(t.trim().startsWith("<?xml") || t.trim().startsWith("<resources")); assertTrue(t.trim().endsWith("</resources>")) }
    @Test fun strings_fr_hasScaleTitle() { assertTrue(File(TestFiles.main, "res/values-fr/strings.xml").readText().contains("name=\"ui_scale_title\"")) }
    @Test fun strings_fr_hasMsgKeys() { val t = File(TestFiles.main, "res/values-fr/strings.xml").readText(); for (k in listOf("msg_title", "msg_hint", "msg_vars")) assertTrue(k, t.contains("name=\"$k\"")) }
    @Test fun strings_fr_noEmptyStrings() { assertFalse(Regex("<string name=\"[a-z_0-9]+\"[^>]*></string>").containsMatchIn(File(TestFiles.main, "res/values-fr/strings.xml").readText())) }
    @Test fun strings_fr_noUnescapedApostropheInMsgs() { val t = File(TestFiles.main, "res/values-fr/strings.xml").readText(); val m = Regex("<string name=\"msg_[a-z_]+\">(.*?)</string>").findAll(t).map { it.groupValues[1] }.toList(); for (x in m) assertFalse(x, Regex("(?<!\\\\)\\u0027|(?<!\\\\)'").containsMatchIn(x)) }
    @Test fun strings_ru_wellFormedXml() { val t = File(TestFiles.main, "res/values-ru/strings.xml").readText(); assertTrue(t.trim().startsWith("<?xml") || t.trim().startsWith("<resources")); assertTrue(t.trim().endsWith("</resources>")) }
    @Test fun strings_ru_hasScaleTitle() { assertTrue(File(TestFiles.main, "res/values-ru/strings.xml").readText().contains("name=\"ui_scale_title\"")) }
    @Test fun strings_ru_hasMsgKeys() { val t = File(TestFiles.main, "res/values-ru/strings.xml").readText(); for (k in listOf("msg_title", "msg_hint", "msg_vars")) assertTrue(k, t.contains("name=\"$k\"")) }
    @Test fun strings_ru_noEmptyStrings() { assertFalse(Regex("<string name=\"[a-z_0-9]+\"[^>]*></string>").containsMatchIn(File(TestFiles.main, "res/values-ru/strings.xml").readText())) }
    @Test fun strings_ru_noUnescapedApostropheInMsgs() { val t = File(TestFiles.main, "res/values-ru/strings.xml").readText(); val m = Regex("<string name=\"msg_[a-z_]+\">(.*?)</string>").findAll(t).map { it.groupValues[1] }.toList(); for (x in m) assertFalse(x, Regex("(?<!\\\\)\\u0027|(?<!\\\\)'").containsMatchIn(x)) }
    @Test fun strings_tr_wellFormedXml() { val t = File(TestFiles.main, "res/values-tr/strings.xml").readText(); assertTrue(t.trim().startsWith("<?xml") || t.trim().startsWith("<resources")); assertTrue(t.trim().endsWith("</resources>")) }
    @Test fun strings_tr_hasScaleTitle() { assertTrue(File(TestFiles.main, "res/values-tr/strings.xml").readText().contains("name=\"ui_scale_title\"")) }
    @Test fun strings_tr_hasMsgKeys() { val t = File(TestFiles.main, "res/values-tr/strings.xml").readText(); for (k in listOf("msg_title", "msg_hint", "msg_vars")) assertTrue(k, t.contains("name=\"$k\"")) }
    @Test fun strings_tr_noEmptyStrings() { assertFalse(Regex("<string name=\"[a-z_0-9]+\"[^>]*></string>").containsMatchIn(File(TestFiles.main, "res/values-tr/strings.xml").readText())) }
    @Test fun strings_tr_noUnescapedApostropheInMsgs() { val t = File(TestFiles.main, "res/values-tr/strings.xml").readText(); val m = Regex("<string name=\"msg_[a-z_]+\">(.*?)</string>").findAll(t).map { it.groupValues[1] }.toList(); for (x in m) assertFalse(x, Regex("(?<!\\\\)\\u0027|(?<!\\\\)'").containsMatchIn(x)) }
}
