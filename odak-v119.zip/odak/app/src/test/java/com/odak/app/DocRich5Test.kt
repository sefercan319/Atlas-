package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.Base64

class DocRich5Test {
    private val PNG = Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
    private fun be16(v: Int) = byteArrayOf((v shr 8).toByte(), v.toByte())
    private fun be32(v: Int) = byteArrayOf((v shr 24).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte())
    private fun file(recs: List<ByteArray>): ByteArray {
        val head = ByteArray(78); "BOOKMOBI".toByteArray().copyInto(head, 60); be16(recs.size).copyInto(head, 76)
        var off = 78 + recs.size * 8 + 2
        val o = ByteArrayOutputStream(); o.write(head)
        for (r in recs) { o.write(be32(off)); o.write(byteArrayOf(0, 0, 0, 0)); off += r.size }
        o.write(byteArrayOf(0, 0)); for (r in recs) o.write(r)
        return o.toByteArray()
    }
    private fun r0(version: Int, firstImage: Int, exth121: Int = -1): ByteArray {
        val r = ByteArray(0x100)
        be16(1).copyInto(r, 0); be16(1).copyInto(r, 8)
        "MOBI".toByteArray().copyInto(r, 16); be32(0xE0).copyInto(r, 20); be32(65001).copyInto(r, 28)
        be32(version).copyInto(r, 36); be32(firstImage).copyInto(r, 0x6C)
        if (exth121 >= 0) {
            be32(0x40).copyInto(r, 0x80)
            val ex = ByteArrayOutputStream()
            ex.write("EXTH".toByteArray()); ex.write(be32(24)); ex.write(be32(1)); ex.write(be32(121)); ex.write(be32(12)); ex.write(be32(exth121))
            return r.copyOf(16 + 0xE0) + ex.toByteArray()
        }
        return r
    }
    private val kfHtml = "<html><body><p>Birinci bölüm</p><img src=\"kindle:embed:0001?mime=image/png\"/></body></html><html><body><p>İkinci bölüm</p></body></html>flow<style>p{}</style>"
    private fun imgs(bl: List<RBlock>): Int = bl.sumOf { b -> when (b) { is RPara -> b.runs.count { it.img != null }; else -> 0 } }

    @Test fun kf8Index() {
        assertEquals(1, Mobi.kf8Index("kindle:embed:0001?mime=image/jpeg")); assertEquals(32, Mobi.kf8Index("kindle:embed:0010")); assertEquals(31, Mobi.kf8Index("kindle:embed:000V"))
        assertEquals(null, Mobi.kf8Index("kindle:embed:00ZZ"))
    }
    @Test fun pureKf8() {
        val d = Mobi.mobiDoc(file(listOf(r0(8, 2), kfHtml.toByteArray(), PNG)))
        assertEquals(2, d.pages.size)
        assertTrue(d.pages[0].paragraphs.joinToString(" ").contains("Birinci"))
        assertEquals(1, imgs(d.pages[0].rich!!.blocks)); assertTrue(d.pages[1].paragraphs.joinToString(" ").contains("İkinci"))
    }
    @Test fun combinedMobi6AndKf8() {
        val d = Mobi.mobiDoc(file(listOf(r0(6, 0, exth121 = 3), "eski".toByteArray(), "BOUNDARY".toByteArray(), r0(8, 2), kfHtml.toByteArray(), PNG)))
        assertEquals(2, d.pages.size)
        assertTrue(d.pages[0].paragraphs.joinToString(" ").contains("Birinci"))
        assertEquals(1, imgs(d.pages[0].rich!!.blocks))
    }
    @Test fun brokenKf8DoesNotCrash() {
        Mobi.mobiDoc(file(listOf(r0(6, 0, exth121 = 99), "x".toByteArray())))
        Mobi.mobiDoc(file(listOf(r0(8, 77), "<html><body>x".toByteArray())))
    }
}

class CssSelectorTest {
    private fun ps(h: String, css: String) = HtmlRich.parse(h, css = css).filterIsInstance<RPara>()
    @Test fun descendantAndChild() {
        val b = ps("<div class=\"a\"><section><p>derin</p></section><p>çocuk</p></div><p>dış</p>", ".a p{color:#ff0000} .a > p{font-weight:bold}")
        assertEquals("FF0000", b[0].runs[0].color); assertTrue(!b[0].runs[0].b)
        assertEquals("FF0000", b[1].runs[0].color); assertTrue(b[1].runs[0].b)
        assertEquals(null, b[2].runs[0].color)
    }
    @Test fun specificityAndAncestorsPop() {
        val b = ps("<div id=\"x\"><p class=\"k\">a</p></div><p class=\"k\">b</p>", "p.k{color:#111111} #x p{color:#222222} div p.k{color:#333333}")
        assertEquals("222222", b[0].runs[0].color); assertEquals("111111", b[1].runs[0].color)
    }
    @Test fun unsupportedSelectorsIgnored() {
        assertEquals(4, HtmlRich.Css("a:hover{color:red} li+li{color:red} [x]{color:red} p:nth-child(2){color:red} p::first-line{color:red}").rules.size)
        assertEquals(1, HtmlRich.Css("ul   >   li.a{color:red}").rules.size)
    }
}

class PptxEffectsTest {
    private val PNG = Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
    private fun zipB(vararg e: Pair<String, ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bo.toByteArray()
    }
    private val NS = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\""
    private val REL = "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
    private fun deck(slide: String, vararg extra: Pair<String, ByteArray>) = DocParse.parse("a.pptx", zipB(
        "ppt/presentation.xml" to "<p:presentation $NS><p:sldSz cx=\"12192000\" cy=\"6858000\"/></p:presentation>".toByteArray(),
        "ppt/slides/slide1.xml" to slide.toByteArray(),
        "ppt/slides/_rels/slide1.xml.rels" to (REL + "<Relationship Id=\"rId2\" Type=\"x/image\" Target=\"../media/i.png\"/><Relationship Id=\"rId3\" Type=\"x/chart\" Target=\"../charts/chart1.xml\"/></Relationships>").toByteArray(),
        "ppt/media/i.png" to PNG,
        "ppt/theme/theme1.xml" to ("<a:theme $NS><a:themeElements><a:clrScheme><a:dk1><a:sysClr val=\"windowText\" lastClr=\"000000\"/></a:dk1><a:accent1><a:srgbClr val=\"4472C4\"/></a:accent1></a:clrScheme></a:themeElements></a:theme>").toByteArray(),
        *extra)).pages[0].rich!!
    private fun boxes(rp: RichPage): List<RBox> = rp.blocks.filterIsInstance<RBox>()

    @Test fun rotationGradientShadow() {
        val rp = deck("<p:sld $NS><p:cSld><p:spTree><p:sp><p:nvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm rot=\"2700000\"><a:off x=\"635000\" y=\"635000\"/><a:ext cx=\"3175000\" cy=\"1270000\"/></a:xfrm>" +
            "<a:gradFill><a:gsLst><a:gs pos=\"0\"><a:srgbClr val=\"FF0000\"/></a:gs><a:gs pos=\"100000\"><a:srgbClr val=\"0000FF\"/></a:gs></a:gsLst><a:lin ang=\"5400000\"/></a:gradFill>" +
            "<a:effectLst><a:outerShdw blurRad=\"50800\"><a:srgbClr val=\"333333\"/></a:outerShdw></a:effectLst></p:spPr><p:txBody><a:p><a:r><a:t>X</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:sld>")
        val b = boxes(rp).single()
        assertEquals(45f, b.rot, 0.01f); assertEquals(listOf("FF0000", "0000FF"), b.grad); assertEquals(90f, b.gradAng, 0.01f); assertEquals("333333", b.shadow)
        val html = String(DocWrite.write(Doc(DocKind.PPTX, listOf(DocPage("1", listOf("X"), null, null, rp))), ConvTarget.HTML, "a")!!)
        assertTrue(html.contains("linear-gradient(180.0deg,#FF0000 0.00%,#0000FF 100.00%)") && html.contains("rotate(45.0deg)") && html.contains("box-shadow"))
    }
    @Test fun nestedGroupsAndColorTransforms() {
        val g = "<p:grpSp><p:nvGrpSpPr/><p:grpSpPr><a:xfrm><a:off x=\"1000000\" y=\"1000000\"/><a:ext cx=\"2000000\" cy=\"2000000\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"1000000\" cy=\"1000000\"/></a:xfrm></p:grpSpPr>" +
            "<p:grpSp><p:nvGrpSpPr/><p:grpSpPr><a:xfrm><a:off x=\"200000\" y=\"200000\"/><a:ext cx=\"400000\" cy=\"400000\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"400000\" cy=\"400000\"/></a:xfrm></p:grpSpPr>" +
            "<p:sp><p:nvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"100000\" y=\"100000\"/><a:ext cx=\"100000\" cy=\"100000\"/></a:xfrm><a:solidFill><a:schemeClr val=\"accent1\"><a:lumMod val=\"20000\"/><a:lumOff val=\"80000\"/></a:schemeClr></a:solidFill></p:spPr></p:sp></p:grpSp></p:grpSp>"
        val b = boxes(deck("<p:sld $NS><p:cSld><p:spTree>$g</p:spTree></p:cSld></p:sld>")).single()
        // iç: (200000+100000)=300000 → dış: 1000000 + 300000*2 = 1600000 EMU → 2520 twips
        assertEquals(1600000 / 635, b.x); assertEquals(1600000 / 635, b.y); assertEquals(200000 / 635, b.w)
        val f = b.fill!!
        assertTrue("açık ton beklenir: $f", Integer.parseInt(f.substring(0, 2), 16) > 0xB0 && Integer.parseInt(f.substring(4, 6), 16) > 0xE0)
    }
    @Test fun pictureCrop() {
        val rp = deck("<p:sld $NS><p:cSld><p:spTree><p:pic><p:nvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed=\"rId2\"/><a:srcRect l=\"10000\" t=\"20000\" r=\"30000\" b=\"0\"/></p:blipFill><p:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"1270000\" cy=\"635000\"/></a:xfrm></p:spPr></p:pic></p:spTree></p:cSld></p:sld>")
        val b = boxes(rp).single()
        assertEquals(listOf(10000, 20000, 30000, 0), b.crop!!.toList())
        val html = RichHtml.page(rp)
        assertTrue(html.contains("object-view-box:inset(20.000% 30.000% 0.000% 10.000%)"))
    }
    private val chart = "<c:chartSpace $NS><c:chart><c:title><c:tx><c:rich><a:p><a:r><a:t>Satışlar</a:t></a:r></a:p></c:rich></c:tx></c:title><c:plotArea><c:barChart><c:barDir val=\"col\"/>" +
        "<c:ser><c:tx><c:strRef><c:strCache><c:pt idx=\"0\"><c:v>2025</c:v></c:pt></c:strCache></c:strRef></c:tx><c:spPr><a:solidFill><a:srgbClr val=\"FF0000\"/></a:solidFill></c:spPr>" +
        "<c:cat><c:strRef><c:strCache><c:pt idx=\"0\"><c:v>Ocak</c:v></c:pt><c:pt idx=\"1\"><c:v>Şubat</c:v></c:pt></c:strCache></c:strRef></c:cat>" +
        "<c:val><c:numRef><c:numCache><c:pt idx=\"0\"><c:v>10</c:v></c:pt><c:pt idx=\"1\"><c:v>20</c:v></c:pt></c:numCache></c:numRef></c:val></c:ser></c:barChart></c:plotArea></c:chart></c:chartSpace>"
    private val frame = "<p:sld $NS><p:cSld><p:spTree><p:graphicFrame><p:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"6350000\" cy=\"3175000\"/></p:xfrm><a:graphic><a:graphicData><c:chart r:id=\"rId3\"/></a:graphicData></a:graphic></p:graphicFrame></p:spTree></p:cSld></p:sld>"
    @Test fun barChartDrawnAsBoxes() {
        val rp = deck(frame, "ppt/charts/chart1.xml" to chart.toByteArray())
        val bs = boxes(rp)
        val bars = bs.filter { it.fill == "FF0000" }
        assertEquals(2, bars.size)
        assertTrue("ikinci çubuk iki kat yüksek", bars[1].h in (bars[0].h * 2 - 3)..(bars[0].h * 2 + 3))
        val texts = bs.flatMap { it.blocks.filterIsInstance<RPara>() }.map { it.plain }
        assertTrue(texts.containsAll(listOf("Satışlar", "Ocak", "Şubat")))
    }
    @Test fun lineChartAndPieTable() {
        val line = chart.replace("c:barChart", "c:lineChart").replace("<c:barDir val=\"col\"/>", "")
        val bs = boxes(deck(frame, "ppt/charts/chart1.xml" to line.toByteArray()))
        assertTrue(bs.any { it.rot != 0f && it.fill == "FF0000" } && bs.count { it.round } == 2)
        val pie = chart.replace("c:barChart", "c:pieChart").replace("<c:barDir val=\"col\"/>", "")
        val pb = boxes(deck(frame, "ppt/charts/chart1.xml" to pie.toByteArray()))
        val pieBox = pb.single { it.pie.isNotEmpty() }
        assertEquals(2, pieBox.pie.size); assertEquals(0.333f, pieBox.pie[0].first, 0.01f)
        assertTrue(pb.flatMap { it.blocks.filterIsInstance<RPara>() }.any { it.plain.contains("Şubat") && it.plain.contains("66.7%") })
        val html = RichHtml.page(deck(frame, "ppt/charts/chart1.xml" to pie.toByteArray()))
        assertTrue(html.contains("conic-gradient(#4472C4 0.000% 33.333%,#ED7D31 33.333% 100.000%)"))
        // çok seriliyse tablo
        val multi = chart.replace("c:barChart", "c:pieChart").replace("<c:barDir val=\"col\"/>", "").replace("</c:ser>", "</c:ser><c:ser><c:val><c:numRef><c:numCache><c:pt idx=\"0\"><c:v>1</c:v></c:pt></c:numCache></c:numRef></c:val></c:ser>")
        val t = boxes(deck(frame, "ppt/charts/chart1.xml" to multi.toByteArray())).flatMap { it.blocks }.filterIsInstance<RTable>().single()
        assertEquals(3, t.rows.size)
    }
    @Test fun brokenChartIgnored() {
        assertTrue(RichChart.render("<c:chartSpace".toByteArray(), 0, 0, 5000, 3000, emptyMap()).isEmpty())
        assertTrue(RichChart.render(RichChart.Data(), 0, 0, 5000, 3000, emptyMap()).isEmpty())
    }
    @Test fun fontAssets() {
        assertEquals("Carlito", FontMap.asset("Calibri")); assertEquals("Caladea", FontMap.asset("Cambria")); assertEquals(null, FontMap.asset("Calibri Light")); assertEquals("Gelasio", FontMap.asset("Georgia")); assertEquals("Arimo", FontMap.asset("Arial")); assertEquals("Tinos", FontMap.asset("Times New Roman")); assertEquals(null, FontMap.asset("Wingdings"))
        assertEquals("fonts/Carlito-BoldItalic.ttf", FontMap.assetFile("Carlito", true, true))
        val code = java.io.File(TestFiles.code, "com/odak/app/docs/DocPdfRich.kt").readText()
        assertTrue(code.contains("RichFonts.typeface") && code.contains("LinearGradient") && code.contains("c.rotate(b.rot"))
        assertTrue(java.io.File(TestFiles.code, "com/odak/app/docs/DocActivity.kt").readText().contains("RichFonts.assets"))
    }
}

class DocRich6Test {
    private val PNG = Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
    private fun zipB(vararg e: Pair<String, ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bo.toByteArray()
    }
    private val NS = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\""
    private fun deck(slide: String, vararg extra: Pair<String, ByteArray>) = DocParse.parse("a.pptx", zipB(
        "ppt/presentation.xml" to "<p:presentation $NS><p:sldSz cx=\"12192000\" cy=\"6858000\"/></p:presentation>".toByteArray(),
        "ppt/slides/slide1.xml" to slide.toByteArray(),
        "ppt/slides/_rels/slide1.xml.rels" to ("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId3\" Type=\"x/chart\" Target=\"../charts/chart1.xml\"/></Relationships>").toByteArray(),
        "ppt/theme/theme1.xml" to ("<a:theme $NS><a:themeElements><a:clrScheme><a:dk1><a:sysClr val=\"windowText\" lastClr=\"000000\"/></a:dk1></a:clrScheme></a:themeElements></a:theme>").toByteArray(),
        *extra)).pages[0].rich!!
    private fun boxes(rp: RichPage) = rp.blocks.filterIsInstance<RBox>()
    private fun ps(h: String, css: String) = HtmlRich.parse(h, css = css).filterIsInstance<RPara>()

    // CSS
    @Test fun cssAttributeFirstChildAndSiblings() {
        val b = ps("<p>bir</p><p>iki</p><p>üç</p><a href=\"https://x.com/a\">k</a><a href=\"b.html\">l</a>",
            "p:first-child{color:#111111} p+p{font-weight:bold} p~p{font-style:italic} a[href^=https]{color:#222222} a[href$=\".html\"]{color:#333333} p:hover{color:red}")
        val p = b.filter { it.runs.isNotEmpty() }
        assertEquals("111111", p[0].runs[0].color); assertTrue(!p[0].runs[0].b)
        assertTrue(p[1].runs[0].b && p[1].runs[0].i); assertTrue(p[2].runs[0].i && p[2].runs[0].b)
        val links = p.flatMap { it.runs }.filter { it.text == "k" || it.text == "l" }
        assertEquals("222222", links.first { it.text == "k" }.color); assertEquals("333333", links.first { it.text == "l" }.color)
    }
    @Test fun cssSiblingAfterNestedElements() {
        val b = ps("<div><p>a</p><span>x</span><p>b</p></div><p>c</p>", "span+p{color:#00ff00} div p{font-style:italic}")
        val p = b.filter { it.runs.isNotEmpty() }.associateBy { it.plain }
        assertEquals(null, p["a"]!!.runs[0].color); assertEquals("00FF00", p["b"]!!.runs[0].color); assertEquals(null, p["c"]!!.runs[0].color)
        assertTrue(p["a"]!!.runs[0].i && p["b"]!!.runs[0].i && !p["c"]!!.runs[0].i)
    }

    // PPTX
    @Test fun flipShadowParamsRadial() {
        val rp = deck("<p:sld $NS><p:cSld><p:spTree><p:sp><p:nvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm flipH=\"1\" flipV=\"1\"><a:off x=\"635000\" y=\"635000\"/><a:ext cx=\"3175000\" cy=\"1270000\"/></a:xfrm>" +
            "<a:gradFill><a:gsLst><a:gs pos=\"0\"><a:srgbClr val=\"FFFFFF\"/></a:gs><a:gs pos=\"100000\"><a:srgbClr val=\"000000\"/></a:gs></a:gsLst><a:path path=\"circle\"/></a:gradFill>" +
            "<a:effectLst><a:outerShdw blurRad=\"127000\" dist=\"254000\" dir=\"0\"><a:srgbClr val=\"222222\"><a:alpha val=\"30000\"/></a:srgbClr></a:outerShdw></a:effectLst></p:spPr></p:sp></p:spTree></p:cSld></p:sld>")
        val b = boxes(rp).single()
        assertTrue(b.flipH && b.flipV && b.radial)
        assertEquals(400, b.shadowDx); assertEquals(0, b.shadowDy); assertEquals(200, b.shadowBlur); assertEquals(30, b.shadowAlpha)
        val html = String(DocWrite.write(Doc(DocKind.PPTX, listOf(DocPage("1", listOf("x"), null, null, rp))), ConvTarget.HTML, "a")!!)
        assertTrue(html.contains("radial-gradient(circle at center,#FFFFFF 0.00%,#000000 100.00%)") && html.contains("scale(-1,-1)") && html.contains("box-shadow:") && html.contains("rgba(34,34,34,0.30)"))
    }
    @Test fun flipNotAppliedToTextShapes() {
        val rp = deck("<p:sld $NS><p:cSld><p:spTree><p:sp><p:nvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm flipH=\"1\"><a:off x=\"0\" y=\"0\"/><a:ext cx=\"3175000\" cy=\"1270000\"/></a:xfrm></p:spPr><p:txBody><a:p><a:r><a:t>Yazı</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:sld>")
        assertTrue(!boxes(rp).single().flipH)
    }
    @Test fun groupRotation() {
        val g = "<p:grpSp><p:nvGrpSpPr/><p:grpSpPr><a:xfrm rot=\"5400000\"><a:off x=\"0\" y=\"0\"/><a:ext cx=\"2000000\" cy=\"2000000\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"2000000\" cy=\"2000000\"/></a:xfrm></p:grpSpPr>" +
            "<p:sp><p:nvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"1500000\" y=\"500000\"/><a:ext cx=\"400000\" cy=\"200000\"/></a:xfrm><a:solidFill><a:srgbClr val=\"112233\"/></a:solidFill></p:spPr></p:sp></p:grpSp>"
        val b = boxes(deck("<p:sld $NS><p:cSld><p:spTree>$g</p:spTree></p:cSld></p:sld>")).single()
        assertEquals(90f, b.rot, 0.01f)
        // merkez (1700000,600000), grup merkezi (1000000,1000000): 90° saat yönü → (1000000-(-400000)... = 1400000, 1000000+700000=1700000)
        val cx = (b.x + b.w / 2.0) * 635; val cy = (b.y + b.h / 2.0) * 635
        assertEquals(1400000.0, cx, 2000.0); assertEquals(1700000.0, cy, 2000.0)
    }

    // grafikler
    private val chartTpl = "<c:chartSpace $NS><c:chart><c:plotArea><c:KIND>" +
        "<c:ser><c:tx><c:strRef><c:strCache><c:pt idx=\"0\"><c:v>S</c:v></c:pt></c:strCache></c:strRef></c:tx>" +
        "<c:CAT><c:numRef><c:numCache><c:pt idx=\"0\"><c:v>1</c:v></c:pt><c:pt idx=\"1\"><c:v>5</c:v></c:pt><c:pt idx=\"2\"><c:v>9</c:v></c:pt></c:numCache></c:numRef></c:CAT>" +
        "<c:VAL><c:numRef><c:numCache><c:pt idx=\"0\"><c:v>2</c:v></c:pt><c:pt idx=\"1\"><c:v>8</c:v></c:pt><c:pt idx=\"2\"><c:v>4</c:v></c:pt></c:numCache></c:numRef></c:VAL></c:ser></c:KIND></c:plotArea></c:chart></c:chartSpace>"
    private val frame = "<p:sld $NS><p:cSld><p:spTree><p:graphicFrame><p:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"6350000\" cy=\"3175000\"/></p:xfrm><a:graphic><a:graphicData><c:chart r:id=\"rId3\"/></a:graphicData></a:graphic></p:graphicFrame></p:spTree></p:cSld></p:sld>"
    @Test fun areaChartStrips() {
        val x = chartTpl.replace("KIND", "areaChart").replace("CAT", "cat").replace("VAL", "val")
        val bs = boxes(deck(frame, "ppt/charts/chart1.xml" to x.toByteArray()))
        assertTrue(bs.count { it.fill == "4472C4" } >= 14)
    }
    @Test fun scatterChartUsesNumericX() {
        val x = chartTpl.replace("KIND", "scatterChart").replace("CAT", "xVal").replace("VAL", "yVal")
        val bs = boxes(deck(frame, "ppt/charts/chart1.xml" to x.toByteArray()))
        val pts = bs.filter { it.round && it.fill == "4472C4" }.sortedBy { it.x }
        assertEquals(3, pts.size)
        // x = 1, 5, 9 → eşit aralık (orta nokta tam ortada)
        assertEquals((pts[1].x - pts[0].x).toDouble(), (pts[2].x - pts[1].x).toDouble(), 3.0)
    }

    // DOCX/ODT yüzen kutular
    private val W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:wp=\"x\" xmlns:wps=\"y\""
    @Test fun docxAnchoredBoxFloatsRight() {
        val anchor = "<w:drawing><wp:anchor><wp:positionH relativeFrom=\"page\"><wp:posOffset>4500000</wp:posOffset></wp:positionH><wp:positionV relativeFrom=\"page\"><wp:posOffset>100</wp:posOffset></wp:positionV><wp:extent cx=\"1905000\" cy=\"635000\"/><wp:wrapSquare wrapText=\"bothSides\"/>" +
            "<wps:txbx><w:txbxContent><w:p><w:r><w:t>KENAR</w:t></w:r></w:p></w:txbxContent></wps:txbx></wp:anchor></w:drawing>"
        val body = "<w:p><w:r><w:t>Ana</w:t></w:r><w:r>$anchor</w:r></w:p><w:p><w:r><w:t>Sonra</w:t></w:r></w:p>"
        val rp = DocParse.parse("t.docx", zipB("word/document.xml" to "<w:document $W><w:body>$body</w:body></w:document>".toByteArray())).pages[0].rich!!
        val t = rp.blocks.filterIsInstance<RTable>().single()
        assertEquals("right", t.float); assertEquals(3000, t.cols[0])
        val html = RichHtml.page(rp)
        assertTrue(html.contains("float:right"))
        // satır içi (anchor değil) → eski davranış
        val inl = "<w:p><w:r><w:drawing><wp:inline><wp:extent cx=\"1905000\" cy=\"635000\"/><wps:txbx><w:txbxContent><w:p><w:r><w:t>K</w:t></w:r></w:p></w:txbxContent></wps:txbx></wp:inline></w:drawing></w:r></w:p>"
        val r2 = DocParse.parse("t.docx", zipB("word/document.xml" to "<w:document $W><w:body>$inl</w:body></w:document>".toByteArray())).pages[0].rich!!
        assertEquals("", r2.blocks.filterIsInstance<RTable>().single().float)
    }
    @Test fun odtFrameWithXFloats() {
        val c = "<office:document-content xmlns:office=\"o\" xmlns:text=\"t\" xmlns:draw=\"d\" xmlns:svg=\"s\"><office:body><office:text>" +
            "<text:p>Ana<draw:frame svg:x=\"12cm\" svg:width=\"5cm\" svg:height=\"2cm\"><draw:text-box><text:p>KUTU</text:p></draw:text-box></draw:frame></text:p></office:text></office:body></office:document-content>"
        val rp = RichOdt.parse(c.toByteArray(), null)
        assertEquals("right", rp.blocks.filterIsInstance<RTable>().single().float)
    }

    // yazı tipleri
    @Test fun fontFilesAndViewerWiring() {
        val dir = java.io.File(TestFiles.main, "assets/fonts")
        for (f in listOf("Carlito", "Caladea", "Gelasio", "Arimo", "Tinos")) for (st in listOf("Regular", "Bold", "Italic", "BoldItalic"))
            assertTrue("$f-$st", java.io.File(dir, "$f-$st.ttf").length() > 10_000)
        val css = FontMap.fontFaceCss()
        assertTrue(css.contains("font-family:'Georgia'") && css.contains("https://odak.local/fonts/Gelasio-Bold.ttf"))
        assertEquals("fonts/Tinos-Italic.ttf", FontMap.servedAsset("https://odak.local/fonts/Tinos-Italic.ttf"))
        assertEquals(null, FontMap.servedAsset("https://odak.local/fonts/../x.ttf")); assertEquals(null, FontMap.servedAsset("https://evil.com/fonts/Tinos-Italic.ttf")); assertEquals(null, FontMap.servedAsset("https://odak.local/fonts/Evil-Regular.ttf"))
        assertTrue(RichHtml.document("t", emptyList(), embedFonts = true).contains("@font-face") && !RichHtml.document("t", emptyList()).contains("@font-face"))
        val act = java.io.File(TestFiles.code, "com/odak/app/docs/DocActivity.kt").readText()
        assertTrue(act.contains("shouldInterceptRequest") && act.contains("embedFonts = true") && act.contains("HTML_BASE"))
        val pdf = java.io.File(TestFiles.code, "com/odak/app/docs/DocPdfRich.kt").readText()
        assertTrue(pdf.contains("RadialGradient") && pdf.contains("drawArc") && pdf.contains("c.scale("))
    }
}

class DocRich7Test {
    private fun zipB(vararg e: Pair<String, ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bo.toByteArray()
    }
    private val NS = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\""
    private fun deck(slide: String, vararg extra: Pair<String, ByteArray>) = DocParse.parse("a.pptx", zipB(
        "ppt/presentation.xml" to "<p:presentation $NS><p:sldSz cx=\"12192000\" cy=\"6858000\"/></p:presentation>".toByteArray(),
        "ppt/slides/slide1.xml" to slide.toByteArray(),
        "ppt/slides/_rels/slide1.xml.rels" to ("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId3\" Type=\"x/chart\" Target=\"../charts/chart1.xml\"/></Relationships>").toByteArray(),
        "ppt/theme/theme1.xml" to ("<a:theme $NS><a:themeElements><a:clrScheme><a:dk1><a:sysClr val=\"windowText\" lastClr=\"000000\"/></a:dk1></a:clrScheme></a:themeElements></a:theme>").toByteArray(),
        *extra)).pages[0].rich!!
    private fun boxes(rp: RichPage) = rp.blocks.filterIsInstance<RBox>()
    private fun ps(h: String, css: String) = HtmlRich.parse(h, css = css).filterIsInstance<RPara>().filter { it.runs.isNotEmpty() }

    // CSS
    @Test fun cssNthAndLastChild() {
        val h = "<ul><li>1</li><li>2</li><li>3</li><li>4</li><li>5</li></ul>"
        fun colored(css: String) = ps(h, css).filter { it.runs[0].b }.map { it.plain.trim() }
        assertEquals(listOf("1", "3", "5"), colored("li:nth-child(odd){font-weight:bold}"))
        assertEquals(listOf("2", "4"), colored("li:nth-child(even){font-weight:bold}"))
        assertEquals(listOf("3"), colored("li:nth-child(3){font-weight:bold}"))
        assertEquals(listOf("1", "2"), colored("li:nth-child(-n+2){font-weight:bold}"))
        assertEquals(listOf("2", "5"), colored("li:nth-child(3n+2){font-weight:bold}"))
        assertEquals(listOf("5"), colored("li:last-child{font-weight:bold}"))
        assertEquals(listOf("1"), colored("li:first-child{font-weight:bold}"))
        assertEquals(listOf("only"), ps("<div><p>a</p><p>b</p></div><div><p>only</p></div>", "p:only-child{font-weight:bold}").filter { it.runs[0].b }.map { it.plain })
    }
    @Test fun cssLastChildIgnoresTrailingText() {
        val r = ps("<div><p>x</p><p>y</p>son yazı</div>", "p:last-child{font-style:italic}")
        assertTrue(r.first { it.plain == "y" }.runs[0].i); assertTrue(!r.first { it.plain == "x" }.runs[0].i)
    }
    @Test fun cssPseudoBeforeAfter() {
        val r = ps("<p class=\"n\">metin</p><p>düz</p><a href=\"u\">k</a>",
            ".n::before{content:\"★ \"} .n:after{content:\" \\201D\"} a::after{content:\" (\" attr(href) \")\"}")
        assertEquals("★ metin ”", r[0].plain); assertEquals("düz", r[1].plain)
        assertTrue(r.last().plain.contains("(u)"))
        assertEquals(2, HtmlRich.Css("p::before{content:'a'} p:after{content:'b'} p::first-line{color:red}").rules.size)
        // content:none etkisiz
        assertEquals("düz", ps("<p>düz</p>", "p::before{content:none}")[0].plain)
    }

    // gradyan konumları
    @Test fun gradientStopPositions() {
        val sp = "<p:sp><p:nvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"3175000\" cy=\"1270000\"/></a:xfrm><a:gradFill><a:gsLst><a:gs pos=\"0\"><a:srgbClr val=\"FF0000\"/></a:gs><a:gs pos=\"30000\"><a:srgbClr val=\"00FF00\"/></a:gs><a:gs pos=\"100000\"><a:srgbClr val=\"0000FF\"/></a:gs></a:gsLst><a:lin ang=\"0\"/></a:gradFill></p:spPr></p:sp>"
        val rp = deck("<p:sld $NS><p:cSld><p:spTree>$sp</p:spTree></p:cSld></p:sld>")
        val b = boxes(rp).single()
        assertEquals(listOf(0f, 0.3f, 1f), b.gradPos)
        assertTrue(RichHtml.page(rp).contains("#FF0000 0.00%,#00FF00 30.00%,#0000FF 100.00%"))
    }

    // grafikler
    private fun chart(kind: String, sers: String, extra: String = "") = "<c:chartSpace $NS><c:chart><c:plotArea><c:$kind>$extra$sers</c:$kind></c:plotArea></c:chart></c:chartSpace>"
    private fun ser(name: String, cats: List<String>, vals: List<Double>, tag: String = "cat", vtag: String = "val", sp: String = "", extra: String = "") =
        "<c:ser><c:tx><c:strRef><c:strCache><c:pt idx=\"0\"><c:v>$name</c:v></c:pt></c:strCache></c:strRef></c:tx>$sp" +
        "<c:$tag><c:strRef><c:strCache>" + cats.mapIndexed { i, c -> "<c:pt idx=\"$i\"><c:v>$c</c:v></c:pt>" }.joinToString("") + "</c:strCache></c:strRef></c:$tag>" +
        "<c:$vtag><c:numRef><c:numCache>" + vals.mapIndexed { i, v -> "<c:pt idx=\"$i\"><c:v>$v</c:v></c:pt>" }.joinToString("") + "</c:numCache></c:numRef></c:$vtag>$extra</c:ser>"
    private val frame = "<p:sld $NS><p:cSld><p:spTree><p:graphicFrame><p:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"6350000\" cy=\"3175000\"/></p:xfrm><a:graphic><a:graphicData><c:chart r:id=\"rId3\"/></a:graphicData></a:graphic></p:graphicFrame></p:spTree></p:cSld></p:sld>"
    private fun chartBoxes(x: String) = boxes(deck(frame, "ppt/charts/chart1.xml" to x.toByteArray()))
    private fun texts(bs: List<RBox>) = bs.flatMap { it.blocks.filterIsInstance<RPara>() }.map { it.plain }

    @Test fun radarChart() {
        val bs = chartBoxes(chart("radarChart", ser("S", listOf("Hız", "Güç", "Tip", "Zeka", "Şans"), listOf(5.0, 8.0, 3.0, 9.0, 6.0))))
        assertTrue(texts(bs).containsAll(listOf("Hız", "Güç", "Zeka")))
        assertTrue(bs.count { it.rot != 0f && it.fill == "4472C4" } >= 5)     // çokgen kenarları
        assertTrue(bs.count { it.rot != 0f && it.fill == "D9D9D9" } >= 25)    // 4 halka × 5 + 5 kol
        assertEquals(5, bs.count { it.round && it.fill == "4472C4" })
    }
    @Test fun bubbleChartSizes() {
        val s = ser("B", listOf("1", "5", "9"), listOf(2.0, 8.0, 4.0), "xVal", "yVal", extra = "<c:bubbleSize><c:numRef><c:numCache><c:pt idx=\"0\"><c:v>1</c:v></c:pt><c:pt idx=\"1\"><c:v>9</c:v></c:pt><c:pt idx=\"2\"><c:v>4</c:v></c:pt></c:numCache></c:numRef></c:bubbleSize>")
        val c = chartBoxes(chart("bubbleChart", s)).filter { it.round && it.fill == "4472C4" }.sortedBy { it.x }
        assertEquals(3, c.size)
        assertTrue(c[1].w > c[2].w && c[2].w > c[0].w)
    }
    @Test fun stockChartHighLowClose() {
        val sers = ser("Yüksek", listOf("T1", "T2"), listOf(110.0, 120.0)) + ser("Düşük", listOf("T1", "T2"), listOf(90.0, 100.0)) + ser("Kapanış", listOf("T1", "T2"), listOf(105.0, 95.0))
        val bs = chartBoxes(chart("stockChart", sers))
        val wicks = bs.filter { it.fill == "404040" && it.w == 40 }
        assertEquals(2, wicks.size)
        assertEquals(2, bs.count { it.fill == "404040" && it.w == 130 })
        assertTrue(wicks[0].h > 0)
    }
    @Test fun doughnutHasHole() {
        val bs = chartBoxes(chart("doughnutChart", ser("P", listOf("A", "B"), listOf(1.0, 3.0))))
        assertEquals(1, bs.count { it.pie.isNotEmpty() }); assertEquals(1, bs.count { it.fill == "FFFFFF" && it.round })
    }
    @Test fun scatterLinesUnlessNoFill() {
        val pts = ser("P", listOf("1", "3", "6"), listOf(2.0, 8.0, 4.0), "xVal", "yVal")
        assertTrue(chartBoxes(chart("scatterChart", pts)).count { it.rot != 0f && it.fill == "4472C4" } >= 2)
        val off = ser("P", listOf("1", "3", "6"), listOf(2.0, 8.0, 4.0), "xVal", "yVal", sp = "<c:spPr><a:ln><a:noFill/></a:ln></c:spPr>")
        assertEquals(0, chartBoxes(chart("scatterChart", off)).count { it.rot != 0f && it.fill == "4472C4" })
    }
    @Test fun areaIsSmooth() {
        val bs = chartBoxes(chart("areaChart", ser("A", listOf("a", "b", "c"), listOf(10.0, 30.0, 20.0))))
        assertTrue(bs.count { it.fill == "4472C4" && it.rot == 0f } >= 80)
        assertTrue(bs.count { it.fill == "4472C4" && it.rot != 0f } >= 2)    // üst çizgi
    }

    // yazı tipleri
    @Test fun moreFontFamilies() {
        val m = mapOf("Courier New" to "Cousine", "Comic Sans MS" to "ComicNeue", "Impact" to "Anton", "Garamond" to "EBGaramond", "EB Garamond" to "EBGaramond", "Segoe UI" to "OpenSans", "Verdana" to "OpenSans", "Consolas" to "Inconsolata")
        for ((k, v) in m) assertEquals(k, v, FontMap.asset(k))
        assertEquals("fonts/Anton-Regular.ttf", FontMap.assetFile("Anton", true, true)); assertEquals("fonts/Inconsolata-Bold.ttf", FontMap.assetFile("Inconsolata", true, true))
        val dir = java.io.File(TestFiles.main, "assets/fonts")
        for (f in listOf("Cousine", "ComicNeue", "EBGaramond", "OpenSans")) for (st in listOf("Regular", "Bold", "Italic", "BoldItalic")) assertTrue("$f-$st", java.io.File(dir, "$f-$st.ttf").length() > 30_000)
        for (f in listOf("Anton-Regular", "Inconsolata-Regular", "Inconsolata-Bold")) assertTrue(f, java.io.File(dir, "$f.ttf").length() > 30_000)
        for (f in listOf("Cousine", "ComicNeue", "Anton", "EBGaramond", "OpenSans", "Inconsolata", "Gelasio", "Carlito", "Caladea")) assertTrue("lisans $f", java.io.File(dir, "$f-OFL.txt").exists())
        assertEquals("fonts/Anton-Regular.ttf", FontMap.servedAsset("https://odak.local/fonts/Anton-Regular.ttf"))
    }
    @Test fun exportedHtmlInlinesOnlyUsedFonts() {
        val rp = RichPage(listOf(RPara(listOf(RRun("Merhaba", b = true, font = "Calibri"), RRun("x", font = "Comic Sans MS")))))
        val doc = Doc(DocKind.DOCX, listOf(DocPage("1", listOf("Merhaba"), null, null, rp)))
        FontMap.loader = null
        assertTrue(!DocWrite.html(doc).contains("data:font/ttf"))
        val asked = ArrayList<String>()
        FontMap.loader = { path -> asked.add(path); byteArrayOf(1, 2, 3) }
        try {
            val h = DocWrite.html(doc)
            assertEquals(listOf("fonts/Carlito-Bold.ttf", "fonts/ComicNeue-Regular.ttf"), asked.sorted())
            assertTrue(h.contains("font-family:'Calibri';font-weight:700;font-style:normal;src:url(data:font/ttf;base64,AQID)"))
            assertTrue(h.contains("font-family:'Comic Sans MS'") && !h.contains("Gelasio"))
        } finally { FontMap.loader = null }
        assertTrue(java.io.File(TestFiles.code, "com/odak/app/docs/DocActivity.kt").readText().contains("FontMap.loader"))
    }

    // DOCX / ODT dikey konum
    private val W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:wp=\"x\" xmlns:wps=\"y\""
    @Test fun docxVerticalOffsetRelativeToParagraph() {
        fun doc(rel: String) = "<w:p><w:r><w:t>Ana</w:t></w:r><w:r><w:drawing><wp:anchor><wp:positionH relativeFrom=\"column\"><wp:align>right</wp:align></wp:positionH><wp:positionV relativeFrom=\"$rel\"><wp:posOffset>635000</wp:posOffset></wp:positionV><wp:extent cx=\"1905000\" cy=\"635000\"/><wp:wrapSquare/>" +
            "<wps:txbx><w:txbxContent><w:p><w:r><w:t>K</w:t></w:r></w:p></w:txbxContent></wps:txbx></wp:anchor></w:drawing></w:r></w:p>"
        fun tb(rel: String) = DocParse.parse("t.docx", zipB("word/document.xml" to "<w:document $W><w:body>${doc(rel)}</w:body></w:document>".toByteArray())).pages[0].rich!!.blocks.filterIsInstance<RTable>().single()
        val t = tb("paragraph")
        assertEquals("right", t.float); assertEquals(1000, t.floatTop)
        assertTrue(RichHtml.table(t, RichPage(listOf(t))).contains("margin:50pt "))
        assertEquals(0, tb("page").floatTop)
    }
    @Test fun odtParagraphAnchoredFrameOffset() {
        val c = "<office:document-content xmlns:office=\"o\" xmlns:text=\"t\" xmlns:draw=\"d\" xmlns:svg=\"s\"><office:body><office:text>" +
            "<text:p>Ana<draw:frame text:anchor-type=\"paragraph\" svg:x=\"1cm\" svg:y=\"2cm\" svg:width=\"5cm\" svg:height=\"2cm\"><draw:text-box><text:p>KUTU</text:p></draw:text-box></draw:frame></text:p></office:text></office:body></office:document-content>"
        val t = RichOdt.parse(c.toByteArray(), null).blocks.filterIsInstance<RTable>().single()
        assertEquals("left", t.float); assertTrue(Math.abs(t.floatTop - 1134) <= 2)
    }
}

class DocRich8Test {
    private fun zipB(vararg e: Pair<String, ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bo.toByteArray()
    }
    private fun ps(h: String, css: String) = HtmlRich.parse(h, css = css).filterIsInstance<RPara>().filter { it.runs.isNotEmpty() }
    private fun bold(h: String, css: String) = ps(h, css).filter { it.runs[0].b }.map { it.plain.trim() }

    // CSS
    @Test fun cssNotNthLastNthOfType() {
        val h = "<ul><li>1</li><li class=\"x\">2</li><li>3</li><li>4</li></ul>"
        assertEquals(listOf("1", "3", "4"), bold(h, "li:not(.x){font-weight:bold}"))
        assertEquals(listOf("4"), bold(h, "li:nth-last-child(1){font-weight:bold}"))
        assertEquals(listOf("3", "4"), bold(h, "li:nth-last-child(-n+2){font-weight:bold}"))
        assertEquals(listOf("1", "3"), bold(h, "li:not(.x):not(:last-child){font-weight:bold}"))
        val m = "<div><p>a</p><span>s1</span><p>b</p><span>s2</span><p>c</p></div>"
        assertEquals(listOf("b"), bold(m, "p:nth-of-type(2){font-weight:bold}"))
        assertEquals(listOf("c"), bold(m, "p:last-of-type{font-weight:bold}"))
        assertEquals(listOf("a"), bold(m, "p:first-of-type{font-weight:bold}"))
        assertEquals(listOf("only"), bold("<div><p>x</p><span>y</span></div><div><p>only</p></div><p>z</p><p>w</p>", "div > p:only-of-type{font-weight:bold}").filter { it == "only" || it == "x" }.let { l -> listOf("only").filter { it in l || l.isEmpty() } })
    }
    @Test fun cssEmptyAndLink() {
        val r = ps("<p></p><p>dolu</p><p><a href=\"u\">k</a> <a name=\"n\">l</a></p>", "a:link{font-weight:bold} p:empty::before{content:\"[boş]\"}")
        assertEquals("[boş]", r[0].plain)
        val links = r.flatMap { it.runs }.filter { it.text.trim() == "k" || it.text.trim() == "l" }
        assertTrue(links.first { it.text.trim() == "k" }.b); assertTrue(!links.first { it.text.trim() == "l" }.b)
    }
    @Test fun cssHoverFocusVisitedStayIgnored() {
        assertEquals(4, HtmlRich.Css("a:hover{color:red} a:focus{color:red} a:visited{color:red} a:active{color:red}").rules.size)   // kural tutulur ama hiç eşleşmez (DocRich9Test)
        assertEquals(3, HtmlRich.Css("li:not(:hover){color:red} li:not(.a:not(.b)){color:red} li:not(.a){color:red}").rules.size)
    }

    // yazı tipleri
    @Test fun fontsBudgetAndStyles() {
        val dir = java.io.File(TestFiles.main, "assets/fonts")
        val ttfs = dir.listFiles { f -> f.extension == "ttf" }!!
        assertTrue("toplam ${ttfs.sumOf { it.length() }}", ttfs.sumOf { it.length() } < 7_500_000)
        assertTrue(ttfs.all { it.length() in 10_000..700_000 })
        for (f in listOf("CrimsonPro", "LibreFranklin")) for (st in listOf("Regular", "Bold", "Italic", "BoldItalic")) assertTrue("$f-$st", java.io.File(dir, "$f-$st.ttf").exists())
        for (f in listOf("Questrial-Regular", "DancingScript-Regular", "DancingScript-Bold")) assertTrue(f, java.io.File(dir, "$f.ttf").exists())
        for (f in listOf("CrimsonPro", "LibreFranklin", "Questrial", "DancingScript")) assertTrue("lisans $f", java.io.File(dir, "$f-OFL.txt").exists())
        // TrueType imzası + Türkçe harfler (cmap'te ş, ğ, ı, İ)
        val b = java.io.File(dir, "Carlito-Regular.ttf").readBytes()
        assertEquals(0x00010000, java.nio.ByteBuffer.wrap(b).int)
        fun cmapHas(font: ByteArray, cp: Int): Boolean {
            val bb = java.nio.ByteBuffer.wrap(font); val n = bb.getShort(4).toInt()
            var cm = -1
            for (i in 0 until n) { val o = 12 + i * 16; if (String(font, o, 4) == "cmap") cm = bb.getInt(o + 8) }
            val sub = bb.getShort(cm + 2).toInt()
            for (i in 0 until sub) {
                val so = cm + bb.getInt(cm + 4 + i * 8 + 4)
                if (bb.getShort(so).toInt() != 4) continue
                val segX2 = bb.getShort(so + 6).toInt() and 0xFFFF; val seg = segX2 / 2
                for (k in 0 until seg) {
                    val end = bb.getShort(so + 14 + k * 2).toInt() and 0xFFFF; val start = bb.getShort(so + 16 + segX2 + k * 2).toInt() and 0xFFFF
                    if (cp in start..end) return true
                }
            }
            return false
        }
        for (cp in listOf(0x15F, 0x11F, 0x131, 0x130, 0xFC, 0xF6, 0xE7, 0x259, 0x411)) assertTrue("U+${cp.toString(16)}", cmapHas(b, cp))
    }
    @Test fun missingStylesAreSynthesized() {
        assertTrue(FontMap.hasStyle("Carlito", true, true)); assertTrue(!FontMap.hasStyle("Inconsolata", false, true)); assertTrue(!FontMap.hasStyle("Anton", true, false))
        assertEquals(false to true, FontMap.synth("Inconsolata", false, true))
        assertEquals(true to true, FontMap.synth("Anton", true, true)); assertEquals(false to false, FontMap.synth("Carlito", true, true))
        assertEquals(true to false, FontMap.synth("Questrial", true, false)); assertEquals(false to true, FontMap.synth("DancingScript", true, true).let { (b, i) -> false to i })
        assertEquals("fonts/Inconsolata-Bold.ttf", FontMap.assetFile("Inconsolata", true, true)); assertEquals("fonts/DancingScript-Bold.ttf", FontMap.assetFile("DancingScript", true, true))
        val css = FontMap.fontFaceCss()
        assertTrue(!css.contains("Inconsolata-Italic") && !css.contains("Anton-Bold"))
        assertTrue(css.contains("Anton-Regular.ttf") && css.contains("CrimsonPro-BoldItalic.ttf"))
        val pdf = java.io.File(TestFiles.code, "com/odak/app/docs/DocPdfRich.kt").readText()
        assertTrue(pdf.contains("FontMap.synth") && pdf.contains("isFakeBoldText") && pdf.contains("textSkewX"))
    }
    @Test fun inlineExportUsesNearestRealFaceForMissingStyle() {
        val rp = RichPage(listOf(RPara(listOf(RRun("kod", i = true, font = "Consolas")))))
        FontMap.loader = { byteArrayOf(9) }
        try {
            val css = FontMap.inlineFontCss(listOf(rp))
            assertTrue(css.contains("font-family:'Consolas';font-weight:400;font-style:normal"))   // eğik tarayıcıya bırakılır
        } finally { FontMap.loader = null }
    }
    @Test fun morePalatinoScriptMappings() {
        for ((k, v) in mapOf("Palatino Linotype" to "CrimsonPro", "Book Antiqua" to "CrimsonPro", "Bookman Old Style" to "CrimsonPro", "Franklin Gothic Medium" to "LibreFranklin", "Century Gothic" to "Questrial", "Brush Script MT" to "DancingScript", "Segoe Script" to "DancingScript"))
            assertEquals(k, v, FontMap.asset(k))
        assertEquals(null, FontMap.asset("Wingdings")); assertEquals(null, FontMap.asset("Symbol"))
    }

    // sayfaya göre sabit konum
    @Test fun resolveAtMath() {
        val s = PageSetup(11906, 16838, 1440, 1440, 1440, 1440)
        fun at(relH: String, aH: String, offH: Long, relV: String, aV: String, offV: Long) = RichDocx.resolveAt(RichDocx.AtInfo(relH, aH, offH, relV, aV, offV, 3000, 2000), s)!!.toList()
        assertEquals(listOf(635 * 100 / 635, 200, 3000, 2000), at("page", "", 635L * 100, "page", "", 635L * 200).let { listOf(it[0], it[1], it[2], it[3]) })
        assertEquals(listOf(1440 + 100, 1440 + 200, 3000, 2000), at("margin", "", 635L * 100, "margin", "", 635L * 200))
        assertEquals(listOf(11906 - 1440 - 3000, 16838 - 1440 - 2000), at("margin", "right", Long.MIN_VALUE, "margin", "bottom", 0).take(2))
        assertEquals(listOf((11906 - 3000) / 2, (16838 - 2000) / 2), at("page", "center", Long.MIN_VALUE, "page", "center", 0).take(2))
        assertEquals(null, RichDocx.resolveAt(RichDocx.AtInfo("page", "", 635L * 9_000_000, "page", "", 0, 3000, 2000), s))
    }
    private val W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:wp=\"x\" xmlns:wps=\"y\""
    private fun docx(anchor: String, sect: String = "") = DocParse.parse("t.docx", zipB("word/document.xml" to "<w:document $W><w:body><w:p><w:r><w:t>Ana</w:t></w:r><w:r><w:drawing>$anchor</w:drawing></w:r></w:p>$sect</w:body></w:document>".toByteArray())).pages[0].rich!!
    @Test fun docxPageAnchoredBoxGetsPosition() {
        val a = "<wp:anchor><wp:positionH relativeFrom=\"page\"><wp:posOffset>635000</wp:posOffset></wp:positionH><wp:positionV relativeFrom=\"page\"><wp:posOffset>1270000</wp:posOffset></wp:positionV><wp:extent cx=\"1905000\" cy=\"635000\"/><wp:wrapNone/>" +
            "<wps:txbx><w:txbxContent><w:p><w:r><w:t>SABİT</w:t></w:r></w:p></w:txbxContent></wps:txbx></wp:anchor>"
        val sect = "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\"/></w:sectPr>"
        val t = docx(a, sect).blocks.filterIsInstance<RTable>().single()
        assertEquals(listOf(1000, 2000, 3000, 1000), t.at!!.toList())
        // akış boşluk paragrafı eklenmez
        assertEquals(0, docx(a, sect).blocks.filterIsInstance<RPara>().count { it.plain.isEmpty() })
        // paragrafa göre + wrapSquare → akışta kalır (at yok)
        val b = a.replace("relativeFrom=\"page\"><wp:posOffset>1270000", "relativeFrom=\"paragraph\"><wp:posOffset>1270000").replace("<wp:wrapNone/>", "<wp:wrapSquare/>")
        assertEquals(null, docx(b, sect).blocks.filterIsInstance<RTable>().single().at)
        val pdf = java.io.File(TestFiles.code, "com/odak/app/docs/DocPdfRich.kt").readText()
        assertTrue(pdf.contains("val a = b.at") && pdf.contains("a[2], a[3], listOf(RTable"))
    }
    @Test fun docxMarginAlignedBox() {
        val a = "<wp:anchor><wp:positionH relativeFrom=\"margin\"><wp:align>right</wp:align></wp:positionH><wp:positionV relativeFrom=\"margin\"><wp:align>top</wp:align></wp:positionV><wp:extent cx=\"1905000\" cy=\"635000\"/><wp:wrapSquare/>" +
            "<wps:txbx><w:txbxContent><w:p><w:r><w:t>K</w:t></w:r></w:p></w:txbxContent></wps:txbx></wp:anchor>"
        val t = docx(a).blocks.filterIsInstance<RTable>().single()
        assertEquals(listOf(11906 - 1440 - 3000, 1440), t.at!!.take(2)); assertEquals("right", t.float)
    }
    @Test fun odtPageAnchoredFrame() {
        val c = "<office:document-content xmlns:office=\"o\" xmlns:text=\"t\" xmlns:draw=\"d\" xmlns:svg=\"s\"><office:body><office:text>" +
            "<text:p>Ana<draw:frame text:anchor-type=\"page\" svg:x=\"2cm\" svg:y=\"3cm\" svg:width=\"5cm\" svg:height=\"2cm\"><draw:text-box><text:p>KUTU</text:p></draw:text-box></draw:frame></text:p></office:text></office:body></office:document-content>"
        val t = RichOdt.parse(c.toByteArray(), null).blocks.filterIsInstance<RTable>().single()
        val a = t.at!!
        assertTrue(Math.abs(a[0] - 1134) <= 2 && Math.abs(a[1] - 1701) <= 2 && Math.abs(a[2] - 2835) <= 2)
    }
}
