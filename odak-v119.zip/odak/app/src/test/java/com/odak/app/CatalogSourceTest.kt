package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Engellenebilir uygulama kataloğunun bütünlüğü. */
class CatalogSourceTest {
    private val apps = TestFiles.catalog()
    private val pkgRe = Regex("""^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$""")

    @Test fun catalogHasAtLeast190Apps() = assertTrue("Katalog: ${apps.size}", apps.size >= 290)

    @Test fun catalogLinesAllParsed() {
        val text = java.io.File(TestFiles.code, "com/odak/app/block/BlockData.kt").readText()
        val body = text.substring(text.indexOf("private val base = listOf("), text.indexOf("/** Kullanıcının eklediği"))
        assertEquals("BlockApp satırı sayısı ile çözümlenen sayı aynı olmalı", Regex("""BlockApp\(""").findAll(body).count(), apps.size)
    }

    @Test fun appIdsAreUnique() {
        val dup = apps.groupBy { it.id }.filter { it.value.size > 1 }.keys
        assertTrue("Tekrarlı uygulama id: $dup", dup.isEmpty())
    }

    @Test fun packagesAreUniqueAndValid() {
        val all = apps.flatMap { it.packages }
        val dup = all.groupBy { it }.filter { it.value.size > 1 }.keys
        assertTrue("Tekrarlı paket: $dup", dup.isEmpty())
        val bad = all.filter { !pkgRe.matches(it) }
        assertTrue("Geçersiz paket adı: $bad", bad.isEmpty())
    }

    @Test fun idsDoNotCollideWithCustomPrefix() = assertTrue(apps.none { it.id.startsWith("c:") })

    @Test fun featureIdsUniquePerApp() {
        val bad = apps.filter { it.features.size != it.features.toSet().size }.map { it.id }
        assertTrue("Tekrarlı özellik id: $bad", bad.isEmpty())
    }

    @Test fun everyAppHasNameAndPackage() {
        assertTrue(apps.all { it.name.isNotBlank() && it.packages.isNotEmpty() })
    }

    @Test fun majorAppsHaveSeveralFeatures() {
        val need = mapOf("youtube" to 3, "instagram" to 5, "tiktok" to 4, "facebook" to 5)
        for ((id, n) in need) {
            val f = apps.first { it.id == id }.features.size
            assertTrue("$id özellik sayısı $f < $n", f >= n)
        }
    }
}
