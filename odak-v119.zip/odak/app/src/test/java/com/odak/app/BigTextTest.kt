package com.odak.app

import com.odak.app.docs.BigText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.RandomAccessFile
import kotlin.random.Random

/** v0.56.3: çok büyük düz metin — pencere ve arama. */
class BigTextTest {
    private fun tmp(bytes: ByteArray): File { val f = File.createTempFile("tst_bt", ".txt"); f.deleteOnExit(); f.writeBytes(bytes); return f }
    private inline fun <T> ch(f: File, b: (java.nio.channels.FileChannel) -> T): T = RandomAccessFile(f, "r").use { b(it.channel) }
    private fun allWindows(f: File, w: Int): List<String> = ch(f) { c ->
        val size = f.length(); val out = ArrayList<String>(); var pos = 0L
        val enc = BigText.detect(c, size)
        while (true) { val win = BigText.window(c, size, pos, true, w, enc); out.addAll(win.lines); if (win.eof || win.end <= pos) break; pos = win.end }
        out
    }
    private val tr = "çğıöşüÇĞİÖŞÜ"

    @Test fun smallFileOneWindow() { val f = tmp("a\nb\nc\n".toByteArray()); ch(f) { c -> val w = BigText.window(c, f.length(), 0, true); assertEquals(listOf("a", "b", "c"), w.lines); assertTrue(w.eof); assertEquals(0L, w.start); assertEquals(6L, w.end) } }
    @Test fun noTrailingNewline() { val f = tmp("a\nb".toByteArray()); assertEquals(listOf("a", "b"), allWindows(f, 100)) }
    @Test fun emptyFile() { val f = tmp(ByteArray(0)); ch(f) { c -> val w = BigText.window(c, 0, 0, true); assertTrue(w.eof); assertTrue(w.lines.all { it.isEmpty() }) } }
    @Test fun crlfNormalised() { val f = tmp("a\r\nb\r\n".toByteArray()); assertEquals(listOf("a", "b"), allWindows(f, 100)) }
    @Test fun bomStripped() { val f = tmp(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + "x\n".toByteArray()); assertEquals(listOf("x"), allWindows(f, 100)) }
    @Test fun windowsCoverWholeFileExactly() {
        val lines = List(500) { "satır $it $tr ${"x".repeat(it % 17)}" }
        val f = tmp((lines.joinToString("\n") + "\n").toByteArray())
        for (w in listOf(64, 100, 333, 1000, 4096)) assertEquals("w=$w", lines, allWindows(f, w))
    }
    @Test fun multibyteNeverSplit() {
        val lines = List(300) { tr.repeat(1 + it % 5) }
        val f = tmp((lines.joinToString("\n") + "\n").toByteArray())
        for (w in listOf(7, 13, 50, 101)) assertEquals("w=$w", lines.joinToString(""), allWindows(f, w).joinToString(""))
        for (w in listOf(130, 400)) assertEquals("w=$w", lines, allWindows(f, w))
    }
    @Test fun longLineWithoutNewlineStillAdvances() {
        val f = tmp(("ö".repeat(5000) + "\nson\n").toByteArray())
        val r = allWindows(f, 300).joinToString("")
        assertEquals("ö".repeat(5000) + "son", r)
    }
    @Test fun randomJumpStartsOnLineBoundary() {
        val lines = List(400) { "kayıt-$it" }
        val f = tmp((lines.joinToString("\n") + "\n").toByteArray())
        val r = Random(4)
        ch(f) { c -> repeat(100) { val p = r.nextLong(f.length()); val w = BigText.window(c, f.length(), p, false, 200); if (p > 0 && w.lines.isNotEmpty()) assertTrue(w.lines[0], w.lines[0].startsWith("kayıt-")) } }
    }
    @Test fun jumpPastEndGivesEof() { val f = tmp("a\nb\n".toByteArray()); ch(f) { c -> val w = BigText.window(c, f.length(), 999, false); assertTrue(w.eof) } }
    @Test fun prevStartClamps() { assertEquals(0L, BigText.prevStart(10)); assertEquals(100L, BigText.prevStart(100 + BigText.WINDOW.toLong())) }
    @Test fun percentAndPos() { assertEquals(0, BigText.percent(0, 100)); assertEquals(50, BigText.percent(50, 100)); assertEquals(100, BigText.percent(500, 100)); assertEquals(0, BigText.percent(5, 0)); assertEquals(0L, BigText.posOf(0f, 100)); assertEquals(99L, BigText.posOf(1f, 100)); assertEquals(50L, BigText.posOf(0.5f, 100)); assertEquals(0L, BigText.posOf(-3f, 100)); assertEquals(0L, BigText.posOf(0.5f, 0)) }

    // ---- arama
    @Test fun findBasic() { val f = tmp("abc\ndef Merhaba\nxyz\n".toByteArray()); ch(f) { c -> assertEquals(8L, BigText.find(c, f.length(), 0, "merhaba")) } }
    @Test fun findNotFound() { val f = tmp("abc\n".toByteArray()); ch(f) { c -> assertEquals(-1L, BigText.find(c, f.length(), 0, "zzz")); assertEquals(-1L, BigText.find(c, f.length(), 0, "")) } }
    @Test fun findFromOffsetSkipsEarlier() { val f = tmp("aa\naa\naa\n".toByteArray()); ch(f) { c -> assertEquals(0L, BigText.find(c, f.length(), 0, "aa")); assertEquals(3L, BigText.find(c, f.length(), 1, "aa")); assertEquals(6L, BigText.find(c, f.length(), 4, "aa")) } }
    @Test fun findReportsByteOffsetForMultibyte() { val f = tmp("çğ iğne\n".toByteArray()); ch(f) { c -> assertEquals("çğ ".toByteArray().size.toLong(), BigText.find(c, f.length(), 0, "iğne")) } }
    @Test fun findAcrossChunkBoundary() {
        val chunk = 4 shl 20
        val bytes = ByteArray(chunk * 2 + 100) { 'a'.code.toByte() }
        val needle = "NEEDLE".toByteArray()
        for (shift in listOf(-3, 0, 2)) {
            val at = chunk + shift
            val b = bytes.copyOf(); System.arraycopy(needle, 0, b, at, needle.size)
            val f = tmp(b); ch(f) { c -> assertEquals("shift=$shift", at.toLong(), BigText.find(c, f.length(), 0, "needle")) }
        }
    }
    @Test fun findCancel() { val f = tmp("abc".toByteArray()); ch(f) { c -> assertEquals(-2L, BigText.find(c, f.length(), 0, "zzz") { true }) } }
    @Test fun findThenWindowShowsMatch() {
        val lines = List(2000) { "satır-$it" }
        val f = tmp((lines.joinToString("\n") + "\n").toByteArray())
        ch(f) { c -> val at = BigText.find(c, f.length(), 0, "satır-1777"); val w = BigText.window(c, f.length(), maxOf(0L, at - 200), false, 1000); assertTrue(w.lines.contains("satır-1777")) }
    }
    @Test fun twoGigabyteOffsetsDoNotOverflow() {
        val f = File.createTempFile("tst_sparse", ".txt"); f.deleteOnExit()
        RandomAccessFile(f, "rw").use { r -> r.setLength(3L * 1024 * 1024 * 1024 + 10); r.seek(3L * 1024 * 1024 * 1024); r.write("SON satir\n".toByteArray()) }
        ch(f) { c ->
            val size = f.length()
            val w = BigText.window(c, size, 3L * 1024 * 1024 * 1024, false, 1000)
            assertTrue(w.start >= 3L * 1024 * 1024 * 1024 - 0); assertTrue(w.eof || w.end > w.start)
            assertEquals(3L * 1024 * 1024 * 1024, BigText.find(c, size, 3L * 1024 * 1024 * 1024 - 100, "SON satir"))
            assertEquals(99, BigText.percent(size - 1, size).coerceAtLeast(99))
        }
    }
    @Test fun generatedRoundTrip() {
        val r = Random(21)
        val alpha = ("abc defg hij\n" + tr).toList()
        repeat(60) { n ->
            val text = String(CharArray(r.nextInt(0, 3000)) { alpha[r.nextInt(alpha.size)] })
            val f = tmp(text.toByteArray())
            val w = listOf(9, 31, 128, 700)[n % 4]
            val expect = text.replace("\r\n", "\n").split('\n').let { if (it.isNotEmpty() && it.last().isEmpty()) it.dropLast(1) else it }
            assertEquals("n=$n w=$w", expect.joinToString(""), allWindows(f, w).joinToString(""))
        }
    }

    // ---- kodlama doğrulama
    private fun det(b: ByteArray): BigText.Enc { val f = tmp(b); return ch(f) { c -> BigText.detect(c, f.length()) } }
    @Test fun detectUtf8Plain() { assertEquals("UTF-8", det("merhaba dünya çğış\n".toByteArray()).label) }
    @Test fun detectUtf8Bom() { val e = det(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + "x".toByteArray()); assertEquals("UTF-8", e.label); assertEquals(3, e.bom) }
    @Test fun detectUtf16Boms() { assertEquals("UTF-16LE", det(byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + "ab".toByteArray(Charsets.UTF_16LE)).label); assertEquals("UTF-16BE", det(byteArrayOf(0xFE.toByte(), 0xFF.toByte()) + "ab".toByteArray(Charsets.UTF_16BE)).label) }
    @Test fun detectUtf16WithoutBom() { val t = "Merhaba dünya, bu bir deneme satırıdır.\n".repeat(20); assertEquals("UTF-16LE", det(t.toByteArray(Charsets.UTF_16LE)).label); assertEquals("UTF-16BE", det(t.toByteArray(Charsets.UTF_16BE)).label) }
    @Test fun detectTurkishLegacy() { val e = det("İstanbul çğış ÖÜŞ\n".repeat(30).toByteArray(charset("windows-1254"))); assertEquals("windows-1254", e.label) }
    @Test fun invalidUtf8LateInFileIsCaught() {
        val head = ByteArray(10 * 1024 * 1024) { 'a'.code.toByte() }
        val tail = "çğ".toByteArray(charset("windows-1254"))
        System.arraycopy(tail, 0, head, head.size - 100, tail.size)
        assertEquals("windows-1254", det(head).label)
    }
    @Test fun invalidInMiddleCaught() { val b = ByteArray(9 * 1024 * 1024) { 'a'.code.toByte() }; b[b.size / 2] = 0xFC.toByte(); b[b.size / 2 + 1] = 0x41; assertEquals("windows-1254", det(b).label) }
    @Test fun asciiOnlyIsUtf8() { assertEquals("UTF-8", det("only ascii\n".repeat(100).toByteArray()).label) }
    @Test fun emptyFileDetect() { assertEquals("UTF-8", det(ByteArray(0)).label) }
    @Test fun utf8OkRules() { assertTrue(BigText.utf8Ok("çğ".toByteArray(), false)); assertTrue(!BigText.utf8Ok(byteArrayOf(0xFC.toByte(), 0x41), false)); assertTrue(BigText.utf8Ok("ç".toByteArray().copyOf(1), false)); assertTrue(BigText.utf8Ok("ç".toByteArray().copyOfRange(1, 2), true)) }
    @Test fun windowsReadLegacyTurkishCorrectly() {
        val lines = List(200) { "Satır $it: ÇĞİÖŞÜ çğıöşü" }
        val f = tmp((lines.joinToString("\n") + "\n").toByteArray(charset("windows-1254")))
        for (w in listOf(100, 333, 4096)) assertEquals("w=$w", lines, allWindows(f, w))
    }
    @Test fun utf16WindowsAlignedAndComplete() {
        val lines = List(300) { "Satır $it çğışöü 😀 son" }
        for (cs in listOf(Charsets.UTF_16LE, Charsets.UTF_16BE)) for (bom in listOf(true, false)) {
            val body = (lines.joinToString("\n") + "\n").toByteArray(cs)
            val b = if (bom) (if (cs == Charsets.UTF_16LE) byteArrayOf(0xFF.toByte(), 0xFE.toByte()) else byteArrayOf(0xFE.toByte(), 0xFF.toByte())) + body else body
            val f = tmp(b)
            for (w in listOf(100, 333, 4096)) assertEquals("$cs bom=$bom w=$w", lines, allWindows(f, w))
        }
    }
    @Test fun utf16FindReturnsAlignedOffset() {
        val t = "ab\ncd Merhaba\nef\n"; val b = byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + t.toByteArray(Charsets.UTF_16LE)
        val f = tmp(b); ch(f) { c -> val e = BigText.detect(c, f.length()); val at = BigText.find(c, f.length(), 0, "merhaba", e); assertEquals(2L + 2L * "ab\ncd ".length, at); assertEquals(0L, at % 2) }
    }
    @Test fun findInLegacyUsesByteOffsets() {
        val f = tmp("çğ şiir\n".toByteArray(charset("windows-1254")))
        ch(f) { c -> val e = BigText.detect(c, f.length()); assertEquals("windows-1254", e.label); assertEquals(3L, BigText.find(c, f.length(), 0, "şiir", e)) }
    }
    @Test fun mixedFileWindowFallsBackPerWindow() {
        // Baş kısım geçerli UTF-8, bir pencerede tek bozuk bayt: o pencere Windows-1254 çözülür, � çıkmaz
        val a = "ilk satır çğ\n".repeat(50).toByteArray()
        val bad = byteArrayOf('x'.code.toByte(), 0xFC.toByte(), 'y'.code.toByte(), '\n'.code.toByte())
        val f = tmp(a + bad)
        ch(f) { c -> val w = BigText.window(c, f.length(), 0, true, 100000, BigText.UTF8); assertTrue(w.lines.joinToString().contains("xüy")); assertTrue(!w.lines.joinToString().contains('\uFFFD')) }
    }
}
