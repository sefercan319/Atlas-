package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** assets/block_rules.json ile katalog (BlockData.kt) arasındaki tutarlılık. */
class RulesFileTest {
    private val rules = TestFiles.parseRules(File(TestFiles.main, "assets/block_rules.json"))
    private val catalog = TestFiles.catalog()
    private val featureKeys = catalog.flatMap { a -> a.features.map { "${a.id}/$it" } }.toSet()
    private val ruleKeys = rules.keys.filter { !it.startsWith("_") }

    /** Çok genel parçalar, ilgisiz ekranları da engellerdi. */
    private val tooGeneric = setOf(
        "chat", "chat_", "feed", "list", "search", "search_", "search_bar", "main", "home", "tab", "root",
        "container", "main_fragment_container", "view", "layout", "item", "status_tab", "clips_tab",
        "feed_tab", "direct_tab", "search_tab", "profile_tab"
    )

    @Test fun rulesFileIsNotEmpty() = assertTrue(rules.size > 10)

    @Test fun everyRuleKeyPointsToARealFeature() {
        val bad = ruleKeys.filter { it.removePrefix("!") !in featureKeys }
        assertTrue("Katalogda olmayan kural anahtarları: $bad", bad.isEmpty())
    }

    @Test fun everyFeatureHasARule() {
        val missing = featureKeys.filter { it !in rules }
        assertTrue("Kuralı olmayan özellikler (engel çalışmaz): $missing", missing.isEmpty())
    }

    @Test fun noRuleListIsEmpty() {
        val empty = ruleKeys.filter { rules[it].isNullOrEmpty() }
        assertTrue("Boş kural listeleri: $empty", empty.isEmpty())
    }

    @Test fun noRuleFragmentIsTooGeneric() {
        val bad = ruleKeys.flatMap { k -> rules[k]!!.filter { it in tooGeneric || it.length < 5 }.map { "$k -> $it" } }
        assertTrue("Çok genel kural parçaları: $bad", bad.isEmpty())
    }

    @Test fun noDuplicateFragmentsInOneRule() {
        val bad = ruleKeys.filter { rules[it]!!.size != rules[it]!!.toSet().size }
        assertTrue("Tekrarlı parçalar: $bad", bad.isEmpty())
    }

    @Test fun verifiedListPointsToExistingRules() {
        val verified = rules["_verified"] ?: emptyList()
        val bad = verified.filter { it !in rules }
        assertTrue("_verified listesinde olmayan kurallar: $bad", bad.isEmpty())
    }

    @Test fun anExemptionNeverCancelsItsOwnRule() {
        val bad = ruleKeys.filter { it.startsWith("!") }.filter { k ->
            val pos = rules[k.removePrefix("!")] ?: return@filter true
            rules[k]!!.any { n -> pos.any { p -> p.contains(n) || n.contains(p) } }
        }
        assertTrue("İstisna kendi kuralını etkisiz kılıyor: $bad", bad.isEmpty())
    }
}
