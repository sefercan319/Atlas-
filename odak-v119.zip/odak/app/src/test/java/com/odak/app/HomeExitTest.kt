package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.53: özellik süresi dolunca uygulamada kal, ana sayfaya dön. */
class HomeExitTest {
    @Test fun homeYes_0() { assertTrue(Pure.isHomeLabel("Home")) }
    @Test fun homeYes_1() { assertTrue(Pure.isHomeLabel("home")) }
    @Test fun homeYes_2() { assertTrue(Pure.isHomeLabel("HOME")) }
    @Test fun homeYes_3() { assertTrue(Pure.isHomeLabel("Ana Sayfa")) }
    @Test fun homeYes_4() { assertTrue(Pure.isHomeLabel("ana sayfa")) }
    @Test fun homeYes_5() { assertTrue(Pure.isHomeLabel("Anasayfa")) }
    @Test fun homeYes_6() { assertTrue(Pure.isHomeLabel("Startseite")) }
    @Test fun homeYes_7() { assertTrue(Pure.isHomeLabel("Accueil")) }
    @Test fun homeYes_8() { assertTrue(Pure.isHomeLabel("Inicio")) }
    @Test fun homeYes_9() { assertTrue(Pure.isHomeLabel("Главная")) }
    @Test fun homeYes_10() { assertTrue(Pure.isHomeLabel("الرئيسية")) }
    @Test fun homeYes_11() { assertTrue(Pure.isHomeLabel("Ana səhifə")) }
    @Test fun homeYes_12() { assertTrue(Pure.isHomeLabel("Əsas səhifə")) }
    @Test fun homeYes_13() { assertTrue(Pure.isHomeLabel("  Home  ")) }
    @Test fun homeYes_14() { assertTrue(Pure.isHomeLabel("Home, tab 1 of 5")) }
    @Test fun homeYes_15() { assertTrue(Pure.isHomeLabel("Home tab")) }
    @Test fun homeYes_16() { assertTrue(Pure.isHomeLabel("Ana Sayfa, sekme 1")) }
    @Test fun homeYes_17() { assertTrue(Pure.isHomeLabel("Home - selected")) }
    @Test fun homeNo_18() { assertFalse(Pure.isHomeLabel("")) }
    @Test fun homeNo_19() { assertFalse(Pure.isHomeLabel("Homepage x")) }
    @Test fun homeNo_20() { assertFalse(Pure.isHomeLabel("Search")) }
    @Test fun homeNo_21() { assertFalse(Pure.isHomeLabel("Reels")) }
    @Test fun homeNo_22() { assertFalse(Pure.isHomeLabel("Reels, tab 3")) }
    @Test fun homeNo_23() { assertFalse(Pure.isHomeLabel("Explore")) }
    @Test fun homeNo_24() { assertFalse(Pure.isHomeLabel("Profile")) }
    @Test fun homeNo_25() { assertFalse(Pure.isHomeLabel("Home sweet home and more text here that is long enough")) }
    @Test fun homeNo_26() { assertFalse(Pure.isHomeLabel("Shop")) }
    @Test fun homeNo_27() { assertFalse(Pure.isHomeLabel("Notifications")) }
    @Test fun homeNo_28() { assertFalse(Pure.isHomeLabel("Messages")) }
    @Test fun homeNo_29() { assertFalse(Pure.isHomeLabel("House")) }
    @Test fun homeNo_30() { assertFalse(Pure.isHomeLabel("homes")) }
    @Test fun homeNo_31() { assertFalse(Pure.isHomeLabel("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")) }
    @Test fun exit_32() { assertEquals(1, Pure.featExit(true, 0)) }
    @Test fun exit_33() { assertEquals(1, Pure.featExit(true, 1)) }
    @Test fun exit_34() { assertEquals(0, Pure.featExit(true, 2)) }
    @Test fun exit_35() { assertEquals(0, Pure.featExit(true, 3)) }
    @Test fun exit_36() { assertEquals(0, Pure.featExit(true, 4)) }
    @Test fun exit_37() { assertEquals(0, Pure.featExit(true, 5)) }
    @Test fun exit_38() { assertEquals(0, Pure.featExit(false, 0)) }
    @Test fun exit_39() { assertEquals(0, Pure.featExit(false, 1)) }
    @Test fun exit_40() { assertEquals(0, Pure.featExit(false, 2)) }
    @Test fun exit_41() { assertEquals(0, Pure.featExit(false, 3)) }
    @Test fun exit_42() { assertEquals(0, Pure.featExit(false, 4)) }
    @Test fun exit_43() { assertEquals(0, Pure.featExit(false, 5)) }
    @Test fun exitConsts() { assertEquals(0, Pure.EXIT_BACK); assertEquals(1, Pure.EXIT_HOME_TAB) }
    private fun svc() = java.io.File(TestFiles.code, "com/odak/app/block/OdakAccessibilityService.kt").readText()
    @Test fun serviceUsesHomeExit() { val s = svc(); assertTrue(s.contains("Pure.featExit(BlockStore.featHome(this), homeTries)")); assertTrue(s.contains("clickHomeTab(root)")) }
    @Test fun serviceFallsBackToBack() { assertTrue(svc().contains("!clickHomeTab(root)) performGlobalAction(GLOBAL_ACTION_BACK)")) }
    @Test fun serviceResetsTries() { assertTrue(svc().contains("if (hitNow.isEmpty()) homeTries = 0")) }
    @Test fun settingDefaultOn() { assertTrue(java.io.File(TestFiles.code, "com/odak/app/block/BlockData.kt").readText().contains("getBoolean(\"feat_home\", true)")) }
    @Test fun toggleInAlertsScreen() { assertTrue(java.io.File(TestFiles.code, "com/odak/app/block/Extras.kt").readText().contains("R.string.alert_feat_home")) }
    @Test fun stringInAllLanguages() { for ((_, f) in TestFiles.stringFiles()) assertTrue(TestFiles.parseStrings(f).containsKey("alert_feat_home")) }
}
