package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Manifest: güncelleme/saat değişiminde alarmların yeniden kurulması. */
class ManifestTest {
    private val m = File(TestFiles.main, "AndroidManifest.xml").readText()

    @Test fun bootReceiverReschedulesOnUpdateAndTimeChange() {
        for (a in listOf("BOOT_COMPLETED", "MY_PACKAGE_REPLACED", "TIME_SET", "TIMEZONE_CHANGED"))
            assertTrue("eksik: $a", m.contains("android.intent.action.$a"))
    }

    @Test fun serviceIsProtectedByBindPermission() {
        assertTrue(m.contains("BIND_ACCESSIBILITY_SERVICE"))
        assertTrue(m.contains("BIND_NOTIFICATION_LISTENER_SERVICE"))
    }

    @Test fun mainActivityHandlesRotationWithoutRecreate() {
        val i = m.indexOf("android:name=\".MainActivity\"")
        val tag = m.substring(i, m.indexOf(">", i))
        assertTrue(tag.contains("configChanges"))
        assertTrue(tag.contains("orientation") && tag.contains("screenSize"))
        assertTrue(!tag.contains("screenOrientation")) // yön kilitli değil
    }

    @Test fun appIsResizableForTabletsAndFoldables() {
        assertTrue(m.contains("android:resizeableActivity=\"true\""))
    }

    @Test fun alarmsAndBootArePermitted() {
        assertTrue(m.contains("USE_EXACT_ALARM"))
        assertTrue(m.contains("RECEIVE_BOOT_COMPLETED"))
    }

    @Test fun mainActivityHandlesDensityChangeWithoutRecreate() {
        val i = m.indexOf("android:name=\".MainActivity\"")
        val tag = m.substring(i, m.indexOf(">", i))
        assertTrue(tag.contains("density"))
    }
}
