package com.odak.app

import com.odak.app.logo.LogoPure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.32: 19 değiştirilebilir uygulama simgesi (activity-alias). */
class LogoTest {
    private val manifest: String get() = File(TestFiles.main, "AndroidManifest.xml").readText()

    @Test fun nineteenOptions() { assertEquals(19, LogoPure.COUNT); assertEquals((1..19).toList(), LogoPure.all()) }

    @Test fun namesAndClamp() {
        assertEquals("A01", LogoPure.code(1)); assertEquals("A19", LogoPure.code(19))
        assertEquals("A01", LogoPure.code(0)); assertEquals("A01", LogoPure.code(99)); assertEquals(1, LogoPure.fromPref(-5))
        assertEquals("com.odak.app.alias.A07", LogoPure.aliasName("com.odak.app", 7))
        assertEquals("ic_logo_a12", LogoPure.resName(12))
    }

    @Test fun disableListExcludesSelected() {
        val d = LogoPure.toDisable(5)
        assertEquals(18, d.size); assertFalse(5 in d); assertEquals(18, LogoPure.toDisable(0).size); assertFalse(1 in LogoPure.toDisable(0))
    }

    @Test fun everyAliasHasIconAndLauncherAndOnlyFirstEnabled() {
        for (n in LogoPure.all()) {
            val c = LogoPure.code(n)
            assertTrue(c, manifest.contains("android:name=\".alias.$c\""))
            assertTrue(c, File(TestFiles.res, "mipmap-nodpi/" + LogoPure.resName(n) + ".png").length() > 1000)
            assertTrue(c, manifest.contains("@mipmap/" + LogoPure.resName(n)))
        }
        assertEquals(19, Regex("<activity-alias ").findAll(manifest).count())
        assertEquals(1, Regex("<activity-alias [^>]*android:enabled=\"true\"").findAll(manifest).count())
        assertTrue(manifest.contains("android:name=\".alias.A01\" android:targetActivity=\".MainActivity\" android:exported=\"true\" android:enabled=\"true\""))
        assertEquals(19, Regex("android.intent.category.LAUNCHER").findAll(manifest.substringAfter("<application")).count())
    }

    @Test fun mainActivityNoLongerLauncher() {
        val s = manifest.substringAfter("android:name=\".MainActivity\"").substringBefore("</activity>")
        assertFalse(s.contains("LAUNCHER"))
    }

    @Test fun pickerInLookGroupAndStringsInAllLocales() {
        assertTrue(File(TestFiles.code, "com/odak/app/settings/SettingsScreen.kt").readText().contains("com.odak.app.logo.LogoCard()"))
        val card = File(TestFiles.code, "com/odak/app/logo/LogoCard.kt").readText()
        assertTrue(card.contains("setComponentEnabledSetting") && card.contains("DONT_KILL_APP"))
        assertTrue(card.indexOf("COMPONENT_ENABLED_STATE_ENABLED") < card.indexOf("COMPONENT_ENABLED_STATE_DISABLED"))
        for (d in TestFiles.res.listFiles { f -> f.isDirectory && f.name.startsWith("values") }!!) {
            val f = File(d, "strings.xml"); if (f.exists()) { val t = f.readText(); assertTrue(d.name, t.contains("name=\"logo_title\"") && t.contains("name=\"logo_note\"")) }
        }
    }

    @Test fun iconsAre512px() {
        for (n in LogoPure.all()) {
            val b = File(TestFiles.res, "mipmap-nodpi/" + LogoPure.resName(n) + ".png").readBytes()
            val w = ((b[16].toInt() and 255) shl 24) or ((b[17].toInt() and 255) shl 16) or ((b[18].toInt() and 255) shl 8) or (b[19].toInt() and 255)
            assertEquals(LogoPure.code(n), 512, w)
        }
    }
}
