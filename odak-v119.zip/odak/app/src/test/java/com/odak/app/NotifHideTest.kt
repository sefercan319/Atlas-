package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Bildirim gizleme kararı ve servis bağlantısı. */
class NotifHideTest {
    @Test fun blockedNormalNotificationIsHidden() {
        assertTrue(Pure.hideNotification(ongoing = false, blocked = true, passActive = false))
    }

    @Test fun notBlockedIsNeverHidden() {
        assertFalse(Pure.hideNotification(ongoing = false, blocked = false, passActive = false))
    }

    @Test fun ongoingNotificationsAreKeptEvenIfBlocked() {
        assertFalse(Pure.hideNotification(ongoing = true, blocked = true, passActive = false))
    }

    @Test fun activePassKeepsNotifications() {
        assertFalse(Pure.hideNotification(ongoing = false, blocked = true, passActive = true))
    }

    @Test fun serviceUsesDecisionOnlyAndChecksOngoingAndLimit() {
        val s = File(TestFiles.code, "com/odak/app/block/OdakNotifService.kt").readText()
        assertTrue(s.contains("Pure.hideNotification(n.isOngoing, blocked, BlockStore.passActive(this, app.id))"))
        assertTrue(s.contains("limitReached(app)"))
        assertTrue(s.contains("BlockStore.usageAccess(this)"))
        assertTrue(s.contains("Pure.limitReached(BlockStore.appUsedMs(this, app), limit)"))
    }
}
