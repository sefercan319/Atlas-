package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Base64
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** v0.56.40: resim, üst/alt bilgi, dipnot, tablo stili, Excel biçimi, EPUB/FB2 yazma, MOBI okuma, PDF kaynak denetimleri. */
class DocRich2Test {
    private val PNG = Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
    private fun zipB(vararg e: Pair<String, ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bo.toByteArray()
    }
    private fun zipS(vararg e: Pair<String, String>) = zipB(*e.map { it.first to it.second.toByteArray() }.toTypedArray())
    private fun entries(b: ByteArray): List<Triple<String, Int, String>> {
        val l = ArrayList<Triple<String, Int, String>>()
        ZipInputStream(b.inputStream()).use { z -> while (true) { val e = z.nextEntry ?: break; l.add(Triple(e.name, e.method, String(z.readBytes(), Charsets.ISO_8859_1))) } }
        return l
    }
    private val W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
        "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\""
    private fun rich(d: Doc) = d.pages.first().rich!!
    private fun paras(rp: RichPage) = rp.blocks.filterIsInstance<RPara>()
    private fun imgDocx(): ByteArray = zipB(
        "word/document.xml" to ("<w:document $W><w:body><w:p><w:r><w:t>Merhaba</w:t></w:r></w:p><w:p><w:r><w:drawing><wp:inline><wp:extent cx=\"952500\" cy=\"476250\"/>" +
            "<a:graphic><a:graphicData><pic:pic><pic:blipFill><a:blip r:embed=\"rId5\"/></pic:blipFill></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p></w:body></w:document>").toByteArray(),
        "word/_rels/document.xml.rels" to "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId5\" Type=\"x/image\" Target=\"media/a.png\"/></Relationships>".toByteArray(),
        "word/media/a.png" to PNG)

    @Test fun mediaWantedCaps() {
        assertTrue(DocParse.mediaWanted("word/media/a.png")); assertTrue(DocParse.mediaWanted("Pictures/x.JPG"))
        assertFalse(DocParse.mediaWanted("word/media/a.emf")); assertFalse(DocParse.mediaWanted("word/document.xml"))
    }

    @Test fun docxImageParsed() {
        val d = DocParse.parse("a.docx", imgDocx())
        val img = paras(rich(d)).flatMap { it.runs }.mapNotNull { it.img }
        assertEquals(1, img.size)
        assertEquals("image/png", img[0].mime)
        assertTrue(img[0].w > 0 && img[0].h > 0)
        assertTrue(RichHtml.page(rich(d)).contains("data:image/png;base64,"))
    }

    @Test fun docxImageRoundTrips() {
        val d = DocParse.parse("a.docx", imgDocx())
        for (t in listOf(ConvTarget.DOCX, ConvTarget.ODT, ConvTarget.RTF, ConvTarget.HTML)) {
            val out = DocWrite.write(d, t, "a")!!
            assertTrue(t.name, out.size > 200)
        }
        val back = DocParse.parse("b.docx", DocWrite.write(d, ConvTarget.DOCX, "a")!!)
        assertEquals(1, paras(rich(back)).flatMap { it.runs }.count { it.img != null })
        val odt = DocParse.parse("b.odt", DocWrite.write(d, ConvTarget.ODT, "a")!!)
        assertEquals(1, paras(rich(odt)).flatMap { it.runs }.count { it.img != null })
        val rtf = String(DocWrite.write(d, ConvTarget.RTF, "a")!!, Charsets.ISO_8859_1)
        assertTrue(rtf.contains("\\pict") && rtf.contains("\\pngblip"))
    }

    @Test fun docxHeaderFooterFootnote() {
        val rels = "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rH\" Type=\"x/header\" Target=\"header1.xml\"/><Relationship Id=\"rF\" Type=\"x/footer\" Target=\"footer1.xml\"/></Relationships>"
        val body = "<w:p><w:r><w:t>Metin</w:t></w:r><w:r><w:footnoteReference w:id=\"2\"/></w:r></w:p><w:sectPr><w:headerReference w:type=\"default\" r:id=\"rH\"/><w:footerReference w:type=\"default\" r:id=\"rF\"/></w:sectPr>"
        val b = zipS(
            "word/document.xml" to "<w:document $W><w:body>$body</w:body></w:document>",
            "word/_rels/document.xml.rels" to rels,
            "word/header1.xml" to "<w:hdr $W><w:p><w:r><w:t>ÜSTBİLGİ</w:t></w:r></w:p></w:hdr>",
            "word/footer1.xml" to "<w:ftr $W><w:p><w:r><w:t>ALTBİLGİ</w:t></w:r></w:p></w:ftr>",
            "word/footnotes.xml" to "<w:footnotes $W><w:footnote w:id=\"2\"><w:p><w:r><w:t>DİPNOT METNİ</w:t></w:r></w:p></w:footnote></w:footnotes>")
        val d = DocParse.parse("n.docx", b)
        val rp = rich(d)
        assertNotNull(rp.header); assertNotNull(rp.footer)
        val html = RichHtml.page(rp)
        assertTrue(html.contains("ÜSTBİLGİ")); assertTrue(html.contains("ALTBİLGİ")); assertTrue(html.contains("DİPNOT METNİ"))
        val back = DocParse.parse("n2.docx", DocWrite.write(d, ConvTarget.DOCX, "n")!!)
        assertNotNull(rich(back).header); assertNotNull(rich(back).footer)
    }

    @Test fun docxTableStyleBanding() {
        val styles = "<w:styles $W><w:style w:type=\"table\" w:styleId=\"TS\"><w:tblStylePr w:type=\"firstRow\"><w:tcPr><w:shd w:val=\"clear\" w:fill=\"1F4E79\"/></w:tcPr></w:tblStylePr>" +
            "<w:tblStylePr w:type=\"band1Horz\"><w:tcPr><w:shd w:val=\"clear\" w:fill=\"DDEEFF\"/></w:tcPr></w:tblStylePr></w:style></w:styles>"
        fun tc(t: String) = "<w:tc><w:p><w:r><w:t>$t</w:t></w:r></w:p></w:tc>"
        val tbl = "<w:tbl><w:tblPr><w:tblStyle w:val=\"TS\"/><w:tblLook w:firstRow=\"1\" w:noHBand=\"0\"/></w:tblPr><w:tblGrid><w:gridCol w:w=\"2000\"/></w:tblGrid>" +
            "<w:tr>${tc("H")}</w:tr><w:tr>${tc("A")}</w:tr><w:tr>${tc("B")}</w:tr></w:tbl><w:p/>"
        val d = DocParse.parse("t.docx", zipS("word/document.xml" to "<w:document $W><w:body>$tbl</w:body></w:document>", "word/styles.xml" to styles))
        val t = rich(d).blocks.filterIsInstance<RTable>().first()
        val fills = t.rows.map { it[0].fill?.uppercase() }
        assertEquals("1F4E79", fills[0])
        assertTrue(fills[1] == "DDEEFF" || fills[2] == "DDEEFF")
    }

    @Test fun xlsxRichFormat() {
        val st = "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFFF0000\"/><name val=\"Calibri\"/></font></fonts>" +
            "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFFFFF00\"/></patternFill></fill></fills>" +
            "<borders count=\"1\"><border><left/><right/><top/><bottom/></border></borders><cellStyleXfs count=\"1\"><xf/></cellStyleXfs>" +
            "<cellXfs count=\"2\"><xf fontId=\"0\" fillId=\"0\" borderId=\"0\"/><xf fontId=\"1\" fillId=\"2\" borderId=\"0\" applyFont=\"1\" applyFill=\"1\"/></cellXfs></styleSheet>"
        val sh = "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols><col min=\"1\" max=\"1\" width=\"30\"/></cols><sheetData><row r=\"1\"><c r=\"A1\" t=\"inlineStr\" s=\"1\"><is><t>Baş</t></is></c><c r=\"B1\"><v>5</v></c></row></sheetData><mergeCells count=\"1\"><mergeCell ref=\"A2:B2\"/></mergeCells></worksheet>"
        val wb = "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"S\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
        val d = DocParse.parse("x.xlsx", zipS("xl/workbook.xml" to wb, "xl/styles.xml" to st, "xl/worksheets/sheet1.xml" to sh,
            "xl/_rels/workbook.xml.rels" to "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"x/ws\" Target=\"worksheets/sheet1.xml\"/></Relationships>"))
        val rp = d.pages.first().rich
        assertNotNull(rp)
        val t = rp!!.blocks.filterIsInstance<RTable>().first()
        val c = t.rows[0][0]
        assertEquals("FFFF00", c.fill?.takeLast(6)?.uppercase())
        assertTrue(c.paras.first().runs.first().b)
    }

    private fun sample(): Doc {
        return DocParse.parse("s.md", "# Bir\n\nBirinci bölüm\n\n# İki\n\nİkinci bölüm & daha\n".toByteArray())
    }

    @Test fun epubStructure() {
        val b = DocWrite.write(sample(), ConvTarget.EPUB, "kitap.docx")!!
        val e = entries(b)
        assertEquals("mimetype", e[0].first); assertEquals(0, e[0].second); assertEquals("application/epub+zip", e[0].third)
        val names = e.map { it.first }
        assertTrue(names.contains("META-INF/container.xml")); assertTrue(names.any { it.endsWith(".opf") })
        assertTrue(names.any { it.endsWith("nav.xhtml") }); assertTrue(names.any { it.endsWith(".ncx") })
        val chapters = names.filter { it.endsWith(".xhtml") && !it.endsWith("nav.xhtml") }
        assertTrue(chapters.size >= 2)
        val all = e.joinToString("") { it.third }
        assertTrue(all.contains("kitap")); assertEquals(names.size, names.toSet().size)
        for ((n, _, c) in e) if (n.endsWith(".xhtml") || n.endsWith(".opf") || n.endsWith(".ncx") || n.endsWith(".xml")) {
            val f = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder()
            f.parse(c.toByteArray(Charsets.ISO_8859_1).inputStream())
        }
    }

    @Test fun epubReadsBackAndKeepsText() {
        val b = DocWrite.write(sample(), ConvTarget.EPUB, "k")!!
        val d = DocParse.parse("k.epub", b)
        assertEquals(DocKind.EPUB, d.kind)
        val all = d.pages.flatMap { it.paragraphs }.joinToString(" ")
        assertTrue(all.contains("Birinci bölüm")); assertTrue(all.contains("İkinci bölüm & daha"))
    }

    @Test fun epubImagesIncluded() {
        val d = DocParse.parse("a.docx", imgDocx())
        val e = entries(DocWrite.write(d, ConvTarget.EPUB, "a")!!)
        assertTrue(e.any { it.first.contains("png") })
    }

    @Test fun fb2RoundTrip() {
        val b = DocWrite.write(sample(), ConvTarget.FB2, "k")!!
        val s = String(b, Charsets.UTF_8)
        javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(b.inputStream())
        assertTrue(s.contains("<FictionBook")); assertTrue(s.contains("İkinci bölüm &amp; daha"))
        val d = DocParse.parse("k.fb2", b)
        assertEquals(DocKind.FB2, d.kind)
        assertTrue(d.pages.flatMap { it.paragraphs }.joinToString(" ").contains("Birinci bölüm"))
    }

    @Test fun ebookTargets() {
        for (k in listOf(DocKind.DOCX, DocKind.TEXT, DocKind.HTML, DocKind.PDF, DocKind.MOBI)) {
            val t = DocConvert.targetsFor(k, true)
            assertTrue(k.name, t.contains(ConvTarget.EPUB) && t.contains(ConvTarget.FB2))
        }
        assertFalse(DocConvert.targetsFor(DocKind.EPUB, true).contains(ConvTarget.EPUB))
        assertFalse(DocConvert.targetsFor(DocKind.FB2, true).contains(ConvTarget.FB2))
        assertEquals("kitap.epub", DocConvert.outName("kitap.docx", ConvTarget.EPUB))
        assertEquals("kitap.fb2", DocConvert.outName("kitap.docx", ConvTarget.FB2))
    }

    @Test fun fbzZipped() {
        val fb = DocWrite.write(sample(), ConvTarget.FB2, "k")!!
        val d = DocParse.parse("k.fb2.zip", zipB("k.fb2" to fb))
        assertEquals(DocKind.FB2, d.kind)
        val d2 = DocParse.parse("k.fbz", zipB("k.fb2" to fb))
        assertEquals(DocKind.FB2, d2.kind)
    }

    // ---- MOBI ----
    private fun be16(v: Int) = byteArrayOf((v shr 8).toByte(), v.toByte())
    private fun be32(v: Int) = byteArrayOf((v shr 24).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte())
    private fun mobi(comp: Int, texts: List<ByteArray>, enc: Int = 0): ByteArray {
        val r0 = be16(comp) + be16(0) + be32(0) + be16(texts.size) + be16(4096) + be16(enc) + be16(0)
        val recs = listOf(r0) + texts
        val head = ByteArray(78); "TESTBOOK".toByteArray().copyInto(head, 0); "BOOKMOBI".toByteArray().copyInto(head, 60)
        be16(recs.size).copyInto(head, 76)
        var off = 78 + recs.size * 8 + 2
        val list = ByteArrayOutputStream()
        for (r in recs) { list.write(be32(off)); list.write(byteArrayOf(0, 0, 0, 0)); off += r.size }
        val o = ByteArrayOutputStream(); o.write(head); o.write(list.toByteArray()); o.write(byteArrayOf(0, 0)); for (r in recs) o.write(r)
        return o.toByteArray()
    }

    @Test fun palmDecompressVectors() {
        fun dec(vararg b: Int): String { val o = ByteArrayOutputStream(); Mobi.palmDecompress(ByteArray(b.size) { b[it].toByte() }, o); return String(o.toByteArray(), Charsets.ISO_8859_1) }
        assertEquals("abc", dec('a'.code, 'b'.code, 'c'.code))
        assertEquals(" A", dec(0xC1))
        assertEquals("abcabc", dec('a'.code, 'b'.code, 'c'.code, 0x80, 0x18))
        assertEquals("xyz", dec(3, 'x'.code, 'y'.code, 'z'.code))
    }

    @Test fun mobiUncompressedAndCompressed() {
        val html = "<html><body><p>Merhaba dünya</p><mbp:pagebreak/><p>İkinci sayfa</p></body></html>"
        val d1 = Mobi.mobiDoc(mobi(1, listOf(html.toByteArray(Charsets.ISO_8859_1))))
        assertTrue(Mobi.isMobi(mobi(1, listOf(ByteArray(1)))))
        assertEquals(2, d1.pages.size)
        assertTrue(d1.pages[0].paragraphs.joinToString(" ").contains("Merhaba"))
        // sıkıştırılmış: yalnız literal baytlar (0x09..0x7f) PalmDOC'ta olduğu gibi kopyalanır
        val txt = "<p>Sade metin burada</p>".toByteArray(Charsets.ISO_8859_1)
        val d2 = Mobi.mobiDoc(mobi(2, listOf(txt)))
        assertEquals(DocKind.MOBI, d2.kind)
        assertTrue(d2.pages.flatMap { it.paragraphs }.joinToString(" ").contains("Sade metin burada"))
    }

    @Test fun mobiUnsupportedAndBroken() {
        assertTrue(Mobi.mobiDoc(mobi(17480, listOf(ByteArray(10)))).pages.isEmpty())
        assertTrue(Mobi.mobiDoc(mobi(2, listOf(ByteArray(10)), enc = 2)).pages.isEmpty())
        assertTrue(Mobi.mobiDoc(ByteArray(50)).pages.isEmpty())
        assertFalse(Mobi.isMobi(ByteArray(100)))
        val d = DocParse.parse("b.azw3", mobi(1, listOf("<p>Kitap</p>".toByteArray())))
        assertEquals(DocKind.MOBI, d.kind)
    }

    // ---- kaynak denetimleri ----
    private fun src(n: String) = File(TestFiles.code, "com/odak/app/docs/$n").readText()

    @Test fun pdfSourceChecks() {
        val p = src("DocPdf.kt"); val r = src("DocPdfRich.kt")
        assertTrue(p.contains("FmtStripper")); assertTrue(p.contains("richPage"))
        assertTrue(r.contains("drawBitmap")); assertTrue(r.contains("justify", ignoreCase = true))
    }

    @Test fun fullViewSourceChecks() {
        val a = src("DocActivity.kt")
        assertTrue(a.contains("RichWebView")); assertTrue(a.contains("javaScriptEnabled = false"))
    }

    @Test fun stringsInAllLocales() {
        val res = TestFiles.res
        for (d in listOf("values", "values-tr", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az")) {
            val s = File(res, "$d/strings.xml").readText()
            assertTrue(d, s.contains("name=\"doc_hint\"") && s.contains("name=\"conv_note_rich\"") && s.contains("EPUB"))
        }
    }
}
