package com.odak.app

import java.io.File

/** Birim testlerde kaynak dosyalara ulaşma yardımcıları (çalışma dizini = app/ modülü). */
object TestFiles {
    val main: File = listOf(File("src/main"), File("app/src/main")).first { it.exists() }
    val res: File = File(main, "res")
    val code: File = File(main, "java")

    fun kotlinSources(): List<File> = code.walkTopDown().filter { it.extension == "kt" }.toList()

    /** values, values-tr, values-en ... klasörlerindeki strings.xml dosyaları. */
    fun stringFiles(): Map<String, File> =
        res.listFiles { f -> f.isDirectory && f.name.startsWith("values") }!!
            .map { it.name to File(it, "strings.xml") }.filter { it.second.exists() }.toMap()

    /** strings.xml -> (ad -> ham metin). */
    fun parseStrings(f: File): Map<String, String> {
        val doc = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(f)
        val nodes = doc.getElementsByTagName("string")
        return (0 until nodes.length).associate {
            val n = nodes.item(it)
            n.attributes.getNamedItem("name").nodeValue to n.textContent
        }
    }

    /** block_rules.json: "anahtar": ["a","b"] biçimindeki basit sözlük. */
    fun parseRules(f: File): Map<String, List<String>> {
        val text = f.readText()
        val out = LinkedHashMap<String, List<String>>()
        Regex(""""([^"]+)"\s*:\s*\[(.*?)]""", RegexOption.DOT_MATCHES_ALL).findAll(text).forEach { m ->
            out[m.groupValues[1]] = Regex(""""([^"]*)"""").findAll(m.groupValues[2]).map { it.groupValues[1] }.toList()
        }
        return out
    }

    class SrcApp(val id: String, val name: String, val packages: List<String>, val features: List<String>)

    /** BlockData.kt içindeki katalog satırlarını okur. */
    fun catalog(): List<SrcApp> {
        val text = File(code, "com/odak/app/block/BlockData.kt").readText()
        val start = text.indexOf("private val base = listOf(")
        val end = text.indexOf("/** Kullanıcının eklediği")
        val body = text.substring(start, end)
        return Regex("""BlockApp\("([^"]+)", "([^"]+)", listOf\(([^)]*)\), (emptyList\(\)|listOf\((.*)\))\)""")
            .findAll(body).map { m ->
                SrcApp(
                    m.groupValues[1], m.groupValues[2],
                    Regex(""""([^"]+)"""").findAll(m.groupValues[3]).map { it.groupValues[1] }.toList(),
                    Regex("""Feat\("([^"]+)"""").findAll(m.groupValues[5]).map { it.groupValues[1] }.toList()
                )
            }.toList()
    }
}
