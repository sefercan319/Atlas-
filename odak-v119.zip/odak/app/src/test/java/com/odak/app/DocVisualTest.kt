package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** v0.56.3: belge içi resim, grafik, diyagram. */
class DocVisualTest {
    private fun zip(m: Map<String, Any>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> for ((k, v) in m) { z.putNextEntry(ZipEntry(k)); z.write(if (v is String) v.toByteArray() else v as ByteArray); z.closeEntry() } }
        return bo.toByteArray()
    }
    private val REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private fun rels(vararg x: Triple<String, String, String>) = "<Relationships>" + x.joinToString("") { "<Relationship Id=\"${it.first}\" Type=\"$REL/${it.second}\" Target=\"${it.third}\"/>" } + "</Relationships>"
    private fun chartXml(kind: String, cats: List<String>, series: List<Pair<String, List<String?>>>, extra: String = "", title: String = "") =
        "<c:chartSpace xmlns:c=\"c\" xmlns:a=\"a\"><c:chart>" + (if (title.isNotEmpty()) "<c:title><c:tx><c:rich><a:p><a:r><a:t>$title</a:t></a:r></a:p></c:rich></c:tx></c:title>" else "") +
            "<c:plotArea><c:$kind>$extra" + series.joinToString("") { (n, vs) ->
            "<c:ser><c:tx><c:strRef><c:strCache><c:ptCount val=\"1\"/><c:pt idx=\"0\"><c:v>$n</c:v></c:pt></c:strCache></c:strRef></c:tx>" +
                "<c:cat><c:strRef><c:strCache><c:ptCount val=\"${cats.size}\"/>" + cats.mapIndexed { i, c -> "<c:pt idx=\"$i\"><c:v>$c</c:v></c:pt>" }.joinToString("") + "</c:strCache></c:strRef></c:cat>" +
                "<c:val><c:numRef><c:numCache><c:ptCount val=\"${cats.size}\"/>" + vs.mapIndexed { i, v -> if (v == null) "" else "<c:pt idx=\"$i\"><c:v>$v</c:v></c:pt>" }.joinToString("") + "</c:numCache></c:numRef></c:val></c:ser>"
        } + "</c:$kind></c:plotArea></c:chart></c:chartSpace>"

    private fun pc(x: Any) = DocVisual.parseChart(if (x is String) x.toByteArray() else x as ByteArray)

    // ---- yol çözümleme
    @Test fun resolveRelative() { assertEquals("word/media/a.png", DocVisual.resolve("word/", "media/a.png")); assertEquals("word/media/a.png", DocVisual.resolve("word/", "./media/a.png")) }
    @Test fun resolveParent() { assertEquals("xl/media/a.png", DocVisual.resolve("xl/drawings/", "../media/a.png")); assertEquals("a.png", DocVisual.resolve("x/", "../../a.png")) }
    @Test fun resolveAbsolute() { assertEquals("ppt/media/a.png", DocVisual.resolve("ppt/slides/", "/ppt/media/a.png")) }
    @Test fun resolveBackslashAndBlank() { assertEquals("word/media/a.png", DocVisual.resolve("word/", "media\\a.png")); assertEquals("", DocVisual.resolve("", "")) }
    @Test fun relsPaths() { assertEquals("word/_rels/document.xml.rels", DocVisual.relsPathOf("word/document.xml")); assertEquals("_rels/x.rels", DocVisual.relsPathOf("x")) ; assertEquals("word/", DocVisual.dirOf("word/document.xml")); assertEquals("", DocVisual.dirOf("content.xml")) }
    @Test fun imageNames() { for (n in listOf("a.PNG", "x/y.jpeg", "a.gif", "a.webp", "a.emf", "a.svg", "a.tiff")) assertTrue(n, DocVisual.isImageName(n)); for (n in listOf("a.xml", "a", "a.bin")) assertFalse(n, DocVisual.isImageName(n)) }
    @Test fun decodableFormats() { for (n in listOf("a.png", "a.JPG", "a.jpeg", "a.gif", "a.bmp", "a.webp", "a.emf", "a.wmf", "a.svg", "a.tif", "a.tiff")) assertTrue(n, DocVisual.isDecodable(n)); for (n in listOf("a.xml", "a.bin", "a")) assertFalse(n, DocVisual.isDecodable(n)) }

    // ---- başvurular
    @Test fun refsOrderAndKinds() {
        val r = DocVisual.refs("<w:p><a:blip r:embed=\"rId5\"/><v:imagedata r:id=\"rId6\"/><c:chart r:id=\"rId7\"/><a:blip r:embed=\"rId8\"/></w:p>".toByteArray())
        assertEquals(listOf("img" to "rId5", "img" to "rId6", "chart" to "rId7", "img" to "rId8"), r)
    }
    @Test fun refsPrefixIndependent() { assertEquals(listOf("chart" to "rId1"), DocVisual.refs("<x><c:chart xmlns:c=\"c\" r:id=\"rId1\"/></x>".toByteArray())); assertEquals(listOf("chart" to "r2"), DocVisual.refs("<x><chart r:id=\"r2\"/></x>".toByteArray())) }
    @Test fun refsGarbageSafe() { assertTrue(DocVisual.refs("<a><b>".toByteArray()).isEmpty()); assertTrue(DocVisual.refs(ByteArray(0)).isEmpty()) }

    // ---- grafik ayrıştırma
    @Test fun barChart() {
        val c = pc(chartXml("barChart", listOf("A", "B", "C"), listOf("S1" to listOf("1", "2.5", "3"), "S2" to listOf("4", "5", "6")), "<c:barDir val=\"col\"/>", "Başlık"))!!
        assertEquals(ChartKind.BAR, c.kind); assertEquals("Başlık", c.title); assertEquals(listOf("A", "B", "C"), c.cats); assertEquals(listOf("S1", "S2"), c.series.map { it.name }); assertEquals(listOf(1.0, 2.5, 3.0), c.series[0].values)
    }
    @Test fun horizontalBar() { assertEquals(ChartKind.HBAR, pc(chartXml("barChart", listOf("A"), listOf("S" to listOf("1")), "<c:barDir val=\"bar\"/>"))!!.kind) }
    @Test fun lineAreaPie() {
        assertEquals(ChartKind.LINE, pc(chartXml("lineChart", listOf("A"), listOf("S" to listOf("1"))))!!.kind)
        assertEquals(ChartKind.AREA, pc(chartXml("areaChart", listOf("A"), listOf("S" to listOf("1"))))!!.kind)
        assertEquals(ChartKind.PIE, pc(chartXml("pieChart", listOf("A", "B"), listOf("S" to listOf("1", "3"))))!!.kind)
        assertEquals(ChartKind.PIE, pc(chartXml("doughnutChart", listOf("A"), listOf("S" to listOf("1"))))!!.kind)
        assertEquals(ChartKind.BAR, pc(chartXml("bar3DChart", listOf("A"), listOf("S" to listOf("1"))))!!.kind)
    }
    @Test fun missingPointsBecomeNull() { val c = pc(chartXml("lineChart", listOf("A", "B", "C"), listOf("S" to listOf("1", null, "3"))))!!; assertEquals(listOf(1.0, null, 3.0), c.series[0].values) }
    @Test fun nonNumericValueIsNull() { val c = pc(chartXml("barChart", listOf("A", "B"), listOf("S" to listOf("x", "2"))))!!; assertEquals(listOf(null, 2.0), c.series[0].values) }
    @Test fun noSeriesOrNoCacheIsNull() {
        assertNull(pc("<c:chartSpace xmlns:c=\"c\"><c:chart><c:plotArea><c:barChart/></c:plotArea></c:chart></c:chartSpace>".toByteArray()))
        assertNull(pc("<chartSpace><chart><plotArea><lineChart><ser><tx><strRef><f>A1</f></strRef></tx><val><numRef><f>B1:B3</f></numRef></val></ser></lineChart></plotArea></chart></chartSpace>".toByteArray()))
        assertNull(pc("<x/>".toByteArray())); assertNull(pc(ByteArray(0)))
    }
    @Test fun unnamedSeriesGetNames() { val x = chartXml("barChart", listOf("A"), listOf("" to listOf("1"))).replace("<c:v></c:v>", "<c:v></c:v>"); assertEquals("S1", pc(x)!!.series[0].name) }
    @Test fun missingCategoriesNumbered() { val x = "<chartSpace><chart><plotArea><barChart><ser><val><numRef><numCache><ptCount val=\"2\"/><pt idx=\"0\"><v>5</v></pt><pt idx=\"1\"><v>6</v></pt></numCache></numRef></val></ser></barChart></plotArea></chart></chartSpace>"; assertEquals(listOf("1", "2"), pc(x.toByteArray())!!.cats) }
    @Test fun axisTitleIsNotChartTitle() { val x = chartXml("barChart", listOf("A"), listOf("S" to listOf("1")), "", "Ana").replace("</c:plotArea>", "<c:valAx><c:title><c:tx><c:rich><a:p><a:r><a:t>Eksen</a:t></a:r></a:p></c:rich></c:tx></c:title></c:valAx></c:plotArea>"); assertEquals("Ana", pc(x.toByteArray())!!.title) }
    @Test fun scatterUsesXVal() {
        val x = "<chartSpace><chart><plotArea><scatterChart><ser><xVal><numRef><numCache><ptCount val=\"2\"/><pt idx=\"0\"><v>1</v></pt><pt idx=\"1\"><v>4</v></pt></numCache></numRef></xVal><yVal><numRef><numCache><ptCount val=\"2\"/><pt idx=\"0\"><v>10</v></pt><pt idx=\"1\"><v>20</v></pt></numCache></numRef></yVal></ser></scatterChart></plotArea></chart></chartSpace>"
        val c = pc(x.toByteArray())!!; assertEquals(ChartKind.SCATTER, c.kind); assertEquals(listOf(10.0, 20.0), c.series[0].values); assertEquals(listOf(1.0, 4.0), c.series[0].xs)
    }
    @Test fun turkishAndEscapedNames() { val c = pc(chartXml("pieChart", listOf("Şubat", "A&amp;B"), listOf("Pay" to listOf("1", "2"))))!!; assertEquals(listOf("Şubat", "A&B"), c.cats) }
    @Test fun seriesCapped() { val c = pc(chartXml("barChart", listOf("A"), List(80) { "S$it" to listOf("1") }))!!; assertEquals(40, c.series.size) }

    // ---- ODF grafik
    private fun odfChart(cls: String, rows: List<List<String>>, header: List<String>, title: String = "") =
        "<office:document-content><office:body><office:chart><chart:chart chart:class=\"chart:$cls\">" + (if (title.isNotEmpty()) "<chart:title><text:p>$title</text:p></chart:title>" else "") +
            "<table:table table:name=\"local-table\"><table:table-header-rows><table:table-row>" + header.joinToString("") { "<table:table-cell><text:p>$it</text:p></table:table-cell>" } + "</table:table-row></table:table-header-rows><table:table-rows>" +
            rows.joinToString("") { r -> "<table:table-row>" + r.mapIndexed { i, c -> if (i == 0) "<table:table-cell><text:p>$c</text:p></table:table-cell>" else "<table:table-cell office:value-type=\"float\" office:value=\"$c\"><text:p>$c</text:p></table:table-cell>" }.joinToString("") + "</table:table-row>" } +
            "</table:table-rows></table:table></chart:chart></office:chart></office:body></office:document-content>"
    @Test fun odfBar() { val c = DocVisual.parseOdfChart(odfChart("bar", listOf(listOf("A", "1", "2"), listOf("B", "3", "4")), listOf("", "X", "Y"), "T").toByteArray())!!; assertEquals(ChartKind.BAR, c.kind); assertEquals("T", c.title); assertEquals(listOf("A", "B"), c.cats); assertEquals(listOf("X", "Y"), c.series.map { it.name }); assertEquals(listOf(2.0, 4.0), c.series[1].values) }
    @Test fun odfClasses() { for ((k, e) in mapOf("circle" to ChartKind.PIE, "line" to ChartKind.LINE, "area" to ChartKind.AREA, "scatter" to ChartKind.SCATTER, "bar" to ChartKind.BAR)) assertEquals(k, e, DocVisual.parseOdfChart(odfChart(k, listOf(listOf("A", "1")), listOf("", "S")).toByteArray())!!.kind) }
    @Test fun odfUnknownOrEmpty() { assertNull(DocVisual.parseOdfChart(odfChart("weird", listOf(listOf("A", "1")), listOf("", "S")).toByteArray())); assertNull(DocVisual.parseOdfChart(odfChart("bar", emptyList(), listOf("", "S")).toByteArray())); assertNull(DocVisual.parseOdfChart(ByteArray(0))) }
    @Test fun odfNoHeaderNamesSeries() { val x = odfChart("bar", listOf(listOf("A", "1")), listOf("")).replace("<table:table-header-rows><table:table-row><table:table-cell><text:p></text:p></table:table-cell></table:table-row></table:table-header-rows>", ""); assertEquals("S1", DocVisual.parseOdfChart(x.toByteArray())!!.series[0].name) }

    // ---- SmartArt
    private fun dsp(vararg b: String) = "<dsp:drawing xmlns:dsp=\"d\" xmlns:a=\"a\"><dsp:spTree>" + b.joinToString("") { it } + "</dsp:spTree></dsp:drawing>"
    private fun sp(x: Int, y: Int, w: Int, h: Int, t: String, geom: String = "rect") = "<dsp:sp><dsp:spPr><a:xfrm><a:off x=\"$x\" y=\"$y\"/><a:ext cx=\"$w\" cy=\"$h\"/></a:xfrm><a:prstGeom prst=\"$geom\"/></dsp:spPr><dsp:txBody><a:p><a:r><a:t>$t</a:t></a:r></a:p></dsp:txBody><dsp:txXfrm><a:off x=\"999\" y=\"999\"/><a:ext cx=\"1\" cy=\"1\"/></dsp:txXfrm></dsp:sp>"
    @Test fun dspBoxes() { val d = DocVisual.parseDsp(dsp(sp(0, 0, 100, 50, "Bir"), sp(200, 100, 100, 50, "İki", "roundRect")).toByteArray())!!; assertEquals(2, d.boxes.size); assertEquals("Bir", d.boxes[0].text); assertFalse(d.boxes[0].round); assertTrue(d.boxes[1].round); assertEquals(300.0, d.w, 0.0); assertEquals(150.0, d.h, 0.0); assertEquals(0.0, d.boxes[0].x, 0.0) }
    @Test fun dspIgnoresTextTransform() { val d = DocVisual.parseDsp(dsp(sp(10, 20, 30, 40, "x")).toByteArray())!!; assertEquals(10.0, d.boxes[0].x, 0.0); assertEquals(30.0, d.boxes[0].w, 0.0) }
    @Test fun dspEmptyOrZeroSize() { assertNull(DocVisual.parseDsp(dsp().toByteArray())); assertNull(DocVisual.parseDsp(dsp(sp(0, 0, 0, 0, "x")).toByteArray())); assertNull(DocVisual.parseDsp(ByteArray(0))) }

    // ---- Visio
    private fun shape(id: Int, x: Double, y: Double, w: Double, h: Double, t: String = "", inner: String = "") =
        "<Shape ID=\"$id\"><Cell N=\"PinX\" V=\"$x\"/><Cell N=\"PinY\" V=\"$y\"/><Cell N=\"Width\" V=\"$w\"/><Cell N=\"Height\" V=\"$h\"/>" + (if (t.isNotEmpty()) "<Text>$t</Text>" else "") + inner + "</Shape>"
    @Test fun visioBoxesAndFlip() {
        val d = DocVisual.parseVisio("<PageContents><Shapes>${shape(1, 2.0, 1.0, 2.0, 1.0, "Alt")}${shape(2, 2.0, 5.0, 2.0, 1.0, "Üst")}</Shapes></PageContents>".toByteArray())!!
        val alt = d.boxes.first { it.text == "Alt" }; val ust = d.boxes.first { it.text == "Üst" }
        assertTrue("Y ekseni çevrilmeli: üst şekil yukarıda", ust.y < alt.y); assertEquals(1.0, alt.x, 1e-9); assertEquals(2.0, alt.w, 1e-9)
    }
    @Test fun visioConnector() { val d = DocVisual.parseVisio("<P><Shapes>${shape(1, 1.0, 1.0, 1.0, 1.0)}<Shape ID=\"3\"><Cell N=\"BeginX\" V=\"1\"/><Cell N=\"BeginY\" V=\"1\"/><Cell N=\"EndX\" V=\"4\"/><Cell N=\"EndY\" V=\"3\"/></Shape></Shapes></P>".toByteArray())!!; assertEquals(1, d.lines.size); assertEquals(1, d.boxes.size); assertEquals(4.0, d.lines[0].x2, 1e-9) }
    @Test fun visioGroupChildOffset() { val d = DocVisual.parseVisio("<P><Shapes><Shape ID=\"1\"><Cell N=\"PinX\" V=\"10\"/><Cell N=\"PinY\" V=\"10\"/><Cell N=\"Width\" V=\"4\"/><Cell N=\"Height\" V=\"4\"/><Cell N=\"LocPinX\" V=\"2\"/><Cell N=\"LocPinY\" V=\"2\"/><Shapes>${shape(2, 1.0, 1.0, 2.0, 2.0, "Çocuk")}</Shapes></Shape></Shapes></P>".toByteArray())!!; val c = d.boxes.first { it.text == "Çocuk" }; assertEquals(8.0, c.x, 1e-9) }
    @Test fun visioEmptyAndGarbage() { assertNull(DocVisual.parseVisio("<P/>".toByteArray())); assertNull(DocVisual.parseVisio(ByteArray(0))) }

    // ---- belgeye iliştirme
    private val png = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47)
    @Test fun docxImagesInOrder() {
        val b = DocWrite.docx(Doc(DocKind.DOCX, listOf(DocPage("", listOf("metin")))))
        val src = unzipAll(b)
        val xml = "<w:document><w:body><w:p><w:r><w:drawing><a:blip r:embed=\"rId9\"/></w:drawing></w:r></w:p><w:p><w:r><w:t>metin</w:t></w:r></w:p><w:p><a:blip r:embed=\"rId8\"/></w:p></w:body></w:document>"
        val z = zip(src.filterKeys { it != "word/document.xml" } + mapOf("word/document.xml" to xml, "word/_rels/document.xml.rels" to rels(Triple("rId8", "image", "media/b.jpg"), Triple("rId9", "image", "media/a.png")), "word/media/a.png" to png, "word/media/b.jpg" to png))
        val d = DocParse.parse("x.docx", z)
        assertEquals(listOf("word/media/a.png", "word/media/b.jpg"), d.pages[0].visuals!!.images); assertEquals(listOf("metin"), d.pages[0].paragraphs)
    }
    @Test fun externalImageLinksIgnored() {
        val xml = "<w:document><w:body><w:p><a:blip r:embed=\"rId1\"/></w:p></w:body></w:document>"
        val z = zip(mapOf("[Content_Types].xml" to "<Types/>", "word/document.xml" to xml, "word/_rels/document.xml.rels" to "<Relationships><Relationship Id=\"rId1\" Type=\"$REL/image\" Target=\"http://x/y.png\" TargetMode=\"External\"/></Relationships>"))
        assertNull(DocParse.parse("x.docx", z).pages.firstOrNull()?.visuals)
    }
    @Test fun docxChartAndDiagram() {
        val xml = "<w:document><w:body><w:p><c:chart r:id=\"rId3\"/></w:p></w:body></w:document>"
        val z = zip(mapOf("[Content_Types].xml" to "<Types/>", "word/document.xml" to xml,
            "word/_rels/document.xml.rels" to rels(Triple("rId3", "chart", "charts/chart1.xml"), Triple("rId4", "diagramDrawing", "diagrams/drawing1.xml")).replace("$REL/diagramDrawing", "http://schemas.microsoft.com/office/2007/relationships/diagramDrawing"),
            "word/charts/chart1.xml" to chartXml("barChart", listOf("A"), listOf("S" to listOf("7"))), "word/diagrams/drawing1.xml" to dsp(sp(0, 0, 10, 10, "Kutu"))))
        val v = DocParse.parse("x.docx", z).pages[0].visuals!!
        assertEquals(1, v.charts.size); assertEquals(1, v.diagrams.size); assertEquals("Kutu", v.diagrams[0].boxes[0].text)
    }
    @Test fun pptxPerSlide() {
        fun slide(r: String) = "<p:sld><a:p><a:r><a:t>t</a:t></a:r></a:p>$r</p:sld>"
        val z = zip(mapOf("[Content_Types].xml" to "<Types/>",
            "ppt/slides/slide1.xml" to slide("<a:blip r:embed=\"rId1\"/>"), "ppt/slides/slide2.xml" to slide("<c:chart r:id=\"rId1\"/>"), "ppt/slides/slide3.xml" to slide(""),
            "ppt/slides/_rels/slide1.xml.rels" to rels(Triple("rId1", "image", "../media/i.png")), "ppt/slides/_rels/slide2.xml.rels" to rels(Triple("rId1", "chart", "../charts/chart1.xml")),
            "ppt/charts/chart1.xml" to chartXml("pieChart", listOf("A", "B"), listOf("S" to listOf("1", "2")))))
        val d = DocParse.parse("x.pptx", z)
        assertEquals(3, d.pages.size); assertEquals(listOf("ppt/media/i.png"), d.pages[0].visuals!!.images); assertEquals(1, d.pages[1].visuals!!.charts.size); assertNull(d.pages[2].visuals)
    }
    @Test fun xlsxSheetDrawings() {
        val wb = "<workbook><sheets><sheet name=\"A\" r:id=\"rId1\"/><sheet name=\"B\" r:id=\"rId2\"/></sheets></workbook>"
        val z = zip(mapOf("[Content_Types].xml" to "<Types/>", "xl/workbook.xml" to wb,
            "xl/_rels/workbook.xml.rels" to rels(Triple("rId1", "worksheet", "worksheets/sheet1.xml"), Triple("rId2", "worksheet", "worksheets/sheet2.xml")),
            "xl/worksheets/sheet1.xml" to "<worksheet><sheetData><row r=\"1\"><c r=\"A1\" t=\"inlineStr\"><is><t>x</t></is></c></row></sheetData></worksheet>",
            "xl/worksheets/sheet2.xml" to "<worksheet><sheetData><row r=\"1\"><c r=\"A1\" t=\"inlineStr\"><is><t>y</t></is></c></row></sheetData></worksheet>",
            "xl/worksheets/_rels/sheet2.xml.rels" to rels(Triple("rId1", "drawing", "../drawings/drawing1.xml")),
            "xl/drawings/drawing1.xml" to "<xdr:wsDr><a:blip r:embed=\"rId1\"/><c:chart r:id=\"rId2\"/></xdr:wsDr>",
            "xl/drawings/_rels/drawing1.xml.rels" to rels(Triple("rId1", "image", "../media/p.png"), Triple("rId2", "chart", "../charts/chart1.xml")),
            "xl/charts/chart1.xml" to chartXml("lineChart", listOf("A", "B"), listOf("S" to listOf("1", "2")))))
        val d = DocParse.parse("x.xlsx", z)
        assertNull(d.pages[0].visuals); assertEquals(listOf("xl/media/p.png"), d.pages[1].visuals!!.images); assertEquals(1, d.pages[1].visuals!!.charts.size)
    }
    @Test fun odpPerPageAndOdsChart() {
        val content = "<office:document-content><office:body><office:presentation><draw:page draw:name=\"1\"><text:p>a</text:p><draw:frame><draw:image xlink:href=\"Pictures/1.png\"/></draw:frame></draw:page><draw:page draw:name=\"2\"><text:p>b</text:p><draw:frame><draw:object xlink:href=\"./Object 1\"/></draw:frame></draw:page></office:presentation></office:body></office:document-content>"
        val z = zip(mapOf("mimetype" to "application/vnd.oasis.opendocument.presentation", "content.xml" to content, "Object 1/content.xml" to odfChart("bar", listOf(listOf("A", "1")), listOf("", "S"))))
        val d = DocParse.parse("x.odp", z)
        assertEquals(2, d.pages.size); assertEquals(listOf("Pictures/1.png"), d.pages[0].visuals!!.images); assertEquals(1, d.pages[1].visuals!!.charts.size)
    }
    @Test fun odtImageOnlyDocumentGetsPage() {
        val content = "<office:document-content><office:body><office:text><text:p><draw:frame><draw:image xlink:href=\"Pictures/a.png\"/></draw:frame></text:p></office:text></office:body></office:document-content>"
        val d = DocParse.parse("x.odt", zip(mapOf("mimetype" to "application/vnd.oasis.opendocument.text", "content.xml" to content)))
        assertEquals(1, d.pages.size); assertEquals(listOf("Pictures/a.png"), d.pages[0].visuals!!.images)
    }
    @Test fun odfRemoteImagesIgnored() { val c = "<office:document-content><office:body><office:text><draw:image xlink:href=\"http://x/a.png\"/><text:p>t</text:p></office:text></office:body></office:document-content>"; assertNull(DocParse.parse("x.odt", zip(mapOf("mimetype" to "application/vnd.oasis.opendocument.text", "content.xml" to c))).pages[0].visuals) }
    @Test fun vsdxDiagramPerPage() {
        val z = zip(mapOf("[Content_Types].xml" to "<Types/>", "visio/pages/page1.xml" to "<PageContents><Shapes>${shape(1, 1.0, 1.0, 1.0, 1.0, "Düğüm")}</Shapes></PageContents>"))
        val d = DocParse.parse("x.vsdx", z)
        assertEquals(1, d.pages.size); assertEquals("Düğüm", d.pages[0].visuals!!.diagrams[0].boxes[0].text)
    }
    @Test fun documentWithoutVisualsUnchanged() { val b = DocWrite.docx(Doc(DocKind.DOCX, listOf(DocPage("", listOf("a"))))); assertNull(DocParse.parse("x.docx", b).pages[0].visuals) }
    @Test fun brokenRelsDoNotThrow() { val z = zip(mapOf("[Content_Types].xml" to "<Types/>", "word/document.xml" to "<w:document><w:p><a:blip r:embed=\"rId1\"/></w:p></w:document>", "word/_rels/document.xml.rels" to "<Relationships><Rel")); DocParse.parse("x.docx", z) }
    private fun unzipAll(b: ByteArray): Map<String, ByteArray> { val m = LinkedHashMap<String, ByteArray>(); java.util.zip.ZipInputStream(b.inputStream()).use { z -> while (true) { val e = z.nextEntry ?: break; m[e.name] = z.readBytes() } }; return m }

    // ---- görüntü satırları
    @Test fun flattenEmitsVisuals() {
        val v = Visuals(listOf("a.png"), listOf(DocChart("T", ChartKind.BAR, listOf("A"), listOf(ChartSeries("S", listOf(1.0))))), listOf(DocDiagram(1.0, 1.0, emptyList(), emptyList())))
        val l = DocParse.flatten(Doc(DocKind.DOCX, listOf(DocPage("", listOf("x"), null, v))), "") { _, _ -> "" }
        assertEquals(listOf(1, 3, 4, 5), l.map { it.kind }); assertEquals("a.png", l[1].img)
    }
    @Test fun imageOnlyPageStillShown() { val l = DocParse.flatten(Doc(DocKind.DOCX, listOf(DocPage("", emptyList(), null, Visuals(listOf("a.png"), emptyList(), emptyList())))), "") { _, _ -> "" }; assertEquals(1, l.size) }
    @Test fun searchHidesVisuals() { val l = DocParse.flatten(Doc(DocKind.DOCX, listOf(DocPage("", listOf("x"), null, Visuals(listOf("a.png"), emptyList(), emptyList())))), "x") { _, _ -> "" }; assertTrue(l.none { it.kind >= 3 }) }

    // ---- saf yardımcılar
    private fun ch(vararg s: List<Double?>) = DocChart("", ChartKind.BAR, List(s.maxOf { it.size }) { "c$it" }, s.mapIndexed { i, v -> ChartSeries("s$i", v) })
    @Test fun rangeIncludesZero() { assertEquals(0.0 to 10.0, DocVisual.range(ch(listOf(3.0, 10.0)))); assertEquals(-5.0 to 0.0 + 2.0, DocVisual.range(ch(listOf(-5.0, 2.0)))) }
    @Test fun rangeFlatOrEmpty() { assertEquals(0.0 to 1.0, DocVisual.range(ch(listOf(null, null)))); assertEquals(0.0 to 1.0, DocVisual.range(ch(listOf(0.0, 0.0)))) }
    @Test fun rangeIgnoresNonFinite() { assertEquals(0.0 to 4.0, DocVisual.range(ch(listOf(Double.NaN, 4.0, Double.POSITIVE_INFINITY)))) }
    @Test fun pieShares() { val s = DocVisual.pieShares(DocChart("", ChartKind.PIE, listOf("a", "b"), listOf(ChartSeries("s", listOf(1.0, 3.0))))); assertEquals(0.25, s[0], 1e-9); assertEquals(1.0, s.sum(), 1e-9) }
    @Test fun pieSharesDegenerate() { assertTrue(DocVisual.pieShares(DocChart("", ChartKind.PIE, listOf("a"), listOf(ChartSeries("s", listOf(0.0))))).isEmpty()); assertEquals(listOf(0.0, 1.0), DocVisual.pieShares(DocChart("", ChartKind.PIE, listOf("a", "b"), listOf(ChartSeries("s", listOf(-4.0, 2.0)))))) ; assertTrue(DocVisual.pieShares(DocChart("", ChartKind.PIE, emptyList(), emptyList())).isEmpty()) }
    @Test fun numFormat() { assertEquals("3", DocVisual.num(3.0)); assertEquals("2.5", DocVisual.num(2.5)); assertEquals("0.33", DocVisual.num(1.0 / 3)); assertEquals("-7", DocVisual.num(-7.0)); assertEquals("0.1", DocVisual.num(0.1)) }
    @Test fun aspect() { assertEquals(0.5, DocVisual.aspect(0.0, 5.0), 0.0); assertEquals(2.0, DocVisual.aspect(1.0, 2.0), 0.0) }
    @Test fun sampleSize() { assertEquals(1, VisualPure.sampleSize(1000, 800, 2048)); assertEquals(2, VisualPure.sampleSize(4000, 3000, 2048)); assertEquals(8, VisualPure.sampleSize(16000, 100, 2048)); assertEquals(1, VisualPure.sampleSize(2048, 1, 2048)) }

    // ---- ortam kaynakları
    @Test fun bytesMediaOpensEntry() { val z = zip(mapOf("a.xml" to "x", "word/media/p.png" to png)); val m = BytesMedia(z); assertEquals(4, m.open("word/media/p.png")!!.readBytes().size); assertNull(m.open("yok.png")) }
    @Test fun fileMediaOpensEntryAndSize() { val f = File.createTempFile("tst_m", ".zip"); f.deleteOnExit(); f.writeBytes(zip(mapOf("m/p.png" to png))); FileMedia(f).use { m -> assertEquals(4, m.open("m/p.png")!!.readBytes().size); assertEquals(4L, m.size("m/p.png")); assertNull(m.open("x")); assertEquals(-1L, m.size("x")) } }
    @Test fun fileMediaCloseCallback() { val f = File.createTempFile("tst_c", ".zip"); f.deleteOnExit(); f.writeBytes(zip(mapOf("a" to "b"))); var called = false; FileMedia(f) { called = true }.close(); assertTrue(called) }
    @Test fun mediaWithBigFileEndToEnd() {
        val f = File.createTempFile("tst_big", ".docx"); f.deleteOnExit()
        val src = unzipAll(DocWrite.docx(Doc(DocKind.DOCX, listOf(DocPage("", listOf("gövde"))))))
        java.util.zip.ZipOutputStream(f.outputStream().buffered()).use { z ->
            for ((k, v) in src) { if (k == "word/document.xml") { z.putNextEntry(ZipEntry(k)); z.write("<w:document><w:body><w:p><a:blip r:embed=\"rId1\"/><w:r><w:t>gövde</w:t></w:r></w:p></w:body></w:document>".toByteArray()) } else { z.putNextEntry(ZipEntry(k)); z.write(v) }; z.closeEntry() }
            z.putNextEntry(ZipEntry("word/_rels/document.xml.rels")); z.write(rels(Triple("rId1", "image", "media/big.png")).toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("word/media/big.png")); val c = ByteArray(1 shl 20); for (i in 0 until 64) z.write(c); z.closeEntry()
        }
        val d = DocParse.parseFile("x.docx", f)
        assertEquals(listOf("word/media/big.png"), d.pages[0].visuals!!.images)
        FileMedia(f).use { m -> assertEquals(64L * (1 shl 20), m.size("word/media/big.png")) }
    }

    // ---- kaynak denetimleri
    private fun code(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    @Test fun uiRendersAllVisualKinds() { val s = code("docs/DocActivity.kt"); assertTrue(s.contains("ImageBlock(s.media")); assertTrue(s.contains("ChartBlock(it)")); assertTrue(s.contains("DiagramBlock(it)")) }
    @Test fun mediaClosedWithScreen() { val s = code("docs/DocActivity.kt"); assertTrue(s.contains("(cur as? DocState.Text)?.close()")); assertTrue(s.contains("(cur as? DocState.Big)?.close()")) }
    @Test fun imageDecodingIsSampledAndGuarded() { val s = code("docs/DocVisualUi.kt"); assertTrue(s.contains("inSampleSize")); assertTrue(s.contains("OutOfMemoryError")); assertTrue(s.contains("Dispatchers.IO")) }
    @Test fun bigTextRoutesLargePlainText() { val s = code("docs/DocActivity.kt"); assertTrue(s.contains("DocState.Big(name, uri, size, pfd)")); assertTrue(s.contains("BigText.window")); assertTrue(s.contains("BigText.find")) }
    @Test fun newStringsEverywhere() { for ((lang, f) in TestFiles.stringFiles()) { val m = TestFiles.parseStrings(f); for (k in listOf("doc_img_unsupported", "doc_bigtext", "doc_big_nf")) assertTrue("$lang $k", (m[k] ?: "").isNotBlank()) } }
}
