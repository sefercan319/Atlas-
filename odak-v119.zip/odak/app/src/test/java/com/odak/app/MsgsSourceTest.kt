package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Özel bildirim metinleri: her tür kullanıldığı yerde bağlı ve tüm dillerde etiketi var. */
class MsgsSourceTest {
    private fun src(rel: String) = File(TestFiles.main, "java/com/odak/app/$rel").readText()
    private val kinds = listOf("remind", "morning", "evening", "week", "warn", "limit", "focus", "pomo", "toast")

    @Test fun everyKindIsUsedSomewhere() {
        val all = listOf("notify/Reminders.kt", "block/OdakAccessibilityService.kt", "block/BlockScreen.kt", "todo/Pomodoro.kt")
            .joinToString("\n") { src(it) }
        for (k in kinds) assertTrue("bağlı değil: $k", all.contains("Msgs.text(") && all.contains("\"$k\""))
    }

    @Test fun everyKindHasLabelInAllLanguages() {
        val res = File(TestFiles.main, "res")
        val dirs = res.listFiles { f -> f.name.startsWith("values") }!!
        assertTrue(dirs.size >= 9)
        for (d in dirs) {
            val t = File(d, "strings.xml").readText()
            for (k in kinds) assertTrue("${d.name}: msg_k_$k", t.contains("name=\"msg_k_$k\""))
            assertTrue(t.contains("name=\"msg_title\""))
        }
    }
}
