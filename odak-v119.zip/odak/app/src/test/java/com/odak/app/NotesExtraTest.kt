package com.odak.app

import com.odak.app.notes.Note
import com.odak.app.notes.NotePure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.31: Notlarda renk filtresi ve okuma süresi. */
class NotesExtraTest {
    @Test fun readMinutes() {
        assertEquals(0, NotePure.readMinutes(""))
        assertEquals(1, NotePure.readMinutes("bir iki"))
        assertEquals(1, NotePure.readMinutes(List(200) { "a" }.joinToString(" ")))
        assertEquals(2, NotePure.readMinutes(List(201) { "a" }.joinToString(" ")))
    }

    @Test fun colorFilter() {
        val l = listOf(Note(id = "1", color = 5), Note(id = "2", color = 7), Note(id = "3", color = 5), Note(id = "4"))
        assertEquals(4, NotePure.byColor(l, 0).size)
        assertEquals(listOf("1", "3"), NotePure.byColor(l, 5).map { it.id })
        assertEquals(0, NotePure.byColor(l, 9).size)
    }

    @Test fun colorsUsedSkipsNoneAndTrash() {
        val l = listOf(Note(color = 5), Note(color = 7, trashedAt = 1L), Note(color = 5), Note(color = 0), Note(color = 9))
        assertEquals(listOf(5, 9), NotePure.colorsUsed(l))
    }

    @Test fun staleColorFilterClears() {
        assertEquals(5, NotePure.activeColor(listOf(5, 9), 5))
        assertEquals(0, NotePure.activeColor(listOf(9), 5)); assertEquals(0, NotePure.activeColor(emptyList(), 5)); assertEquals(0, NotePure.activeColor(listOf(5), 0))
        val src = File(TestFiles.code, "com/odak/app/notes/NotesList.kt").readText()
        assertTrue(src.contains("NotePure.activeColor(used, colorFilter)") && src.contains("NotePure.byColor(NotePure.visible(notes, folder, trash, query), activeColor)"))
    }

    @Test fun uiWiredAndTranslated() {
        val list = File(TestFiles.code, "com/odak/app/notes/NotesList.kt").readText()
        assertTrue(list.contains("NotePure.byColor(") && list.contains("NotePure.colorsUsed(notes)"))
        assertTrue(File(TestFiles.code, "com/odak/app/notes/NoteEditor.kt").readText().contains("NotePure.readMinutes(body)"))
        for (d in TestFiles.res.listFiles { f -> f.isDirectory && f.name.startsWith("values") }!!) {
            val f = File(d, "strings.xml"); if (f.exists()) assertTrue(d.name, f.readText().contains("name=\"notes_read_min\""))
        }
    }
}
