package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Belge okuyucu bağlantıları: manifest, ayarlar kartı, dil dosyaları. */
class DocUiSourceTest {
    private val manifest = File(TestFiles.main, "AndroidManifest.xml").readText()
    private fun src(rel: String) = File(TestFiles.code, "com/odak/app/$rel").readText()
    private val keys = listOf("doc_title", "doc_open", "doc_recent", "doc_search", "doc_approx", "doc_external", "doc_cant",
        "doc_error", "doc_toobig", "doc_google", "doc_open_link", "doc_page", "doc_slide", "doc_empty", "doc_hint", "doc_pdf_error")

    @Test fun activityDeclaredWithViewFilter() {
        val i = manifest.indexOf("android:name=\".docs.DocActivity\"")
        assertTrue(i > 0)
        val end = manifest.indexOf("</activity>", i)
        val tag = manifest.substring(i, end)
        assertTrue(tag.contains("android.intent.action.VIEW"))
        assertTrue(tag.contains("android:exported=\"true\""))
        assertTrue(tag.contains("density"))
    }
    @Test fun viewFilterCoversMainOfficeTypes() {
        for (m in listOf("application/pdf", "wordprocessingml.document", "spreadsheetml.sheet", "presentationml.presentation",
            "opendocument.text", "opendocument.spreadsheet", "opendocument.presentation", "application/rtf", "application/msword"))
            assertTrue(m, manifest.contains(m))
    }
    @Test fun docsReachedThroughNotesHub() {
        // v0.54: belgeler artık Not defteri ekranındaki ikinci sekmeden açılır (Ayarlar → Not defteri → Belgeler).
        assertTrue(src("settings/SettingsScreen.kt").contains("NotesCard()"))
        assertTrue(src("notes/NotesActivity.kt").contains("DocsCard()"))
        assertTrue(src("settings/MoreCards.kt").contains("DocActivity::class.java"))
    }
    @Test fun allDocStringsExistInAllLanguages() {
        for ((n, f) in TestFiles.stringFiles()) {
            val t = f.readText()
            for (k in keys) assertTrue("$n: $k", t.contains("name=\"$k\""))
        }
    }
    @Test fun pageAndSlideStringsTakeNumber() {
        for ((n, f) in TestFiles.stringFiles()) {
            val t = f.readText()
            for (k in listOf("doc_page", "doc_slide")) {
                val line = Regex("name=\"$k\">([^<]*)<").find(t)!!.groupValues[1]
                assertTrue("$n $k: $line", line.contains("%1\$d"))
            }
        }
    }
    @Test fun pdfUsesAndroidRenderer() {
        val t = src("docs/DocActivity.kt")
        assertTrue(t.contains("PdfRenderer"))
        assertTrue(t.contains("synchronized(r)"))   // PdfRenderer aynı anda tek sayfa açar
        assertTrue(t.contains("close()"))
    }
    @Test fun googleLinksAreValidatedBeforeOpening() {
        assertTrue(src("docs/DocParse.kt").contains("safeGoogleUrl"))
    }
    @Test fun parserIsFreeOfAndroidDependencies() {
        assertTrue(!src("docs/DocParse.kt").contains("import android."))
    }
}
