package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Günlük süre sınırı satırı: sınır uyarısı (saf mantık + kaynak denetimi). */
class LimitRowTest {
    private val min = 60_000L

    @Test fun reachedExactlyAtLimit() {
        assertTrue(Pure.limitReached(30 * min, 30))
        assertTrue(Pure.limitReached(31 * min, 30))
    }

    @Test fun notReachedBelowLimit() {
        assertFalse(Pure.limitReached(29 * min, 30))
    }

    @Test fun zeroMeansUnlimitedNeverReached() {
        assertFalse(Pure.limitReached(999 * min, 0))
    }

    @Test fun limitRowShowsWarningWithoutColorAlone() {
        val s = File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()
        val row = s.substringAfter("private fun LimitRow").substringBefore("/** − 30 dk + */")
        assertTrue(row.contains("Pure.limitReached(usedMin * 60_000L, minutes)"))
        assertTrue(row.contains("\"✖ \""))
        assertTrue(row.contains("MaterialTheme.colorScheme.error"))
        assertTrue(row.contains("minutes > 0 &&"))
    }
}
