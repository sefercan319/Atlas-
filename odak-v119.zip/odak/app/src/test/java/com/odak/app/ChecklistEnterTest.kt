package com.odak.app

import com.odak.app.notes.NotePure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Yapılacaklar: Enter ile sonraki madde, boş maddede listeyi bitirme, diğer değişikliklere dokunmama. */
class ChecklistEnterTest {
    @Test fun enterAfterItemStartsNextUncheckedItem() {
        assertEquals("[ ] a\n[ ] ", NotePure.enterInList("[ ] a", "[ ] a\n"))
    }

    @Test fun enterAfterCheckedItemStartsUncheckedItem() {
        assertEquals("[x] bitti\n[ ] ", NotePure.enterInList("[x] bitti", "[x] bitti\n"))
    }

    @Test fun enterOnPlainLineIsUnchanged() {
        assertEquals("düz\n", NotePure.enterInList("düz", "düz\n"))
    }

    @Test fun enterOnEmptyItemEndsList() {
        assertEquals("x\n", NotePure.enterInList("x\n[ ] ", "x\n[ ] \n"))
    }

    @Test fun enterInsideItemMovesTailToNewItem() {
        assertEquals("[ ] a\n[ ] b", NotePure.enterInList("[ ] ab", "[ ] a\nb"))
    }

    @Test fun enterOnFirstLineWorks() {
        assertEquals("\n", NotePure.enterInList("", "\n"))
    }

    @Test fun typingAndPastingAreUnchanged() {
        assertEquals("[ ] abc", NotePure.enterInList("[ ] ab", "[ ] abc"))
        assertEquals("[ ] a\nb\nc", NotePure.enterInList("[ ] a", "[ ] a\nb\nc"))
    }

    @Test fun editorUsesEnterRule() {
        val s = File(TestFiles.code, "com/odak/app/notes/NoteEditor.kt").readText()
        assertTrue(s.contains("onValueChange = { body = NotePure.enterInList(body, it).take(100_000) }"))
    }
}
