package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.52: yeni özellikler için tablo tabanlı testler (beklenen değerler bağımsız Python hesabından). */
class BackupGenTest {
    @Test fun bFile_0() { assertTrue(Pure.backupFileAllowed("odak_plan")) }
    @Test fun bFile_1() { assertTrue(Pure.backupFileAllowed("odak_todo")) }
    @Test fun bFile_2() { assertTrue(Pure.backupFileAllowed("odak_habits")) }
    @Test fun bFile_3() { assertTrue(Pure.backupFileAllowed("odak_block")) }
    @Test fun bFile_4() { assertTrue(Pure.backupFileAllowed("odak_app")) }
    @Test fun bFile_5() { assertTrue(Pure.backupFileAllowed("odak_colors")) }
    @Test fun bFile_6() { assertFalse(Pure.backupFileAllowed("odak_pin")) }
    @Test fun bFile_7() { assertFalse(Pure.backupFileAllowed("")) }
    @Test fun bFile_8() { assertFalse(Pure.backupFileAllowed("ODAK_PLAN")) }
    @Test fun bFile_9() { assertFalse(Pure.backupFileAllowed("odak_plan ")) }
    @Test fun bFile_10() { assertFalse(Pure.backupFileAllowed("../odak_plan")) }
    @Test fun bFile_11() { assertFalse(Pure.backupFileAllowed("odak_other")) }
    @Test fun bFile_12() { assertFalse(Pure.backupFileAllowed("random")) }
    @Test fun jArr_13() { assertTrue(Pure.looksLikeJsonArray("[]")) }
    @Test fun jArr_14() { assertTrue(Pure.looksLikeJsonArray("[1]")) }
    @Test fun jArr_15() { assertTrue(Pure.looksLikeJsonArray(" [1,2] ")) }
    @Test fun jArr_16() { assertFalse(Pure.looksLikeJsonArray("[")) }
    @Test fun jArr_17() { assertFalse(Pure.looksLikeJsonArray("]")) }
    @Test fun jArr_18() { assertFalse(Pure.looksLikeJsonArray("")) }
    @Test fun jArr_19() { assertFalse(Pure.looksLikeJsonArray("{}")) }
    @Test fun jArr_20() { assertFalse(Pure.looksLikeJsonArray("[}")) }
    @Test fun jArr_21() { assertFalse(Pure.looksLikeJsonArray("a[]")) }
    @Test fun jArr_22() { assertFalse(Pure.looksLikeJsonArray("[]a")) }
    @Test fun jArr_23() { assertTrue(Pure.looksLikeJsonArray("\n[ ]\n")) }
    @Test fun jArr_24() { assertTrue(Pure.looksLikeJsonArray("[[]]")) }
}
