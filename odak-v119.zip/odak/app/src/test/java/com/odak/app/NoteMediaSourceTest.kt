package com.odak.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.55: ekler (resim/ses/PDF/paylaşım/basınç) için kaynak ve manifest denetimleri. */
class NoteMediaSourceTest {
    private fun code(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    private val manifest get() = File(TestFiles.main, "AndroidManifest.xml").readText()

    @Test fun micPermissionDeclared() { assertTrue(manifest.contains("android.permission.RECORD_AUDIO")) }
    @Test fun fileProviderDeclaredNotExported() { val m = manifest; assertTrue(m.contains("androidx.core.content.FileProvider")); assertTrue(m.contains("android:exported=\"false\"")); assertTrue(m.contains("grantUriPermissions=\"true\"")) }
    @Test fun providerAuthorityMatchesCode() { assertTrue(manifest.contains("\${applicationId}.files")); assertTrue(code("notes/NoteMedia.kt").contains("c.packageName + \".files\"")) }
    @Test fun filePathsShareOnly() { val x = File(TestFiles.res, "xml/file_paths.xml").readText(); assertTrue(x.contains("cache-path")); assertFalse(x.contains("root-path")); assertFalse(x.contains("external")) }
    @Test fun mediaFilesGoThroughSafeName() { val s = code("notes/NoteMedia.kt"); assertTrue(s.contains("fun file(c: Context, sub: String, name: String): File? = if (NotePure.safeFile(name))")) }
    @Test fun stylusPressureOnlyFromStylus() { val s = code("notes/NoteEditor.kt"); assertTrue(s.contains("PointerType.Stylus")); assertTrue(s.contains("if (stylus) c.pressure")) }
    @Test fun exportHandlesPressureAndPdfPages() { val s = code("notes/NoteMedia.kt"); assertTrue(s.contains("NotePure.pressW")); assertTrue(s.contains("PdfDocument")); assertTrue(s.contains("strokesOfPage")) }
    @Test fun importsAreDownscaled() { assertTrue(code("notes/NoteMedia.kt").contains("MAX_IMG_PX")); assertTrue(code("notes/NoteMedia.kt").contains("fitSize")) }
    @Test fun pdfImportIsCappedAndValidated() { val s = code("notes/NoteMedia.kt"); assertTrue(s.contains("MAX_PDF_BYTES")); assertTrue(s.contains("pageCount > 0")) }
    @Test fun heavyWorkOffMainThread() { assertTrue(code("notes/NotesList.kt").contains("Dispatchers.IO")); assertTrue(code("notes/NoteEditor.kt").contains("Dispatchers.IO")) }
    @Test fun permanentDeleteRemovesMedia() { val s = code("notes/NoteStore.kt"); assertTrue(s.contains("NoteMedia.deleteFiles")) }
    @Test fun editorReleasesRecorderAndPlayer() { val s = code("notes/NoteEditor.kt"); assertTrue(s.contains("player.stop()")); assertTrue(s.contains("recorder.stop()")) }
    @Test fun recordingCappedOneHour() { assertTrue(code("notes/NoteEditor.kt").contains("3_600_000L")) }
    @Test fun pdfButtonInList() { assertTrue(code("notes/NotesList.kt").contains("OpenDocument")) }
    @Test fun allNewStringsInEveryLanguage() {
        val keys = listOf("notes_add_image", "notes_image_big", "notes_image_small", "notes_image_del", "notes_rec_start", "notes_rec_stop", "notes_rec_denied", "notes_audio_play", "notes_audio_stop", "notes_audio_del", "notes_share_image", "notes_share_pdf", "notes_pdf_open", "notes_pdf_err", "notes_audio_title", "notes_image_err", "notes_share_err")
        for ((lang, f) in TestFiles.stringFiles()) { val m = TestFiles.parseStrings(f); for (k in keys) assertTrue("$lang eksik: $k", m.containsKey(k)) }
    }
}
