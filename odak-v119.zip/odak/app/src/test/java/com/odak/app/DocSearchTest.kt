package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Belge araması: Türkçe harf toleransı, eşleşme konumları, sayaç ve vurgu bağlantısı. */
class DocSearchTest {
    @Test fun blankQueryHasNoMatches() {
        assertEquals(emptyList<Int>(), Pure.matchStarts("Merhaba", "  "))
    }

    @Test fun findsEveryNonOverlappingOccurrence() {
        assertEquals(listOf(0, 3), Pure.matchStarts("abcabc", "abc"))
        assertEquals(listOf(0), Pure.matchStarts("aaa", "aa"))
    }

    @Test fun caseInsensitive() {
        assertEquals(listOf(0), Pure.matchStarts("RAPOR", "rap"))
    }

    @Test fun turkishDotlessIAndAccentsMatch() {
        assertEquals(listOf(0), Pure.matchStarts("Işık raporu", "isik"))
        assertEquals(listOf(5), Pure.matchStarts("Yeni Çiçek", "cicek"))
        assertEquals(listOf(0), Pure.matchStarts("ışık", "IŞIK"))
    }

    @Test fun uppercaseDottedIMatchesLowercaseI() {
        assertEquals(listOf(0), Pure.matchStarts("İstanbul", "istanbul"))
    }

    @Test fun queryNotFoundGivesEmpty() {
        assertEquals(emptyList<Int>(), Pure.matchStarts("Merhaba dünya", "elma"))
    }

    @Test fun docParseUsesSharedMatcher() {
        val s = File(TestFiles.code, "com/odak/app/docs/DocParse.kt").readText()
        assertTrue(s.contains("Pure.matchStarts(t, q).isNotEmpty()"))
        assertTrue(s.contains("Pure.matchStarts(it, q).isNotEmpty()"))
        assertTrue(!s.contains("t.contains(q, ignoreCase = true)"))
    }

    @Test fun viewShowsCountAndHighlight() {
        val s = File(TestFiles.code, "com/odak/app/docs/DocActivity.kt").readText()
        assertTrue(s.contains("R.string.doc_hits, hits"))
        assertTrue(s.contains("val hits = lines.count { it.kind == 1 || it.kind == 2 }"))
        assertTrue(s.contains("highlight(l.text, query)"))
        assertTrue(s.contains("background = Color(0xFFFFE082), color = Color(0xFF111111)"))
    }

    @Test fun countStringExistsInEveryLocale() {
        for (d in listOf("values", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az", "values-tr")) {
            assertTrue(d, File(TestFiles.res, "$d/strings.xml").readText().contains("name=\"doc_hits\">"))
        }
    }
}
