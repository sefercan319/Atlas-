package com.odak.app

import com.odak.app.notes.Note
import com.odak.app.notes.NoteAudio
import com.odak.app.notes.NoteImg
import com.odak.app.notes.NotePure
import com.odak.app.notes.Pt
import com.odak.app.notes.Stroke
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.55: kalem basıncı, resim, ses kaydı, PDF üstüne yazma — saf mantık ve kodlama. */
class NoteMediaTest {
    @Test fun pressureRoundTrip() {
        val n = Note(id = "a", strokes = listOf(Stroke(0, 0, 4f, listOf(Pt(0.1f, 0.1f, 0.25f), Pt(0.2f, 0.2f, 1f), Pt(0.3f, 0.3f, 0.8f)))))
        val b = NotePure.decode(NotePure.encode(n))!!
        assertEquals(0.25f, b.strokes[0].pts[0].p, 0.001f); assertEquals(1f, b.strokes[0].pts[1].p, 0.001f); assertEquals(0.8f, b.strokes[0].pts[2].p, 0.001f)
    }
    @Test fun fullPressureNotWrittenKeepsFileSmall() { val e = NotePure.encode(Note(id = "a", strokes = listOf(Stroke(0, 0, 4f, listOf(Pt(0.1f, 0.2f)))))); assertTrue(e.contains(" 0.1,0.2\n")) }
    @Test fun oldFilesWithoutPressureStillLoad() { assertEquals(1f, NotePure.decode("ODN1\nS 0 0 4 0.1,0.2")!!.strokes[0].pts[0].p, 0.001f) }
    @Test fun badPressureSkipped() { assertEquals(0, NotePure.decode("ODN1\nS 0 0 4 0.1,0.2,abc")!!.strokes.size) }
    @Test fun pressureClamped() { assertEquals(1f, NotePure.decode("ODN1\nS 0 0 4 0.1,0.2,7")!!.strokes[0].pts[0].p, 0.001f) }
    @Test fun pressWBounds() { assertEquals(0.35f, NotePure.pressW(1f, 0f), 0.001f); assertEquals(1f, NotePure.pressW(1f, 1f), 0.001f); assertEquals(1f, NotePure.pressW(1f, 5f), 0.001f); assertEquals(0.35f, NotePure.pressW(1f, -3f), 0.001f) }
    @Test fun pressWMonotonic() { var last = 0f; for (i in 0..20) { val w = NotePure.pressW(4f, i / 20f); assertTrue(w >= last); last = w } }
    @Test fun avgPressure() { assertEquals(0.5f, NotePure.avgPressure(listOf(Pt(0f, 0f, 0f), Pt(0f, 0f, 1f))), 0.001f); assertEquals(1f, NotePure.avgPressure(emptyList()), 0.001f) }

    @Test fun safeFileRules() {
        for (ok in listOf("a.jpg", "img_1-2.png", "A1.m4a")) assertTrue(ok, NotePure.safeFile(ok))
        for (bad in listOf("", ".hidden", "../x", "a/b", "a\\b", "a b", "ğ.jpg", "a..b", "x".repeat(101), "a\n.jpg")) assertFalse(bad, NotePure.safeFile(bad))
    }
    @Test fun unsafeMediaNamesDroppedOnDecode() {
        val n = NotePure.decode("ODN1\nI ../../etc/passwd 0.1 0.1 0.5 1\nA /sdcard/x.m4a 100 5\npdf=../../x.pdf\nI ok.jpg 0.1 0.1 0.5 1")!!
        assertEquals(listOf("ok.jpg"), n.images.map { it.file }); assertEquals(0, n.audios.size); assertEquals("", n.pdf)
    }
    @Test fun unsafeMediaNamesDroppedOnEncode() { val e = NotePure.encode(Note(id = "a", pdf = "../x.pdf", images = listOf(NoteImg("../x", 0f, 0f, 0.5f, 1f)), audios = listOf(NoteAudio("a/b", 1, 1)))); assertFalse(e.contains("..")); assertFalse(e.contains("pdf=")) }
    @Test fun mediaRoundTrip() {
        val n = Note(id = "a", pdf = "doc1.pdf", images = listOf(NoteImg("i1.jpg", 0.1f, 0.5f, 0.4f, 0.75f)), audios = listOf(NoteAudio("s1.m4a", 12_345L, 99L)))
        val b = NotePure.decode(NotePure.encode(n))!!
        assertEquals("doc1.pdf", b.pdf); assertEquals(1, b.images.size); assertEquals(0.75f, b.images[0].a, 0.001f); assertEquals(12_345L, b.audios[0].durMs); assertEquals(99L, b.audios[0].at)
    }
    @Test fun mediaCountCapped() { val sb = StringBuilder("ODN1\n"); repeat(100) { sb.append("I i$it.jpg 0.1 0.1 0.5 1\nA a$it.m4a 1 1\n") }; val n = NotePure.decode(sb.toString())!!; assertEquals(NotePure.MAX_MEDIA, n.images.size); assertEquals(NotePure.MAX_MEDIA, n.audios.size) }
    @Test fun badImageNumbersSkipped() { assertEquals(0, NotePure.decode("ODN1\nI a.jpg NaN 0 0.5 1\nI b.jpg x 0 0.5 1\nI c.jpg 0 0 0.5")!!.images.size) }
    @Test fun imageValuesClamped() { val i = NotePure.decode("ODN1\nI a.jpg 5 -3 9 0")!!.images[0]; assertEquals(1f, i.x, 0.001f); assertEquals(0f, i.y, 0.001f); assertEquals(1f, i.w, 0.001f); assertEquals(0.05f, i.a, 0.001f) }

    private val im = NoteImg("a.jpg", 0.2f, 0.3f, 0.4f, 0.5f)
    @Test fun imgBottomAndHit() { assertEquals(0.5f, NotePure.imgBottom(im), 0.001f); assertTrue(NotePure.imgHit(im, 0.3f, 0.4f)); assertFalse(NotePure.imgHit(im, 0.1f, 0.4f)); assertFalse(NotePure.imgHit(im, 0.3f, 0.6f)) }
    @Test fun imgAtTopMostWins() { val l = listOf(im, im.copy(file = "b.jpg")); assertEquals(1, NotePure.imgAt(l, 0.3f, 0.4f)); assertEquals(-1, NotePure.imgAt(l, 0.9f, 0.9f)) }
    @Test fun moveImgClamps() { val m = NotePure.moveImg(im, 5f, -9f); assertEquals(0.6f, m.x, 0.001f); assertEquals(0f, m.y, 0.001f); assertEquals(0f, NotePure.moveImg(im, -5f, 0f).x, 0.001f) }
    @Test fun scaleImgClamps() { assertEquals(0.1f, NotePure.scaleImg(im, 0.01f).w, 0.001f); val big = NotePure.scaleImg(im, 9f); assertEquals(1f, big.w, 0.001f); assertEquals(0f, big.x, 0.001f) }
    @Test fun scaleImgKeepsInsidePage() { val r = NotePure.scaleImg(im.copy(x = 0.7f, w = 0.3f), 2f); assertTrue(r.x + r.w <= 1.0001f) }
    @Test fun fitSizeCases() {
        assertEquals(100 to 50, NotePure.fitSize(100, 50, 200)); assertEquals(200 to 100, NotePure.fitSize(4000, 2000, 200)); assertEquals(100 to 200, NotePure.fitSize(2000, 4000, 200)); assertEquals(1 to 1, NotePure.fitSize(0, 5, 10))
        val (w, h) = NotePure.fitSize(10000, 1, 100); assertEquals(100, w); assertEquals(1, h)
    }
    @Test fun pageHeightIncludesImages() { assertEquals(3.6f, NotePure.pageHeight(emptyList(), listOf(NoteImg("a.jpg", 0f, 2f, 1f, 1f))), 0.001f); assertEquals(1.4f, NotePure.pageHeight(emptyList(), emptyList()), 0.001f) }

    @Test fun fmtDurForms() { assertEquals("0:00", NotePure.fmtDur(0)); assertEquals("0:09", NotePure.fmtDur(9_999)); assertEquals("1:05", NotePure.fmtDur(65_000)); assertEquals("61:01", NotePure.fmtDur(3_661_000)); assertEquals("0:00", NotePure.fmtDur(-5)) }

    @Test fun pdfTopsAndTotal() {
        val a = listOf(1.4f, 1.0f, 1.5f); val t = NotePure.pdfTops(a)
        assertEquals(0f, t[0], 0.0001f); assertEquals(1.42f, t[1], 0.0001f); assertEquals(2.44f, t[2], 0.0001f); assertEquals(3.94f, NotePure.pdfTotal(a), 0.0001f); assertEquals(0f, NotePure.pdfTotal(emptyList()), 0f)
    }
    @Test fun pdfPageAtBoundaries() { val t = NotePure.pdfTops(listOf(1f, 1f, 1f)); assertEquals(0, NotePure.pdfPageAt(t, -1f)); assertEquals(0, NotePure.pdfPageAt(t, 0.5f)); assertEquals(0, NotePure.pdfPageAt(t, 1.01f)); assertEquals(1, NotePure.pdfPageAt(t, 1.02f)); assertEquals(2, NotePure.pdfPageAt(t, 99f)) }
    @Test fun strokesGroupedByPage() {
        val t = NotePure.pdfTops(listOf(1f, 1f)); val s0 = Stroke(0, 0, 4f, listOf(Pt(0.1f, 0.5f))); val s1 = Stroke(0, 0, 4f, listOf(Pt(0.1f, 1.5f)))
        assertEquals(listOf(s0), NotePure.strokesOfPage(t, listOf(s0, s1), 0)); assertEquals(listOf(s1), NotePure.strokesOfPage(t, listOf(s0, s1), 1))
    }
    @Test fun strokePageEmpty() { assertEquals(0, NotePure.strokePage(emptyList(), Stroke(0, 0, 4f, emptyList()))) }
}
