package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** v0.56.42: HTML→biçimli çevirici, e-kitap resimleri, MOBI Huffman, Markdown resmi, Excel tarih/sayı biçimi. */
class DocRich3Test {
    private val PNG = Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
    private val PNG64 = Base64.getEncoder().encodeToString(PNG)
    private fun zipB(vararg e: Pair<String, ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bo.toByteArray()
    }
    private fun zipS(vararg e: Pair<String, String>) = zipB(*e.map { it.first to it.second.toByteArray() }.toTypedArray())
    private fun imgs(bl: List<RBlock>): List<RImg> = bl.flatMap { b -> when (b) { is RPara -> b.runs.mapNotNull { it.img }; is RTable -> b.rows.flatten().flatMap { c -> c.paras.flatMap { p -> p.runs.mapNotNull { it.img } } }; is RBox -> imgs(b.blocks) } }
    private fun paras(bl: List<RBlock>) = bl.filterIsInstance<RPara>()

    // ---- HtmlRich ----
    @Test fun htmlInlineAndHeadings() {
        val b = paras(HtmlRich.parse("<h1>Başlık</h1><p>Düz <b>kalın</b> <i>italik</i> <a href=\"http://x.io\">link</a><br/>yeni satır</p>"))
        assertEquals(1, b[0].head); assertTrue(b[0].runs.all { it.b })
        val r = b[1].runs
        assertTrue(r.any { it.text.contains("kalın") && it.b }); assertTrue(r.any { it.text.contains("italik") && it.i })
        assertTrue(r.any { it.href == "http://x.io" })
        assertTrue(b[1].plain.contains("yeni satır"))
    }
    @Test fun htmlStyleAttr() {
        val p = paras(HtmlRich.parse("<p style=\"text-align:center\"><span style=\"color:#ff0000;font-weight:bold;font-size:20pt\">K</span></p>"))[0]
        assertEquals("center", p.align)
        val r = p.runs[0]; assertEquals("FF0000", r.color); assertTrue(r.b); assertEquals(40, r.sz)
    }
    @Test fun htmlLists() {
        val b = paras(HtmlRich.parse("<ul><li>bir</li><li>iki</li></ul><ol><li>a</li><li>b</li></ol>"))
        assertEquals(listOf("•", "•", "1.", "2."), b.map { it.marker })
    }
    @Test fun htmlTable() {
        val t = HtmlRich.parse("<table><tr><th>A</th><th>B</th></tr><tr><td>1</td><td colspan=\"1\">2</td></tr></table><p>son</p>").filterIsInstance<RTable>().single()
        assertEquals(2, t.rows.size); assertEquals(2, t.rows[0].size)
        assertEquals("A", t.rows[0][0].paras[0].plain); assertTrue(t.rows[0][0].paras[0].runs[0].b)
        assertEquals("2", t.rows[1][1].paras[0].plain)
    }
    @Test fun htmlImagesAndSkips() {
        val bl = HtmlRich.parse("<head><title>x</title><style>p{}</style></head><body><p>a<img src=\"data:image/png;base64,$PNG64\" alt=\"i\"/></p><script>var x=1</script></body>", { s -> HtmlRich.dataUri(s)?.let { HtmlRich.image(it) } })
        assertEquals(1, imgs(bl).size); assertEquals("image/png", imgs(bl)[0].mime)
        assertFalse(paras(bl).joinToString { it.plain }.contains("var x"))
        val alt = paras(HtmlRich.parse("<p><img src=\"yok.png\" alt=\"Resim adı\"/></p>"))[0].plain
        assertEquals("[Resim adı]", alt)
    }
    @Test fun htmlEntitiesPreAndQuote() {
        val b = paras(HtmlRich.parse("<p>a &amp; b &lt;c&gt;</p><pre>x  y\nz</pre><blockquote>alıntı</blockquote>"))
        assertEquals("a & b <c>", b[0].plain)
        assertTrue(b[1].plain.contains("x  y")); assertTrue(b.last().left > 0)
    }

    // ---- EPUB ----
    private fun epub(): ByteArray = zipS(
        "mimetype" to "application/epub+zip",
        "META-INF/container.xml" to "<container><rootfiles><rootfile full-path=\"OEBPS/content.opf\"/></rootfiles></container>",
        "OEBPS/content.opf" to "<package><manifest><item id=\"c1\" href=\"ch1.xhtml\"/><item id=\"i\" href=\"img/a%20b.png\"/></manifest><spine><itemref idref=\"c1\"/></spine></package>",
        "OEBPS/ch1.xhtml" to "<html><body><h1>Bölüm</h1><p>Metin <b>kalın</b></p><p><img src=\"img/a%20b.png\"/></p></body></html>"
    ).let { base ->
        // resim ikili olduğundan ayrıca ekle
        zipB("mimetype" to "application/epub+zip".toByteArray(),
            "META-INF/container.xml" to "<container><rootfiles><rootfile full-path=\"OEBPS/content.opf\"/></rootfiles></container>".toByteArray(),
            "OEBPS/content.opf" to "<package><manifest><item id=\"c1\" href=\"ch1.xhtml\"/></manifest><spine><itemref idref=\"c1\"/></spine></package>".toByteArray(),
            "OEBPS/ch1.xhtml" to "<html><body><h1>Bölüm</h1><p>Metin <b>kalın</b></p><p><img src=\"img/a%20b.png\"/></p></body></html>".toByteArray(),
            "OEBPS/img/a b.png" to PNG)
    }
    @Test fun epubRichWithImage() {
        val d = DocParse.parse("k.epub", epub())
        assertEquals(DocKind.EPUB, d.kind)
        val rp = d.pages[0].rich
        assertNotNull(rp)
        assertEquals(1, imgs(rp!!.blocks).size)
        assertEquals(1, paras(rp.blocks)[0].head)
        assertTrue(paras(rp.blocks).any { p -> p.runs.any { it.b && it.text.contains("kalın") } })
    }
    @Test fun epubToDocxAndEpubKeepsImage() {
        val d = DocParse.parse("k.epub", epub())
        val docx = DocParse.parse("o.docx", DocWrite.write(d, ConvTarget.DOCX, "k")!!)
        assertEquals(1, imgs(docx.pages[0].rich!!.blocks).size)
        val fb = DocParse.parse("o.fb2", DocWrite.write(d, ConvTarget.FB2, "k")!!)
        assertEquals(DocKind.FB2, fb.kind)
        val e2 = DocParse.parse("o.epub", DocWrite.write(d, ConvTarget.ODT, "k")!!)
        assertEquals(1, imgs(e2.pages[0].rich!!.blocks).size)
    }

    // ---- FB2 ----
    @Test fun fb2WithBinaryImage() {
        val x = "<?xml version=\"1.0\" encoding=\"utf-8\"?><FictionBook xmlns:l=\"http://www.w3.org/1999/xlink\"><description><title-info><book-title>Kitap</book-title></title-info></description>" +
            "<body><section><title><p>Bir</p></title><p>Merhaba <emphasis>dünya</emphasis></p><image l:href=\"#a.png\"/></section><section><title><p>İki</p></title><p>Son</p></section></body>" +
            "<binary id=\"a.png\" content-type=\"image/png\">$PNG64</binary></FictionBook>"
        val d = DocMore.fb2Doc(x.toByteArray())
        val rich = d.pages.mapNotNull { it.rich }
        assertTrue(rich.isNotEmpty())
        assertEquals(1, rich.sumOf { imgs(it.blocks).size })
        assertTrue(rich.any { r -> paras(r.blocks).any { it.head >= 1 } })
        assertTrue(rich.any { r -> paras(r.blocks).any { p -> p.runs.any { it.i && it.text.contains("dünya") } } })
    }

    // ---- Markdown ----
    @Test fun markdownDataImage() {
        val d = DocParse.parse("a.md", "# Başlık\n\nMetin ![alt](data:image/png;base64,$PNG64) devam\n\n![yok](a.png)\n".toByteArray())
        val rp = d.pages[0].rich!!
        assertEquals(1, imgs(rp.blocks).size)
        assertTrue(paras(rp.blocks).any { it.plain.contains("[yok]") })
    }

    // ---- MOBI Huffman ----
    private fun be16(v: Int) = byteArrayOf((v shr 8).toByte(), v.toByte())
    private fun be32(v: Long) = byteArrayOf((v shr 24).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte())
    private fun huffRec(): ByteArray {
        val h = ByteArray(24 + 1024 + 256)
        "HUFF".toByteArray().copyInto(h, 0); be32(0x18).copyInto(h, 4); be32(24).copyInto(h, 8); be32(24 + 1024).copyInto(h, 12)
        for (i in 0 until 256) be32((255L shl 8) or 0x80L or 8L).copyInto(h, 24 + i * 4)
        return h
    }
    private val phrases = listOf("<p>", "Merhaba ", "dünya", "</p>", "<img recindex=\"00001\"/>")
    private fun cdicRec(extra: List<Pair<ByteArray, Boolean>> = emptyList()): ByteArray {
        val all = phrases.map { it.toByteArray(Charsets.ISO_8859_1) to true } + extra
        val o = ByteArrayOutputStream()
        o.write("CDIC".toByteArray()); o.write(be32(16)); o.write(be32(256)); o.write(be32(8))
        var off = 512; val offs = ByteArrayOutputStream(); val data = ByteArrayOutputStream()
        for (j in 0 until 256) {
            val (b, lit) = all.getOrNull(j) ?: (ByteArray(0) to true)
            offs.write(be16(off)); data.write(be16(b.size or (if (lit) 0x8000 else 0))); data.write(b); off += 2 + b.size
        }
        o.write(offs.toByteArray()); o.write(data.toByteArray())
        return o.toByteArray()
    }
    private fun code(vararg idx: Int) = ByteArray(idx.size) { (255 - idx[it]).toByte() }

    @Test fun huffUnpackLiteralAndNested() {
        val nested = code(1, 2) to false  // dizin 5: kendisi de Huffman ile sıkıştırılmış
        val h = Mobi.Huff(listOf(huffRec(), cdicRec(listOf(nested))))
        assertEquals("<p>Merhaba dünya</p>", String(h.unpack(code(0, 1, 2, 3)), Charsets.ISO_8859_1))
        assertEquals("Merhaba dünya!", String(h.unpack(code(5)), Charsets.ISO_8859_1).let { it + "!" })
        assertEquals("", String(Mobi.Huff(listOf(ByteArray(30), cdicRec())).unpack(code(0))))
    }

    private fun huffMobi(): ByteArray {
        val r0 = ByteArray(0xE8)
        be16(17480).copyInto(r0, 0); be16(1).copyInto(r0, 8)           // sıkıştırma, 1 metin kaydı
        "MOBI".toByteArray().copyInto(r0, 16); be32(0xE0).copyInto(r0, 20); be32(1252).copyInto(r0, 28)
        be32(4).copyInto(r0, 0x6C); be32(2).copyInto(r0, 0x70); be32(2).copyInto(r0, 0x74)
        val recs = listOf(r0, code(0, 1, 2, 3, 4), huffRec(), cdicRec(), PNG)
        val head = ByteArray(78); "T".toByteArray().copyInto(head, 0); "BOOKMOBI".toByteArray().copyInto(head, 60); be16(recs.size).copyInto(head, 76)
        var off = 78 + recs.size * 8 + 2
        val o = ByteArrayOutputStream(); o.write(head)
        for (r in recs) { o.write(be32(off.toLong())); o.write(byteArrayOf(0, 0, 0, 0)); off += r.size }
        o.write(byteArrayOf(0, 0)); for (r in recs) o.write(r)
        return o.toByteArray()
    }
    @Test fun mobiHuffmanTextAndImage() {
        val d = Mobi.mobiDoc(huffMobi())
        assertEquals(1, d.pages.size)
        assertTrue(d.pages[0].paragraphs.joinToString(" ").contains("Merhaba dünya"))
        assertEquals(1, imgs(d.pages[0].rich!!.blocks).size)
        // bozuk Huffman kaydı çökmez
        val broken = huffMobi().also { it[it.size - 200] = 0x55 }
        Mobi.mobiDoc(broken)
        val noHuff = huffMobi().copyOf(130)
        assertTrue(Mobi.mobiDoc(noHuff).pages.isEmpty())
    }

    // ---- Excel biçimi ----
    @Test fun xlsxDateAndNumberFormats() {
        val st = "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.00&quot; TL&quot;\"/></numFmts>" +
            "<fonts count=\"1\"><font><sz val=\"11\"/></font></fonts><fills count=\"1\"><fill><patternFill patternType=\"none\"/></fill></fills><borders count=\"1\"><border/></borders>" +
            "<cellXfs count=\"4\"><xf numFmtId=\"0\"/><xf numFmtId=\"14\"/><xf numFmtId=\"164\"/><xf numFmtId=\"10\"/></cellXfs></styleSheet>"
        val sh = "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData><row r=\"1\"><c r=\"A1\" s=\"1\"><v>46321</v></c><c r=\"B1\" s=\"2\"><v>1234.5</v></c><c r=\"C1\" s=\"3\"><v>0.256</v></c><c r=\"D1\"><v>0.30000000000000004</v></c></row></sheetData></worksheet>"
        val wb = "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"S\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
        val d = DocParse.parse("x.xlsx", zipS("xl/workbook.xml" to wb, "xl/styles.xml" to st, "xl/worksheets/sheet1.xml" to sh,
            "xl/_rels/workbook.xml.rels" to "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"x/ws\" Target=\"worksheets/sheet1.xml\"/></Relationships>"))
        val row = d.pages[0].table!![0]
        assertEquals(listOf("26.10.2026", "1,234.50 TL", "25.60%", "0.3"), row)
        val cells = (d.pages[0].rich!!.blocks.filterIsInstance<RTable>().first().rows[0]).map { it.paras[0].plain }
        assertEquals(row, cells)
    }

    @Test fun sourceChecks() {
        val m = java.io.File(TestFiles.code, "com/odak/app/docs/Mobi.kt").readText()
        assertTrue(m.contains("17480") && m.contains("class Huff") && m.contains("recindex"))
        assertTrue(DocParse.mediaWanted("OEBPS/img/a.png") && DocParse.mediaWanted("images/c.JPEG"))
    }
}
