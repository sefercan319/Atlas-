package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.24: grafik iyileştirmeleri — yatay çubuk geometrisi, yükseklik, pasta etiket kontrastı, erişilebilirlik özeti. */
class DocChartTest {
    private val white = 0xFFFFFFFF.toInt()
    private val dark = 0xFF111111.toInt()
    private fun chart(kind: ChartKind, cats: List<String>, vararg s: List<Double?>) =
        DocChart("", kind, cats, s.mapIndexed { i, v -> ChartSeries("s$i", v) })

    // ---- oran ve çubuk aralığı
    @Test fun fracMapsAndClamps() {
        assertEquals(0.5, VisualPure.frac(5.0, 0.0, 10.0), 1e-9)
        assertEquals(0.0, VisualPure.frac(-1.0, 0.0, 10.0), 0.0)
        assertEquals(1.0, VisualPure.frac(99.0, 0.0, 10.0), 0.0)
    }
    @Test fun fracDegenerate() {
        assertEquals(0.0, VisualPure.frac(3.0, 5.0, 5.0), 0.0)
        assertEquals(0.0, VisualPure.frac(3.0, 10.0, 0.0), 0.0)
        assertEquals(0.0, VisualPure.frac(Double.NaN, 0.0, 10.0), 0.0)
        assertEquals(0.0, VisualPure.frac(Double.POSITIVE_INFINITY, 0.0, 10.0), 0.0)
    }
    @Test fun barSpanFromZeroToValue() {
        assertEquals(0.0 to 0.5, VisualPure.barSpan(5.0, 0.0, 10.0))
        assertEquals(0.0 to 1.0, VisualPure.barSpan(10.0, 0.0, 10.0))
        assertEquals(0.0 to 0.0, VisualPure.barSpan(0.0, 0.0, 10.0))
    }
    @Test fun barSpanNegativeGoesLeftOfZero() {
        // aralık -10..10: sıfır 0.5'te; -5 değeri 0.25'te → çubuk 0.25..0.5
        assertEquals(0.25 to 0.5, VisualPure.barSpan(-5.0, -10.0, 10.0))
        assertEquals(0.5 to 0.75, VisualPure.barSpan(5.0, -10.0, 10.0))
    }
    @Test fun barSpanStartsOrdered() {
        for (v in listOf(-8.0, -1.0, 0.0, 3.0, 9.0)) { val (a, b) = VisualPure.barSpan(v, -10.0, 10.0); assertTrue("$v", a <= b) }
    }

    // ---- yükseklik
    @Test fun chartHeightPerKind() {
        assertEquals(220, VisualPure.chartHeightDp(ChartKind.PIE, 5))
        assertEquals(240, VisualPure.chartHeightDp(ChartKind.BAR, 50))
        assertEquals(240, VisualPure.chartHeightDp(ChartKind.LINE, 50))
        assertEquals(240, VisualPure.chartHeightDp(ChartKind.HBAR, 3))
        assertEquals(480, VisualPure.chartHeightDp(ChartKind.HBAR, 20))
        assertEquals(640, VisualPure.chartHeightDp(ChartKind.HBAR, 100))
    }

    // ---- kontrast ve pasta etiketi
    @Test fun contrastRatioExtremes() {
        assertEquals(21.0, VisualPure.contrastRatio(white, 0xFF000000.toInt()), 0.01)
        assertEquals(1.0, VisualPure.contrastRatio(white, white), 1e-9)
    }
    @Test fun labelOnPicksReadableText() {
        assertEquals(dark, VisualPure.labelOn(white))
        assertEquals(white, VisualPure.labelOn(0xFF111111.toInt()))
        assertEquals(dark, VisualPure.labelOn(0xFFD4B93C.toInt())) // sarı dilim: koyu yazı
        assertEquals(white, VisualPure.labelOn(0xFF1B2A6B.toInt())) // koyu lacivert: beyaz yazı
    }
    @Test fun everyPaletteSliceHasReadableLabel() {
        assertEquals(8, VisualPure.PALETTE.size)
        for (bg in VisualPure.PALETTE) {
            val ratio = VisualPure.contrastRatio(VisualPure.labelOn(bg), bg)
            assertTrue("bg=${Integer.toHexString(bg)} ratio=$ratio", ratio >= 4.5)
        }
    }

    // ---- erişilebilirlik özeti
    @Test fun maxEntryFindsHighestValue() {
        assertEquals("B" to "10", VisualPure.maxEntry(chart(ChartKind.BAR, listOf("A", "B", "C"), listOf(3.0, 10.0, 2.0))))
    }
    @Test fun maxEntryAcrossSeriesSkipsNullAndNaN() {
        assertEquals("B" to "7.5", VisualPure.maxEntry(chart(ChartKind.LINE, listOf("A", "B"), listOf(1.0, null), listOf(null, 7.5))))
        assertEquals("A" to "4", VisualPure.maxEntry(chart(ChartKind.BAR, listOf("A", "B"), listOf(4.0, Double.NaN))))
    }
    @Test fun maxEntryNumbersMissingCategories() {
        assertEquals("2" to "5", VisualPure.maxEntry(chart(ChartKind.BAR, listOf("A"), listOf(1.0, 5.0))))
    }
    @Test fun maxEntryNullWhenNoValues() {
        assertNull(VisualPure.maxEntry(chart(ChartKind.PIE, listOf("A"), listOf(null))))
        assertNull(VisualPure.maxEntry(chart(ChartKind.PIE, emptyList())))
    }

    // ---- kaynak doğrulaması: arayüz bağlantıları
    private val ui: String get() = File(TestFiles.code, "com/odak/app/docs/DocVisualUi.kt").readText()

    @Test fun uiRoutesHbarToHorizontalDrawer() {
        assertTrue(ui.contains("if (c.kind == ChartKind.HBAR) { drawHBar(c, txt); return }"))
        assertTrue(ui.contains("private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawHBar("))
        assertFalse(ui.contains("ChartKind.BAR, ChartKind.HBAR"))
    }
    @Test fun uiUsesSharedPaletteAndHeight() {
        assertTrue(ui.contains("VisualPure.PALETTE.map { Color(it) }"))
        assertTrue(ui.contains(".height(VisualPure.chartHeightDp(c.kind, c.cats.size).dp)"))
    }
    @Test fun uiPieLabelsUseContrastColor() {
        assertTrue(ui.contains("VisualPure.labelOn(VisualPure.PALETTE[i % VisualPure.PALETTE.size])"))
        assertFalse(ui.contains("color = android.graphics.Color.WHITE"))
    }
    @Test fun noScreenReaderCodeLeft() {
        assertFalse(ui.contains("semantics"))
        assertFalse(ui.contains("chart_a11y"))
    }
}
