package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.47 hata avı düzeltmeleri. */
class BugFixTest {
    private val all = 127
    private val noTue = 127 and (1 shl 1).inv() // Salı kapalı
    private val noMon = 127 and 1.inv()         // Pazartesi kapalı

    @Test fun quietSameDayUsesTodayMask() {
        assertTrue(Pure.quietActive(600, 540, 660, 1, all))
        assertFalse(Pure.quietActive(600, 540, 660, 1, noTue))
    }
    @Test fun quietNightBeforeMidnightUsesTodayMask() {
        assertTrue(Pure.quietActive(23 * 60, 22 * 60, 7 * 60, 0, all))
        assertFalse(Pure.quietActive(23 * 60, 22 * 60, 7 * 60, 0, noMon))
    }
    @Test fun quietEarlyMorningBelongsToPreviousNight() {
        // Pazartesi gecesi açık, Salı kapalı: Salı 03:00 hâlâ Pazartesi gecesinin parçası → aktif
        assertTrue(Pure.quietActive(180, 22 * 60, 7 * 60, 1, noTue))
        // Pazartesi kapalı: Salı 03:00 Pazartesi gecesine ait → pasif
        assertFalse(Pure.quietActive(180, 22 * 60, 7 * 60, 1, noMon))
    }
    @Test fun quietMondayEarlyMorningUsesSunday() {
        assertTrue(Pure.quietActive(60, 22 * 60, 7 * 60, 0, 1 shl 6))
        assertFalse(Pure.quietActive(60, 22 * 60, 7 * 60, 0, 1))
    }
    @Test fun quietOutsideRangeAlwaysOff() {
        assertFalse(Pure.quietActive(12 * 60, 22 * 60, 7 * 60, 3, all))
    }
    @Test fun quietEqualBoundsOff() {
        assertFalse(Pure.quietActive(100, 300, 300, 2, all))
    }
    @Test fun quietEmptyMaskOff() {
        assertFalse(Pure.quietActive(23 * 60, 22 * 60, 7 * 60, 2, 0))
    }

    @Test fun firstResumeIsNewOpen() = assertTrue(Pure.isNewOpen(null, 1000))
    @Test fun quickActivitySwitchIsNotNewOpen() = assertFalse(Pure.isNewOpen(1000, 1500))
    @Test fun resumeAfterGapIsNewOpen() = assertTrue(Pure.isNewOpen(1000, 5000))
    @Test fun resumeExactlyAtGapIsNotNewOpen() = assertFalse(Pure.isNewOpen(1000, 3000))
    @Test fun resumeJustAfterGapIsNewOpen() = assertTrue(Pure.isNewOpen(1000, 3001))

    @Test fun featDeltaFirstScanIsZero() = assertEquals(0L, Pure.featDelta(null, 5000))
    @Test fun featDeltaNormalStep() = assertEquals(400L, Pure.featDelta(1000, 1400))
    @Test fun featDeltaAtCapIsKept() = assertEquals(3000L, Pure.featDelta(1000, 4000))
    @Test fun featDeltaLongAbsenceIsZero() = assertEquals(0L, Pure.featDelta(1000, 3_600_000))
    @Test fun featDeltaClockBackwardsIsZero() = assertEquals(0L, Pure.featDelta(5000, 1000))
    @Test fun featDeltaSameInstantIsZero() = assertEquals(0L, Pure.featDelta(1000, 1000))
}
