package com.odak.app

import com.odak.app.logic.PinHash
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** PIN özeti: PBKDF2 sürüm 2, eski özet doğrulaması, yükseltme kuralı, kaynak denetimi. */
class PinHashTest {
    private val salt = "00112233445566778899aabbccddeeff"

    @Test fun pbkdf2IsDeterministicHex256() {
        val a = PinHash.pbkdf2("1234", salt)
        assertEquals(a, PinHash.pbkdf2("1234", salt))
        assertEquals(64, a.length)
        assertTrue(a.all { it in '0'..'9' || it in 'a'..'f' })
    }

    @Test fun differentPinOrSaltGivesDifferentHash() {
        val h = PinHash.pbkdf2("1234", salt)
        assertTrue(h != PinHash.pbkdf2("1235", salt))
        assertTrue(h != PinHash.pbkdf2("1234", "ffeeddccbbaa99887766554433221100"))
    }

    @Test fun iterationCountIsStrong() {
        assertTrue(PinHash.ITERATIONS >= 100_000)
        assertEquals(2, PinHash.VERSION)
    }

    @Test fun legacyHashIsStillSha256OfSaltThenPin() {
        // eski kayıtlar bu özetle saklanıyordu; değişmemeli ki mevcut PIN'ler çalışsın
        assertEquals(64, PinHash.legacy("1234", salt).length)
        assertEquals(PinHash.legacy("1234", salt), PinHash.legacy("1234", salt))
        assertTrue(PinHash.legacy("1234", salt) != PinHash.pbkdf2("1234", salt))
    }

    @Test fun verifyUsesVersionToPickAlgorithm() {
        val old = PinHash.legacy("4321", salt)
        assertTrue(PinHash.verify("4321", salt, old, 1))
        assertFalse(PinHash.verify("4322", salt, old, 1))
        val new = PinHash.pbkdf2("4321", salt)
        assertTrue(PinHash.verify("4321", salt, new, 2))
        assertFalse(PinHash.verify("4321", salt, old, 2)) // sürüm 2 eski özeti kabul etmez
    }

    @Test fun oldRecordsNeedUpgradeNewOnesDoNot() {
        assertTrue(PinHash.needsUpgrade(1))
        assertFalse(PinHash.needsUpgrade(PinHash.VERSION))
    }

    @Test fun newSaltsAreRandomAndHex() {
        val a = PinHash.newSalt(); val b = PinHash.newSalt()
        assertEquals(32, a.length)
        assertTrue(a != b)
    }

    @Test fun pinSourceUsesPbkdf2AndUpgradesOnCheck() {
        val s = File(TestFiles.code, "com/odak/app/block/Pin.kt").readText()
        assertTrue(s.contains("PinHash.pbkdf2(pin, salt)"))
        assertTrue(s.contains(".putInt(\"v\", com.odak.app.logic.PinHash.VERSION)"))
        assertTrue(s.contains("if (com.odak.app.logic.PinHash.needsUpgrade(ver)) store(c, pin)"))
        assertFalse(s.contains("MessageDigest"))
        assertFalse(s.contains("UUID"))
    }

    @Test fun pinStaysOutOfBackup() {
        assertFalse(com.odak.app.logic.Pure.backupFileAllowed("odak_pin"))
    }
}
