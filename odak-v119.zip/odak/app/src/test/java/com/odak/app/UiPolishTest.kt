package com.odak.app

import com.odak.app.settings.MoreLayout
import com.odak.app.settings.MoreRecents
import com.odak.app.settings.NavMemory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.51: boş durum ekranları, "Diğer" son kullanılanlar. */
class UiPolishTest {
    @Test fun recentsPushMovesToFront() {
        assertEquals(listOf("DOCS"), MoreRecents.push(emptyList(), "DOCS"))
        assertEquals(listOf("PROGRAM", "DOCS"), MoreRecents.push(listOf("DOCS"), "PROGRAM"))
        assertEquals(listOf("DOCS", "PROGRAM"), MoreRecents.push(listOf("PROGRAM", "DOCS"), "DOCS"))
        // en fazla 2
        assertEquals(listOf("SETTINGS", "PROGRAM"), MoreRecents.push(listOf("PROGRAM", "DOCS"), "SETTINGS"))
        // bilinmeyen ad eklenmez
        assertEquals(listOf("DOCS"), MoreRecents.push(listOf("DOCS"), "YOK"))
    }
    @Test fun recentsEncodeDecode() {
        assertEquals(emptyList<String>(), MoreRecents.decode(null)); assertEquals(emptyList<String>(), MoreRecents.decode(""))
        assertEquals(listOf("DOCS", "PROGRAM"), MoreRecents.decode("DOCS, PROGRAM,DOCS,BOZUK,SETTINGS"))
        assertEquals("DOCS,PROGRAM", MoreRecents.encode(listOf("DOCS", "PROGRAM", "SETTINGS")))
        assertTrue(MoreLayout.allEntries().containsAll(MoreRecents.decode("SCREEN_TIME,SETTINGS")))
    }
    @Test fun newStringsInAllLanguages() {
        val res = File(TestFiles.main, "res")
        val keys = listOf("empty_todo_hint", "empty_st_hint", "more_recent", "doc_err_hint", "notes_empty_hint", "plan_empty_hint", "blk_none_hint", "blk_active_count")
        val dirs = listOf("values", "values-tr", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az")
        for (d in dirs) {
            val t = File(res, "$d/strings.xml").readText()
            for (k in keys) assertTrue("$d $k", Regex("<string name=\"$k\">[^<]+</string>").containsMatchIn(t))
            // kesme işareti kaçışlı olmalı
            assertTrue("$d kaçışsız '", Regex("<string name=\"(${keys.joinToString("|")})\">[^<]*(?<!\\\\)'[^<]*</string>").findAll(t).none())
        }
    }
    @Test fun emptyStateWired() {
        fun src(p: String) = File(TestFiles.code, "com/odak/app/" + p).readText()
        assertTrue(src("todo/TodoScreen.kt").contains("EmptyState(\"☑\""))
        assertTrue(src("block/ScreenTimeScreen.kt").contains("EmptyState(\"⏱\""))
        assertTrue(src("notes/NotesList.kt").contains("EmptyState(\"📝\""))
        assertTrue(src("docs/DocActivity.kt").contains("EmptyState(\"⚠\""))
        assertTrue(src("settings/MoreScreen.kt").contains("MoreRecents.push") && src("settings/MoreScreen.kt").contains("launch(e)"))
        assertTrue(File(TestFiles.code, "com/odak/app/theme/EmptyState.kt").exists())
    }
    @Test fun navMemoryRestore() {
        assertEquals(3, NavMemory.restore(3, 5)); assertEquals(0, NavMemory.restore(5, 5)); assertEquals(0, NavMemory.restore(-1, 5)); assertEquals(0, NavMemory.restore(2, 0)); assertEquals(4, NavMemory.restore(4, 5))
    }
    @Test fun planEmptyUsesSharedComponent() {
        val dir = File(TestFiles.code, "com/odak/app/plan")
        val all = dir.listFiles { f -> f.extension == "kt" }!!.joinToString("\n") { it.readText() }
        assertTrue(!Regex("Text\\(stringResource\\(R\\.string\\.plan_empty\\)").containsMatchIn(all))
        assertEquals(14, Regex("PlanEmpty\\(").findAll(all).count())
        assertTrue(File(TestFiles.code, "com/odak/app/theme/EmptyState.kt").readText().contains("fun PlanEmpty"))
    }
    @Test fun blockAndNavWired() {
        val b = File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()
        assertTrue(b.contains("blk_active_count") && b.contains("filtered.isEmpty()") && b.contains("blk_none_hint"))
        val m = File(TestFiles.code, "com/odak/app/MainActivity.kt").readText()
        assertTrue(m.contains("NavMemory.restore") && m.contains("NavMemory.KEY"))
    }
}
