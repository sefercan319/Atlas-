package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Günlük hedef kartı: kullanılan/hedef gösterimi ve aşım işareti (kaynak denetimi). */
class GoalCardTest {
    @Test fun goalCardShowsUsedOverGoalWithWarning() {
        val s = File(TestFiles.code, "com/odak/app/block/ScreenTimeScreen.kt").readText()
        val card = s.substringAfter("private fun GoalCard").substringBefore("private fun catEmoji")
        assertTrue(card.contains("Pure.limitReached(todayMs, goal)"))
        assertTrue(card.contains("\"✖ \""))
        assertTrue(card.contains("MaterialTheme.colorScheme.error"))
        assertTrue(card.contains("\"${'$'}{todayMs / 60_000} / \""))
        assertTrue(card.contains("goal > 0 &&"))
    }
}
