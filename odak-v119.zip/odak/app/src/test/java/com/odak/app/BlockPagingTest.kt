package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.30: Engel ekranı 4 sekme; uygulama listesi 15'er yüklenir, "Daha fazla" ve "Tümünü göster". */
class BlockPagingTest {
    private val src: String get() = File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()

    @Test fun pageIsFifteen() { assertEquals(15, Pure.APP_PAGE) }
    @Test fun nextShownAddsOnePageAndCaps() {
        assertEquals(30, Pure.appsNextShown(15, 100))
        assertEquals(20, Pure.appsNextShown(15, 20))
        assertEquals(0, Pure.appsNextShown(15, 0))
        assertEquals(15, Pure.appsNextShown(-5, 100))
    }
    @Test fun visibleNeverExceedsTotal() {
        assertEquals(15, Pure.appsVisible(15, 100))
        assertEquals(7, Pure.appsVisible(15, 7))
        assertEquals(0, Pure.appsVisible(-1, 7))
    }
    @Test fun remainingCountsHidden() {
        assertEquals(85, Pure.appsRemaining(15, 100))
        assertEquals(0, Pure.appsRemaining(100, 100))
        assertEquals(0, Pure.appsRemaining(120, 100))
    }
    @Test fun walkingPagesReachesEndExactly() {
        var shown = Pure.APP_PAGE; var steps = 0
        while (Pure.appsRemaining(shown, 47) > 0) { shown = Pure.appsNextShown(shown, 47); steps++ }
        assertEquals(47, shown); assertEquals(3, steps)
    }
    @Test fun screenUsesPagingAndNoAutoLoad() {
        val s = src
        assertTrue(s.contains("val PAGE = com.odak.app.logic.Pure.APP_PAGE"))
        assertTrue(s.contains("Pure.appsVisible(shown, filtered.size)"))
        assertTrue(s.contains("R.string.blk_more, rem"))
        assertTrue(s.contains("shown = filtered.size"))
        assertFalse(s.contains("shown += PAGE"))
    }
    @Test fun screenHasFourTabsEachWithItsContent() {
        val s = src
        for (t in 0..3) assertTrue("tab $t", s.contains("if (tab == $t) {"))
        val t0 = s.substringAfter("if (tab == 0) {").substringBefore("if (tab == 1) {")
        assertTrue(t0.contains("ThemedTextField(appQ")); assertTrue(t0.contains("custom_app_add"))
        val t1 = s.substringAfter("if (tab == 1) {").substringBefore("if (tab == 2) {")
        assertTrue(t1.contains("focusUntil")); assertTrue(t1.contains("blk_today"))
        assertTrue(s.substringAfter("if (tab == 2) {").substringBefore("if (tab == 3) {").contains("quietOn"))
        val t3 = s.substringAfter("if (tab == 3) {")
        for (c in listOf("AlertsCard()", "ScreensCard()", "NotifHideCard()", "LearnCard(")) assertTrue(c, t3.contains(c))
    }
    @Test fun blockStringsInEveryLocale() {
        for (d in TestFiles.res.listFiles { f -> f.isDirectory && f.name.startsWith("values") }!!) {
            val f = File(d, "strings.xml"); if (!f.exists()) continue
            val t = f.readText()
            for (k in listOf("blk_tab_apps", "blk_tab_quiet", "blk_tab_adv", "blk_more", "blk_all")) assertTrue("${d.name}:$k", t.contains("name=\"$k\""))
            assertTrue(d.name, Regex("name=\"blk_more\">[^<]*%1\\\$d").containsMatchIn(t))
        }
    }

    @Test fun screenTimeListIsPaged() {
        val s = File(TestFiles.code, "com/odak/app/block/ScreenTimeScreen.kt").readText()
        assertTrue(s.contains("var rowsShown by remember(day)"))
        assertTrue(s.contains("rows.take(com.odak.app.logic.Pure.appsVisible(rowsShown, rows.size))"))
        assertTrue(s.contains("rowsShown = rows.size"))
    }
    @Test fun appPickerIsPaged() {
        val s = File(TestFiles.code, "com/odak/app/block/Extras.kt").readText()
        assertTrue(s.contains("var lim by remember(q)"))
        assertTrue(s.contains("shown.take(com.odak.app.logic.Pure.appsVisible(lim, shown.size))"))
        assertTrue(s.contains("lim = shown.size"))
    }
}
