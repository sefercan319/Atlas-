package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.31: Notlar/Belgeler için başlatıcı kısayolları ve yeni dosya türü filtreleri. */
class ShortcutsTest {
    private val manifest: String get() = File(TestFiles.main, "AndroidManifest.xml").readText()

    @Test fun launcherShortcutsPointToNotesAndDocs() {
        val s = File(TestFiles.res, "xml/shortcuts.xml").readText()
        assertTrue(s.contains("com.odak.app.notes.NotesActivity"))
        assertTrue(s.contains("com.odak.app.docs.DocActivity"))
        assertTrue(s.contains("@string/notes_title") && s.contains("@string/doc_title"))
        assertTrue(manifest.contains("android:name=\"android.app.shortcuts\" android:resource=\"@xml/shortcuts\""))
    }

    @Test fun notesActivityIsExportedForShortcut() {
        assertTrue(manifest.contains(".notes.NotesActivity\" android:exported=\"true\""))
    }

    @Test fun viewFilterListsNewTypes() {
        for (m in listOf("text/html", "application/epub+zip", "text/markdown", "text/calendar", "text/x-vcard"))
            assertTrue(m, manifest.contains("android:mimeType=\"$m\""))
    }
}
