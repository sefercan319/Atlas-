package com.odak.app

import com.odak.app.theme.ColorMath
import com.odak.app.theme.ColorSlot
import com.odak.app.theme.Recolor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.55: renk yuvaları, yeniden boyama (stilin deseni korunur), tek tek sıfırlama, düğme/kart renkleri. */
class ColorSlotTest {
    private fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    private fun ch(c: Int, sh: Int) = (c shr sh) and 255

    @Test fun slotKeysUniqueAndBackwardCompatible() {
        assertEquals(7, ColorSlot.entries.size); assertEquals(7, ColorSlot.entries.map { it.key }.toSet().size)
        // eski kayıtlar korunur: ana renk ":p", vurgu ":a", arka plan ":b", yazı ":t"
        assertEquals("neon:p", ColorSlot.prefKey("neon", ColorSlot.PRIMARY)); assertEquals("neon:a", ColorSlot.prefKey("neon", ColorSlot.ACCENT))
        assertEquals("neon:b", ColorSlot.prefKey("neon", ColorSlot.BACKGROUND)); assertEquals("neon:t", ColorSlot.prefKey("neon", ColorSlot.TEXT))
        assertEquals("neon:bb", ColorSlot.prefKey("neon", ColorSlot.BUTTON)); assertEquals("neon:bt", ColorSlot.prefKey("neon", ColorSlot.BUTTON_TEXT)); assertEquals("neon:s", ColorSlot.prefKey("neon", ColorSlot.SURFACE))
    }
    @Test fun recolorBaseBecomesTargetAndStructureKept() {
        val base = 0xFF87CEEB.toInt(); val target = 0xFF7C4DFF.toInt()
        val m = Recolor.matrix(target, base)
        assertEquals(20, m.size)
        val atBase = Recolor.apply(m, base)
        for (sh in listOf(16, 8, 0)) assertTrue("kanal $sh", Math.abs(ch(atBase, sh) - ch(target, sh)) <= 2)
        // taban piksel zaten tam hedef; daha parlak piksel hedeften parlak, daha koyu piksel hedeften koyu (desen/parlama korunur)
        val light = Recolor.luma(Recolor.apply(m, 0xFFCFF5B0.toInt())); val dark = Recolor.luma(Recolor.apply(m, 0xFF3FA9F5.toInt()))
        val mid = Recolor.luma(target)
        assertTrue("açık $light > $mid", light > mid); assertTrue("koyu $dark < $mid", dark < mid)
        // alfa dokunulmaz
        assertEquals(0x80, ch(Recolor.apply(m, 0x80123456.toInt()), 24))
    }
    @Test fun recolorWorksForEveryPaletteColor() {
        val base = 0xFF2B8FF2.toInt()
        for (t in ColorMath.PALETTE) {
            val out = Recolor.apply(Recolor.matrix(t, base), base)
            for (sh in listOf(16, 8, 0)) assertTrue("${ColorMath.toHex(t)} kanal $sh", Math.abs(ch(out, sh) - ch(t, sh)) <= 4)
        }
        // siyah/beyaz hedeflerde de taşma olmaz
        assertTrue(Recolor.luma(Recolor.apply(Recolor.matrix(0xFF000000.toInt(), base), base)) <= 6f)
    }
    @Test fun gainReducesContrast() {
        val base = 0xFF808080.toInt(); val t = 0xFF336699.toInt()
        val full = Recolor.apply(Recolor.matrix(t, base, 1f), 0xFFFFFFFF.toInt()); val half = Recolor.apply(Recolor.matrix(t, base, 0.5f), 0xFFFFFFFF.toInt())
        assertTrue(Recolor.luma(full) > Recolor.luma(half))
    }

    @Test fun backgroundKeepsStyleArt() {
        val c = src("theme/ThemedComponents.kt")
        assertTrue(c.contains("fun art(t: DesignTokens)") && c.contains("art(if (userBg != null) stock else t)"))
        assertTrue(c.contains(".recolor(userBg, stock.background"))
        // içerik boyanmaz: boyama ayrı katmanda, içerik dışarıda
        assertTrue(c.contains("Box(Modifier.matchParentSize().then(base).then(grid).recolor(") && c.contains("{ Decor(d.style) }\n        content()"))
        assertTrue(!c.contains("Brush.verticalGradient(listOf(Color(ColorMath.lighter"))   // eski "düz renge çevir" kodu kalkmış
    }
    @Test fun buttonAndCardSlotsWired() {
        val c = src("theme/ThemedComponents.kt")
        assertTrue(c.contains("val userBtn = if (derived) null else t.buttonBg") && c.contains("recolor(userBtn, buttonBase(style, t)") && c.contains("t.buttonText ?: c0"))
        assertTrue(c.contains("val artCard = userCard != null") && c.contains("recolor(userCard, stock.surface.over(stock.background)"))
        assertTrue(c.contains("userCard ?: Color.White"))
        val d = src("theme/DesignStyle.kt")
        assertTrue(d.contains("buttonBg = ColorPrefs.buttonOf(style)") && d.contains("ColorPrefs.surfaceOf(style)") && d.contains("fun stockTokens"))
    }
    @Test fun resetIsPerColorNotGlobal() {
        val p = src("theme/ColorPrefs.kt")
        assertTrue(p.contains("fun clear(c: Context, s: DesignStyle, slot: ColorSlot)") && !p.contains("fun reset("))
        val st = src("settings/SettingsScreen.kt")
        assertTrue(st.contains("ColorPrefs.clear(ctx, style, slot)") && !st.contains("ColorPrefs.reset"))
        for (slot in listOf("PRIMARY", "ACCENT", "BACKGROUND", "SURFACE", "TEXT", "BUTTON", "BUTTON_TEXT")) assertTrue(slot, st.contains("ColorSlot.$slot"))
        // her satırda sıfırlama yalnız renk değiştirilmişse görünür
        assertTrue(st.contains("if (custom) ThemedButton(\"↺ \""))
    }
}
