package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.34: profesyonel arayüz ilkeleri — en çok 5 sekme, ana işlevler sekmede, ekleme altta sabit, ikincil olanlar "Diğer"de. */
class ProNavTest {
    private fun code(rel: String) = File(TestFiles.code, "com/odak/app/$rel").readText()

    @Test fun atMostFiveTabsAndNotesIsOne() {
        val m = code("MainActivity.kt")
        val tabs = m.substringAfter("val tabRes = listOf(").substringBefore(")").split(",").map { it.trim() }.filter { it.startsWith("R.string") }
        assertEquals(5, tabs.size); assertTrue(tabs.size <= 5)
        assertTrue(tabs.contains("R.string.notes_title"))
        assertEquals(tabs.size, Regex("\"[^\"]+\"").findAll(m.substringAfter("icons = listOf(").substringBefore(")")).count())
    }

    @Test fun notesHubEmbedsWithoutDoubleInsets() {
        val n = code("notes/NotesActivity.kt")
        assertTrue(n.contains("fun NotesHub(embedded: Boolean = false, onEditorChange: (Boolean) -> Unit = {})"))
        assertTrue(n.contains("if (embedded) Modifier.fillMaxSize() else Modifier.fillMaxSize().systemBarsPadding()"))
        assertTrue(n.contains("NotesHub()")) // Activity hâlâ kendi başına açar
    }

    @Test fun landscapeNarrowCoversAllContentTabs() {
        assertTrue(code("MainActivity.kt").contains("val narrow = land && (page in 1..4)"))
    }

    @Test fun planAddRowIsPinnedBelowScroll() {
        val u = code("plan/UnifiedPlan.kt").substringAfter("fun UnifiedPlan(")
        val scrollEnd = u.indexOf("Spacer(Modifier.height(8.dp))\n        }")
        val add = u.indexOf("AddRow(vm)")
        assertTrue(u.contains("Modifier.weight(1f).verticalScroll(rememberScrollState())"))
        assertTrue("AddRow kaydırma alanının dışında", add > scrollEnd && scrollEnd > 0)
        assertEquals(1, Regex("AddRow\\(vm\\)").findAll(u).count())
    }

    @Test fun secondaryItemsLiveInMore() {
        val s = code("settings/MoreScreen.kt")
        assertTrue(s.contains("SCREEN_TIME(") && s.contains("DOCS(") && s.contains("SETTINGS("))
        assertFalse(s.contains("NOTES("))
    }

    @Test fun tabLabelsAreShort() {
        val m = code("MainActivity.kt")
        assertTrue(m.contains("R.string.tab_todo_s"))
        for (d in TestFiles.res.listFiles { f -> f.isDirectory && f.name.startsWith("values") }!!) {
            val f = File(d, "strings.xml"); if (!f.exists()) continue
            val t = f.readText()
            val v = Regex("name=\"tab_todo_s\">([^<]+)<").find(t)?.groupValues?.get(1)
            assertTrue(d.name, v != null && v.length <= 10)
        }
    }

    @Test fun barHiddenWhileEditingNote() {
        val m = code("MainActivity.kt")
        assertTrue(m.contains("if (!land && !hideBar) ThemedNavBar(") && m.contains("onEditorChange = { hideBar = it }"))
        assertTrue(code("notes/NotesActivity.kt").contains("onEditorChange(it)"))
    }

    @Test fun addRowRisesWithKeyboard() {
        assertTrue(code("plan/UnifiedPlan.kt").contains("Modifier.imePadding().padding(horizontal = 16.dp, vertical = 8.dp)) { AddRow(vm) }"))
    }
}
