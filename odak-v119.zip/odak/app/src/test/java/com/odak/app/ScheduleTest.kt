package com.odak.app

import com.odak.app.schedule.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.time.DayOfWeek
import java.time.LocalDateTime

/** v0.56.40: günlük program (saatli liste + bildirim), not listesi sadeleştirme, ayarlar alt sekmeleri. */
class ScheduleTest {
    private fun it(id: String, min: Int, days: Int = SchedulePure.ALL, on: Boolean = true, t: String = "x") = SchedItem(id, min, days, on, t)
    private val mon = LocalDateTime.of(2026, 10, 26, 10, 0) // Pazartesi

    @Test fun nextFireTodayOrTomorrow() {
        assertEquals(mon.withHour(11).withMinute(30), SchedulePure.nextFire(it("a", 11 * 60 + 30), mon))
        assertEquals(mon.plusDays(1).withHour(9), SchedulePure.nextFire(it("a", 9 * 60), mon))
        assertEquals(mon.plusDays(1).withHour(10).withMinute(0), SchedulePure.nextFire(it("a", 600), mon)) // tam şimdi ise yarın
    }

    @Test fun nextFireRespectsDaysAndOff() {
        val wed = SchedulePure.bit(DayOfWeek.WEDNESDAY)
        assertEquals(mon.plusDays(2).withHour(8).withMinute(0), SchedulePure.nextFire(it("a", 480, wed), mon))
        val mo = SchedulePure.bit(DayOfWeek.MONDAY)
        assertEquals(mon.plusDays(7).withHour(8).withMinute(0), SchedulePure.nextFire(it("a", 480, mo), mon))
        assertNull(SchedulePure.nextFire(it("a", 480, on = false), mon))
        assertNull(SchedulePure.nextFire(it("a", 480, 0), mon))
    }

    @Test fun sortingAndDayFilter() {
        val l = listOf(it("1", 600, t = "b"), it("2", 300, t = "z"), it("3", 600, t = "a"), it("4", 100, SchedulePure.bit(DayOfWeek.SUNDAY)))
        assertEquals(listOf("4", "2", "3", "1"), SchedulePure.sorted(l).map { it.id })
        assertEquals(listOf("2", "3", "1"), SchedulePure.forDay(l, DayOfWeek.MONDAY).map { it.id })
        assertEquals(listOf("4", "2", "3", "1"), SchedulePure.forDay(l, DayOfWeek.SUNDAY).map { it.id })
    }

    @Test fun upcomingPicksEarliest() {
        val l = listOf(it("late", 20 * 60), it("soon", 10 * 60 + 5), it("off", 10 * 60 + 1, on = false))
        assertEquals("soon", SchedulePure.upcoming(l, mon)!!.first.id)
        assertNull(SchedulePure.upcoming(emptyList(), mon))
    }

    @Test fun labelsAndToggle() {
        val n = listOf("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz")
        assertEquals("Her gün", SchedulePure.daysLabel(127, n, "Her gün"))
        assertEquals("Pzt Çar", SchedulePure.daysLabel(5, n, "Her gün"))
        assertEquals("08:05", SchedulePure.fmt(485)); assertEquals("23:59", SchedulePure.fmt(5000)); assertEquals("00:00", SchedulePure.fmt(-3))
        assertEquals(126, SchedulePure.toggleDay(127, DayOfWeek.MONDAY))
        assertEquals(127, SchedulePure.toggleDay(126, DayOfWeek.MONDAY))
    }

    @Test fun encodeDecodeRoundTrip() {
        val l = listOf(it("a-1", 70, 5, true, "Su iç | ilaç"), it("b", 1439, 127, false, "Satır\nsonu \\ ters"))
        val back = SchedulePure.decode(SchedulePure.encode(l))
        assertEquals(listOf("a-1", "b"), back.map { it.id })
        assertEquals("Su iç | ilaç", back[0].text)
        assertEquals("Satır sonu \\ ters", back[1].text) // satır sonu boşluğa çevrilir
        assertFalse(back[1].on); assertEquals(5, back[0].days)
    }

    @Test fun decodeIgnoresBrokenAndLimits() {
        val bad = "x|abc|1|1|t\n|5|1|1|t\nok|5|1|1|\nok2|9999|1|1|t\nok3|5|1|1|tamam\nok3|6|1|1|kopya\nonlyone"
        val d = SchedulePure.decode(bad)
        assertEquals(listOf("ok3"), d.map { it.id })
        assertEquals(SchedulePure.MAX_TEXT, SchedulePure.clean("a".repeat(500)).length)
        assertEquals("a b", SchedulePure.clean("  a \n  b "))
        assertEquals(SchedulePure.ALL, SchedulePure.decode("i|1|1000|1|t")[0].days or 0 and SchedulePure.ALL or SchedulePure.ALL)
        assertEquals(SchedulePure.MAX_ITEMS, SchedulePure.decode((0 until 400).joinToString("\n") { "i$it|1|1|1|t" }).size)
    }

    // ---- kaynak denetimleri (Android dosyaları) ----
    private fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()

    @Test fun wiringSource() {
        val s = src("schedule/ScheduleStore.kt")
        assertTrue(s.contains("class ScheduleReceiver") && s.contains("setExactAndAllowWhileIdle") && s.contains("nextFire"))
        assertTrue(src("notify/Reminders.kt").contains("ScheduleStore.rescheduleAll"))
        assertTrue(File(TestFiles.main, "AndroidManifest.xml").readText().contains(".schedule.ScheduleReceiver"))
        assertTrue(src("settings/MoreScreen.kt").contains("PROGRAM(") && src("settings/MoreScreen.kt").contains("ScheduleScreen()"))
        assertTrue(src("settings/MoreLayout.kt").contains("\"PROGRAM\""))
        assertTrue(src("schedule/ScheduleScreen.kt").contains("TimePickerDialog"))
    }

    @Test fun pureFileHasNoAndroid() {
        assertFalse(Regex("^import (android|androidx|org\\.json)", RegexOption.MULTILINE).containsMatchIn(src("schedule/SchedulePure.kt")))
    }

    @Test fun notesListIsCollapsible() {
        val s = src("notes/NotesList.kt")
        assertTrue(s.contains("var panel") && s.contains("if (panel) {"))
        assertTrue(s.indexOf("if (panel) {") < s.indexOf("NotePure.SORT_UPDATED to"))
    }

    @Test fun lookGroupSplitIntoTabs() {
        val s = src("settings/SettingsScreen.kt").substringAfter("private fun LookGroup").substringBefore("private fun SoundGroup")
        assertTrue(s.contains("var sub") && s.contains("when (sub)"))
        for (c in listOf("ColorsCard(current)", "FontCard(", "ScaleCard()", "LanguageCard()", "LogoCard()")) assertTrue(c, s.contains(c))
    }

    @Test fun stringsInAllLocales() {
        for ((n, f) in TestFiles.stringFiles()) {
            val s = f.readText()
            for (k in listOf("sched_title", "more_d_sched", "sched_text", "sched_empty", "sched_every_day")) assertTrue("$n $k", s.contains("name=\"$k\""))
        }
    }
}
