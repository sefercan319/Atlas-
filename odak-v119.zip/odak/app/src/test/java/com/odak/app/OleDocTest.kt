package com.odak.app

import com.odak.app.docs.DocKind
import com.odak.app.docs.DocParse
import com.odak.app.docs.OleDoc
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Eski ikili biçimler: LibreOffice ile üretilmiş gerçek .doc/.xls/.ppt dosyaları üzerinde sınanır. */
class OleDocTest {
    private val dir = File(TestFiles.main.parentFile, "test/fixtures")
    private fun fx(n: String) = File(dir, n).readBytes()

    // ---- DOC ----
    @Test fun docIsExactNotApproximate() {
        val d = DocParse.parse("fx.doc", fx("fx.doc"))
        assertFalse(d.approx)
        assertEquals(DocKind.LEGACY, d.kind)
    }
    @Test fun docParagraphsAndTurkishChars() {
        val p = DocParse.parse("fx.doc", fx("fx.doc")).pages[0].paragraphs
        assertEquals("Toplantı Notları", p[0])
        assertTrue(p[1].contains("çalışma ğüşiöç İĞÜŞÖÇ"))
        assertTrue(p[1].contains("€"))
        assertEquals("İkinci paragraf: kısa.", p[2])
    }
    @Test fun docTableCellsJoined() {
        val p = DocParse.parse("fx.doc", fx("fx.doc")).pages[0].paragraphs.joinToString("\n")
        assertTrue(p.contains("Ad │ Yaş"))
        assertTrue(p.contains("Ayşe │ 31"))
    }
    @Test fun docHasNoMetadataJunk() {
        val p = DocParse.parse("fx.doc", fx("fx.doc")).pages[0].paragraphs.joinToString("\n")
        assertFalse(p.contains("MSWordDoc"))
        assertFalse(p.contains("python-docx"))
    }
    @Test fun docDetectedWithWrongExtension() {
        val d = DocParse.parse("belge.wps", fx("fx.doc"))   // WPS .wps dosyaları da Word 97 yapısındadır
        assertFalse(d.approx)
        assertEquals("Toplantı Notları", d.pages[0].paragraphs[0])
    }
    @Test fun docTextCleaningFieldsAndCells() {
        val raw = "A\u0013 HYPERLINK \"x\"\u0014Bağlantı\u0015 son\rSatır\u0007Hücre\u0007\r"
        assertEquals(listOf("ABağlantı son", "Satır │ Hücre"), OleDoc.docText(raw))
    }
    @Test fun docTextDropsControlChars() {
        assertEquals(listOf("abc"), OleDoc.docText("a\u0001b\u0008c\r"))
    }

    // ---- XLS ----
    @Test fun xlsSheetNamesAndOrder() {
        val d = DocParse.parse("fx.xls", fx("fx.xls"))
        assertEquals(listOf("Liste", "Büyük"), d.pages.map { it.title })
        assertFalse(d.approx)
    }
    @Test fun xlsCellValues() {
        val t = DocParse.parse("fx.xls", fx("fx.xls")).pages[0].table!!
        assertEquals(listOf("Ad", "Sayı", "Ondalık", "Mantık"), t[0])
        assertEquals(listOf("Ayşe", "42", "3.14159"), t[1].take(3))
        assertEquals(listOf("Şükrü", "-7", "1000000.5"), t[2].take(3))
    }
    @Test fun xlsBooleans() {
        val t = DocParse.parse("fx.xls", fx("fx.xls")).pages[0].table!!
        assertEquals("TRUE", t[1][3])
        assertEquals("FALSE", t[2][3])
    }
    @Test fun xlsFormulaCachedValue() {
        val t = DocParse.parse("fx.xls", fx("fx.xls")).pages[0].table!!
        assertEquals(listOf("Toplam", "35"), t[3].take(2))
    }
    @Test fun xlsLargeSharedStringTableAcrossContinueRecords() {
        val t = DocParse.parse("fx.xls", fx("fx.xls")).pages[1].table!!
        assertEquals(2500, t.size)
        assertEquals("Uzun metin satırı numara 1 abcabcabcabcabcabcabcabcabcabc", t[0][0])
        assertEquals("Uzun metin satırı numara 1234 abcabcabcabcabcabcabcabcabcabc", t[1233][0])
        assertEquals("Uzun metin satırı numara 2500 abcabcabcabcabcabcabcabcabcabc", t[2499][0])
    }
    @Test fun etExtensionUsesSameReader() {
        val d = DocParse.parse("tablo.et", fx("fx.xls"))
        assertEquals(2, d.pages.size)
    }
    @Test fun fmtNumCases() {
        assertEquals("42", OleDoc.fmtNum(42.0))
        assertEquals("-7", OleDoc.fmtNum(-7.0))
        assertEquals("3.14159", OleDoc.fmtNum(3.14159))
        assertEquals("0.5", OleDoc.fmtNum(0.5))
        assertEquals("", OleDoc.fmtNum(Double.NaN))
    }

    // ---- PPT ----
    @Test fun pptSlidesAndText() {
        val d = DocParse.parse("fx.ppt", fx("fx.ppt"))
        assertEquals(2, d.pages.size)
        assertEquals(listOf("Başlık Slaytı", "Madde bir", "Madde iki"), d.pages[0].paragraphs)
        assertEquals(listOf("İkinci Slayt", "Türkçe içerik ğüş"), d.pages[1].paragraphs)
        assertFalse(d.approx)
    }
    @Test fun dpsExtensionUsesSameReader() {
        assertEquals(2, DocParse.parse("sunum.dps", fx("fx.ppt")).pages.size)
    }

    // ---- CFB dayanıklılığı ----
    @Test fun streamsListsKnownNames() {
        val s = OleDoc.streams(fx("fx.doc"))!!
        assertTrue(s.keys.any { it == "WordDocument" })
        assertTrue(s.keys.any { it.endsWith("Table") })
    }
    @Test fun truncatedOleDoesNotThrow() {
        val b = fx("fx.doc")
        for (n in listOf(600, 1500, 4000, b.size / 2)) DocParse.parse("x.doc", b.copyOf(n))
    }
    @Test fun corruptedOleDoesNotThrow() {
        val b = fx("fx.xls").copyOf()
        for (i in 600 until b.size step 997) b[i] = 0x7F
        DocParse.parse("x.xls", b)
    }
    @Test fun garbageWithOleMagicFallsBackToRough() {
        val b = byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte(), 0xA1.toByte(), 0xB1.toByte(), 0x1A, 0xE1.toByte()) + ByteArray(600) { 1 }
        val d = DocParse.parse("x.doc", b)
        assertTrue(d.pages.isEmpty() || d.approx)
    }
    @Test fun nonOleReturnsNull() {
        assertNull(OleDoc.streams("hello".toByteArray()))
        assertFalse(OleDoc.isOle(ByteArray(3)))
    }

    // ---- PUB / ONE ----
    @Test fun oneNoteDetectedAndUtf16TextRead() {
        val magic = intArrayOf(0xE4, 0x52, 0x5C, 0x7B, 0x8C, 0xD8, 0xA7, 0x4D, 0xAE, 0xB1, 0x53, 0x78, 0xD0, 0x29, 0x96, 0xD3).map { it.toByte() }.toByteArray()
        val b = magic + ByteArray(100) + "Alışveriş listesi: süt, ekmek".toByteArray(Charsets.UTF_16LE) + ByteArray(20) + "Toplantı notu cuma".toByteArray(Charsets.UTF_16LE)
        assertTrue(DocParse.isOneNote(b))
        val d = DocParse.parse("defter.one", b)
        assertTrue(d.approx)
        val p = d.pages[0].paragraphs
        assertTrue(p.any { it.contains("Alışveriş listesi") })
        assertTrue(p.any { it.contains("Toplantı notu cuma") })
    }
    @Test fun oneNoteIgnoresPlainUrlsAndNoise() {
        val magic = intArrayOf(0xE4, 0x52, 0x5C, 0x7B, 0x8C, 0xD8, 0xA7, 0x4D, 0xAE, 0xB1, 0x53, 0x78, 0xD0, 0x29, 0x96, 0xD3).map { it.toByte() }.toByteArray()
        val b = magic + "https://example.com/x".toByteArray(Charsets.UTF_16LE) + ByteArray(8) + "aaaa".toByteArray(Charsets.UTF_16LE)
        assertTrue(DocParse.utf16Text(b).isEmpty())
    }
    @Test fun oneAndPubExtensionsAreReadable() {
        assertEquals(DocKind.LEGACY, DocParse.detect("a.one", ByteArray(0)))
        assertEquals(DocKind.LEGACY, DocParse.detect("a.pub", ByteArray(0)))
    }
    @Test fun oneNoteNonMagicIsNotOneNote() {
        assertFalse(DocParse.isOneNote(ByteArray(40)))
        assertFalse(DocParse.isOneNote(ByteArray(4)))
    }

    // ---- ODB ----
    private fun odb(script: String?, content: String = "<c/>"): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            z.putNextEntry(ZipEntry("mimetype")); z.write("application/vnd.sun.xml.base".toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("content.xml")); z.write(content.toByteArray()); z.closeEntry()
            if (script != null) { z.putNextEntry(ZipEntry("database/script")); z.write(script.toByteArray()); z.closeEntry() }
        }
        return bo.toByteArray()
    }
    @Test fun odbTablesAndRows() {
        val sc = "SET DATABASE UNIQUE NAME HSQLDB\nCREATE MEMORY TABLE PUBLIC.\"Kisiler\"(\"ID\" INTEGER NOT NULL PRIMARY KEY,\"Ad\" VARCHAR(50),\"Not\" VARCHAR(20))\n" +
            "INSERT INTO \"Kisiler\" VALUES(1,'Ali',NULL)\nINSERT INTO \"Kisiler\" VALUES(2,'Ay\\u015fe','a,b (x)')\nINSERT INTO \"Kisiler\" VALUES(3,'O''Neil','')"
        val d = DocParse.parse("v.odb", odb(sc))
        assertEquals(DocKind.ODB, d.kind)
        val t = d.pages[0].table!!
        assertEquals("Kisiler", d.pages[0].title)
        assertEquals(listOf("ID", "Ad", "Not"), t[0])
        assertEquals(listOf("1", "Ali", ""), t[1])
        assertEquals(listOf("2", "Ayşe", "a,b (x)"), t[2])
        assertEquals(listOf("3", "O'Neil", ""), t[3])
    }
    @Test fun odbConstraintsAreNotColumns() {
        val sc = "CREATE MEMORY TABLE PUBLIC.\"T\"(\"A\" INTEGER,\"B\" INTEGER,CONSTRAINT SYS_PK PRIMARY KEY(\"A\",\"B\"))"
        assertEquals(listOf("A", "B"), DocParse.parse("v.odb", odb(sc)).pages[0].table!![0])
    }
    @Test fun odbMultipleTables() {
        val sc = "CREATE MEMORY TABLE PUBLIC.\"A\"(\"x\" INTEGER)\nCREATE MEMORY TABLE PUBLIC.\"B\"(\"y\" INTEGER)\nINSERT INTO \"B\" VALUES(9)"
        val d = DocParse.parse("v.odb", odb(sc))
        assertEquals(listOf("A", "B"), d.pages.map { it.title })
        assertEquals(listOf(listOf("y"), listOf("9")), d.pages[1].table)
    }
    @Test fun odbRowsOfUnknownTableIgnored() {
        val d = DocParse.parse("v.odb", odb("INSERT INTO \"Yok\" VALUES(1)"))
        assertTrue(d.pages.isEmpty())
    }
    @Test fun odbConnectionOnlyShowsLink() {
        val d = DocParse.parse("v.odb", odb(null, "<c><db:connection-resource xlink:href=\"sdbc:mysql:jdbc:localhost/test\"/></c>"))
        assertTrue(d.pages[0].paragraphs[0].contains("sdbc:mysql:jdbc:localhost/test"))
    }
    @Test fun odbWithoutAnythingIsEmpty() {
        assertTrue(DocParse.parse("v.odb", odb(null)).pages.isEmpty())
    }
}
