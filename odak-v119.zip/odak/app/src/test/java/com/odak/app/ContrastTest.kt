package com.odak.app

import com.odak.app.theme.Contrast
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.53: yazı okunurluğu (WCAG kontrast). */
class ContrastTest {
    private val W = 0xFFFFFFFF.toInt(); private val K = 0xFF000000.toInt()
    @Test fun ratioKnownValues() {
        assertEquals(21.0, Contrast.ratio(K, W), 0.01); assertEquals(1.0, Contrast.ratio(W, W), 0.001)
        assertEquals(4.54, Contrast.ratio(0xFF767676.toInt(), W), 0.02)   // klasik sınır gri
    }
    @Test fun blendTranslucent() {
        // yarı saydam siyah beyaz üstünde orta gri
        val g = Contrast.blend(0x80000000.toInt(), W) and 0xFF
        assertTrue(g in 126..129)
    }
    @Test fun readableKeepsGoodAndFixesBad() {
        val navy = 0xFF0B2540.toInt()
        assertEquals(navy, Contrast.readable(navy, W))
        // beyaz zeminde açık gri → siyaha döner
        assertEquals(K, Contrast.readable(0xFFAAAAAA.toInt(), W))
        // koyu zeminde koyu yazı → beyaz
        assertEquals(W, Contrast.readable(0xFF111111.toInt(), 0xFF0A0A0F.toInt()))
        // kullanıcı açık sarı seçti, üstünde beyaz etiket → siyah
        assertEquals(K, Contrast.readable(W, 0xFFFFEB3B.toInt()))
        assertEquals(W, Contrast.onColor(0xFF0054E3.toInt())); assertEquals(K, Contrast.onColor(0xFFFFFFC0.toInt()))
    }
    @Test fun alphaRaisedUntilReadable() {
        val a = Contrast.alphaFor(0xFF111111.toInt(), 0xFFFAFAFA.toInt(), 0.4)
        assertTrue(a > 0.4 && a <= 1.0)
        assertTrue(Contrast.ratio(((Math.round(a * 255).toInt()) shl 24) or 0x111111, 0xFFFAFAFA.toInt()) >= 4.5)
        // zaten yeterliyse değişmez
        assertEquals(0.9, Contrast.alphaFor(K, W, 0.9), 0.0001)
    }
    @Test fun errorColorReadableOnLightAndDark() {
        for (bg in listOf(0xFFFFFFFF.toInt(), 0xFFFAFAFA.toInt(), 0xFFF3F3F3.toInt(), 0xFFD8C9AC.toInt(), 0xFF0A0A0F.toInt(), 0xFF14141F.toInt(), 0xFF01012B.toInt(), 0xFF020B04.toInt()))
            assertTrue("bg ${Integer.toHexString(bg)}", Contrast.ratio(Contrast.errorFor(bg), bg) >= 4.5)
    }

    private fun hex(s: String) = java.lang.Long.parseLong(s, 16).toInt()
    @Test fun allStyleTokensReadable() {
        val src = File(TestFiles.code, "com/odak/app/theme/DesignStyle.kt").readText()
        val blocks = Regex("DesignStyle\\.(\\w+) -> DesignTokens\\((.*?)\\)\\n", RegexOption.DOT_MATCHES_ALL).findAll(src).toList()
        assertTrue(blocks.size >= 17)
        for (b in blocks) {
            fun c(k: String) = hex(Regex("$k = Color\\(0x([0-9A-Fa-f]{8})\\)").find(b.groupValues[2])!!.groupValues[1])
            val bg = c("background"); val surf = Contrast.blend(c("surface"), bg); val txt = c("text")
            assertTrue("${b.groupValues[1]} text/bg", Contrast.ratio(txt, bg) >= 4.5)
            assertTrue("${b.groupValues[1]} text/surface", Contrast.ratio(txt, surf) >= 4.5)
        }
    }
    @Test fun lightPlanLabelsReadable() {
        val src = File(TestFiles.code, "com/odak/app/plan/PlanSkin.kt").readText()
        fun labels(style: String): List<Int> {
            val i = src.indexOf("DesignStyle.$style -> GridSkin(")
            val seg = src.substring(i, src.indexOf("numberStyle", i))
            return Regex("(?:hourLabel|dayLabel) = Color\\(0x([0-9A-Fa-f]{8})\\)").findAll(seg).map { hex(it.groupValues[1]) }.toList()
        }
        for ((st, bg) in listOf("MINIMAL" to 0xFFFAF9F6.toInt(), "WINDOWS11" to 0xFFF3F3F3.toInt(), "FRUTIGER_AERO" to 0xFFBFE4F6.toInt())) {
            val l = labels(st); assertTrue(st, l.size == 2)
            for (c in l) assertTrue("$st ${Integer.toHexString(c)}", Contrast.ratio(c, bg) >= 4.5)
        }
    }
    @Test fun uiWired() {
        fun src(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
        val c = src("theme/ThemedComponents.kt")
        assertTrue(c.contains("buttonBg(style, t, pressed)") && c.contains("readableOn(it)") && c.contains("legibleAlpha(tb, idle.alpha)"))
        assertTrue(src("MainActivity.kt").contains("tokens.surface.readableOn(tokens.primary)"))
        assertTrue(src("block/Pin.kt").contains("errorColor()") && src("settings/SettingsScreen.kt").contains("errorColor()"))
    }
}
