package com.odak.app

import com.odak.app.logic.Pure
import com.odak.app.logic.Pure.QuietState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Sessiz saat durumu (kapalı / aralık kapalı / aktif / beklemede) ve 15 dk'lık saat adımı. */
class QuietStateTest {
    private val all = 127
    private val from = 22 * 60
    private val to = 7 * 60

    @Test fun offWhenSwitchedOff() {
        assertEquals(QuietState.OFF, Pure.quietState(false, 23 * 60, from, to, 0, all))
    }

    @Test fun sameTimesIsClosedRangeEvenWhenOn() {
        assertEquals(QuietState.SAME_TIMES, Pure.quietState(true, 100, 300, 300, 2, all))
    }

    @Test fun activeInsideOvernightRange() {
        assertEquals(QuietState.ACTIVE, Pure.quietState(true, 23 * 60, from, to, 0, all))
        assertEquals(QuietState.ACTIVE, Pure.quietState(true, 3 * 60, from, to, 1, all))
    }

    @Test fun idleOutsideRangeOrOnExcludedDay() {
        assertEquals(QuietState.IDLE, Pure.quietState(true, 12 * 60, from, to, 0, all))
        assertEquals(QuietState.IDLE, Pure.quietState(true, 23 * 60, from, to, 0, 0))
    }

    @Test fun stepWrapsBothWaysAcrossMidnight() {
        assertEquals(5, Pure.stepTime(23 * 60 + 50, 15)) // 23:50 + 15 dk = 00:05
        assertEquals(23 * 60 + 50, Pure.stepTime(5, -15))
        assertEquals(0, Pure.stepTime(1440 - 15, 15))
    }

    @Test fun fifteenMinuteStepAndFullDayReachable() {
        assertEquals(15, Pure.TIME_STEP_MIN)
        var m = 0
        repeat(96) { m = Pure.stepTime(m, Pure.TIME_STEP_MIN) }
        assertEquals(0, m) // 96 adım = 24 saat
    }

    @Test fun stateStringsExistInEveryLocale() {
        for (d in listOf("values", "values-en", "values-de", "values-fr", "values-es", "values-ar", "values-ru", "values-az", "values-tr")) {
            val s = File(TestFiles.res, "$d/strings.xml").readText()
            for (k in listOf("quiet_state_active", "quiet_state_idle", "quiet_state_same")) assertTrue("$d $k", s.contains("name=\"$k\">"))
        }
    }

    @Test fun quietCardShowsStateAndFinerSteps() {
        val s = File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()
        assertTrue(s.contains("Pure.quietState("))
        assertTrue(s.contains("Pure.stepTime(minutes, -com.odak.app.logic.Pure.TIME_STEP_MIN)"))
        assertTrue(s.contains("R.string.quiet_state_same"))
        assertTrue(!s.contains("(minutes - 30 + 1440) % 1440"))
    }
}
