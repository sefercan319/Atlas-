package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import kotlin.math.abs
import kotlin.math.pow

/** Y2K, Aurora UI, Claymorphism, Dark Mode: kayıt, ses, kontrast, kaynak denetimi. */
class NewStyles2Test {
    private val theme = File(TestFiles.code, "com/odak/app/theme")
    private val designSrc = File(theme, "DesignStyle.kt").readText()
    private val keys = listOf("y2k", "aurora", "claymorphism", "dark_mode")
    private val names = listOf("Y2K", "AURORA", "CLAYMORPHISM", "DARK")
    private val kinds = listOf("tap", "success", "delete", "notify")
    private val ns2 = File(theme, "NewStyles2.kt").readText()

    // ---------- kayıt ----------
    @Test fun enumHasTheFourNewStyles() {
        val rows = Regex("""^\s+([A-Z0-9_]+)\("([^"]*)", "([a-z0-9_]+)"\)""", RegexOption.MULTILINE)
            .findAll(designSrc.substringBefore("data class DesignTokens")).map { Triple(it.groupValues[1], it.groupValues[2], it.groupValues[3]) }.toList()
        assertEquals(17, rows.size)
        for ((i, n) in names.withIndex()) assertTrue(n, rows.any { it.first == n && it.third == keys[i] })
        assertTrue(rows.any { it.second == "Y2K" }); assertTrue(rows.any { it.second == "Aurora UI" })
        assertTrue(rows.any { it.second == "Dark Mode" })
    }

    @Test fun everyNewStyleHasBaseTokens() {
        for (n in names) assertTrue(n, Regex("""DesignStyle\.$n -> DesignTokens\(""").containsMatchIn(designSrc))
    }

    // ---------- ses ----------
    private class Wav(val rate: Int, val ch: Int, val bits: Int, val s: ShortArray)
    private fun wav(name: String): Wav {
        val b = File(TestFiles.res, "raw/$name.wav").readBytes()
        assertEquals("RIFF", String(b, 0, 4)); assertEquals("WAVE", String(b, 8, 4))
        fun le16(o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
        fun le32(o: Int) = le16(o) or (le16(o + 2) shl 16)
        var p = 12; var rate = 0; var ch = 0; var bits = 0; var data: ShortArray? = null
        while (p + 8 <= b.size) {
            val id = String(b, p, 4); val sz = le32(p + 4)
            if (id == "fmt ") { assertEquals(1, le16(p + 8)); ch = le16(p + 10); rate = le32(p + 12); bits = le16(p + 22) }
            if (id == "data") data = ShortArray(sz / 2) { le16(p + 8 + it * 2).toShort() }
            p += 8 + sz + (sz and 1)
        }
        return Wav(rate, ch, bits, data!!)
    }
    private fun sec(w: Wav) = w.s.size.toDouble() / w.rate

    @Test fun sixteenSoundsAreValidMonoPcm16() {
        for (k in keys) for (kind in kinds) {
            val w = wav("snd_${k}_$kind")
            assertEquals("$k/$kind", 1, w.ch); assertEquals(16, w.bits); assertTrue(w.rate in 8000..48000)
        }
    }

    @Test fun durationsFitTheirRole() {
        for (k in keys) {
            assertTrue("$k tap ${sec(wav("snd_${k}_tap"))}", sec(wav("snd_${k}_tap")) in 0.03..0.5)
            for (kind in listOf("success", "delete")) assertTrue("$k/$kind", sec(wav("snd_${k}_$kind")) in 0.1..1.3)
            assertTrue("$k notify ${sec(wav("snd_${k}_notify"))}", sec(wav("snd_${k}_notify")) in 0.6..2.6)
            assertTrue(wav("snd_${k}_tap").s.size < wav("snd_${k}_notify").s.size)
        }
    }

    @Test fun audibleNotClippingAndClickFree() {
        for (k in keys) for (kind in kinds) {
            val w = wav("snd_${k}_$kind")
            val peak = w.s.maxOf { abs(it.toInt()) } / 32768.0
            assertTrue("$k/$kind sessiz $peak", peak > 0.2); assertTrue("$k/$kind kırpılıyor", peak < 0.9)
            val rms = Math.sqrt(w.s.sumOf { (it / 32768.0).pow(2) } / w.s.size)
            assertTrue("$k/$kind rms $rms", rms > 0.01)
            assertTrue("$k/$kind başlangıç tık", abs(w.s.first().toInt()) < 800)
            assertTrue("$k/$kind bitiş tık", abs(w.s.last().toInt()) < 400)
        }
    }

    @Test fun allSoundsAcrossAllStylesAreDistinct() {
        val seen = HashMap<Int, String>()
        val all = Regex("""^\s+[A-Z0-9_]+\("[^"]*", "([a-z0-9_]+)"\)""", RegexOption.MULTILINE)
            .findAll(designSrc.substringBefore("data class DesignTokens")).map { it.groupValues[1] }.toList()
        for (k in all) for (kind in kinds) {
            val h = wav("snd_${k}_$kind").s.contentHashCode()
            assertFalse("${seen[h]} ile $k/$kind aynı", seen.containsKey(h)); seen[h] = "$k/$kind"
        }
        assertEquals(17 * 4, seen.size)
    }

    // ---------- kontrast ----------
    private fun lum(c: Long): Double {
        fun f(v: Int): Double { val x = v / 255.0; return if (x <= 0.03928) x / 12.92 else ((x + 0.055) / 1.055).pow(2.4) }
        return 0.2126 * f(((c shr 16) and 255).toInt()) + 0.7152 * f(((c shr 8) and 255).toInt()) + 0.0722 * f((c and 255).toInt())
    }
    private fun contrast(a: Long, b: Long): Double { val l1 = lum(a); val l2 = lum(b); return (maxOf(l1, l2) + 0.05) / (minOf(l1, l2) + 0.05) }
    private fun mix(a: Long, b: Long, t: Double): Long {
        var o = 0L
        for (s in listOf(16, 8, 0)) o = o or (((((a shr s) and 255) * (1 - t) + ((b shr s) and 255) * t).toLong()) shl s)
        return o
    }
    private fun tok(style: String, field: String): Long {
        val block = designSrc.substringAfter("DesignStyle.$style -> DesignTokens(").substringBefore("radius")
        return Regex("""$field = Color\(0x([0-9A-Fa-f]{8})\)""").find(block)!!.groupValues[1].toLong(16) and 0xFFFFFF
    }

    @Test fun y2kTextAndAccentAreReadable() {
        val t = tok("Y2K", "text")
        for (c in listOf(0xBFF3FFL, 0xD9C8FFL, 0xFFC2EAL, tok("Y2K", "surface"))) assertTrue(contrast(t, c) >= 7.0)
        assertTrue(contrast(tok("Y2K", "primary"), tok("Y2K", "surface")) >= 4.5)
        assertTrue(contrast(tok("Y2K", "accent"), tok("Y2K", "surface")) >= 4.5)
        assertTrue("jel düğme yazısı", contrast(0xFFFFFF, 0x2A5BFF) >= 4.5)
        assertTrue("bugün hücresi", contrast(0xFFFFFF, 0xC0106F) >= 4.5)
    }

    @Test fun claymorphismInkAndLabelsMeetAA() {
        val t = tok("CLAYMORPHISM", "text")
        val pastels = listOf(0xE0D6FFL, 0xCDEEDDL, 0xFFD9D2L, 0xD3E8FAL, 0xFCE9A8L, 0xF8D3E4L, 0xB8A6FFL,
            tok("CLAYMORPHISM", "background"), tok("CLAYMORPHISM", "surface"))
        for (c in pastels) assertTrue("${c.toString(16)}: ${contrast(t, c)}", contrast(t, c) >= (if (c == 0xB8A6FFL) 4.5 else 7.0))
        assertTrue("mercan düğme + koyu yazı", contrast(t, tok("CLAYMORPHISM", "primary")) >= 4.5)
        assertTrue("vurgu", contrast(tok("CLAYMORPHISM", "accent"), tok("CLAYMORPHISM", "background")) >= 4.5)
        assertTrue("vurgu/surface", contrast(tok("CLAYMORPHISM", "accent"), tok("CLAYMORPHISM", "surface")) >= 4.5)
        val ink = File(theme, "ThemedComponents.kt").readText()
        val inkHex = Regex("""val ClayInk = Color\(0xFF([0-9A-F]{6})\)""").find(ink)!!.groupValues[1].toLong(16)
        assertTrue(contrast(inkHex, tok("CLAYMORPHISM", "background")) >= 4.5)
        assertTrue(contrast(inkHex, tok("CLAYMORPHISM", "surface")) >= 4.5)
        assertTrue("bugün: beyaz / koyu mercan", contrast(0xFFFFFF, 0xB8352B) >= 4.5)
    }

    @Test fun darkModeFollowsMaterialGuidance() {
        val bg = tok("DARK", "background")
        assertTrue("saf siyah olmamalı", bg != 0x000000L)
        assertEquals(0x121212L, bg)
        assertTrue("saf beyaz metin olmamalı", tok("DARK", "text") != 0xFFFFFFL)
        assertTrue(contrast(tok("DARK", "text"), bg) >= 7.0)
        assertTrue(contrast(tok("DARK", "text"), tok("DARK", "surface")) >= 7.0)
        assertTrue(contrast(tok("DARK", "primary"), tok("DARK", "surface")) >= 4.5)
        assertTrue(contrast(tok("DARK", "accent"), tok("DARK", "surface")) >= 4.5)
        assertTrue("düğme yazısı", contrast(0x0B1B33, tok("DARK", "primary")) >= 4.5)
        // yüzey yükseldikçe açılır
        val e = File(theme, "NewStyles2.kt").readText()
        assertTrue(e.contains("fun darkElevation(level: Int): Color = lerp(DarkBase, Color.White, 0.05f + 0.02f * level.coerceIn(0, 5))"))
    }

    @Test fun auroraTextReadableOverEveryCloudAndPanel() {
        val text = tok("AURORA", "text")
        val cloud = Regex("""drawCircle\(Color\(0xFF([0-9A-F]{6})\)""").findAll(ns2.substringAfter("fun AuroraBackdrop")).map { it.groupValues[1].toLong(16) }.toList()
        assertEquals(3, cloud.size)
        val sky = 0x070B1FL
        val scrim = 0x070B1FL
        for (c in cloud) {
            val under = mix(mix(sky, c, 0.8), scrim, 0.35)
            val panel = mix(under, 0xFFFFFF, 0.1)
            assertTrue("bulut ${c.toString(16)}: ${contrast(text, panel)}", contrast(text, panel) >= 4.5)
        }
        assertTrue(contrast(tok("AURORA", "primary"), tok("AURORA", "surface")) >= 4.5)
        assertTrue(contrast(tok("AURORA", "accent"), tok("AURORA", "surface")) >= 4.5)
        assertTrue("düğme yazısı nane", contrast(0x06122B, 0x5EEAD4) >= 4.5)
        assertTrue("düğme yazısı mor", contrast(0x06122B, 0xA78BFA) >= 4.5)
    }

    // ---------- kaynak denetimi ----------
    @Test fun helpersImplementTheResearchedRecipes() {
        for (fn in listOf("fun Modifier.claySurface", "fun Modifier.clayWell", "fun Modifier.y2kGel", "fun Modifier.holoBorder",
            "fun Y2kSparkles", "fun DrawScope.y2kBurst", "fun AuroraBackdrop", "fun Modifier.auroraPanel", "fun Modifier.auroraButton", "fun darkElevation"))
            assertTrue(fn, ns2.contains(fn))
        // kil: renkli dış gölge + beyaz iç ışık + koyu iç gölge
        assertTrue(ns2.contains("drop.copy(alpha = 0.45f)")); assertTrue(ns2.contains("Color.White.copy(alpha = 0.65f)"))
        assertTrue(ns2.contains("shade.copy(alpha = 0.40f)")); assertTrue(ns2.contains("FillType.EVEN_ODD"))
        // Y2K: krom halka + üst parlama; Aurora: blur + nefes
        assertTrue(ns2.contains("0xFF8E9BB8")); assertTrue(ns2.contains("blur(60.dp)")); assertTrue(ns2.contains("tween(14000"))
    }

    @Test fun pressFxGivesEachNewStyleItsOwnReaction() {
        val p = File(theme, "PressFx.kt").readText()
        for (n in names) assertTrue(n, p.contains("DesignStyle.$n"))
        assertTrue(p.contains("DesignStyle.Y2K -> if (x) 1.12f else 0.80f"))
        assertTrue(p.contains("y2kBurst(c, g)")); assertTrue(p.contains("DesignStyle.DARK -> if (g > 0f) drawRect(Color.White.copy(alpha = 0.12f * g))"))
        assertTrue(p.contains("DesignStyle.CLAYMORPHISM ->\n                prog.animateTo(if (p) 1f else 0f, tween(140))"))
    }

    @Test fun motionShapeAndTransitionExistForNewStyles() {
        val s = File(theme, "Styling.kt").readText()
        for (fn in listOf("fun <T> motion", "fun fadeMs", "fun pressScale", "fun pageTransition", "fun buttonShape", "fun cardShape", "fun checkShape")) {
            val body = s.substringAfter(fn).substringBefore("\nfun ")
            for (n in names) assertTrue("$fn / $n", body.contains("DesignStyle.$n"))
        }
    }

    @Test fun componentsAndNavigationHaveBranches() {
        for (f in listOf("ThemedComponents.kt", "NavBar.kt", "PeriodSelector.kt", "Header.kt")) {
            val t = File(theme, f).readText()
            for (n in names) assertTrue("$f / $n", t.contains("DesignStyle.$n"))
        }
    }

    @Test fun planScreenRoutesToOwnLayouts() {
        val p = File(TestFiles.code, "com/odak/app/plan/PlanScreen.kt").readText()
        assertTrue("v0.56.28: tüm stiller tek düzene gider", p.contains("UnifiedPlan(vm, style)"))
        val k = File(TestFiles.code, "com/odak/app/plan/PlanNewStyles2.kt").readText()
        for (fn in listOf("fun Y2kPlan", "fun AuroraPlan", "fun ClayPlan", "fun DarkPlan")) assertTrue(fn, k.contains(fn))
        assertTrue("Y2K pencere başlığı", k.contains(".EXE"))
    }

    @Test fun darkAndAuroraAreNaturallyDarkOthersLight() {
        val d = File(theme, "DarkMode.kt").readText().substringAfter("fun naturallyDark").substringBefore("/**")
        assertTrue(d.contains("AURORA")); assertTrue(d.contains("DARK"))
        assertFalse(d.contains("Y2K")); assertFalse(d.contains("CLAYMORPHISM"))
        val m = File(TestFiles.code, "com/odak/app/MainActivity.kt").readText().substringAfter("val light =").substringBefore("!= inv")
        assertTrue(m.contains("Y2K")); assertTrue(m.contains("CLAYMORPHISM"))
        assertFalse(m.contains("AURORA")); assertFalse(m.contains("DesignStyle.DARK"))
    }

    @Test fun notificationChannelsCoverAllSevenCustomStyles() {
        val c = File(TestFiles.code, "com/odak/app/notify/StyleChannel.kt").readText()
        for (n in names + listOf("SKEUOMORPHISM", "NEUMORPHISM", "GLASSMORPHISM")) assertTrue(n, c.contains("DesignStyle.$n"))
    }

    @Test fun backgroundsAddTheNewBackdrops() {
        val c = File(theme, "ThemedComponents.kt").readText()
        assertTrue(c.contains("AuroraBackdrop(Modifier.matchParentSize())"))
        assertTrue(c.contains("Y2kSparkles(Modifier.matchParentSize())"))
    }
}
