package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import kotlin.math.abs
import kotlin.math.pow

/** Skeuomorphism / Neumorphism / Glassmorphism: kayıt, kapsam, ses dosyaları, kontrast, kaynak denetimi. */
class NewStylesTest {
    private val theme = File(TestFiles.code, "com/odak/app/theme")
    private val designSrc = File(theme, "DesignStyle.kt").readText()
    private val news = listOf("skeuomorphism", "neumorphism", "glassmorphism")
    private val kinds = listOf("tap", "success", "delete", "notify")

    private fun entries(): List<Pair<String, String>> =
        Regex("""^\s+([A-Z0-9_]+)\("[^"]*", "([a-z0-9_]+)"\)""", RegexOption.MULTILINE)
            .findAll(designSrc.substringBefore("data class DesignTokens"))
            .map { it.groupValues[1] to it.groupValues[2] }.toList()

    // ---------- kayıt ----------
    @Test fun enumHasThirteenStylesIncludingNewOnes() {
        val e = entries()
        assertEquals(17, e.size)
        assertTrue(e.map { it.second }.containsAll(news))
        assertTrue(e.map { it.first }.containsAll(listOf("SKEUOMORPHISM", "NEUMORPHISM", "GLASSMORPHISM")))
    }

    @Test fun keysAndNamesAreUnique() {
        val e = entries()
        assertEquals(e.size, e.map { it.first }.toSet().size)
        assertEquals(e.size, e.map { it.second }.toSet().size)
    }

    @Test fun everyNewStyleHasBaseTokens() {
        for (n in listOf("SKEUOMORPHISM", "NEUMORPHISM", "GLASSMORPHISM")) {
            assertTrue("$n tokens", Regex("""DesignStyle\.$n -> DesignTokens\(""").containsMatchIn(designSrc))
        }
    }

    // ---------- when kapsamı ----------
    /** `when (…)` gövdesi eşleşen süslü parantezle bulunur. */
    private fun whenBodies(src: String): List<String> {
        val out = mutableListOf<String>()
        var i = src.indexOf("when (")
        while (i >= 0) {
            val open = src.indexOf('{', i)
            if (open < 0) break
            var depth = 0
            var j = open
            while (j < src.length) {
                if (src[j] == '{') depth++ else if (src[j] == '}') { depth--; if (depth == 0) break }
                j++
            }
            out += src.substring(open, minOf(j + 1, src.length))
            i = src.indexOf("when (", i + 6)
        }
        return out
    }

    @Test fun everyDesignWhenWithoutElseCoversAllStyles() {
        val all = entries().map { it.first }
        var checked = 0
        for (f in TestFiles.kotlinSources()) {
            for (body in whenBodies(f.readText())) {
                // yalnızca bu gövdenin kendi dalları: iç içe when'leri sayma
                val own = StringBuilder()
                var d = 0
                for (ch in body) { if (ch == '{') d++; if (d == 1) own.append(ch); if (ch == '}') d-- }
                val mentioned = Regex("""DesignStyle\.([A-Z0-9_]+)\s*(?:,|->)""").findAll(body).map { it.groupValues[1] }.toSet()
                if (mentioned.size < 2 || Regex("""\belse\s*->""").containsMatchIn(own)) continue
                if (!Regex("""->""").containsMatchIn(own)) continue
                checked++
                val missing = all.filter { it !in mentioned }
                assertTrue("${f.name}: when eksik dallar $missing", missing.isEmpty())
            }
        }
        assertTrue("Denetlenen when sayısı beklenenden az: $checked", checked >= 10)
    }

    @Test fun whenCheckerFindsAMissingBranch() {
        val bad = "when (style) { DesignStyle.A -> 1\n DesignStyle.B -> 2 }"
        val b = whenBodies(bad).single()
        val mentioned = Regex("""DesignStyle\.([A-Z0-9_]+)\s*(?:,|->)""").findAll(b).map { it.groupValues[1] }.toSet()
        assertEquals(setOf("A", "B"), mentioned)
    }

    // ---------- ses ----------
    private class Wav(val rate: Int, val ch: Int, val bits: Int, val s: ShortArray)

    private fun wav(name: String): Wav {
        val b = File(TestFiles.res, "raw/$name.wav").readBytes()
        assertEquals("RIFF", String(b, 0, 4)); assertEquals("WAVE", String(b, 8, 4))
        fun le16(o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
        fun le32(o: Int) = le16(o) or (le16(o + 2) shl 16)
        var p = 12
        var rate = 0; var ch = 0; var bits = 0
        var data: ShortArray? = null
        while (p + 8 <= b.size) {
            val id = String(b, p, 4); val sz = le32(p + 4)
            if (id == "fmt ") { assertEquals(1, le16(p + 8)); ch = le16(p + 10); rate = le32(p + 12); bits = le16(p + 22) }
            if (id == "data") data = ShortArray(sz / 2) { le16(p + 8 + it * 2).toShort() }
            p += 8 + sz + (sz and 1)
        }
        return Wav(rate, ch, bits, data!!)
    }

    @Test fun allTwelveSoundsAreValidMonoPcm16() {
        for (n in news) for (k in kinds) {
            val w = wav("snd_${n}_$k")
            assertEquals("$n/$k kanal", 1, w.ch)
            assertEquals("$n/$k bit", 16, w.bits)
            assertTrue("$n/$k örnekleme", w.rate in 8000..48000)
        }
    }

    @Test fun soundDurationsFitTheirRole() {
        for (n in news) {
            for (k in listOf("tap", "success", "delete")) {
                val sec = wav("snd_${n}_$k").let { it.s.size.toDouble() / it.rate }
                assertTrue("$n/$k süre $sec", sec in 0.04..(if (k == "success") 1.2 else 0.9))
            }
            val tap = wav("snd_${n}_tap").let { it.s.size.toDouble() / it.rate }
            assertTrue("$n tap kısa olmalı: $tap", tap <= 0.5)
            val nf = wav("snd_${n}_notify").let { it.s.size.toDouble() / it.rate }
            assertTrue("$n notify süre $nf", nf in 0.6..2.0)
        }
    }

    @Test fun soundsAreAudibleButNotClippingOrHarsh() {
        for (n in news) for (k in kinds) {
            val w = wav("snd_${n}_$k")
            val peak = w.s.maxOf { abs(it.toInt()) } / 32768.0
            assertTrue("$n/$k çok sessiz: $peak", peak > 0.2)
            assertTrue("$n/$k kırpılıyor: $peak", peak < 0.9)
            val rms = Math.sqrt(w.s.sumOf { (it / 32768.0).pow(2) } / w.s.size)
            assertTrue("$n/$k rms $rms", rms > 0.01)
        }
    }

    @Test fun soundsStartAndEndWithoutClicks() {
        for (n in news) for (k in kinds) {
            val w = wav("snd_${n}_$k")
            assertTrue("$n/$k başlangıç tık", abs(w.s.first().toInt()) < 800)
            assertTrue("$n/$k bitiş tık", abs(w.s.last().toInt()) < 400)
        }
    }

    @Test fun everySoundIsDistinct() {
        val seen = HashMap<Int, String>()
        for (n in news) for (k in kinds) {
            val h = wav("snd_${n}_$k").s.contentHashCode()
            assertFalse("${seen[h]} ile $n/$k aynı", seen.containsKey(h))
            seen[h] = "$n/$k"
        }
        // diğer tasarımlarla da çakışmasın
        for ((_, key) in entries()) if (key !in news) for (k in kinds) {
            val h = wav("snd_${key}_$k").s.contentHashCode()
            assertFalse("${seen[h]} ile $key/$k aynı", seen.containsKey(h))
        }
    }

    @Test fun tapIsShorterThanNotifyInEveryNewStyle() {
        for (n in news) assertTrue(wav("snd_${n}_tap").s.size < wav("snd_${n}_notify").s.size)
    }

    // ---------- kontrast ----------
    private fun lum(c: Long): Double {
        fun f(v: Int): Double { val x = v / 255.0; return if (x <= 0.03928) x / 12.92 else ((x + 0.055) / 1.055).pow(2.4) }
        return 0.2126 * f(((c shr 16) and 255).toInt()) + 0.7152 * f(((c shr 8) and 255).toInt()) + 0.0722 * f((c and 255).toInt())
    }
    private fun contrast(a: Long, b: Long): Double {
        val l1 = lum(a); val l2 = lum(b); return (maxOf(l1, l2) + 0.05) / (minOf(l1, l2) + 0.05)
    }
    private fun mix(a: Long, b: Long, t: Double): Long {
        var o = 0L
        for (s in listOf(16, 8, 0)) o = o or (((((a shr s) and 255) * (1 - t) + ((b shr s) and 255) * t).toLong()) shl s)
        return o
    }
    private fun tokenHex(style: String, field: String): Long {
        val block = designSrc.substringAfter("DesignStyle.$style -> DesignTokens(").substringBefore("radius")
        return Regex("""$field = Color\(0x([0-9A-Fa-f]{8})\)""").find(block)!!.groupValues[1].toLong(16) and 0xFFFFFF
    }

    @Test fun neumorphismBodyTextMeetsAAA() {
        val bg = tokenHex("NEUMORPHISM", "background")
        assertTrue(contrast(tokenHex("NEUMORPHISM", "text"), bg) >= 7.0)
        assertTrue("vurgu metni", contrast(tokenHex("NEUMORPHISM", "primary"), bg) >= 4.5)
        assertTrue("ikincil metin", contrast(tokenHex("NEUMORPHISM", "accent"), bg) >= 4.5)
    }

    @Test fun skeuomorphismTextMeetsAAAOnDeskAndPaper() {
        val t = tokenHex("SKEUOMORPHISM", "text")
        assertTrue(contrast(t, tokenHex("SKEUOMORPHISM", "background")) >= 7.0)
        assertTrue(contrast(t, tokenHex("SKEUOMORPHISM", "surface")) >= 7.0)
        // deri düğme: krem yazı en açık gradyan ucunda bile ≥4.5
        val btn = mix(tokenHex("SKEUOMORPHISM", "primary"), 0xFFFFFF, 0.12)
        assertTrue(contrast(0xFFF3D6, btn) >= 4.5)
    }

    @Test fun glassmorphismTextReadableOverEveryOrbAndPanel() {
        val text = tokenHex("GLASSMORPHISM", "text")
        val src = File(theme, "NewStyles.kt").readText()
        val orbs = Regex("""drawCircle\(Color\(0xFF([0-9A-F]{6})\)""").findAll(src).map { it.groupValues[1].toLong(16) }.toList()
        val stops = Regex("""Color\(0xFF([0-9A-F]{6})\), Color\(0xFF([0-9A-F]{6})\), Color\(0xFF([0-9A-F]{6})\)""")
            .find(src.substringAfter("fun GlassOrbs"))!!.groupValues.drop(1).map { it.toLong(16) }
        assertEquals(3, orbs.size); assertEquals(3, stops.size)
        val scrim = 0x140A3FL
        for (o in orbs) for (s in stops) {
            val under = mix(mix(s, o, 0.75), scrim, 0.4)
            val panel = mix(under, 0xFFFFFF, 0.27) // cam panelin en açık köşesi
            assertTrue("orb ${o.toString(16)} / ${s.toString(16)}: ${contrast(text, panel)}", contrast(text, panel) >= 4.5)
        }
    }

    // ---------- kaynak denetimi ----------
    private val newSrc = File(theme, "NewStyles.kt").readText()

    @Test fun helpersExist() {
        for (fn in listOf("fun Modifier.neuSurface", "fun Modifier.skeuoSurface", "fun Modifier.glassPanel", "fun Modifier.skeuoDesk", "fun GlassOrbs")) {
            assertTrue(fn, newSrc.contains(fn))
        }
    }

    @Test fun neumorphismUsesDualShadowAndInset() {
        assertTrue(newSrc.contains("setShadowLayer"))
        assertTrue("sol-üst ışık", newSrc.contains("-d * raise, -d * raise"))
        assertTrue("sağ-alt koyu", newSrc.contains("d * raise, d * raise"))
        assertTrue("inset", newSrc.contains("FillType.EVEN_ODD"))
    }

    @Test fun skeuomorphismHasTexturesGlossAndBevel() {
        for (g in listOf("LEATHER", "METAL", "PAPER")) assertTrue(g, newSrc.contains("Grain.$g"))
        assertTrue(newSrc.contains("Stroke(1.2.dp.toPx())"))
        assertTrue(newSrc.contains("pathEffect = PathEffect.dashPathEffect"))
    }

    @Test fun glassHasBorderSpecularSweepAndOrbs() {
        assertTrue(newSrc.contains("clipOutPath"))
        assertTrue(newSrc.contains("sweep"))
        assertTrue(newSrc.contains(".blur(56.dp)"))
        assertTrue(newSrc.contains("alpha = 0.75f"))
    }

    @Test fun pressFxGivesEachNewStyleItsOwnReaction() {
        val p = File(theme, "PressFx.kt").readText()
        for (n in listOf("SKEUOMORPHISM", "NEUMORPHISM", "GLASSMORPHISM")) assertTrue(n, p.contains("DesignStyle.$n"))
        assertTrue(p.contains("tween(160, easing = FastOutSlowInEasing)"))
        assertTrue(p.contains("Spring.DampingRatioMediumBouncy"))
    }

    @Test fun eachNewStyleHasItsOwnMotionShapeAndTransition() {
        val s = File(theme, "Styling.kt").readText()
        for (fn in listOf("fun <T> motion", "fun fadeMs", "fun pressScale", "fun pageTransition", "fun buttonShape", "fun cardShape", "fun checkShape")) {
            val body = s.substringAfter(fn).substringBefore("\nfun ")
            for (n in listOf("SKEUOMORPHISM", "NEUMORPHISM", "GLASSMORPHISM")) assertTrue("$fn / $n", body.contains("DesignStyle.$n"))
        }
    }

    @Test fun componentsHaveBranchesForNewStyles() {
        for (f in listOf("ThemedComponents.kt", "NavBar.kt", "PeriodSelector.kt", "Header.kt")) {
            val t = File(theme, f).readText()
            for (n in listOf("SKEUOMORPHISM", "NEUMORPHISM", "GLASSMORPHISM")) assertTrue("$f / $n", t.contains("DesignStyle.$n"))
        }
    }

    @Test fun planScreenRoutesNewStylesToTheirOwnLayouts() {
        val p = File(TestFiles.code, "com/odak/app/plan/PlanScreen.kt").readText()
        assertTrue("v0.56.28: tüm stiller tek düzene gider", p.contains("UnifiedPlan(vm, style)"))
        val k = File(TestFiles.code, "com/odak/app/plan/PlanNewStyles.kt").readText()
        for (fn in listOf("fun SkeuoPlan", "fun NeuPlan", "fun GlassPlan")) assertTrue(fn, k.contains(fn))
    }

    @Test fun notificationSoundsAreBoundToPerStyleChannels() {
        val c = File(TestFiles.code, "com/odak/app/notify/StyleChannel.kt").readText()
        assertTrue(c.contains("setSound"))
        assertTrue(c.contains("snd_\${style.key}_notify"))
        for (n in listOf("SKEUOMORPHISM", "NEUMORPHISM", "GLASSMORPHISM")) assertTrue(n, c.contains("DesignStyle.$n"))
        val r = File(TestFiles.code, "com/odak/app/notify/Reminders.kt").readText()
        assertEquals(2, Regex("""StyleChannel\.ensure\(c, nm\)""").findAll(r).count())
        assertFalse("eski sabit kanal kalmamalı", r.contains("NotificationCompat.Builder(c, CHANNEL)"))
    }

    @Test fun legacyStylesKeepTheOldChannel() {
        val c = File(TestFiles.code, "com/odak/app/notify/StyleChannel.kt").readText()
        assertTrue(c.contains("if (style in own) \"\${CHANNEL}_\${style.key}\" else CHANNEL"))
    }

    @Test fun lightStatusBarForLightNewStyles() {
        val m = File(TestFiles.code, "com/odak/app/MainActivity.kt").readText()
        assertTrue(m.contains("DesignStyle.SKEUOMORPHISM"))
        assertTrue(m.contains("DesignStyle.NEUMORPHISM"))
        assertFalse("cam koyu zemin", m.substringAfter("val light =").substringBefore("!= inv").contains("GLASSMORPHISM"))
    }

    @Test fun glassIsNaturallyDarkAndOthersLightStayUnchanged() {
        val d = File(theme, "DarkMode.kt").readText()
        assertTrue(d.substringAfter("fun naturallyDark").substringBefore("/**").contains("GLASSMORPHISM"))
        assertFalse(d.substringAfter("fun naturallyDark").substringBefore("/**").contains("NEUMORPHISM"))
    }

    @Test fun savedStyleNameStillResolvesWithEnumNames() {
        assertTrue(designSrc.contains("it.name == name"))
        assertTrue(designSrc.contains("putString(KEY, style.name)"))
    }
}
