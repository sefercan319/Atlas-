package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.52: yeni özellikler için tablo tabanlı testler (beklenen değerler bağımsız Python hesabından). */
class ScaleGenTest {
    @Test fun autoScale_0() { assertEquals(1.0f, Pure.autoScale(0,0), 0.0001f) }
    @Test fun autoScale_1() { assertEquals(1.0f, Pure.autoScale(0,300), 0.0001f) }
    @Test fun autoScale_2() { assertEquals(1.0f, Pure.autoScale(0,640), 0.0001f) }
    @Test fun autoScale_3() { assertEquals(1.0f, Pure.autoScale(0,900), 0.0001f) }
    @Test fun autoScale_4() { assertEquals(1.0f, Pure.autoScale(0,1500), 0.0001f) }
    @Test fun autoScale_5() { assertEquals(1.0f, Pure.autoScale(20,0), 0.0001f) }
    @Test fun autoScale_6() { assertEquals(0.9f, Pure.autoScale(20,300), 0.0001f) }
    @Test fun autoScale_7() { assertEquals(0.9f, Pure.autoScale(20,640), 0.0001f) }
    @Test fun autoScale_8() { assertEquals(0.9f, Pure.autoScale(20,900), 0.0001f) }
    @Test fun autoScale_9() { assertEquals(0.9f, Pure.autoScale(20,1500), 0.0001f) }
    @Test fun autoScale_10() { assertEquals(1.0f, Pure.autoScale(40,0), 0.0001f) }
    @Test fun autoScale_11() { assertEquals(0.9f, Pure.autoScale(40,300), 0.0001f) }
    @Test fun autoScale_12() { assertEquals(0.9f, Pure.autoScale(40,640), 0.0001f) }
    @Test fun autoScale_13() { assertEquals(0.9f, Pure.autoScale(40,900), 0.0001f) }
    @Test fun autoScale_14() { assertEquals(0.9f, Pure.autoScale(40,1500), 0.0001f) }
    @Test fun autoScale_15() { assertEquals(1.0f, Pure.autoScale(60,0), 0.0001f) }
    @Test fun autoScale_16() { assertEquals(0.9f, Pure.autoScale(60,300), 0.0001f) }
    @Test fun autoScale_17() { assertEquals(0.9f, Pure.autoScale(60,640), 0.0001f) }
    @Test fun autoScale_18() { assertEquals(0.9f, Pure.autoScale(60,900), 0.0001f) }
    @Test fun autoScale_19() { assertEquals(0.9f, Pure.autoScale(60,1500), 0.0001f) }
    @Test fun autoScale_20() { assertEquals(1.0f, Pure.autoScale(80,0), 0.0001f) }
    @Test fun autoScale_21() { assertEquals(0.9f, Pure.autoScale(80,300), 0.0001f) }
    @Test fun autoScale_22() { assertEquals(0.9f, Pure.autoScale(80,640), 0.0001f) }
    @Test fun autoScale_23() { assertEquals(0.9f, Pure.autoScale(80,900), 0.0001f) }
    @Test fun autoScale_24() { assertEquals(0.9f, Pure.autoScale(80,1500), 0.0001f) }
    @Test fun autoScale_25() { assertEquals(1.0f, Pure.autoScale(100,0), 0.0001f) }
    @Test fun autoScale_26() { assertEquals(0.9f, Pure.autoScale(100,300), 0.0001f) }
    @Test fun autoScale_27() { assertEquals(0.9f, Pure.autoScale(100,640), 0.0001f) }
    @Test fun autoScale_28() { assertEquals(0.9f, Pure.autoScale(100,900), 0.0001f) }
    @Test fun autoScale_29() { assertEquals(0.9f, Pure.autoScale(100,1500), 0.0001f) }
    @Test fun autoScale_30() { assertEquals(1.0f, Pure.autoScale(120,0), 0.0001f) }
    @Test fun autoScale_31() { assertEquals(0.9f, Pure.autoScale(120,300), 0.0001f) }
    @Test fun autoScale_32() { assertEquals(0.9f, Pure.autoScale(120,640), 0.0001f) }
    @Test fun autoScale_33() { assertEquals(0.9f, Pure.autoScale(120,900), 0.0001f) }
    @Test fun autoScale_34() { assertEquals(0.9f, Pure.autoScale(120,1500), 0.0001f) }
    @Test fun autoScale_35() { assertEquals(1.0f, Pure.autoScale(140,0), 0.0001f) }
    @Test fun autoScale_36() { assertEquals(0.9f, Pure.autoScale(140,300), 0.0001f) }
    @Test fun autoScale_37() { assertEquals(0.9f, Pure.autoScale(140,640), 0.0001f) }
    @Test fun autoScale_38() { assertEquals(0.9f, Pure.autoScale(140,900), 0.0001f) }
    @Test fun autoScale_39() { assertEquals(0.9f, Pure.autoScale(140,1500), 0.0001f) }
    @Test fun autoScale_40() { assertEquals(1.0f, Pure.autoScale(160,0), 0.0001f) }
    @Test fun autoScale_41() { assertEquals(0.9f, Pure.autoScale(160,300), 0.0001f) }
    @Test fun autoScale_42() { assertEquals(0.9f, Pure.autoScale(160,640), 0.0001f) }
    @Test fun autoScale_43() { assertEquals(0.9f, Pure.autoScale(160,900), 0.0001f) }
    @Test fun autoScale_44() { assertEquals(0.9f, Pure.autoScale(160,1500), 0.0001f) }
    @Test fun autoScale_45() { assertEquals(1.0f, Pure.autoScale(180,0), 0.0001f) }
    @Test fun autoScale_46() { assertEquals(0.9f, Pure.autoScale(180,300), 0.0001f) }
    @Test fun autoScale_47() { assertEquals(0.9f, Pure.autoScale(180,640), 0.0001f) }
    @Test fun autoScale_48() { assertEquals(0.9f, Pure.autoScale(180,900), 0.0001f) }
    @Test fun autoScale_49() { assertEquals(0.9f, Pure.autoScale(180,1500), 0.0001f) }
    @Test fun autoScale_50() { assertEquals(1.0f, Pure.autoScale(200,0), 0.0001f) }
    @Test fun autoScale_51() { assertEquals(0.9f, Pure.autoScale(200,300), 0.0001f) }
    @Test fun autoScale_52() { assertEquals(0.9f, Pure.autoScale(200,640), 0.0001f) }
    @Test fun autoScale_53() { assertEquals(0.9f, Pure.autoScale(200,900), 0.0001f) }
    @Test fun autoScale_54() { assertEquals(0.9f, Pure.autoScale(200,1500), 0.0001f) }
    @Test fun autoScale_55() { assertEquals(1.0f, Pure.autoScale(220,0), 0.0001f) }
    @Test fun autoScale_56() { assertEquals(0.9f, Pure.autoScale(220,300), 0.0001f) }
    @Test fun autoScale_57() { assertEquals(0.9f, Pure.autoScale(220,640), 0.0001f) }
    @Test fun autoScale_58() { assertEquals(0.9f, Pure.autoScale(220,900), 0.0001f) }
    @Test fun autoScale_59() { assertEquals(0.9f, Pure.autoScale(220,1500), 0.0001f) }
    @Test fun autoScale_60() { assertEquals(1.0f, Pure.autoScale(240,0), 0.0001f) }
    @Test fun autoScale_61() { assertEquals(0.9f, Pure.autoScale(240,300), 0.0001f) }
    @Test fun autoScale_62() { assertEquals(0.9f, Pure.autoScale(240,640), 0.0001f) }
    @Test fun autoScale_63() { assertEquals(0.9f, Pure.autoScale(240,900), 0.0001f) }
    @Test fun autoScale_64() { assertEquals(0.9f, Pure.autoScale(240,1500), 0.0001f) }
    @Test fun autoScale_65() { assertEquals(1.0f, Pure.autoScale(260,0), 0.0001f) }
    @Test fun autoScale_66() { assertEquals(0.9f, Pure.autoScale(260,300), 0.0001f) }
    @Test fun autoScale_67() { assertEquals(0.9f, Pure.autoScale(260,640), 0.0001f) }
    @Test fun autoScale_68() { assertEquals(0.9f, Pure.autoScale(260,900), 0.0001f) }
    @Test fun autoScale_69() { assertEquals(0.9f, Pure.autoScale(260,1500), 0.0001f) }
    @Test fun autoScale_70() { assertEquals(1.0f, Pure.autoScale(280,0), 0.0001f) }
    @Test fun autoScale_71() { assertEquals(0.9f, Pure.autoScale(280,300), 0.0001f) }
    @Test fun autoScale_72() { assertEquals(0.9f, Pure.autoScale(280,640), 0.0001f) }
    @Test fun autoScale_73() { assertEquals(0.9f, Pure.autoScale(280,900), 0.0001f) }
    @Test fun autoScale_74() { assertEquals(0.9f, Pure.autoScale(280,1500), 0.0001f) }
    @Test fun autoScale_75() { assertEquals(1.0f, Pure.autoScale(300,0), 0.0001f) }
    @Test fun autoScale_76() { assertEquals(0.9f, Pure.autoScale(300,300), 0.0001f) }
    @Test fun autoScale_77() { assertEquals(0.9f, Pure.autoScale(300,640), 0.0001f) }
    @Test fun autoScale_78() { assertEquals(0.9f, Pure.autoScale(300,900), 0.0001f) }
    @Test fun autoScale_79() { assertEquals(0.9f, Pure.autoScale(300,1500), 0.0001f) }
    @Test fun autoScale_80() { assertEquals(1.0f, Pure.autoScale(320,0), 0.0001f) }
    @Test fun autoScale_81() { assertEquals(0.9f, Pure.autoScale(320,300), 0.0001f) }
    @Test fun autoScale_82() { assertEquals(0.95f, Pure.autoScale(320,640), 0.0001f) }
    @Test fun autoScale_83() { assertEquals(0.95f, Pure.autoScale(320,900), 0.0001f) }
    @Test fun autoScale_84() { assertEquals(0.95f, Pure.autoScale(320,1500), 0.0001f) }
    @Test fun autoScale_85() { assertEquals(1.0f, Pure.autoScale(340,0), 0.0001f) }
    @Test fun autoScale_86() { assertEquals(0.9f, Pure.autoScale(340,300), 0.0001f) }
    @Test fun autoScale_87() { assertEquals(0.95f, Pure.autoScale(340,640), 0.0001f) }
    @Test fun autoScale_88() { assertEquals(0.95f, Pure.autoScale(340,900), 0.0001f) }
    @Test fun autoScale_89() { assertEquals(0.95f, Pure.autoScale(340,1500), 0.0001f) }
    @Test fun autoScale_90() { assertEquals(1.0f, Pure.autoScale(360,0), 0.0001f) }
    @Test fun autoScale_91() { assertEquals(0.9f, Pure.autoScale(360,300), 0.0001f) }
    @Test fun autoScale_92() { assertEquals(1.0f, Pure.autoScale(360,640), 0.0001f) }
    @Test fun autoScale_93() { assertEquals(1.0f, Pure.autoScale(360,900), 0.0001f) }
    @Test fun autoScale_94() { assertEquals(1.0f, Pure.autoScale(360,1500), 0.0001f) }
    @Test fun autoScale_95() { assertEquals(1.0f, Pure.autoScale(380,0), 0.0001f) }
    @Test fun autoScale_96() { assertEquals(0.9f, Pure.autoScale(380,300), 0.0001f) }
    @Test fun autoScale_97() { assertEquals(1.0f, Pure.autoScale(380,640), 0.0001f) }
    @Test fun autoScale_98() { assertEquals(1.0f, Pure.autoScale(380,900), 0.0001f) }
    @Test fun autoScale_99() { assertEquals(1.0f, Pure.autoScale(380,1500), 0.0001f) }
    @Test fun autoScale_100() { assertEquals(1.0f, Pure.autoScale(400,0), 0.0001f) }
    @Test fun autoScale_101() { assertEquals(0.9f, Pure.autoScale(400,300), 0.0001f) }
    @Test fun autoScale_102() { assertEquals(1.0f, Pure.autoScale(400,640), 0.0001f) }
    @Test fun autoScale_103() { assertEquals(1.0f, Pure.autoScale(400,900), 0.0001f) }
    @Test fun autoScale_104() { assertEquals(1.0f, Pure.autoScale(400,1500), 0.0001f) }
    @Test fun autoScale_105() { assertEquals(1.0f, Pure.autoScale(420,0), 0.0001f) }
    @Test fun autoScale_106() { assertEquals(0.9f, Pure.autoScale(420,300), 0.0001f) }
    @Test fun autoScale_107() { assertEquals(1.0f, Pure.autoScale(420,640), 0.0001f) }
    @Test fun autoScale_108() { assertEquals(1.0f, Pure.autoScale(420,900), 0.0001f) }
    @Test fun autoScale_109() { assertEquals(1.0f, Pure.autoScale(420,1500), 0.0001f) }
    @Test fun autoScale_110() { assertEquals(1.0f, Pure.autoScale(440,0), 0.0001f) }
    @Test fun autoScale_111() { assertEquals(0.9f, Pure.autoScale(440,300), 0.0001f) }
    @Test fun autoScale_112() { assertEquals(1.0f, Pure.autoScale(440,640), 0.0001f) }
    @Test fun autoScale_113() { assertEquals(1.0f, Pure.autoScale(440,900), 0.0001f) }
    @Test fun autoScale_114() { assertEquals(1.0f, Pure.autoScale(440,1500), 0.0001f) }
    @Test fun autoScale_115() { assertEquals(1.0f, Pure.autoScale(460,0), 0.0001f) }
    @Test fun autoScale_116() { assertEquals(0.9f, Pure.autoScale(460,300), 0.0001f) }
    @Test fun autoScale_117() { assertEquals(1.0f, Pure.autoScale(460,640), 0.0001f) }
    @Test fun autoScale_118() { assertEquals(1.0f, Pure.autoScale(460,900), 0.0001f) }
    @Test fun autoScale_119() { assertEquals(1.0f, Pure.autoScale(460,1500), 0.0001f) }
    @Test fun autoScale_120() { assertEquals(1.0f, Pure.autoScale(480,0), 0.0001f) }
    @Test fun autoScale_121() { assertEquals(0.9f, Pure.autoScale(480,300), 0.0001f) }
    @Test fun autoScale_122() { assertEquals(1.05f, Pure.autoScale(480,640), 0.0001f) }
    @Test fun autoScale_123() { assertEquals(1.05f, Pure.autoScale(480,900), 0.0001f) }
    @Test fun autoScale_124() { assertEquals(1.05f, Pure.autoScale(480,1500), 0.0001f) }
    @Test fun autoScale_125() { assertEquals(1.0f, Pure.autoScale(500,0), 0.0001f) }
    @Test fun autoScale_126() { assertEquals(0.9f, Pure.autoScale(500,300), 0.0001f) }
    @Test fun autoScale_127() { assertEquals(1.05f, Pure.autoScale(500,640), 0.0001f) }
    @Test fun autoScale_128() { assertEquals(1.05f, Pure.autoScale(500,900), 0.0001f) }
    @Test fun autoScale_129() { assertEquals(1.05f, Pure.autoScale(500,1500), 0.0001f) }
    @Test fun autoScale_130() { assertEquals(1.0f, Pure.autoScale(520,0), 0.0001f) }
    @Test fun autoScale_131() { assertEquals(0.9f, Pure.autoScale(520,300), 0.0001f) }
    @Test fun autoScale_132() { assertEquals(1.05f, Pure.autoScale(520,640), 0.0001f) }
    @Test fun autoScale_133() { assertEquals(1.05f, Pure.autoScale(520,900), 0.0001f) }
    @Test fun autoScale_134() { assertEquals(1.05f, Pure.autoScale(520,1500), 0.0001f) }
    @Test fun autoScale_135() { assertEquals(1.0f, Pure.autoScale(540,0), 0.0001f) }
    @Test fun autoScale_136() { assertEquals(0.9f, Pure.autoScale(540,300), 0.0001f) }
    @Test fun autoScale_137() { assertEquals(1.05f, Pure.autoScale(540,640), 0.0001f) }
    @Test fun autoScale_138() { assertEquals(1.05f, Pure.autoScale(540,900), 0.0001f) }
    @Test fun autoScale_139() { assertEquals(1.05f, Pure.autoScale(540,1500), 0.0001f) }
    @Test fun autoScale_140() { assertEquals(1.0f, Pure.autoScale(560,0), 0.0001f) }
    @Test fun autoScale_141() { assertEquals(0.9f, Pure.autoScale(560,300), 0.0001f) }
    @Test fun autoScale_142() { assertEquals(1.05f, Pure.autoScale(560,640), 0.0001f) }
    @Test fun autoScale_143() { assertEquals(1.05f, Pure.autoScale(560,900), 0.0001f) }
    @Test fun autoScale_144() { assertEquals(1.05f, Pure.autoScale(560,1500), 0.0001f) }
    @Test fun autoScale_145() { assertEquals(1.0f, Pure.autoScale(580,0), 0.0001f) }
    @Test fun autoScale_146() { assertEquals(0.9f, Pure.autoScale(580,300), 0.0001f) }
    @Test fun autoScale_147() { assertEquals(1.05f, Pure.autoScale(580,640), 0.0001f) }
    @Test fun autoScale_148() { assertEquals(1.05f, Pure.autoScale(580,900), 0.0001f) }
    @Test fun autoScale_149() { assertEquals(1.05f, Pure.autoScale(580,1500), 0.0001f) }
    @Test fun autoScale_150() { assertEquals(1.0f, Pure.autoScale(600,0), 0.0001f) }
    @Test fun autoScale_151() { assertEquals(0.9f, Pure.autoScale(600,300), 0.0001f) }
    @Test fun autoScale_152() { assertEquals(1.12f, Pure.autoScale(600,640), 0.0001f) }
    @Test fun autoScale_153() { assertEquals(1.12f, Pure.autoScale(600,900), 0.0001f) }
    @Test fun autoScale_154() { assertEquals(1.12f, Pure.autoScale(600,1500), 0.0001f) }
    @Test fun autoScale_155() { assertEquals(1.0f, Pure.autoScale(620,0), 0.0001f) }
    @Test fun autoScale_156() { assertEquals(0.9f, Pure.autoScale(620,300), 0.0001f) }
    @Test fun autoScale_157() { assertEquals(1.12f, Pure.autoScale(620,640), 0.0001f) }
    @Test fun autoScale_158() { assertEquals(1.12f, Pure.autoScale(620,900), 0.0001f) }
    @Test fun autoScale_159() { assertEquals(1.12f, Pure.autoScale(620,1500), 0.0001f) }
    @Test fun autoScale_160() { assertEquals(1.0f, Pure.autoScale(640,0), 0.0001f) }
    @Test fun autoScale_161() { assertEquals(0.9f, Pure.autoScale(640,300), 0.0001f) }
    @Test fun autoScale_162() { assertEquals(1.12f, Pure.autoScale(640,640), 0.0001f) }
    @Test fun autoScale_163() { assertEquals(1.12f, Pure.autoScale(640,900), 0.0001f) }
    @Test fun autoScale_164() { assertEquals(1.12f, Pure.autoScale(640,1500), 0.0001f) }
    @Test fun autoScale_165() { assertEquals(1.0f, Pure.autoScale(660,0), 0.0001f) }
    @Test fun autoScale_166() { assertEquals(0.9f, Pure.autoScale(660,300), 0.0001f) }
    @Test fun autoScale_167() { assertEquals(1.12f, Pure.autoScale(660,640), 0.0001f) }
    @Test fun autoScale_168() { assertEquals(1.12f, Pure.autoScale(660,900), 0.0001f) }
    @Test fun autoScale_169() { assertEquals(1.12f, Pure.autoScale(660,1500), 0.0001f) }
    @Test fun autoScale_170() { assertEquals(1.0f, Pure.autoScale(680,0), 0.0001f) }
    @Test fun autoScale_171() { assertEquals(0.9f, Pure.autoScale(680,300), 0.0001f) }
    @Test fun autoScale_172() { assertEquals(1.12f, Pure.autoScale(680,640), 0.0001f) }
    @Test fun autoScale_173() { assertEquals(1.12f, Pure.autoScale(680,900), 0.0001f) }
    @Test fun autoScale_174() { assertEquals(1.12f, Pure.autoScale(680,1500), 0.0001f) }
    @Test fun autoScale_175() { assertEquals(1.0f, Pure.autoScale(700,0), 0.0001f) }
    @Test fun autoScale_176() { assertEquals(0.9f, Pure.autoScale(700,300), 0.0001f) }
    @Test fun autoScale_177() { assertEquals(1.12f, Pure.autoScale(700,640), 0.0001f) }
    @Test fun autoScale_178() { assertEquals(1.12f, Pure.autoScale(700,900), 0.0001f) }
    @Test fun autoScale_179() { assertEquals(1.12f, Pure.autoScale(700,1500), 0.0001f) }
    @Test fun autoScale_180() { assertEquals(1.0f, Pure.autoScale(720,0), 0.0001f) }
    @Test fun autoScale_181() { assertEquals(0.9f, Pure.autoScale(720,300), 0.0001f) }
    @Test fun autoScale_182() { assertEquals(1.12f, Pure.autoScale(720,640), 0.0001f) }
    @Test fun autoScale_183() { assertEquals(1.2f, Pure.autoScale(720,900), 0.0001f) }
    @Test fun autoScale_184() { assertEquals(1.2f, Pure.autoScale(720,1500), 0.0001f) }
    @Test fun autoScale_185() { assertEquals(1.0f, Pure.autoScale(740,0), 0.0001f) }
    @Test fun autoScale_186() { assertEquals(0.9f, Pure.autoScale(740,300), 0.0001f) }
    @Test fun autoScale_187() { assertEquals(1.12f, Pure.autoScale(740,640), 0.0001f) }
    @Test fun autoScale_188() { assertEquals(1.2f, Pure.autoScale(740,900), 0.0001f) }
    @Test fun autoScale_189() { assertEquals(1.2f, Pure.autoScale(740,1500), 0.0001f) }
    @Test fun autoScale_190() { assertEquals(1.0f, Pure.autoScale(760,0), 0.0001f) }
    @Test fun autoScale_191() { assertEquals(0.9f, Pure.autoScale(760,300), 0.0001f) }
    @Test fun autoScale_192() { assertEquals(1.12f, Pure.autoScale(760,640), 0.0001f) }
    @Test fun autoScale_193() { assertEquals(1.2f, Pure.autoScale(760,900), 0.0001f) }
    @Test fun autoScale_194() { assertEquals(1.2f, Pure.autoScale(760,1500), 0.0001f) }
    @Test fun autoScale_195() { assertEquals(1.0f, Pure.autoScale(780,0), 0.0001f) }
    @Test fun autoScale_196() { assertEquals(0.9f, Pure.autoScale(780,300), 0.0001f) }
    @Test fun autoScale_197() { assertEquals(1.12f, Pure.autoScale(780,640), 0.0001f) }
    @Test fun autoScale_198() { assertEquals(1.2f, Pure.autoScale(780,900), 0.0001f) }
    @Test fun autoScale_199() { assertEquals(1.2f, Pure.autoScale(780,1500), 0.0001f) }
    @Test fun autoScale_200() { assertEquals(1.0f, Pure.autoScale(800,0), 0.0001f) }
    @Test fun autoScale_201() { assertEquals(0.9f, Pure.autoScale(800,300), 0.0001f) }
    @Test fun autoScale_202() { assertEquals(1.12f, Pure.autoScale(800,640), 0.0001f) }
    @Test fun autoScale_203() { assertEquals(1.2f, Pure.autoScale(800,900), 0.0001f) }
    @Test fun autoScale_204() { assertEquals(1.2f, Pure.autoScale(800,1500), 0.0001f) }
    @Test fun autoScale_205() { assertEquals(1.0f, Pure.autoScale(820,0), 0.0001f) }
    @Test fun autoScale_206() { assertEquals(0.9f, Pure.autoScale(820,300), 0.0001f) }
    @Test fun autoScale_207() { assertEquals(1.12f, Pure.autoScale(820,640), 0.0001f) }
    @Test fun autoScale_208() { assertEquals(1.2f, Pure.autoScale(820,900), 0.0001f) }
    @Test fun autoScale_209() { assertEquals(1.2f, Pure.autoScale(820,1500), 0.0001f) }
    @Test fun autoScale_210() { assertEquals(1.0f, Pure.autoScale(840,0), 0.0001f) }
    @Test fun autoScale_211() { assertEquals(0.9f, Pure.autoScale(840,300), 0.0001f) }
    @Test fun autoScale_212() { assertEquals(1.12f, Pure.autoScale(840,640), 0.0001f) }
    @Test fun autoScale_213() { assertEquals(1.3f, Pure.autoScale(840,900), 0.0001f) }
    @Test fun autoScale_214() { assertEquals(1.3f, Pure.autoScale(840,1500), 0.0001f) }
    @Test fun autoScale_215() { assertEquals(1.0f, Pure.autoScale(860,0), 0.0001f) }
    @Test fun autoScale_216() { assertEquals(0.9f, Pure.autoScale(860,300), 0.0001f) }
    @Test fun autoScale_217() { assertEquals(1.12f, Pure.autoScale(860,640), 0.0001f) }
    @Test fun autoScale_218() { assertEquals(1.3f, Pure.autoScale(860,900), 0.0001f) }
    @Test fun autoScale_219() { assertEquals(1.3f, Pure.autoScale(860,1500), 0.0001f) }
    @Test fun autoScale_220() { assertEquals(1.0f, Pure.autoScale(880,0), 0.0001f) }
    @Test fun autoScale_221() { assertEquals(0.9f, Pure.autoScale(880,300), 0.0001f) }
    @Test fun autoScale_222() { assertEquals(1.12f, Pure.autoScale(880,640), 0.0001f) }
    @Test fun autoScale_223() { assertEquals(1.3f, Pure.autoScale(880,900), 0.0001f) }
    @Test fun autoScale_224() { assertEquals(1.3f, Pure.autoScale(880,1500), 0.0001f) }
    @Test fun autoScale_225() { assertEquals(1.0f, Pure.autoScale(900,0), 0.0001f) }
    @Test fun autoScale_226() { assertEquals(0.9f, Pure.autoScale(900,300), 0.0001f) }
    @Test fun autoScale_227() { assertEquals(1.12f, Pure.autoScale(900,640), 0.0001f) }
    @Test fun autoScale_228() { assertEquals(1.3f, Pure.autoScale(900,900), 0.0001f) }
    @Test fun autoScale_229() { assertEquals(1.3f, Pure.autoScale(900,1500), 0.0001f) }
    @Test fun autoScale_230() { assertEquals(1.0f, Pure.autoScale(920,0), 0.0001f) }
    @Test fun autoScale_231() { assertEquals(0.9f, Pure.autoScale(920,300), 0.0001f) }
    @Test fun autoScale_232() { assertEquals(1.12f, Pure.autoScale(920,640), 0.0001f) }
    @Test fun autoScale_233() { assertEquals(1.3f, Pure.autoScale(920,900), 0.0001f) }
    @Test fun autoScale_234() { assertEquals(1.3f, Pure.autoScale(920,1500), 0.0001f) }
    @Test fun autoScale_235() { assertEquals(1.0f, Pure.autoScale(940,0), 0.0001f) }
    @Test fun autoScale_236() { assertEquals(0.9f, Pure.autoScale(940,300), 0.0001f) }
    @Test fun autoScale_237() { assertEquals(1.12f, Pure.autoScale(940,640), 0.0001f) }
    @Test fun autoScale_238() { assertEquals(1.3f, Pure.autoScale(940,900), 0.0001f) }
    @Test fun autoScale_239() { assertEquals(1.3f, Pure.autoScale(940,1500), 0.0001f) }
    @Test fun autoScale_240() { assertEquals(1.0f, Pure.autoScale(960,0), 0.0001f) }
    @Test fun autoScale_241() { assertEquals(0.9f, Pure.autoScale(960,300), 0.0001f) }
    @Test fun autoScale_242() { assertEquals(1.12f, Pure.autoScale(960,640), 0.0001f) }
    @Test fun autoScale_243() { assertEquals(1.3f, Pure.autoScale(960,900), 0.0001f) }
    @Test fun autoScale_244() { assertEquals(1.3f, Pure.autoScale(960,1500), 0.0001f) }
    @Test fun autoScale_245() { assertEquals(1.0f, Pure.autoScale(980,0), 0.0001f) }
    @Test fun autoScale_246() { assertEquals(0.9f, Pure.autoScale(980,300), 0.0001f) }
    @Test fun autoScale_247() { assertEquals(1.12f, Pure.autoScale(980,640), 0.0001f) }
    @Test fun autoScale_248() { assertEquals(1.3f, Pure.autoScale(980,900), 0.0001f) }
    @Test fun autoScale_249() { assertEquals(1.3f, Pure.autoScale(980,1500), 0.0001f) }
    @Test fun autoScale_250() { assertEquals(1.0f, Pure.autoScale(1000,0), 0.0001f) }
    @Test fun autoScale_251() { assertEquals(0.9f, Pure.autoScale(1000,300), 0.0001f) }
    @Test fun autoScale_252() { assertEquals(1.12f, Pure.autoScale(1000,640), 0.0001f) }
    @Test fun autoScale_253() { assertEquals(1.3f, Pure.autoScale(1000,900), 0.0001f) }
    @Test fun autoScale_254() { assertEquals(1.3f, Pure.autoScale(1000,1500), 0.0001f) }
    @Test fun autoScale_255() { assertEquals(1.0f, Pure.autoScale(1280,0), 0.0001f) }
    @Test fun autoScale_256() { assertEquals(0.9f, Pure.autoScale(1280,300), 0.0001f) }
    @Test fun autoScale_257() { assertEquals(1.12f, Pure.autoScale(1280,640), 0.0001f) }
    @Test fun autoScale_258() { assertEquals(1.3f, Pure.autoScale(1280,900), 0.0001f) }
    @Test fun autoScale_259() { assertEquals(1.3f, Pure.autoScale(1280,1500), 0.0001f) }
    @Test fun autoScale_260() { assertEquals(1.0f, Pure.autoScale(1440,0), 0.0001f) }
    @Test fun autoScale_261() { assertEquals(0.9f, Pure.autoScale(1440,300), 0.0001f) }
    @Test fun autoScale_262() { assertEquals(1.12f, Pure.autoScale(1440,640), 0.0001f) }
    @Test fun autoScale_263() { assertEquals(1.3f, Pure.autoScale(1440,900), 0.0001f) }
    @Test fun autoScale_264() { assertEquals(1.3f, Pure.autoScale(1440,1500), 0.0001f) }
    @Test fun autoScale_265() { assertEquals(1.0f, Pure.autoScale(1600,0), 0.0001f) }
    @Test fun autoScale_266() { assertEquals(0.9f, Pure.autoScale(1600,300), 0.0001f) }
    @Test fun autoScale_267() { assertEquals(1.12f, Pure.autoScale(1600,640), 0.0001f) }
    @Test fun autoScale_268() { assertEquals(1.3f, Pure.autoScale(1600,900), 0.0001f) }
    @Test fun autoScale_269() { assertEquals(1.3f, Pure.autoScale(1600,1500), 0.0001f) }
    @Test fun effScale_270() { assertEquals(0.9f, Pure.effectiveScale(-1.0f, 0.9f), 0.0001f) }
    @Test fun effScale_271() { assertEquals(1.0f, Pure.effectiveScale(-1.0f, 1.0f), 0.0001f) }
    @Test fun effScale_272() { assertEquals(1.2f, Pure.effectiveScale(-1.0f, 1.2f), 0.0001f) }
    @Test fun effScale_273() { assertEquals(1.3f, Pure.effectiveScale(-1.0f, 1.3f), 0.0001f) }
    @Test fun effScale_274() { assertEquals(0.9f, Pure.effectiveScale(0.0f, 0.9f), 0.0001f) }
    @Test fun effScale_275() { assertEquals(1.0f, Pure.effectiveScale(0.0f, 1.0f), 0.0001f) }
    @Test fun effScale_276() { assertEquals(1.2f, Pure.effectiveScale(0.0f, 1.2f), 0.0001f) }
    @Test fun effScale_277() { assertEquals(1.3f, Pure.effectiveScale(0.0f, 1.3f), 0.0001f) }
    @Test fun effScale_278() { assertEquals(0.9f, Pure.effectiveScale(0.0f, 0.9f), 0.0001f) }
    @Test fun effScale_279() { assertEquals(1.0f, Pure.effectiveScale(0.0f, 1.0f), 0.0001f) }
    @Test fun effScale_280() { assertEquals(1.2f, Pure.effectiveScale(0.0f, 1.2f), 0.0001f) }
    @Test fun effScale_281() { assertEquals(1.3f, Pure.effectiveScale(0.0f, 1.3f), 0.0001f) }
    @Test fun effScale_282() { assertEquals(0.7f, Pure.effectiveScale(0.5f, 0.9f), 0.0001f) }
    @Test fun effScale_283() { assertEquals(0.7f, Pure.effectiveScale(0.5f, 1.0f), 0.0001f) }
    @Test fun effScale_284() { assertEquals(0.7f, Pure.effectiveScale(0.5f, 1.2f), 0.0001f) }
    @Test fun effScale_285() { assertEquals(0.7f, Pure.effectiveScale(0.5f, 1.3f), 0.0001f) }
    @Test fun effScale_286() { assertEquals(0.7f, Pure.effectiveScale(0.7f, 0.9f), 0.0001f) }
    @Test fun effScale_287() { assertEquals(0.7f, Pure.effectiveScale(0.7f, 1.0f), 0.0001f) }
    @Test fun effScale_288() { assertEquals(0.7f, Pure.effectiveScale(0.7f, 1.2f), 0.0001f) }
    @Test fun effScale_289() { assertEquals(0.7f, Pure.effectiveScale(0.7f, 1.3f), 0.0001f) }
    @Test fun effScale_290() { assertEquals(0.8f, Pure.effectiveScale(0.8f, 0.9f), 0.0001f) }
    @Test fun effScale_291() { assertEquals(0.8f, Pure.effectiveScale(0.8f, 1.0f), 0.0001f) }
    @Test fun effScale_292() { assertEquals(0.8f, Pure.effectiveScale(0.8f, 1.2f), 0.0001f) }
    @Test fun effScale_293() { assertEquals(0.8f, Pure.effectiveScale(0.8f, 1.3f), 0.0001f) }
    @Test fun effScale_294() { assertEquals(1.0f, Pure.effectiveScale(1.0f, 0.9f), 0.0001f) }
    @Test fun effScale_295() { assertEquals(1.0f, Pure.effectiveScale(1.0f, 1.0f), 0.0001f) }
    @Test fun effScale_296() { assertEquals(1.0f, Pure.effectiveScale(1.0f, 1.2f), 0.0001f) }
    @Test fun effScale_297() { assertEquals(1.0f, Pure.effectiveScale(1.0f, 1.3f), 0.0001f) }
    @Test fun effScale_298() { assertEquals(1.15f, Pure.effectiveScale(1.15f, 0.9f), 0.0001f) }
    @Test fun effScale_299() { assertEquals(1.15f, Pure.effectiveScale(1.15f, 1.0f), 0.0001f) }
    @Test fun effScale_300() { assertEquals(1.15f, Pure.effectiveScale(1.15f, 1.2f), 0.0001f) }
    @Test fun effScale_301() { assertEquals(1.15f, Pure.effectiveScale(1.15f, 1.3f), 0.0001f) }
    @Test fun effScale_302() { assertEquals(1.3f, Pure.effectiveScale(1.3f, 0.9f), 0.0001f) }
    @Test fun effScale_303() { assertEquals(1.3f, Pure.effectiveScale(1.3f, 1.0f), 0.0001f) }
    @Test fun effScale_304() { assertEquals(1.3f, Pure.effectiveScale(1.3f, 1.2f), 0.0001f) }
    @Test fun effScale_305() { assertEquals(1.3f, Pure.effectiveScale(1.3f, 1.3f), 0.0001f) }
    @Test fun effScale_306() { assertEquals(1.6f, Pure.effectiveScale(1.6f, 0.9f), 0.0001f) }
    @Test fun effScale_307() { assertEquals(1.6f, Pure.effectiveScale(1.6f, 1.0f), 0.0001f) }
    @Test fun effScale_308() { assertEquals(1.6f, Pure.effectiveScale(1.6f, 1.2f), 0.0001f) }
    @Test fun effScale_309() { assertEquals(1.6f, Pure.effectiveScale(1.6f, 1.3f), 0.0001f) }
    @Test fun effScale_310() { assertEquals(1.6f, Pure.effectiveScale(2.0f, 0.9f), 0.0001f) }
    @Test fun effScale_311() { assertEquals(1.6f, Pure.effectiveScale(2.0f, 1.0f), 0.0001f) }
    @Test fun effScale_312() { assertEquals(1.6f, Pure.effectiveScale(2.0f, 1.2f), 0.0001f) }
    @Test fun effScale_313() { assertEquals(1.6f, Pure.effectiveScale(2.0f, 1.3f), 0.0001f) }
    @Test fun effScale_314() { assertEquals(1.6f, Pure.effectiveScale(5.0f, 0.9f), 0.0001f) }
    @Test fun effScale_315() { assertEquals(1.6f, Pure.effectiveScale(5.0f, 1.0f), 0.0001f) }
    @Test fun effScale_316() { assertEquals(1.6f, Pure.effectiveScale(5.0f, 1.2f), 0.0001f) }
    @Test fun effScale_317() { assertEquals(1.6f, Pure.effectiveScale(5.0f, 1.3f), 0.0001f) }
}
