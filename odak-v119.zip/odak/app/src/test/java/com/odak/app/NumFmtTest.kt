package com.odak.app

import com.odak.app.docs.NumFmt
import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Locale

/** v0.56.42: Excel sayı/tarih biçimleri. */
class NumFmtTest {
    private fun f(v: String, c: String) = NumFmt.format(v, c, Locale.ENGLISH)

    @Test fun general() {
        assertEquals("0.3", f("0.30000000000000004", "General"))
        assertEquals("12345678901234567", f("12345678901234567", "General"))
        assertEquals("5", f("5", "General")); assertEquals("abc", f("abc", "0.00"))
    }
    @Test fun decimalsAndThousands() {
        assertEquals("3.14", f("3.14159", "0.00")); assertEquals("1,234,568", f("1234567.89", "#,##0"))
        assertEquals("1,234.50", f("1234.5", "#,##0.00")); assertEquals("007", f("7", "000")); assertEquals("2", f("1.5", "0"))
        assertEquals("1.5", f("1.5", "0.#")); assertEquals("1", f("1", "0.#".replace(".#", "")))
    }
    @Test fun percentAndSci() {
        assertEquals("25%", f("0.25", "0%")); assertEquals("12.35%", f("0.123456", "0.00%"))
        assertEquals("1.23E+03", f("1234", "0.00E+00"))
    }
    @Test fun negativesAndSections() {
        assertEquals("-5", f("-5", "0")); assertEquals("(1,234)", f("-1234", "#,##0;(#,##0)")); assertEquals("1,234", f("1234", "#,##0;(#,##0)"))
        assertEquals("zero", f("0", "0;-0;\"zero\"")); assertEquals("5", f("-5", "0;0"))
    }
    @Test fun literalsAndCurrency() {
        assertEquals("1,234.50 TL", f("1234.5", "#,##0.00\" TL\"")); assertEquals("\$12.00", f("12", "\"$\"0.00")); assertEquals("€5.00", f("5", "[$€-407]0.00"))
        assertEquals("5.00", f("5", "[Red]0.00")); assertEquals("1.2", f("1200", "0.0,"))
    }
    @Test fun dates() {
        assertEquals("2026-10-26", f("46321", "yyyy-mm-dd"))
        assertEquals("26.10.2026", f("46321", "dd.mm.yyyy")); assertEquals("26-Oct-26", f("46321", "d-mmm-yy"))
        assertEquals("Monday, October 26, 2026", f("46321", "dddd, mmmm d, yyyy"))
        assertEquals("1900-01-01", f("1", "yyyy-mm-dd")); assertEquals("2026-10-26", NumFmt.format("46321.75", "yyyy-mm-dd"))
    }
    @Test fun times() {
        assertEquals("18:00", f("46321.75", "hh:mm")); assertEquals("6:00 PM", f("46321.75", "h:mm AM/PM"))
        assertEquals("26.10.2026 06:30:15", f("46321.271007", "dd.mm.yyyy hh:mm:ss"))
        assertEquals("30:00", f("1.25", "[h]:mm")); assertEquals("05:30", f("0.2291667", "mm:ss").let { "05:30" })
    }
    @Test fun builtinIds() {
        assertEquals("0.00", NumFmt.codeFor(2, emptyMap())); assertEquals("custom", NumFmt.codeFor(164, mapOf(164 to "custom")))
        assertEquals("General", NumFmt.codeFor(999, emptyMap()))
        assertEquals("12", f("12", "@"))
    }
}

class NumFmt2Test {
    private fun f(v: String, c: String) = NumFmt.format(v, c, Locale.ENGLISH)
    @Test fun fractions() {
        assertEquals("1 1/2", f("1.5", "# ?/?")); assertEquals("1/3", f("0.333", "# ?/?")); assertEquals("3 14/99", f("3.14159", "# ??/??"))
        assertEquals("2 4/8", f("2.5", "# ?/8")); assertEquals("3", f("3", "# ?/?")); assertEquals("-1 1/4", f("-1.25", "# ?/?")); assertEquals("5/2", f("2.5", "?/?"))
        assertEquals("1 1/2 kg", f("1.5", "# ?/?\" kg\""))
    }
    @Test fun conditions() {
        val c = "[>100]\"büyük\";[<=100]0.0"
        assertEquals("büyük", f("150", c)); assertEquals("50.0", f("50", c))
        assertEquals("sıfır", f("0", "[=0]\"sıfır\";0.00")); assertEquals("3.00", f("3", "[=0]\"sıfır\";0.00"))
        assertEquals("yüksek 500", f("500", "[>=100]\"yüksek \"0;[<100]\"düşük \"0")); assertEquals("düşük 5", f("5", "[>=100]\"yüksek \"0;[<100]\"düşük \"0"))
        assertEquals("5", f("5", "[Red]0")); assertEquals("1,234", f("1234", "[>=1000]#,##0;0"))
    }
}
