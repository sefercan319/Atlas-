package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/** Rastgele grafik/diyagram üret → ayrıştır → aynı veriyi bul. */
class DocVisualGenTest {
    private val names = listOf("Ocak", "Şubat", "Ağustos", "İş", "Q1", "x y", "ğ", "A&amp;B")
    private val plain = listOf("Ocak", "Şubat", "Ağustos", "İş", "Q1", "x y", "ğ", "A&B")

    private fun xml(kind: String, n: Int, ser: List<List<Double?>>, snames: List<String>, cats: List<String>, pfx: String): String {
        val p = if (pfx.isEmpty()) "" else "$pfx:"
        return "<${p}chartSpace><${p}chart><${p}plotArea><${p}$kind>" + ser.mapIndexed { si, vs ->
            "<${p}ser><${p}tx><${p}strRef><${p}strCache><${p}ptCount val=\"1\"/><${p}pt idx=\"0\"><${p}v>${snames[si]}</${p}v></${p}pt></${p}strCache></${p}strRef></${p}tx>" +
                "<${p}cat><${p}strRef><${p}strCache><${p}ptCount val=\"$n\"/>" + cats.mapIndexed { i, c -> "<${p}pt idx=\"$i\"><${p}v>$c</${p}v></${p}pt>" }.joinToString("") + "</${p}strCache></${p}strRef></${p}cat>" +
                "<${p}val><${p}numRef><${p}numCache><${p}ptCount val=\"$n\"/>" + vs.mapIndexed { i, v -> if (v == null) "" else "<${p}pt idx=\"$i\"><${p}v>$v</${p}v></${p}pt>" }.joinToString("") + "</${p}numCache></${p}numRef></${p}val></${p}ser>"
        }.joinToString("") + "</${p}$kind></${p}plotArea></${p}chart></${p}chartSpace>"
    }

    @Test fun randomChartsRoundTrip() {
        val r = Random(563)
        val kinds = mapOf("barChart" to ChartKind.BAR, "lineChart" to ChartKind.LINE, "pieChart" to ChartKind.PIE, "areaChart" to ChartKind.AREA, "doughnutChart" to ChartKind.PIE, "line3DChart" to ChartKind.LINE)
        repeat(300) { t ->
            val (k, want) = kinds.entries.elementAt(r.nextInt(kinds.size)).let { it.key to it.value }
            val n = r.nextInt(1, 13); val m = r.nextInt(1, 6)
            val ci = List(n) { r.nextInt(names.size) }
            val cats = ci.map { names[it] }
            val sn = List(m) { "Seri${it}_" + names[r.nextInt(names.size)] }
            val ser = List(m) { List(n) { if (r.nextInt(8) == 0) null else Math.round(r.nextDouble(-500.0, 5000.0) * 100) / 100.0 } }
            val pfx = listOf("c", "", "ch")[t % 3]
            val c = DocVisual.parseChart(xml(k, n, ser, sn, cats, pfx).toByteArray())!!
            assertEquals("t=$t kind", want, c.kind)
            assertEquals("t=$t cats", ci.map { plain[it] }, c.cats)
            assertEquals("t=$t names", sn.map { it.replace("&amp;", "&") }, c.series.map { it.name })
            for (si in 0 until m) assertEquals("t=$t s=$si", ser[si], c.series[si].values)
        }
    }

    @Test fun rangeAlwaysContainsAllValuesAndZero() {
        val r = Random(5)
        repeat(300) {
            val ser = List(r.nextInt(1, 4)) { List(r.nextInt(1, 10)) { if (r.nextInt(6) == 0) null else r.nextDouble(-1e6, 1e6) } }
            val c = DocChart("", ChartKind.BAR, List(10) { "c" }, ser.mapIndexed { i, v -> ChartSeries("s$i", v) })
            val (lo, hi) = DocVisual.range(c)
            assertTrue(lo <= 0.0 && hi >= 0.0 && hi > lo)
            for (v in ser.flatten().filterNotNull()) assertTrue(v >= lo && v <= hi)
        }
    }

    @Test fun pieSharesSumToOne() {
        val r = Random(6)
        repeat(300) {
            val vs = List(r.nextInt(1, 9)) { if (r.nextInt(5) == 0) null else r.nextDouble(-10.0, 100.0) }
            val s = DocVisual.pieShares(DocChart("", ChartKind.PIE, List(vs.size) { "c" }, listOf(ChartSeries("s", vs))))
            if (s.isNotEmpty()) { assertEquals(1.0, s.sum(), 1e-9); assertTrue(s.all { it >= 0.0 }) }
            else assertTrue(vs.all { (it ?: 0.0) <= 0.0 })
        }
    }

    @Test fun visioRandomLayoutKeepsEveryBoxAndOrder() {
        val r = Random(9)
        repeat(100) {
            val n = r.nextInt(1, 15)
            val ys = List(n) { r.nextInt(1, 40).toDouble() }
            val xml = "<P><Shapes>" + ys.mapIndexed { i, y -> "<Shape ID=\"$i\"><Cell N=\"PinX\" V=\"${i + 1}\"/><Cell N=\"PinY\" V=\"$y\"/><Cell N=\"Width\" V=\"1\"/><Cell N=\"Height\" V=\"1\"/><Text>T$i</Text></Shape>" }.joinToString("") + "</Shapes></P>"
            val d = DocVisual.parseVisio(xml.toByteArray())!!
            assertEquals(n, d.boxes.size)
            for (i in 0 until n) for (j in 0 until n) {
                val a = d.boxes.first { it.text == "T$i" }; val b = d.boxes.first { it.text == "T$j" }
                if (ys[i] > ys[j]) assertTrue(a.y < b.y)
            }
            assertTrue(d.boxes.all { it.y >= -1e-9 && it.y + it.h <= d.h + 1e-9 })
        }
    }

    @Test fun resolveNeverEscapesRoot() {
        val r = Random(11)
        val parts = listOf("..", ".", "a", "media", "x.png", "")
        repeat(500) { val t = List(r.nextInt(1, 7)) { parts[r.nextInt(parts.size)] }.joinToString("/"); val p = DocVisual.resolve("word/", t); assertTrue(p, !p.startsWith("..") && !p.contains("/../") && !p.startsWith("/")) }
    }
}
