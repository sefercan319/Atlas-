package com.odak.app

import com.odak.app.notes.Note
import com.odak.app.notes.NotePure
import com.odak.app.notes.Pt
import com.odak.app.notes.Stroke
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.54: not defteri saf mantığı. */
class NotePureTest {
    private fun sample() = Note(
        id = "n-1", title = "Başlık ğüşiöç İ", body = "satır1\nsatır2 \\ ters\n[ ] a\n[x] b", paper = 2, color = 0xFFFFF59D.toInt(),
        pinned = true, folder = "Ders", created = 100L, updated = 200L, trashedAt = 0L, locked = true,
        strokes = listOf(
            Stroke(0, 0, 4f, listOf(Pt(0.1f, 0.2f), Pt(0.5f, 0.6f), Pt(0.9f, 1.25f))),
            Stroke(1, 0xFFE53935.toInt(), 8f, listOf(Pt(0.3f, 0.3f)))
        )
    )

    @Test fun roundTripKeepsFields() {
        val a = sample(); val b = NotePure.decode(NotePure.encode(a))!!
        assertEquals(a.id, b.id); assertEquals(a.title, b.title); assertEquals(a.body, b.body)
        assertEquals(a.paper, b.paper); assertEquals(a.color, b.color); assertEquals(a.pinned, b.pinned)
        assertEquals(a.folder, b.folder); assertEquals(a.created, b.created); assertEquals(a.updated, b.updated)
        assertEquals(a.locked, b.locked); assertEquals(2, b.strokes.size)
    }
    @Test fun roundTripStrokePoints() {
        val b = NotePure.decode(NotePure.encode(sample()))!!
        assertEquals(3, b.strokes[0].pts.size); assertEquals(0.9f, b.strokes[0].pts[2].x, 0.001f); assertEquals(1.25f, b.strokes[0].pts[2].y, 0.001f)
        assertEquals(1, b.strokes[1].tool); assertEquals(0xFFE53935.toInt(), b.strokes[1].color); assertEquals(8f, b.strokes[1].width, 0.001f)
    }
    @Test fun decodeRejectsWrongMagic() { assertNull(NotePure.decode("XXX\nid=a")); assertNull(NotePure.decode("")) }
    @Test fun decodeIgnoresGarbageLines() { val n = NotePure.decode("ODN1\nid=abc\nfoo\n=bar\nS x y z\nS 0 1\ntitle=T")!!; assertEquals("abc", n.id); assertEquals("T", n.title); assertEquals(0, n.strokes.size) }
    @Test fun decodeDropsNaNPoints() { val n = NotePure.decode("ODN1\nS 0 0 4 NaN,1 0.5,0.5 Infinity,2")!!; assertEquals(1, n.strokes[0].pts.size) }
    @Test fun decodeRejectsBadId() { val n = NotePure.decode("ODN1\nid=../../etc")!!; assertFalse(n.id.contains("..")) }
    @Test fun decodeClampsPaper() { assertEquals(3, NotePure.decode("ODN1\npaper=99")!!.paper); assertEquals(0, NotePure.decode("ODN1\npaper=-4")!!.paper) }
    @Test fun decodeClampsTool() { assertEquals(2, NotePure.decode("ODN1\nS 9 0 4 0.1,0.1")!!.strokes[0].tool) }
    @Test fun decodeStrokeLimit() { val sb = StringBuilder("ODN1\n"); repeat(NotePure.MAX_STROKES + 50) { sb.append("S 0 0 4 0.1,0.1\n") }; assertEquals(NotePure.MAX_STROKES, NotePure.decode(sb.toString())!!.strokes.size) }
    @Test fun decodeEmptyStrokeSkipped() { assertEquals(0, NotePure.decode("ODN1\nS 0 0 4")!!.strokes.size) }
    @Test fun escRoundTrip() { for (s in listOf("", "a", "a\nb", "\\", "\\n", "a\\\nb", "ğü\n\n", "\\\\")) assertEquals(s, NotePure.unesc(NotePure.esc(s))) }
    @Test fun escDropsCarriageReturn() { assertEquals("ab", NotePure.esc("a\rb")) }
    @Test fun bodyNewlinesSurvive() { val n = NotePure.decode(NotePure.encode(Note(id = "x", body = "1\n2\n3")))!!; assertEquals("1\n2\n3", n.body) }
    @Test fun displayTitleFromBody() { assertEquals("ilk satır", NotePure.displayTitle(Note(body = "\n  ilk satır \nikinci"))) }
    @Test fun displayTitleStripsCheck() { assertEquals("süt al", NotePure.displayTitle(Note(body = "[ ] süt al"))) }
    @Test fun displayTitlePrefersTitle() { assertEquals("T", NotePure.displayTitle(Note(title = " T ", body = "x"))) }
    @Test fun displayTitleEmpty() { assertEquals("", NotePure.displayTitle(Note())) }
    @Test fun matchesTitleBodyFolder() {
        val n = Note(title = "Alışveriş", body = "süt yumurta", folder = "Ev")
        assertTrue(NotePure.matches(n, "alış")); assertTrue(NotePure.matches(n, "YUMURTA")); assertTrue(NotePure.matches(n, "ev")); assertFalse(NotePure.matches(n, "xyz"))
    }
    @Test fun matchesBlankQueryAll() { assertTrue(NotePure.matches(Note(), "  ")) }
    @Test fun lockedBodyNotSearchable() { val n = Note(title = "Gizli", body = "şifre 1234", locked = true); assertFalse(NotePure.matches(n, "1234")); assertTrue(NotePure.matches(n, "gizli")) }
    @Test fun sortedPinnedFirst() { val l = listOf(Note(id = "a", updated = 9), Note(id = "b", updated = 1, pinned = true)); assertEquals("b", NotePure.sorted(l, 0)[0].id) }
    @Test fun sortedByUpdated() { val l = listOf(Note(id = "a", updated = 1), Note(id = "b", updated = 5)); assertEquals(listOf("b", "a"), NotePure.sorted(l, 0).map { it.id }) }
    @Test fun sortedByCreated() { val l = listOf(Note(id = "a", created = 1, updated = 9), Note(id = "b", created = 5, updated = 1)); assertEquals(listOf("b", "a"), NotePure.sorted(l, 1).map { it.id }) }
    @Test fun sortedByTitle() { val l = listOf(Note(id = "a", title = "b"), Note(id = "b", title = "A")); assertEquals(listOf("b", "a"), NotePure.sorted(l, 2).map { it.id }) }
    @Test fun visibleHidesTrash() { val l = listOf(Note(id = "a"), Note(id = "b", trashedAt = 5)); assertEquals(listOf("a"), NotePure.visible(l, null, false, "").map { it.id }); assertEquals(listOf("b"), NotePure.visible(l, null, true, "").map { it.id }) }
    @Test fun visibleFolderFilter() { val l = listOf(Note(id = "a", folder = "X"), Note(id = "b"), Note(id = "c", folder = "Y")); assertEquals(listOf("a"), NotePure.visible(l, "X", false, "").map { it.id }); assertEquals(listOf("b"), NotePure.visible(l, "", false, "").map { it.id }) }
    @Test fun foldersDistinctSorted() { val l = listOf(Note(folder = "b"), Note(folder = "A"), Note(folder = "b"), Note(folder = ""), Note(folder = "z", trashedAt = 4)); assertEquals(listOf("A", "b"), NotePure.folders(l)) }
    @Test fun cleanFolderTrimsAndCaps() { assertEquals("a b", NotePure.cleanFolder("  a\nb ")); assertEquals(30, NotePure.cleanFolder("x".repeat(50)).length) }
    @Test fun expiredAfter30Days() { val d = 86_400_000L; assertTrue(NotePure.isExpired(Note(trashedAt = 1), 1 + 31 * d)); assertFalse(NotePure.isExpired(Note(trashedAt = 1), 1 + 29 * d)); assertFalse(NotePure.isExpired(Note(trashedAt = 0), 99 * d)) }
    @Test fun daysLeftCounts() { val d = 86_400_000L; assertEquals(30, NotePure.daysLeft(Note(trashedAt = 10), 10)); assertEquals(20, NotePure.daysLeft(Note(trashedAt = 10), 10 + 10 * d)); assertEquals(0, NotePure.daysLeft(Note(trashedAt = 10), 10 + 99 * d)) }
    @Test fun wordCountWorks() { assertEquals(3, NotePure.wordCount(" a  b\nc ")); assertEquals(0, NotePure.wordCount("   ")) }
    @Test fun toggleCheckBothWays() { assertEquals("[x] a\nb", NotePure.toggleCheck("[ ] a\nb", 0)); assertEquals("[ ] a", NotePure.toggleCheck("[x] a", 0)) }
    @Test fun toggleCheckIgnoresPlainAndRange() { assertEquals("a", NotePure.toggleCheck("a", 0)); assertEquals("a", NotePure.toggleCheck("a", 5)); assertEquals("a", NotePure.toggleCheck("a", -1)) }
    @Test fun addCheckLineForms() { assertEquals("[ ] ", NotePure.addCheckLine("")); assertEquals("x\n[ ] ", NotePure.addCheckLine("x")); assertEquals("x\n[ ] ", NotePure.addCheckLine("x\n")) }
    @Test fun checkCountsWork() { assertEquals(1 to 3, NotePure.checkCounts("[x] a\n[ ] b\n[ ] c\ntext")); assertEquals(0 to 0, NotePure.checkCounts("hi")) }
    @Test fun simplifyKeepsEnds() { val p = (0..100).map { Pt(it * 0.0001f, 0f) }; val s = NotePure.simplify(p, 0.001f); assertEquals(p.first(), s.first()); assertEquals(p.last(), s.last()); assertTrue(s.size < p.size) }
    @Test fun simplifyShortUnchanged() { val p = listOf(Pt(0f, 0f), Pt(1f, 1f)); assertEquals(p, NotePure.simplify(p, 5f)) }
    @Test fun segDistBasics() { assertEquals(1f, NotePure.segDist(0.5f, 1f, Pt(0f, 0f), Pt(1f, 0f)), 0.0001f); assertEquals(0.5f, NotePure.segDist(-0.5f, 0f, Pt(0f, 0f), Pt(1f, 0f)), 0.0001f); assertEquals(0f, NotePure.segDist(0.3f, 0f, Pt(0f, 0f), Pt(1f, 0f)), 0.0001f) }
    @Test fun segDistDegenerate() { assertEquals(5f, NotePure.segDist(3f, 4f, Pt(0f, 0f), Pt(0f, 0f)), 0.0001f) }
    @Test fun strokeHitSinglePoint() { val s = Stroke(0, 0, 4f, listOf(Pt(0.5f, 0.5f))); assertTrue(NotePure.strokeHit(s, 0.51f, 0.5f, 0.02f)); assertFalse(NotePure.strokeHit(s, 0.9f, 0.9f, 0.02f)) }
    @Test fun eraseRemovesTouchedOnly() {
        val a = Stroke(0, 0, 4f, listOf(Pt(0f, 0f), Pt(1f, 0f))); val b = Stroke(0, 0, 4f, listOf(Pt(0f, 1f), Pt(1f, 1f)))
        val r = NotePure.eraseAt(listOf(a, b), 0.5f, 0.01f, 0.02f); assertEquals(listOf(b), r)
    }
    @Test fun eraseNothingKeepsSameList() { val a = Stroke(0, 0, 4f, listOf(Pt(0f, 0f), Pt(1f, 0f))); assertEquals(1, NotePure.eraseAt(listOf(a), 0.5f, 0.5f, 0.02f).size) }
    @Test fun pageHeightGrows() { assertEquals(1.4f, NotePure.pageHeight(emptyList()), 0.001f); assertEquals(3.1f, NotePure.pageHeight(listOf(Stroke(0, 0, 4f, listOf(Pt(0f, 2.5f))))), 0.001f) }
    @Test fun alphaAndWidthByTool() { assertEquals(0.35f, NotePure.strokeAlpha(1), 0.001f); assertEquals(1f, NotePure.strokeAlpha(0), 0.001f); assertEquals(12f, NotePure.effWidth(1, 4f), 0.001f); assertEquals(4f, NotePure.effWidth(0, 4f), 0.001f) }
    @Test fun historyUndoRedo() {
        val h = NotePure.History<Int>(); h.push(1); h.push(2)
        assertEquals(2, h.undo(3)); assertEquals(1, h.undo(2)); assertNull(h.undo(1)); assertEquals(2, h.redo(1)); assertEquals(3, h.redo(2)); assertFalse(h.canRedo())
    }
    @Test fun historyPushClearsRedo() { val h = NotePure.History<Int>(); h.push(1); h.undo(2); assertTrue(h.canRedo()); h.push(5); assertFalse(h.canRedo()) }
    @Test fun historyLimit() { val h = NotePure.History<Int>(3); for (i in 1..10) h.push(i); var n = 0; var c = 0; while (h.undo(c) != null) n++; assertEquals(3, n) }
    @Test fun exportTextForms() { assertEquals("T\n\nbody", NotePure.exportText(Note(title = "T", body = "body"))); assertEquals("body", NotePure.exportText(Note(body = "body"))) }

    // ---- kaynak/kaynak kaynakları
    private fun code(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    @Test fun manifestRegistersNotes() { assertTrue(File(TestFiles.main, "AndroidManifest.xml").readText().contains(".notes.NotesActivity")) }
    @Test fun settingsLaunchesNotes() { assertTrue(code("settings/MoreCards.kt").contains("NotesActivity::class.java")); assertTrue(code("settings/SettingsScreen.kt").contains("NotesCard()")) }
    @Test fun hubReusesDocsCard() { assertTrue(code("notes/NotesActivity.kt").contains("DocsCard()")) }
    @Test fun allNotesStringsExistEverywhere() {
        val used = TestFiles.kotlinSources().flatMap { Regex("""R\.string\.(notes_\w+)""").findAll(it.readText()).map { m -> m.groupValues[1] }.toList() }.toSet()
        assertTrue(used.size >= 30)
        for ((lang, f) in TestFiles.stringFiles()) { val m = TestFiles.parseStrings(f); for (k in used) assertTrue("$lang eksik: $k", m.containsKey(k)) }
    }
    @Test fun storeUsesAtomicWriteAndSafeId() { val s = code("notes/NoteStore.kt"); assertTrue(s.contains("renameTo")); assertTrue(s.contains("safeId")) }
    @Test fun editorAutosaves() { assertTrue(code("notes/NoteEditor.kt").contains("LaunchedEffect(title, body, strokes")) }
    @Test fun editorPinGateForLocked() { assertTrue(code("notes/NotesList.kt").contains("PinGate")) }
}
