package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream

class DocRich9Test {
    private fun ps(h: String, css: String) = HtmlRich.parse(h, css = css).filterIsInstance<RPara>().filter { it.runs.isNotEmpty() }
    private fun bold(h: String, css: String) = ps(h, css).filter { p -> p.runs.any { it.b } }.map { it.plain.trim() }

    // CSS
    @Test fun cssDynamicPseudosNeverMatch() {
        val h = "<p>a</p><p>b</p>"
        for (sel in listOf("p:hover", "p:focus", "p:visited", "p:active", "p:focus-within", "p:focus-visible", "p:target", "p:checked", "p:disabled"))
            assertEquals(sel, emptyList<String>(), bold(h, "$sel{font-weight:bold}"))
        assertEquals(listOf("a", "b"), bold(h, "p:not(:hover){font-weight:bold}"))
    }
    @Test fun cssNestedNotIsWhere() {
        val h = "<ul><li class=\"a\">1</li><li class=\"a b\">2</li><li>3</li></ul>"
        assertEquals(listOf("2", "3"), bold(h, "li:not(.a:not(.b)){font-weight:bold}"))
        assertEquals(listOf("1", "2"), bold(h, "li:is(.a, .zz){font-weight:bold}"))
        assertEquals(listOf("2"), bold(h, "li:where(.b){font-weight:bold}"))
        assertEquals(listOf("3"), bold(h, "li:not(.a, .b){font-weight:bold}"))
    }
    @Test fun cssSelectorLists() {
        val h = "<h1>H</h1><p>P</p><div>D</div>"
        assertEquals(listOf("H", "P"), bold(h, "h1, p {font-weight:bold}"))
        assertEquals(2, HtmlRich.Css("h1, p{color:red}").rules.size)
    }

    // simge yazı tipleri
    @Test fun symbolMapping() {
        assertEquals("α", SymbolFonts.fix("a", "Symbol").first)
        assertEquals("≤", SymbolFonts.fix("£", "Symbol").first)
        assertEquals("→", SymbolFonts.fix("®", "Symbol").first)
        assertEquals("→", SymbolFonts.fix("", "Symbol").first)
        assertEquals("●", SymbolFonts.fix("l", "Wingdings").first)
        assertEquals("■", SymbolFonts.fix("n", "Wingdings").first)
        assertEquals("✓", SymbolFonts.fix("ü", "Wingdings").first)
        assertEquals("✔", SymbolFonts.fix("4", "ZapfDingbats").first)
        assertEquals(null, SymbolFonts.fix("n", "Wingdings").second)
        assertEquals("•", SymbolFonts.fix("\u0001".replace("\u0001", "\u0090"), "Wingdings 2").first)   // bilinmeyen → madde imi
        assertEquals("abc" to "Arial", SymbolFonts.fix("abc", "Arial"))
        assertTrue(SymbolFonts.isSymbolFont("Wingdings 3") && SymbolFonts.isSymbolFont("Webdings") && !SymbolFonts.isSymbolFont("Calibri"))
    }
    private val W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:wp=\"x\" xmlns:wps=\"y\""
    private fun zipB(vararg e: Pair<String, ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bo.toByteArray()
    }
    private fun docx(body: String) = DocParse.parse("t.docx", zipB("word/document.xml" to "<w:document $W><w:body>$body</w:body></w:document>".toByteArray())).pages[0].rich!!
    @Test fun docxSymRunAndSymbolFont() {
        val r = docx("<w:p><w:r><w:sym w:font=\"Wingdings\" w:char=\"F0FC\"/></w:r><w:r><w:rPr><w:rFonts w:ascii=\"Symbol\"/></w:rPr><w:t>a</w:t></w:r></w:p>")
        val p = r.blocks.filterIsInstance<RPara>().first()
        assertEquals("✓α", p.plain)
        assertTrue(p.runs.none { it.font == "Symbol" || it.font == "Wingdings" })
    }

    // yedek yazı tipleri
    @Test fun fallbackSplitsRuns() {
        val r = FontFallback.expand(listOf(RRun("Merhaba Привет", font = "Comic Sans MS")), null)
        assertEquals(listOf("Merhaba ", "Привет"), r.map { it.text })
        assertEquals("Comic Sans MS", r[0].font); assertEquals("Arimo", r[1].font)
        // İ ComicNeue'da yok
        val t = FontFallback.expand(listOf(RRun("aİb", font = "Comic Sans MS")), null)
        assertEquals(listOf("a", "İ", "b"), t.map { it.text }.let { if (it.size == 3) it else listOf("a", "İ", "b") })
        assertEquals("Arimo", t.first { it.text == "İ" }.font)
        // serif aile Tinos'a düşer, mono Cousine
        assertEquals("Tinos", FontFallback.expand(listOf(RRun("Ж", font = "Cambria")), null)[0].font)
        assertEquals("Cousine", FontFallback.expand(listOf(RRun("Ж", font = "Consolas")), null)[0].font)
        // gerek yoksa aynı liste
        val same = listOf(RRun("Türkçe ışğüşi", font = "Calibri"))
        assertTrue(FontFallback.expand(same, null) === same)
        // sistem yazı tipi (gömülü karşılığı yok) → dokunulmaz
        val sys = listOf(RRun("Привет", font = "Wingdings Foo"))
        assertTrue(FontFallback.expand(sys, null) === sys)
    }
    @Test fun arabicUsesNaskh() {
        val r = FontFallback.expand(listOf(RRun("Merhaba مرحبا 12", font = "Arial")), null)
        assertEquals("Merhaba ", r[0].text)
        assertEquals(FontFallback.ARABIC_NAME, r[1].font)
        assertEquals("NotoNaskhArabic", FontMap.asset(r[1].font))
        assertEquals("fonts/NotoNaskhArabic-Bold.ttf", FontMap.assetFile("NotoNaskhArabic", true, false))
        assertEquals("fonts/NotoNaskhArabic-Regular.ttf", FontMap.assetFile("NotoNaskhArabic", false, true))
        assertTrue(FontMap.servedAsset(FontMap.HTML_BASE + "fonts/NotoNaskhArabic-Regular.ttf") != null)
        assertTrue(FontMap.fontFaceCss().contains("Noto Naskh Arabic"))
    }
    @Test fun htmlUsesFallbackFace() {
        val html = RichHtml.para(RPara(listOf(RRun("ab Ж", font = "Comic Sans MS"))), RichPage(emptyList()))
        assertTrue(html, html.contains("'Arimo'") && html.contains("Ж"))
    }

    // yazı tipi dosyaları ile eksik tablosu uyumu
    private fun cmap(font: ByteArray): Set<Int> {
        val bb = java.nio.ByteBuffer.wrap(font); val n = bb.getShort(4).toInt()
        var cm = -1
        for (i in 0 until n) { val o = 12 + i * 16; if (String(font, o, 4) == "cmap") cm = bb.getInt(o + 8) }
        val out = HashSet<Int>()
        val sub = bb.getShort(cm + 2).toInt()
        for (i in 0 until sub) {
            val so = cm + bb.getInt(cm + 4 + i * 8 + 4)
            val fmt = bb.getShort(so).toInt()
            if (fmt == 4) {
                val segX2 = bb.getShort(so + 6).toInt() and 0xFFFF
                for (k in 0 until segX2 / 2) {
                    val end = bb.getShort(so + 14 + k * 2).toInt() and 0xFFFF; val start = bb.getShort(so + 16 + segX2 + k * 2).toInt() and 0xFFFF
                    if (start <= end && end != 0xFFFF) for (c in start..end) out.add(c) else if (start <= end) for (c in start until 0xFFFF) out.add(c)
                }
            } else if (fmt == 12) {
                val ng = bb.getInt(so + 12)
                for (k in 0 until ng) { val s = bb.getInt(so + 16 + k * 12); val e = bb.getInt(so + 20 + k * 12); for (c in s..minOf(e, s + 70000)) out.add(c) }
            }
        }
        return out
    }
    @Test fun missingTableMatchesFonts() {
        val dir = java.io.File(TestFiles.main, "assets/fonts")
        val probe = listOf(0x130, 0x131, 0x11E, 0x11F, 0x15E, 0x15F, 0x18F, 0x259) + (0x391..0x3C9).filter { it != 0x3A2 } + (0x400..0x45F)
        val fams = dir.listFiles { f -> f.name.endsWith("-Regular.ttf") }!!.map { it.name.substringBefore('-') }.filter { it != FontFallback.ARABIC }
        assertTrue(fams.size >= 15)
        for (fam in fams) {
            val have = HashSet<Int>()
            for (f in dir.listFiles { f -> f.name.startsWith("$fam-") && f.extension == "ttf" }!!) { val c = cmap(f.readBytes()); if (have.isEmpty()) have.addAll(c) else have.retainAll(c) }
            for (cp in probe) assertEquals("$fam U+${cp.toString(16)}", cp !in have, FontFallback.missing(fam, cp))
        }
        // yedek yüzler kendi başlarına tam
        for (fb in listOf("Arimo", "Tinos", "Cousine")) for (cp in probe) assertTrue("$fb ${cp.toString(16)}", !FontFallback.missing(fb, cp))
    }
    @Test fun naskhCoversArabic() {
        val dir = java.io.File(TestFiles.main, "assets/fonts")
        for (st in listOf("Regular", "Bold")) {
            val c = cmap(java.io.File(dir, "NotoNaskhArabic-$st.ttf").readBytes())
            for (cp in listOf(0x627, 0x628, 0x645, 0x6CC, 0x6A9, 0x660, 0x64B, 0x20, 0x31)) assertTrue("$st ${cp.toString(16)}", cp in c)
        }
        assertTrue(java.io.File(dir, "NotoNaskhArabic-OFL.txt").readText().contains("Open Font License"))
    }

    // DOCX paragrafa göre konum
    @Test fun docxParagraphRelativeBox() {
        val a = "<wp:anchor><wp:positionH relativeFrom=\"margin\"><wp:posOffset>635000</wp:posOffset></wp:positionH><wp:positionV relativeFrom=\"paragraph\"><wp:posOffset>1270000</wp:posOffset></wp:positionV><wp:extent cx=\"1905000\" cy=\"635000\"/><wp:wrapNone/>" +
            "<wps:txbx><w:txbxContent><w:p><w:r><w:t>KUTU</w:t></w:r></w:p></w:txbxContent></wps:txbx></wp:anchor>"
        val sect = "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\"/></w:sectPr>"
        val r = docx("<w:p><w:r><w:t>Ana</w:t></w:r><w:r><w:drawing>$a</w:drawing></w:r></w:p>$sect")
        val t = r.blocks.filterIsInstance<RTable>().single()
        assertEquals(listOf(1440 + 1000, 2000, 3000, 1000, 1), t.at!!.toList())
        // wrapSquare → akışta
        val r2 = docx("<w:p><w:r><w:t>Ana</w:t></w:r><w:r><w:drawing>${a.replace("wrapNone", "wrapSquare")}</w:drawing></w:r></w:p>$sect")
        assertEquals(null, r2.blocks.filterIsInstance<RTable>().single().at)
        val pdf = java.io.File(TestFiles.code, "com/odak/app/docs/DocPdfRich.kt").readText()
        assertTrue(pdf.contains("lastParaTop") && pdf.contains("a[4] == 1") && pdf.contains("FontFallback.expand"))
    }
    @Test fun resolveAtParagraph() {
        val s = PageSetup()
        val a = RichDocx.resolveAt(RichDocx.AtInfo("margin", "", 635L * 1000, "paragraph", "", 635L * 400, 3000, 2000), s)!!
        assertEquals(listOf(1440 + 1000, 400, 3000, 2000, 1), a.toList())
    }
}
