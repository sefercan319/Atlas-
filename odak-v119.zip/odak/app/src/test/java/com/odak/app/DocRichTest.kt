package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** v0.56.39: biçim koruyan dönüştürme, Tam görünüm, 6 yeni tür (CSV, Markdown, vCard, iCalendar, MBOX, OpenOffice/düz ODF). */
class DocRichTest {
    private fun zip(vararg e: Pair<String, String>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(ZipEntry(n)); z.write(b.toByteArray()); z.closeEntry() } }
        return bo.toByteArray()
    }
    private fun unzip(b: ByteArray): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        ZipInputStream(b.inputStream()).use { z -> while (true) { val e = z.nextEntry ?: break; m[e.name] = String(z.readBytes()) } }
        return m
    }
    private val W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\""
    private fun docx(body: String, extra: List<Pair<String, String>> = emptyList()) =
        zip("word/document.xml" to "<w:document $W><w:body>$body</w:body></w:document>", *extra.toTypedArray())

    private val SAMPLE = "<w:p><w:pPr><w:jc w:val=\"center\"/><w:spacing w:before=\"120\" w:after=\"240\"/></w:pPr>" +
        "<w:r><w:rPr><w:b/><w:i/><w:color w:val=\"CC0000\"/><w:sz w:val=\"32\"/></w:rPr><w:t>Kalın</w:t></w:r><w:r><w:rPr><w:u w:val=\"single\"/></w:rPr><w:t xml:space=\"preserve\"> alt</w:t></w:r></w:p>" +
        "<w:tbl><w:tblPr><w:tblBorders><w:top w:val=\"single\" w:sz=\"8\" w:color=\"112233\"/><w:left w:val=\"single\" w:sz=\"8\"/><w:bottom w:val=\"single\" w:sz=\"8\"/><w:right w:val=\"single\" w:sz=\"8\"/><w:insideH w:val=\"single\" w:sz=\"4\"/><w:insideV w:val=\"single\" w:sz=\"4\"/></w:tblBorders></w:tblPr>" +
        "<w:tblGrid><w:gridCol w:w=\"3000\"/><w:gridCol w:w=\"3000\"/></w:tblGrid>" +
        "<w:tr><w:tc><w:tcPr><w:gridSpan w:val=\"2\"/><w:shd w:val=\"clear\" w:fill=\"FFE699\"/></w:tcPr><w:p><w:r><w:t>Birleşik</w:t></w:r></w:p></w:tc></w:tr>" +
        "<w:tr><w:tc><w:tcPr><w:vMerge w:val=\"restart\"/></w:tcPr><w:p><w:r><w:t>A</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>B</w:t></w:r></w:p></w:tc></w:tr>" +
        "<w:tr><w:tc><w:tcPr><w:vMerge/></w:tcPr><w:p/></w:tc><w:tc><w:p><w:r><w:t>C</w:t></w:r></w:p></w:tc></w:tr></w:tbl>" +
        "<w:sectPr><w:pgSz w:w=\"16838\" w:h=\"11906\" w:orient=\"landscape\"/><w:pgMar w:top=\"700\" w:right=\"800\" w:bottom=\"900\" w:left=\"1000\"/></w:sectPr>"

    private fun rich(): RichPage = DocParse.parse("a.docx", docx(SAMPLE)).pages[0].rich!!

    // ---- DOCX okuma
    @Test fun docxKeepsRunFormatting() {
        val p = rich().blocks[0] as RPara
        assertEquals("center", p.align)
        assertEquals(120, p.before); assertEquals(240, p.after)
        val r = p.runs[0]
        assertTrue(r.b && r.i); assertEquals("CC0000", r.color); assertEquals(32, r.sz)
        assertTrue(p.runs[1].u); assertFalse(p.runs[1].b)
    }
    @Test fun docxKeepsPageSetup() {
        val s = rich().setup
        assertEquals(16838, s.w); assertEquals(11906, s.h); assertTrue(s.landscape)
        assertEquals(700, s.top); assertEquals(1000, s.left)
    }
    @Test fun docxTableBordersFillAndMerges() {
        val t = rich().blocks[1] as RTable
        assertEquals(listOf(3000, 3000), t.cols)
        val c0 = t.rows[0][0]
        assertEquals(2, c0.span); assertEquals("FFE699", c0.fill)
        assertEquals("112233", c0.bt!!.color)      // dış üst çizgi
        assertNotNull(c0.bl); assertNotNull(c0.br)
        assertEquals(1, t.rows[1][0].vMerge); assertEquals(2, t.rows[2][0].vMerge)
        assertNotNull(t.rows[1][0].bt)             // iç yatay çizgi
        assertEquals(4, t.rows[1][0].bt!!.w)
    }
    @Test fun docxWithoutBordersHasNoLines() {
        val d = DocParse.parse("a.docx", docx("<w:tbl><w:tblGrid><w:gridCol w:w=\"1000\"/></w:tblGrid><w:tr><w:tc><w:p><w:r><w:t>x</w:t></w:r></w:p></w:tc></w:tr></w:tbl>"))
        val c = (d.pages[0].rich!!.blocks[0] as RTable).rows[0][0]
        assertTrue(c.bt == null && c.bl == null && c.bb == null && c.br == null)
    }
    @Test fun docxStylesHeadingsAndLists() {
        val styles = "<w:styles $W><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"Arial\"/><w:sz w:val=\"20\"/></w:rPr></w:rPrDefault></w:docDefaults>" +
            "<w:style w:type=\"paragraph\" w:styleId=\"Heading1\"><w:name w:val=\"heading 1\"/><w:pPr><w:pBdr><w:bottom w:val=\"single\" w:sz=\"6\" w:color=\"336699\"/></w:pBdr></w:pPr><w:rPr><w:b/><w:sz w:val=\"36\"/><w:color w:val=\"336699\"/></w:rPr></w:style></w:styles>"
        val num = "<w:numbering $W><w:abstractNum w:abstractNumId=\"0\"><w:lvl w:ilvl=\"0\"><w:numFmt w:val=\"decimal\"/><w:lvlText w:val=\"%1.\"/><w:pPr><w:ind w:left=\"720\" w:hanging=\"360\"/></w:pPr></w:lvl></w:abstractNum><w:num w:numId=\"1\"><w:abstractNumId w:val=\"0\"/></w:num></w:numbering>"
        val body = "<w:p><w:pPr><w:pStyle w:val=\"Heading1\"/></w:pPr><w:r><w:t>Başlık</w:t></w:r></w:p>" +
            "<w:p><w:pPr><w:numPr><w:ilvl w:val=\"0\"/><w:numId w:val=\"1\"/></w:numPr></w:pPr><w:r><w:t>bir</w:t></w:r></w:p>" +
            "<w:p><w:pPr><w:numPr><w:ilvl w:val=\"0\"/><w:numId w:val=\"1\"/></w:numPr></w:pPr><w:r><w:t>iki</w:t></w:r></w:p>"
        val rp = DocParse.parse("a.docx", docx(body, listOf("word/styles.xml" to styles, "word/numbering.xml" to num))).pages[0].rich!!
        val h = rp.blocks[0] as RPara
        assertEquals(1, h.head); assertTrue(h.runs[0].b); assertEquals(36, h.runs[0].sz); assertEquals("336699", h.runs[0].color); assertNotNull(h.bottom)
        assertEquals(20, rp.defSz); assertEquals("Arial", rp.defFont)
        assertEquals("1.", (rp.blocks[1] as RPara).marker); assertEquals("2.", (rp.blocks[2] as RPara).marker)
        assertEquals(720, (rp.blocks[1] as RPara).left); assertEquals(-360, (rp.blocks[1] as RPara).first)
    }
    @Test fun docxPlainTextUnchanged() {
        val d = DocParse.parse("a.docx", docx(SAMPLE))
        assertEquals("Kalın alt", d.pages[0].paragraphs[0])
        assertTrue(d.pages[0].paragraphs.contains("Birleşik"))
    }
    @Test fun brokenDocxStillOpens() {
        val d = DocParse.parse("a.docx", docx("<w:p><w:r><w:t>x</w:t></w:r></w:p>"))
        assertEquals(listOf("x"), d.pages[0].paragraphs)
    }

    // ---- HTML
    @Test fun htmlKeepsStylesAndTable() {
        val h = DocWrite.html(DocParse.parse("a.docx", docx(SAMPLE)))
        assertTrue(h.contains("font-weight:bold")); assertTrue(h.contains("font-style:italic")); assertTrue(h.contains("color:#CC0000"))
        assertTrue(h.contains("text-align:center")); assertTrue(h.contains("text-decoration:underline"))
        assertTrue(h.contains("colspan=2")); assertTrue(h.contains("rowspan=2")); assertTrue(h.contains("background:#FFE699"))
        assertTrue(h.contains("border-top:1.0pt solid #112233"))
        assertTrue(h.contains("max-width:841.9pt"))
    }
    @Test fun htmlEscapesText() {
        val d = DocParse.parse("a.docx", docx("<w:p><w:r><w:t>&lt;script&gt;x&lt;/script&gt;</w:t></w:r></w:p>"))
        val h = DocWrite.html(d)
        assertFalse(h.contains("<script>")); assertTrue(h.contains("&lt;script&gt;"))
    }
    @Test fun htmlLinksOnlySafeSchemes() {
        val rp = RichPage(listOf(RPara(listOf(RRun("a", href = "javascript:alert(1)"), RRun("b", href = "https://x.y")))))
        val h = RichHtml.page(rp)
        assertFalse(h.contains("javascript:")); assertTrue(h.contains("href=\"https://x.y\""))
    }

    // ---- Yazıcılar: DOCX / RTF / ODT geri okunabilir
    @Test fun docxRoundTripKeepsFormatting() {
        val out = DocWrite.write(DocParse.parse("a.docx", docx(SAMPLE)), ConvTarget.DOCX)!!
        val back = DocParse.parse("b.docx", out).pages[0].rich!!
        val p = back.blocks[0] as RPara
        assertTrue(p.runs[0].b && p.runs[0].i); assertEquals("CC0000", p.runs[0].color); assertEquals("center", p.align)
        val t = back.blocks[1] as RTable
        assertEquals(2, t.rows[0][0].span); assertEquals("FFE699", t.rows[0][0].fill); assertEquals(1, t.rows[1][0].vMerge); assertEquals(2, t.rows[2][0].vMerge)
        assertNotNull(t.rows[0][0].bt)
        assertTrue(back.setup.landscape)
    }
    @Test fun docxWriterIsWellFormedXml() {
        val x = unzip(DocWrite.write(DocParse.parse("a.docx", docx(SAMPLE)), ConvTarget.DOCX)!!)["word/document.xml"]!!
        javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(x.byteInputStream())
        assertTrue(x.contains("<w:pgSz w:w=\"16838\" w:h=\"11906\" w:orient=\"landscape\"/>"))
    }
    @Test fun rtfCarriesFormatting() {
        val r = DocWrite.rtf(DocParse.parse("a.docx", docx(SAMPLE)))
        assertTrue(r.contains("\\b")); assertTrue(r.contains("\\i")); assertTrue(r.contains("\\ul")); assertTrue(r.contains("\\cf1"))
        assertTrue(r.contains("\\red204")); assertTrue(r.contains("\\qc")); assertTrue(r.contains("\\clcbpat")); assertTrue(r.contains("\\clvmgf")); assertTrue(r.contains("\\clvmrg"))
        assertTrue(r.contains("\\paperw16838\\paperh11906\\landscape"))
    }
    @Test fun odtRoundTripKeepsFormatting() {
        val out = DocWrite.write(DocParse.parse("a.docx", docx(SAMPLE)), ConvTarget.ODT)!!
        val x = unzip(out)
        javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(x["content.xml"]!!.byteInputStream())
        javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(x["styles.xml"]!!.byteInputStream())
        val back = DocParse.parse("b.odt", out).pages[0].rich!!
        val p = back.blocks[0] as RPara
        assertTrue(p.runs[0].b && p.runs[0].i); assertEquals("CC0000", p.runs[0].color); assertEquals("center", p.align)
        val t = back.blocks[1] as RTable
        assertEquals(2, t.rows[0][0].span); assertEquals("FFE699", t.rows[0][0].fill); assertEquals(1, t.rows[1][0].vMerge)
        assertNotNull(t.rows[0][0].bt)
        assertTrue(back.setup.landscape)
    }
    @Test fun plainPagesStillWriteWithoutRichPath() {
        val d = Doc(DocKind.TEXT, listOf(DocPage("", listOf("a", "b"))))
        for (t in listOf(ConvTarget.HTML, ConvTarget.DOCX, ConvTarget.RTF, ConvTarget.ODT)) assertNotNull(DocWrite.write(d, t))
    }
    @Test fun mixedPagesWriteBoth() {
        val rp = rich()
        val d = Doc(DocKind.DOCX, listOf(DocPage("", listOf("x"), null, null, rp), DocPage("S2", listOf("plain"))))
        assertTrue(DocWrite.html(d).contains("plain")); assertTrue(DocWrite.write(d, ConvTarget.DOCX)!!.isNotEmpty())
        assertTrue(DocWrite.write(d, ConvTarget.ODT)!!.isNotEmpty())
    }

    // ---- ODT / OpenOffice / düz ODF okuma
    private val ONS = "xmlns:office=\"urn:oasis:names:tc:opendocument:xmlns:office:1.0\" xmlns:text=\"urn:oasis:names:tc:opendocument:xmlns:text:1.0\" xmlns:style=\"urn:oasis:names:tc:opendocument:xmlns:style:1.0\" xmlns:fo=\"urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0\" xmlns:table=\"urn:oasis:names:tc:opendocument:xmlns:table:1.0\""
    private val ODT_BODY = "<office:automatic-styles><style:style style:name=\"T1\" style:family=\"text\"><style:text-properties fo:font-weight=\"bold\" fo:color=\"#FF0000\"/></style:style>" +
        "<style:style style:name=\"P1\" style:family=\"paragraph\"><style:paragraph-properties fo:text-align=\"center\"/></style:style></office:automatic-styles>" +
        "<office:body><office:text><text:p text:style-name=\"P1\">Merhaba <text:span text:style-name=\"T1\">dünya</text:span></text:p></office:text></office:body>"
    @Test fun odtReadsSpanAndAlign() {
        val c = "<office:document-content $ONS>$ODT_BODY</office:document-content>"
        val rp = DocParse.parse("a.odt", zip("mimetype" to "application/vnd.oasis.opendocument.text", "content.xml" to c)).pages[0].rich!!
        val p = rp.blocks[0] as RPara
        assertEquals("center", p.align)
        assertTrue(p.runs.any { it.text == "dünya" && it.b && it.color == "FF0000" })
    }
    @Test fun flatOdfIsReadable() {
        val c = "<office:document $ONS>$ODT_BODY</office:document>"
        val d = DocParse.parse("a.fodt", c.toByteArray())
        assertEquals(DocKind.ODT, d.kind); assertEquals(listOf("Merhaba dünya"), d.pages[0].paragraphs)
        assertTrue(d.pages[0].rich != null)
    }
    @Test fun openOffice1ZipIsRecognised() {
        val c = "<office:document-content $ONS>$ODT_BODY</office:document-content>"
        val d = DocParse.parse("a.sxw", zip("mimetype" to "application/vnd.sun.xml.writer", "content.xml" to c))
        assertEquals(DocKind.ODT, d.kind); assertEquals("Merhaba dünya", d.pages[0].paragraphs[0])
        for ((e, k) in mapOf("a.sxc" to DocKind.ODS, "a.sxi" to DocKind.ODP, "a.sxd" to DocKind.ODG, "a.fods" to DocKind.ODS, "a.fodp" to DocKind.ODP, "a.stw" to DocKind.ODT))
            assertEquals(e, k, DocParse.detect(e, ByteArray(8)))
    }
    @Test fun odfLengthsToTwips() {
        assertEquals(1417, RichOdt.twips("2.5cm")); assertEquals(240, RichOdt.twips("12pt")); assertEquals(1440, RichOdt.twips("1in")); assertEquals(null, RichOdt.twips("abc"))
    }

    // ---- Markdown
    @Test fun markdownHeadingsListsEmphasis() {
        val d = DocParse.parse("a.md", "# Başlık\n\nBu **kalın** ve *italik* ve `kod` ve ~~çizili~~.\n\n- bir\n- iki\n  - alt\n\n1. x\n2. y\n".toByteArray())
        assertEquals(DocKind.MARKDOWN, d.kind)
        val b = d.pages[0].rich!!.blocks.filterIsInstance<RPara>()
        assertEquals(1, b[0].head); assertTrue(b[0].runs[0].b)
        val para = b[1]
        assertTrue(para.runs.any { it.text == "kalın" && it.b }); assertTrue(para.runs.any { it.text == "italik" && it.i })
        assertTrue(para.runs.any { it.text == "kod" && it.font == "Courier New" }); assertTrue(para.runs.any { it.text == "çizili" && it.s })
        assertEquals(listOf("•", "•", "◦", "1.", "2."), b.filter { it.marker.isNotEmpty() }.map { it.marker })
    }
    @Test fun markdownTableCodeQuoteRuleLink() {
        val md = "| a | b |\n|---|:-:|\n| 1 | 2 |\n\n```\nx = 1\n```\n\n> alıntı\n\n---\n\n[site](https://e.com) snake_case_word\n"
        val rp = DocMore2.mdRich(md)
        val t = rp.blocks.filterIsInstance<RTable>().single()
        assertEquals(2, t.rows.size); assertTrue(t.rows[0][0].paras[0].runs[0].b); assertNotNull(t.rows[1][1].bt)
        assertTrue(rp.blocks.any { it is RPara && it.fill == "F2F2F2" && it.plain == "x = 1" })
        assertTrue(rp.blocks.any { it is RPara && it.plain == "alıntı" && it.left > 0 })
        assertTrue(rp.blocks.any { it is RPara && it.runs.isEmpty() && it.bottom != null })
        val link = rp.blocks.filterIsInstance<RPara>().last().runs.first { it.href != null }
        assertEquals("https://e.com", link.href); assertTrue(link.u)
        assertEquals("snake_case_word", rp.blocks.filterIsInstance<RPara>().last().plain.substringAfter("site "))
    }
    @Test fun markdownSetextAndTaskList() {
        val rp = DocMore2.mdRich("Üst\n===\n\n- [x] bitti\n- [ ] açık\n")
        val ps = rp.blocks.filterIsInstance<RPara>()
        assertEquals(1, ps[0].head); assertEquals("☑", ps[1].marker); assertEquals("☐", ps[2].marker)
    }
    @Test fun markdownConvertsToFormattedDocx() {
        val d = DocParse.parse("a.md", "# T\n\n**b**".toByteArray())
        val back = DocParse.parse("b.docx", DocWrite.write(d, ConvTarget.DOCX)!!).pages[0].rich!!
        assertTrue((back.blocks[0] as RPara).runs[0].b); assertEquals(1 + 0, back.blocks.size.coerceAtMost(2) - 1)
        assertTrue(ConvTarget.MD !in DocConvert.targetsFor(DocKind.MARKDOWN, true))
    }

    // ---- CSV
    @Test fun csvDetectsDelimiterAndQuotes() {
        assertEquals(';', DocMore2.detectDelimiter("a;b;c\n1;2;3"))
        assertEquals('\t', DocMore2.detectDelimiter("a\tb\n1\t2"))
        val rows = DocMore2.parseCsv("ad,not\n\"Ali, V\",\"he said \"\"hi\"\"\"\nx,\"a\nb\"\n")
        assertEquals(listOf(listOf("ad", "not"), listOf("Ali, V", "he said \"hi\""), listOf("x", "a\nb")), rows)
    }
    @Test fun csvDocIsATableAndConverts() {
        val d = DocParse.parse("a.csv", "﻿a,b\n1,2\n3".toByteArray())
        assertEquals(DocKind.CSV, d.kind)
        assertEquals(listOf(listOf("a", "b"), listOf("1", "2"), listOf("3", "")), d.pages[0].table)
        assertTrue(ConvTarget.XLSX in DocConvert.targetsFor(DocKind.CSV, true)); assertFalse(ConvTarget.CSV in DocConvert.targetsFor(DocKind.CSV, true))
        assertNotNull(DocWrite.write(d, ConvTarget.XLSX))
    }
    @Test fun csvHandlesCrlfEmptyAndLimits() {
        assertEquals(0, DocParse.parse("a.csv", ByteArray(0)).pages.size)
        assertEquals(2, DocMore2.parseCsv("a,b\r\nc,d\r\n").size)
        val big = (1..5000).joinToString("\n") { "$it,x" }
        assertEquals(3000, DocMore2.parseCsv(big).size)
    }

    // ---- vCard
    @Test fun vcardContacts() {
        val v = "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:Ayşe Yılmaz\r\nORG:Acme;Satış\r\nTITLE:Müdür\r\nTEL;TYPE=CELL:+90 555 111\r\nTEL;TYPE=WORK:+90 212 222\r\nEMAIL:a@b.com\r\nADR;TYPE=HOME:;;Cadde 1;İstanbul;;34000;TR\r\nNOTE:Merhaba\\, dünya\r\nEND:VCARD\r\n" +
            "BEGIN:VCARD\r\nN:Kaya;Ali;;;\r\nTEL:123\r\nEND:VCARD\r\n"
        val d = DocParse.parse("k.vcf", v.toByteArray())
        assertEquals(DocKind.VCARD, d.kind)
        val t = d.pages[0].table!!
        assertEquals(3, t.size)
        assertEquals("Ayşe Yılmaz", t[1][0]); assertEquals("Acme, Satış — Müdür", t[1][1])
        assertTrue(t[1][2].contains("+90 555 111 (cell)") && t[1][2].contains("+90 212 222 (work)"))
        assertEquals("a@b.com", t[1][3]); assertEquals("Cadde 1, İstanbul, 34000, TR", t[1][4]); assertEquals("Merhaba, dünya", t[1][5])
        assertEquals("Ali Kaya", t[2][0])
    }
    @Test fun vcardFoldedAndQuotedPrintable() {
        val d = DocMore2.vcardDoc("BEGIN:VCARD\nFN:Uzun\n  Ad\nNOTE;ENCODING=QUOTED-PRINTABLE;CHARSET=UTF-8:=C4=B1r\nTEL:1\nEND:VCARD")
        val r = d.pages[0].table!![1]
        assertEquals("Uzun Ad", r[0]); assertEquals("ır", r[5])
    }
    @Test fun vcardEmptyIsEmpty() { assertEquals(0, DocMore2.vcardDoc("nothing").pages.size) }

    // ---- iCalendar
    @Test fun icalEventsSortedAndFormatted() {
        val c = "BEGIN:VCALENDAR\nBEGIN:VEVENT\nSUMMARY:İkinci\nDTSTART:20261102T140000Z\nEND:VEVENT\nBEGIN:VEVENT\nSUMMARY:Toplantı\\, haftalık\nDTSTART;TZID=Europe/Istanbul:20261026T093000\nDTEND:20261026T103000\nLOCATION:Ofis\nRRULE:FREQ=WEEKLY;BYDAY=MO\nEND:VEVENT\nBEGIN:VTODO\nSUMMARY:Yap\nDUE:20261030\nEND:VTODO\nEND:VCALENDAR"
        val d = DocParse.parse("t.ics", c.toByteArray())
        assertEquals(DocKind.ICAL, d.kind)
        val t = d.pages[0].table!!
        assertEquals(listOf("Type", "Title", "Start", "End", "Location", "Description", "Repeat"), t[0])
        assertEquals("Toplantı, haftalık", t[1][1]); assertEquals("2026-10-26 09:30", t[1][2]); assertEquals("2026-10-26 10:30", t[1][3]); assertEquals("Ofis", t[1][4]); assertEquals("WEEKLY BYDAY=MO", t[1][6])
        assertEquals("Task", t[2][0]); assertEquals("2026-10-30", t[2][2])
        assertEquals("2026-11-02 14:00 UTC", t[3][2])
    }
    @Test fun icalDateEdge() { assertEquals("x", DocMore2.icalDate("x")); assertEquals("2026-01-02", DocMore2.icalDate("20260102")) }

    // ---- MBOX
    @Test fun mboxSplitsMessages() {
        val m = "From a@b Mon Oct 26 10:00:00 2026\nSubject: Bir\nFrom: a@b\n\nMerhaba\n\nFrom c@d Mon Oct 26 11:00:00 2026\nSubject: İki\n\nGovde iki\n"
        val d = DocParse.parse("x.mbox", m.toByteArray())
        assertEquals(DocKind.MBOX, d.kind)
        assertEquals(2, d.pages.size)
        assertEquals("1. Bir", d.pages[0].title); assertTrue(d.pages[0].paragraphs.any { it.contains("Merhaba") })
        assertEquals("2. İki", d.pages[1].title)
    }
    @Test fun mboxEmptyAndNoFromLine() { assertEquals(0, DocParse.parse("x.mbox", ByteArray(0)).pages.size) }

    // ---- uzantı eşlemesi ve yönlendirme
    @Test fun newExtensionsMap() {
        val m = mapOf("a.csv" to DocKind.CSV, "a.tsv" to DocKind.CSV, "a.md" to DocKind.MARKDOWN, "a.markdown" to DocKind.MARKDOWN, "a.vcf" to DocKind.VCARD,
            "a.ics" to DocKind.ICAL, "a.mbox" to DocKind.MBOX)
        for ((n, k) in m) assertEquals(n, k, DocParse.detect(n, ByteArray(8)))
    }
    @Test fun manifestAcceptsNewMimeTypes() {
        val x = File(TestFiles.main, "AndroidManifest.xml").readText()
        for (t in listOf("text/csv", "text/tab-separated-values", "application/mbox", "application/vnd.sun.xml.writer", "text/x-markdown")) assertTrue(t, x.contains(t))
    }

    // ---- uygulama bağlantıları
    private fun src(n: String) = File(TestFiles.code, "com/odak/app/docs/$n").readText()
    @Test fun fullViewUsesSafeWebView() {
        val a = src("DocActivity.kt")
        assertTrue(a.contains("RichWebView(html)")); assertTrue(a.contains("javaScriptEnabled = false")); assertTrue(a.contains("allowFileAccess = false"))
        assertTrue(a.contains("shouldOverrideUrlLoading") ); assertTrue(a.contains("R.string.doc_full")); assertTrue(a.contains("R.string.doc_textview"))
        assertTrue(a.contains("R.string.conv_note_rich"))
    }
    @Test fun pdfWriterUsesRichPainter() {
        assertTrue(src("DocPdf.kt").contains("RichPdfPainter"))
        val p = src("DocPdfRich.kt"); assertTrue(p.contains("drawRect")); assertTrue(p.contains("Rich.rowSpan"))
    }
    @Test fun stringsExistInAllLocales() {
        for ((l, f) in TestFiles.stringFiles()) { val s = f.readText(); for (k in listOf("doc_full", "doc_textview", "conv_note_rich")) assertTrue("$l $k", s.contains("name=\"$k\"")) }
    }
    @Test fun plainHelpers() {
        val rp = rich()
        assertTrue(Rich.hasFormatting(rp)); assertTrue(Rich.plain(rp).contains("Birleşik"))
        assertFalse(Rich.hasFormatting(RichPage(listOf(RPara(listOf(RRun("düz")))))))
        assertEquals("12", Rich.pt(240)); assertEquals("0.5", Rich.pt(10))
        assertEquals("AABBCC", Rich.hex("#aabbcc")); assertEquals(null, Rich.hex("auto"))
    }
}
