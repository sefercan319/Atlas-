package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.36: okunamayan kayıt varsa ham veri yedeklenir (sessiz veri kaybı olmaz). */
class StoreSafetyTest {
    private fun code(rel: String) = File(TestFiles.code, "com/odak/app/$rel").readText()

    @Test fun planStoreBacksUpRawOnBadRecords() {
        val s = code("plan/PlanItem.kt").substringAfter("object PlanStore")
        assertTrue(s.contains("bad++") && s.contains("if (bad > 0)") && s.contains("KEY + \"_bak\""))
        assertEquals(2, Regex("KEY \\+ \"_bak\"").findAll(s).count()) // kayıt hatası + tüm JSON bozuk
    }

    @Test fun todoStoreBacksUpRawOnBadRecords() {
        val s = code("todo/TodoStore.kt").substringAfter("object TodoStore")
        assertTrue(s.contains("bad++") && s.contains("if (bad > 0)") && s.contains("KEY + \"_bak\""))
        assertEquals(2, Regex("KEY \\+ \"_bak\"").findAll(s).count())
    }

    @Test fun backupKeyDoesNotCollideWithDataKey() {
        for (f in listOf("plan/PlanItem.kt", "todo/TodoStore.kt")) assertTrue(code(f).contains("private const val KEY = \"items\""))
    }
}
