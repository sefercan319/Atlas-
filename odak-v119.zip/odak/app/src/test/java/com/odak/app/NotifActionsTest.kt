package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.49: bildirimden "Tamamlandı" eylemi ve sabah özetinde geciken görev sayısı. */
class NotifActionsTest {
    private fun src(rel: String) = File(TestFiles.code, "com/odak/app/$rel").readText()

    @Test fun receiverHandlesDoneAction() {
        val t = src("notify/Reminders.kt")
        assertTrue(t.contains("getBooleanExtra(\"done\", false)"))
        assertTrue(t.contains("it.copy(done = true)"))
        assertTrue(t.contains("PlanWidget.refresh(c)"))
    }
    @Test fun doneActionOnlyForPlans() {
        assertTrue(src("notify/Reminders.kt").contains("if (isPlan) addAction"))
    }
    @Test fun doneActionIsTranslatedEverywhere() {
        for ((n, f) in TestFiles.stringFiles()) assertTrue(n, f.readText().contains("name=\"plan_done_action\""))
    }
    @Test fun morningSummaryHasOverduePlaceholder() {
        assertTrue(src("notify/Msgs.kt").contains("\"overdue\""))
        assertTrue(src("notify/Reminders.kt").contains("\"overdue\" to overdue.toString()"))
    }
    @Test fun morningSummaryCountsOverdueWithPureLogic() {
        assertTrue(src("notify/Reminders.kt").contains("Pure.isOverdue(it.due, it.done, today)"))
    }
}
