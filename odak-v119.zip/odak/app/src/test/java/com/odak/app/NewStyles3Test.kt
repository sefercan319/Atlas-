package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import kotlin.math.abs
import kotlin.math.pow

/** Cosmic Dark, Sci-Fi HUD, Cyber-Industrial, Neoclassical: kayıt, ses, kontrast, kaynak denetimi. */
class NewStyles3Test {
    private val theme = File(TestFiles.code, "com/odak/app/theme")
    private val designSrc = File(theme, "DesignStyle.kt").readText()
    private val ns3 = File(theme, "NewStyles3.kt").readText()
    private val keys = listOf("cosmic", "scifi_hud", "cyber_industrial", "neoclassical")
    private val names = listOf("COSMIC", "SCIFI_HUD", "CYBER_INDUSTRIAL", "NEOCLASSICAL")
    private val kinds = listOf("tap", "success", "delete", "notify")

    // ---------- kayıt ----------
    @Test fun enumHasTheFourStylesWithKeys() {
        val rows = Regex("""^\s+([A-Z0-9_]+)\("([^"]*)", "([a-z0-9_]+)"\)""", RegexOption.MULTILINE)
            .findAll(designSrc.substringBefore("data class DesignTokens")).map { Triple(it.groupValues[1], it.groupValues[2], it.groupValues[3]) }.toList()
        assertEquals(17, rows.size)
        for ((i, n) in names.withIndex()) assertTrue(n, rows.any { it.first == n && it.third == keys[i] })
        assertTrue(rows.any { it.second == "Cosmic Dark" }); assertTrue(rows.any { it.second == "Sci-Fi HUD" })
        assertEquals(17, rows.map { it.third }.toSet().size)
    }

    @Test fun everyStyleHasBaseTokens() {
        for (n in names) assertTrue(n, Regex("""DesignStyle\.$n -> DesignTokens\(""").containsMatchIn(designSrc))
    }

    // ---------- ses ----------
    private class Wav(val rate: Int, val ch: Int, val bits: Int, val s: ShortArray)
    private fun wav(name: String): Wav {
        val b = File(TestFiles.res, "raw/$name.wav").readBytes()
        assertEquals("RIFF", String(b, 0, 4)); assertEquals("WAVE", String(b, 8, 4))
        fun le16(o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
        fun le32(o: Int) = le16(o) or (le16(o + 2) shl 16)
        var p = 12; var rate = 0; var ch = 0; var bits = 0; var data: ShortArray? = null
        while (p + 8 <= b.size) {
            val id = String(b, p, 4); val sz = le32(p + 4)
            if (id == "fmt ") { assertEquals(1, le16(p + 8)); ch = le16(p + 10); rate = le32(p + 12); bits = le16(p + 22) }
            if (id == "data") data = ShortArray(sz / 2) { le16(p + 8 + it * 2).toShort() }
            p += 8 + sz + (sz and 1)
        }
        return Wav(rate, ch, bits, data!!)
    }
    private fun sec(w: Wav) = w.s.size.toDouble() / w.rate

    @Test fun sixteenSoundsAreValidMonoPcm16() {
        for (k in keys) for (kind in kinds) {
            val w = wav("snd_${k}_$kind")
            assertEquals("$k/$kind", 1, w.ch); assertEquals(16, w.bits); assertTrue(w.rate in 8000..48000)
        }
    }

    @Test fun durationsFitTheirRole() {
        for (k in keys) {
            assertTrue("$k tap", sec(wav("snd_${k}_tap")) in 0.03..0.5)
            for (kind in listOf("success", "delete")) assertTrue("$k/$kind ${sec(wav("snd_${k}_$kind"))}", sec(wav("snd_${k}_$kind")) in 0.1..1.3)
            assertTrue("$k notify ${sec(wav("snd_${k}_notify"))}", sec(wav("snd_${k}_notify")) in 0.6..2.6)
            assertTrue(wav("snd_${k}_tap").s.size < wav("snd_${k}_notify").s.size)
        }
    }

    @Test fun audibleNotClippingAndClickFree() {
        for (k in keys) for (kind in kinds) {
            val w = wav("snd_${k}_$kind")
            val peak = w.s.maxOf { abs(it.toInt()) } / 32768.0
            assertTrue("$k/$kind sessiz $peak", peak > 0.2); assertTrue("$k/$kind kırpılıyor", peak < 0.9)
            val rms = Math.sqrt(w.s.sumOf { (it / 32768.0).pow(2) } / w.s.size)
            assertTrue("$k/$kind rms $rms", rms > 0.01)
            assertTrue("$k/$kind başlangıç tık", abs(w.s.first().toInt()) < 800)
            assertTrue("$k/$kind bitiş tık", abs(w.s.last().toInt()) < 400)
        }
    }

    @Test fun soundsDifferFromEachOther() {
        val seen = HashSet<Int>()
        for (k in keys) for (kind in kinds) assertTrue("$k/$kind", seen.add(wav("snd_${k}_$kind").s.contentHashCode()))
        assertEquals(16, seen.size)
    }

    // ---------- kontrast ----------
    private fun lum(c: Long): Double {
        fun f(v: Int): Double { val x = v / 255.0; return if (x <= 0.03928) x / 12.92 else ((x + 0.055) / 1.055).pow(2.4) }
        return 0.2126 * f(((c shr 16) and 255).toInt()) + 0.7152 * f(((c shr 8) and 255).toInt()) + 0.0722 * f((c and 255).toInt())
    }
    private fun contrast(a: Long, b: Long): Double { val l1 = lum(a); val l2 = lum(b); return (maxOf(l1, l2) + 0.05) / (minOf(l1, l2) + 0.05) }
    private fun mix(a: Long, b: Long, t: Double): Long {
        var o = 0L
        for (s in listOf(16, 8, 0)) o = o or (((((a shr s) and 255) * (1 - t) + ((b shr s) and 255) * t).toLong()) shl s)
        return o
    }
    private fun tok(style: String, field: String): Long {
        val block = designSrc.substringAfter("DesignStyle.$style -> DesignTokens(").substringBefore("radius")
        return Regex("""$field = Color\(0x([0-9A-Fa-f]{8})\)""").find(block)!!.groupValues[1].toLong(16) and 0xFFFFFF
    }

    @Test fun cosmicTextReadableOverEveryNebulaCloud() {
        val text = tok("COSMIC", "text")
        val clouds = Regex("""drawCircle\(Color\(0xFF([0-9A-F]{6})\)""").findAll(ns3.substringAfter("fun CosmicBackdrop").substringBefore("fun Modifier.cosmicPanel"))
            .map { it.groupValues[1].toLong(16) }.toList()
        assertEquals(3, clouds.size)
        val sky = 0x14083AL; val scrim = 0x05020FL
        for (c in clouds) {
            // en kötü durum: bulut tam alfa + örtü; panel koyu mor %90 üstünde
            val under = mix(mix(sky, c, 0.75), scrim, 0.30)
            assertTrue("bulut ${c.toString(16)}: ${contrast(text, under)}", contrast(text, under) >= 4.5)
        }
        assertTrue(contrast(text, tok("COSMIC", "surface")) >= 7.0)
        assertTrue(contrast(tok("COSMIC", "primary"), tok("COSMIC", "surface")) >= 4.5)
        assertTrue(contrast(tok("COSMIC", "accent"), tok("COSMIC", "surface")) >= 4.5)
        assertTrue("düğme: koyu yazı / lavanta", contrast(0x05020F, 0xB4A7FF) >= 7.0)
        assertTrue("düğme: koyu yazı / pembe orta", contrast(0x05020F, 0xE0A8FF) >= 7.0)
        assertTrue("düğme: koyu yazı / mavi uç", contrast(0x05020F, 0x9AB4FF) >= 7.0)
    }

    @Test fun hudAmberAndCyanReadable() {
        val bg = tok("SCIFI_HUD", "background"); val sf = tok("SCIFI_HUD", "surface")
        assertTrue(contrast(tok("SCIFI_HUD", "text"), sf) >= 7.0)
        assertTrue(contrast(tok("SCIFI_HUD", "primary"), bg) >= 7.0)
        assertTrue(contrast(tok("SCIFI_HUD", "primary"), 0x0A1822) >= 7.0)
        assertTrue(contrast(tok("SCIFI_HUD", "accent"), 0x0A1822) >= 7.0)
        assertTrue("bugün hücresi", contrast(0x04090F, 0xFFB020) >= 7.0)
        assertTrue("açık ızgara yazısı", contrast(0x7FB8CC, bg) >= 4.5)
    }

    @Test fun cyberYellowAndBlackPairs() {
        val bg = tok("CYBER_INDUSTRIAL", "background"); val sf = tok("CYBER_INDUSTRIAL", "surface")
        assertTrue(contrast(tok("CYBER_INDUSTRIAL", "text"), sf) >= 7.0)
        assertTrue(contrast(tok("CYBER_INDUSTRIAL", "primary"), sf) >= 7.0)
        assertTrue(contrast(tok("CYBER_INDUSTRIAL", "accent"), sf) >= 4.5)
        assertTrue("sarı plaka üstü siyah yazı", contrast(0x111111, 0xFFC400) >= 7.0)
        assertTrue("koyu sarı bilet üstü açık yazı", contrast(0xF3E7A0, 0x6B5A00) >= 4.5)
        assertTrue("çelik plaka üstü yazı", contrast(tok("CYBER_INDUSTRIAL", "text"), 0x23272C) >= 7.0)
        assertTrue(contrast(tok("CYBER_INDUSTRIAL", "text"), bg) >= 7.0)
    }

    @Test fun neoclassicalInkOnIvoryAndGold() {
        val bg = tok("NEOCLASSICAL", "background"); val sf = tok("NEOCLASSICAL", "surface")
        assertTrue(contrast(tok("NEOCLASSICAL", "text"), bg) >= 7.0)
        assertTrue(contrast(tok("NEOCLASSICAL", "text"), sf) >= 7.0)
        assertTrue(contrast(tok("NEOCLASSICAL", "text"), 0xEFE9DA) >= 7.0)
        assertTrue("koyu altın yazı", contrast(tok("NEOCLASSICAL", "primary"), sf) >= 4.5)
        assertTrue(contrast(tok("NEOCLASSICAL", "primary"), bg) >= 4.5)
        assertTrue(contrast(tok("NEOCLASSICAL", "accent"), bg) >= 4.5)
        assertTrue("bugün: fildişi / koyu altın", contrast(0xFBF8F0, 0x6F5210) >= 6.5)
        assertTrue("altın para üstü ✓", contrast(0x3A2A06, 0xC9A24B) >= 4.5)
    }

    // ---------- kaynak denetimi ----------
    @Test fun helpersImplementTheResearchedRecipes() {
        for (fn in listOf("fun CosmicBackdrop", "fun Modifier.cosmicPanel", "fun Modifier.cosmicButton", "fun DrawScope.warpRings", "fun Modifier.cosmicPlanet",
            "fun DrawScope.hudBrackets", "fun Modifier.hudPanel", "fun HudBackdrop", "fun DrawScope.hudLockOn",
            "fun Modifier.steelPlate", "fun DrawScope.hazardStripes", "fun Modifier.yellowPlate", "fun CyberBackdrop",
            "fun Modifier.neoMarble", "fun Modifier.neoFrame", "fun DrawScope.greekKey", "fun Modifier.goldCoin", "fun roman"))
            assertTrue(fn, ns3.contains(fn))
        assertTrue(ns3.contains("blur(70.dp)"))          // nebula
        assertTrue(ns3.contains("val HudAmber = Color(0xFFFFB020)"))
        assertTrue(ns3.contains("val HazardYellow = Color(0xFFFFC400)"))
        assertTrue(ns3.contains("val NeoGold = Color(0xFFC9A24B)"))
    }

    @Test fun pressFxGivesEachStyleItsOwnReaction() {
        val p = File(theme, "PressFx.kt").readText()
        for (n in names) assertTrue(n, p.contains("DesignStyle.$n"))
        assertTrue(p.contains("warpRings(c, g, tint)")); assertTrue(p.contains("hudLockOn(tint, g)"))
        assertTrue(p.contains("DesignStyle.CYBER_INDUSTRIAL && p.pressed.value) 3.dp.toPx()"))
        assertTrue(p.contains("h * (1f - g)"))           // altın dolgu yükselir
    }

    @Test fun motionShapeAndTransitionExist() {
        val s = File(theme, "Styling.kt").readText()
        for (fn in listOf("fun <T> motion", "fun fadeMs", "fun pressScale", "fun pageTransition", "fun buttonShape", "fun cardShape", "fun checkShape")) {
            val body = s.substringAfter(fn).substringBefore("\nfun ")
            for (n in names) assertTrue("$fn / $n", body.contains("DesignStyle.$n"))
        }
        assertTrue(s.contains("import androidx.compose.animation.slideOutVertically"))
    }

    @Test fun componentsAndNavigationHaveBranches() {
        for (f in listOf("ThemedComponents.kt", "NavBar.kt", "PeriodSelector.kt", "Header.kt")) {
            val t = File(theme, f).readText()
            for (n in names) assertTrue("$f / $n", t.contains("DesignStyle.$n"))
        }
        val c = File(theme, "ThemedComponents.kt").readText()
        for (n in names) assertTrue(n, c.substringAfter("private val NewLookStyles").substringBefore(")").contains("DesignStyle.$n"))
    }

    @Test fun planScreenRoutesAndSkinsExist() {
        val plan = File(TestFiles.code, "com/odak/app/plan")
        val p = File(plan, "PlanScreen.kt").readText()
        assertTrue("v0.56.28: tüm stiller tek düzene gider", p.contains("UnifiedPlan(vm, style)"))
        val sk = File(plan, "PlanSkin.kt").readText()
        for (n in names) assertTrue(n, sk.contains("DesignStyle.$n -> GridSkin("))
        val src = File(plan, "PlanNewStyles3.kt").readText()
        assertTrue(src.contains("greekKey")); assertTrue(src.contains("roman(")); assertTrue(src.contains("hazardStripes")); assertTrue(src.contains("drawArc"))
    }

    @Test fun eachStyleHasOwnNotificationChannelAndStatusBar() {
        val ch = File(TestFiles.code, "com/odak/app/notify/StyleChannel.kt").readText()
        for (n in names) assertTrue(n, ch.contains("DesignStyle.$n"))
        val main = File(TestFiles.code, "com/odak/app/MainActivity.kt").readText()
        assertTrue(main.contains("DesignStyle.NEOCLASSICAL"))
        val d = File(theme, "DarkMode.kt").readText().substringAfter("fun naturallyDark").substringBefore("/**")
        for (n in listOf("COSMIC", "SCIFI_HUD", "CYBER_INDUSTRIAL")) assertTrue(n, d.contains("DesignStyle.$n"))
        assertTrue(!d.contains("DesignStyle.NEOCLASSICAL"))
    }

    @Test fun romanNumeralsMatchImplementation() {
        val body = ns3.substringAfter("fun roman")
        assertTrue(body.contains("\"X\"") || body.contains("\"XL\"") || body.contains("\"I\""))
        // 1..39 için kural: onlar X tekrarı, birler I/V/IX
        fun r(n: Int): String {
            var x = n; val sb = StringBuilder()
            for ((v, s) in listOf(10 to "X", 9 to "IX", 5 to "V", 4 to "IV", 1 to "I")) while (x >= v) { sb.append(s); x -= v }
            return sb.toString()
        }
        assertEquals("XXXIX", r(39)); assertEquals("XIV", r(14)); assertEquals("IX", r(9))
    }
}
