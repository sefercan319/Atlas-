package com.odak.app

import com.odak.app.notes.Note
import com.odak.app.notes.NotePure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Not paylaşımı: başlık/gövde birleşimi, yapılacak glifleri, sondaki boşluklar, bağlantı. */
class NoteExportTest {
    @Test fun titleThenBlankLineThenBody() {
        assertEquals("Plan\n\nmerhaba", NotePure.exportText(Note(title = " Plan ", body = "merhaba")))
    }

    @Test fun blankTitleStartsWithBody() {
        assertEquals("merhaba", NotePure.exportText(Note(title = "  ", body = "merhaba")))
    }

    @Test fun emptyBodyGivesTitleOnly() {
        assertEquals("Plan", NotePure.exportText(Note(title = "Plan", body = "")))
    }

    @Test fun checklistPrefixesBecomeGlyphs() {
        val out = NotePure.exportText(Note(title = "Alış", body = "[ ] süt\n[x] ekmek\nnot"))
        assertEquals("Alış\n\n☐ süt\n☑ ekmek\nnot", out)
    }

    @Test fun trailingBlankLinesAreTrimmed() {
        assertEquals("a", NotePure.exportText(Note(title = "", body = "a\n\n")))
        assertEquals("Plan\n\na", NotePure.exportText(Note(title = "Plan", body = "a\n\n  \n")))
    }

    @Test fun shareUsesExportText() {
        val s = File(TestFiles.code, "com/odak/app/notes/NoteEditor.kt").readText()
        assertTrue(s.contains("putExtra(Intent.EXTRA_TEXT, NotePure.exportText(current()))"))
    }
}
