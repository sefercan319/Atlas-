package com.odak.app

import com.odak.app.notes.Note
import com.odak.app.notes.NotePure
import com.odak.app.notes.Pt
import com.odak.app.notes.Stroke
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.54: not defteri için üretilmiş tablo/özellik testleri (beklenen değerler Python hesabından). */
class NoteGenTest {
    private fun randStr(r: java.util.Random, max: Int): String {
        val al = "abcXYZ ğüşıöçİ\n\\=12 ☑😀"
        val sb = StringBuilder()
        repeat(r.nextInt(max + 1)) { sb.append(al[r.nextInt(al.length)]) }
        return sb.toString().replace("\uD83D", "").replace("\uDE00", "")
    }
    private fun rnd(seed: Long): Note {
        val r = java.util.Random(seed)
        val strokes = List(r.nextInt(6)) { Stroke(r.nextInt(3), r.nextInt(), 0.5f + r.nextInt(80) / 4f, List(1 + r.nextInt(8)) { Pt(r.nextInt(10000) / 3333f, r.nextInt(30000) / 3333f) }) }
        return Note(id = "id" + seed, title = randStr(r, 20), body = randStr(r, 80), strokes = strokes, paper = r.nextInt(4), color = r.nextInt(),
            pinned = r.nextBoolean(), folder = randStr(r, 10).replace("\n", " "), created = r.nextLong() and 0xFFFFFFFFL, updated = r.nextLong() and 0xFFFFFFFFL,
            trashedAt = if (r.nextBoolean()) 0L else (r.nextLong() and 0xFFFFFFL) + 1, locked = r.nextBoolean())
    }
    private fun same(a: Note, b: Note) {
        assertEquals(a.id, b.id); assertEquals(a.title, b.title); assertEquals(a.body, b.body); assertEquals(a.paper, b.paper)
        assertEquals(a.color, b.color); assertEquals(a.pinned, b.pinned); assertEquals(a.folder, b.folder); assertEquals(a.created, b.created)
        assertEquals(a.updated, b.updated); assertEquals(a.trashedAt, b.trashedAt); assertEquals(a.locked, b.locked); assertEquals(a.strokes.size, b.strokes.size)
        for (i in a.strokes.indices) {
            assertEquals(a.strokes[i].tool, b.strokes[i].tool); assertEquals(a.strokes[i].color, b.strokes[i].color)
            assertEquals(a.strokes[i].width, b.strokes[i].width, 0.001f); assertEquals(a.strokes[i].pts.size, b.strokes[i].pts.size)
            for (j in a.strokes[i].pts.indices) { assertEquals(a.strokes[i].pts[j].x, b.strokes[i].pts[j].x, 0.0002f); assertEquals(a.strokes[i].pts[j].y, b.strokes[i].pts[j].y, 0.0002f) }
        }
    }
    @Test fun roundTrip_1() { val a = rnd(1L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_1() { val a = rnd(1L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_2() { val a = rnd(2L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_2() { val a = rnd(2L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_3() { val a = rnd(3L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_3() { val a = rnd(3L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_4() { val a = rnd(4L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_4() { val a = rnd(4L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_5() { val a = rnd(5L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_5() { val a = rnd(5L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_6() { val a = rnd(6L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_6() { val a = rnd(6L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_7() { val a = rnd(7L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_7() { val a = rnd(7L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_8() { val a = rnd(8L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_8() { val a = rnd(8L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_9() { val a = rnd(9L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_9() { val a = rnd(9L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_10() { val a = rnd(10L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_10() { val a = rnd(10L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_11() { val a = rnd(11L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_11() { val a = rnd(11L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_12() { val a = rnd(12L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_12() { val a = rnd(12L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_13() { val a = rnd(13L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_13() { val a = rnd(13L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_14() { val a = rnd(14L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_14() { val a = rnd(14L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_15() { val a = rnd(15L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_15() { val a = rnd(15L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_16() { val a = rnd(16L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_16() { val a = rnd(16L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_17() { val a = rnd(17L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_17() { val a = rnd(17L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_18() { val a = rnd(18L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_18() { val a = rnd(18L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_19() { val a = rnd(19L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_19() { val a = rnd(19L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_20() { val a = rnd(20L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_20() { val a = rnd(20L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_21() { val a = rnd(21L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_21() { val a = rnd(21L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_22() { val a = rnd(22L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_22() { val a = rnd(22L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_23() { val a = rnd(23L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_23() { val a = rnd(23L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_24() { val a = rnd(24L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_24() { val a = rnd(24L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_25() { val a = rnd(25L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_25() { val a = rnd(25L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_26() { val a = rnd(26L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_26() { val a = rnd(26L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_27() { val a = rnd(27L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_27() { val a = rnd(27L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_28() { val a = rnd(28L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_28() { val a = rnd(28L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_29() { val a = rnd(29L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_29() { val a = rnd(29L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_30() { val a = rnd(30L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_30() { val a = rnd(30L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_31() { val a = rnd(31L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_31() { val a = rnd(31L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_32() { val a = rnd(32L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_32() { val a = rnd(32L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_33() { val a = rnd(33L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_33() { val a = rnd(33L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_34() { val a = rnd(34L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_34() { val a = rnd(34L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_35() { val a = rnd(35L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_35() { val a = rnd(35L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_36() { val a = rnd(36L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_36() { val a = rnd(36L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_37() { val a = rnd(37L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_37() { val a = rnd(37L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_38() { val a = rnd(38L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_38() { val a = rnd(38L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_39() { val a = rnd(39L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_39() { val a = rnd(39L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_40() { val a = rnd(40L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_40() { val a = rnd(40L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_41() { val a = rnd(41L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_41() { val a = rnd(41L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_42() { val a = rnd(42L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_42() { val a = rnd(42L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_43() { val a = rnd(43L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_43() { val a = rnd(43L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_44() { val a = rnd(44L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_44() { val a = rnd(44L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_45() { val a = rnd(45L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_45() { val a = rnd(45L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_46() { val a = rnd(46L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_46() { val a = rnd(46L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_47() { val a = rnd(47L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_47() { val a = rnd(47L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_48() { val a = rnd(48L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_48() { val a = rnd(48L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_49() { val a = rnd(49L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_49() { val a = rnd(49L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_50() { val a = rnd(50L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_50() { val a = rnd(50L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_51() { val a = rnd(51L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_51() { val a = rnd(51L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_52() { val a = rnd(52L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_52() { val a = rnd(52L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_53() { val a = rnd(53L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_53() { val a = rnd(53L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_54() { val a = rnd(54L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_54() { val a = rnd(54L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_55() { val a = rnd(55L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_55() { val a = rnd(55L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_56() { val a = rnd(56L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_56() { val a = rnd(56L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_57() { val a = rnd(57L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_57() { val a = rnd(57L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_58() { val a = rnd(58L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_58() { val a = rnd(58L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_59() { val a = rnd(59L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_59() { val a = rnd(59L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_60() { val a = rnd(60L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_60() { val a = rnd(60L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_61() { val a = rnd(61L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_61() { val a = rnd(61L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_62() { val a = rnd(62L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_62() { val a = rnd(62L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_63() { val a = rnd(63L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_63() { val a = rnd(63L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_64() { val a = rnd(64L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_64() { val a = rnd(64L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_65() { val a = rnd(65L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_65() { val a = rnd(65L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_66() { val a = rnd(66L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_66() { val a = rnd(66L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_67() { val a = rnd(67L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_67() { val a = rnd(67L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_68() { val a = rnd(68L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_68() { val a = rnd(68L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_69() { val a = rnd(69L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_69() { val a = rnd(69L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_70() { val a = rnd(70L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_70() { val a = rnd(70L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_71() { val a = rnd(71L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_71() { val a = rnd(71L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_72() { val a = rnd(72L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_72() { val a = rnd(72L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_73() { val a = rnd(73L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_73() { val a = rnd(73L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_74() { val a = rnd(74L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_74() { val a = rnd(74L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_75() { val a = rnd(75L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_75() { val a = rnd(75L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_76() { val a = rnd(76L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_76() { val a = rnd(76L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_77() { val a = rnd(77L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_77() { val a = rnd(77L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_78() { val a = rnd(78L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_78() { val a = rnd(78L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_79() { val a = rnd(79L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_79() { val a = rnd(79L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_80() { val a = rnd(80L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_80() { val a = rnd(80L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_81() { val a = rnd(81L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_81() { val a = rnd(81L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_82() { val a = rnd(82L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_82() { val a = rnd(82L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_83() { val a = rnd(83L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_83() { val a = rnd(83L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_84() { val a = rnd(84L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_84() { val a = rnd(84L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_85() { val a = rnd(85L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_85() { val a = rnd(85L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_86() { val a = rnd(86L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_86() { val a = rnd(86L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_87() { val a = rnd(87L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_87() { val a = rnd(87L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_88() { val a = rnd(88L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_88() { val a = rnd(88L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_89() { val a = rnd(89L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_89() { val a = rnd(89L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_90() { val a = rnd(90L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_90() { val a = rnd(90L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_91() { val a = rnd(91L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_91() { val a = rnd(91L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_92() { val a = rnd(92L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_92() { val a = rnd(92L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_93() { val a = rnd(93L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_93() { val a = rnd(93L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_94() { val a = rnd(94L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_94() { val a = rnd(94L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_95() { val a = rnd(95L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_95() { val a = rnd(95L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_96() { val a = rnd(96L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_96() { val a = rnd(96L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_97() { val a = rnd(97L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_97() { val a = rnd(97L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_98() { val a = rnd(98L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_98() { val a = rnd(98L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_99() { val a = rnd(99L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_99() { val a = rnd(99L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_100() { val a = rnd(100L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_100() { val a = rnd(100L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_101() { val a = rnd(101L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_101() { val a = rnd(101L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_102() { val a = rnd(102L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_102() { val a = rnd(102L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_103() { val a = rnd(103L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_103() { val a = rnd(103L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_104() { val a = rnd(104L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_104() { val a = rnd(104L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_105() { val a = rnd(105L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_105() { val a = rnd(105L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_106() { val a = rnd(106L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_106() { val a = rnd(106L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_107() { val a = rnd(107L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_107() { val a = rnd(107L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_108() { val a = rnd(108L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_108() { val a = rnd(108L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_109() { val a = rnd(109L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_109() { val a = rnd(109L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_110() { val a = rnd(110L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_110() { val a = rnd(110L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_111() { val a = rnd(111L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_111() { val a = rnd(111L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_112() { val a = rnd(112L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_112() { val a = rnd(112L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_113() { val a = rnd(113L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_113() { val a = rnd(113L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_114() { val a = rnd(114L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_114() { val a = rnd(114L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_115() { val a = rnd(115L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_115() { val a = rnd(115L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_116() { val a = rnd(116L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_116() { val a = rnd(116L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_117() { val a = rnd(117L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_117() { val a = rnd(117L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_118() { val a = rnd(118L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_118() { val a = rnd(118L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_119() { val a = rnd(119L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_119() { val a = rnd(119L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_120() { val a = rnd(120L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_120() { val a = rnd(120L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_121() { val a = rnd(121L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_121() { val a = rnd(121L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_122() { val a = rnd(122L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_122() { val a = rnd(122L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_123() { val a = rnd(123L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_123() { val a = rnd(123L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_124() { val a = rnd(124L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_124() { val a = rnd(124L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_125() { val a = rnd(125L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_125() { val a = rnd(125L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_126() { val a = rnd(126L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_126() { val a = rnd(126L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_127() { val a = rnd(127L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_127() { val a = rnd(127L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_128() { val a = rnd(128L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_128() { val a = rnd(128L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_129() { val a = rnd(129L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_129() { val a = rnd(129L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_130() { val a = rnd(130L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_130() { val a = rnd(130L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_131() { val a = rnd(131L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_131() { val a = rnd(131L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_132() { val a = rnd(132L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_132() { val a = rnd(132L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_133() { val a = rnd(133L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_133() { val a = rnd(133L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_134() { val a = rnd(134L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_134() { val a = rnd(134L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_135() { val a = rnd(135L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_135() { val a = rnd(135L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_136() { val a = rnd(136L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_136() { val a = rnd(136L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_137() { val a = rnd(137L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_137() { val a = rnd(137L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_138() { val a = rnd(138L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_138() { val a = rnd(138L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_139() { val a = rnd(139L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_139() { val a = rnd(139L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_140() { val a = rnd(140L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_140() { val a = rnd(140L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_141() { val a = rnd(141L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_141() { val a = rnd(141L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_142() { val a = rnd(142L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_142() { val a = rnd(142L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_143() { val a = rnd(143L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_143() { val a = rnd(143L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_144() { val a = rnd(144L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_144() { val a = rnd(144L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_145() { val a = rnd(145L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_145() { val a = rnd(145L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_146() { val a = rnd(146L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_146() { val a = rnd(146L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_147() { val a = rnd(147L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_147() { val a = rnd(147L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_148() { val a = rnd(148L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_148() { val a = rnd(148L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_149() { val a = rnd(149L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_149() { val a = rnd(149L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_150() { val a = rnd(150L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_150() { val a = rnd(150L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_151() { val a = rnd(151L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_151() { val a = rnd(151L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_152() { val a = rnd(152L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_152() { val a = rnd(152L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_153() { val a = rnd(153L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_153() { val a = rnd(153L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_154() { val a = rnd(154L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_154() { val a = rnd(154L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_155() { val a = rnd(155L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_155() { val a = rnd(155L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_156() { val a = rnd(156L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_156() { val a = rnd(156L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_157() { val a = rnd(157L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_157() { val a = rnd(157L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_158() { val a = rnd(158L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_158() { val a = rnd(158L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_159() { val a = rnd(159L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_159() { val a = rnd(159L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_160() { val a = rnd(160L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_160() { val a = rnd(160L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_161() { val a = rnd(161L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_161() { val a = rnd(161L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_162() { val a = rnd(162L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_162() { val a = rnd(162L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_163() { val a = rnd(163L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_163() { val a = rnd(163L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_164() { val a = rnd(164L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_164() { val a = rnd(164L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_165() { val a = rnd(165L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_165() { val a = rnd(165L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_166() { val a = rnd(166L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_166() { val a = rnd(166L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_167() { val a = rnd(167L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_167() { val a = rnd(167L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_168() { val a = rnd(168L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_168() { val a = rnd(168L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_169() { val a = rnd(169L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_169() { val a = rnd(169L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_170() { val a = rnd(170L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_170() { val a = rnd(170L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_171() { val a = rnd(171L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_171() { val a = rnd(171L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_172() { val a = rnd(172L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_172() { val a = rnd(172L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_173() { val a = rnd(173L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_173() { val a = rnd(173L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_174() { val a = rnd(174L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_174() { val a = rnd(174L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_175() { val a = rnd(175L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_175() { val a = rnd(175L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_176() { val a = rnd(176L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_176() { val a = rnd(176L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_177() { val a = rnd(177L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_177() { val a = rnd(177L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_178() { val a = rnd(178L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_178() { val a = rnd(178L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_179() { val a = rnd(179L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_179() { val a = rnd(179L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_180() { val a = rnd(180L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_180() { val a = rnd(180L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_181() { val a = rnd(181L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_181() { val a = rnd(181L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_182() { val a = rnd(182L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_182() { val a = rnd(182L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_183() { val a = rnd(183L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_183() { val a = rnd(183L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_184() { val a = rnd(184L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_184() { val a = rnd(184L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_185() { val a = rnd(185L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_185() { val a = rnd(185L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_186() { val a = rnd(186L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_186() { val a = rnd(186L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_187() { val a = rnd(187L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_187() { val a = rnd(187L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_188() { val a = rnd(188L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_188() { val a = rnd(188L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_189() { val a = rnd(189L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_189() { val a = rnd(189L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_190() { val a = rnd(190L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_190() { val a = rnd(190L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_191() { val a = rnd(191L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_191() { val a = rnd(191L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_192() { val a = rnd(192L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_192() { val a = rnd(192L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_193() { val a = rnd(193L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_193() { val a = rnd(193L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_194() { val a = rnd(194L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_194() { val a = rnd(194L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_195() { val a = rnd(195L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_195() { val a = rnd(195L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_196() { val a = rnd(196L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_196() { val a = rnd(196L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_197() { val a = rnd(197L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_197() { val a = rnd(197L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_198() { val a = rnd(198L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_198() { val a = rnd(198L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_199() { val a = rnd(199L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_199() { val a = rnd(199L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_200() { val a = rnd(200L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_200() { val a = rnd(200L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_201() { val a = rnd(201L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_201() { val a = rnd(201L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_202() { val a = rnd(202L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_202() { val a = rnd(202L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_203() { val a = rnd(203L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_203() { val a = rnd(203L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_204() { val a = rnd(204L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_204() { val a = rnd(204L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_205() { val a = rnd(205L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_205() { val a = rnd(205L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_206() { val a = rnd(206L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_206() { val a = rnd(206L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_207() { val a = rnd(207L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_207() { val a = rnd(207L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_208() { val a = rnd(208L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_208() { val a = rnd(208L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_209() { val a = rnd(209L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_209() { val a = rnd(209L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_210() { val a = rnd(210L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_210() { val a = rnd(210L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_211() { val a = rnd(211L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_211() { val a = rnd(211L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_212() { val a = rnd(212L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_212() { val a = rnd(212L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_213() { val a = rnd(213L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_213() { val a = rnd(213L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_214() { val a = rnd(214L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_214() { val a = rnd(214L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_215() { val a = rnd(215L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_215() { val a = rnd(215L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_216() { val a = rnd(216L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_216() { val a = rnd(216L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_217() { val a = rnd(217L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_217() { val a = rnd(217L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_218() { val a = rnd(218L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_218() { val a = rnd(218L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_219() { val a = rnd(219L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_219() { val a = rnd(219L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_220() { val a = rnd(220L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_220() { val a = rnd(220L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_221() { val a = rnd(221L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_221() { val a = rnd(221L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_222() { val a = rnd(222L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_222() { val a = rnd(222L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_223() { val a = rnd(223L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_223() { val a = rnd(223L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_224() { val a = rnd(224L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_224() { val a = rnd(224L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_225() { val a = rnd(225L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_225() { val a = rnd(225L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_226() { val a = rnd(226L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_226() { val a = rnd(226L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_227() { val a = rnd(227L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_227() { val a = rnd(227L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_228() { val a = rnd(228L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_228() { val a = rnd(228L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_229() { val a = rnd(229L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_229() { val a = rnd(229L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_230() { val a = rnd(230L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_230() { val a = rnd(230L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_231() { val a = rnd(231L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_231() { val a = rnd(231L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_232() { val a = rnd(232L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_232() { val a = rnd(232L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_233() { val a = rnd(233L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_233() { val a = rnd(233L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_234() { val a = rnd(234L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_234() { val a = rnd(234L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_235() { val a = rnd(235L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_235() { val a = rnd(235L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_236() { val a = rnd(236L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_236() { val a = rnd(236L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_237() { val a = rnd(237L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_237() { val a = rnd(237L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_238() { val a = rnd(238L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_238() { val a = rnd(238L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_239() { val a = rnd(239L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_239() { val a = rnd(239L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_240() { val a = rnd(240L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_240() { val a = rnd(240L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_241() { val a = rnd(241L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_241() { val a = rnd(241L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_242() { val a = rnd(242L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_242() { val a = rnd(242L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_243() { val a = rnd(243L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_243() { val a = rnd(243L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_244() { val a = rnd(244L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_244() { val a = rnd(244L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_245() { val a = rnd(245L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_245() { val a = rnd(245L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_246() { val a = rnd(246L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_246() { val a = rnd(246L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_247() { val a = rnd(247L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_247() { val a = rnd(247L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_248() { val a = rnd(248L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_248() { val a = rnd(248L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_249() { val a = rnd(249L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_249() { val a = rnd(249L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_250() { val a = rnd(250L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_250() { val a = rnd(250L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_251() { val a = rnd(251L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_251() { val a = rnd(251L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_252() { val a = rnd(252L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_252() { val a = rnd(252L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_253() { val a = rnd(253L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_253() { val a = rnd(253L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_254() { val a = rnd(254L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_254() { val a = rnd(254L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_255() { val a = rnd(255L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_255() { val a = rnd(255L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_256() { val a = rnd(256L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_256() { val a = rnd(256L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_257() { val a = rnd(257L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_257() { val a = rnd(257L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_258() { val a = rnd(258L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_258() { val a = rnd(258L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_259() { val a = rnd(259L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_259() { val a = rnd(259L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_260() { val a = rnd(260L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_260() { val a = rnd(260L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_261() { val a = rnd(261L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_261() { val a = rnd(261L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_262() { val a = rnd(262L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_262() { val a = rnd(262L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_263() { val a = rnd(263L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_263() { val a = rnd(263L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_264() { val a = rnd(264L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_264() { val a = rnd(264L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_265() { val a = rnd(265L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_265() { val a = rnd(265L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_266() { val a = rnd(266L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_266() { val a = rnd(266L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_267() { val a = rnd(267L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_267() { val a = rnd(267L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_268() { val a = rnd(268L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_268() { val a = rnd(268L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_269() { val a = rnd(269L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_269() { val a = rnd(269L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_270() { val a = rnd(270L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_270() { val a = rnd(270L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_271() { val a = rnd(271L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_271() { val a = rnd(271L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_272() { val a = rnd(272L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_272() { val a = rnd(272L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_273() { val a = rnd(273L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_273() { val a = rnd(273L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_274() { val a = rnd(274L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_274() { val a = rnd(274L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_275() { val a = rnd(275L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_275() { val a = rnd(275L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_276() { val a = rnd(276L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_276() { val a = rnd(276L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_277() { val a = rnd(277L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_277() { val a = rnd(277L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_278() { val a = rnd(278L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_278() { val a = rnd(278L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_279() { val a = rnd(279L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_279() { val a = rnd(279L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_280() { val a = rnd(280L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_280() { val a = rnd(280L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_281() { val a = rnd(281L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_281() { val a = rnd(281L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_282() { val a = rnd(282L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_282() { val a = rnd(282L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_283() { val a = rnd(283L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_283() { val a = rnd(283L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_284() { val a = rnd(284L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_284() { val a = rnd(284L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_285() { val a = rnd(285L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_285() { val a = rnd(285L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_286() { val a = rnd(286L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_286() { val a = rnd(286L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_287() { val a = rnd(287L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_287() { val a = rnd(287L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_288() { val a = rnd(288L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_288() { val a = rnd(288L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_289() { val a = rnd(289L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_289() { val a = rnd(289L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_290() { val a = rnd(290L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_290() { val a = rnd(290L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_291() { val a = rnd(291L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_291() { val a = rnd(291L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_292() { val a = rnd(292L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_292() { val a = rnd(292L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_293() { val a = rnd(293L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_293() { val a = rnd(293L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_294() { val a = rnd(294L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_294() { val a = rnd(294L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_295() { val a = rnd(295L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_295() { val a = rnd(295L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_296() { val a = rnd(296L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_296() { val a = rnd(296L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_297() { val a = rnd(297L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_297() { val a = rnd(297L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_298() { val a = rnd(298L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_298() { val a = rnd(298L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_299() { val a = rnd(299L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_299() { val a = rnd(299L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_300() { val a = rnd(300L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_300() { val a = rnd(300L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_301() { val a = rnd(301L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_301() { val a = rnd(301L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_302() { val a = rnd(302L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_302() { val a = rnd(302L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_303() { val a = rnd(303L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_303() { val a = rnd(303L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_304() { val a = rnd(304L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_304() { val a = rnd(304L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_305() { val a = rnd(305L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_305() { val a = rnd(305L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_306() { val a = rnd(306L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_306() { val a = rnd(306L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_307() { val a = rnd(307L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_307() { val a = rnd(307L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_308() { val a = rnd(308L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_308() { val a = rnd(308L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_309() { val a = rnd(309L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_309() { val a = rnd(309L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_310() { val a = rnd(310L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_310() { val a = rnd(310L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_311() { val a = rnd(311L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_311() { val a = rnd(311L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_312() { val a = rnd(312L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_312() { val a = rnd(312L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_313() { val a = rnd(313L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_313() { val a = rnd(313L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_314() { val a = rnd(314L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_314() { val a = rnd(314L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_315() { val a = rnd(315L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_315() { val a = rnd(315L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_316() { val a = rnd(316L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_316() { val a = rnd(316L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_317() { val a = rnd(317L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_317() { val a = rnd(317L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_318() { val a = rnd(318L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_318() { val a = rnd(318L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_319() { val a = rnd(319L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_319() { val a = rnd(319L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_320() { val a = rnd(320L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_320() { val a = rnd(320L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_321() { val a = rnd(321L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_321() { val a = rnd(321L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_322() { val a = rnd(322L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_322() { val a = rnd(322L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_323() { val a = rnd(323L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_323() { val a = rnd(323L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_324() { val a = rnd(324L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_324() { val a = rnd(324L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_325() { val a = rnd(325L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_325() { val a = rnd(325L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_326() { val a = rnd(326L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_326() { val a = rnd(326L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_327() { val a = rnd(327L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_327() { val a = rnd(327L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_328() { val a = rnd(328L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_328() { val a = rnd(328L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_329() { val a = rnd(329L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_329() { val a = rnd(329L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_330() { val a = rnd(330L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_330() { val a = rnd(330L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_331() { val a = rnd(331L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_331() { val a = rnd(331L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_332() { val a = rnd(332L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_332() { val a = rnd(332L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_333() { val a = rnd(333L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_333() { val a = rnd(333L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_334() { val a = rnd(334L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_334() { val a = rnd(334L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_335() { val a = rnd(335L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_335() { val a = rnd(335L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_336() { val a = rnd(336L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_336() { val a = rnd(336L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_337() { val a = rnd(337L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_337() { val a = rnd(337L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_338() { val a = rnd(338L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_338() { val a = rnd(338L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_339() { val a = rnd(339L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_339() { val a = rnd(339L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_340() { val a = rnd(340L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_340() { val a = rnd(340L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_341() { val a = rnd(341L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_341() { val a = rnd(341L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_342() { val a = rnd(342L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_342() { val a = rnd(342L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_343() { val a = rnd(343L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_343() { val a = rnd(343L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_344() { val a = rnd(344L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_344() { val a = rnd(344L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_345() { val a = rnd(345L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_345() { val a = rnd(345L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_346() { val a = rnd(346L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_346() { val a = rnd(346L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_347() { val a = rnd(347L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_347() { val a = rnd(347L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_348() { val a = rnd(348L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_348() { val a = rnd(348L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_349() { val a = rnd(349L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_349() { val a = rnd(349L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_350() { val a = rnd(350L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_350() { val a = rnd(350L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_351() { val a = rnd(351L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_351() { val a = rnd(351L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_352() { val a = rnd(352L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_352() { val a = rnd(352L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_353() { val a = rnd(353L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_353() { val a = rnd(353L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_354() { val a = rnd(354L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_354() { val a = rnd(354L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_355() { val a = rnd(355L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_355() { val a = rnd(355L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_356() { val a = rnd(356L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_356() { val a = rnd(356L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_357() { val a = rnd(357L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_357() { val a = rnd(357L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_358() { val a = rnd(358L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_358() { val a = rnd(358L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_359() { val a = rnd(359L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_359() { val a = rnd(359L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_360() { val a = rnd(360L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_360() { val a = rnd(360L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_361() { val a = rnd(361L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_361() { val a = rnd(361L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_362() { val a = rnd(362L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_362() { val a = rnd(362L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_363() { val a = rnd(363L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_363() { val a = rnd(363L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_364() { val a = rnd(364L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_364() { val a = rnd(364L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_365() { val a = rnd(365L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_365() { val a = rnd(365L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_366() { val a = rnd(366L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_366() { val a = rnd(366L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_367() { val a = rnd(367L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_367() { val a = rnd(367L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_368() { val a = rnd(368L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_368() { val a = rnd(368L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_369() { val a = rnd(369L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_369() { val a = rnd(369L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_370() { val a = rnd(370L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_370() { val a = rnd(370L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_371() { val a = rnd(371L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_371() { val a = rnd(371L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_372() { val a = rnd(372L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_372() { val a = rnd(372L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_373() { val a = rnd(373L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_373() { val a = rnd(373L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_374() { val a = rnd(374L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_374() { val a = rnd(374L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_375() { val a = rnd(375L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_375() { val a = rnd(375L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_376() { val a = rnd(376L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_376() { val a = rnd(376L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_377() { val a = rnd(377L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_377() { val a = rnd(377L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_378() { val a = rnd(378L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_378() { val a = rnd(378L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_379() { val a = rnd(379L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_379() { val a = rnd(379L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_380() { val a = rnd(380L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_380() { val a = rnd(380L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_381() { val a = rnd(381L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_381() { val a = rnd(381L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_382() { val a = rnd(382L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_382() { val a = rnd(382L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_383() { val a = rnd(383L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_383() { val a = rnd(383L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_384() { val a = rnd(384L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_384() { val a = rnd(384L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_385() { val a = rnd(385L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_385() { val a = rnd(385L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_386() { val a = rnd(386L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_386() { val a = rnd(386L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_387() { val a = rnd(387L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_387() { val a = rnd(387L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_388() { val a = rnd(388L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_388() { val a = rnd(388L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_389() { val a = rnd(389L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_389() { val a = rnd(389L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_390() { val a = rnd(390L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_390() { val a = rnd(390L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_391() { val a = rnd(391L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_391() { val a = rnd(391L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_392() { val a = rnd(392L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_392() { val a = rnd(392L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_393() { val a = rnd(393L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_393() { val a = rnd(393L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_394() { val a = rnd(394L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_394() { val a = rnd(394L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_395() { val a = rnd(395L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_395() { val a = rnd(395L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_396() { val a = rnd(396L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_396() { val a = rnd(396L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_397() { val a = rnd(397L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_397() { val a = rnd(397L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_398() { val a = rnd(398L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_398() { val a = rnd(398L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_399() { val a = rnd(399L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_399() { val a = rnd(399L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun roundTrip_400() { val a = rnd(400L); same(a, NotePure.decode(NotePure.encode(a))!!) }
    @Test fun reEncodeStable_400() { val a = rnd(400L); val e1 = NotePure.encode(a); assertEquals(e1, NotePure.encode(NotePure.decode(e1)!!)) }
    @Test fun segDist_0() { assertEquals(0.436773968386849f, NotePure.segDist(0.55f, 0.678f, Pt(0.324f, 0.302f), Pt(0.651f, 0.145f)), 0.0005f) }
    @Test fun segDist_1() { assertEquals(0.8603034348414517f, NotePure.segDist(-0.102f, 0.018f, Pt(0.058f, 1.015f), Pt(0.037f, 0.867f)), 0.0005f) }
    @Test fun segDist_2() { assertEquals(0.49117206760971277f, NotePure.segDist(0.678f, 2.075f, Pt(0.425f, 1.654f), Pt(0.124f, 0.446f)), 0.0005f) }
    @Test fun segDist_3() { assertEquals(0.22165983271695552f, NotePure.segDist(1.002f, 0.495f, Pt(0.577f, 0.793f), Pt(0.976f, 0.093f)), 0.0005f) }
    @Test fun segDist_4() { assertEquals(0.20238755970709515f, NotePure.segDist(0.053f, 1.196f, Pt(0.144f, 0.236f), Pt(0.308f, 1.632f)), 0.0005f) }
    @Test fun segDist_5() { assertEquals(0.6823635841896887f, NotePure.segDist(-0.117f, 0.294f, Pt(0.639f, 0.745f), Pt(0.548f, 0.126f)), 0.0005f) }
    @Test fun segDist_6() { assertEquals(0.4164276647870552f, NotePure.segDist(0.434f, 0.519f, Pt(0.68f, 0.855f), Pt(0.314f, 1.171f)), 0.0005f) }
    @Test fun segDist_7() { assertEquals(0.5641359880215358f, NotePure.segDist(0.535f, 1.9f, Pt(0.794f, 1.398f), Pt(0.244f, 1.149f)), 0.0005f) }
    @Test fun segDist_8() { assertEquals(1.0963653588106475f, NotePure.segDist(0.385f, 1.617f, Pt(0.729f, 0.576f), Pt(0.98f, 0.236f)), 0.0005f) }
    @Test fun segDist_9() { assertEquals(0.7445354256178816f, NotePure.segDist(0.87f, 1.175f, Pt(0.152f, 0.978f), Pt(0.039f, 1.336f)), 0.0005f) }
    @Test fun segDist_10() { assertEquals(0.16872103803884297f, NotePure.segDist(0.612f, 0.895f, Pt(0.875f, 0.627f), Pt(0.695f, 1.189f)), 0.0005f) }
    @Test fun segDist_11() { assertEquals(0.6093086245901989f, NotePure.segDist(-0.115f, 1.484f, Pt(0.84f, 1.889f), Pt(0.474f, 1.328f)), 0.0005f) }
    @Test fun segDist_12() { assertEquals(0.3758978925586604f, NotePure.segDist(0.34f, 1.405f, Pt(0.647f, 1.986f), Pt(0.822f, 0.569f)), 0.0005f) }
    @Test fun segDist_13() { assertEquals(0.7344664730265091f, NotePure.segDist(-0.117f, 1.644f, Pt(0.023f, 0.923f), Pt(0.168f, 0.234f)), 0.0005f) }
    @Test fun segDist_14() { assertEquals(0.2900819682678942f, NotePure.segDist(-0.087f, 0.878f, Pt(0.129f, 0.495f), Pt(0.391f, 1.743f)), 0.0005f) }
    @Test fun segDist_15() { assertEquals(1.0343021802162073f, NotePure.segDist(0.19f, 0.797f, Pt(0.549f, 1.767f), Pt(0.819f, 1.728f)), 0.0005f) }
    @Test fun segDist_16() { assertEquals(0.8225166462607857f, NotePure.segDist(0.047f, 0.357f, Pt(0.359f, 1.768f), Pt(0.958f, 0.302f)), 0.0005f) }
    @Test fun segDist_17() { assertEquals(0.4577706849504455f, NotePure.segDist(-0.194f, 0.805f, Pt(0.233f, 0.97f), Pt(0.589f, 0.525f)), 0.0005f) }
    @Test fun segDist_18() { assertEquals(0.07734254326313672f, NotePure.segDist(0.522f, 1.282f, Pt(0.369f, 1.133f), Pt(0.953f, 1.381f)), 0.0005f) }
    @Test fun segDist_19() { assertEquals(0.19849685136041834f, NotePure.segDist(1.024f, 1.715f, Pt(0.676f, 0.108f), Pt(0.9f, 1.56f)), 0.0005f) }
    @Test fun segDist_20() { assertEquals(0.9766887938335322f, NotePure.segDist(-0.113f, -0.038f, Pt(0.392f, 0.798f), Pt(0.104f, 1.269f)), 0.0005f) }
    @Test fun segDist_21() { assertEquals(0.43991476447148264f, NotePure.segDist(-0.2f, 0.163f, Pt(0.209f, 0.325f), Pt(0.34f, 0.105f)), 0.0005f) }
    @Test fun segDist_22() { assertEquals(0.7983614469649696f, NotePure.segDist(0.66f, 0.157f, Pt(0.101f, 0.727f), Pt(0.026f, 1.749f)), 0.0005f) }
    @Test fun segDist_23() { assertEquals(1.6605158836939802f, NotePure.segDist(0.989f, 2.183f, Pt(0.252f, 0.695f), Pt(0.364f, 0.246f)), 0.0005f) }
    @Test fun segDist_24() { assertEquals(0.07082741473700793f, NotePure.segDist(0.28f, 0.435f, Pt(0.466f, 0.968f), Pt(0.086f, 0.204f)), 0.0005f) }
    @Test fun segDist_25() { assertEquals(0.3358005360329253f, NotePure.segDist(0.54f, 0.152f, Pt(0.829f, 0.323f), Pt(0.023f, 1.902f)), 0.0005f) }
    @Test fun segDist_26() { assertEquals(0.47715438382286646f, NotePure.segDist(1.009f, 1.471f, Pt(0.543f, 0.054f), Pt(0.528f, 1.957f)), 0.0005f) }
    @Test fun segDist_27() { assertEquals(0.399395793668386f, NotePure.segDist(0.546f, 1.67f, Pt(0.261f, 0.733f), Pt(0.167f, 1.544f)), 0.0005f) }
    @Test fun segDist_28() { assertEquals(0.2443923090158406f, NotePure.segDist(0.994f, 1.735f, Pt(0.33f, 0.446f), Pt(0.812f, 1.97f)), 0.0005f) }
    @Test fun segDist_29() { assertEquals(1.167161514101626f, NotePure.segDist(0.298f, -0.13f, Pt(0.818f, 1.48f), Pt(0.227f, 1.035f)), 0.0005f) }
    @Test fun segDist_30() { assertEquals(0.9853784071151646f, NotePure.segDist(1.139f, 0.873f, Pt(0.028f, 0.559f), Pt(0.259f, 1.385f)), 0.0005f) }
    @Test fun segDist_31() { assertEquals(0.9294842656010913f, NotePure.segDist(0.109f, 0.344f, Pt(0.937f, 1.976f), Pt(0.955f, 0.729f)), 0.0005f) }
    @Test fun segDist_32() { assertEquals(0.5867544744793629f, NotePure.segDist(0.977f, 0.951f, Pt(0.197f, 0.409f), Pt(0.624f, 1.801f)), 0.0005f) }
    @Test fun segDist_33() { assertEquals(0.4283479893731264f, NotePure.segDist(1.074f, 1.678f, Pt(0.653f, 1.599f), Pt(0.085f, 1.321f)), 0.0005f) }
    @Test fun segDist_34() { assertEquals(0.16824089871371933f, NotePure.segDist(0.266f, 1.722f, Pt(0.75f, 0.956f), Pt(0.179f, 1.578f)), 0.0005f) }
    @Test fun segDist_35() { assertEquals(0.6047354793626715f, NotePure.segDist(0.815f, 0.208f, Pt(0.972f, 0.792f), Pt(0.401f, 1.894f)), 0.0005f) }
    @Test fun segDist_36() { assertEquals(0.8612429683773885f, NotePure.segDist(0.005f, 1.784f, Pt(0.127f, 0.302f), Pt(0.905f, 1.613f)), 0.0005f) }
    @Test fun segDist_37() { assertEquals(1.3152406623884465f, NotePure.segDist(-0.017f, -0.166f, Pt(0.98f, 1.315f), Pt(0.35f, 1.097f)), 0.0005f) }
    @Test fun segDist_38() { assertEquals(0.12257650672131266f, NotePure.segDist(0.407f, 1.892f, Pt(0.971f, 1.299f), Pt(0.527f, 1.867f)), 0.0005f) }
    @Test fun segDist_39() { assertEquals(0.6315583900163152f, NotePure.segDist(0.137f, 1.207f, Pt(0.826f, 0.422f), Pt(0.252f, 0.586f)), 0.0005f) }
    @Test fun segDist_40() { assertEquals(0.043711696464112576f, NotePure.segDist(0.295f, 0.9f, Pt(0.259f, 0.838f), Pt(0.131f, 1.82f)), 0.0005f) }
    @Test fun segDist_41() { assertEquals(0.7374618634207465f, NotePure.segDist(0.502f, 1.076f, Pt(0.583f, 1.809f), Pt(0.421f, 1.835f)), 0.0005f) }
    @Test fun segDist_42() { assertEquals(1.4932715761039583f, NotePure.segDist(-0.194f, 1.718f, Pt(0.524f, 0.037f), Pt(0.44f, 0.366f)), 0.0005f) }
    @Test fun segDist_43() { assertEquals(0.0687539551727505f, NotePure.segDist(0.256f, 1.044f, Pt(0.172f, 0.947f), Pt(0.725f, 1.113f)), 0.0005f) }
    @Test fun segDist_44() { assertEquals(0.6573431371817917f, NotePure.segDist(0.148f, 0.465f, Pt(0.555f, 1.569f), Pt(0.106f, 1.121f)), 0.0005f) }
    @Test fun segDist_45() { assertEquals(0.3403321906608306f, NotePure.segDist(1.077f, 0.864f, Pt(0.772f, 1.015f), Pt(0.562f, 1.52f)), 0.0005f) }
    @Test fun segDist_46() { assertEquals(0.15578563210249183f, NotePure.segDist(0.433f, 1.08f, Pt(0.613f, 1.011f), Pt(0.512f, 1.385f)), 0.0005f) }
    @Test fun segDist_47() { assertEquals(1.394740119161989f, NotePure.segDist(1.119f, 0.423f, Pt(0.478f, 1.883f), Pt(0.699f, 1.753f)), 0.0005f) }
    @Test fun segDist_48() { assertEquals(0.756785304474685f, NotePure.segDist(-0.03f, 0.861f, Pt(0.56f, 1.887f), Pt(0.84f, 0.274f)), 0.0005f) }
    @Test fun segDist_49() { assertEquals(1.0284070205905833f, NotePure.segDist(0.898f, 1.953f, Pt(0.073f, 0.481f), Pt(0.073f, 1.339f)), 0.0005f) }
    @Test fun segDist_50() { assertEquals(1.1198321302766767f, NotePure.segDist(1.036f, 2.122f, Pt(0.154f, 1.432f), Pt(0.66f, 0.286f)), 0.0005f) }
    @Test fun segDist_51() { assertEquals(0.9286634937838176f, NotePure.segDist(1.186f, 1.798f, Pt(0.22f, 1.905f), Pt(0.398f, 0.975f)), 0.0005f) }
    @Test fun segDist_52() { assertEquals(0.3053615294213501f, NotePure.segDist(0.074f, 0.564f, Pt(0.161f, 0.863f), Pt(0.516f, 0.678f)), 0.0005f) }
    @Test fun segDist_53() { assertEquals(0.7706739748832004f, NotePure.segDist(-0.175f, 0.596f, Pt(0.722f, 0.039f), Pt(0.554f, 0.881f)), 0.0005f) }
    @Test fun segDist_54() { assertEquals(0.8052328754815873f, NotePure.segDist(0.904f, 2.132f, Pt(0.624f, 1.025f), Pt(0.064f, 1.97f)), 0.0005f) }
    @Test fun segDist_55() { assertEquals(0.4264692251499515f, NotePure.segDist(0.179f, 0.111f, Pt(0.105f, 0.531f), Pt(0.04f, 1.558f)), 0.0005f) }
    @Test fun segDist_56() { assertEquals(0.45172779414156033f, NotePure.segDist(0.009f, 2.006f, Pt(0.422f, 1.823f), Pt(0.819f, 0.517f)), 0.0005f) }
    @Test fun segDist_57() { assertEquals(0.38334571965787495f, NotePure.segDist(0.763f, 0.821f, Pt(0.571f, 1.401f), Pt(0.089f, 0.115f)), 0.0005f) }
    @Test fun segDist_58() { assertEquals(0.1565535052306399f, NotePure.segDist(-0.083f, 1.855f, Pt(0.072f, 1.877f), Pt(0.634f, 1.603f)), 0.0005f) }
    @Test fun segDist_59() { assertEquals(0.5880926797707994f, NotePure.segDist(0.574f, 2.024f, Pt(0.067f, 1.726f), Pt(0.454f, 0.678f)), 0.0005f) }
    @Test fun segDist_60() { assertEquals(0.32290246205317175f, NotePure.segDist(-0.047f, 0.187f, Pt(0.268f, 0.258f), Pt(0.527f, 0.477f)), 0.0005f) }
    @Test fun segDist_61() { assertEquals(0.5626695300085122f, NotePure.segDist(0.863f, 0.496f, Pt(0.05f, 0.404f), Pt(0.312f, 0.61f)), 0.0005f) }
    @Test fun segDist_62() { assertEquals(0.2793152340993953f, NotePure.segDist(0.151f, -0.163f, Pt(0.5f, 0.356f), Pt(0.347f, 0.036f)), 0.0005f) }
    @Test fun segDist_63() { assertEquals(1.1121303880391005f, NotePure.segDist(1.108f, 0.055f, Pt(0.733f, 1.102f), Pt(0.189f, 0.95f)), 0.0005f) }
    @Test fun segDist_64() { assertEquals(0.378328568941973f, NotePure.segDist(0.35f, 1.016f, Pt(0.819f, 0.864f), Pt(0.495f, 1.669f)), 0.0005f) }
    @Test fun segDist_65() { assertEquals(0.5484669788698829f, NotePure.segDist(0.789f, 1.326f, Pt(0.688f, 1.965f), Pt(0.343f, 1.665f)), 0.0005f) }
    @Test fun segDist_66() { assertEquals(1.0177057531526488f, NotePure.segDist(-0.101f, 1.578f, Pt(0.405f, 0.695f), Pt(0.054f, 0.26f)), 0.0005f) }
    @Test fun segDist_67() { assertEquals(0.8931247387056865f, NotePure.segDist(1.019f, 1.409f, Pt(0.256f, 0.326f), Pt(0.084f, 1.683f)), 0.0005f) }
    @Test fun segDist_68() { assertEquals(0.27067439194783205f, NotePure.segDist(0.021f, 0.87f, Pt(0.282f, 0.484f), Pt(0.293f, 0.919f)), 0.0005f) }
    @Test fun segDist_69() { assertEquals(0.22864164100180873f, NotePure.segDist(0.142f, 2.118f, Pt(0.263f, 1.924f), Pt(0.973f, 1.094f)), 0.0005f) }
    @Test fun segDist_70() { assertEquals(0.3323567360532956f, NotePure.segDist(0.465f, 1.007f, Pt(0.31f, 0.713f), Pt(0.001f, 0.763f)), 0.0005f) }
    @Test fun segDist_71() { assertEquals(0.16032903585302638f, NotePure.segDist(-0.074f, 0.759f, Pt(0.201f, 1.009f), Pt(0.005f, 0.528f)), 0.0005f) }
    @Test fun segDist_72() { assertEquals(0.681668541154717f, NotePure.segDist(0.62f, 1.07f, Pt(0.042f, 0.045f), Pt(0.304f, 0.466f)), 0.0005f) }
    @Test fun segDist_73() { assertEquals(0.8370543590472485f, NotePure.segDist(0.345f, 0.583f, Pt(0.751f, 1.315f), Pt(0.716f, 1.758f)), 0.0005f) }
    @Test fun segDist_74() { assertEquals(1.0070402176675963f, NotePure.segDist(-0.139f, 1.805f, Pt(0.985f, 0.299f), Pt(0.724f, 1.286f)), 0.0005f) }
    @Test fun segDist_75() { assertEquals(0.9025251180428253f, NotePure.segDist(-0.005f, 1.057f, Pt(0.892f, 1.255f), Pt(0.734f, 1.624f)), 0.0005f) }
    @Test fun segDist_76() { assertEquals(0.27899392364168096f, NotePure.segDist(0.618f, 1.943f, Pt(0.504f, 1.67f), Pt(0.805f, 1.653f)), 0.0005f) }
    @Test fun segDist_77() { assertEquals(0.4262750317433991f, NotePure.segDist(-0.014f, 0.666f, Pt(0.683f, 1.387f), Pt(0.23f, 0.062f)), 0.0005f) }
    @Test fun segDist_78() { assertEquals(0.2109555819376748f, NotePure.segDist(0.677f, 1.434f, Pt(0.105f, 1.672f), Pt(0.559f, 1.256f)), 0.0005f) }
    @Test fun segDist_79() { assertEquals(0.20401020062467684f, NotePure.segDist(0.504f, 1.084f, Pt(0.489f, 0.007f), Pt(0.798f, 1.497f)), 0.0005f) }
    @Test fun segDist_80() { assertEquals(0.8015218245534458f, NotePure.segDist(-0.096f, 0.437f, Pt(0.659f, 0.132f), Pt(0.737f, 0.504f)), 0.0005f) }
    @Test fun segDist_81() { assertEquals(0.2391924785010649f, NotePure.segDist(0.492f, 0.718f, Pt(0.729f, 0.41f), Pt(0.74f, 1.951f)), 0.0005f) }
    @Test fun segDist_82() { assertEquals(1.2497971835461945f, NotePure.segDist(0.7f, -0.014f, Pt(0.479f, 1.367f), Pt(0.767f, 1.234f)), 0.0005f) }
    @Test fun segDist_83() { assertEquals(0.7433217505065205f, NotePure.segDist(0.595f, -0.17f, Pt(0.147f, 0.508f), Pt(0.743f, 0.609f)), 0.0005f) }
    @Test fun segDist_84() { assertEquals(0.5787348936076928f, NotePure.segDist(0.746f, 0.498f, Pt(0.061f, 0.538f), Pt(0.672f, 1.384f)), 0.0005f) }
    @Test fun segDist_85() { assertEquals(0.5804041952099659f, NotePure.segDist(1.051f, 0.278f, Pt(0.517f, 0.929f), Pt(0.466f, 0.237f)), 0.0005f) }
    @Test fun segDist_86() { assertEquals(0.25179356624028365f, NotePure.segDist(0.948f, 2.123f, Pt(0.978f, 1.873f), Pt(0.018f, 0.918f)), 0.0005f) }
    @Test fun segDist_87() { assertEquals(0.23405891019347183f, NotePure.segDist(0.095f, 1.196f, Pt(0.449f, 0.537f), Pt(0.21f, 1.891f)), 0.0005f) }
    @Test fun segDist_88() { assertEquals(0.5404061661127157f, NotePure.segDist(0.948f, 1.021f, Pt(0.142f, 1.048f), Pt(0.953f, 0.265f)), 0.0005f) }
    @Test fun segDist_89() { assertEquals(1.5993889458164954f, NotePure.segDist(0.481f, -0.14f, Pt(0.887f, 1.407f), Pt(0.231f, 1.795f)), 0.0005f) }
    @Test fun segDist_90() { assertEquals(0.27682465150503693f, NotePure.segDist(-0.003f, 0.626f, Pt(0.004f, 0.983f), Pt(0.451f, 0.604f)), 0.0005f) }
    @Test fun segDist_91() { assertEquals(1.7094218420459755f, NotePure.segDist(0.975f, 0.088f, Pt(0.316f, 1.68f), Pt(0.002f, 1.501f)), 0.0005f) }
    @Test fun segDist_92() { assertEquals(0.5853886038437864f, NotePure.segDist(0.321f, 0.743f, Pt(0.926f, 1.426f), Pt(0.902f, 0.58f)), 0.0005f) }
    @Test fun segDist_93() { assertEquals(0.9563346694541612f, NotePure.segDist(0.185f, -0.084f, Pt(0.999f, 1.178f), Pt(0.361f, 0.856f)), 0.0005f) }
    @Test fun segDist_94() { assertEquals(1.2318969112713938f, NotePure.segDist(0.149f, 0.438f, Pt(0.102f, 1.669f), Pt(0.286f, 1.871f)), 0.0005f) }
    @Test fun segDist_95() { assertEquals(0.64769480932327f, NotePure.segDist(1.038f, 1.749f, Pt(0.511f, 0.38f), Pt(0.373f, 1.912f)), 0.0005f) }
    @Test fun segDist_96() { assertEquals(1.1865904938098906f, NotePure.segDist(0.807f, -0.081f, Pt(0.631f, 1.827f), Pt(0.941f, 1.098f)), 0.0005f) }
    @Test fun segDist_97() { assertEquals(1.1181310298887157f, NotePure.segDist(0.201f, -0.082f, Pt(0.732f, 0.902f), Pt(0.753f, 1.289f)), 0.0005f) }
    @Test fun segDist_98() { assertEquals(0.9229268660083528f, NotePure.segDist(0.217f, 1.574f, Pt(0.927f, 0.255f), Pt(0.472f, 0.687f)), 0.0005f) }
    @Test fun segDist_99() { assertEquals(0.162825059496381f, NotePure.segDist(0.58f, 0.746f, Pt(0.976f, 0.52f), Pt(0.656f, 0.602f)), 0.0005f) }
    @Test fun segDist_100() { assertEquals(0.3287377244162852f, NotePure.segDist(0.496f, 0.328f, Pt(0.167f, 0.323f), Pt(0.208f, 1.812f)), 0.0005f) }
    @Test fun segDist_101() { assertEquals(0.46182464204500834f, NotePure.segDist(0.069f, 0.018f, Pt(0.906f, 1.993f), Pt(0.45f, 0.279f)), 0.0005f) }
    @Test fun segDist_102() { assertEquals(1.4566770403902163f, NotePure.segDist(0.597f, 1.929f, Pt(0.342f, 0.182f), Pt(0.239f, 0.517f)), 0.0005f) }
    @Test fun segDist_103() { assertEquals(0.4111783246359035f, NotePure.segDist(0.328f, 0.612f, Pt(0.75f, 0.826f), Pt(0.414f, 1.048f)), 0.0005f) }
    @Test fun segDist_104() { assertEquals(0.8574729898124926f, NotePure.segDist(0.505f, 1.311f, Pt(0.062f, 0.555f), Pt(0.968f, 0.252f)), 0.0005f) }
    @Test fun segDist_105() { assertEquals(0.3804853697702429f, NotePure.segDist(0.36f, 0.87f, Pt(0.863f, 0.432f), Pt(0.271f, 0.497f)), 0.0005f) }
    @Test fun segDist_106() { assertEquals(1.098175980500751f, NotePure.segDist(-0.155f, 1.503f, Pt(0.954f, 1.697f), Pt(0.873f, 0.044f)), 0.0005f) }
    @Test fun segDist_107() { assertEquals(1.2084010095990485f, NotePure.segDist(0.348f, 2.024f, Pt(0.896f, 0.947f), Pt(0.587f, 0.0f)), 0.0005f) }
    @Test fun segDist_108() { assertEquals(1.069877095745114f, NotePure.segDist(-0.047f, 0.171f, Pt(0.826f, 1.711f), Pt(0.972f, 0.497f)), 0.0005f) }
    @Test fun segDist_109() { assertEquals(0.233199087505682f, NotePure.segDist(0.706f, 1.636f, Pt(0.522f, 1.364f), Pt(0.941f, 1.443f)), 0.0005f) }
    @Test fun segDist_110() { assertEquals(0.4512704289004544f, NotePure.segDist(0.126f, 2.008f, Pt(0.457f, 1.103f), Pt(0.04f, 1.565f)), 0.0005f) }
    @Test fun segDist_111() { assertEquals(0.8701643522921404f, NotePure.segDist(0.691f, 1.477f, Pt(0.646f, 0.608f), Pt(0.128f, 0.504f)), 0.0005f) }
    @Test fun segDist_112() { assertEquals(0.14123522972839317f, NotePure.segDist(0.343f, 0.337f, Pt(0.112f, 0.141f), Pt(0.524f, 1.166f)), 0.0005f) }
    @Test fun segDist_113() { assertEquals(0.9427390943415892f, NotePure.segDist(1.143f, 1.347f, Pt(0.601f, 0.021f), Pt(0.302f, 0.921f)), 0.0005f) }
    @Test fun segDist_114() { assertEquals(0.599767454935661f, NotePure.segDist(1.145f, 1.491f, Pt(0.884f, 0.951f), Pt(0.235f, 0.494f)), 0.0005f) }
    @Test fun segDist_115() { assertEquals(0.026129284198128166f, NotePure.segDist(0.388f, 0.417f, Pt(0.307f, 0.044f), Pt(0.498f, 1.349f)), 0.0005f) }
    @Test fun segDist_116() { assertEquals(0.13296959459665997f, NotePure.segDist(0.273f, 0.809f, Pt(0.667f, 1.85f), Pt(0.227f, 0.068f)), 0.0005f) }
    @Test fun segDist_117() { assertEquals(0.2039240054530119f, NotePure.segDist(0.507f, 0.293f, Pt(0.683f, 0.396f), Pt(0.797f, 1.478f)), 0.0005f) }
    @Test fun segDist_118() { assertEquals(1.3204559818486945f, NotePure.segDist(0.11f, 1.625f, Pt(0.97f, 0.623f), Pt(0.82f, 0.462f)), 0.0005f) }
    @Test fun segDist_119() { assertEquals(0.3242093075130044f, NotePure.segDist(0.113f, 0.801f, Pt(0.295f, 1.904f), Pt(0.496f, 0.375f)), 0.0005f) }
    @Test fun segDist_120() { assertEquals(0.6152895183366162f, NotePure.segDist(0.098f, 2.138f, Pt(0.665f, 1.898f), Pt(0.146f, 0.787f)), 0.0005f) }
    @Test fun segDist_121() { assertEquals(1.5099552973515473f, NotePure.segDist(1.057f, 1.921f, Pt(0.142f, 0.104f), Pt(0.06f, 0.787f)), 0.0005f) }
    @Test fun segDist_122() { assertEquals(0.6749296259611072f, NotePure.segDist(0.06f, 2.046f, Pt(0.733f, 1.995f), Pt(0.932f, 0.658f)), 0.0005f) }
    @Test fun segDist_123() { assertEquals(0.3575561215186275f, NotePure.segDist(0.323f, 0.596f, Pt(0.746f, 0.064f), Pt(0.664f, 0.757f)), 0.0005f) }
    @Test fun segDist_124() { assertEquals(0.9426293374288234f, NotePure.segDist(1.138f, 0.097f, Pt(0.169f, 0.006f), Pt(0.28f, 0.703f)), 0.0005f) }
    @Test fun segDist_125() { assertEquals(0.1757861040059763f, NotePure.segDist(0.951f, 0.838f, Pt(0.964f, 0.415f), Pt(0.357f, 1.643f)), 0.0005f) }
    @Test fun segDist_126() { assertEquals(0.2738065010185112f, NotePure.segDist(0.07f, 0.674f, Pt(0.049f, 0.947f), Pt(0.373f, 1.839f)), 0.0005f) }
    @Test fun segDist_127() { assertEquals(0.16475739740600417f, NotePure.segDist(0.873f, -0.102f, Pt(0.897f, 0.061f), Pt(0.411f, 1.624f)), 0.0005f) }
    @Test fun segDist_128() { assertEquals(1.444896190042731f, NotePure.segDist(0.846f, 1.957f, Pt(0.035f, 0.125f), Pt(0.92f, 0.514f)), 0.0005f) }
    @Test fun segDist_129() { assertEquals(0.7795487317837249f, NotePure.segDist(0.167f, 1.52f, Pt(0.339f, 0.545f), Pt(0.958f, 1.234f)), 0.0005f) }
    @Test fun segDist_130() { assertEquals(0.9677484924888945f, NotePure.segDist(1.083f, 1.322f, Pt(0.316f, 0.551f), Pt(0.004f, 1.511f)), 0.0005f) }
    @Test fun segDist_131() { assertEquals(1.4547666479542347f, NotePure.segDist(1.139f, 2.089f, Pt(0.943f, 0.049f), Pt(0.234f, 0.95f)), 0.0005f) }
    @Test fun segDist_132() { assertEquals(0.7590210800761729f, NotePure.segDist(1.099f, 0.239f, Pt(0.387f, 0.502f), Pt(0.43f, 0.987f)), 0.0005f) }
    @Test fun segDist_133() { assertEquals(0.9030553692880632f, NotePure.segDist(0.65f, 0.587f, Pt(0.803f, 1.477f), Pt(0.823f, 1.546f)), 0.0005f) }
    @Test fun segDist_134() { assertEquals(0.916092244263644f, NotePure.segDist(0.076f, 1.607f, Pt(0.32f, 0.724f), Pt(0.782f, 0.158f)), 0.0005f) }
    @Test fun segDist_135() { assertEquals(1.0712553383764303f, NotePure.segDist(0.256f, 2.153f, Pt(0.247f, 0.129f), Pt(0.034f, 1.105f)), 0.0005f) }
    @Test fun segDist_136() { assertEquals(0.5800711515388606f, NotePure.segDist(-0.065f, 0.996f, Pt(0.883f, 1.976f), Pt(0.265f, 0.168f)), 0.0005f) }
    @Test fun segDist_137() { assertEquals(0.5256805113374472f, NotePure.segDist(0.668f, 1.418f, Pt(0.71f, 0.894f), Pt(0.234f, 0.834f)), 0.0005f) }
    @Test fun segDist_138() { assertEquals(0.29728806272640473f, NotePure.segDist(0.977f, 0.505f, Pt(0.748f, 1.694f), Pt(0.664f, 0.242f)), 0.0005f) }
    @Test fun segDist_139() { assertEquals(0.5352894762707051f, NotePure.segDist(0.146f, 0.389f, Pt(0.567f, 0.746f), Pt(0.738f, 0.398f)), 0.0005f) }
    @Test fun segDist_140() { assertEquals(0.46021408061900926f, NotePure.segDist(0.354f, 2.182f, Pt(0.153f, 1.768f), Pt(0.578f, 0.653f)), 0.0005f) }
    @Test fun segDist_141() { assertEquals(0.7976772530290682f, NotePure.segDist(1.187f, 0.046f, Pt(0.507f, 0.463f), Pt(0.808f, 1.307f)), 0.0005f) }
    @Test fun segDist_142() { assertEquals(1.2905863008725917f, NotePure.segDist(-0.143f, 0.505f, Pt(0.475f, 1.638f), Pt(0.841f, 1.829f)), 0.0005f) }
    @Test fun segDist_143() { assertEquals(0.43524703909502305f, NotePure.segDist(1.102f, 0.693f, Pt(0.119f, 0.379f), Pt(0.973f, 1.166f)), 0.0005f) }
    @Test fun segDist_144() { assertEquals(0.8825531145489205f, NotePure.segDist(1.124f, 0.054f, Pt(0.866f, 0.898f), Pt(0.26f, 1.556f)), 0.0005f) }
    @Test fun segDist_145() { assertEquals(0.4982057807773812f, NotePure.segDist(-0.002f, 0.29f, Pt(0.596f, 1.24f), Pt(0.218f, 0.737f)), 0.0005f) }
    @Test fun segDist_146() { assertEquals(0.6675985800196452f, NotePure.segDist(-0.184f, 0.585f, Pt(0.255f, 1.199f), Pt(0.652f, 0.407f)), 0.0005f) }
    @Test fun segDist_147() { assertEquals(0.781184997295775f, NotePure.segDist(0.913f, 1.115f, Pt(0.678f, 0.37f), Pt(0.312f, 0.407f)), 0.0005f) }
    @Test fun segDist_148() { assertEquals(0.6565732732987425f, NotePure.segDist(0.695f, 0.019f, Pt(0.063f, 0.203f), Pt(0.395f, 1.1f)), 0.0005f) }
    @Test fun segDist_149() { assertEquals(0.7002128247897207f, NotePure.segDist(0.231f, 2.088f, Pt(0.164f, 1.391f), Pt(0.41f, 0.567f)), 0.0005f) }
    @Test fun segDist_150() { assertEquals(1.268339465600594f, NotePure.segDist(1.01f, 2.192f, Pt(0.312f, 1.133f), Pt(0.357f, 0.833f)), 0.0005f) }
    @Test fun segDist_151() { assertEquals(1.6655437550541863f, NotePure.segDist(-0.192f, 1.964f, Pt(0.364f, 0.394f), Pt(0.728f, 0.407f)), 0.0005f) }
    @Test fun segDist_152() { assertEquals(1.4511519562058277f, NotePure.segDist(0.445f, 0.19f, Pt(0.424f, 1.641f), Pt(0.406f, 1.766f)), 0.0005f) }
    @Test fun segDist_153() { assertEquals(0.19275664159769673f, NotePure.segDist(-0.075f, 1.293f, Pt(0.015f, 1.103f), Pt(0.641f, 1.82f)), 0.0005f) }
    @Test fun segDist_154() { assertEquals(1.0244144669029231f, NotePure.segDist(0.53f, 2.021f, Pt(0.371f, 1.009f), Pt(0.146f, 0.567f)), 0.0005f) }
    @Test fun segDist_155() { assertEquals(0.8776206469768131f, NotePure.segDist(0.076f, 0.104f, Pt(0.109f, 0.981f), Pt(0.805f, 1.934f)), 0.0005f) }
    @Test fun segDist_156() { assertEquals(0.4447102432643514f, NotePure.segDist(1.097f, 0.731f, Pt(0.943f, 1.951f), Pt(0.483f, 0.107f)), 0.0005f) }
    @Test fun segDist_157() { assertEquals(0.07369835381301522f, NotePure.segDist(0.9f, 0.333f, Pt(0.904f, 1.241f), Pt(0.825f, 0.321f)), 0.0005f) }
    @Test fun segDist_158() { assertEquals(0.5696318028565439f, NotePure.segDist(0.105f, 0.759f, Pt(0.404f, 1.693f), Pt(0.829f, 0.366f)), 0.0005f) }
    @Test fun segDist_159() { assertEquals(1.223592252345527f, NotePure.segDist(0.815f, 1.954f, Pt(0.518f, 0.767f), Pt(0.123f, 0.494f)), 0.0005f) }
    @Test fun segDist_160() { assertEquals(0.21611339616044162f, NotePure.segDist(0.973f, 0.083f, Pt(0.041f, 1.125f), Pt(0.757f, 0.076f)), 0.0005f) }
    @Test fun segDist_161() { assertEquals(0.23355513267749f, NotePure.segDist(0.388f, 1.198f, Pt(0.6f, 1.1f), Pt(0.627f, 0.612f)), 0.0005f) }
    @Test fun segDist_162() { assertEquals(0.5938984556013013f, NotePure.segDist(-0.167f, 1.285f, Pt(0.426f, 1.318f), Pt(0.447f, 0.877f)), 0.0005f) }
    @Test fun segDist_163() { assertEquals(0.24475293665245362f, NotePure.segDist(0.442f, 0.231f, Pt(0.49f, 0.471f), Pt(0.764f, 1.56f)), 0.0005f) }
    @Test fun segDist_164() { assertEquals(0.2f, NotePure.segDist(-0.072f, 0.861f, Pt(0.473f, 0.214f), Pt(0.128f, 0.861f)), 0.0005f) }
    @Test fun segDist_165() { assertEquals(1.5140954395281692f, NotePure.segDist(0.827f, 1.666f, Pt(0.51f, 0.082f), Pt(0.636f, 0.164f)), 0.0005f) }
    @Test fun segDist_166() { assertEquals(0.6201584499200409f, NotePure.segDist(1.131f, 0.127f, Pt(0.511f, 0.109f), Pt(0.504f, 0.756f)), 0.0005f) }
    @Test fun segDist_167() { assertEquals(0.7964824976411435f, NotePure.segDist(0.071f, 2.156f, Pt(0.857f, 1.992f), Pt(0.732f, 1.63f)), 0.0005f) }
    @Test fun segDist_168() { assertEquals(0.4291200298284852f, NotePure.segDist(0.904f, 2.033f, Pt(0.492f, 1.913f), Pt(0.916f, 0.33f)), 0.0005f) }
    @Test fun segDist_169() { assertEquals(0.3310060422409234f, NotePure.segDist(1.055f, 0.46f, Pt(0.066f, 0.702f), Pt(0.756f, 0.318f)), 0.0005f) }
    @Test fun segDist_170() { assertEquals(0.6811022799990889f, NotePure.segDist(0.092f, 0.431f, Pt(0.816f, 0.287f), Pt(0.502f, 1.84f)), 0.0005f) }
    @Test fun segDist_171() { assertEquals(1.488516375455776f, NotePure.segDist(0.026f, 2.047f, Pt(0.506f, 0.638f), Pt(0.037f, 0.364f)), 0.0005f) }
    @Test fun segDist_172() { assertEquals(0.5378475620470916f, NotePure.segDist(-0.039f, 1.074f, Pt(0.68f, 1.791f), Pt(0.169f, 1.57f)), 0.0005f) }
    @Test fun segDist_173() { assertEquals(0.8491083558651391f, NotePure.segDist(0.612f, 1.918f, Pt(0.636f, 0.72f), Pt(0.873f, 1.11f)), 0.0005f) }
    @Test fun segDist_174() { assertEquals(0.4557246975971348f, NotePure.segDist(0.917f, 0.435f, Pt(0.105f, 1.986f), Pt(0.63f, 0.789f)), 0.0005f) }
    @Test fun segDist_175() { assertEquals(1.0920412431154451f, NotePure.segDist(0.419f, 0.224f, Pt(0.99f, 1.155f), Pt(0.36f, 1.529f)), 0.0005f) }
    @Test fun segDist_176() { assertEquals(1.6597138307551695f, NotePure.segDist(0.695f, 2.162f, Pt(0.744f, 0.097f), Pt(0.82f, 0.507f)), 0.0005f) }
    @Test fun segDist_177() { assertEquals(0.48750694930045846f, NotePure.segDist(-0.153f, 0.158f, Pt(0.586f, 1.327f), Pt(0.313f, 0.004f)), 0.0005f) }
    @Test fun segDist_178() { assertEquals(0.8170201955888239f, NotePure.segDist(-0.015f, 0.345f, Pt(0.616f, 0.864f), Pt(0.513f, 1.791f)), 0.0005f) }
    @Test fun segDist_179() { assertEquals(0.07566356907991914f, NotePure.segDist(-0.051f, 0.657f, Pt(0.653f, 0.045f), Pt(0.003f, 0.71f)), 0.0005f) }
    @Test fun segDist_180() { assertEquals(0.3071646390784938f, NotePure.segDist(0.674f, 0.94f, Pt(0.224f, 1.167f), Pt(0.589f, 0.408f)), 0.0005f) }
    @Test fun segDist_181() { assertEquals(0.2378946794681043f, NotePure.segDist(-0.066f, 1.332f, Pt(0.135f, 1.873f), Pt(0.244f, 0.299f)), 0.0005f) }
    @Test fun segDist_182() { assertEquals(0.8720218838293657f, NotePure.segDist(-0.184f, 1.348f, Pt(0.871f, 1.564f), Pt(0.402f, 0.528f)), 0.0005f) }
    @Test fun segDist_183() { assertEquals(0.8177652474885443f, NotePure.segDist(1.112f, 1.56f, Pt(0.562f, 0.701f), Pt(0.646f, 0.888f)), 0.0005f) }
    @Test fun segDist_184() { assertEquals(0.765f, NotePure.segDist(0.368f, 0.37f, Pt(0.248f, 1.807f), Pt(0.044f, 1.063f)), 0.0005f) }
    @Test fun segDist_185() { assertEquals(1.4644268503411155f, NotePure.segDist(1.117f, 0.141f, Pt(0.058f, 1.558f), Pt(0.012f, 1.102f)), 0.0005f) }
    @Test fun segDist_186() { assertEquals(1.1483553457009723f, NotePure.segDist(0.939f, 0.219f, Pt(0.2f, 1.216f), Pt(0.507f, 1.283f)), 0.0005f) }
    @Test fun segDist_187() { assertEquals(0.7712473957782682f, NotePure.segDist(0.896f, 1.517f, Pt(0.309f, 0.601f), Pt(0.048f, 1.779f)), 0.0005f) }
    @Test fun segDist_188() { assertEquals(0.10331505214633538f, NotePure.segDist(0.838f, 0.886f, Pt(0.006f, 1.689f), Pt(0.745f, 0.931f)), 0.0005f) }
    @Test fun segDist_189() { assertEquals(1.388697231220686f, NotePure.segDist(0.27f, 1.599f, Pt(0.226f, 0.211f), Pt(0.232f, 0.078f)), 0.0005f) }
    @Test fun segDist_190() { assertEquals(0.13236539951686754f, NotePure.segDist(0.575f, 0.847f, Pt(0.695f, 1.691f), Pt(0.712f, 0.532f)), 0.0005f) }
    @Test fun segDist_191() { assertEquals(0.8107983719766586f, NotePure.segDist(1.151f, 0.321f, Pt(0.788f, 1.046f), Pt(0.265f, 1.284f)), 0.0005f) }
    @Test fun segDist_192() { assertEquals(1.697523490264568f, NotePure.segDist(0.841f, 2.067f, Pt(0.88f, 0.03f), Pt(0.26f, 0.472f)), 0.0005f) }
    @Test fun segDist_193() { assertEquals(1.4581827731803718f, NotePure.segDist(0.135f, 1.978f, Pt(0.746f, 0.654f), Pt(0.88f, 0.657f)), 0.0005f) }
    @Test fun segDist_194() { assertEquals(0.1991484964546033f, NotePure.segDist(0.457f, 1.815f, Pt(0.631f, 1.386f), Pt(0.665f, 1.958f)), 0.0005f) }
    @Test fun segDist_195() { assertEquals(0.9241325662479383f, NotePure.segDist(0.598f, 0.539f, Pt(0.698f, 1.715f), Pt(0.437f, 1.449f)), 0.0005f) }
    @Test fun segDist_196() { assertEquals(1.395886814895821f, NotePure.segDist(0.002f, -0.135f, Pt(0.212f, 1.245f), Pt(0.078f, 1.822f)), 0.0005f) }
    @Test fun segDist_197() { assertEquals(0.6344139027480403f, NotePure.segDist(-0.16f, -0.1f, Pt(0.107f, 1.858f), Pt(0.345f, 0.284f)), 0.0005f) }
    @Test fun segDist_198() { assertEquals(0.8026219533503927f, NotePure.segDist(-0.108f, 1.217f, Pt(0.693f, 1.268f), Pt(0.697f, 1.474f)), 0.0005f) }
    @Test fun segDist_199() { assertEquals(0.5323016062346609f, NotePure.segDist(-0.108f, 1.883f, Pt(0.363f, 1.635f), Pt(0.82f, 1.783f)), 0.0005f) }
    @Test fun segDist_200() { assertEquals(0.5488934322798916f, NotePure.segDist(-0.043f, -0.117f, Pt(0.914f, 1.889f), Pt(0.107f, 0.411f)), 0.0005f) }
    @Test fun segDist_201() { assertEquals(1.1455017633748936f, NotePure.segDist(0.684f, 0.49f, Pt(0.848f, 1.624f), Pt(0.634f, 1.65f)), 0.0005f) }
    @Test fun segDist_202() { assertEquals(0.5449395014585304f, NotePure.segDist(0.247f, 0.817f, Pt(0.1f, 0.196f), Pt(0.757f, 0.41f)), 0.0005f) }
    @Test fun segDist_203() { assertEquals(0.26710684236120513f, NotePure.segDist(0.315f, 0.57f, Pt(0.021f, 0.513f), Pt(0.283f, 1.432f)), 0.0005f) }
    @Test fun segDist_204() { assertEquals(1.1022613120308633f, NotePure.segDist(-0.157f, 0.791f, Pt(0.964f, 1.007f), Pt(0.851f, 1.237f)), 0.0005f) }
    @Test fun segDist_205() { assertEquals(1.1083126815118556f, NotePure.segDist(0.553f, 0.32f, Pt(0.436f, 1.546f), Pt(0.347f, 1.409f)), 0.0005f) }
    @Test fun segDist_206() { assertEquals(1.0195391115597283f, NotePure.segDist(-0.198f, 0.285f, Pt(0.862f, 0.182f), Pt(0.82f, 0.341f)), 0.0005f) }
    @Test fun segDist_207() { assertEquals(0.06637843075055141f, NotePure.segDist(0.488f, 1.712f, Pt(0.762f, 1.956f), Pt(0.004f, 0.982f)), 0.0005f) }
    @Test fun segDist_208() { assertEquals(0.4403691633164157f, NotePure.segDist(0.165f, 2.065f, Pt(0.185f, 0.989f), Pt(0.347f, 1.664f)), 0.0005f) }
    @Test fun segDist_209() { assertEquals(0.7968170875656592f, NotePure.segDist(-0.046f, 1.328f, Pt(0.284f, 0.429f), Pt(0.699f, 0.997f)), 0.0005f) }
    @Test fun segDist_210() { assertEquals(0.9210535869710339f, NotePure.segDist(0.679f, 0.653f, Pt(0.081f, 1.576f), Pt(0.697f, 1.574f)), 0.0005f) }
    @Test fun segDist_211() { assertEquals(0.3479367758659611f, NotePure.segDist(1.044f, -0.14f, Pt(0.401f, 0.789f), Pt(0.89f, 0.172f)), 0.0005f) }
    @Test fun segDist_212() { assertEquals(1.082266141020775f, NotePure.segDist(0.331f, 1.922f, Pt(0.206f, 0.526f), Pt(0.901f, 1.002f)), 0.0005f) }
    @Test fun segDist_213() { assertEquals(0.3586753406633915f, NotePure.segDist(0.854f, 1.351f, Pt(0.234f, 0.922f), Pt(0.532f, 1.509f)), 0.0005f) }
    @Test fun segDist_214() { assertEquals(0.5429866241219566f, NotePure.segDist(0.727f, 1.581f, Pt(0.348f, 0.653f), Pt(0.155f, 1.686f)), 0.0005f) }
    @Test fun segDist_215() { assertEquals(0.19646119209655633f, NotePure.segDist(-0.024f, 0.909f, Pt(0.17f, 0.878f), Pt(0.773f, 1.158f)), 0.0005f) }
    @Test fun segDist_216() { assertEquals(1.3086960435342194f, NotePure.segDist(0.784f, 1.825f, Pt(0.885f, 0.476f), Pt(0.192f, 0.603f)), 0.0005f) }
    @Test fun segDist_217() { assertEquals(0.39655012293529807f, NotePure.segDist(0.531f, 0.186f, Pt(0.155f, 0.312f), Pt(0.248f, 0.653f)), 0.0005f) }
    @Test fun segDist_218() { assertEquals(1.2212424001810613f, NotePure.segDist(-0.057f, 2.11f, Pt(0.328f, 0.379f), Pt(0.975f, 1.457f)), 0.0005f) }
    @Test fun segDist_219() { assertEquals(0.4386970306200202f, NotePure.segDist(0.827f, 0.844f, Pt(0.102f, 0.768f), Pt(0.984f, 1.59f)), 0.0005f) }
    @Test fun segDist_220() { assertEquals(0.5824027815867641f, NotePure.segDist(0.344f, -0.119f, Pt(0.196f, 1.276f), Pt(0.107f, 0.413f)), 0.0005f) }
    @Test fun segDist_221() { assertEquals(0.08935882720806028f, NotePure.segDist(0.685f, 0.912f, Pt(0.399f, 1.582f), Pt(0.693f, 1.001f)), 0.0005f) }
    @Test fun segDist_222() { assertEquals(0.9305734204743165f, NotePure.segDist(1.071f, 0.832f, Pt(0.142f, 1.207f), Pt(0.405f, 1.482f)), 0.0005f) }
    @Test fun segDist_223() { assertEquals(0.47703773435651814f, NotePure.segDist(0.811f, 1.912f, Pt(0.574f, 1.498f), Pt(0.421f, 0.457f)), 0.0005f) }
    @Test fun segDist_224() { assertEquals(0.4945866961413337f, NotePure.segDist(0.698f, 0.889f, Pt(0.774f, 1.4f), Pt(0.852f, 1.359f)), 0.0005f) }
    @Test fun segDist_225() { assertEquals(0.6354124644669792f, NotePure.segDist(0.895f, 1.512f, Pt(0.313f, 1.257f), Pt(0.098f, 0.839f)), 0.0005f) }
    @Test fun segDist_226() { assertEquals(0.1623478160942858f, NotePure.segDist(0.67f, 0.782f, Pt(0.63f, 0.5f), Pt(0.424f, 0.91f)), 0.0005f) }
    @Test fun segDist_227() { assertEquals(0.9102556093239216f, NotePure.segDist(0.889f, 0.733f, Pt(0.675f, 1.86f), Pt(0.183f, 1.309f)), 0.0005f) }
    @Test fun segDist_228() { assertEquals(0.2850394111912695f, NotePure.segDist(0.025f, 1.676f, Pt(0.49f, 1.949f), Pt(0.038f, 1.087f)), 0.0005f) }
    @Test fun segDist_229() { assertEquals(0.4295232617052292f, NotePure.segDist(0.557f, 1.522f, Pt(0.941f, 1.038f), Pt(0.101f, 1.149f)), 0.0005f) }
    @Test fun segDist_230() { assertEquals(0.8078737525133494f, NotePure.segDist(0.374f, 2.075f, Pt(0.512f, 1.279f), Pt(0.829f, 1.043f)), 0.0005f) }
    @Test fun segDist_231() { assertEquals(0.7643853740097333f, NotePure.segDist(-0.029f, 2.163f, Pt(0.21f, 1.369f), Pt(0.392f, 1.525f)), 0.0005f) }
    @Test fun segDist_232() { assertEquals(0.45503955871989854f, NotePure.segDist(-0.181f, 0.805f, Pt(0.355f, 0.113f), Pt(0.274f, 0.799f)), 0.0005f) }
    @Test fun segDist_233() { assertEquals(0.35740453270768685f, NotePure.segDist(0.114f, 1.58f, Pt(0.421f, 1.397f), Pt(0.352f, 0.53f)), 0.0005f) }
    @Test fun segDist_234() { assertEquals(0.9507626895433707f, NotePure.segDist(0.349f, 0.309f, Pt(0.94f, 1.054f), Pt(0.219f, 1.603f)), 0.0005f) }
    @Test fun segDist_235() { assertEquals(0.24662592621952453f, NotePure.segDist(0.457f, 1.149f, Pt(0.129f, 1.553f), Pt(0.81f, 1.269f)), 0.0005f) }
    @Test fun segDist_236() { assertEquals(0.6742310973030249f, NotePure.segDist(0.946f, 1.759f, Pt(0.226f, 1.928f), Pt(0.353f, 1.278f)), 0.0005f) }
    @Test fun segDist_237() { assertEquals(0.4999000290839639f, NotePure.segDist(0.967f, 0.651f, Pt(0.468f, 0.589f), Pt(0.548f, 0.25f)), 0.0005f) }
    @Test fun segDist_238() { assertEquals(0.26178346757317045f, NotePure.segDist(0.397f, 0.246f, Pt(0.851f, 0.535f), Pt(0.376f, 0.507f)), 0.0005f) }
    @Test fun segDist_239() { assertEquals(0.07328918552838623f, NotePure.segDist(0.223f, 0.951f, Pt(0.003f, 1.444f), Pt(0.281f, 0.49f)), 0.0005f) }
    @Test fun segDist_240() { assertEquals(0.8850762679001174f, NotePure.segDist(1.1f, 1.851f, Pt(0.428f, 1.275f), Pt(0.659f, 0.725f)), 0.0005f) }
    @Test fun segDist_241() { assertEquals(0.15139682955729292f, NotePure.segDist(-0.003f, 1.795f, Pt(0.057f, 1.656f), Pt(0.906f, 1.568f)), 0.0005f) }
    @Test fun segDist_242() { assertEquals(0.19722690237471255f, NotePure.segDist(0.718f, 0.4f, Pt(0.633f, 0.03f), Pt(0.011f, 1.904f)), 0.0005f) }
    @Test fun segDist_243() { assertEquals(0.21828879952943073f, NotePure.segDist(0.285f, 0.166f, Pt(0.102f, 0.285f), Pt(0.234f, 1.553f)), 0.0005f) }
    @Test fun segDist_244() { assertEquals(0.02303691859315027f, NotePure.segDist(0.652f, 1.675f, Pt(0.904f, 1.583f), Pt(0.168f, 1.782f)), 0.0005f) }
    @Test fun segDist_245() { assertEquals(0.6753436162428724f, NotePure.segDist(0.076f, 1.463f, Pt(0.668f, 1.788f), Pt(0.788f, 1.678f)), 0.0005f) }
    @Test fun segDist_246() { assertEquals(1.0500080952068893f, NotePure.segDist(0.577f, 0.435f, Pt(0.531f, 1.484f), Pt(0.439f, 1.765f)), 0.0005f) }
    @Test fun segDist_247() { assertEquals(0.004752997841480081f, NotePure.segDist(0.454f, 0.147f, Pt(0.234f, 0.279f), Pt(0.493f, 0.117f)), 0.0005f) }
    @Test fun segDist_248() { assertEquals(0.7367665844757078f, NotePure.segDist(-0.191f, 1.818f, Pt(0.491f, 0.996f), Pt(0.54f, 1.726f)), 0.0005f) }
    @Test fun segDist_249() { assertEquals(0.3504982168285596f, NotePure.segDist(0.325f, 0.805f, Pt(0.468f, 1.125f), Pt(0.665f, 1.681f)), 0.0005f) }
    @Test fun segDist_250() { assertEquals(0.7970508139384841f, NotePure.segDist(-0.16f, 1.263f, Pt(0.961f, 0.151f), Pt(0.637f, 1.272f)), 0.0005f) }
    @Test fun segDist_251() { assertEquals(0.9155457388901987f, NotePure.segDist(0.515f, 0.963f, Pt(0.683f, 1.863f), Pt(0.33f, 1.963f)), 0.0005f) }
    @Test fun segDist_252() { assertEquals(0.7601480119029452f, NotePure.segDist(0.274f, 1.868f, Pt(0.898f, 0.068f), Pt(0.718f, 1.251f)), 0.0005f) }
    @Test fun segDist_253() { assertEquals(0.29063034941313337f, NotePure.segDist(0.095f, 0.844f, Pt(0.366f, 0.949f), Pt(0.526f, 1.541f)), 0.0005f) }
    @Test fun segDist_254() { assertEquals(0.21646971026248568f, NotePure.segDist(0.959f, 0.769f, Pt(0.422f, 1.108f), Pt(0.827f, 0.586f)), 0.0005f) }
    @Test fun segDist_255() { assertEquals(0.21035373204681654f, NotePure.segDist(0.716f, 1.701f, Pt(0.504f, 0.543f), Pt(0.506f, 1.95f)), 0.0005f) }
    @Test fun segDist_256() { assertEquals(0.6412339666611555f, NotePure.segDist(0.689f, 1.682f, Pt(0.331f, 0.634f), Pt(0.299f, 1.173f)), 0.0005f) }
    @Test fun segDist_257() { assertEquals(0.9180070060250276f, NotePure.segDist(-0.13f, 0.521f, Pt(0.04f, 1.445f), Pt(0.886f, 1.091f)), 0.0005f) }
    @Test fun segDist_258() { assertEquals(0.5172320562378167f, NotePure.segDist(0.721f, 1.694f, Pt(0.006f, 0.38f), Pt(0.921f, 1.217f)), 0.0005f) }
    @Test fun segDist_259() { assertEquals(0.006248401246964774f, NotePure.segDist(0.775f, 1.231f, Pt(0.91f, 1.223f), Pt(0.617f, 1.254f)), 0.0005f) }
    @Test fun segDist_260() { assertEquals(0.42531517725094176f, NotePure.segDist(0.868f, 0.043f, Pt(0.681f, 0.425f), Pt(0.667f, 0.916f)), 0.0005f) }
    @Test fun segDist_261() { assertEquals(0.31264070956735107f, NotePure.segDist(0.718f, 0.685f, Pt(0.181f, 0.074f), Pt(0.775f, 1.828f)), 0.0005f) }
    @Test fun segDist_262() { assertEquals(0.4000736677240817f, NotePure.segDist(0.223f, 0.812f, Pt(0.823f, 1.573f), Pt(0.562f, 0.516f)), 0.0005f) }
    @Test fun segDist_263() { assertEquals(0.5129491349214306f, NotePure.segDist(-0.124f, 1.162f, Pt(0.318f, 0.861f), Pt(0.642f, 1.868f)), 0.0005f) }
    @Test fun segDist_264() { assertEquals(0.39087820352880714f, NotePure.segDist(1.086f, 0.872f, Pt(0.039f, 0.238f), Pt(0.81f, 1.151f)), 0.0005f) }
    @Test fun segDist_265() { assertEquals(0.9485611300439014f, NotePure.segDist(1.173f, 0.941f, Pt(0.014f, 0.774f), Pt(0.592f, 1.875f)), 0.0005f) }
    @Test fun segDist_266() { assertEquals(0.5428526503573506f, NotePure.segDist(0.012f, -0.163f, Pt(0.412f, 0.204f), Pt(0.645f, 0.425f)), 0.0005f) }
    @Test fun segDist_267() { assertEquals(0.18553797521540102f, NotePure.segDist(-0.077f, 1.887f, Pt(0.005f, 1.368f), Pt(0.122f, 1.933f)), 0.0005f) }
    @Test fun segDist_268() { assertEquals(0.252410840505168f, NotePure.segDist(0.827f, 0.25f, Pt(0.129f, 0.036f), Pt(0.719f, 0.485f)), 0.0005f) }
    @Test fun segDist_269() { assertEquals(1.685470525891744f, NotePure.segDist(0.822f, 0.002f, Pt(0.05f, 1.548f), Pt(0.714f, 1.711f)), 0.0005f) }
    @Test fun segDist_270() { assertEquals(0.39373341234901565f, NotePure.segDist(0.156f, 2.114f, Pt(0.629f, 1.418f), Pt(0.461f, 1.865f)), 0.0005f) }
    @Test fun segDist_271() { assertEquals(0.22924441105510074f, NotePure.segDist(0.944f, -0.009f, Pt(0.717f, 0.023f), Pt(0.015f, 1.301f)), 0.0005f) }
    @Test fun segDist_272() { assertEquals(1.5255018846268267f, NotePure.segDist(0.481f, -0.057f, Pt(0.311f, 1.459f), Pt(0.166f, 1.722f)), 0.0005f) }
    @Test fun segDist_273() { assertEquals(0.5654166605256693f, NotePure.segDist(0.003f, 1.714f, Pt(0.368f, 1.15f), Pt(0.439f, 1.354f)), 0.0005f) }
    @Test fun segDist_274() { assertEquals(0.39766568873866903f, NotePure.segDist(0.34f, 1.687f, Pt(0.363f, 1.29f), Pt(0.63f, 0.836f)), 0.0005f) }
    @Test fun segDist_275() { assertEquals(1.202590537132236f, NotePure.segDist(-0.115f, 2.137f, Pt(0.945f, 1.569f), Pt(0.567f, 0.585f)), 0.0005f) }
    @Test fun segDist_276() { assertEquals(0.48561816275753106f, NotePure.segDist(1.168f, 1.795f, Pt(0.703f, 1.655f), Pt(0.332f, 1.212f)), 0.0005f) }
    @Test fun segDist_277() { assertEquals(0.14963131741476626f, NotePure.segDist(0.327f, 1.444f, Pt(0.601f, 0.617f), Pt(0.429f, 1.776f)), 0.0005f) }
    @Test fun segDist_278() { assertEquals(1.0136633702605387f, NotePure.segDist(-0.198f, 0.431f, Pt(0.602f, 1.792f), Pt(0.807f, 0.567f)), 0.0005f) }
    @Test fun segDist_279() { assertEquals(0.8150211610577296f, NotePure.segDist(-0.141f, 1.8f, Pt(0.423f, 1.173f), Pt(0.816f, 1.775f)), 0.0005f) }
    @Test fun segDist_280() { assertEquals(0.1800249982641299f, NotePure.segDist(0.992f, 1.737f, Pt(0.812f, 1.734f), Pt(0.572f, 0.548f)), 0.0005f) }
    @Test fun segDist_281() { assertEquals(0.08519551847182043f, NotePure.segDist(0.575f, 1.714f, Pt(0.685f, 1.827f), Pt(0.347f, 0.17f)), 0.0005f) }
    @Test fun segDist_282() { assertEquals(0.3242309624480437f, NotePure.segDist(0.65f, 1.426f, Pt(0.2f, 1.5f), Pt(0.932f, 0.468f)), 0.0005f) }
    @Test fun segDist_283() { assertEquals(0.5277670769415085f, NotePure.segDist(0.908f, 0.903f, Pt(0.465f, 0.413f), Pt(0.255f, 1.502f)), 0.0005f) }
    @Test fun segDist_284() { assertEquals(0.6238020519363495f, NotePure.segDist(0.611f, 1.953f, Pt(0.088f, 1.613f), Pt(0.772f, 0.466f)), 0.0005f) }
    @Test fun segDist_285() { assertEquals(1.0053024420541312f, NotePure.segDist(0.065f, 0.262f, Pt(0.885f, 1.044f), Pt(0.477f, 1.179f)), 0.0005f) }
    @Test fun segDist_286() { assertEquals(0.08800000000000008f, NotePure.segDist(0.363f, 1.041f, Pt(0.181f, 1.402f), Pt(0.363f, 1.129f)), 0.0005f) }
    @Test fun segDist_287() { assertEquals(1.0939351447544796f, NotePure.segDist(-0.051f, 1.319f, Pt(0.149f, 0.089f), Pt(0.997f, 0.748f)), 0.0005f) }
    @Test fun segDist_288() { assertEquals(0.5310075329032536f, NotePure.segDist(0.527f, -0.151f, Pt(0.787f, 0.312f), Pt(0.597f, 0.69f)), 0.0005f) }
    @Test fun segDist_289() { assertEquals(0.6091050812462495f, NotePure.segDist(0.594f, 0.428f, Pt(0.034f, 1.981f), Pt(0.866f, 0.973f)), 0.0005f) }
    @Test fun segDist_290() { assertEquals(0.5780000000000001f, NotePure.segDist(0.946f, 2.112f, Pt(0.779f, 0.852f), Pt(0.946f, 1.534f)), 0.0005f) }
    @Test fun segDist_291() { assertEquals(0.3705199049983685f, NotePure.segDist(-0.083f, -0.078f, Pt(0.254f, 0.076f), Pt(0.201f, 0.361f)), 0.0005f) }
    @Test fun segDist_292() { assertEquals(1.8602843868613208f, NotePure.segDist(1.074f, -0.046f, Pt(0.557f, 1.741f), Pt(0.458f, 1.894f)), 0.0005f) }
    @Test fun segDist_293() { assertEquals(0.2621806844320593f, NotePure.segDist(0.16f, 1.155f, Pt(0.598f, 0.795f), Pt(0.12f, 1.919f)), 0.0005f) }
    @Test fun segDist_294() { assertEquals(0.6497484128491581f, NotePure.segDist(0.428f, 0.183f, Pt(0.641f, 1.913f), Pt(0.67f, 0.786f)), 0.0005f) }
    @Test fun segDist_295() { assertEquals(0.2661580396462415f, NotePure.segDist(0.158f, 0.645f, Pt(0.966f, 1.983f), Pt(0.222f, 0.077f)), 0.0005f) }
    @Test fun segDist_296() { assertEquals(0.009768862052498047f, NotePure.segDist(0.901f, 1.503f, Pt(0.903f, 1.809f), Pt(0.837f, 0.094f)), 0.0005f) }
    @Test fun segDist_297() { assertEquals(0.22617692189964916f, NotePure.segDist(0.857f, 2.055f, Pt(0.647f, 1.971f), Pt(0.056f, 0.29f)), 0.0005f) }
    @Test fun segDist_298() { assertEquals(0.7277806853044574f, NotePure.segDist(-0.052f, 0.577f, Pt(0.677f, 0.598f), Pt(0.591f, 1.516f)), 0.0005f) }
    @Test fun segDist_299() { assertEquals(0.16107451691686056f, NotePure.segDist(0.134f, 0.144f, Pt(0.257f, 0.248f), Pt(0.481f, 0.337f)), 0.0005f) }
    @Test fun erase_0() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.71f, 0.01f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_1() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.86f, 0.16f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_2() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.01f, 0.62f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_3() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.97f, 0.14f, 0.1f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_4() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.05f, 0.93f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_5() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.91f, 0.63f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_6() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.07f, 0.32f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_7() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.47f, 0.63f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_8() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.3f, 0.74f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_9() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.76f, 0.55f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_10() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.43f, 0.15f, 0.1f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_11() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.39f, 0.16f, 0.05f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_12() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.59f, 0.3f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_13() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.21f, 0.11f, 0.1f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_14() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.98f, 0.11f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_15() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.03f, 0.9f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_16() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.57f, 0.84f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_17() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.21f, 0.2f, 0.05f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_18() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.42f, 0.26f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_19() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.01f, 0.1f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_20() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.4f, 0.16f, 0.05f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_21() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.07f, 0.64f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_22() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.87f, 0.34f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_23() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.43f, 0.79f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_24() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.24f, 0.36f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_25() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.99f, 0.22f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_26() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.12f, 0.84f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_27() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.82f, 0.71f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_28() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.62f, 0.83f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_29() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.78f, 0.76f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_30() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.15f, 0.61f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_31() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.6f, 0.2f, 0.01f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_32() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.73f, 0.52f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_33() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.52f, 0.35f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_34() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.91f, 0.86f, 0.1f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_35() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.01f, 0.41f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_36() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.06f, 0.67f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_37() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.12f, 0.83f, 0.05f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_38() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.06f, 0.7f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_40() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.02f, 0.97f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_41() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.04f, 0.71f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_42() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.83f, 0.87f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_43() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.8f, 0.06f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_44() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.04f, 0.49f, 0.2f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_45() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.07f, 0.8f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_46() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.08f, 0.97f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_47() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.64f, 0.17f, 0.05f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_48() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.2f, 0.82f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_49() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.08f, 0.93f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_50() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.21f, 0.84f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_51() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.46f, 0.24f, 0.1f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_52() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.02f, 0.87f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_53() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.05f, 0.12f, 0.1f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_54() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.6f, 0.76f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_55() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.05f, 0.41f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_56() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.55f, 0.23f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_57() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.08f, 0.57f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_58() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.1f, 0.83f, 0.1f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_60() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.53f, 0.4f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_61() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.83f, 0.34f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_62() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.91f, 0.72f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_63() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.87f, 0.91f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_64() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.92f, 0.05f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_65() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.08f, 0.68f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_66() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.2f, 0.42f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_67() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.34f, 0.53f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_68() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.29f, 0.2f, 0.01f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_69() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.17f, 0.42f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_70() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.83f, 0.94f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_71() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.87f, 0.88f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_72() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.06f, 0.64f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_73() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.0f, 0.62f, 0.2f); assertEquals(listOf(0), r.map { s.indexOf(it) }) }
    @Test fun erase_74() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.87f, 0.04f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_75() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.2f, 0.52f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_76() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.18f, 0.04f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_77() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.27f, 0.65f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_78() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.03f, 0.96f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_79() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.98f, 0.08f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_80() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.54f, 0.15f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_81() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.51f, 0.89f, 0.1f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_82() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.59f, 0.27f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_83() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.79f, 0.29f, 0.1f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_84() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.63f, 0.57f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_85() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.14f, 0.71f, 0.1f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_87() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.46f, 0.31f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_88() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.3f, 0.19f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_89() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.36f, 0.59f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_90() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.01f, 0.16f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_91() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.29f, 0.33f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_92() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.24f, 0.99f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_93() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.03f, 0.02f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_94() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.02f, 0.87f, 0.1f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_95() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.69f, 0.52f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_96() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.32f, 0.76f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_97() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.17f, 0.96f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_98() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.4f, 0.67f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_99() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.71f, 0.62f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_100() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.89f, 0.52f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_101() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.22f, 0.63f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_103() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.82f, 0.59f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_104() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.38f, 0.99f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_105() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.4f, 0.78f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_106() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.63f, 0.38f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_107() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.73f, 0.29f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_108() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.25f, 0.39f, 0.2f); assertEquals(listOf(2), r.map { s.indexOf(it) }) }
    @Test fun erase_109() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.61f, 0.65f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_110() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.84f, 0.85f, 0.1f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_112() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.26f, 0.14f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_113() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.35f, 0.23f, 0.05f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_114() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.29f, 0.84f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_115() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.05f, 0.2f, 0.1f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_116() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.97f, 0.96f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_117() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.04f, 0.56f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_118() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.26f, 0.54f, 0.05f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_120() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.89f, 0.73f, 0.1f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_121() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.37f, 0.36f, 0.2f); assertEquals(listOf(2), r.map { s.indexOf(it) }) }
    @Test fun erase_122() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.71f, 0.45f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_123() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.71f, 0.53f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_124() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.39f, 0.5f, 0.2f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_125() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.01f, 0.15f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_126() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.06f, 0.49f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_127() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.82f, 0.9f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_128() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.31f, 0.53f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_129() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.1f, 0.32f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_131() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.69f, 0.29f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_132() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.88f, 0.99f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_133() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.66f, 0.52f, 0.2f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_134() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.15f, 0.89f, 0.1f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_135() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.12f, 0.63f, 0.2f); assertEquals(listOf(0), r.map { s.indexOf(it) }) }
    @Test fun erase_136() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.03f, 0.57f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_137() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.73f, 0.01f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_138() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.27f, 0.69f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_139() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.0f, 0.4f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_140() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.6f, 0.67f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_141() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.11f, 0.77f, 0.2f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_142() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.22f, 0.65f, 0.2f); assertEquals(listOf(0), r.map { s.indexOf(it) }) }
    @Test fun erase_143() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.52f, 0.14f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_144() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.39f, 0.12f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_146() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.02f, 0.17f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_147() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.49f, 0.47f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_148() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.87f, 0.06f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_149() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.72f, 0.58f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_150() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.76f, 0.35f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_151() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.06f, 0.63f, 0.2f); assertEquals(listOf(0), r.map { s.indexOf(it) }) }
    @Test fun erase_152() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.02f, 0.19f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_153() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.36f, 0.05f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_154() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.6f, 0.96f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_155() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.03f, 0.24f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_156() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.05f, 0.93f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_159() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.08f, 0.07f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_160() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.71f, 0.58f, 0.1f); assertEquals(listOf(0, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_161() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.27f, 0.88f, 0.1f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_162() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.07f, 0.87f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_163() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.11f, 0.36f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_164() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.09f, 0.88f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_165() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.57f, 0.11f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_166() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.95f, 0.34f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_167() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.05f, 0.42f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_168() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.56f, 0.39f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_169() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.24f, 0.24f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_170() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.23f, 0.03f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_171() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.19f, 0.13f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_172() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.22f, 0.84f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_173() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.57f, 0.47f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_174() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.09f, 0.35f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_175() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.35f, 0.96f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_177() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.17f, 0.45f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_178() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.03f, 1.0f, 0.2f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_179() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.98f, 0.59f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_181() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.16f, 0.87f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_182() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.71f, 0.09f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_183() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.78f, 0.76f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_184() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.69f, 0.57f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_185() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, -0.08f, 0.71f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_186() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.83f, 0.23f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_187() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.7f, 0.11f, 0.2f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_188() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.0f, 0.81f, 0.05f); assertEquals(listOf(0, 1), r.map { s.indexOf(it) }) }
    @Test fun erase_189() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.13f, 0.72f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_190() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.17f, 0.13f, 0.1f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_192() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.83f, 0.88f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_193() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 1.02f, 0.18f, 0.05f); assertEquals(listOf(1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_194() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.72f, 0.66f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_195() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.98f, 0.03f, 0.1f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_197() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.99f, 0.1f, 0.05f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_198() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.04f, 0.91f, 0.02f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun erase_199() { val s = listOf(Stroke(0,0,4f,listOf(Pt(0f,0.2f),Pt(1f,0.2f))), Stroke(0,0,4f,listOf(Pt(0f,0.5f),Pt(1f,0.5f))), Stroke(1,0,4f,listOf(Pt(0f,0.8f),Pt(1f,0.8f)))); val r = NotePure.eraseAt(s, 0.76f, 0.04f, 0.01f); assertEquals(listOf(0, 1, 2), r.map { s.indexOf(it) }) }
    @Test fun simplify_0() { assertEquals(37, NotePure.simplify(listOf(Pt(0.0f,0.002f),Pt(0.0016f,0.0038f),Pt(0.0013f,0.0031f),Pt(0.0082f,0.0018f),Pt(0.0138f,0.0057f),Pt(0.015f,0.0025f),Pt(0.0121f,0.0068f),Pt(0.0121f,0.0f),Pt(0.0274f,0.0078f),Pt(0.0135f,0.0004f),Pt(0.0349f,0.0061f),Pt(0.0073f,0.0024f),Pt(0.0107f,0.0079f),Pt(0.0161f,0.0091f),Pt(0.0437f,0.0009f),Pt(0.044f,0.0039f),Pt(0.0499f,0.0083f),Pt(0.0252f,0.0009f),Pt(0.0686f,0.0042f),Pt(0.0714f,0.0069f),Pt(0.0617f,0.0083f),Pt(0.0567f,0.0045f),Pt(0.0152f,0.007f),Pt(0.046f,0.0051f),Pt(0.09f,0.0013f),Pt(0.0792f,0.0004f),Pt(0.0769f,0.0081f),Pt(0.0382f,0.0055f),Pt(0.109f,0.0064f),Pt(0.0697f,0.0025f),Pt(0.0212f,0.0036f),Pt(0.0602f,0.002f),Pt(0.0508f,0.0014f),Pt(0.0982f,0.0067f),Pt(0.0453f,0.0024f),Pt(0.0806f,0.0045f),Pt(0.1359f,0.0035f),Pt(0.0573f,0.0088f)), 0.002f).size) }
    @Test fun simplify_1() { assertEquals(36, NotePure.simplify(listOf(Pt(0.0f,0.0033f),Pt(0.0034f,0.0055f),Pt(0.0063f,0.0017f),Pt(0.0085f,0.006f),Pt(0.0085f,0.0077f),Pt(0.017f,0.0011f),Pt(0.0091f,0.0036f),Pt(0.0086f,0.0006f),Pt(0.0119f,0.002f),Pt(0.0266f,0.0045f),Pt(0.009f,0.0032f),Pt(0.0235f,0.0036f),Pt(0.0131f,0.0007f),Pt(0.007f,0.0099f),Pt(0.0438f,0.0008f),Pt(0.0451f,0.0098f),Pt(0.0396f,0.0011f),Pt(0.0376f,0.0043f),Pt(0.021f,0.0054f),Pt(0.0101f,0.0092f),Pt(0.0551f,0.0063f),Pt(0.0792f,0.0065f),Pt(0.0304f,0.0025f),Pt(0.0227f,0.0003f),Pt(0.0771f,0.0084f),Pt(0.0384f,0.0019f),Pt(0.0711f,0.0085f),Pt(0.1011f,0.0017f),Pt(0.0909f,0.0083f),Pt(0.0898f,0.0033f),Pt(0.0344f,0.0083f),Pt(0.0502f,0.0037f),Pt(0.0777f,0.0037f),Pt(0.1125f,0.0024f),Pt(0.0219f,0.0057f),Pt(0.0945f,0.0082f),Pt(0.1069f,0.0091f)), 0.002f).size) }
    @Test fun simplify_2() { assertEquals(19, NotePure.simplify(listOf(Pt(0.0f,0.0073f),Pt(0.004f,0.006f),Pt(0.0054f,0.0014f),Pt(0.0039f,0.0014f),Pt(0.0109f,0.004f),Pt(0.0196f,0.0085f),Pt(0.0131f,0.0022f),Pt(0.0126f,0.0003f),Pt(0.0211f,0.0083f),Pt(0.0206f,0.0014f),Pt(0.0075f,0.0006f),Pt(0.0329f,0.0089f),Pt(0.0086f,0.0001f),Pt(0.05f,0.0018f),Pt(0.0425f,0.0038f),Pt(0.0077f,0.008f),Pt(0.0458f,0.0057f),Pt(0.0364f,0.0054f),Pt(0.0416f,0.0043f),Pt(0.0451f,0.0063f),Pt(0.0208f,0.004f),Pt(0.0553f,0.0008f),Pt(0.0733f,0.0072f),Pt(0.0382f,0.0066f),Pt(0.0595f,0.0042f),Pt(0.0448f,0.0066f),Pt(0.0255f,0.0087f),Pt(0.0636f,0.0063f),Pt(0.0971f,0.0022f),Pt(0.0896f,0.0069f),Pt(0.0304f,0.0058f)), 0.01f).size) }
    @Test fun simplify_4() { assertEquals(7, NotePure.simplify(listOf(Pt(0.0f,0.0043f),Pt(0.0036f,0.0062f),Pt(0.0071f,0.0056f),Pt(0.0111f,0.0087f),Pt(0.0044f,0.0075f),Pt(0.0085f,0.0076f),Pt(0.0173f,0.0083f)), 0.001f).size) }
    @Test fun simplify_5() { assertEquals(12, NotePure.simplify(listOf(Pt(0.0f,0.0074f),Pt(0.0038f,0.0072f),Pt(0.0013f,0.006f),Pt(0.0025f,0.0055f),Pt(0.0132f,0.0011f),Pt(0.0187f,0.0068f),Pt(0.0083f,0.0019f),Pt(0.0144f,0.0084f),Pt(0.0203f,0.0011f),Pt(0.0052f,0.0011f),Pt(0.033f,0.0019f),Pt(0.0268f,0.0029f),Pt(0.0349f,0.0038f),Pt(0.0131f,0.0088f),Pt(0.0334f,0.0069f)), 0.005f).size) }
    @Test fun simplify_6() { assertEquals(60, NotePure.simplify(listOf(Pt(0.0f,0.0002f),Pt(0.004f,0.0049f),Pt(0.0044f,0.0003f),Pt(0.0103f,0.0007f),Pt(0.0107f,0.0064f),Pt(0.013f,0.0084f),Pt(0.0233f,0.0069f),Pt(0.0145f,0.0023f),Pt(0.0308f,0.0052f),Pt(0.0159f,0.0053f),Pt(0.0159f,0.0013f),Pt(0.0295f,0.0021f),Pt(0.0404f,0.0073f),Pt(0.0216f,0.0047f),Pt(0.0529f,0.0031f),Pt(0.0251f,0.0048f),Pt(0.0207f,0.0025f),Pt(0.0606f,0.0061f),Pt(0.0487f,0.0073f),Pt(0.0191f,0.0038f),Pt(0.0144f,0.0099f),Pt(0.0367f,0.0057f),Pt(0.056f,0.0014f),Pt(0.0677f,0.0092f),Pt(0.0878f,0.001f),Pt(0.0299f,0.0043f),Pt(0.065f,0.001f),Pt(0.0883f,0.0079f),Pt(0.0373f,0.008f),Pt(0.0288f,0.0007f),Pt(0.1161f,0.0034f),Pt(0.0548f,0.0085f),Pt(0.0435f,0.0087f),Pt(0.0992f,0.0033f),Pt(0.1008f,0.0067f),Pt(0.1257f,0.0078f),Pt(0.0815f,0.0089f),Pt(0.1233f,0.01f),Pt(0.0391f,0.0021f),Pt(0.1408f,0.0067f),Pt(0.0767f,0.004f),Pt(0.1313f,0.0093f),Pt(0.1073f,0.0014f),Pt(0.1298f,0.0025f),Pt(0.1101f,0.0066f),Pt(0.1746f,0.0007f),Pt(0.0536f,0.0092f),Pt(0.1197f,0.003f),Pt(0.0834f,0.0047f),Pt(0.191f,0.0069f),Pt(0.1512f,0.0092f),Pt(0.1752f,0.0032f),Pt(0.0579f,0.009f),Pt(0.1279f,0.0076f),Pt(0.1454f,0.0024f),Pt(0.0314f,0.0005f),Pt(0.1158f,0.0089f),Pt(0.0849f,0.005f),Pt(0.0492f,0.0024f),Pt(0.0412f,0.0013f)), 0.001f).size) }
    @Test fun simplify_7() { assertEquals(4, NotePure.simplify(listOf(Pt(0.0f,0.0082f),Pt(0.0025f,0.0072f),Pt(0.001f,0.0027f),Pt(0.0082f,0.0002f),Pt(0.0065f,0.0003f)), 0.005f).size) }
    @Test fun simplify_8() { assertEquals(18, NotePure.simplify(listOf(Pt(0.0f,0.0003f),Pt(0.0022f,0.0061f),Pt(0.0066f,0.0017f),Pt(0.0106f,0.008f),Pt(0.0032f,0.0061f),Pt(0.0161f,0.0099f),Pt(0.0114f,0.0094f),Pt(0.0249f,0.0003f),Pt(0.0129f,0.0065f),Pt(0.0144f,0.0042f),Pt(0.0299f,0.0083f),Pt(0.0115f,0.0002f),Pt(0.0148f,0.0053f),Pt(0.0447f,0.0036f),Pt(0.0247f,0.0034f),Pt(0.0432f,0.0087f),Pt(0.0166f,0.0098f),Pt(0.0427f,0.0023f),Pt(0.048f,0.0081f),Pt(0.0413f,0.0003f)), 0.005f).size) }
    @Test fun simplify_9() { assertEquals(36, NotePure.simplify(listOf(Pt(0.0f,0.0098f),Pt(0.0021f,0.0028f),Pt(0.0047f,0.0094f),Pt(0.0029f,0.0001f),Pt(0.0087f,0.0066f),Pt(0.016f,0.0036f),Pt(0.0238f,0.0023f),Pt(0.022f,0.0009f),Pt(0.0048f,0.0013f),Pt(0.0064f,0.005f),Pt(0.0244f,0.0018f),Pt(0.0417f,0.0037f),Pt(0.0123f,0.0018f),Pt(0.0401f,0.0092f),Pt(0.0149f,0.0003f),Pt(0.0484f,0.0024f),Pt(0.063f,0.005f),Pt(0.0463f,0.0034f),Pt(0.0594f,0.0046f),Pt(0.031f,0.009f),Pt(0.0175f,0.0073f),Pt(0.0153f,0.0065f),Pt(0.0419f,0.0086f),Pt(0.0163f,0.0056f),Pt(0.0464f,0.0092f),Pt(0.0952f,0.0063f),Pt(0.0334f,0.0025f),Pt(0.0383f,0.0043f),Pt(0.0367f,0.002f),Pt(0.0916f,0.0064f),Pt(0.0463f,0.0099f),Pt(0.039f,0.0057f),Pt(0.0336f,0.0086f),Pt(0.1169f,0.0027f),Pt(0.1064f,0.0082f),Pt(0.0521f,0.0033f),Pt(0.0792f,0.0089f),Pt(0.0394f,0.0068f),Pt(0.0985f,0.0045f),Pt(0.0986f,0.0088f),Pt(0.0494f,0.0088f)), 0.005f).size) }
    @Test fun simplify_10() { assertEquals(2, NotePure.simplify(listOf(Pt(0.0f,0.0086f),Pt(0.0011f,0.0086f)), 0.005f).size) }
    @Test fun simplify_11() { assertEquals(43, NotePure.simplify(listOf(Pt(0.0f,0.0011f),Pt(0.0039f,0.0001f),Pt(0.0074f,0.0015f),Pt(0.0092f,0.001f),Pt(0.0044f,0.0068f),Pt(0.0041f,0.0034f),Pt(0.0223f,0.0072f),Pt(0.0251f,0.0098f),Pt(0.0049f,0.0023f),Pt(0.0295f,0.0069f),Pt(0.0063f,0.005f),Pt(0.0144f,0.0043f),Pt(0.0104f,0.0002f),Pt(0.0516f,0.0032f),Pt(0.0501f,0.0012f),Pt(0.0331f,0.0014f),Pt(0.032f,0.0018f),Pt(0.0493f,0.0015f),Pt(0.0555f,0.005f),Pt(0.017f,0.0035f),Pt(0.0447f,0.0092f),Pt(0.0362f,0.0022f),Pt(0.0855f,0.0088f),Pt(0.0704f,0.0027f),Pt(0.0269f,0.0026f),Pt(0.0185f,0.0004f),Pt(0.0593f,0.0041f),Pt(0.0661f,0.0036f),Pt(0.015f,0.0069f),Pt(0.0808f,0.0054f),Pt(0.0726f,0.0069f),Pt(0.1221f,0.0087f),Pt(0.0964f,0.004f),Pt(0.0533f,0.0042f),Pt(0.1328f,0.0039f),Pt(0.0647f,0.0041f),Pt(0.036f,0.01f),Pt(0.0192f,0.0061f),Pt(0.1422f,0.0025f),Pt(0.1029f,0.0038f),Pt(0.0537f,0.002f),Pt(0.0372f,0.0084f),Pt(0.1362f,0.0091f)), 0.001f).size) }
    @Test fun simplify_13() { assertEquals(6, NotePure.simplify(listOf(Pt(0.0f,0.007f),Pt(0.0018f,0.0036f),Pt(0.0056f,0.0052f),Pt(0.0047f,0.0066f),Pt(0.0059f,0.0029f),Pt(0.0103f,0.0011f),Pt(0.0163f,0.0073f)), 0.002f).size) }
    @Test fun simplify_15() { assertEquals(2, NotePure.simplify(listOf(Pt(0.0f,0.0026f),Pt(0.0035f,0.0056f),Pt(0.0046f,0.0042f),Pt(0.002f,0.003f),Pt(0.0141f,0.008f)), 0.005f).size) }
    @Test fun simplify_16() { assertEquals(18, NotePure.simplify(listOf(Pt(0.0f,0.0005f),Pt(0.0024f,0.0037f),Pt(0.0042f,0.0049f),Pt(0.0076f,0.0037f),Pt(0.0132f,0.002f),Pt(0.0186f,0.0056f),Pt(0.0041f,0.0031f),Pt(0.0166f,0.0041f),Pt(0.0198f,0.0032f),Pt(0.0131f,0.008f),Pt(0.0152f,0.0071f),Pt(0.0364f,0.0059f),Pt(0.0251f,0.0093f),Pt(0.0267f,0.0088f),Pt(0.0098f,0.0043f),Pt(0.0411f,0.0005f),Pt(0.0563f,0.0007f),Pt(0.044f,0.0018f),Pt(0.0671f,0.0056f)), 0.002f).size) }
    @Test fun simplify_17() { assertEquals(31, NotePure.simplify(listOf(Pt(0.0f,0.0072f),Pt(0.0031f,0.008f),Pt(0.0047f,0.0016f),Pt(0.0097f,0.0072f),Pt(0.0092f,0.0047f),Pt(0.006f,0.0009f),Pt(0.0041f,0.0022f),Pt(0.0239f,0.0071f),Pt(0.0164f,0.0042f),Pt(0.0318f,0.0092f),Pt(0.0097f,0.0016f),Pt(0.0227f,0.0076f),Pt(0.0427f,0.008f),Pt(0.0387f,0.0072f),Pt(0.0222f,0.0026f),Pt(0.0363f,0.0021f),Pt(0.061f,0.0067f),Pt(0.0222f,0.0097f),Pt(0.0296f,0.0016f),Pt(0.0289f,0.0065f),Pt(0.0586f,0.002f),Pt(0.0214f,0.0018f),Pt(0.0367f,0.004f),Pt(0.0146f,0.0035f),Pt(0.0672f,0.0021f),Pt(0.0699f,0.0052f),Pt(0.0196f,0.0049f),Pt(0.0152f,0.0078f),Pt(0.1012f,0.0091f),Pt(0.0349f,0.0028f),Pt(0.0468f,0.0058f)), 0.001f).size) }
    @Test fun simplify_18() { assertEquals(11, NotePure.simplify(listOf(Pt(0.0f,0.0027f),Pt(0.0036f,0.0085f),Pt(0.0026f,0.0092f),Pt(0.0018f,0.006f),Pt(0.0155f,0.0034f),Pt(0.019f,0.0066f),Pt(0.0041f,0.0033f),Pt(0.0145f,0.0025f),Pt(0.0248f,0.0018f),Pt(0.0293f,0.003f),Pt(0.0074f,0.0056f),Pt(0.0092f,0.0055f)), 0.002f).size) }
    @Test fun simplify_19() { assertEquals(37, NotePure.simplify(listOf(Pt(0.0f,0.0004f),Pt(0.0006f,0.0058f),Pt(0.0039f,0.007f),Pt(0.0059f,0.0084f),Pt(0.0031f,0.0073f),Pt(0.0153f,0.0036f),Pt(0.0169f,0.0009f),Pt(0.0036f,0.0064f),Pt(0.0274f,0.003f),Pt(0.0127f,0.0011f),Pt(0.0134f,0.0015f),Pt(0.0159f,0.0054f),Pt(0.0196f,0.0025f),Pt(0.0324f,0.0004f),Pt(0.0196f,0.0095f),Pt(0.0224f,0.0056f),Pt(0.0633f,0.0091f),Pt(0.0517f,0.0053f),Pt(0.0241f,0.0009f),Pt(0.0165f,0.0005f),Pt(0.0654f,0.007f),Pt(0.026f,0.0074f),Pt(0.0177f,0.0017f),Pt(0.0792f,0.01f),Pt(0.0476f,0.0062f),Pt(0.0221f,0.0057f),Pt(0.024f,0.0066f),Pt(0.0341f,0.0024f),Pt(0.0899f,0.0051f),Pt(0.0976f,0.0082f),Pt(0.0227f,0.0034f),Pt(0.0261f,0.0021f),Pt(0.1026f,0.0017f),Pt(0.0516f,0.0008f),Pt(0.1073f,0.0059f),Pt(0.0399f,0.0032f),Pt(0.1354f,0.0079f),Pt(0.0227f,0.0079f)), 0.002f).size) }
    @Test fun simplify_20() { assertEquals(46, NotePure.simplify(listOf(Pt(0.0f,0.0017f),Pt(0.0033f,0.0077f),Pt(0.0024f,0.0092f),Pt(0.0087f,0.0071f),Pt(0.0029f,0.0f),Pt(0.0179f,0.0004f),Pt(0.014f,0.0033f),Pt(0.0052f,0.006f),Pt(0.0058f,0.0087f),Pt(0.0061f,0.0037f),Pt(0.0194f,0.0065f),Pt(0.0429f,0.0058f),Pt(0.0397f,0.0049f),Pt(0.0416f,0.005f),Pt(0.0197f,0.0069f),Pt(0.0234f,0.0005f),Pt(0.0341f,0.0079f),Pt(0.049f,0.0016f),Pt(0.0333f,0.0064f),Pt(0.0719f,0.0051f),Pt(0.0624f,0.0059f),Pt(0.0587f,0.0063f),Pt(0.0162f,0.0078f),Pt(0.0761f,0.0075f),Pt(0.0832f,0.0024f),Pt(0.0639f,0.0056f),Pt(0.0929f,0.0058f),Pt(0.1017f,0.0089f),Pt(0.0189f,0.0066f),Pt(0.0546f,0.0063f),Pt(0.0963f,0.0034f),Pt(0.0566f,0.0095f),Pt(0.0416f,0.0067f),Pt(0.108f,0.0066f),Pt(0.1246f,0.0043f),Pt(0.0548f,0.003f),Pt(0.0941f,0.0095f),Pt(0.1322f,0.0048f),Pt(0.0736f,0.003f),Pt(0.0394f,0.0055f),Pt(0.0316f,0.0039f),Pt(0.0874f,0.0003f),Pt(0.0704f,0.0099f),Pt(0.0497f,0.0089f),Pt(0.0847f,0.0054f),Pt(0.0606f,0.0022f)), 0.001f).size) }
    @Test fun simplify_21() { assertEquals(24, NotePure.simplify(listOf(Pt(0.0f,0.0018f),Pt(0.0015f,0.0096f),Pt(0.0035f,0.0022f),Pt(0.0108f,0.0061f),Pt(0.0145f,0.0039f),Pt(0.0112f,0.0096f),Pt(0.0136f,0.0099f),Pt(0.0081f,0.0083f),Pt(0.0085f,0.0053f),Pt(0.0045f,0.0018f),Pt(0.0381f,0.0045f),Pt(0.0367f,0.0025f),Pt(0.0208f,0.001f),Pt(0.0316f,0.0086f),Pt(0.0322f,0.0038f),Pt(0.0563f,0.0089f),Pt(0.0453f,0.0008f),Pt(0.0456f,0.0044f),Pt(0.0693f,0.0036f),Pt(0.0535f,0.0063f),Pt(0.0363f,0.0052f),Pt(0.0602f,0.0091f),Pt(0.0494f,0.0036f),Pt(0.0901f,0.0006f)), 0.001f).size) }
    @Test fun simplify_22() { assertEquals(22, NotePure.simplify(listOf(Pt(0.0f,0.0031f),Pt(0.0023f,0.0015f),Pt(0.0052f,0.0046f),Pt(0.0115f,0.0048f),Pt(0.0021f,0.0094f),Pt(0.0073f,0.0019f),Pt(0.0223f,0.0051f),Pt(0.0279f,0.0017f),Pt(0.0205f,0.0098f),Pt(0.0243f,0.0024f),Pt(0.0321f,0.0003f),Pt(0.0266f,0.0041f),Pt(0.0095f,0.0095f),Pt(0.0356f,0.0049f),Pt(0.0548f,0.0036f),Pt(0.0549f,0.0032f),Pt(0.0547f,0.005f),Pt(0.0114f,0.0053f),Pt(0.0653f,0.002f),Pt(0.0632f,0.0006f),Pt(0.0316f,0.0052f),Pt(0.0606f,0.0091f),Pt(0.0562f,0.0097f),Pt(0.0741f,0.0036f),Pt(0.0703f,0.0027f),Pt(0.0905f,0.0047f),Pt(0.0695f,0.0093f),Pt(0.0516f,0.0068f),Pt(0.0495f,0.0032f),Pt(0.095f,0.0047f),Pt(0.0268f,0.0093f),Pt(0.0831f,0.005f),Pt(0.0617f,0.0016f),Pt(0.1196f,0.0004f),Pt(0.0502f,0.0054f)), 0.01f).size) }
    @Test fun simplify_23() { assertEquals(34, NotePure.simplify(listOf(Pt(0.0f,0.0039f),Pt(0.003f,0.004f),Pt(0.0067f,0.0085f),Pt(0.0028f,0.0045f),Pt(0.0022f,0.0053f),Pt(0.0147f,0.0031f),Pt(0.0156f,0.0036f),Pt(0.0275f,0.0089f),Pt(0.0285f,0.001f),Pt(0.0235f,0.0083f),Pt(0.0342f,0.0071f),Pt(0.0413f,0.0017f),Pt(0.0134f,0.0072f),Pt(0.0403f,0.0012f),Pt(0.0268f,0.0084f),Pt(0.049f,0.0084f),Pt(0.0304f,0.005f),Pt(0.0285f,0.0087f),Pt(0.0539f,0.0014f),Pt(0.0584f,0.0041f),Pt(0.0749f,0.0029f),Pt(0.0262f,0.0068f),Pt(0.0822f,0.0007f),Pt(0.0118f,0.0057f),Pt(0.0318f,0.0043f),Pt(0.0312f,0.0073f),Pt(0.0845f,0.0068f),Pt(0.0941f,0.0013f),Pt(0.0358f,0.0085f),Pt(0.0387f,0.0012f),Pt(0.0447f,0.0003f),Pt(0.1207f,0.0093f),Pt(0.0587f,0.0029f),Pt(0.0913f,0.0088f),Pt(0.0627f,0.009f),Pt(0.1047f,0.0077f),Pt(0.0942f,0.0051f),Pt(0.0972f,0.009f),Pt(0.0601f,0.0036f),Pt(0.0972f,0.0089f),Pt(0.031f,0.0002f),Pt(0.0947f,0.0012f),Pt(0.1612f,0.0022f),Pt(0.0904f,0.0076f),Pt(0.0908f,0.005f),Pt(0.1764f,0.0059f),Pt(0.1189f,0.0003f),Pt(0.112f,0.0047f)), 0.01f).size) }
    @Test fun simplify_24() { assertEquals(11, NotePure.simplify(listOf(Pt(0.0f,0.0094f),Pt(0.0039f,0.0053f),Pt(0.0026f,0.0056f),Pt(0.0101f,0.0028f),Pt(0.0156f,0.0058f),Pt(0.015f,0.0022f),Pt(0.0066f,0.0081f),Pt(0.0101f,0.0037f),Pt(0.0307f,0.0027f),Pt(0.0073f,0.0011f),Pt(0.0187f,0.0095f),Pt(0.0212f,0.0067f),Pt(0.043f,0.0005f),Pt(0.0234f,0.0053f)), 0.005f).size) }
    @Test fun simplify_25() { assertEquals(4, NotePure.simplify(listOf(Pt(0.0f,0.0058f),Pt(0.002f,0.0097f),Pt(0.0072f,0.0062f),Pt(0.0035f,0.0062f)), 0.001f).size) }
    @Test fun simplify_26() { assertEquals(18, NotePure.simplify(listOf(Pt(0.0f,0.0076f),Pt(0.0008f,0.009f),Pt(0.0011f,0.0078f),Pt(0.0098f,0.0074f),Pt(0.0128f,0.002f),Pt(0.0157f,0.0084f),Pt(0.0092f,0.0079f),Pt(0.0041f,0.0074f),Pt(0.0212f,0.0002f),Pt(0.0156f,0.0042f),Pt(0.0342f,0.0064f),Pt(0.0343f,0.0054f),Pt(0.0294f,0.0063f),Pt(0.0322f,0.0032f),Pt(0.0244f,0.0011f),Pt(0.0463f,0.0069f),Pt(0.0316f,0.0003f),Pt(0.0509f,0.0077f),Pt(0.0306f,0.0086f),Pt(0.0337f,0.0088f),Pt(0.044f,0.0008f),Pt(0.0353f,0.0032f),Pt(0.0801f,0.0098f),Pt(0.0799f,0.0053f),Pt(0.0331f,0.0039f)), 0.005f).size) }
    @Test fun simplify_27() { assertEquals(16, NotePure.simplify(listOf(Pt(0.0f,0.0094f),Pt(0.0012f,0.0028f),Pt(0.0067f,0.0052f),Pt(0.0096f,0.0073f),Pt(0.0043f,0.009f),Pt(0.0101f,0.0014f),Pt(0.0053f,0.0073f),Pt(0.0165f,0.0003f),Pt(0.0268f,0.0097f),Pt(0.0072f,0.0078f),Pt(0.0121f,0.0057f),Pt(0.0407f,0.0086f),Pt(0.0202f,0.0056f),Pt(0.0275f,0.0077f),Pt(0.0513f,0.0001f),Pt(0.0182f,0.0035f)), 0.001f).size) }
    @Test fun simplify_28() { assertEquals(2, NotePure.simplify(listOf(Pt(0.0f,0.0013f),Pt(0.0012f,0.0046f),Pt(0.0051f,0.0064f),Pt(0.0089f,0.0044f),Pt(0.0029f,0.0072f),Pt(0.0034f,0.0047f)), 0.01f).size) }
    @Test fun simplify_30() { assertEquals(49, NotePure.simplify(listOf(Pt(0.0f,0.0008f),Pt(0.0007f,0.0068f),Pt(0.0064f,0.0021f),Pt(0.0055f,0.0098f),Pt(0.0149f,0.0057f),Pt(0.0062f,0.0076f),Pt(0.0188f,0.0008f),Pt(0.004f,0.0006f),Pt(0.0244f,0.0067f),Pt(0.0088f,0.0091f),Pt(0.033f,0.0005f),Pt(0.0293f,0.0029f),Pt(0.0167f,0.0013f),Pt(0.0423f,0.0085f),Pt(0.0084f,0.0038f),Pt(0.016f,0.0016f),Pt(0.061f,0.0066f),Pt(0.0367f,0.0062f),Pt(0.0565f,0.0075f),Pt(0.0312f,0.008f),Pt(0.0109f,0.0054f),Pt(0.0355f,0.0054f),Pt(0.0385f,0.0082f),Pt(0.0116f,0.0077f),Pt(0.0321f,0.0034f),Pt(0.0194f,0.0016f),Pt(0.0162f,0.0085f),Pt(0.0537f,0.0034f),Pt(0.0203f,0.0012f),Pt(0.061f,0.0021f),Pt(0.0206f,0.0066f),Pt(0.0421f,0.0092f),Pt(0.1203f,0.0052f),Pt(0.1062f,0.0063f),Pt(0.0941f,0.0022f),Pt(0.11f,0.0089f),Pt(0.108f,0.0043f),Pt(0.0338f,0.0095f),Pt(0.1002f,0.0061f),Pt(0.0422f,0.0095f),Pt(0.0598f,0.0039f),Pt(0.0695f,0.0096f),Pt(0.0345f,0.0087f),Pt(0.118f,0.0062f),Pt(0.123f,0.0074f),Pt(0.0449f,0.0007f),Pt(0.0339f,0.0039f),Pt(0.0363f,0.0073f),Pt(0.114f,0.0007f)), 0.001f).size) }
    @Test fun simplify_31() { assertEquals(4, NotePure.simplify(listOf(Pt(0.0f,0.0072f),Pt(0.0028f,0.0051f),Pt(0.0071f,0.0092f),Pt(0.0062f,0.009f),Pt(0.0056f,0.0039f),Pt(0.0147f,0.0017f),Pt(0.0238f,0.0088f),Pt(0.0246f,0.0046f),Pt(0.013f,0.0021f)), 0.01f).size) }
    @Test fun simplify_32() { assertEquals(53, NotePure.simplify(listOf(Pt(0.0f,0.0011f),Pt(0.0012f,0.0035f),Pt(0.0033f,0.0062f),Pt(0.0104f,0.0007f),Pt(0.0033f,0.0078f),Pt(0.0141f,0.0031f),Pt(0.0085f,0.0005f),Pt(0.0153f,0.0084f),Pt(0.0056f,0.0025f),Pt(0.0073f,0.0058f),Pt(0.0072f,0.003f),Pt(0.0158f,0.0093f),Pt(0.0453f,0.0036f),Pt(0.0312f,0.0018f),Pt(0.0251f,0.0074f),Pt(0.027f,0.0017f),Pt(0.0451f,0.0087f),Pt(0.0626f,0.0017f),Pt(0.0569f,0.0093f),Pt(0.0115f,0.0065f),Pt(0.0721f,0.0076f),Pt(0.0732f,0.0024f),Pt(0.0798f,0.0026f),Pt(0.0121f,0.001f),Pt(0.0437f,0.0037f),Pt(0.0372f,0.0047f),Pt(0.0574f,0.0011f),Pt(0.066f,0.0049f),Pt(0.0537f,0.0048f),Pt(0.1082f,0.0091f),Pt(0.0597f,0.0006f),Pt(0.0362f,0.0027f),Pt(0.0657f,0.0024f),Pt(0.0556f,0.0006f),Pt(0.0776f,0.0048f),Pt(0.0439f,0.0061f),Pt(0.144f,0.0093f),Pt(0.0672f,0.0006f),Pt(0.0764f,0.0006f),Pt(0.0907f,0.0051f),Pt(0.0643f,0.001f),Pt(0.089f,0.0047f),Pt(0.1601f,0.0079f),Pt(0.0413f,0.0081f),Pt(0.1192f,0.001f),Pt(0.0667f,0.0079f),Pt(0.034f,0.007f),Pt(0.1016f,0.0026f),Pt(0.1096f,0.0063f),Pt(0.1637f,0.009f),Pt(0.1376f,0.0069f),Pt(0.0313f,0.0065f),Pt(0.1666f,0.0066f)), 0.002f).size) }
    @Test fun simplify_34() { assertEquals(17, NotePure.simplify(listOf(Pt(0.0f,0.0038f),Pt(0.0016f,0.0066f),Pt(0.0059f,0.0058f),Pt(0.0062f,0.005f),Pt(0.0094f,0.0068f),Pt(0.009f,0.0052f),Pt(0.0147f,0.0044f),Pt(0.018f,0.0025f),Pt(0.0147f,0.0086f),Pt(0.0346f,0.0064f),Pt(0.0194f,0.0096f),Pt(0.0154f,0.0082f),Pt(0.0354f,0.0006f),Pt(0.0375f,0.0021f),Pt(0.0231f,0.0092f),Pt(0.0309f,0.0034f),Pt(0.0506f,0.0096f),Pt(0.0614f,0.0047f),Pt(0.0294f,0.0097f),Pt(0.0746f,0.0009f),Pt(0.078f,0.0054f),Pt(0.04f,0.0013f),Pt(0.0685f,0.0037f),Pt(0.0685f,0.0038f),Pt(0.0535f,0.0036f),Pt(0.0998f,0.0064f)), 0.005f).size) }
    @Test fun simplify_35() { assertEquals(6, NotePure.simplify(listOf(Pt(0.0f,0.0014f),Pt(0.0019f,0.0042f),Pt(0.0015f,0.0058f),Pt(0.0114f,0.0058f),Pt(0.007f,0.007f),Pt(0.0102f,0.0018f),Pt(0.0131f,0.0002f)), 0.002f).size) }
    @Test fun simplify_36() { assertEquals(18, NotePure.simplify(listOf(Pt(0.0f,0.0096f),Pt(0.0032f,0.0084f),Pt(0.0055f,0.0063f),Pt(0.0089f,0.0097f),Pt(0.0047f,0.0077f),Pt(0.0078f,0.0026f),Pt(0.0203f,0.006f),Pt(0.0243f,0.0088f),Pt(0.0205f,0.002f),Pt(0.005f,0.0053f),Pt(0.0304f,0.0027f),Pt(0.0082f,0.0f),Pt(0.0133f,0.007f),Pt(0.0067f,0.0023f),Pt(0.02f,0.0071f),Pt(0.0593f,0.0002f),Pt(0.0144f,0.0093f),Pt(0.0662f,0.0015f),Pt(0.0301f,0.0052f),Pt(0.0308f,0.0042f),Pt(0.0435f,0.0026f),Pt(0.0145f,0.0008f),Pt(0.0235f,0.0009f),Pt(0.0617f,0.007f),Pt(0.0341f,0.0079f)), 0.005f).size) }
    @Test fun simplify_37() { assertEquals(15, NotePure.simplify(listOf(Pt(0.0f,0.0014f),Pt(0.0026f,0.0099f),Pt(0.0066f,0.0075f),Pt(0.0103f,0.0042f),Pt(0.0061f,0.0002f),Pt(0.0079f,0.0007f),Pt(0.0129f,0.0007f),Pt(0.0072f,0.0079f),Pt(0.0167f,0.0047f),Pt(0.0302f,0.0062f),Pt(0.0339f,0.0047f),Pt(0.0223f,0.0001f),Pt(0.0452f,0.0022f),Pt(0.0447f,0.0046f),Pt(0.0438f,0.005f),Pt(0.0349f,0.0033f),Pt(0.0112f,0.0023f),Pt(0.0099f,0.0051f),Pt(0.0223f,0.0072f),Pt(0.0397f,0.0019f),Pt(0.0229f,0.0099f)), 0.005f).size) }
    @Test fun simplify_38() { assertEquals(8, NotePure.simplify(listOf(Pt(0.0f,0.0023f),Pt(0.0032f,0.0083f),Pt(0.006f,0.0096f),Pt(0.0098f,0.0031f),Pt(0.0064f,0.0072f),Pt(0.0035f,0.0061f),Pt(0.0049f,0.0005f),Pt(0.0161f,0.0015f)), 0.002f).size) }
    @Test fun simplify_39() { assertEquals(28, NotePure.simplify(listOf(Pt(0.0f,0.0032f),Pt(0.0032f,0.0072f),Pt(0.0071f,0.0069f),Pt(0.0065f,0.0031f),Pt(0.003f,0.0066f),Pt(0.0134f,0.0044f),Pt(0.0044f,0.008f),Pt(0.0161f,0.0045f),Pt(0.0279f,0.0094f),Pt(0.0177f,0.0071f),Pt(0.0237f,0.0078f),Pt(0.0334f,0.0031f),Pt(0.0081f,0.0077f),Pt(0.0105f,0.0092f),Pt(0.0135f,0.0086f),Pt(0.057f,0.0056f),Pt(0.0115f,0.0068f),Pt(0.0106f,0.0066f),Pt(0.0627f,0.0066f),Pt(0.0322f,0.0052f),Pt(0.0201f,0.007f),Pt(0.0631f,0.0074f),Pt(0.0135f,0.0091f),Pt(0.0655f,0.0053f),Pt(0.0708f,0.0032f),Pt(0.0841f,0.006f),Pt(0.05f,0.0024f),Pt(0.0501f,0.0081f),Pt(0.0834f,0.0036f)), 0.002f).size) }
    @Test fun simplify_42() { assertEquals(52, NotePure.simplify(listOf(Pt(0.0f,0.008f),Pt(0.0011f,0.0091f),Pt(0.0049f,0.0076f),Pt(0.0106f,0.0036f),Pt(0.0149f,0.0021f),Pt(0.0029f,0.005f),Pt(0.0219f,0.009f),Pt(0.0269f,0.0051f),Pt(0.0301f,0.0056f),Pt(0.009f,0.0063f),Pt(0.0331f,0.0042f),Pt(0.0287f,0.0026f),Pt(0.0176f,0.0042f),Pt(0.0299f,0.0047f),Pt(0.0115f,0.0001f),Pt(0.0254f,0.0072f),Pt(0.0499f,0.0024f),Pt(0.0237f,0.0052f),Pt(0.0201f,0.006f),Pt(0.0696f,0.002f),Pt(0.051f,0.0072f),Pt(0.0656f,0.0071f),Pt(0.0657f,0.0027f),Pt(0.079f,0.0093f),Pt(0.0164f,0.0094f),Pt(0.0512f,0.0009f),Pt(0.0193f,0.008f),Pt(0.0775f,0.0014f),Pt(0.0591f,0.0064f),Pt(0.1158f,0.0034f),Pt(0.0955f,0.0025f),Pt(0.0371f,0.0016f),Pt(0.0619f,0.0062f),Pt(0.0515f,0.0016f),Pt(0.043f,0.0008f),Pt(0.0412f,0.0032f),Pt(0.0816f,0.0018f),Pt(0.0806f,0.0044f),Pt(0.1484f,0.0049f),Pt(0.1485f,0.0047f),Pt(0.0477f,0.0059f),Pt(0.0413f,0.0017f),Pt(0.0318f,0.007f),Pt(0.167f,0.004f),Pt(0.0765f,0.0043f),Pt(0.0779f,0.0069f),Pt(0.0861f,0.0015f),Pt(0.1657f,0.0057f),Pt(0.0251f,0.0085f),Pt(0.1494f,0.0035f),Pt(0.1352f,0.0092f),Pt(0.0972f,0.0043f),Pt(0.0803f,0.0055f)), 0.001f).size) }
    @Test fun simplify_46() { assertEquals(30, NotePure.simplify(listOf(Pt(0.0f,0.0096f),Pt(0.0037f,0.0016f),Pt(0.0058f,0.0055f),Pt(0.0058f,0.0017f),Pt(0.0039f,0.0047f),Pt(0.0111f,0.0027f),Pt(0.0107f,0.0055f),Pt(0.0222f,0.0059f),Pt(0.0085f,0.0089f),Pt(0.0161f,0.0096f),Pt(0.0394f,0.0014f),Pt(0.0279f,0.0097f),Pt(0.0222f,0.0055f),Pt(0.0208f,0.0003f),Pt(0.017f,0.0012f),Pt(0.0224f,0.0063f),Pt(0.0395f,0.0095f),Pt(0.0493f,0.0036f),Pt(0.0688f,0.0063f),Pt(0.0456f,0.0086f),Pt(0.0569f,0.0036f),Pt(0.055f,0.003f),Pt(0.0856f,0.0024f),Pt(0.0898f,0.0006f),Pt(0.0128f,0.0055f),Pt(0.0305f,0.0051f),Pt(0.0238f,0.0084f),Pt(0.0767f,0.0068f),Pt(0.1048f,0.0099f),Pt(0.0833f,0.0071f)), 0.001f).size) }
    @Test fun simplify_47() { assertEquals(7, NotePure.simplify(listOf(Pt(0.0f,0.0043f),Pt(0.0039f,0.0031f),Pt(0.005f,0.0001f),Pt(0.0059f,0.009f),Pt(0.0103f,0.0082f),Pt(0.0027f,0.002f),Pt(0.0068f,0.0083f),Pt(0.006f,0.0093f),Pt(0.0115f,0.0088f),Pt(0.0207f,0.0032f),Pt(0.0388f,0.0041f),Pt(0.0324f,0.0007f),Pt(0.0409f,0.0098f),Pt(0.0115f,0.0075f),Pt(0.0202f,0.0015f),Pt(0.0266f,0.0066f),Pt(0.0614f,0.0099f)), 0.01f).size) }
    @Test fun simplify_50() { assertEquals(6, NotePure.simplify(listOf(Pt(0.0f,0.0048f),Pt(0.0009f,0.0069f),Pt(0.0059f,0.0058f),Pt(0.0118f,0.0005f),Pt(0.012f,0.008f),Pt(0.0045f,0.0032f),Pt(0.0041f,0.0058f),Pt(0.0212f,0.0035f)), 0.005f).size) }
    @Test fun simplify_51() { assertEquals(15, NotePure.simplify(listOf(Pt(0.0f,0.0028f),Pt(0.0039f,0.0044f),Pt(0.001f,0.0009f),Pt(0.0091f,0.0086f),Pt(0.0109f,0.0016f),Pt(0.0178f,0.0072f),Pt(0.0054f,0.0038f),Pt(0.02f,0.0f),Pt(0.0052f,0.0035f),Pt(0.0321f,0.01f),Pt(0.0161f,0.0091f),Pt(0.0358f,0.0087f),Pt(0.0307f,0.0097f),Pt(0.0358f,0.0095f),Pt(0.0347f,0.002f),Pt(0.0347f,0.0048f),Pt(0.0269f,0.0037f),Pt(0.0389f,0.0059f),Pt(0.023f,0.0028f),Pt(0.0429f,0.005f),Pt(0.0393f,0.0066f),Pt(0.0241f,0.0053f),Pt(0.0322f,0.0077f),Pt(0.0681f,0.0078f),Pt(0.0555f,0.0025f),Pt(0.0935f,0.0051f)), 0.01f).size) }
    @Test fun simplify_53() { assertEquals(4, NotePure.simplify(listOf(Pt(0.0f,0.0033f),Pt(0.0029f,0.0062f),Pt(0.0023f,0.0002f),Pt(0.0086f,0.0061f),Pt(0.0061f,0.002f),Pt(0.0175f,0.0091f),Pt(0.0079f,0.0059f)), 0.005f).size) }
    @Test fun simplify_54() { assertEquals(3, NotePure.simplify(listOf(Pt(0.0f,0.0033f),Pt(0.0028f,0.006f),Pt(0.0046f,0.0012f),Pt(0.0037f,0.0031f),Pt(0.0078f,0.0036f),Pt(0.0183f,0.0012f),Pt(0.0237f,0.0024f)), 0.01f).size) }
    @Test fun simplify_55() { assertEquals(15, NotePure.simplify(listOf(Pt(0.0f,0.0024f),Pt(0.0027f,0.0052f),Pt(0.0049f,0.003f),Pt(0.0064f,0.0071f),Pt(0.0085f,0.0001f),Pt(0.0141f,0.0046f),Pt(0.0156f,0.0018f),Pt(0.0182f,0.0047f),Pt(0.0308f,0.0016f),Pt(0.0346f,0.0098f),Pt(0.0316f,0.0075f),Pt(0.0416f,0.0088f),Pt(0.019f,0.0087f),Pt(0.038f,0.0007f),Pt(0.0513f,0.0018f)), 0.001f).size) }
    @Test fun simplify_58() { assertEquals(31, NotePure.simplify(listOf(Pt(0.0f,0.0062f),Pt(0.0032f,0.008f),Pt(0.006f,0.004f),Pt(0.0032f,0.005f),Pt(0.0148f,0.0093f),Pt(0.0052f,0.0076f),Pt(0.0119f,0.0018f),Pt(0.0273f,0.0021f),Pt(0.0305f,0.0065f),Pt(0.0123f,0.0057f),Pt(0.0365f,0.0026f),Pt(0.0189f,0.0012f),Pt(0.0178f,0.0059f),Pt(0.0448f,0.0032f),Pt(0.0466f,0.0087f),Pt(0.0234f,0.0079f),Pt(0.0157f,0.0055f),Pt(0.042f,0.009f),Pt(0.0531f,0.0017f),Pt(0.0542f,0.001f),Pt(0.078f,0.0044f),Pt(0.0448f,0.0083f),Pt(0.0659f,0.0044f),Pt(0.0797f,0.0016f),Pt(0.0265f,0.009f),Pt(0.0403f,0.0064f),Pt(0.0525f,0.0028f),Pt(0.0229f,0.0072f),Pt(0.0964f,0.0016f),Pt(0.074f,0.0019f),Pt(0.0828f,0.0049f),Pt(0.0263f,0.0098f)), 0.002f).size) }
    @Test fun simplify_59() { assertEquals(17, NotePure.simplify(listOf(Pt(0.0f,0.0077f),Pt(0.0025f,0.0054f),Pt(0.0025f,0.0078f),Pt(0.0047f,0.0073f),Pt(0.0052f,0.0057f),Pt(0.0138f,0.0037f),Pt(0.0131f,0.0007f),Pt(0.0193f,0.0069f),Pt(0.0083f,0.0055f),Pt(0.0276f,0.001f),Pt(0.0344f,0.0087f),Pt(0.0074f,0.0025f),Pt(0.0095f,0.0025f),Pt(0.0104f,0.0049f),Pt(0.0193f,0.003f),Pt(0.0317f,0.0037f),Pt(0.0522f,0.0072f),Pt(0.0153f,0.0022f),Pt(0.0095f,0.0033f),Pt(0.0167f,0.007f),Pt(0.0646f,0.01f),Pt(0.0259f,0.0004f),Pt(0.0693f,0.0041f),Pt(0.0865f,0.0039f),Pt(0.0382f,0.0007f),Pt(0.0954f,0.0051f),Pt(0.0531f,0.0044f),Pt(0.0861f,0.0083f)), 0.01f).size) }
    @Test fun simplify_60() { assertEquals(15, NotePure.simplify(listOf(Pt(0.0f,0.0041f),Pt(0.0036f,0.0041f),Pt(0.0056f,0.0056f),Pt(0.0063f,0.0057f),Pt(0.0054f,0.0056f),Pt(0.0176f,0.0008f),Pt(0.0107f,0.0088f),Pt(0.0275f,0.0001f),Pt(0.0216f,0.0063f),Pt(0.0311f,0.0047f),Pt(0.0096f,0.003f),Pt(0.0329f,0.0073f),Pt(0.0146f,0.0064f),Pt(0.0364f,0.0066f),Pt(0.0081f,0.0044f),Pt(0.0246f,0.006f),Pt(0.0269f,0.0013f)), 0.001f).size) }
    @Test fun simplify_61() { assertEquals(13, NotePure.simplify(listOf(Pt(0.0f,0.003f),Pt(0.0033f,0.0069f),Pt(0.0021f,0.0009f),Pt(0.0082f,0.01f),Pt(0.0062f,0.0078f),Pt(0.0185f,0.007f),Pt(0.0159f,0.0064f),Pt(0.0216f,0.009f),Pt(0.0073f,0.0046f),Pt(0.0198f,0.0044f),Pt(0.0087f,0.0093f),Pt(0.0201f,0.002f),Pt(0.0262f,0.0071f),Pt(0.0237f,0.0052f),Pt(0.0343f,0.0083f),Pt(0.0383f,0.0065f),Pt(0.0227f,0.0092f),Pt(0.0176f,0.0039f)), 0.005f).size) }
    @Test fun simplify_62() { assertEquals(18, NotePure.simplify(listOf(Pt(0.0f,0.0052f),Pt(0.002f,0.0094f),Pt(0.0073f,0.0024f),Pt(0.0074f,0.0042f),Pt(0.0025f,0.0044f),Pt(0.0185f,0.003f),Pt(0.0153f,0.0071f),Pt(0.005f,0.0092f),Pt(0.0071f,0.003f),Pt(0.027f,0.0002f),Pt(0.0181f,0.0013f),Pt(0.0237f,0.0002f),Pt(0.0123f,0.0022f),Pt(0.0102f,0.0009f),Pt(0.0165f,0.0052f),Pt(0.0147f,0.0082f),Pt(0.0313f,0.0025f),Pt(0.0228f,0.0084f),Pt(0.012f,0.0074f),Pt(0.016f,0.0094f),Pt(0.0386f,0.006f),Pt(0.074f,0.001f),Pt(0.0159f,0.0069f)), 0.005f).size) }
    @Test fun simplify_64() { assertEquals(9, NotePure.simplify(listOf(Pt(0.0f,0.0022f),Pt(0.0035f,0.0033f),Pt(0.0069f,0.003f),Pt(0.0043f,0.0039f),Pt(0.0022f,0.0044f),Pt(0.0091f,0.0001f),Pt(0.0211f,0.0038f),Pt(0.0035f,0.0096f),Pt(0.0104f,0.0025f)), 0.001f).size) }
    @Test fun simplify_66() { assertEquals(21, NotePure.simplify(listOf(Pt(0.0f,0.0049f),Pt(0.0019f,0.0065f),Pt(0.0045f,0.0032f),Pt(0.0079f,0.01f),Pt(0.0048f,0.0034f),Pt(0.0027f,0.0009f),Pt(0.0042f,0.0042f),Pt(0.024f,0.007f),Pt(0.0311f,0.0084f),Pt(0.023f,0.0058f),Pt(0.0054f,0.0038f),Pt(0.0156f,0.0062f),Pt(0.0088f,0.0054f),Pt(0.0236f,0.0049f),Pt(0.0268f,0.001f),Pt(0.0459f,0.008f),Pt(0.0415f,0.0012f),Pt(0.0441f,0.0087f),Pt(0.0712f,0.0076f),Pt(0.0125f,0.0088f),Pt(0.0566f,0.0028f)), 0.001f).size) }
    @Test fun simplify_67() { assertEquals(52, NotePure.simplify(listOf(Pt(0.0f,0.009f),Pt(0.0017f,0.0047f),Pt(0.0017f,0.0063f),Pt(0.0078f,0.0005f),Pt(0.0063f,0.0023f),Pt(0.017f,0.004f),Pt(0.0216f,0.008f),Pt(0.0197f,0.0043f),Pt(0.0287f,0.0063f),Pt(0.0228f,0.0015f),Pt(0.0307f,0.003f),Pt(0.0402f,0.0005f),Pt(0.0182f,0.0067f),Pt(0.0132f,0.0071f),Pt(0.0414f,0.0077f),Pt(0.0203f,0.0091f),Pt(0.0172f,0.0026f),Pt(0.0521f,0.0084f),Pt(0.056f,0.0072f),Pt(0.0746f,0.0077f),Pt(0.053f,0.0014f),Pt(0.0697f,0.0082f),Pt(0.0188f,0.0044f),Pt(0.0828f,0.0095f),Pt(0.0249f,0.0045f),Pt(0.0864f,0.0096f),Pt(0.0393f,0.0037f),Pt(0.0634f,0.008f),Pt(0.0191f,0.0012f),Pt(0.0996f,0.0f),Pt(0.1027f,0.0068f),Pt(0.0966f,0.0033f),Pt(0.024f,0.0038f),Pt(0.124f,0.0054f),Pt(0.0218f,0.0088f),Pt(0.122f,0.0046f),Pt(0.1126f,0.0049f),Pt(0.1269f,0.0012f),Pt(0.137f,0.0015f),Pt(0.0614f,0.009f),Pt(0.0276f,0.0091f),Pt(0.0576f,0.009f),Pt(0.0477f,0.0044f),Pt(0.1f,0.0081f),Pt(0.1728f,0.0098f),Pt(0.0429f,0.0019f),Pt(0.1367f,0.0039f),Pt(0.0474f,0.0068f),Pt(0.0993f,0.0081f),Pt(0.1282f,0.0018f),Pt(0.1326f,0.0037f),Pt(0.0526f,0.0069f)), 0.001f).size) }
    @Test fun simplify_68() { assertEquals(30, NotePure.simplify(listOf(Pt(0.0f,0.002f),Pt(0.0016f,0.0001f),Pt(0.0033f,0.0074f),Pt(0.0112f,0.0068f),Pt(0.0133f,0.0054f),Pt(0.0102f,0.0009f),Pt(0.0114f,0.0018f),Pt(0.0086f,0.0093f),Pt(0.0042f,0.0091f),Pt(0.0171f,0.0013f),Pt(0.0209f,0.0005f),Pt(0.0418f,0.0063f),Pt(0.0109f,0.004f),Pt(0.0157f,0.0059f),Pt(0.0283f,0.0035f),Pt(0.0313f,0.0036f),Pt(0.0556f,0.0088f),Pt(0.0125f,0.0042f),Pt(0.0274f,0.0012f),Pt(0.0385f,0.0044f),Pt(0.0231f,0.0088f),Pt(0.069f,0.003f),Pt(0.0589f,0.0009f),Pt(0.0211f,0.0006f),Pt(0.0493f,0.0043f),Pt(0.0558f,0.004f),Pt(0.0341f,0.007f),Pt(0.0741f,0.0051f),Pt(0.0327f,0.0001f),Pt(0.1038f,0.0084f),Pt(0.1162f,0.0034f),Pt(0.0851f,0.0056f),Pt(0.097f,0.0008f),Pt(0.0618f,0.0016f),Pt(0.0658f,0.0013f),Pt(0.0573f,0.0083f),Pt(0.0543f,0.0087f),Pt(0.1188f,0.0059f),Pt(0.1004f,0.0062f),Pt(0.0432f,0.0025f),Pt(0.09f,0.0002f),Pt(0.1223f,0.008f),Pt(0.0614f,0.0054f)), 0.01f).size) }
    @Test fun simplify_69() { assertEquals(19, NotePure.simplify(listOf(Pt(0.0f,0.0087f),Pt(0.002f,0.0002f),Pt(0.008f,0.0073f),Pt(0.0088f,0.0068f),Pt(0.0033f,0.0064f),Pt(0.0199f,0.0031f),Pt(0.0073f,0.0037f),Pt(0.0197f,0.0069f),Pt(0.0167f,0.0043f),Pt(0.0168f,0.0023f),Pt(0.0158f,0.0011f),Pt(0.0343f,0.0076f),Pt(0.0453f,0.0066f),Pt(0.0325f,0.0063f),Pt(0.0188f,0.0063f),Pt(0.0341f,0.0099f),Pt(0.0265f,0.0039f),Pt(0.068f,0.0073f),Pt(0.0113f,0.005f),Pt(0.0435f,0.0066f),Pt(0.0669f,0.0006f),Pt(0.0324f,0.0008f),Pt(0.0276f,0.005f)), 0.005f).size) }
    @Test fun simplify_71() { assertEquals(5, NotePure.simplify(listOf(Pt(0.0f,0.0001f),Pt(0.0036f,0.0003f),Pt(0.0048f,0.0039f),Pt(0.0096f,0.0032f),Pt(0.0049f,0.0078f)), 0.002f).size) }
    @Test fun simplify_72() { assertEquals(25, NotePure.simplify(listOf(Pt(0.0f,0.0047f),Pt(0.0036f,0.0033f),Pt(0.0064f,0.007f),Pt(0.0046f,0.0069f),Pt(0.0039f,0.0076f),Pt(0.0165f,0.0062f),Pt(0.0208f,0.0029f),Pt(0.0155f,0.0018f),Pt(0.0294f,0.0099f),Pt(0.017f,0.0002f),Pt(0.0154f,0.0092f),Pt(0.0129f,0.0015f),Pt(0.0234f,0.0029f),Pt(0.0235f,0.0059f),Pt(0.0542f,0.003f),Pt(0.0474f,0.0041f),Pt(0.044f,0.0046f),Pt(0.0616f,0.0076f),Pt(0.0518f,0.0092f),Pt(0.0323f,0.0066f),Pt(0.078f,0.0073f),Pt(0.0268f,0.0023f),Pt(0.071f,0.008f),Pt(0.0327f,0.0034f),Pt(0.0733f,0.0065f),Pt(0.0372f,0.0051f),Pt(0.0998f,0.0014f),Pt(0.048f,0.0064f),Pt(0.0475f,0.0051f),Pt(0.0579f,0.0009f),Pt(0.1121f,0.005f)), 0.005f).size) }
    @Test fun simplify_73() { assertEquals(33, NotePure.simplify(listOf(Pt(0.0f,0.0082f),Pt(0.0006f,0.0042f),Pt(0.0054f,0.0026f),Pt(0.0034f,0.005f),Pt(0.0148f,0.0024f),Pt(0.007f,0.0069f),Pt(0.0079f,0.0025f),Pt(0.0095f,0.002f),Pt(0.0187f,0.0013f),Pt(0.0259f,0.0049f),Pt(0.0351f,0.0037f),Pt(0.0077f,0.0067f),Pt(0.0157f,0.0052f),Pt(0.0282f,0.0005f),Pt(0.0238f,0.0009f),Pt(0.0258f,0.0049f),Pt(0.0367f,0.0089f),Pt(0.0652f,0.0063f),Pt(0.0416f,0.0015f),Pt(0.0345f,0.003f),Pt(0.0508f,0.0033f),Pt(0.0163f,0.0048f),Pt(0.0715f,0.0021f),Pt(0.0738f,0.0002f),Pt(0.0533f,0.0049f),Pt(0.0299f,0.005f),Pt(0.1014f,0.0069f),Pt(0.057f,0.0097f),Pt(0.036f,0.0076f),Pt(0.0487f,0.0015f),Pt(0.035f,0.0056f),Pt(0.0852f,0.0036f),Pt(0.0248f,0.001f)), 0.001f).size) }
    @Test fun simplify_74() { assertEquals(18, NotePure.simplify(listOf(Pt(0.0f,0.0038f),Pt(0.0033f,0.0047f),Pt(0.0067f,0.003f),Pt(0.0072f,0.0003f),Pt(0.0088f,0.0008f),Pt(0.0175f,0.0068f),Pt(0.0119f,0.0097f),Pt(0.0267f,0.0096f),Pt(0.0063f,0.007f),Pt(0.0274f,0.0061f),Pt(0.0056f,0.0092f),Pt(0.0224f,0.006f),Pt(0.0402f,0.0028f),Pt(0.0078f,0.0092f),Pt(0.0203f,0.0004f),Pt(0.0147f,0.0099f),Pt(0.0494f,0.0021f),Pt(0.0172f,0.009f),Pt(0.0509f,0.0058f)), 0.002f).size) }
    @Test fun simplify_75() { assertEquals(31, NotePure.simplify(listOf(Pt(0.0f,0.0095f),Pt(0.0005f,0.0042f),Pt(0.0014f,0.01f),Pt(0.0026f,0.0095f),Pt(0.0138f,0.0073f),Pt(0.0032f,0.007f),Pt(0.0134f,0.0049f),Pt(0.0071f,0.0051f),Pt(0.0265f,0.0013f),Pt(0.0321f,0.0042f),Pt(0.0143f,0.0024f),Pt(0.0232f,0.0065f),Pt(0.0299f,0.0089f),Pt(0.0298f,0.0051f),Pt(0.0555f,0.0022f),Pt(0.0084f,0.0033f),Pt(0.0255f,0.0012f),Pt(0.0334f,0.0003f),Pt(0.067f,0.0048f),Pt(0.0679f,0.007f),Pt(0.0611f,0.0076f),Pt(0.0327f,0.0073f),Pt(0.0269f,0.0055f),Pt(0.0594f,0.0078f),Pt(0.0261f,0.0034f),Pt(0.0846f,0.008f),Pt(0.102f,0.0012f),Pt(0.0334f,0.0011f),Pt(0.0849f,0.0075f),Pt(0.0803f,0.0078f),Pt(0.0692f,0.0056f)), 0.001f).size) }
    @Test fun simplify_76() { assertEquals(30, NotePure.simplify(listOf(Pt(0.0f,0.0001f),Pt(0.0025f,0.0042f),Pt(0.0014f,0.0033f),Pt(0.0081f,0.0007f),Pt(0.0054f,0.0052f),Pt(0.0116f,0.0015f),Pt(0.0085f,0.003f),Pt(0.0184f,0.0044f),Pt(0.0131f,0.0011f),Pt(0.0201f,0.0017f),Pt(0.0092f,0.0004f),Pt(0.0273f,0.0015f),Pt(0.0082f,0.0071f),Pt(0.0461f,0.0067f),Pt(0.0516f,0.0091f),Pt(0.0198f,0.0067f),Pt(0.0331f,0.0083f),Pt(0.0606f,0.009f),Pt(0.037f,0.0012f),Pt(0.0219f,0.0081f),Pt(0.0653f,0.0037f),Pt(0.0362f,0.0082f),Pt(0.0653f,0.0079f),Pt(0.0852f,0.0097f),Pt(0.0477f,0.0022f),Pt(0.0759f,0.0045f),Pt(0.0658f,0.0079f),Pt(0.102f,0.0076f),Pt(0.0268f,0.007f),Pt(0.0153f,0.0041f),Pt(0.0679f,0.0072f),Pt(0.1239f,0.0059f),Pt(0.0652f,0.0022f),Pt(0.1197f,0.0009f),Pt(0.0898f,0.0085f),Pt(0.1067f,0.0052f),Pt(0.1398f,0.0073f),Pt(0.027f,0.0087f),Pt(0.0215f,0.0025f),Pt(0.1473f,0.0018f),Pt(0.09f,0.0084f)), 0.01f).size) }
    @Test fun simplify_77() { assertEquals(7, NotePure.simplify(listOf(Pt(0.0f,0.0021f),Pt(0.0035f,0.0054f),Pt(0.002f,0.0098f),Pt(0.0043f,0.0091f),Pt(0.0116f,0.0045f),Pt(0.0152f,0.0029f),Pt(0.0177f,0.0021f)), 0.002f).size) }
    @Test fun simplify_78() { assertEquals(30, NotePure.simplify(listOf(Pt(0.0f,0.0013f),Pt(0.0012f,0.0033f),Pt(0.0038f,0.0076f),Pt(0.0057f,0.0048f),Pt(0.0076f,0.0077f),Pt(0.0183f,0.0043f),Pt(0.0223f,0.0025f),Pt(0.0275f,0.0053f),Pt(0.0231f,0.0038f),Pt(0.0131f,0.0014f),Pt(0.036f,0.0036f),Pt(0.0324f,0.0046f),Pt(0.0281f,0.0021f),Pt(0.0146f,0.0034f),Pt(0.0404f,0.0054f),Pt(0.0076f,0.0071f),Pt(0.0323f,0.0007f),Pt(0.024f,0.0021f),Pt(0.0608f,0.0055f),Pt(0.0312f,0.0025f),Pt(0.0304f,0.0028f),Pt(0.036f,0.0079f),Pt(0.0717f,0.007f),Pt(0.0827f,0.0065f),Pt(0.0215f,0.0004f),Pt(0.0269f,0.0026f),Pt(0.0611f,0.0082f),Pt(0.0689f,0.0043f),Pt(0.0377f,0.0098f),Pt(0.091f,0.0034f),Pt(0.0198f,0.0098f),Pt(0.0433f,0.0085f),Pt(0.0291f,0.0065f),Pt(0.0577f,0.0089f),Pt(0.0524f,0.001f),Pt(0.0419f,0.0081f),Pt(0.1413f,0.0064f)), 0.005f).size) }
    @Test fun simplify_79() { assertEquals(18, NotePure.simplify(listOf(Pt(0.0f,0.0061f),Pt(0.0013f,0.0078f),Pt(0.0016f,0.0038f),Pt(0.0075f,0.0065f),Pt(0.0068f,0.0027f),Pt(0.0134f,0.0087f),Pt(0.0232f,0.0052f),Pt(0.0107f,0.0058f),Pt(0.0291f,0.0055f),Pt(0.0055f,0.0037f),Pt(0.023f,0.0014f),Pt(0.0421f,0.0042f),Pt(0.0304f,0.0017f),Pt(0.0234f,0.0009f),Pt(0.0389f,0.0084f),Pt(0.0088f,0.0006f),Pt(0.0183f,0.003f),Pt(0.0573f,0.0087f)), 0.001f).size) }
    @Test fun simplify_81() { assertEquals(2, NotePure.simplify(listOf(Pt(0.0f,0.0093f),Pt(0.0015f,0.0092f)), 0.002f).size) }
    @Test fun simplify_82() { assertEquals(26, NotePure.simplify(listOf(Pt(0.0f,0.0054f),Pt(0.001f,0.0025f),Pt(0.0058f,0.0095f),Pt(0.0061f,0.0062f),Pt(0.0136f,0.0f),Pt(0.0067f,0.0023f),Pt(0.0182f,0.0075f),Pt(0.0262f,0.0038f),Pt(0.0286f,0.0015f),Pt(0.0313f,0.0086f),Pt(0.0316f,0.0058f),Pt(0.0428f,0.0081f),Pt(0.0062f,0.0084f),Pt(0.0171f,0.0032f),Pt(0.0344f,0.0078f),Pt(0.056f,0.0003f),Pt(0.0324f,0.0013f),Pt(0.0456f,0.0013f),Pt(0.0468f,0.0066f),Pt(0.0315f,0.0065f),Pt(0.0598f,0.0097f),Pt(0.0623f,0.0055f),Pt(0.0534f,0.0001f),Pt(0.05f,0.0083f),Pt(0.0454f,0.0057f),Pt(0.0149f,0.0049f)), 0.001f).size) }
    @Test fun simplify_83() { assertEquals(30, NotePure.simplify(listOf(Pt(0.0f,0.0057f),Pt(0.0016f,0.0026f),Pt(0.0041f,0.0008f),Pt(0.011f,0.0084f),Pt(0.0098f,0.0044f),Pt(0.0079f,0.006f),Pt(0.0103f,0.0098f),Pt(0.0269f,0.0073f),Pt(0.0271f,0.0008f),Pt(0.0084f,0.0035f),Pt(0.0094f,0.0042f),Pt(0.0435f,0.0083f),Pt(0.0463f,0.0022f),Pt(0.0166f,0.0002f),Pt(0.0204f,0.0006f),Pt(0.0352f,0.003f),Pt(0.0457f,0.0056f),Pt(0.044f,0.003f),Pt(0.0553f,0.0069f),Pt(0.057f,0.0047f),Pt(0.0425f,0.0029f),Pt(0.0134f,0.0047f),Pt(0.0584f,0.0019f),Pt(0.0807f,0.0088f),Pt(0.0837f,0.0082f),Pt(0.0552f,0.0018f),Pt(0.0377f,0.0074f),Pt(0.1065f,0.0011f),Pt(0.0146f,0.0035f),Pt(0.0499f,0.006f)), 0.001f).size) }
    @Test fun simplify_84() { assertEquals(44, NotePure.simplify(listOf(Pt(0.0f,0.0034f),Pt(0.0037f,0.0033f),Pt(0.0031f,0.0018f),Pt(0.0116f,0.0059f),Pt(0.0136f,0.0006f),Pt(0.012f,0.0073f),Pt(0.0237f,0.0094f),Pt(0.006f,0.0037f),Pt(0.032f,0.0053f),Pt(0.0346f,0.0025f),Pt(0.0059f,0.0095f),Pt(0.0157f,0.0056f),Pt(0.0211f,0.0058f),Pt(0.049f,0.0095f),Pt(0.05f,0.0026f),Pt(0.0506f,0.0002f),Pt(0.0313f,0.0094f),Pt(0.0236f,0.0037f),Pt(0.0457f,0.0024f),Pt(0.0566f,0.0065f),Pt(0.0167f,0.0092f),Pt(0.0158f,0.007f),Pt(0.0378f,0.0014f),Pt(0.0178f,0.01f),Pt(0.0792f,0.0046f),Pt(0.082f,0.0097f),Pt(0.0973f,0.0053f),Pt(0.0395f,0.0052f),Pt(0.1102f,0.0073f),Pt(0.0825f,0.0084f),Pt(0.0579f,0.0056f),Pt(0.1076f,0.002f),Pt(0.1122f,0.0002f),Pt(0.0785f,0.0057f),Pt(0.0344f,0.0092f),Pt(0.0713f,0.0019f),Pt(0.0699f,0.0059f),Pt(0.0741f,0.0f),Pt(0.0313f,0.0071f),Pt(0.0375f,0.0026f),Pt(0.1331f,0.0086f),Pt(0.147f,0.0017f),Pt(0.0218f,0.0075f),Pt(0.1116f,0.0036f),Pt(0.0249f,0.0043f),Pt(0.0599f,0.0059f),Pt(0.1809f,0.0021f),Pt(0.0358f,0.0069f),Pt(0.0421f,0.0022f),Pt(0.0998f,0.0099f),Pt(0.0818f,0.0032f),Pt(0.1103f,0.0016f),Pt(0.0992f,0.007f),Pt(0.0866f,0.008f),Pt(0.0618f,0.001f),Pt(0.1482f,0.0045f),Pt(0.208f,0.0011f),Pt(0.1774f,0.0067f),Pt(0.1042f,0.0013f),Pt(0.1558f,0.0076f)), 0.01f).size) }
    @Test fun simplify_85() { assertEquals(16, NotePure.simplify(listOf(Pt(0.0f,0.0014f),Pt(0.0035f,0.005f),Pt(0.0075f,0.0029f),Pt(0.0025f,0.006f),Pt(0.0146f,0.0016f),Pt(0.009f,0.006f),Pt(0.0201f,0.0024f),Pt(0.0144f,0.0082f),Pt(0.028f,0.005f),Pt(0.0201f,0.0054f),Pt(0.0326f,0.0014f),Pt(0.0143f,0.0083f),Pt(0.0199f,0.0007f),Pt(0.0119f,0.0018f),Pt(0.0297f,0.0097f),Pt(0.0537f,0.0047f),Pt(0.0306f,0.0058f),Pt(0.0395f,0.0019f),Pt(0.071f,0.0094f),Pt(0.0179f,0.0076f),Pt(0.0341f,0.0033f),Pt(0.0259f,0.0065f),Pt(0.0258f,0.0093f),Pt(0.0277f,0.009f),Pt(0.0911f,0.0096f),Pt(0.0776f,0.0085f),Pt(0.0183f,0.0067f),Pt(0.0148f,0.0071f),Pt(0.1072f,0.0002f),Pt(0.1121f,0.0097f)), 0.01f).size) }
    @Test fun simplify_86() { assertEquals(47, NotePure.simplify(listOf(Pt(0.0f,0.0099f),Pt(0.0037f,0.0092f),Pt(0.0062f,0.007f),Pt(0.003f,0.0004f),Pt(0.0136f,0.0067f),Pt(0.0135f,0.0031f),Pt(0.0086f,0.0092f),Pt(0.0165f,0.0002f),Pt(0.0135f,0.0035f),Pt(0.0066f,0.0098f),Pt(0.0366f,0.0081f),Pt(0.0057f,0.0042f),Pt(0.0107f,0.0073f),Pt(0.0433f,0.0079f),Pt(0.0458f,0.0012f),Pt(0.0082f,0.0009f),Pt(0.0552f,0.0083f),Pt(0.0392f,0.0023f),Pt(0.063f,0.0012f),Pt(0.0311f,0.0f),Pt(0.0788f,0.0042f),Pt(0.0672f,0.008f),Pt(0.0557f,0.0099f),Pt(0.0738f,0.0093f),Pt(0.0929f,0.0008f),Pt(0.0782f,0.0023f),Pt(0.0425f,0.0034f),Pt(0.1069f,0.0006f),Pt(0.0566f,0.0013f),Pt(0.1157f,0.005f),Pt(0.0887f,0.0052f),Pt(0.0987f,0.0034f),Pt(0.0623f,0.0074f),Pt(0.0977f,0.0089f),Pt(0.0538f,0.0085f),Pt(0.1078f,0.0057f),Pt(0.0694f,0.0057f),Pt(0.0284f,0.001f),Pt(0.0604f,0.0012f),Pt(0.0262f,0.0072f),Pt(0.1224f,0.0062f),Pt(0.05f,0.0072f),Pt(0.1424f,0.0062f),Pt(0.0557f,0.0056f),Pt(0.0828f,0.0027f),Pt(0.0459f,0.0086f),Pt(0.1248f,0.0093f)), 0.002f).size) }
    @Test fun simplify_87() { assertEquals(22, NotePure.simplify(listOf(Pt(0.0f,0.0051f),Pt(0.0007f,0.003f),Pt(0.0048f,0.0048f),Pt(0.0111f,0.0058f),Pt(0.0109f,0.0059f),Pt(0.0162f,0.0037f),Pt(0.003f,0.0098f),Pt(0.0229f,0.0013f),Pt(0.0071f,0.0022f),Pt(0.0252f,0.0013f),Pt(0.0057f,0.0049f),Pt(0.0057f,0.0026f),Pt(0.0221f,0.0021f),Pt(0.0066f,0.0026f),Pt(0.0189f,0.0032f),Pt(0.0293f,0.0036f),Pt(0.0261f,0.0002f),Pt(0.0583f,0.0074f),Pt(0.0401f,0.0f),Pt(0.025f,0.009f),Pt(0.042f,0.0021f),Pt(0.0708f,0.0089f),Pt(0.0204f,0.005f),Pt(0.0567f,0.0012f),Pt(0.0388f,0.0062f),Pt(0.0714f,0.0063f),Pt(0.0694f,0.0038f),Pt(0.02f,0.0002f)), 0.005f).size) }
    @Test fun simplify_88() { assertEquals(3, NotePure.simplify(listOf(Pt(0.0f,0.0012f),Pt(0.0021f,0.0012f),Pt(0.0049f,0.0097f),Pt(0.0113f,0.0098f)), 0.005f).size) }
    @Test fun simplify_90() { assertEquals(12, NotePure.simplify(listOf(Pt(0.0f,0.0089f),Pt(0.0013f,0.0027f),Pt(0.0044f,0.0098f),Pt(0.0027f,0.0021f),Pt(0.0131f,0.0008f),Pt(0.0098f,0.0078f),Pt(0.018f,0.0079f),Pt(0.0064f,0.0089f),Pt(0.014f,0.0081f),Pt(0.0194f,0.0089f),Pt(0.0217f,0.0026f),Pt(0.0113f,0.005f)), 0.001f).size) }
    @Test fun simplify_91() { assertEquals(53, NotePure.simplify(listOf(Pt(0.0f,0.0087f),Pt(0.0025f,0.0086f),Pt(0.0021f,0.0048f),Pt(0.0064f,0.0011f),Pt(0.0057f,0.0092f),Pt(0.0152f,0.0051f),Pt(0.0158f,0.0086f),Pt(0.0269f,0.0059f),Pt(0.0054f,0.0087f),Pt(0.0097f,0.0024f),Pt(0.0098f,0.0051f),Pt(0.0279f,0.0046f),Pt(0.0257f,0.0014f),Pt(0.0392f,0.0054f),Pt(0.0221f,0.0083f),Pt(0.0568f,0.0092f),Pt(0.0632f,0.0007f),Pt(0.0316f,0.0045f),Pt(0.0252f,0.0074f),Pt(0.0697f,0.0014f),Pt(0.0454f,0.0097f),Pt(0.0758f,0.0045f),Pt(0.0191f,0.0046f),Pt(0.0532f,0.0079f),Pt(0.0276f,0.0028f),Pt(0.0987f,0.0001f),Pt(0.0686f,0.0009f),Pt(0.0844f,0.0042f),Pt(0.1047f,0.0022f),Pt(0.1036f,0.0023f),Pt(0.02f,0.0009f),Pt(0.0238f,0.0039f),Pt(0.1249f,0.0035f),Pt(0.0993f,0.0003f),Pt(0.0784f,0.0054f),Pt(0.0295f,0.0058f),Pt(0.0742f,0.0033f),Pt(0.126f,0.0069f),Pt(0.035f,0.0011f),Pt(0.0267f,0.0026f),Pt(0.1091f,0.0097f),Pt(0.1595f,0.0086f),Pt(0.0393f,0.0079f),Pt(0.1362f,0.0047f),Pt(0.1753f,0.006f),Pt(0.0411f,0.0022f),Pt(0.0439f,0.0061f),Pt(0.1262f,0.0086f),Pt(0.0257f,0.0001f),Pt(0.1913f,0.0026f),Pt(0.0712f,0.0087f),Pt(0.0454f,0.0079f),Pt(0.1892f,0.0056f)), 0.001f).size) }
    @Test fun simplify_93() { assertEquals(10, NotePure.simplify(listOf(Pt(0.0f,0.0084f),Pt(0.0025f,0.0001f),Pt(0.0021f,0.0087f),Pt(0.0042f,0.0053f),Pt(0.009f,0.0087f),Pt(0.0185f,0.0009f),Pt(0.0054f,0.0013f),Pt(0.0042f,0.0087f),Pt(0.0148f,0.0081f),Pt(0.012f,0.0033f),Pt(0.0098f,0.003f)), 0.005f).size) }
    @Test fun simplify_94() { assertEquals(12, NotePure.simplify(listOf(Pt(0.0f,0.0059f),Pt(0.0027f,0.0003f),Pt(0.0072f,0.003f),Pt(0.008f,0.0026f),Pt(0.0062f,0.0038f),Pt(0.0065f,0.0009f),Pt(0.0127f,0.0079f),Pt(0.0064f,0.0052f),Pt(0.028f,0.003f),Pt(0.0249f,0.0049f),Pt(0.022f,0.007f),Pt(0.0217f,0.0002f),Pt(0.0208f,0.0003f),Pt(0.0089f,0.0095f),Pt(0.0263f,0.0032f)), 0.002f).size) }
    @Test fun simplify_95() { assertEquals(5, NotePure.simplify(listOf(Pt(0.0f,0.0051f),Pt(0.0022f,0.0093f),Pt(0.0063f,0.0009f),Pt(0.0018f,0.007f),Pt(0.0104f,0.0065f)), 0.001f).size) }
    @Test fun simplify_96() { assertEquals(2, NotePure.simplify(listOf(Pt(0.0f,0.0052f),Pt(0.0006f,0.0015f)), 0.005f).size) }
    @Test fun simplify_97() { assertEquals(4, NotePure.simplify(listOf(Pt(0.0f,0.0009f),Pt(0.0032f,0.0019f),Pt(0.0069f,0.01f),Pt(0.0111f,0.0096f),Pt(0.0156f,0.0027f),Pt(0.0193f,0.0041f),Pt(0.0172f,0.0018f)), 0.005f).size) }
    @Test fun simplify_98() { assertEquals(0, NotePure.simplify(emptyList<Pt>(), 0.001f).size) }
    @Test fun simplify_99() { assertEquals(4, NotePure.simplify(listOf(Pt(0.0f,0.0085f),Pt(0.0032f,0.0044f),Pt(0.0076f,0.0061f),Pt(0.0049f,0.0075f)), 0.002f).size) }
    @Test fun toggle_0() { assertEquals("[x] süt\n\ndüz satır\n[x] ekmek", NotePure.toggleCheck("[ ] süt\n\ndüz satır\n[x] ekmek", 0)) }
    @Test fun counts_0() { assertEquals(1 to 2, NotePure.checkCounts("[ ] süt\n\ndüz satır\n[x] ekmek")) }
    @Test fun toggle_1() { assertEquals("[ ] \n[x]\n[X] büyük\n[x] ekmek\n[x]\ndüz satır\ndüz satır", NotePure.toggleCheck("[ ] \n[x]\n[X] büyük\n[x] ekmek\n[x]\ndüz satır\ndüz satır", 6)) }
    @Test fun counts_1() { assertEquals(1 to 2, NotePure.checkCounts("[ ] \n[x]\n[X] büyük\n[x] ekmek\n[x]\ndüz satır\ndüz satır")) }
    @Test fun toggle_2() { assertEquals("[x]\n[ ]x\n[ ]x\n\n[X] büyük", NotePure.toggleCheck("[x]\n[ ]x\n[ ]x\n\n[X] büyük", 8)) }
    @Test fun counts_2() { assertEquals(0 to 0, NotePure.checkCounts("[x]\n[ ]x\n[ ]x\n\n[X] büyük")) }
    @Test fun toggle_3() { assertEquals("[ ] \n[ ]x\n", NotePure.toggleCheck("[ ] \n[ ]x\n", 1)) }
    @Test fun counts_3() { assertEquals(0 to 1, NotePure.checkCounts("[ ] \n[ ]x\n")) }
    @Test fun toggle_4() { assertEquals("[ ]x\n[X] büyük", NotePure.toggleCheck("[ ]x\n[X] büyük", 4)) }
    @Test fun counts_4() { assertEquals(0 to 0, NotePure.checkCounts("[ ]x\n[X] büyük")) }
    @Test fun toggle_5() { assertEquals("[ ] \n[x] ekmek\n[ ]x\n[X] büyük\n[ ] süt\n[ ]x", NotePure.toggleCheck("[ ] \n[x] ekmek\n[ ]x\n[X] büyük\n[ ] süt\n[ ]x", 3)) }
    @Test fun counts_5() { assertEquals(1 to 3, NotePure.checkCounts("[ ] \n[x] ekmek\n[ ]x\n[X] büyük\n[ ] süt\n[ ]x")) }
    @Test fun toggle_6() { assertEquals("[ ] ekmek", NotePure.toggleCheck("[x] ekmek", 0)) }
    @Test fun counts_6() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek")) }
    @Test fun toggle_7() { assertEquals("düz satır\n[x]\n[ ] süt\n[ ] ", NotePure.toggleCheck("düz satır\n[x]\n[ ] süt\n[ ] ", 6)) }
    @Test fun counts_7() { assertEquals(0 to 2, NotePure.checkCounts("düz satır\n[x]\n[ ] süt\n[ ] ")) }
    @Test fun toggle_8() { assertEquals("\ndüz satır\n[x] ekmek\n[X] büyük\ndüz satır\n[ ]x\n[ ]x", NotePure.toggleCheck("\ndüz satır\n[x] ekmek\n[X] büyük\ndüz satır\n[ ]x\n[ ]x", 0)) }
    @Test fun counts_8() { assertEquals(1 to 1, NotePure.checkCounts("\ndüz satır\n[x] ekmek\n[X] büyük\ndüz satır\n[ ]x\n[ ]x")) }
    @Test fun toggle_9() { assertEquals("[X] büyük\n[X] büyük\ndüz satır\n[ ] \n[x] süt", NotePure.toggleCheck("[X] büyük\n[X] büyük\ndüz satır\n[ ] \n[ ] süt", 4)) }
    @Test fun counts_9() { assertEquals(0 to 2, NotePure.checkCounts("[X] büyük\n[X] büyük\ndüz satır\n[ ] \n[ ] süt")) }
    @Test fun toggle_10() { assertEquals("[ ] süt\n[ ]x\n[x] ekmek\n[x]", NotePure.toggleCheck("[ ] süt\n[ ]x\n[x] ekmek\n[x]", 1)) }
    @Test fun counts_10() { assertEquals(1 to 2, NotePure.checkCounts("[ ] süt\n[ ]x\n[x] ekmek\n[x]")) }
    @Test fun toggle_11() { assertEquals("\n[ ]x\n[X] büyük\n[x] ekmek", NotePure.toggleCheck("\n[ ]x\n[X] büyük\n[x] ekmek", 1)) }
    @Test fun counts_11() { assertEquals(1 to 1, NotePure.checkCounts("\n[ ]x\n[X] büyük\n[x] ekmek")) }
    @Test fun toggle_12() { assertEquals("[ ]x\n[ ]x\n\n[ ]x\n[ ] süt", NotePure.toggleCheck("[ ]x\n[ ]x\n\n[ ]x\n[ ] süt", 5)) }
    @Test fun counts_12() { assertEquals(0 to 1, NotePure.checkCounts("[ ]x\n[ ]x\n\n[ ]x\n[ ] süt")) }
    @Test fun toggle_13() { assertEquals("[x]\n[x] ekmek\n[ ]x", NotePure.toggleCheck("[x]\n[x] ekmek\n[ ]x", 6)) }
    @Test fun counts_13() { assertEquals(1 to 1, NotePure.checkCounts("[x]\n[x] ekmek\n[ ]x")) }
    @Test fun toggle_14() { assertEquals("[X] büyük\n[x] ekmek\n[ ] süt\n[x]", NotePure.toggleCheck("[X] büyük\n[x] ekmek\n[ ] süt\n[x]", 0)) }
    @Test fun counts_14() { assertEquals(1 to 2, NotePure.checkCounts("[X] büyük\n[x] ekmek\n[ ] süt\n[x]")) }
    @Test fun toggle_15() { assertEquals("düz satır\n[ ] süt\n[X] büyük\n[ ]x\n\n[ ] süt", NotePure.toggleCheck("düz satır\n[ ] süt\n[X] büyük\n[ ]x\n\n[ ] süt", 4)) }
    @Test fun counts_15() { assertEquals(0 to 2, NotePure.checkCounts("düz satır\n[ ] süt\n[X] büyük\n[ ]x\n\n[ ] süt")) }
    @Test fun toggle_16() { assertEquals("[x]", NotePure.toggleCheck("[x]", 3)) }
    @Test fun counts_16() { assertEquals(0 to 0, NotePure.checkCounts("[x]")) }
    @Test fun toggle_17() { assertEquals("\n[x] ekmek\n[x] ekmek\n[x]\n[ ]x", NotePure.toggleCheck("\n[x] ekmek\n[x] ekmek\n[x]\n[ ]x", 0)) }
    @Test fun counts_17() { assertEquals(2 to 2, NotePure.checkCounts("\n[x] ekmek\n[x] ekmek\n[x]\n[ ]x")) }
    @Test fun toggle_18() { assertEquals("[x] ekmek\n[X] büyük\n\n[x]\n[ ]x", NotePure.toggleCheck("[x] ekmek\n[X] büyük\n\n[x]\n[ ]x", -1)) }
    @Test fun counts_18() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek\n[X] büyük\n\n[x]\n[ ]x")) }
    @Test fun toggle_19() { assertEquals("\n[x] ekmek\n\n[ ] \n[ ] \n[ ]x", NotePure.toggleCheck("\n[x] ekmek\n\n[ ] \n[ ] \n[ ]x", 8)) }
    @Test fun counts_19() { assertEquals(1 to 3, NotePure.checkCounts("\n[x] ekmek\n\n[ ] \n[ ] \n[ ]x")) }
    @Test fun toggle_20() { assertEquals("[x]\n[x]\n", NotePure.toggleCheck("[x]\n[x]\n", -1)) }
    @Test fun counts_20() { assertEquals(0 to 0, NotePure.checkCounts("[x]\n[x]\n")) }
    @Test fun toggle_21() { assertEquals("[x] ekmek\n[X] büyük\n[ ] ekmek\n\n[x]\n[X] büyük\n[ ] süt", NotePure.toggleCheck("[x] ekmek\n[X] büyük\n[x] ekmek\n\n[x]\n[X] büyük\n[ ] süt", 2)) }
    @Test fun counts_21() { assertEquals(2 to 3, NotePure.checkCounts("[x] ekmek\n[X] büyük\n[x] ekmek\n\n[x]\n[X] büyük\n[ ] süt")) }
    @Test fun toggle_22() { assertEquals("\n[ ] süt\n[x]\ndüz satır\ndüz satır", NotePure.toggleCheck("\n[ ] süt\n[x]\ndüz satır\ndüz satır", 4)) }
    @Test fun counts_22() { assertEquals(0 to 1, NotePure.checkCounts("\n[ ] süt\n[x]\ndüz satır\ndüz satır")) }
    @Test fun toggle_23() { assertEquals("düz satır\n[x]\n\n[X] büyük\ndüz satır\n[x]\n[x] ekmek", NotePure.toggleCheck("düz satır\n[x]\n\n[X] büyük\ndüz satır\n[x]\n[x] ekmek", 4)) }
    @Test fun counts_23() { assertEquals(1 to 1, NotePure.checkCounts("düz satır\n[x]\n\n[X] büyük\ndüz satır\n[x]\n[x] ekmek")) }
    @Test fun toggle_24() { assertEquals("\n[ ]x\n[X] büyük\n[ ] süt", NotePure.toggleCheck("\n[ ]x\n[X] büyük\n[ ] süt", -1)) }
    @Test fun counts_24() { assertEquals(0 to 1, NotePure.checkCounts("\n[ ]x\n[X] büyük\n[ ] süt")) }
    @Test fun toggle_25() { assertEquals("[X] büyük", NotePure.toggleCheck("[X] büyük", 4)) }
    @Test fun counts_25() { assertEquals(0 to 0, NotePure.checkCounts("[X] büyük")) }
    @Test fun toggle_26() { assertEquals("[x] ekmek\ndüz satır\n[x]\n[ ] \n[x]\n[x] ekmek", NotePure.toggleCheck("[x] ekmek\ndüz satır\n[x]\n[ ] \n[x]\n[x] ekmek", 7)) }
    @Test fun counts_26() { assertEquals(2 to 3, NotePure.checkCounts("[x] ekmek\ndüz satır\n[x]\n[ ] \n[x]\n[x] ekmek")) }
    @Test fun toggle_27() { assertEquals("[X] büyük\n[X] büyük", NotePure.toggleCheck("[X] büyük\n[X] büyük", 7)) }
    @Test fun counts_27() { assertEquals(0 to 0, NotePure.checkCounts("[X] büyük\n[X] büyük")) }
    @Test fun toggle_28() { assertEquals("[X] büyük\ndüz satır\n", NotePure.toggleCheck("[X] büyük\ndüz satır\n", 1)) }
    @Test fun counts_28() { assertEquals(0 to 0, NotePure.checkCounts("[X] büyük\ndüz satır\n")) }
    @Test fun toggle_29() { assertEquals("[x] ekmek\n[ ] \n[ ] \n[ ] süt\n[ ] süt", NotePure.toggleCheck("[x] ekmek\n[ ] \n[ ] \n[ ] süt\n[ ] süt", 5)) }
    @Test fun counts_29() { assertEquals(1 to 5, NotePure.checkCounts("[x] ekmek\n[ ] \n[ ] \n[ ] süt\n[ ] süt")) }
    @Test fun toggle_30() { assertEquals("[ ] süt\ndüz satır", NotePure.toggleCheck("[ ] süt\ndüz satır", 3)) }
    @Test fun counts_30() { assertEquals(0 to 1, NotePure.checkCounts("[ ] süt\ndüz satır")) }
    @Test fun toggle_31() { assertEquals("[ ] \n[x] ekmek\n[X] büyük\n[ ] \n[x] ", NotePure.toggleCheck("[ ] \n[x] ekmek\n[X] büyük\n[ ] \n[ ] ", 4)) }
    @Test fun counts_31() { assertEquals(1 to 4, NotePure.checkCounts("[ ] \n[x] ekmek\n[X] büyük\n[ ] \n[ ] ")) }
    @Test fun toggle_32() { assertEquals("[ ]x\n[ ] süt\n\ndüz satır", NotePure.toggleCheck("[ ]x\n[ ] süt\n\ndüz satır", 7)) }
    @Test fun counts_32() { assertEquals(0 to 1, NotePure.checkCounts("[ ]x\n[ ] süt\n\ndüz satır")) }
    @Test fun toggle_33() { assertEquals("\n[x]\n[ ] süt", NotePure.toggleCheck("\n[x]\n[ ] süt", 4)) }
    @Test fun counts_33() { assertEquals(0 to 1, NotePure.checkCounts("\n[x]\n[ ] süt")) }
    @Test fun toggle_34() { assertEquals("[x]\ndüz satır\n[ ]x\n[ ] \n\n[x]", NotePure.toggleCheck("[x]\ndüz satır\n[ ]x\n[ ] \n\n[x]", 7)) }
    @Test fun counts_34() { assertEquals(0 to 1, NotePure.checkCounts("[x]\ndüz satır\n[ ]x\n[ ] \n\n[x]")) }
    @Test fun toggle_35() { assertEquals("[x] ekmek\n[ ]x\n[X] büyük\n[x] \n[x]", NotePure.toggleCheck("[x] ekmek\n[ ]x\n[X] büyük\n[ ] \n[x]", 3)) }
    @Test fun counts_35() { assertEquals(1 to 2, NotePure.checkCounts("[x] ekmek\n[ ]x\n[X] büyük\n[ ] \n[x]")) }
    @Test fun toggle_36() { assertEquals("[X] büyük\n[x]", NotePure.toggleCheck("[X] büyük\n[x]", 8)) }
    @Test fun counts_36() { assertEquals(0 to 0, NotePure.checkCounts("[X] büyük\n[x]")) }
    @Test fun toggle_37() { assertEquals("[ ] \n[x] \n[x] ekmek\n[ ]x\n[x] ekmek\n[X] büyük", NotePure.toggleCheck("[ ] \n[ ] \n[x] ekmek\n[ ]x\n[x] ekmek\n[X] büyük", 1)) }
    @Test fun counts_37() { assertEquals(2 to 4, NotePure.checkCounts("[ ] \n[ ] \n[x] ekmek\n[ ]x\n[x] ekmek\n[X] büyük")) }
    @Test fun toggle_38() { assertEquals("düz satır\ndüz satır\n[x]", NotePure.toggleCheck("düz satır\ndüz satır\n[x]", 2)) }
    @Test fun counts_38() { assertEquals(0 to 0, NotePure.checkCounts("düz satır\ndüz satır\n[x]")) }
    @Test fun toggle_39() { assertEquals("\n\ndüz satır\n[X] büyük\ndüz satır\n[ ]x\n[x] ekmek", NotePure.toggleCheck("\n\ndüz satır\n[X] büyük\ndüz satır\n[ ]x\n[x] ekmek", 0)) }
    @Test fun counts_39() { assertEquals(1 to 1, NotePure.checkCounts("\n\ndüz satır\n[X] büyük\ndüz satır\n[ ]x\n[x] ekmek")) }
    @Test fun toggle_40() { assertEquals("[X] büyük\n[ ] \n[X] büyük\n[x] ekmek\n[x]\n[X] büyük", NotePure.toggleCheck("[X] büyük\n[ ] \n[X] büyük\n[x] ekmek\n[x]\n[X] büyük", 4)) }
    @Test fun counts_40() { assertEquals(1 to 2, NotePure.checkCounts("[X] büyük\n[ ] \n[X] büyük\n[x] ekmek\n[x]\n[X] büyük")) }
    @Test fun toggle_41() { assertEquals("[ ] ekmek", NotePure.toggleCheck("[x] ekmek", 0)) }
    @Test fun counts_41() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek")) }
    @Test fun toggle_42() { assertEquals("[x] ekmek\n[x]\n[ ]x\n[x]", NotePure.toggleCheck("[x] ekmek\n[x]\n[ ]x\n[x]", 7)) }
    @Test fun counts_42() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek\n[x]\n[ ]x\n[x]")) }
    @Test fun toggle_43() { assertEquals("[x] süt\n\ndüz satır", NotePure.toggleCheck("[ ] süt\n\ndüz satır", 0)) }
    @Test fun counts_43() { assertEquals(0 to 1, NotePure.checkCounts("[ ] süt\n\ndüz satır")) }
    @Test fun toggle_44() { assertEquals("\n[x]\n[X] büyük\ndüz satır\n[ ] \n[ ] süt", NotePure.toggleCheck("\n[x]\n[X] büyük\ndüz satır\n[ ] \n[ ] süt", 1)) }
    @Test fun counts_44() { assertEquals(0 to 2, NotePure.checkCounts("\n[x]\n[X] büyük\ndüz satır\n[ ] \n[ ] süt")) }
    @Test fun toggle_45() { assertEquals("[x]\n[ ]x", NotePure.toggleCheck("[x]\n[ ]x", 8)) }
    @Test fun counts_45() { assertEquals(0 to 0, NotePure.checkCounts("[x]\n[ ]x")) }
    @Test fun toggle_46() { assertEquals("[x]\n[ ] \ndüz satır", NotePure.toggleCheck("[x]\n[ ] \ndüz satır", 5)) }
    @Test fun counts_46() { assertEquals(0 to 1, NotePure.checkCounts("[x]\n[ ] \ndüz satır")) }
    @Test fun toggle_47() { assertEquals("düz satır\n[X] büyük\n[ ]x\n\n[x] ekmek", NotePure.toggleCheck("düz satır\n[X] büyük\n[ ]x\n\n[x] ekmek", 3)) }
    @Test fun counts_47() { assertEquals(1 to 1, NotePure.checkCounts("düz satır\n[X] büyük\n[ ]x\n\n[x] ekmek")) }
    @Test fun toggle_48() { assertEquals("[ ] \n[ ]x\n[ ]x\n[ ] süt\n[x] ekmek\n\ndüz satır", NotePure.toggleCheck("[ ] \n[ ]x\n[ ]x\n[ ] süt\n[x] ekmek\n\ndüz satır", 7)) }
    @Test fun counts_48() { assertEquals(1 to 3, NotePure.checkCounts("[ ] \n[ ]x\n[ ]x\n[ ] süt\n[x] ekmek\n\ndüz satır")) }
    @Test fun toggle_49() { assertEquals("[x]\n[x] süt\n[x] ekmek\ndüz satır\n[X] büyük\n\n[ ] ", NotePure.toggleCheck("[x]\n[ ] süt\n[x] ekmek\ndüz satır\n[X] büyük\n\n[ ] ", 1)) }
    @Test fun counts_49() { assertEquals(1 to 3, NotePure.checkCounts("[x]\n[ ] süt\n[x] ekmek\ndüz satır\n[X] büyük\n\n[ ] ")) }
    @Test fun toggle_50() { assertEquals("[ ]x\n\n[ ] süt\n\n", NotePure.toggleCheck("[ ]x\n\n[ ] süt\n\n", 1)) }
    @Test fun counts_50() { assertEquals(0 to 1, NotePure.checkCounts("[ ]x\n\n[ ] süt\n\n")) }
    @Test fun toggle_51() { assertEquals("[x] ekmek", NotePure.toggleCheck("[x] ekmek", 7)) }
    @Test fun counts_51() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek")) }
    @Test fun toggle_52() { assertEquals("[x]\n[x] ekmek\n[X] büyük\n[x]", NotePure.toggleCheck("[x]\n[x] ekmek\n[X] büyük\n[x]", 5)) }
    @Test fun counts_52() { assertEquals(1 to 1, NotePure.checkCounts("[x]\n[x] ekmek\n[X] büyük\n[x]")) }
    @Test fun toggle_53() { assertEquals("[ ] süt\n[ ] \n[ ] süt\n[x] \n[x]\n[ ] süt", NotePure.toggleCheck("[ ] süt\n[ ] \n[ ] süt\n[ ] \n[x]\n[ ] süt", 3)) }
    @Test fun counts_53() { assertEquals(0 to 5, NotePure.checkCounts("[ ] süt\n[ ] \n[ ] süt\n[ ] \n[x]\n[ ] süt")) }
    @Test fun toggle_54() { assertEquals("[ ] \n[ ] süt", NotePure.toggleCheck("[ ] \n[ ] süt", 7)) }
    @Test fun counts_54() { assertEquals(0 to 2, NotePure.checkCounts("[ ] \n[ ] süt")) }
    @Test fun toggle_55() { assertEquals("\n[ ] süt\ndüz satır\ndüz satır\n[ ] süt\n[ ] ", NotePure.toggleCheck("\n[ ] süt\ndüz satır\ndüz satır\n[ ] süt\n[ ] ", -1)) }
    @Test fun counts_55() { assertEquals(0 to 3, NotePure.checkCounts("\n[ ] süt\ndüz satır\ndüz satır\n[ ] süt\n[ ] ")) }
    @Test fun toggle_56() { assertEquals("düz satır\n\n[x] ekmek\n[ ] \ndüz satır\n[ ] süt\n[x] ", NotePure.toggleCheck("düz satır\n\n[x] ekmek\n[ ] \ndüz satır\n[ ] süt\n[ ] ", 6)) }
    @Test fun counts_56() { assertEquals(1 to 4, NotePure.checkCounts("düz satır\n\n[x] ekmek\n[ ] \ndüz satır\n[ ] süt\n[ ] ")) }
    @Test fun toggle_57() { assertEquals("[x] süt\n\n[X] büyük\n[x] ekmek\n\n[x] ekmek\n[ ] ", NotePure.toggleCheck("[ ] süt\n\n[X] büyük\n[x] ekmek\n\n[x] ekmek\n[ ] ", 0)) }
    @Test fun counts_57() { assertEquals(2 to 4, NotePure.checkCounts("[ ] süt\n\n[X] büyük\n[x] ekmek\n\n[x] ekmek\n[ ] ")) }
    @Test fun toggle_58() { assertEquals("[X] büyük\n\n[ ] süt\n[X] büyük\ndüz satır", NotePure.toggleCheck("[X] büyük\n\n[ ] süt\n[X] büyük\ndüz satır", 5)) }
    @Test fun counts_58() { assertEquals(0 to 1, NotePure.checkCounts("[X] büyük\n\n[ ] süt\n[X] büyük\ndüz satır")) }
    @Test fun toggle_59() { assertEquals("[X] büyük\n[x] ekmek\n[ ] \n[ ]x\n[X] büyük\n[x] süt", NotePure.toggleCheck("[X] büyük\n[x] ekmek\n[ ] \n[ ]x\n[X] büyük\n[ ] süt", 5)) }
    @Test fun counts_59() { assertEquals(1 to 3, NotePure.checkCounts("[X] büyük\n[x] ekmek\n[ ] \n[ ]x\n[X] büyük\n[ ] süt")) }
    @Test fun toggle_60() { assertEquals("\n[ ]x\n[X] büyük", NotePure.toggleCheck("\n[ ]x\n[X] büyük", -1)) }
    @Test fun counts_60() { assertEquals(0 to 0, NotePure.checkCounts("\n[ ]x\n[X] büyük")) }
    @Test fun toggle_61() { assertEquals("düz satır", NotePure.toggleCheck("düz satır", 4)) }
    @Test fun counts_61() { assertEquals(0 to 0, NotePure.checkCounts("düz satır")) }
    @Test fun toggle_62() { assertEquals("[ ] süt\n[X] büyük\n[X] büyük\n[ ] \n[ ]x", NotePure.toggleCheck("[ ] süt\n[X] büyük\n[X] büyük\n[ ] \n[ ]x", 5)) }
    @Test fun counts_62() { assertEquals(0 to 2, NotePure.checkCounts("[ ] süt\n[X] büyük\n[X] büyük\n[ ] \n[ ]x")) }
    @Test fun toggle_63() { assertEquals("\n[ ] süt\n[ ] süt\n\n[X] büyük\n[x] ekmek", NotePure.toggleCheck("\n[ ] süt\n[ ] süt\n\n[X] büyük\n[x] ekmek", 7)) }
    @Test fun counts_63() { assertEquals(1 to 3, NotePure.checkCounts("\n[ ] süt\n[ ] süt\n\n[X] büyük\n[x] ekmek")) }
    @Test fun toggle_64() { assertEquals("düz satır\n[x] ekmek\n[ ] süt\n\n[x] ekmek\ndüz satır\n[x]", NotePure.toggleCheck("düz satır\n[x] ekmek\n[ ] süt\n\n[x] ekmek\ndüz satır\n[x]", 5)) }
    @Test fun counts_64() { assertEquals(2 to 3, NotePure.checkCounts("düz satır\n[x] ekmek\n[ ] süt\n\n[x] ekmek\ndüz satır\n[x]")) }
    @Test fun toggle_65() { assertEquals("[ ] süt\n[x]\n[x] ekmek\n[ ] \n[X] büyük\ndüz satır\n[ ] ", NotePure.toggleCheck("[ ] süt\n[x]\n[x] ekmek\n[ ] \n[X] büyük\ndüz satır\n[ ] ", 1)) }
    @Test fun counts_65() { assertEquals(1 to 4, NotePure.checkCounts("[ ] süt\n[x]\n[x] ekmek\n[ ] \n[X] büyük\ndüz satır\n[ ] ")) }
    @Test fun toggle_66() { assertEquals("[ ] ekmek\n[X] büyük\n[x] ekmek\n[X] büyük\n[x]\n[x]", NotePure.toggleCheck("[x] ekmek\n[X] büyük\n[x] ekmek\n[X] büyük\n[x]\n[x]", 0)) }
    @Test fun counts_66() { assertEquals(2 to 2, NotePure.checkCounts("[x] ekmek\n[X] büyük\n[x] ekmek\n[X] büyük\n[x]\n[x]")) }
    @Test fun toggle_67() { assertEquals("[x] ekmek\ndüz satır\n[x]\n[X] büyük\n", NotePure.toggleCheck("[x] ekmek\ndüz satır\n[x]\n[X] büyük\n", 6)) }
    @Test fun counts_67() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek\ndüz satır\n[x]\n[X] büyük\n")) }
    @Test fun toggle_68() { assertEquals("[X] büyük\ndüz satır", NotePure.toggleCheck("[X] büyük\ndüz satır", 2)) }
    @Test fun counts_68() { assertEquals(0 to 0, NotePure.checkCounts("[X] büyük\ndüz satır")) }
    @Test fun toggle_69() { assertEquals("\n[X] büyük\n[ ] ", NotePure.toggleCheck("\n[X] büyük\n[ ] ", 3)) }
    @Test fun counts_69() { assertEquals(0 to 1, NotePure.checkCounts("\n[X] büyük\n[ ] ")) }
    @Test fun toggle_70() { assertEquals("[X] büyük\n[ ] \n[ ] süt\n[ ] \n[ ] \n\n[X] büyük", NotePure.toggleCheck("[X] büyük\n[ ] \n[ ] süt\n[ ] \n[ ] \n\n[X] büyük", 5)) }
    @Test fun counts_70() { assertEquals(0 to 4, NotePure.checkCounts("[X] büyük\n[ ] \n[ ] süt\n[ ] \n[ ] \n\n[X] büyük")) }
    @Test fun toggle_71() { assertEquals("[X] büyük\n[x]\n[X] büyük\n[x] süt\n\n[x]", NotePure.toggleCheck("[X] büyük\n[x]\n[X] büyük\n[ ] süt\n\n[x]", 3)) }
    @Test fun counts_71() { assertEquals(0 to 1, NotePure.checkCounts("[X] büyük\n[x]\n[X] büyük\n[ ] süt\n\n[x]")) }
    @Test fun toggle_72() { assertEquals("[ ]x\ndüz satır\n\n[x] ekmek\n[x] ekmek\n\n[x]", NotePure.toggleCheck("[ ]x\ndüz satır\n\n[x] ekmek\n[x] ekmek\n\n[x]", 1)) }
    @Test fun counts_72() { assertEquals(2 to 2, NotePure.checkCounts("[ ]x\ndüz satır\n\n[x] ekmek\n[x] ekmek\n\n[x]")) }
    @Test fun toggle_73() { assertEquals("[x] ekmek\ndüz satır\n[x] süt\n[ ]x\n[x]\ndüz satır\n[ ]x", NotePure.toggleCheck("[x] ekmek\ndüz satır\n[ ] süt\n[ ]x\n[x]\ndüz satır\n[ ]x", 2)) }
    @Test fun counts_73() { assertEquals(1 to 2, NotePure.checkCounts("[x] ekmek\ndüz satır\n[ ] süt\n[ ]x\n[x]\ndüz satır\n[ ]x")) }
    @Test fun toggle_74() { assertEquals("\n[x] ekmek\n[x] ekmek\n[ ] süt", NotePure.toggleCheck("\n[x] ekmek\n[x] ekmek\n[ ] süt", 8)) }
    @Test fun counts_74() { assertEquals(2 to 3, NotePure.checkCounts("\n[x] ekmek\n[x] ekmek\n[ ] süt")) }
    @Test fun toggle_75() { assertEquals("[X] büyük", NotePure.toggleCheck("[X] büyük", 3)) }
    @Test fun counts_75() { assertEquals(0 to 0, NotePure.checkCounts("[X] büyük")) }
    @Test fun toggle_76() { assertEquals("düz satır\ndüz satır\n[ ] \ndüz satır\n[x] ekmek", NotePure.toggleCheck("düz satır\ndüz satır\n[ ] \ndüz satır\n[x] ekmek", 1)) }
    @Test fun counts_76() { assertEquals(1 to 2, NotePure.checkCounts("düz satır\ndüz satır\n[ ] \ndüz satır\n[x] ekmek")) }
    @Test fun toggle_77() { assertEquals("[ ] ", NotePure.toggleCheck("[ ] ", -1)) }
    @Test fun counts_77() { assertEquals(0 to 1, NotePure.checkCounts("[ ] ")) }
    @Test fun toggle_78() { assertEquals("[X] büyük\n[ ] süt\n[ ]x", NotePure.toggleCheck("[X] büyük\n[ ] süt\n[ ]x", 0)) }
    @Test fun counts_78() { assertEquals(0 to 1, NotePure.checkCounts("[X] büyük\n[ ] süt\n[ ]x")) }
    @Test fun toggle_79() { assertEquals("[ ] \n[ ]x\n[X] büyük\n[x] ekmek\ndüz satır", NotePure.toggleCheck("[ ] \n[ ]x\n[X] büyük\n[x] ekmek\ndüz satır", 1)) }
    @Test fun counts_79() { assertEquals(1 to 2, NotePure.checkCounts("[ ] \n[ ]x\n[X] büyük\n[x] ekmek\ndüz satır")) }
    @Test fun toggle_80() { assertEquals("düz satır\n[ ] süt\n[x]\n[x]", NotePure.toggleCheck("düz satır\n[ ] süt\n[x]\n[x]", 7)) }
    @Test fun counts_80() { assertEquals(0 to 1, NotePure.checkCounts("düz satır\n[ ] süt\n[x]\n[x]")) }
    @Test fun toggle_81() { assertEquals("düz satır", NotePure.toggleCheck("düz satır", 2)) }
    @Test fun counts_81() { assertEquals(0 to 0, NotePure.checkCounts("düz satır")) }
    @Test fun toggle_82() { assertEquals("[ ] süt", NotePure.toggleCheck("[ ] süt", -1)) }
    @Test fun counts_82() { assertEquals(0 to 1, NotePure.checkCounts("[ ] süt")) }
    @Test fun toggle_83() { assertEquals("\n[ ]x", NotePure.toggleCheck("\n[ ]x", -1)) }
    @Test fun counts_83() { assertEquals(0 to 0, NotePure.checkCounts("\n[ ]x")) }
    @Test fun toggle_84() { assertEquals("[x] ekmek\n\n[x]\n[x]\n[x] ekmek\n[X] büyük", NotePure.toggleCheck("[x] ekmek\n\n[x]\n[x]\n[x] ekmek\n[X] büyük", 1)) }
    @Test fun counts_84() { assertEquals(2 to 2, NotePure.checkCounts("[x] ekmek\n\n[x]\n[x]\n[x] ekmek\n[X] büyük")) }
    @Test fun toggle_85() { assertEquals("[X] büyük\n[x] ekmek\n[X] büyük", NotePure.toggleCheck("[X] büyük\n[x] ekmek\n[X] büyük", 7)) }
    @Test fun counts_85() { assertEquals(1 to 1, NotePure.checkCounts("[X] büyük\n[x] ekmek\n[X] büyük")) }
    @Test fun toggle_86() { assertEquals("[x] ekmek\ndüz satır\n[X] büyük\n[x] ekmek\n\ndüz satır\ndüz satır", NotePure.toggleCheck("[x] ekmek\ndüz satır\n[X] büyük\n[x] ekmek\n\ndüz satır\ndüz satır", 2)) }
    @Test fun counts_86() { assertEquals(2 to 2, NotePure.checkCounts("[x] ekmek\ndüz satır\n[X] büyük\n[x] ekmek\n\ndüz satır\ndüz satır")) }
    @Test fun toggle_87() { assertEquals("[x] ekmek\n\n", NotePure.toggleCheck("[x] ekmek\n\n", 4)) }
    @Test fun counts_87() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek\n\n")) }
    @Test fun toggle_88() { assertEquals("[x] süt\n[x]\n[x] ekmek\n[x]\n[x]", NotePure.toggleCheck("[ ] süt\n[x]\n[x] ekmek\n[x]\n[x]", 0)) }
    @Test fun counts_88() { assertEquals(1 to 2, NotePure.checkCounts("[ ] süt\n[x]\n[x] ekmek\n[x]\n[x]")) }
    @Test fun toggle_89() { assertEquals("[ ]x\n[x]\n", NotePure.toggleCheck("[ ]x\n[x]\n", 5)) }
    @Test fun counts_89() { assertEquals(0 to 0, NotePure.checkCounts("[ ]x\n[x]\n")) }
    @Test fun toggle_90() { assertEquals("[ ]x\ndüz satır\n\n[ ]x\n[ ] süt", NotePure.toggleCheck("[ ]x\ndüz satır\n\n[ ]x\n[ ] süt", 1)) }
    @Test fun counts_90() { assertEquals(0 to 1, NotePure.checkCounts("[ ]x\ndüz satır\n\n[ ]x\n[ ] süt")) }
    @Test fun toggle_91() { assertEquals("[ ]x\n[x] ekmek\n[x]\n[ ] süt\n[X] büyük\n[X] büyük", NotePure.toggleCheck("[ ]x\n[x] ekmek\n[x]\n[ ] süt\n[X] büyük\n[X] büyük", 7)) }
    @Test fun counts_91() { assertEquals(1 to 2, NotePure.checkCounts("[ ]x\n[x] ekmek\n[x]\n[ ] süt\n[X] büyük\n[X] büyük")) }
    @Test fun toggle_92() { assertEquals("[x] ekmek\ndüz satır\n[ ]x\n[ ]x\n[X] büyük\n", NotePure.toggleCheck("[x] ekmek\ndüz satır\n[ ]x\n[ ]x\n[X] büyük\n", 1)) }
    @Test fun counts_92() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek\ndüz satır\n[ ]x\n[ ]x\n[X] büyük\n")) }
    @Test fun toggle_93() { assertEquals("[X] büyük\n[x]", NotePure.toggleCheck("[X] büyük\n[x]", -1)) }
    @Test fun counts_93() { assertEquals(0 to 0, NotePure.checkCounts("[X] büyük\n[x]")) }
    @Test fun toggle_94() { assertEquals("[ ]x\n[ ]x\n[ ] süt\n[ ] ekmek\n[X] büyük\n[X] büyük", NotePure.toggleCheck("[ ]x\n[ ]x\n[ ] süt\n[x] ekmek\n[X] büyük\n[X] büyük", 3)) }
    @Test fun counts_94() { assertEquals(1 to 2, NotePure.checkCounts("[ ]x\n[ ]x\n[ ] süt\n[x] ekmek\n[X] büyük\n[X] büyük")) }
    @Test fun toggle_95() { assertEquals("[X] büyük\n[x] ekmek\ndüz satır\n[X] büyük\ndüz satır", NotePure.toggleCheck("[X] büyük\n[x] ekmek\ndüz satır\n[X] büyük\ndüz satır", 3)) }
    @Test fun counts_95() { assertEquals(1 to 1, NotePure.checkCounts("[X] büyük\n[x] ekmek\ndüz satır\n[X] büyük\ndüz satır")) }
    @Test fun toggle_96() { assertEquals("[ ] ekmek\n[ ] \n[ ] süt", NotePure.toggleCheck("[x] ekmek\n[ ] \n[ ] süt", 0)) }
    @Test fun counts_96() { assertEquals(1 to 3, NotePure.checkCounts("[x] ekmek\n[ ] \n[ ] süt")) }
    @Test fun toggle_97() { assertEquals("[ ]x\n\n[ ] süt\n\n[X] büyük\n[ ] \n[x]", NotePure.toggleCheck("[ ]x\n\n[ ] süt\n\n[X] büyük\n[ ] \n[x]", 8)) }
    @Test fun counts_97() { assertEquals(0 to 2, NotePure.checkCounts("[ ]x\n\n[ ] süt\n\n[X] büyük\n[ ] \n[x]")) }
    @Test fun toggle_98() { assertEquals("[ ] \n[X] büyük", NotePure.toggleCheck("[ ] \n[X] büyük", 7)) }
    @Test fun counts_98() { assertEquals(0 to 1, NotePure.checkCounts("[ ] \n[X] büyük")) }
    @Test fun toggle_99() { assertEquals("\n[ ]x\n[X] büyük\ndüz satır\n[x]", NotePure.toggleCheck("\n[ ]x\n[X] büyük\ndüz satır\n[x]", 3)) }
    @Test fun counts_99() { assertEquals(0 to 0, NotePure.checkCounts("\n[ ]x\n[X] büyük\ndüz satır\n[x]")) }
    @Test fun toggle_100() { assertEquals("[x] ekmek\ndüz satır\n[x] süt\n[X] büyük\n[ ]x\n[ ] ", NotePure.toggleCheck("[x] ekmek\ndüz satır\n[ ] süt\n[X] büyük\n[ ]x\n[ ] ", 2)) }
    @Test fun counts_100() { assertEquals(1 to 3, NotePure.checkCounts("[x] ekmek\ndüz satır\n[ ] süt\n[X] büyük\n[ ]x\n[ ] ")) }
    @Test fun toggle_101() { assertEquals("[X] büyük\n[ ] süt\n[x] ekmek", NotePure.toggleCheck("[X] büyük\n[ ] süt\n[x] ekmek", 3)) }
    @Test fun counts_101() { assertEquals(1 to 2, NotePure.checkCounts("[X] büyük\n[ ] süt\n[x] ekmek")) }
    @Test fun toggle_102() { assertEquals("[X] büyük\ndüz satır\n[ ] süt", NotePure.toggleCheck("[X] büyük\ndüz satır\n[ ] süt", 3)) }
    @Test fun counts_102() { assertEquals(0 to 1, NotePure.checkCounts("[X] büyük\ndüz satır\n[ ] süt")) }
    @Test fun toggle_103() { assertEquals("[ ] \ndüz satır\n[ ]x\n[ ] \n[x]\n[X] büyük\n[x]", NotePure.toggleCheck("[ ] \ndüz satır\n[ ]x\n[ ] \n[x]\n[X] büyük\n[x]", -1)) }
    @Test fun counts_103() { assertEquals(0 to 2, NotePure.checkCounts("[ ] \ndüz satır\n[ ]x\n[ ] \n[x]\n[X] büyük\n[x]")) }
    @Test fun toggle_104() { assertEquals("[x] ekmek", NotePure.toggleCheck("[x] ekmek", -1)) }
    @Test fun counts_104() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek")) }
    @Test fun toggle_105() { assertEquals("[ ]x\n[ ] \n[x] ekmek\n[x] ekmek\n\n", NotePure.toggleCheck("[ ]x\n[ ] \n[x] ekmek\n[x] ekmek\n\n", 4)) }
    @Test fun counts_105() { assertEquals(2 to 3, NotePure.checkCounts("[ ]x\n[ ] \n[x] ekmek\n[x] ekmek\n\n")) }
    @Test fun toggle_106() { assertEquals("[x] ekmek\n[ ] süt\n[x] ekmek\n\n[x]\n\ndüz satır", NotePure.toggleCheck("[x] ekmek\n[ ] süt\n[x] ekmek\n\n[x]\n\ndüz satır", 4)) }
    @Test fun counts_106() { assertEquals(2 to 3, NotePure.checkCounts("[x] ekmek\n[ ] süt\n[x] ekmek\n\n[x]\n\ndüz satır")) }
    @Test fun toggle_107() { assertEquals("[X] büyük\ndüz satır\ndüz satır\n[x] ekmek\n\n[X] büyük\n[x] ekmek", NotePure.toggleCheck("[X] büyük\ndüz satır\ndüz satır\n[x] ekmek\n\n[X] büyük\n[x] ekmek", -1)) }
    @Test fun counts_107() { assertEquals(2 to 2, NotePure.checkCounts("[X] büyük\ndüz satır\ndüz satır\n[x] ekmek\n\n[X] büyük\n[x] ekmek")) }
    @Test fun toggle_108() { assertEquals("[ ] süt\n[ ] ekmek\n[X] büyük\ndüz satır\n[ ]x", NotePure.toggleCheck("[ ] süt\n[x] ekmek\n[X] büyük\ndüz satır\n[ ]x", 1)) }
    @Test fun counts_108() { assertEquals(1 to 2, NotePure.checkCounts("[ ] süt\n[x] ekmek\n[X] büyük\ndüz satır\n[ ]x")) }
    @Test fun toggle_109() { assertEquals("[x]\n[ ] süt\n[ ] ", NotePure.toggleCheck("[x]\n[ ] süt\n[ ] ", 7)) }
    @Test fun counts_109() { assertEquals(0 to 2, NotePure.checkCounts("[x]\n[ ] süt\n[ ] ")) }
    @Test fun toggle_110() { assertEquals("[ ]x\n[ ]x\n[ ]x\n[ ] \n[x]", NotePure.toggleCheck("[ ]x\n[ ]x\n[ ]x\n[ ] \n[x]", 0)) }
    @Test fun counts_110() { assertEquals(0 to 1, NotePure.checkCounts("[ ]x\n[ ]x\n[ ]x\n[ ] \n[x]")) }
    @Test fun toggle_111() { assertEquals("[x] ekmek\n[ ]x", NotePure.toggleCheck("[x] ekmek\n[ ]x", 8)) }
    @Test fun counts_111() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek\n[ ]x")) }
    @Test fun toggle_112() { assertEquals("[x]\n[x] ekmek\n[x] ekmek", NotePure.toggleCheck("[x]\n[x] ekmek\n[x] ekmek", 6)) }
    @Test fun counts_112() { assertEquals(2 to 2, NotePure.checkCounts("[x]\n[x] ekmek\n[x] ekmek")) }
    @Test fun toggle_113() { assertEquals("[ ] \n[x]\n[X] büyük", NotePure.toggleCheck("[ ] \n[x]\n[X] büyük", 1)) }
    @Test fun counts_113() { assertEquals(0 to 1, NotePure.checkCounts("[ ] \n[x]\n[X] büyük")) }
    @Test fun toggle_114() { assertEquals("[X] büyük\n[ ]x\n[ ]x\n[ ]x\ndüz satır", NotePure.toggleCheck("[X] büyük\n[ ]x\n[ ]x\n[ ]x\ndüz satır", 0)) }
    @Test fun counts_114() { assertEquals(0 to 0, NotePure.checkCounts("[X] büyük\n[ ]x\n[ ]x\n[ ]x\ndüz satır")) }
    @Test fun toggle_115() { assertEquals("[ ] süt\n\ndüz satır\n[x]\n[ ] süt", NotePure.toggleCheck("[ ] süt\n\ndüz satır\n[x]\n[ ] süt", 7)) }
    @Test fun counts_115() { assertEquals(0 to 2, NotePure.checkCounts("[ ] süt\n\ndüz satır\n[x]\n[ ] süt")) }
    @Test fun toggle_116() { assertEquals("[ ]x\n[ ]x\n[X] büyük", NotePure.toggleCheck("[ ]x\n[ ]x\n[X] büyük", 0)) }
    @Test fun counts_116() { assertEquals(0 to 0, NotePure.checkCounts("[ ]x\n[ ]x\n[X] büyük")) }
    @Test fun toggle_117() { assertEquals("\n\n[ ] süt\n[ ]x\n[X] büyük\ndüz satır\n[x] ekmek", NotePure.toggleCheck("\n\n[ ] süt\n[ ]x\n[X] büyük\ndüz satır\n[x] ekmek", 7)) }
    @Test fun counts_117() { assertEquals(1 to 2, NotePure.checkCounts("\n\n[ ] süt\n[ ]x\n[X] büyük\ndüz satır\n[x] ekmek")) }
    @Test fun toggle_118() { assertEquals("[ ] ekmek\ndüz satır\n[x] ekmek", NotePure.toggleCheck("[x] ekmek\ndüz satır\n[x] ekmek", 0)) }
    @Test fun counts_118() { assertEquals(2 to 2, NotePure.checkCounts("[x] ekmek\ndüz satır\n[x] ekmek")) }
    @Test fun toggle_119() { assertEquals("[ ] süt\n[X] büyük\n\n[ ]x\n[x] ekmek\n[ ] \n[ ] ekmek", NotePure.toggleCheck("[ ] süt\n[X] büyük\n\n[ ]x\n[x] ekmek\n[ ] \n[x] ekmek", 6)) }
    @Test fun counts_119() { assertEquals(2 to 4, NotePure.checkCounts("[ ] süt\n[X] büyük\n\n[ ]x\n[x] ekmek\n[ ] \n[x] ekmek")) }
    @Test fun toggle_120() { assertEquals("[x] ekmek", NotePure.toggleCheck("[x] ekmek", 4)) }
    @Test fun counts_120() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek")) }
    @Test fun toggle_121() { assertEquals("düz satır\n[ ] süt", NotePure.toggleCheck("düz satır\n[ ] süt", 8)) }
    @Test fun counts_121() { assertEquals(0 to 1, NotePure.checkCounts("düz satır\n[ ] süt")) }
    @Test fun toggle_122() { assertEquals("[ ] ", NotePure.toggleCheck("[ ] ", 1)) }
    @Test fun counts_122() { assertEquals(0 to 1, NotePure.checkCounts("[ ] ")) }
    @Test fun toggle_123() { assertEquals("[ ]x\n[X] büyük\n\n[ ] \n[X] büyük\n\n[ ] ", NotePure.toggleCheck("[ ]x\n[X] büyük\n\n[ ] \n[X] büyük\n\n[ ] ", 8)) }
    @Test fun counts_123() { assertEquals(0 to 2, NotePure.checkCounts("[ ]x\n[X] büyük\n\n[ ] \n[X] büyük\n\n[ ] ")) }
    @Test fun toggle_124() { assertEquals("[ ] süt\n[x]", NotePure.toggleCheck("[ ] süt\n[x]", 8)) }
    @Test fun counts_124() { assertEquals(0 to 1, NotePure.checkCounts("[ ] süt\n[x]")) }
    @Test fun toggle_125() { assertEquals("\n[X] büyük\n[ ]x\n[ ]x\n\n\n[X] büyük", NotePure.toggleCheck("\n[X] büyük\n[ ]x\n[ ]x\n\n\n[X] büyük", -1)) }
    @Test fun counts_125() { assertEquals(0 to 0, NotePure.checkCounts("\n[X] büyük\n[ ]x\n[ ]x\n\n\n[X] büyük")) }
    @Test fun toggle_126() { assertEquals("düz satır\n\n[ ] süt\n[X] büyük", NotePure.toggleCheck("düz satır\n\n[ ] süt\n[X] büyük", 7)) }
    @Test fun counts_126() { assertEquals(0 to 1, NotePure.checkCounts("düz satır\n\n[ ] süt\n[X] büyük")) }
    @Test fun toggle_127() { assertEquals("[X] büyük\n[ ] süt\n[ ] süt\n[x] süt\n[ ] \n[x] ekmek", NotePure.toggleCheck("[X] büyük\n[ ] süt\n[ ] süt\n[ ] süt\n[ ] \n[x] ekmek", 3)) }
    @Test fun counts_127() { assertEquals(1 to 5, NotePure.checkCounts("[X] büyük\n[ ] süt\n[ ] süt\n[ ] süt\n[ ] \n[x] ekmek")) }
    @Test fun toggle_128() { assertEquals("[x]\n[ ]x\n[x]\n", NotePure.toggleCheck("[x]\n[ ]x\n[x]\n", 6)) }
    @Test fun counts_128() { assertEquals(0 to 0, NotePure.checkCounts("[x]\n[ ]x\n[x]\n")) }
    @Test fun toggle_129() { assertEquals("[X] büyük\n\n[ ]x", NotePure.toggleCheck("[X] büyük\n\n[ ]x", 4)) }
    @Test fun counts_129() { assertEquals(0 to 0, NotePure.checkCounts("[X] büyük\n\n[ ]x")) }
    @Test fun toggle_130() { assertEquals("[x]\ndüz satır\n[ ]x\n[ ] \n[ ] ekmek", NotePure.toggleCheck("[x]\ndüz satır\n[ ]x\n[ ] \n[x] ekmek", 4)) }
    @Test fun counts_130() { assertEquals(1 to 2, NotePure.checkCounts("[x]\ndüz satır\n[ ]x\n[ ] \n[x] ekmek")) }
    @Test fun toggle_131() { assertEquals("düz satır\n[X] büyük\n[ ] \n[X] büyük\n[x]\n[x]", NotePure.toggleCheck("düz satır\n[X] büyük\n[ ] \n[X] büyük\n[x]\n[x]", 6)) }
    @Test fun counts_131() { assertEquals(0 to 1, NotePure.checkCounts("düz satır\n[X] büyük\n[ ] \n[X] büyük\n[x]\n[x]")) }
    @Test fun toggle_132() { assertEquals("[ ] \n[ ] \n[x]\ndüz satır\n[x]\ndüz satır\n[ ] süt", NotePure.toggleCheck("[ ] \n[ ] \n[x]\ndüz satır\n[x]\ndüz satır\n[ ] süt", -1)) }
    @Test fun counts_132() { assertEquals(0 to 3, NotePure.checkCounts("[ ] \n[ ] \n[x]\ndüz satır\n[x]\ndüz satır\n[ ] süt")) }
    @Test fun toggle_133() { assertEquals("[x]\n[x]", NotePure.toggleCheck("[x]\n[x]", 1)) }
    @Test fun counts_133() { assertEquals(0 to 0, NotePure.checkCounts("[x]\n[x]")) }
    @Test fun toggle_134() { assertEquals("[X] büyük\n[X] büyük\ndüz satır\n[ ] \n\n", NotePure.toggleCheck("[X] büyük\n[X] büyük\ndüz satır\n[ ] \n\n", 4)) }
    @Test fun counts_134() { assertEquals(0 to 1, NotePure.checkCounts("[X] büyük\n[X] büyük\ndüz satır\n[ ] \n\n")) }
    @Test fun toggle_135() { assertEquals("[ ] süt\n[x]\n[ ]x\n[x] süt\n\n[ ]x", NotePure.toggleCheck("[ ] süt\n[x]\n[ ]x\n[ ] süt\n\n[ ]x", 3)) }
    @Test fun counts_135() { assertEquals(0 to 2, NotePure.checkCounts("[ ] süt\n[x]\n[ ]x\n[ ] süt\n\n[ ]x")) }
    @Test fun toggle_136() { assertEquals("[ ] \ndüz satır", NotePure.toggleCheck("[ ] \ndüz satır", -1)) }
    @Test fun counts_136() { assertEquals(0 to 1, NotePure.checkCounts("[ ] \ndüz satır")) }
    @Test fun toggle_137() { assertEquals("[ ] süt\n\n[ ] süt\n[x] ekmek\n[ ]x\n[ ] ", NotePure.toggleCheck("[ ] süt\n\n[ ] süt\n[x] ekmek\n[ ]x\n[ ] ", 1)) }
    @Test fun counts_137() { assertEquals(1 to 4, NotePure.checkCounts("[ ] süt\n\n[ ] süt\n[x] ekmek\n[ ]x\n[ ] ")) }
    @Test fun toggle_138() { assertEquals("[x] ekmek\n\ndüz satır\ndüz satır\n", NotePure.toggleCheck("[x] ekmek\n\ndüz satır\ndüz satır\n", 2)) }
    @Test fun counts_138() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek\n\ndüz satır\ndüz satır\n")) }
    @Test fun toggle_139() { assertEquals("[ ] süt", NotePure.toggleCheck("[ ] süt", 7)) }
    @Test fun counts_139() { assertEquals(0 to 1, NotePure.checkCounts("[ ] süt")) }
    @Test fun toggle_140() { assertEquals("[x] ekmek\n\n\ndüz satır\n[ ] süt\n[x] ekmek", NotePure.toggleCheck("[x] ekmek\n\n\ndüz satır\n[ ] süt\n[x] ekmek", 3)) }
    @Test fun counts_140() { assertEquals(2 to 3, NotePure.checkCounts("[x] ekmek\n\n\ndüz satır\n[ ] süt\n[x] ekmek")) }
    @Test fun toggle_141() { assertEquals("[x] ekmek\ndüz satır", NotePure.toggleCheck("[x] ekmek\ndüz satır", 1)) }
    @Test fun counts_141() { assertEquals(1 to 1, NotePure.checkCounts("[x] ekmek\ndüz satır")) }
    @Test fun toggle_142() { assertEquals("[ ] ", NotePure.toggleCheck("[ ] ", 8)) }
    @Test fun counts_142() { assertEquals(0 to 1, NotePure.checkCounts("[ ] ")) }
    @Test fun toggle_143() { assertEquals("[ ]x\n[x] ekmek\n[ ] süt\n[ ]x\n[x]\n[ ] süt\n[ ] süt", NotePure.toggleCheck("[ ]x\n[x] ekmek\n[ ] süt\n[ ]x\n[x]\n[ ] süt\n[ ] süt", 0)) }
    @Test fun counts_143() { assertEquals(1 to 4, NotePure.checkCounts("[ ]x\n[x] ekmek\n[ ] süt\n[ ]x\n[x]\n[ ] süt\n[ ] süt")) }
    @Test fun toggle_144() { assertEquals("düz satır\n\n[ ] \n[ ]x\n", NotePure.toggleCheck("düz satır\n\n[ ] \n[ ]x\n", 0)) }
    @Test fun counts_144() { assertEquals(0 to 1, NotePure.checkCounts("düz satır\n\n[ ] \n[ ]x\n")) }
    @Test fun toggle_145() { assertEquals("düz satır\n[ ] süt", NotePure.toggleCheck("düz satır\n[ ] süt", 8)) }
    @Test fun counts_145() { assertEquals(0 to 1, NotePure.checkCounts("düz satır\n[ ] süt")) }
    @Test fun toggle_146() { assertEquals("[ ]x\ndüz satır\n[ ] süt\n", NotePure.toggleCheck("[ ]x\ndüz satır\n[ ] süt\n", 3)) }
    @Test fun counts_146() { assertEquals(0 to 1, NotePure.checkCounts("[ ]x\ndüz satır\n[ ] süt\n")) }
    @Test fun toggle_147() { assertEquals("[X] büyük", NotePure.toggleCheck("[X] büyük", 4)) }
    @Test fun counts_147() { assertEquals(0 to 0, NotePure.checkCounts("[X] büyük")) }
    @Test fun toggle_148() { assertEquals("[X] büyük\n[ ] süt\ndüz satır\n[x]\ndüz satır\n[ ] ", NotePure.toggleCheck("[X] büyük\n[ ] süt\ndüz satır\n[x]\ndüz satır\n[ ] ", 7)) }
    @Test fun counts_148() { assertEquals(0 to 2, NotePure.checkCounts("[X] büyük\n[ ] süt\ndüz satır\n[x]\ndüz satır\n[ ] ")) }
    @Test fun toggle_149() { assertEquals("[X] büyük\n[ ] süt\n\n[X] büyük", NotePure.toggleCheck("[X] büyük\n[ ] süt\n\n[X] büyük", 5)) }
    @Test fun counts_149() { assertEquals(0 to 1, NotePure.checkCounts("[X] büyük\n[ ] süt\n\n[X] büyük")) }
    @Test fun trash_0() { val n = Note(trashedAt = 1L); assertEquals(9, NotePure.daysLeft(n, 1814400002L)); assertFalse(NotePure.isExpired(n, 1814400002L)) }
    @Test fun trash_1() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 1209600001L)); assertFalse(NotePure.isExpired(n, 1209600001L)) }
    @Test fun trash_2() { val n = Note(trashedAt = 1L); assertEquals(0, NotePure.daysLeft(n, 3715200002L)); assertTrue(NotePure.isExpired(n, 3715200002L)) }
    @Test fun trash_3() { val n = Note(trashedAt = 1L); assertEquals(0, NotePure.daysLeft(n, 2764800001L)); assertTrue(NotePure.isExpired(n, 2764800001L)) }
    @Test fun trash_4() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 2851200000L)); assertFalse(NotePure.isExpired(n, 2851200000L)) }
    @Test fun trash_5() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 2073600001L)); assertFalse(NotePure.isExpired(n, 2073600001L)) }
    @Test fun trash_6() { val n = Note(trashedAt = 1L); assertEquals(0, NotePure.daysLeft(n, 3974400000L)); assertTrue(NotePure.isExpired(n, 3974400000L)) }
    @Test fun trash_7() { val n = Note(trashedAt = 432000000L); assertEquals(0, NotePure.daysLeft(n, 3974400000L)); assertTrue(NotePure.isExpired(n, 3974400000L)) }
    @Test fun trash_8() { val n = Note(trashedAt = 1000L); assertEquals(23, NotePure.daysLeft(n, 604801000L)); assertFalse(NotePure.isExpired(n, 604801000L)) }
    @Test fun trash_9() { val n = Note(trashedAt = 1L); assertEquals(5, NotePure.daysLeft(n, 2160000002L)); assertFalse(NotePure.isExpired(n, 2160000002L)) }
    @Test fun trash_10() { val n = Note(trashedAt = 1L); assertEquals(0, NotePure.daysLeft(n, 3110400000L)); assertTrue(NotePure.isExpired(n, 3110400000L)) }
    @Test fun trash_11() { val n = Note(trashedAt = 1L); assertEquals(21, NotePure.daysLeft(n, 864000000L)); assertFalse(NotePure.isExpired(n, 864000000L)) }
    @Test fun trash_12() { val n = Note(trashedAt = 1L); assertEquals(18, NotePure.daysLeft(n, 1036800001L)); assertFalse(NotePure.isExpired(n, 1036800001L)) }
    @Test fun trash_13() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 3974400999L)); assertTrue(NotePure.isExpired(n, 3974400999L)) }
    @Test fun trash_14() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 2678401001L)); assertTrue(NotePure.isExpired(n, 2678401001L)) }
    @Test fun trash_15() { val n = Note(trashedAt = 432000000L); assertEquals(25, NotePure.daysLeft(n, 864000001L)); assertFalse(NotePure.isExpired(n, 864000001L)) }
    @Test fun trash_16() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 86399999L)); assertFalse(NotePure.isExpired(n, 86399999L)) }
    @Test fun trash_17() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 2937601000L)); assertTrue(NotePure.isExpired(n, 2937601000L)) }
    @Test fun trash_18() { val n = Note(trashedAt = 1000L); assertEquals(4, NotePure.daysLeft(n, 2332800999L)); assertFalse(NotePure.isExpired(n, 2332800999L)) }
    @Test fun trash_19() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 431999999L)); assertFalse(NotePure.isExpired(n, 431999999L)) }
    @Test fun trash_20() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 3542399999L)); assertFalse(NotePure.isExpired(n, 3542399999L)) }
    @Test fun trash_21() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 2851201000L)); assertTrue(NotePure.isExpired(n, 2851201000L)) }
    @Test fun trash_22() { val n = Note(trashedAt = 1L); assertEquals(19, NotePure.daysLeft(n, 950400001L)); assertFalse(NotePure.isExpired(n, 950400001L)) }
    @Test fun trash_23() { val n = Note(trashedAt = 432000000L); assertEquals(21, NotePure.daysLeft(n, 1295999999L)); assertFalse(NotePure.isExpired(n, 1295999999L)) }
    @Test fun trash_24() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 3024001000L)); assertTrue(NotePure.isExpired(n, 3024001000L)) }
    @Test fun trash_25() { val n = Note(trashedAt = 432000000L); assertEquals(3, NotePure.daysLeft(n, 2851199999L)); assertFalse(NotePure.isExpired(n, 2851199999L)) }
    @Test fun trash_26() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 432000001L)); assertFalse(NotePure.isExpired(n, 432000001L)) }
    @Test fun trash_27() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 86400000L)); assertFalse(NotePure.isExpired(n, 86400000L)) }
    @Test fun trash_28() { val n = Note(trashedAt = 1L); assertEquals(19, NotePure.daysLeft(n, 950400001L)); assertFalse(NotePure.isExpired(n, 950400001L)) }
    @Test fun trash_29() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 3196800999L)); assertTrue(NotePure.isExpired(n, 3196800999L)) }
    @Test fun trash_30() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 2851201000L)); assertTrue(NotePure.isExpired(n, 2851201000L)) }
    @Test fun trash_31() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 2851200000L)); assertFalse(NotePure.isExpired(n, 2851200000L)) }
    @Test fun trash_32() { val n = Note(trashedAt = 1L); assertEquals(0, NotePure.daysLeft(n, 3715200001L)); assertTrue(NotePure.isExpired(n, 3715200001L)) }
    @Test fun trash_33() { val n = Note(trashedAt = 432000000L); assertEquals(28, NotePure.daysLeft(n, 604800000L)); assertFalse(NotePure.isExpired(n, 604800000L)) }
    @Test fun trash_34() { val n = Note(trashedAt = 432000000L); assertEquals(0, NotePure.daysLeft(n, 4320000001L)); assertTrue(NotePure.isExpired(n, 4320000001L)) }
    @Test fun trash_35() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 3283200000L)); assertFalse(NotePure.isExpired(n, 3283200000L)) }
    @Test fun trash_36() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 431999999L)); assertFalse(NotePure.isExpired(n, 431999999L)) }
    @Test fun trash_37() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 2160000000L)); assertFalse(NotePure.isExpired(n, 2160000000L)) }
    @Test fun trash_38() { val n = Note(trashedAt = 1L); assertEquals(0, NotePure.daysLeft(n, 3024000000L)); assertTrue(NotePure.isExpired(n, 3024000000L)) }
    @Test fun trash_39() { val n = Note(trashedAt = 1000L); assertEquals(14, NotePure.daysLeft(n, 1468800999L)); assertFalse(NotePure.isExpired(n, 1468800999L)) }
    @Test fun trash_40() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 3283200001L)); assertFalse(NotePure.isExpired(n, 3283200001L)) }
    @Test fun trash_41() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 3888001001L)); assertTrue(NotePure.isExpired(n, 3888001001L)) }
    @Test fun trash_42() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 2937600999L)); assertTrue(NotePure.isExpired(n, 2937600999L)) }
    @Test fun trash_43() { val n = Note(trashedAt = 432000000L); assertEquals(27, NotePure.daysLeft(n, 777599999L)); assertFalse(NotePure.isExpired(n, 777599999L)) }
    @Test fun trash_44() { val n = Note(trashedAt = 432000000L); assertEquals(25, NotePure.daysLeft(n, 864000001L)); assertFalse(NotePure.isExpired(n, 864000001L)) }
    @Test fun trash_45() { val n = Note(trashedAt = 1L); assertEquals(24, NotePure.daysLeft(n, 518400002L)); assertFalse(NotePure.isExpired(n, 518400002L)) }
    @Test fun trash_46() { val n = Note(trashedAt = 1000L); assertEquals(5, NotePure.daysLeft(n, 2246400999L)); assertFalse(NotePure.isExpired(n, 2246400999L)) }
    @Test fun trash_47() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 2073600000L)); assertFalse(NotePure.isExpired(n, 2073600000L)) }
    @Test fun trash_48() { val n = Note(trashedAt = 1L); assertEquals(15, NotePure.daysLeft(n, 1382400000L)); assertFalse(NotePure.isExpired(n, 1382400000L)) }
    @Test fun trash_49() { val n = Note(trashedAt = 1L); assertEquals(29, NotePure.daysLeft(n, 172800000L)); assertFalse(NotePure.isExpired(n, 172800000L)) }
    @Test fun trash_50() { val n = Note(trashedAt = 1L); assertEquals(19, NotePure.daysLeft(n, 950400002L)); assertFalse(NotePure.isExpired(n, 950400002L)) }
    @Test fun trash_51() { val n = Note(trashedAt = 1000L); assertEquals(23, NotePure.daysLeft(n, 604801000L)); assertFalse(NotePure.isExpired(n, 604801000L)) }
    @Test fun trash_52() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 518400001L)); assertFalse(NotePure.isExpired(n, 518400001L)) }
    @Test fun trash_53() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 3283200001L)); assertFalse(NotePure.isExpired(n, 3283200001L)) }
    @Test fun trash_54() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 172800000L)); assertFalse(NotePure.isExpired(n, 172800000L)) }
    @Test fun trash_55() { val n = Note(trashedAt = 1000L); assertEquals(10, NotePure.daysLeft(n, 1728001000L)); assertFalse(NotePure.isExpired(n, 1728001000L)) }
    @Test fun trash_56() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 432000000L)); assertFalse(NotePure.isExpired(n, 432000000L)) }
    @Test fun trash_57() { val n = Note(trashedAt = 432000000L); assertEquals(0, NotePure.daysLeft(n, 3801599999L)); assertTrue(NotePure.isExpired(n, 3801599999L)) }
    @Test fun trash_58() { val n = Note(trashedAt = 432000000L); assertEquals(19, NotePure.daysLeft(n, 1468799999L)); assertFalse(NotePure.isExpired(n, 1468799999L)) }
    @Test fun trash_59() { val n = Note(trashedAt = 1000L); assertEquals(17, NotePure.daysLeft(n, 1123201001L)); assertFalse(NotePure.isExpired(n, 1123201001L)) }
    @Test fun trash_60() { val n = Note(trashedAt = 1L); assertEquals(9, NotePure.daysLeft(n, 1900800000L)); assertFalse(NotePure.isExpired(n, 1900800000L)) }
    @Test fun trash_61() { val n = Note(trashedAt = 432000000L); assertEquals(4, NotePure.daysLeft(n, 2678400001L)); assertFalse(NotePure.isExpired(n, 2678400001L)) }
    @Test fun trash_62() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 1209600000L)); assertFalse(NotePure.isExpired(n, 1209600000L)) }
    @Test fun trash_63() { val n = Note(trashedAt = 1000L); assertEquals(19, NotePure.daysLeft(n, 950401001L)); assertFalse(NotePure.isExpired(n, 950401001L)) }
    @Test fun trash_64() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 3024001001L)); assertTrue(NotePure.isExpired(n, 3024001001L)) }
    @Test fun trash_65() { val n = Note(trashedAt = 432000000L); assertEquals(0, NotePure.daysLeft(n, 3110400000L)); assertTrue(NotePure.isExpired(n, 3110400000L)) }
    @Test fun trash_66() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 3110400001L)); assertFalse(NotePure.isExpired(n, 3110400001L)) }
    @Test fun trash_67() { val n = Note(trashedAt = 1L); assertEquals(28, NotePure.daysLeft(n, 172800002L)); assertFalse(NotePure.isExpired(n, 172800002L)) }
    @Test fun trash_68() { val n = Note(trashedAt = 1000L); assertEquals(14, NotePure.daysLeft(n, 1382401001L)); assertFalse(NotePure.isExpired(n, 1382401001L)) }
    @Test fun trash_69() { val n = Note(trashedAt = 1L); assertEquals(0, NotePure.daysLeft(n, 2851200002L)); assertTrue(NotePure.isExpired(n, 2851200002L)) }
    @Test fun trash_70() { val n = Note(trashedAt = 432000000L); assertEquals(0, NotePure.daysLeft(n, 3283200000L)); assertTrue(NotePure.isExpired(n, 3283200000L)) }
    @Test fun trash_71() { val n = Note(trashedAt = 1000L); assertEquals(18, NotePure.daysLeft(n, 1036801001L)); assertFalse(NotePure.isExpired(n, 1036801001L)) }
    @Test fun trash_72() { val n = Note(trashedAt = 1000L); assertEquals(4, NotePure.daysLeft(n, 2332800999L)); assertFalse(NotePure.isExpired(n, 2332800999L)) }
    @Test fun trash_73() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 3801601000L)); assertTrue(NotePure.isExpired(n, 3801601000L)) }
    @Test fun trash_74() { val n = Note(trashedAt = 1L); assertEquals(22, NotePure.daysLeft(n, 777600000L)); assertFalse(NotePure.isExpired(n, 777600000L)) }
    @Test fun trash_75() { val n = Note(trashedAt = 432000000L); assertEquals(0, NotePure.daysLeft(n, 4060800000L)); assertTrue(NotePure.isExpired(n, 4060800000L)) }
    @Test fun trash_76() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 950400001L)); assertFalse(NotePure.isExpired(n, 950400001L)) }
    @Test fun trash_77() { val n = Note(trashedAt = 1L); assertEquals(3, NotePure.daysLeft(n, 2332800002L)); assertFalse(NotePure.isExpired(n, 2332800002L)) }
    @Test fun trash_78() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 3283200001L)); assertFalse(NotePure.isExpired(n, 3283200001L)) }
    @Test fun trash_79() { val n = Note(trashedAt = 1L); assertEquals(0, NotePure.daysLeft(n, 3196800001L)); assertTrue(NotePure.isExpired(n, 3196800001L)) }
    @Test fun trash_80() { val n = Note(trashedAt = 1L); assertEquals(0, NotePure.daysLeft(n, 3456000002L)); assertTrue(NotePure.isExpired(n, 3456000002L)) }
    @Test fun trash_81() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 3023999999L)); assertFalse(NotePure.isExpired(n, 3023999999L)) }
    @Test fun trash_82() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 2678400001L)); assertFalse(NotePure.isExpired(n, 2678400001L)) }
    @Test fun trash_83() { val n = Note(trashedAt = 1000L); assertEquals(30, NotePure.daysLeft(n, 86400999L)); assertFalse(NotePure.isExpired(n, 86400999L)) }
    @Test fun trash_84() { val n = Note(trashedAt = 1000L); assertEquals(4, NotePure.daysLeft(n, 2332800999L)); assertFalse(NotePure.isExpired(n, 2332800999L)) }
    @Test fun trash_85() { val n = Note(trashedAt = 432000000L); assertEquals(9, NotePure.daysLeft(n, 2246400000L)); assertFalse(NotePure.isExpired(n, 2246400000L)) }
    @Test fun trash_86() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 3801601000L)); assertTrue(NotePure.isExpired(n, 3801601000L)) }
    @Test fun trash_87() { val n = Note(trashedAt = 1L); assertEquals(10, NotePure.daysLeft(n, 1728000002L)); assertFalse(NotePure.isExpired(n, 1728000002L)) }
    @Test fun trash_88() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 2678401000L)); assertTrue(NotePure.isExpired(n, 2678401000L)) }
    @Test fun trash_89() { val n = Note(trashedAt = 432000000L); assertEquals(16, NotePure.daysLeft(n, 1641600000L)); assertFalse(NotePure.isExpired(n, 1641600000L)) }
    @Test fun trash_90() { val n = Note(trashedAt = 432000000L); assertEquals(23, NotePure.daysLeft(n, 1036800001L)); assertFalse(NotePure.isExpired(n, 1036800001L)) }
    @Test fun trash_91() { val n = Note(trashedAt = 432000000L); assertEquals(0, NotePure.daysLeft(n, 3456000001L)); assertTrue(NotePure.isExpired(n, 3456000001L)) }
    @Test fun trash_92() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 604799999L)); assertFalse(NotePure.isExpired(n, 604799999L)) }
    @Test fun trash_93() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 2937600999L)); assertTrue(NotePure.isExpired(n, 2937600999L)) }
    @Test fun trash_94() { val n = Note(trashedAt = 1L); assertEquals(0, NotePure.daysLeft(n, 3369600001L)); assertTrue(NotePure.isExpired(n, 3369600001L)) }
    @Test fun trash_95() { val n = Note(trashedAt = 432000000L); assertEquals(18, NotePure.daysLeft(n, 1468800001L)); assertFalse(NotePure.isExpired(n, 1468800001L)) }
    @Test fun trash_96() { val n = Note(trashedAt = 432000000L); assertEquals(7, NotePure.daysLeft(n, 2419200000L)); assertFalse(NotePure.isExpired(n, 2419200000L)) }
    @Test fun trash_97() { val n = Note(trashedAt = 1L); assertEquals(13, NotePure.daysLeft(n, 1468800002L)); assertFalse(NotePure.isExpired(n, 1468800002L)) }
    @Test fun trash_98() { val n = Note(trashedAt = 1000L); assertEquals(0, NotePure.daysLeft(n, 3283201001L)); assertTrue(NotePure.isExpired(n, 3283201001L)) }
    @Test fun trash_99() { val n = Note(trashedAt = 0L); assertEquals(30, NotePure.daysLeft(n, 1296000000L)); assertFalse(NotePure.isExpired(n, 1296000000L)) }
    @Test fun words_0() { assertEquals(4, NotePure.wordCount("çğ a	bb	bb  ")) }
    @Test fun words_1() { assertEquals(2, NotePure.wordCount("a  1	")) }
    @Test fun words_2() { assertEquals(9, NotePure.wordCount("bb  a\nçğ  bb\na	1  a bb\n1 ")) }
    @Test fun words_3() { assertEquals(0, NotePure.wordCount("")) }
    @Test fun words_4() { assertEquals(7, NotePure.wordCount("a  bb	bb\n1\na a\nçğ\n")) }
    @Test fun words_5() { assertEquals(1, NotePure.wordCount("a  ")) }
    @Test fun words_6() { assertEquals(0, NotePure.wordCount("")) }
    @Test fun words_7() { assertEquals(9, NotePure.wordCount("çğ bb\nbb	a\nçğ\n1\n1	a\na	")) }
    @Test fun words_8() { assertEquals(6, NotePure.wordCount("bb  çğ  çğ a  1\nçğ  ")) }
    @Test fun words_9() { assertEquals(5, NotePure.wordCount("1  a	çğ\nbb	1  ")) }
    @Test fun words_10() { assertEquals(8, NotePure.wordCount("çğ  a a  a\n1  1  a	bb ")) }
    @Test fun words_11() { assertEquals(7, NotePure.wordCount("a	1 a  1 çğ\nbb\nbb	")) }
    @Test fun words_12() { assertEquals(6, NotePure.wordCount("a\nbb	a\nçğ a\nçğ  ")) }
    @Test fun words_13() { assertEquals(8, NotePure.wordCount("1\n1  çğ çğ  1	1 1\nbb	")) }
    @Test fun words_14() { assertEquals(9, NotePure.wordCount("a  çğ  bb  1	çğ  a\na\nbb\nçğ  ")) }
    @Test fun words_15() { assertEquals(4, NotePure.wordCount("a	1\n1 çğ  ")) }
    @Test fun words_16() { assertEquals(7, NotePure.wordCount("a 1  bb	1  1\n1 çğ\n")) }
    @Test fun words_17() { assertEquals(4, NotePure.wordCount("1 çğ 1\nçğ  ")) }
    @Test fun words_18() { assertEquals(6, NotePure.wordCount("bb\nçğ bb 1 bb 1	")) }
    @Test fun words_19() { assertEquals(4, NotePure.wordCount("1  bb\nbb	1 ")) }
    @Test fun words_20() { assertEquals(6, NotePure.wordCount("bb  1  bb a çğ\nbb ")) }
    @Test fun words_21() { assertEquals(1, NotePure.wordCount("çğ\n")) }
    @Test fun words_22() { assertEquals(5, NotePure.wordCount("a\nçğ  a	çğ\nçğ  ")) }
    @Test fun words_23() { assertEquals(3, NotePure.wordCount("1\n1  1	")) }
    @Test fun words_24() { assertEquals(3, NotePure.wordCount("a	1\nçğ\n")) }
    @Test fun words_25() { assertEquals(2, NotePure.wordCount("1 bb\n")) }
    @Test fun words_26() { assertEquals(8, NotePure.wordCount("çğ çğ\na bb\na	çğ 1  çğ	")) }
    @Test fun words_27() { assertEquals(8, NotePure.wordCount("bb  1	1	çğ 1 1	1\nçğ	")) }
    @Test fun words_28() { assertEquals(9, NotePure.wordCount("a çğ  a  bb  çğ	1	a\n1	1	")) }
    @Test fun words_29() { assertEquals(6, NotePure.wordCount("1\nbb\nbb  bb\na	1 ")) }
    @Test fun words_30() { assertEquals(4, NotePure.wordCount("bb a  çğ	a	")) }
    @Test fun words_31() { assertEquals(6, NotePure.wordCount("1\n1\nbb  çğ	1  çğ ")) }
    @Test fun words_32() { assertEquals(2, NotePure.wordCount("a  çğ	")) }
    @Test fun words_33() { assertEquals(7, NotePure.wordCount("bb\nçğ  a 1 bb\na\nçğ\n")) }
    @Test fun words_34() { assertEquals(3, NotePure.wordCount("1 bb	a	")) }
    @Test fun words_35() { assertEquals(0, NotePure.wordCount("")) }
    @Test fun words_36() { assertEquals(8, NotePure.wordCount("1	1  çğ	bb  1\nbb  a\nbb ")) }
    @Test fun words_37() { assertEquals(0, NotePure.wordCount("")) }
    @Test fun words_38() { assertEquals(1, NotePure.wordCount("çğ\n")) }
    @Test fun words_39() { assertEquals(5, NotePure.wordCount("bb 1\nçğ\na  çğ\n")) }
    @Test fun words_40() { assertEquals(0, NotePure.wordCount("")) }
    @Test fun words_41() { assertEquals(6, NotePure.wordCount("1 a\nbb  a çğ  çğ	")) }
    @Test fun words_42() { assertEquals(6, NotePure.wordCount("a	a	çğ\na	1\nçğ\n")) }
    @Test fun words_43() { assertEquals(5, NotePure.wordCount("1  1	bb  a\nçğ ")) }
    @Test fun words_44() { assertEquals(9, NotePure.wordCount("bb\na\n1	bb	bb  bb	1	bb çğ	")) }
    @Test fun words_45() { assertEquals(8, NotePure.wordCount("bb	çğ\n1\na bb  1	1\nçğ ")) }
    @Test fun words_46() { assertEquals(8, NotePure.wordCount("a  a a	1 1\n1	a çğ ")) }
    @Test fun words_47() { assertEquals(3, NotePure.wordCount("bb 1 bb ")) }
    @Test fun words_48() { assertEquals(3, NotePure.wordCount("a  a	çğ  ")) }
    @Test fun words_49() { assertEquals(0, NotePure.wordCount("")) }
    @Test fun words_50() { assertEquals(1, NotePure.wordCount("bb  ")) }
    @Test fun words_51() { assertEquals(8, NotePure.wordCount("çğ 1 çğ  1	a  çğ	çğ  a ")) }
    @Test fun words_52() { assertEquals(8, NotePure.wordCount("çğ	a a	bb  1	bb a\nçğ ")) }
    @Test fun words_53() { assertEquals(0, NotePure.wordCount("")) }
    @Test fun words_54() { assertEquals(4, NotePure.wordCount("bb  bb\nbb  çğ ")) }
    @Test fun words_55() { assertEquals(6, NotePure.wordCount("a\nçğ çğ\nçğ bb  1 ")) }
    @Test fun words_56() { assertEquals(4, NotePure.wordCount("çğ\n1 a	çğ ")) }
    @Test fun words_57() { assertEquals(7, NotePure.wordCount("a\n1 bb\nbb	a	1  a	")) }
    @Test fun words_58() { assertEquals(0, NotePure.wordCount("")) }
    @Test fun words_59() { assertEquals(2, NotePure.wordCount("1\nçğ ")) }
    @Test fun words_60() { assertEquals(0, NotePure.wordCount("")) }
    @Test fun words_61() { assertEquals(4, NotePure.wordCount("a bb\nçğ  bb ")) }
    @Test fun words_62() { assertEquals(4, NotePure.wordCount("çğ 1\n1	1\n")) }
    @Test fun words_63() { assertEquals(3, NotePure.wordCount("a	bb a  ")) }
    @Test fun words_64() { assertEquals(5, NotePure.wordCount("bb	1 a 1 a ")) }
    @Test fun words_65() { assertEquals(5, NotePure.wordCount("bb\n1	a	bb bb\n")) }
    @Test fun words_66() { assertEquals(6, NotePure.wordCount("bb	çğ a\nbb 1  bb	")) }
    @Test fun words_67() { assertEquals(1, NotePure.wordCount("bb  ")) }
    @Test fun words_68() { assertEquals(3, NotePure.wordCount("1	bb  1\n")) }
    @Test fun words_69() { assertEquals(6, NotePure.wordCount("a\n1	1	a	a 1	")) }
    @Test fun words_70() { assertEquals(1, NotePure.wordCount("1\n")) }
    @Test fun words_71() { assertEquals(3, NotePure.wordCount("çğ\nbb\na\n")) }
    @Test fun words_72() { assertEquals(8, NotePure.wordCount("bb çğ\na	bb  1\nbb 1 a\n")) }
    @Test fun words_73() { assertEquals(1, NotePure.wordCount("çğ	")) }
    @Test fun words_74() { assertEquals(5, NotePure.wordCount("çğ  a  bb\n1 çğ\n")) }
    @Test fun words_75() { assertEquals(9, NotePure.wordCount("1  a a  1  çğ\n1\n1 1\nbb\n")) }
    @Test fun words_76() { assertEquals(7, NotePure.wordCount("çğ  çğ  1  bb\nbb bb 1	")) }
    @Test fun words_77() { assertEquals(6, NotePure.wordCount("a  1 çğ  a	bb\nçğ	")) }
    @Test fun words_78() { assertEquals(1, NotePure.wordCount("bb	")) }
    @Test fun words_79() { assertEquals(5, NotePure.wordCount("1 1\nçğ çğ çğ	")) }
    @Test fun pageH_0() { assertEquals(4.64f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.04f))))), 0.001f) }
    @Test fun pageH_1() { assertEquals(4.3f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,3.7f))))), 0.001f) }
    @Test fun pageH_2() { assertEquals(6.38f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,5.78f))))), 0.001f) }
    @Test fun pageH_3() { assertEquals(3.27f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,2.67f))))), 0.001f) }
    @Test fun pageH_4() { assertEquals(1.4f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,0.59f))))), 0.001f) }
    @Test fun pageH_5() { assertEquals(5.56f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.96f))))), 0.001f) }
    @Test fun pageH_6() { assertEquals(4.05f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,3.45f))))), 0.001f) }
    @Test fun pageH_7() { assertEquals(6.3f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,5.7f))))), 0.001f) }
    @Test fun pageH_8() { assertEquals(2.62f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,2.02f))))), 0.001f) }
    @Test fun pageH_9() { assertEquals(2.42f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.82f))))), 0.001f) }
    @Test fun pageH_10() { assertEquals(1.46f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,0.86f))))), 0.001f) }
    @Test fun pageH_11() { assertEquals(1.4f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,0.38f))))), 0.001f) }
    @Test fun pageH_12() { assertEquals(1.4f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,0.48f))))), 0.001f) }
    @Test fun pageH_13() { assertEquals(5.51f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.91f))))), 0.001f) }
    @Test fun pageH_14() { assertEquals(1.9700000000000002f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.37f))))), 0.001f) }
    @Test fun pageH_15() { assertEquals(1.8900000000000001f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.29f))))), 0.001f) }
    @Test fun pageH_16() { assertEquals(6.5f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,5.9f))))), 0.001f) }
    @Test fun pageH_17() { assertEquals(1.5f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,0.9f))))), 0.001f) }
    @Test fun pageH_18() { assertEquals(4.05f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,3.45f))))), 0.001f) }
    @Test fun pageH_19() { assertEquals(1.88f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.28f))))), 0.001f) }
    @Test fun pageH_20() { assertEquals(6.0f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,5.4f))))), 0.001f) }
    @Test fun pageH_21() { assertEquals(5.239999999999999f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.64f))))), 0.001f) }
    @Test fun pageH_22() { assertEquals(3.4f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,2.8f))))), 0.001f) }
    @Test fun pageH_23() { assertEquals(1.6400000000000001f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.04f))))), 0.001f) }
    @Test fun pageH_24() { assertEquals(4.13f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,3.53f))))), 0.001f) }
    @Test fun pageH_25() { assertEquals(1.69f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.09f))))), 0.001f) }
    @Test fun pageH_26() { assertEquals(4.49f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,3.89f))))), 0.001f) }
    @Test fun pageH_27() { assertEquals(3.23f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,2.63f))))), 0.001f) }
    @Test fun pageH_28() { assertEquals(4.869999999999999f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.27f))))), 0.001f) }
    @Test fun pageH_29() { assertEquals(5.159999999999999f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.56f))))), 0.001f) }
    @Test fun pageH_30() { assertEquals(2.18f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.58f))))), 0.001f) }
    @Test fun pageH_31() { assertEquals(4.85f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.25f))))), 0.001f) }
    @Test fun pageH_32() { assertEquals(1.7000000000000002f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.1f))))), 0.001f) }
    @Test fun pageH_33() { assertEquals(1.67f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.07f))))), 0.001f) }
    @Test fun pageH_34() { assertEquals(6.09f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,5.49f))))), 0.001f) }
    @Test fun pageH_35() { assertEquals(1.4f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,0.29f))))), 0.001f) }
    @Test fun pageH_36() { assertEquals(5.6899999999999995f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,5.09f))))), 0.001f) }
    @Test fun pageH_37() { assertEquals(3.41f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,2.81f))))), 0.001f) }
    @Test fun pageH_38() { assertEquals(1.4f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,0.22f))))), 0.001f) }
    @Test fun pageH_39() { assertEquals(1.4f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,0.72f))))), 0.001f) }
    @Test fun pageH_40() { assertEquals(4.83f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.23f))))), 0.001f) }
    @Test fun pageH_41() { assertEquals(1.54f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,0.94f))))), 0.001f) }
    @Test fun pageH_42() { assertEquals(2.19f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.59f))))), 0.001f) }
    @Test fun pageH_43() { assertEquals(2.01f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.41f))))), 0.001f) }
    @Test fun pageH_44() { assertEquals(5.4399999999999995f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.84f))))), 0.001f) }
    @Test fun pageH_45() { assertEquals(6.34f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,5.74f))))), 0.001f) }
    @Test fun pageH_46() { assertEquals(1.77f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.17f))))), 0.001f) }
    @Test fun pageH_47() { assertEquals(5.47f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.87f))))), 0.001f) }
    @Test fun pageH_48() { assertEquals(1.81f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.21f))))), 0.001f) }
    @Test fun pageH_49() { assertEquals(5.069999999999999f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.47f))))), 0.001f) }
    @Test fun pageH_50() { assertEquals(5.43f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.83f))))), 0.001f) }
    @Test fun pageH_51() { assertEquals(2.4899999999999998f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.89f))))), 0.001f) }
    @Test fun pageH_52() { assertEquals(1.4f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,0.44f))))), 0.001f) }
    @Test fun pageH_53() { assertEquals(6.56f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,5.96f))))), 0.001f) }
    @Test fun pageH_54() { assertEquals(4.54f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,3.94f))))), 0.001f) }
    @Test fun pageH_55() { assertEquals(2.7f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,2.1f))))), 0.001f) }
    @Test fun pageH_56() { assertEquals(3.38f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,2.78f))))), 0.001f) }
    @Test fun pageH_57() { assertEquals(3.99f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,3.39f))))), 0.001f) }
    @Test fun pageH_58() { assertEquals(4.96f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,4.36f))))), 0.001f) }
    @Test fun pageH_59() { assertEquals(2.03f, NotePure.pageHeight(listOf(Stroke(0,0,4f,listOf(Pt(0f,1.43f))))), 0.001f) }
}
