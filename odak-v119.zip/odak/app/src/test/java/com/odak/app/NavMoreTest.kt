package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.28: 4 sekmeli menü, "Diğer" sayfası ve tüm stiller için tek ana ekran düzeni. */
class NavMoreTest {
    private fun code(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()

    @Test fun mainHasFiveTabsInOrder() {
        val m = code("MainActivity.kt")
        assertTrue(m.contains("R.string.tab_plan,\n        R.string.tab_todo_s,\n        R.string.tab_block,\n        R.string.notes_title,\n        R.string.tab_more"))
        assertEquals(2, Regex("icons = listOf\\(\"📅\", \"☑\", \"⛔\", \"📝\", \"☰\"\\)").findAll(m).count())
        assertFalse(m.contains("\"⏱\", \"⛔\", \"⚙\""))
    }
    @Test fun pagesRouteToBlockAndMore() {
        val m = code("MainActivity.kt")
        assertTrue(m.contains("2 -> BlockScreen()"))
        assertTrue(m.contains("3 -> com.odak.app.notes.NotesHub(embedded = true, onEditorChange = { hideBar = it })"))
        assertTrue(m.contains("4 -> com.odak.app.settings.MoreScreen("))
        assertTrue(m.contains("labels.getOrElse(page)"))
    }
    @Test fun moreListsThreeEntriesAndHandlesBack() {
        val s = code("settings/MoreScreen.kt")
        for (e in listOf("SCREEN_TIME(", "DOCS(", "SETTINGS(")) assertTrue(e, s.contains(e))
        assertTrue(s.contains("BackHandler(enabled = open != null)"))
        assertFalse(s.contains("NOTES("))
        assertTrue(s.contains("DocActivity::class.java"))
    }
    @Test fun allStylesUseUnifiedPlan() {
        val p = code("plan/PlanScreen.kt")
        assertTrue(p.contains("UnifiedPlan(vm, style)"))
        assertFalse(p.contains("DesignStyle.COSMIC ->"))
        val u = code("plan/UnifiedPlan.kt")
        for (c in listOf("PeriodSelector(", "NavRow(vm)", "AddRow(vm)", "WeekGrid(", "MonthGrid(")) assertTrue(c, u.contains(c))
    }
    @Test fun tabMoreStringInEveryLocale() {
        for (d in TestFiles.res.listFiles { f -> f.isDirectory && f.name.startsWith("values") }!!) {
            val f = File(d, "strings.xml"); if (f.exists()) assertTrue(d.name, f.readText().contains("name=\"tab_more\""))
        }
    }
}
