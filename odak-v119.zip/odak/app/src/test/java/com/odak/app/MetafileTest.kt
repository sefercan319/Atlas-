package com.odak.app

import com.odak.app.docs.DocVisual
import com.odak.app.docs.Metafile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.random.Random

/** v0.56.4: EMF/WMF okuyucu — LibreOffice'in ürettiği gerçek dosyalar ve elle üretilen kayıtlar. */
class MetafileTest {
    private val dir: File = listOf(File("src/test/resources/meta"), File("app/src/test/resources/meta")).first { it.exists() }
    private fun fx(n: String) = File(dir, n).readBytes()

    // ---- bayt kurucular
    private class W { val o = ByteArrayOutputStream()
        fun i(v: Int) = apply { o.write(v and 0xFF); o.write((v shr 8) and 0xFF); o.write((v shr 16) and 0xFF); o.write((v shr 24) and 0xFF) }
        fun s(v: Int) = apply { o.write(v and 0xFF); o.write((v shr 8) and 0xFF) }
        fun f(v: Float) = i(java.lang.Float.floatToIntBits(v))
        fun b(v: ByteArray) = apply { o.write(v) }
        fun bytes() = o.toByteArray() }
    private fun rec(type: Int, vararg ints: Int): ByteArray { val w = W().i(type).i(8 + 4 * ints.size); for (v in ints) w.i(v); return w.bytes() }
    private fun recBytes(type: Int, body: ByteArray): ByteArray { val pad = (4 - body.size % 4) % 4; return W().i(type).i(8 + body.size + pad).b(body).b(ByteArray(pad)).bytes() }
    private fun emf(bounds: IntArray, vararg recs: ByteArray): ByteArray {
        val hdrBody = W().i(bounds[0]).i(bounds[1]).i(bounds[2]).i(bounds[3]).i(0).i(0).i(100).i(100).i(0x464D4520).i(0x10000).i(0).i(0).i(0).i(0).i(0).i(0).i(0).i(0).bytes()
        val all = ByteArrayOutputStream(); all.write(recBytes(1, hdrBody)); for (r in recs) all.write(r); all.write(rec(14, 0, 0, 0)); return all.toByteArray()
    }
    private fun pts32(type: Int, vararg p: Int) = recBytes(type, W().i(0).i(0).i(0).i(0).i(p.size / 2).also { w -> p.forEach { w.i(it) } }.bytes())
    private fun pts16(type: Int, vararg p: Int) = recBytes(type, W().i(0).i(0).i(0).i(0).i(p.size / 2).also { w -> p.forEach { w.s(it) } }.bytes())
    private fun mapAniso(wx: Int, wy: Int, vx: Int, vy: Int) = arrayOf(rec(17, 8), rec(9, wx, wy), rec(11, vx, vy))

    private fun poly(m: Metafile.Meta, i: Int = 0) = m.ops.filterIsInstance<Metafile.Poly>()[i]

    // ---- biçim tanıma
    @Test fun recognisesFormats() { assertTrue(Metafile.isEmf(fx("s.emf"))); assertTrue(Metafile.isWmf(fx("s.wmf"))); assertFalse(Metafile.isEmf(fx("s.wmf"))); assertFalse(Metafile.isWmf(fx("s.emf"))); assertFalse(Metafile.isEmf(ByteArray(10))); assertNull(Metafile.parse(ByteArray(100))) }

    // ---- gerçek dosyalar
    @Test fun realEmfShapesAndText() {
        val m = Metafile.parse(fx("s.emf"))!!
        assertTrue(m.ops.size >= 50); assertTrue(m.ops.filterIsInstance<Metafile.Poly>().size >= 5)
        val t = m.ops.filterIsInstance<Metafile.Text>().single(); assertEquals("Merhaba Atlas ğüşİ", t.s)
        assertEquals(374.0 / 234.0, m.w / m.h, 0.08)
        assertTrue(m.ops.filterIsInstance<Metafile.Poly>().any { it.fill == 0xFF4C8DF6.toInt() })   // mavi dikdörtgen
        assertTrue(m.ops.filterIsInstance<Metafile.Poly>().any { it.fill == 0xFFF6A04C.toInt() })   // turuncu elips
    }
    @Test fun realWmfShapesAndText() {
        val m = Metafile.parse(fx("s.wmf"))!!
        assertEquals("Merhaba Atlas ğüşİ", m.ops.filterIsInstance<Metafile.Text>().single().s)
        assertEquals(374.0 / 234.0, m.w / m.h, 0.08)
        assertTrue(m.ops.filterIsInstance<Metafile.Poly>().any { it.fill == 0xFF5CC27E.toInt() })   // yeşil üçgen
    }
    @Test fun realEmfAndWmfAgreeOnLayout() {
        val a = Metafile.parse(fx("s.emf"))!!; val b = Metafile.parse(fx("s.wmf"))!!
        val ta = a.ops.filterIsInstance<Metafile.Text>().single(); val tb = b.ops.filterIsInstance<Metafile.Text>().single()
        assertEquals((ta.x - a.left) / a.w, (tb.x - b.left) / b.w, 0.03); assertEquals((ta.y - a.top) / a.h, (tb.y - b.top) / b.h, 0.03)
    }
    @Test fun realEmfBitmapOrientationAndColours() {
        val m = Metafile.parse(fx("p.emf"))!!
        val bm = m.ops.filterIsInstance<Metafile.Bmp>().single(); assertEquals(64, bm.pw); assertEquals(48, bm.ph)
        assertEquals(0xFF000000.toInt(), bm.argb[0])                                  // sol üst (0,0,0)
        assertEquals(0xFFFC007E.toInt(), bm.argb[63])                                 // sağ üst (252,0,126)
        assertEquals(0xFFFCEBDC.toInt(), bm.argb[47 * 64 + 63])                       // sağ alt (252,235,220)
    }
    @Test fun fuzzedFilesNeverThrow() {
        val r = Random(77)
        for (n in listOf("s.emf", "s.wmf", "p.emf")) {
            val good = fx(n)
            repeat(150) { val b = good.copyOf(); repeat(r.nextInt(1, 40)) { b[r.nextInt(b.size)] = r.nextInt().toByte() }; Metafile.parse(b) }
            repeat(60) { Metafile.parse(good.copyOf(r.nextInt(1, good.size))) }
        }
    }

    // ---- EMF kayıtları
    @Test fun polygonWithAnisotropicMapping() {
        // pencere 100x100 → görünüm 200x300: x×2, y×3
        val b = emf(intArrayOf(0, 0, 199, 299), *mapAniso(100, 100, 200, 300), pts32(3, 10, 10, 50, 10, 50, 40))
        val p = poly(Metafile.parse(b)!!); val c = p.subs[0].pts
        assertEquals(listOf(20.0, 30.0, 100.0, 30.0, 100.0, 120.0), c.toList()); assertTrue(p.subs[0].closed)
    }
    @Test fun windowOriginShiftsCoordinates() {
        val b = emf(intArrayOf(0, 0, 99, 99), rec(17, 8), rec(9, 100, 100), rec(11, 100, 100), rec(10, 50, 50), pts32(4, 60, 60, 70, 70))
        assertEquals(listOf(10.0, 10.0, 20.0, 20.0), poly(Metafile.parse(b)!!).subs[0].pts.toList())
    }
    @Test fun textModeIgnoresWindowExtents() {
        val b = emf(intArrayOf(0, 0, 99, 99), rec(17, 1), rec(9, 7, 7), rec(11, 700, 700), pts32(4, 10, 10, 20, 20))
        assertEquals(listOf(10.0, 10.0, 20.0, 20.0), poly(Metafile.parse(b)!!).subs[0].pts.toList())
    }
    @Test fun sixteenBitPolylineAndNegativeValues() {
        val b = emf(intArrayOf(-50, -50, 49, 49), pts16(87, -10, -20, 30, 40))
        assertEquals(listOf(-10.0, -20.0, 30.0, 40.0), poly(Metafile.parse(b)!!).subs[0].pts.toList())
    }
    @Test fun rectangleIsClosedFourPoints() {
        val b = emf(intArrayOf(0, 0, 99, 99), rec(43, 10, 20, 60, 70))
        val p = poly(Metafile.parse(b)!!); assertEquals(8, p.subs[0].pts.size); assertTrue(p.subs[0].closed); assertEquals(listOf(10.0, 20.0, 60.0, 20.0, 60.0, 70.0, 10.0, 70.0), p.subs[0].pts.toList())
    }
    @Test fun ellipseStaysInsideBox() {
        val m = Metafile.parse(emf(intArrayOf(0, 0, 99, 99), rec(42, 10, 20, 90, 60)))!!
        val c = poly(m).subs[0].pts; var i = 0; while (i < c.size) { assertTrue(c[i] in 9.99..90.01 && c[i + 1] in 19.99..60.01); i += 2 }
        assertTrue(c.size > 40)
    }
    @Test fun penAndBrushObjects() {
        val b = emf(intArrayOf(0, 0, 99, 99),
            rec(38, 1, 0, 3, 0, 0x0000FF),          // kalem: kırmızı (COLORREF BGR=0x0000FF → R=255), genişlik 3
            rec(39, 2, 0, 0x00FF00, 0),              // fırça: yeşil
            rec(37, 1), rec(37, 2), rec(43, 0, 0, 10, 10))
        val p = poly(Metafile.parse(b)!!)
        assertEquals(0xFFFF0000.toInt(), p.stroke); assertEquals(0xFF00FF00.toInt(), p.fill); assertEquals(3.0, p.sw, 1e-9)
    }
    @Test fun nullBrushAndNullPen() {
        val hollow = emf(intArrayOf(0, 0, 99, 99), rec(37, 0x80000005.toInt()), rec(43, 0, 0, 10, 10))
        assertNull(poly(Metafile.parse(hollow)!!).fill)
        val noPen = emf(intArrayOf(0, 0, 99, 99), rec(37, 0x80000008.toInt()), rec(43, 0, 0, 10, 10))
        assertNull(poly(Metafile.parse(noPen)!!).stroke)
    }
    @Test fun stockBrushesAndPens() { val m = Metafile.parse(emf(intArrayOf(0, 0, 99, 99), rec(37, 0x80000004.toInt()), rec(37, 0x80000006.toInt()), rec(43, 0, 0, 10, 10)))!!; assertEquals(0xFF000000.toInt(), poly(m).fill); assertEquals(0xFFFFFFFF.toInt(), poly(m).stroke) }
    @Test fun deleteObjectThenSelectIgnored() {
        val b = emf(intArrayOf(0, 0, 99, 99), rec(39, 1, 0, 0x0000FF, 0), rec(37, 1), rec(40, 1), rec(37, 1), rec(43, 0, 0, 10, 10))
        assertEquals(0xFFFF0000.toInt(), poly(Metafile.parse(b)!!).fill)   // COLORREF 0x0000FF = kırmızı
    }
    @Test fun saveRestoreDc() {
        val b = emf(intArrayOf(0, 0, 99, 99), rec(39, 1, 0, 0x0000FF, 0), rec(33), rec(37, 1), rec(43, 0, 0, 5, 5), rec(34, -1), rec(43, 6, 6, 9, 9))
        val ps = Metafile.parse(b)!!.ops.filterIsInstance<Metafile.Poly>()
        assertEquals(0xFFFF0000.toInt(), ps[0].fill); assertEquals(0xFFFFFFFF.toInt(), ps[1].fill)   // geri yüklenince varsayılan beyaz fırça
    }
    @Test fun worldTransformTranslateScale() {
        val w = W().i(35).i(32).f(2f).f(0f).f(0f).f(3f).f(10f).f(20f).bytes()
        val b = emf(intArrayOf(0, 0, 99, 99), w, pts32(4, 1, 1, 2, 2))
        assertEquals(listOf(12.0, 23.0, 14.0, 26.0), poly(Metafile.parse(b)!!).subs[0].pts.toList())
    }
    @Test fun modifyWorldTransformModes() {
        val set = W().i(35).i(32).f(1f).f(0f).f(0f).f(1f).f(5f).f(5f).bytes()
        val mod = W().i(36).i(36).f(2f).f(0f).f(0f).f(2f).f(0f).f(0f).i(3).bytes()     // mevcut × ölçek 2
        val reset = W().i(36).i(36).f(1f).f(0f).f(0f).f(1f).f(0f).f(0f).i(1).bytes()
        val b = emf(intArrayOf(0, 0, 99, 99), set, mod, pts32(4, 1, 1, 2, 2), reset, pts32(4, 1, 1, 2, 2))
        val ps = Metafile.parse(b)!!.ops.filterIsInstance<Metafile.Poly>()
        assertEquals(listOf(2.0 + 10.0, 2.0 + 10.0, 4.0 + 10.0, 4.0 + 10.0), ps[0].subs[0].pts.toList()); assertEquals(listOf(1.0, 1.0, 2.0, 2.0), ps[1].subs[0].pts.toList())
    }
    @Test fun moveToLineTo() { val b = emf(intArrayOf(0, 0, 99, 99), rec(27, 5, 6), rec(54, 20, 30)); assertEquals(listOf(5.0, 6.0, 20.0, 30.0), poly(Metafile.parse(b)!!).subs[0].pts.toList()) }
    @Test fun polylineToContinuesFromCurrentPoint() { val b = emf(intArrayOf(0, 0, 99, 99), rec(27, 1, 1), pts32(6, 5, 5, 9, 9)); assertEquals(listOf(1.0, 1.0, 5.0, 5.0, 9.0, 9.0), poly(Metafile.parse(b)!!).subs[0].pts.toList()) }
    @Test fun bezierFlattensEndsAtLastPoint() { val b = emf(intArrayOf(0, 0, 99, 99), pts32(2, 0, 0, 10, 40, 30, 40, 40, 0)); val c = poly(Metafile.parse(b)!!).subs[0].pts; assertEquals(0.0, c[0], 1e-9); assertEquals(40.0, c[c.size - 2], 1e-9); assertEquals(0.0, c[c.size - 1], 1e-9); assertTrue(c.size > 20); assertTrue(c.toList().filterIndexed { i, _ -> i % 2 == 1 }.max() > 10.0) }
    @Test fun polyPolygonTwoSubpaths() {
        val body = W().i(0).i(0).i(0).i(0).i(2).i(7).i(3).i(4).also { w -> listOf(0, 0, 10, 0, 5, 9, 20, 20, 30, 20, 30, 30, 20, 30).forEach { w.i(it) } }.bytes()
        val m = Metafile.parse(emf(intArrayOf(0, 0, 99, 99), recBytes(8, body)))!!
        assertEquals(2, poly(m).subs.size); assertEquals(6, poly(m).subs[0].pts.size); assertEquals(8, poly(m).subs[1].pts.size)
    }
    @Test fun pathFillWithHole() {
        val b = emf(intArrayOf(0, 0, 99, 99), rec(59), rec(27, 0, 0), rec(54, 50, 0), rec(54, 50, 50), rec(54, 0, 50), rec(61), rec(27, 10, 10), rec(54, 40, 10), rec(54, 40, 40), rec(54, 10, 40), rec(61), rec(60), rec(62, 0, 0, 0, 0))
        val p = poly(Metafile.parse(b)!!); assertEquals(2, p.subs.size); assertTrue(p.subs.all { it.closed }); assertNotNull(p.fill)
    }
    @Test fun strokePathUsesPenOnly() {
        val b = emf(intArrayOf(0, 0, 99, 99), rec(59), rec(27, 0, 0), rec(54, 50, 50), rec(60), rec(64, 0, 0, 0, 0))
        val p = poly(Metafile.parse(b)!!); assertNull(p.fill); assertNotNull(p.stroke)
    }
    @Test fun pathBezierToStaysOneSubpath() {
        val b = emf(intArrayOf(0, 0, 99, 99), rec(59), rec(27, 0, 0), pts32(5, 10, 0, 20, 10, 20, 20), rec(54, 0, 20), rec(61), rec(60), rec(62, 0, 0, 0, 0))
        val p = poly(Metafile.parse(b)!!); assertEquals(1, p.subs.size); assertTrue(p.subs[0].pts.size > 20)
    }
    @Test fun abortPathDiscards() { val b = emf(intArrayOf(0, 0, 99, 99), rec(59), rec(27, 0, 0), rec(54, 9, 9), rec(68), rec(43, 0, 0, 5, 5)); assertEquals(1, Metafile.parse(b)!!.ops.size) }
    @Test fun arcToBuildsCurve() {
        val b = emf(intArrayOf(0, 0, 99, 99), rec(27, 100, 50), rec(55, 0, 0, 100, 100, 100, 50, 50, 100))
        val c = poly(Metafile.parse(b)!!).subs[0].pts; assertTrue(c.size > 20)
    }
    @Test fun textRecord() {
        val s = "Merhaba İ"; val u = s.toByteArray(Charsets.UTF_16LE)
        val font = W().i(1).i(-20).i(0).i(0).i(0).i(700).b(byteArrayOf(1, 0, 0, 0)).b(ByteArray(100)).bytes()   // ihFont, lfHeight=-20, weight=700, italic=1
        val body = W().i(0).i(0).i(0).i(0).i(1).i(0x3F800000).i(0x3F800000).i(15).i(25).i(s.length).i(76).i(0).i(0).i(0).i(0).i(0).i(0).b(u).bytes()
        val m = Metafile.parse(emf(intArrayOf(0, 0, 99, 99), rec(24, 0x0000FF), rec(22, 24), recBytes(82, font), rec(37, 1), recBytes(84, body)))!!
        val t = m.ops.filterIsInstance<Metafile.Text>().single()
        assertEquals(s, t.s); assertEquals(15.0, t.x, 1e-9); assertEquals(25.0, t.y, 1e-9); assertEquals(20.0, t.size, 1e-9); assertTrue(t.bold); assertTrue(t.italic); assertEquals(0xFFFF0000.toInt(), t.color); assertEquals(24, t.align)
    }

    // ---- DIB
    private fun dibHeader(w: Int, h: Int, bpp: Int, clr: Int = 0, comp: Int = 0) = W().i(40).i(w).i(h).s(1).s(bpp).i(comp).i(0).i(0).i(0).i(clr).i(0)
    @Test fun dib24BottomUp() {
        val raw = dibHeader(2, 2, 24).also { w -> // alt satır önce: (0,1)=kırmızı (1,1)=yeşil ; (0,0)=mavi (1,0)=beyaz  (BGR)
            w.b(byteArrayOf(0, 0, 255.toByte(), 0, 255.toByte(), 0, 0, 0)); w.b(byteArrayOf(255.toByte(), 0, 0, 255.toByte(), 255.toByte(), 255.toByte(), 0, 0)) }.bytes()
        val d = Metafile.dib(raw, 0, raw.size, 0, 0)!!
        assertEquals(listOf(0xFF0000FF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt(), 0xFF00FF00.toInt()), d.argb.toList())
    }
    @Test fun dib24TopDown() {
        val raw = dibHeader(1, -2, 24).also { w -> w.b(byteArrayOf(0, 0, 255.toByte(), 0)); w.b(byteArrayOf(255.toByte(), 0, 0, 0)) }.bytes()
        assertEquals(listOf(0xFFFF0000.toInt(), 0xFF0000FF.toInt()), Metafile.dib(raw, 0, raw.size, 0, 0)!!.argb.toList())
    }
    @Test fun dib8Palette() {
        val raw = dibHeader(2, 1, 8, 2).b(byteArrayOf(0, 0, 255.toByte(), 0, 0, 255.toByte(), 0, 0)).b(byteArrayOf(0, 1, 0, 0)).bytes()
        assertEquals(listOf(0xFFFF0000.toInt(), 0xFF00FF00.toInt()), Metafile.dib(raw, 0, raw.size, 0, 0)!!.argb.toList())
    }
    @Test fun dib4and1() {
        val r4 = dibHeader(2, 1, 4, 2).b(byteArrayOf(0, 0, 0, 0, 255.toByte(), 255.toByte(), 255.toByte(), 0)).b(byteArrayOf(0x01, 0, 0, 0)).bytes()
        assertEquals(listOf(0xFF000000.toInt(), 0xFFFFFFFF.toInt()), Metafile.dib(r4, 0, r4.size, 0, 0)!!.argb.toList())
        val r1 = dibHeader(8, 1, 1, 2).b(byteArrayOf(0, 0, 0, 0, 255.toByte(), 255.toByte(), 255.toByte(), 0)).b(byteArrayOf(0xA5.toByte(), 0, 0, 0)).bytes()
        assertEquals(listOf(1, 0, 1, 0, 0, 1, 0, 1), Metafile.dib(r1, 0, r1.size, 0, 0)!!.argb.map { if (it == 0xFFFFFFFF.toInt()) 1 else 0 })
    }
    @Test fun dib32OpaqueWhenAlphaZero() { val raw = dibHeader(1, 1, 32).b(byteArrayOf(1, 2, 3, 0)).bytes(); assertEquals(0xFF030201.toInt(), Metafile.dib(raw, 0, raw.size, 0, 0)!!.argb[0]); val raw2 = dibHeader(1, 1, 32).b(byteArrayOf(1, 2, 3, 0x80.toByte())).bytes(); assertEquals(0x80030201.toInt(), Metafile.dib(raw2, 0, raw2.size, 0, 0)!!.argb[0]) }
    @Test fun dibRejectsBadInput() { assertNull(Metafile.dib(ByteArray(10), 0, 10, 0, 0)); assertNull(Metafile.dib(dibHeader(1, 1, 24, 0, 1).bytes(), 0, 40, 0, 0)); assertNull(Metafile.dib(dibHeader(0, 5, 24).bytes(), 0, 40, 0, 0)); assertNull(Metafile.dib(dibHeader(100000, 100000, 24).bytes(), 0, 40, 0, 0)); assertNull(Metafile.dib(dibHeader(1, 1, 3).bytes(), 0, 40, 0, 0)) }
    @Test fun stretchDibitsRecord() {
        val dibB = dibHeader(2, 1, 24).b(byteArrayOf(0, 0, 255.toByte(), 255.toByte(), 255.toByte(), 255.toByte(), 0, 0)).bytes()
        val body = W().i(0).i(0).i(0).i(0).i(10).i(20).i(0).i(0).i(2).i(1).i(80).i(40).i(160).i(40).i(0).i(0xCC0020).i(60).i(30).b(dibB.copyOfRange(0, 40)).b(dibB.copyOfRange(40, dibB.size)).bytes()
        // offBmiSrc = 80 (kayıt başından), offBitsSrc = 80+40
        val m = Metafile.parse(emf(intArrayOf(0, 0, 199, 199), recBytes(81, body)))!!
        val bm = m.ops.filterIsInstance<Metafile.Bmp>().single(); assertEquals(2, bm.pw); assertEquals(1, bm.ph); assertEquals(10.0, bm.x, 1e-9); assertEquals(20.0, bm.y, 1e-9); assertEquals(60.0, bm.w, 1e-9); assertEquals(30.0, bm.h, 1e-9)
        assertEquals(0xFFFF0000.toInt(), bm.argb[0])
    }

    // ---- WMF
    private fun wrec(fn: Int, vararg p: Int): ByteArray { val w = W().i(3 + p.size).s(fn); p.forEach { w.s(it) }; return w.bytes() }
    private fun wmf(placeable: IntArray?, vararg recs: ByteArray): ByteArray {
        val w = W()
        if (placeable != null) { w.i(0x9AC6CDD7.toInt()).s(0).s(placeable[0]).s(placeable[1]).s(placeable[2]).s(placeable[3]).s(1440).i(0).s(0) }
        w.s(1).s(9).s(0x300).i(0).s(0).i(0).s(0)
        for (r in recs) w.b(r); w.b(wrec(0)); return w.bytes()
    }
    @Test fun wmfPolygonWithWindowMapping() {
        val b = wmf(intArrayOf(0, 0, 200, 200), wrec(0x020C, 100, 100), wrec(0x020B, 0, 0), wrec(0x0324, 3, 10, 10, 50, 10, 50, 40))
        val m = Metafile.parse(b)!!; val p = poly(m)
        assertEquals(listOf(10.0, 10.0, 50.0, 10.0, 50.0, 40.0), p.subs[0].pts.toList()); assertTrue(p.subs[0].closed); assertEquals(100.0, m.w, 3.0)
    }
    @Test fun wmfRectangleOrder() { val b = wmf(null, wrec(0x020C, 100, 100), wrec(0x020B, 0, 0), wrec(0x041B, 70, 60, 20, 10)); assertEquals(listOf(10.0, 20.0, 60.0, 20.0, 60.0, 70.0, 10.0, 70.0), poly(Metafile.parse(b)!!).subs[0].pts.toList()) }
    @Test fun wmfLineToMoveToOrder() { val b = wmf(null, wrec(0x020C, 100, 100), wrec(0x020B, 0, 0), wrec(0x0214, 6, 5), wrec(0x0213, 30, 20)); assertEquals(listOf(5.0, 6.0, 20.0, 30.0), poly(Metafile.parse(b)!!).subs[0].pts.toList()) }
    @Test fun wmfNegativeExtentFlipsAxis() { val b = wmf(null, wrec(0x020C, -100, 100), wrec(0x020B, 100, 0), wrec(0x0325, 2, 10, 90, 10, 10)); val m = Metafile.parse(b)!!; assertEquals(listOf(10.0, 10.0, 10.0, 90.0), poly(m).subs[0].pts.toList()); assertTrue(m.h > 0 && m.w > 0) }
    @Test fun wmfPenBrushSelect() {
        val b = wmf(null, wrec(0x020C, 100, 100), wrec(0x020B, 0, 0), W().i(5 + 2).s(0x02FC).s(0).i(0x0000FF).s(0).bytes(), wrec(0x012D, 0), wrec(0x041B, 9, 9, 1, 1))
        assertEquals(0xFFFF0000.toInt(), poly(Metafile.parse(b)!!).fill)
    }
    @Test fun wmfTextOut() {
        val s = "Merhaba"; val sb = s.toByteArray()
        val body = W().s(s.length).b(sb).b(ByteArray(1)).s(40).s(30).bytes()
        val rec = W().i(3 + body.size / 2).s(0x0521).b(body).bytes()
        val m = Metafile.parse(wmf(null, wrec(0x020C, 100, 100), wrec(0x020B, 0, 0), rec))!!
        val t = m.ops.filterIsInstance<Metafile.Text>().single(); assertEquals(s, t.s); assertEquals(30.0, t.x, 1e-9); assertEquals(40.0, t.y, 1e-9)
    }
    @Test fun wmfExtTextOut() {
        val s = "Atlas"; val sb = s.toByteArray()
        val body = W().s(50).s(20).s(s.length).s(0).b(sb).b(ByteArray(1)).bytes()
        val rec = W().i(3 + body.size / 2).s(0x0A32).b(body).bytes()
        val t = Metafile.parse(wmf(null, wrec(0x020C, 100, 100), wrec(0x020B, 0, 0), rec))!!.ops.filterIsInstance<Metafile.Text>().single()
        assertEquals(s, t.s); assertEquals(20.0, t.x, 1e-9); assertEquals(50.0, t.y, 1e-9)
    }
    @Test fun wmfHeaderRejects() { assertNull(Metafile.parse(wmf(null))); assertFalse(Metafile.isWmf(ByteArray(18))) }

    // ---- DocVisual yardımcıları
    @Test fun imageKinds() {
        for (n in listOf("a.png", "a.JPG", "a.webp", "a.heic")) assertEquals(n, "bitmap", DocVisual.imageKind(n))
        assertEquals("tiff", DocVisual.imageKind("x.TIF")); assertEquals("tiff", DocVisual.imageKind("x.tiff")); assertEquals("meta", DocVisual.imageKind("x.emf")); assertEquals("meta", DocVisual.imageKind("x.WMF")); assertEquals("svg", DocVisual.imageKind("x.svg")); assertEquals("svg", DocVisual.imageKind("x.svgz")); assertEquals("none", DocVisual.imageKind("x.bin")); assertEquals("none", DocVisual.imageKind("noext"))
    }
    @Test fun everyImageNameIsDecodable() { for (n in listOf("a.png", "a.tif", "a.emf", "a.wmf", "a.svg")) { assertTrue(DocVisual.isImageName(n)); assertTrue(DocVisual.isDecodable(n)) }; assertFalse(DocVisual.isDecodable("a.xml")) }
    @Test fun svgFixtureHasContent() { val s = String(fx("s.svg")); assertTrue(s.contains("<svg") && s.contains("Merhaba")) }

    // ---- kaynak denetimleri
    private fun code(p: String) = File(TestFiles.code, "com/odak/app/$p").readText()
    @Test fun decoderRoutesAllKinds() { val s = code("docs/DocVisualUi.kt"); assertTrue(s.contains("TiffDecoder.decode")); assertTrue(s.contains("Metafile.parse")); assertTrue(s.contains("SvgRender.render")); assertTrue(s.contains("MetaRender.render")) }
    @Test fun svgSizeCappedAndDependencyDeclared() { assertTrue(code("docs/DocVisualUi.kt").contains("8 * 1024 * 1024")); val g = listOf(File("build.gradle.kts"), File("app/build.gradle.kts")).first { it.exists() }; assertTrue(g.readText().contains("com.caverock:androidsvg-aar")) }
}
