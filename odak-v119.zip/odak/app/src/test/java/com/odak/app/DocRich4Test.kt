package com.odak.app

import com.odak.app.docs.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Base64
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** v0.56.42: PowerPoint slayt biçimi, metin kutuları (DOCX/ODT), yazı tipi aileleri. */
class DocRich4Test {
    private val PNG = Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
    private fun zipB(vararg e: Pair<String, ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bo.toByteArray()
    }
    private fun s(x: String) = x.toByteArray()
    private fun paras(bl: List<RBlock>) = bl.filterIsInstance<RPara>()
    private fun allParas(bl: List<RBlock>): List<RPara> = bl.flatMap { b -> when (b) { is RPara -> listOf(b); is RTable -> b.rows.flatten().flatMap { it.paras }; is RBox -> allParas(b.blocks) } }

    private val NS = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\""
    private fun pptx(): ByteArray {
        val slide = "<p:sld $NS><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val=\"102030\"/></a:solidFill></p:bgPr></p:bg><p:spTree>" +
            // gövde şekli önce yazılmış ama aşağıda; başlık yukarıda -> konuma göre sıralanmalı
            "<p:sp><p:nvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"500000\" y=\"2000000\"/><a:ext cx=\"5000000\" cy=\"1000000\"/></a:xfrm><a:solidFill><a:srgbClr val=\"FFEE99\"/></a:solidFill></p:spPr>" +
            "<p:txBody><a:p><a:pPr marL=\"342900\" indent=\"-342900\"><a:buChar char=\"•\"/></a:pPr><a:r><a:rPr sz=\"2000\" i=\"1\"/><a:t>Madde bir</a:t></a:r></a:p><a:p><a:pPr><a:buAutoNum type=\"arabicPeriod\"/></a:pPr><a:r><a:rPr/><a:t>Sayılı</a:t></a:r></a:p></p:txBody></p:sp>" +
            "<p:sp><p:nvSpPr><p:nvPr><p:ph type=\"title\"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"500000\" y=\"300000\"/><a:ext cx=\"5000000\" cy=\"800000\"/></a:xfrm></p:spPr>" +
            "<p:txBody><a:p><a:pPr algn=\"ctr\"/><a:r><a:rPr sz=\"3200\" b=\"1\"><a:solidFill><a:srgbClr val=\"FF0000\"/></a:solidFill><a:latin typeface=\"Georgia\"/></a:rPr><a:t>Başlık</a:t></a:r></a:p></p:txBody></p:sp>" +
            "<p:pic><p:nvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed=\"rId2\"/></p:blipFill><p:spPr><a:xfrm><a:off x=\"500000\" y=\"3500000\"/><a:ext cx=\"1270000\" cy=\"635000\"/></a:xfrm></p:spPr></p:pic>" +
            "<p:graphicFrame><p:xfrm><a:off x=\"500000\" y=\"4500000\"/></p:xfrm><a:graphic><a:graphicData><a:tbl><a:tblGrid><a:gridCol w=\"1270000\"/><a:gridCol w=\"1270000\"/></a:tblGrid>" +
            "<a:tr><a:tc><a:txBody><a:p><a:r><a:rPr b=\"1\"/><a:t>H1</a:t></a:r></a:p></a:txBody><a:tcPr><a:solidFill><a:srgbClr val=\"336699\"/></a:solidFill></a:tcPr></a:tc><a:tc><a:txBody><a:p><a:r><a:t>H2</a:t></a:r></a:p></a:txBody></a:tc></a:tr>" +
            "<a:tr><a:tc gridSpan=\"2\"><a:txBody><a:p><a:r><a:t>birleşik</a:t></a:r></a:p></a:txBody></a:tc><a:tc hMerge=\"1\"><a:txBody><a:p><a:endParaRPr/></a:p></a:txBody></a:tc></a:tr>" +
            "</a:tbl></a:graphicData></a:graphic></p:graphicFrame>" +
            "</p:spTree></p:cSld></p:sld>"
        return zipB(
            "ppt/presentation.xml" to s("<p:presentation $NS><p:sldSz cx=\"12192000\" cy=\"6858000\"/></p:presentation>"),
            "ppt/slides/slide1.xml" to s(slide),
            "ppt/slides/_rels/slide1.xml.rels" to s("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId2\" Type=\"x/image\" Target=\"../media/image1.png\"/></Relationships>"),
            "ppt/media/image1.png" to PNG,
            "ppt/theme/theme1.xml" to s("<a:theme $NS><a:themeElements><a:clrScheme><a:dk1><a:sysClr val=\"windowText\" lastClr=\"000000\"/></a:dk1></a:clrScheme></a:themeElements></a:theme>"))
    }

    @Test fun pptxSlideFormat() {
        val d = DocParse.parse("a.pptx", pptx())
        assertEquals(DocKind.PPTX, d.kind)
        val rp = d.pages[0].rich
        assertNotNull(rp)
        assertEquals("102030", rp!!.bg)
        assertEquals(19200, rp.setup.w); assertEquals(10800, rp.setup.h)
        val ps = allParas(Rich.flat(rp).blocks)
        // başlık, konumu yukarıda olduğu için gövdeden önce gelir
        val ti = ps.indexOfFirst { it.plain == "Başlık" }; val bi = ps.indexOfFirst { it.plain == "Madde bir" }
        assertTrue(ti in 0 until bi)
        val t = ps[ti]; assertEquals("center", t.align); assertEquals(1, t.head)
        val r = t.runs[0]; assertTrue(r.b); assertEquals("FF0000", r.color); assertEquals(64, r.sz); assertEquals("Georgia", r.font)
        val b1 = ps[bi]; assertEquals("•", b1.marker); assertTrue(b1.runs[0].i); assertEquals(40, b1.runs[0].sz)
        assertTrue(rp.blocks.any { it is RBox && it.fill == "FFEE99" && it.blocks.any { p -> (p as RPara).plain == "Madde bir" } })
        assertEquals("1.", ps.first { it.plain == "Sayılı" }.marker)
    }
    private fun tb0(rp: RichPage) = Rich.flat(rp).blocks.filterIsInstance<RTable>().single()
    @Test fun pptxImageAndTable() {
        val rp = DocParse.parse("a.pptx", pptx()).pages[0].rich!!
        assertEquals(1, allParas(rp.blocks).sumOf { p -> p.runs.count { it.img != null } })
        assertEquals(2, tb0(rp).rows.size)
        val img = allParas(rp.blocks).flatMap { it.runs }.first { it.img != null }.img!!
        assertEquals(2000, img.w); assertEquals(1000, img.h)
        val tb = Rich.flat(rp).blocks.filterIsInstance<RTable>().single()
        assertEquals("336699", tb.rows[0][0].fill); assertTrue(tb.rows[0][0].paras[0].runs[0].b)
        assertEquals(2, tb.rows[1][0].span); assertEquals("row1=" + tb.rows[1].map { it.span + 100 * it.paras.size }, 1, tb.rows[1].size)
    }
    @Test fun pptxConvertsKeepingFormat() {
        val d = DocParse.parse("a.pptx", pptx())
        val html = String(DocWrite.write(d, ConvTarget.HTML, "a")!!)
        assertTrue(html.contains("background:#102030") && html.contains("FF0000") && html.contains("data:image/png"))
        val docx = DocParse.parse("o.docx", DocWrite.write(d, ConvTarget.DOCX, "a")!!)
        assertTrue(allParas(docx.pages[0].rich!!.blocks).any { it.plain == "Başlık" && it.runs[0].b })
        assertTrue(DocWrite.write(d, ConvTarget.PDF, "a") == null || true)
    }
    @Test fun pptxBadSlideFallsBackToText() {
        val z = zipB("ppt/slides/slide1.xml" to s("<p:sld xmlns:a=\"x\"><a:t>düz metin</a:t></p:sld>"))
        val d = DocParse.parse("b.pptx", z)
        assertEquals(1, d.pages.size)
    }

    // ---- metin kutuları ----
    private val W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" xmlns:wps=\"x\" xmlns:v=\"y\""
    @Test fun docxTextBox() {
        val body = "<w:p><w:r><w:t>Ana metin</w:t></w:r><w:r><mc:AlternateContent><mc:Choice><w:drawing><wps:txbx><w:txbxContent><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>KUTU METNİ</w:t></w:r></w:p></w:txbxContent></wps:txbx></w:drawing></mc:Choice>" +
            "<mc:Fallback><w:pict><v:textbox><w:txbxContent><w:p><w:r><w:t>KUTU METNİ</w:t></w:r></w:p></w:txbxContent></v:textbox></w:pict></mc:Fallback></mc:AlternateContent></w:r></w:p><w:p><w:r><w:t>Sonraki</w:t></w:r></w:p>"
        val d = DocParse.parse("t.docx", zipB("word/document.xml" to s("<w:document $W><w:body>$body</w:body></w:document>")))
        val rp = d.pages[0].rich!!
        val all = allParas(rp.blocks)
        assertEquals(1, all.count { it.plain == "KUTU METNİ" })           // Fallback kopyası eklenmez
        assertTrue(all.first { it.plain == "KUTU METNİ" }.runs[0].b)
        val order = all.map { it.plain }.filter { it.isNotEmpty() }
        assertEquals(listOf("Ana metin", "KUTU METNİ", "Sonraki"), order)
        assertTrue(rp.blocks.any { it is RTable })                          // çerçeveli kutu
    }
    @Test fun docxTextBoxSplitHelper() {
        val x = "<a><w:txbxContent>1<w:txbxContent>iç</w:txbxContent>2</w:txbxContent><mc:Fallback><w:txbxContent>f</w:txbxContent></mc:Fallback><w:txbxContent>3</w:txbxContent></a>"
        assertEquals(listOf("1<w:txbxContent>iç</w:txbxContent>2", "3"), RichDocx.textBoxes(x))
    }
    @Test fun odtTextBox() {
        val c = "<office:document-content xmlns:office=\"o\" xmlns:text=\"t\" xmlns:draw=\"d\" xmlns:svg=\"s\"><office:body><office:text>" +
            "<text:p>Ana<draw:frame svg:width=\"5cm\" svg:height=\"2cm\"><draw:text-box><text:p>KUTU</text:p></draw:text-box></draw:frame></text:p><text:p>Sonra</text:p></office:text></office:body></office:document-content>"
        val rp = RichOdt.parse(s(c), null)
        val all = allParas(rp.blocks).map { it.plain }.filter { it.isNotEmpty() }
        assertEquals(listOf("Ana", "KUTU", "Sonra"), all)
        assertTrue(rp.blocks.any { it is RTable })
    }

    // ---- yazı tipi aileleri ----
    @Test fun fontFamilies() {
        val m = mapOf("Arial" to "sans-serif", "Calibri" to "sans-serif", "Times New Roman" to "serif", "Georgia" to "serif", "Courier New" to "serif-monospace",
            "Consolas" to "monospace", "Arial Narrow" to "sans-serif-condensed", "Impact" to "sans-serif-black", "Segoe UI Light" to "sans-serif-light",
            "Comic Sans MS" to "casual", "Brush Script MT" to "cursive", "Lucida Sans" to "sans-serif", "Segoe UI Semibold" to "sans-serif-medium", "Noto Sans Mono" to "monospace")
        for ((k, v) in m) assertEquals(k, v, FontMap.family(k))
        assertEquals("sans-serif", FontMap.family(null)); assertEquals("sans-serif", FontMap.family("Bilinmeyen"))
        assertTrue(listOf("Arial", "Georgia", "Consolas", "Impact", "Comic Sans", "Brush Script", "Arial Narrow", "Courier New").map { FontMap.family(it) }.toSet().size >= 7)
        assertTrue(FontMap.FAMILIES.containsAll(m.values.toSet()))
    }

    @Test fun sourceChecks() {
        val r = File(TestFiles.code, "com/odak/app/docs/DocPdfRich.kt").readText()
        assertTrue(r.contains("FontMap.family") && r.contains("rp.bg") && !r.contains("Typeface.SERIF"))
        assertTrue(File(TestFiles.code, "com/odak/app/docs/Rich.kt").readText().contains("rp.bg"))
    }
}

class EpubCssTest {
    private fun zipS(vararg e: Pair<String, String>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> for ((n, b) in e) { z.putNextEntry(ZipEntry(n)); z.write(b.toByteArray()); z.closeEntry() } }
        return bo.toByteArray()
    }
    private fun paras(bl: List<RBlock>) = bl.filterIsInstance<RPara>()

    @Test fun cssClassesApply() {
        val b = HtmlRich.parse("<p class=\"note\">Not</p><p>Düz</p><p><span class=\"b\">kalın</span> x</p><div class=\"hide\">GİZLİ<p>iç gizli</p></div><p id=\"x\">kimlik</p>",
            css = "/* yorum */ p.note{font-style:italic;color:#ff0000;text-align:center} .b{font-weight:bold} .hide{display:none} p{text-indent:1em;margin-bottom:6pt} #x{color:#00ff00} @media print{p{color:red}} div p{color:blue}")
        val ps = paras(b)
        assertEquals(listOf("Not", "Düz", "kalın x", "kimlik"), ps.map { it.plain })
        assertTrue(ps[0].runs[0].i); assertEquals("FF0000", ps[0].runs[0].color); assertEquals("center", ps[0].align)
        assertEquals(220, ps[1].first); assertEquals(120, ps[1].after)
        assertTrue(ps[2].runs[0].b); assertEquals("00FF00", ps[3].runs[0].color)
    }
    @Test fun cssParserSkipsComplexSelectors() {
        val c = HtmlRich.Css("a b{color:red} p > i{color:red} p:first-child{color:red} .x{font-weight:bold} h1,h2{color:#112233}")
        assertEquals(6, c.rules.size)
        assertTrue(c.styleFor("h2", null, null).contains("112233")); assertTrue(c.styleFor("p", "x y", null).contains("bold"))
    }
    @Test fun epubLinkedStylesheetAndStyleBlock() {
        val e = zipS(
            "mimetype" to "application/epub+zip",
            "META-INF/container.xml" to "<container><rootfiles><rootfile full-path=\"OEBPS/c.opf\"/></rootfiles></container>",
            "OEBPS/c.opf" to "<package><manifest><item id=\"c1\" href=\"ch1.xhtml\"/></manifest><spine><itemref idref=\"c1\"/></spine></package>",
            "OEBPS/css/main.css" to ".k{font-weight:bold;color:#0000ff} .i{font-style:italic}",
            "OEBPS/ch1.xhtml" to "<html><head><link rel=\"stylesheet\" href=\"css/main.css\"/><style>.s{text-decoration:underline}</style></head><body><p><span class=\"k\">kalın</span> <span class=\"i\">eğik</span> <span class=\"s\">alt</span></p></body></html>")
        val d = DocParse.parse("k.epub", e)
        val r = paras(d.pages[0].rich!!.blocks)[0].runs
        assertTrue(r.any { it.text == "kalın" && it.b && it.color == "0000FF" }); assertTrue(r.any { it.text.trim() == "eğik" && it.i }); assertTrue(r.any { it.text.trim() == "alt" && it.u })
    }
}
