# Odak — 80 özellik yol haritası
✅ = uygulamada var · ✅ = sırada

## Planlama (1–14)
1 ✅ Gün/hafta/ay planı · 2 ✅ İsteğe bağlı saat · 3 ✅ Saatinde bildirim · 4 ✅ Telefon açılınca hatırlatıcıları yeniden kurma · 5 ✅ Plana süre seçme · 6 ✅ Tekrarlayan plan (her gün/hafta) · 7 ✅ Plan düzenleme (plana dokun) · 8 ✅ Plana renk/etiket · 9 ✅ Hatırlatmayı X dk önceye alma · 10 ✅ Görevi yarına ertele · 11 ✅ Görev arama (6+ görevde) · 12 ✅ Plan şablonları · 13 ✅ Gün sonu özeti · 14 ✅ Plan notu

## Yapılacaklar (15–24)
15 ✅ Görev ekle/sil/işaretle · 16 ✅ Öncelik (!, !!, !!!) · 17 ✅ Tamamlananları temizle · 18 ✅ İlerleme sayacı · 19 ✅ Son tarih · 20 ✅ Alt görevler · 21 ✅ Görevi plana çevir · 22 ✅ Sürükleyerek sırala · 23 ✅ Kategori/liste · 24 ✅ Geri al (silme)

## Ekran süresi (25–36)
25 ✅ Uygulama başına bugünkü süre · 26 ✅ Toplam süre · 27 ✅ 7 günlük grafik · 28 ✅ Açılma sayısı · 29 ✅ Gece/gündüz dağılımı · 30 ✅ Haftalık rapor bildirimi · 31 ✅ Hedef süre (günlük toplam) · 32 ✅ Kategori toplamları · 33 ✅ Geçen haftayla karşılaştırma · 34 ✅ En çok kullanılan saat · 35 ✅ Süre serisi (kaç gündür hedefte) · 36 ✅ Dışa aktar (CSV)

## Engelleme (37–56)
37 ✅ Uygulamayı tamamen engelle · 38 ✅ Shorts/Reels/Hikaye/DM tek tek engel · 39 ✅ Günlük süre sınırı (uygulama) · 40 ✅ Günlük süre sınırı (özellik) · 41 ✅ Engel ekranı · 42 ✅ Saat aralığı (22:00–07:00) · 43 ✅ Hafta günü seçimi · 44 ✅ PIN ile ayar kilidi · 45 ✅ "5 dk daha" butonu (günde 3) · 46 ✅ Motivasyon cümleleri · 47 ✅ Odak modu (hepsini aynı anda kapat) · 48 ✅ Pomodoro sayacı · 49 ✅ Engel kurallarını dosyadan güncelleme · 50 ✅ Ekran kimliği kaydı (kural bulmak için) · 51 ✅ Daha çok uygulama (Telegram, WhatsApp, Pinterest, Twitch, Discord, LinkedIn, Netflix) · 52 ✅ Kendi uygulamanı listeye ekle · 53 ✅ Engeli kapatmadan 10 sn bekleme · 54 ✅ Süre dolmadan uyarı (%80) · 55 ✅ Engeli geçici kaldır (kilit açma sorusu) · 56 ✅ Bildirimleri engelli uygulamadan gizle

## Tasarım ve ses (57–66)
57 ✅ 5 tasarım dili · 58 ✅ Tasarıma özel sesler · 59 ✅ Tasarıma özel başlık ve gezinme · 60 ✅ Tasarım renklerini değiştirme (ana + vurgu) · 61 ✅ Koyu/açık mod · 62 ✅ Yazı boyutu · 63 ✅ Ses açma/kapama · 64 ✅ Titreşim açma/kapama · 65 ✅ Yeni tasarım ekleme · 66 ✅ Ana ekran widget'ı

## Genel (67–80)
67 ✅ 8 dil · 68 ✅ Android 13+ · 69 ✅ Dil seçici (telefondan bağımsız) · 70 ✅ Yedekleme (dosyaya) · 71 ✅ Yedekten geri yükleme · 72 ✅ İlk açılış rehberi · 73 ✅ İzin durumu sayfası · 74 ✅ Pil optimizasyonu uyarısı · 75 ✅ Günlük hedef ve seri · 76 ✅ Rozetler · 77 ✅ Günün sözü · 78 ✅ Sabah özeti bildirimi · 79 ✅ Akşam değerlendirmesi · 80 ✅ Kişisel istatistik kartı
