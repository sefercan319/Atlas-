
## v0.43 — Otomatik arayüz ölçeği
- PureLogicTest.autoScaleGrowsWithScreen / effectiveScaleManualOverridesAndClamps
- ManifestTest.mainActivityHandlesDensityChangeWithoutRecreate

## v0.56.56 — Stil başına boyama profili
- RecolorProfileTest: 17 stil × 3 parça × 6 hedef (siyah, koyu lacivert, mor, sarı, açık gri, beyaz) — desen aralığının ≥%80'i korunur; Aero düğmesinde beyaz parlama boyanmadan kalır; mat stillerde (Clay, Minimal) parlama katmanı yok.
- ColorSlotTest güncellendi (türetimli düğme stilleri, kenar hedef toleransı).
- Doğrulanmadı: telefonda gerçek görünüm (yalnız JVM mantığı + PIL önizleme).

## v0.56.57 — Günlük açma sınırı (Engelleme)
- OpenLimitTest: 30 sn aralık kuralı, sayaç limit+1'de durur, tam `limit` kez açmaya izin, servis/arayüz bağlantısı, 9 dilde metinler.
- Doğrulanmadı: telefonda gerçek davranış (yalnız JVM mantığı + sözdizimi).

## v0.56.58 — Hata düzeltme
- BlockActivity: yeni engel gelince açık kalan çarpma sorusu/"yanlış" mesajı sıfırlanır (BlockScreenResetTest).

## v0.56.59 — Engelleme iyileştirmeleri
- Açma sınırı dolunca engel ekranı kendi başlığını gösterir ("Açma sınırı doldu"); uygulama başlığında bugünkü açılış sayısı (örn. "12m · 3×") görünür. OpenLimitScreenTest.

## v0.56.60 — GitHub Actions derleme hatası
- EmojiText.kt: InlineTextContent/appendInlineContent `foundation.text` paketinden; material3 Text çağrıları adlandırılmış argümanla (yeni sürümde araya `autoSize` girmişti); AnnotatedString sürümünde onTextLayout boş lambda ile. EmojiTextApiTest.

## v0.56.61 — Gün değişimi, logo, sabit imza, +700 uygulama, sıralama
- AppListTest: ek katalogdan ≥600 yeni uygulama (tekrarsız), paket adı biçimi, A–Z / Z–A / kullanım sıralaması (Türkçe harfler, eşitlikte ada göre), arayüz ve 9 dil bağlantısı.
- DayChangeTest: ekran süresi gün değişince "bugün"ü izler; manifestte uygulama simgesi; sabit imza anahtarı (build.gradle.kts + atlas-release.jks).
- Doğrulanmadı: paket adlarının Play Store'da varlığı (elle derlendi, ağ erişimi yok); telefonda gerçek davranış; yeni imzayla ilk kurulumda eski APK silinmeli.

## v0.56.62 — Engelleme ekranı sadeleştirme
- Uygulama satırı: ad + özet rozetleri + tek onay kutusu; Sınırlar / Özellikler / Sessiz saat ayrıntı penceresine ("⋯") taşındı. BlockWindowTest (rozet özeti, satırda ayrıntı yok, 9 dilde bölüm başlıkları).
- Doğrulanmadı: pencerenin telefonda görünümü (yalnız sözdizimi).

## v0.56.63 — Ayarlar sadeleştirme
- Görünüm: stil listesinde önizleme yalnız seçili stilde; Renkler ve Koyu/Açık mod ayrı alt sekmede; her renk satırı sade (ad + renk dairesi), palet dokununca pencerede açılır; sıfırlama pencerede. SettingsSimplifyTest.

## v0.56.64 — Diğer ekranlar pencereli
- Yapılacaklar: araçlar (🧰), ek seçenekler (⋯), filtre/sıralama (⇅) satır içi açılma yerine pencerede.
- Ekran süresi: özet kartında yalnız toplam + dünle fark; ayrıntılar (ⓘ) ve uygulama haftalık grafiği pencerede. OtherWindowsTest.

## v0.56.65 — Plan ve Program pencereli
- Plan ekleme satırı: başlık + ⋯ + Ekle; saat/süre/tekrar ve araçlar (şablon, günü kopyala, ara) ⋯ penceresinde. Program düzenleyici tam ekran yerine pencere. PlanScheduleWindowTest.
