package com.odak.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v0.56.29: Yapılacaklar ekranı sadeleştirildi; seçenekler açılır gruplarda. */
class TodoLayoutTest {
    private val src: String get() = File(TestFiles.code, "com/odak/app/todo/TodoScreen.kt").readText()
    private fun between(a: String, b: String): String { val s = src; val i = s.indexOf(a); return s.substring(i, s.indexOf(b, i)) }

    @Test fun threeWindowGroupsStartClosed() {
        for (n in listOf("showTools", "showNew", "showList")) assertTrue(n, src.contains("var $n by remember { mutableStateOf(false) }"))
    }
    @Test fun toolCardsOnlyInsideToolsGroup() {
        val s = src
        val g = between("if (showTools) androidx.compose.material3.AlertDialog(", "Spacer(Modifier.height(10.dp))\n            if (all.size > 5)")
        for (c in listOf("PomodoroCard()", "HabitCard()", "WaterCard()")) { assertEquals(c, 1, Regex(Regex.escape(c)).findAll(s).count()); assertTrue(c, g.contains(c)) }
    }
    @Test fun addRowKeepsOnlyFieldToggleAndPlus() {
        val row = between("ThemedTextField(\n                    value = title", "lastDeleted?.let")
        assertEquals(2, Regex("ThemedButton\\(").findAll(row).count())
    }
    @Test fun newItemOptionsInsideShowNew() {
        val g = between("if (showNew) androidx.compose.material3.AlertDialog(", "if (overdueN > 0)")
        for (c in listOf("PrioMarks[prio]", "dueMode", "Cats[cat]", "rep = !rep")) assertTrue(c, g.contains(c))
    }
    @Test fun listOptionsInsideShowList() {
        val g = between("if (showList) androidx.compose.material3.AlertDialog(", "if (all.isEmpty()) {")
        for (c in listOf("filterCat = -1", "todo_manual", "todo_sort")) assertTrue(c, g.contains(c))
    }
}
