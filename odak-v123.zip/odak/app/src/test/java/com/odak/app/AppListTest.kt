package com.odak.app

import com.odak.app.logic.AppList
import com.odak.app.logic.MoreAppsData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AppListTest {
    private val raw = java.io.File(TestFiles.code, "com/odak/app/block/BlockData.kt").readText()
    private val old = Regex("\"([A-Za-z0-9_]+\\.[A-Za-z0-9_.]+)\"").findAll(raw).map { it.groupValues[1] }.toSet()

    @Test fun parseSkipsBadLines() {
        val r = AppList.parse(listOf("A B|com.a.b", "bozuk", "|x.y", "Adı|", "  Ad  | pkg.x "))
        assertEquals(listOf("A B" to "com.a.b", "Ad" to "pkg.x"), r.map { it.name to it.pkg })
    }
    @Test fun atLeast600NewAppsAfterDedupe() {
        val e = AppList.parse(MoreAppsData.ALL)
        val fresh = e.filter { it.pkg !in old }.map { it.pkg }.toSet()
        assertTrue("yeni uygulama ${fresh.size}", fresh.size >= 600)
    }
    @Test fun packagesLookValid() {
        for (e in AppList.parse(MoreAppsData.ALL)) {
            assertTrue(e.pkg, Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+").matches(e.pkg))
            assertTrue(e.name, e.name.length in 1..40)
        }
    }
    @Test fun sortAzZaUsage() {
        val l = listOf("Çay" to 5L, "Ay" to 50L, "Zeytin" to 1L)
        assertEquals(listOf("Ay", "Çay", "Zeytin"), AppList.order(l, AppList.Sort.AZ, { it.first }, { it.second }).map { it.first })
        assertEquals(listOf("Zeytin", "Çay", "Ay"), AppList.order(l, AppList.Sort.ZA, { it.first }, { it.second }).map { it.first })
        assertEquals(listOf("Ay", "Çay", "Zeytin"), AppList.order(l, AppList.Sort.USAGE, { it.first }, { it.second }).map { it.first })
        assertEquals(AppList.Sort.AZ, AppList.sortOf(99))
    }
    @Test fun usageTieBreaksByName() {
        val l = listOf("B" to 0L, "A" to 0L)
        assertEquals(listOf("A", "B"), AppList.order(l, AppList.Sort.USAGE, { it.first }, { it.second }).map { it.first })
    }
    @Test fun wiredInUiAndCatalog() {
        val ui = java.io.File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()
        assertTrue(ui.contains("AppList.order(") && ui.contains("BlockStore.setAppSort"))
        assertTrue(raw.contains("MoreAppsData.ALL") && raw.contains("fun invalidateIndex"))
        for (l in listOf("", "-tr", "-en", "-de", "-fr", "-es", "-ar", "-ru", "-az"))
            assertTrue(l, java.io.File(TestFiles.main, "res/values$l/strings.xml").readText().contains("name=\"sort_usage\""))
    }
}

class DayChangeTest {
    @Test fun followTodayMovesOnlyWhenOnToday() {
        val d1 = java.time.LocalDate.of(2026, 10, 26); val d2 = d1.plusDays(1)
        assertEquals(d2, com.odak.app.logic.Pure.followToday(d1, d1, d2))
        assertEquals(d1.minusDays(2), com.odak.app.logic.Pure.followToday(d1.minusDays(2), d1, d2))
    }
    @Test fun screenTimeWatchesDateAndManifestHasIcon() {
        val s = java.io.File(TestFiles.code, "com/odak/app/block/ScreenTimeScreen.kt").readText()
        assertTrue(s.contains("Pure.followToday(day, last, n)"))
        val m = java.io.File(TestFiles.main, "AndroidManifest.xml").readText()
        assertTrue(Regex("<application[^>]*android:icon=\"@mipmap/ic_logo_a01\"").containsMatchIn(m))
    }
    @Test fun signingConfigIsFixed() {
        val g = java.io.File(TestFiles.main, "../../build.gradle.kts").readText()
        assertTrue(g.contains("signingConfigs") && g.contains("atlas-release.jks"))
        assertTrue(java.io.File(TestFiles.main, "../../atlas-release.jks").exists())
    }
}

class BlockWindowTest {
    private val ui = java.io.File(TestFiles.code, "com/odak/app/block/BlockScreen.kt").readText()
    @Test fun badgesSummarize() {
        assertEquals("", AppList.badges(false, 0, 0, false, 0))
        assertEquals("⏱30 🔢5 🌙 🎯2", AppList.badges(false, 30, 5, true, 2))
        assertEquals("⏱10", AppList.badges(true, 10, 0, false, 3)) // tam engelde özellik rozeti gizli
    }
    @Test fun listRowIsCompactAndDetailInWindow() {
        assertTrue(ui.contains("detail = app.id") && ui.contains("private fun AppDetailDialog("))
        val row = ui.substring(ui.indexOf("items(filtered.take("), ui.indexOf("val rem = com.odak.app.logic.Pure.appsRemaining"))
        assertTrue(!row.contains("LimitRow(") && !row.contains("CountRow(") && !row.contains("features.forEach")) // satırda ayrıntı yok
        for (k in listOf("blk_sec_block", "blk_sec_limits", "blk_sec_features")) for (l in listOf("", "-tr", "-en", "-de", "-fr", "-es", "-ar", "-ru", "-az"))
            assertTrue("$k $l", java.io.File(TestFiles.main, "res/values$l/strings.xml").readText().contains("name=\"$k\""))
    }
}

class SettingsSimplifyTest {
    private val s = java.io.File(TestFiles.code, "com/odak/app/settings/SettingsScreen.kt").readText()
    @Test fun previewOnlyForSelectedStyle() { assertTrue(s.contains("if (s == current) {") && s.contains("ThemePreview(s, Modifier.fillMaxWidth())")) }
    @Test fun colorsHaveOwnTabAndPaletteInWindow() {
        assertTrue(s.contains("R.string.colors_title), \"Aa\"") || s.contains("\"🖌 \" + stringResource(R.string.colors_title)"))
        val row = s.substring(s.indexOf("private fun SwatchRow"), s.indexOf("private fun PinCard"))
        assertTrue(row.contains("AlertDialog(") && row.contains("SwatchPalette(current, onPick)"))
    }
}

class OtherWindowsTest {
    private fun src(f: String) = java.io.File(TestFiles.code, "com/odak/app/$f").readText()
    @Test fun todoUsesWindows() {
        val t = src("todo/TodoScreen.kt")
        assertTrue(t.contains("showTools = true") && t.contains("showNew = true") && t.contains("showList = true"))
        assertTrue(!t.contains("showTools = !showTools") && !t.contains("showNew = !showNew") && !t.contains("showList = !showList"))
        assertEquals(3, Regex("AlertDialog\\(").findAll(t).count { true })
    }
    @Test fun screenTimeUsesWindows() {
        val t = src("block/ScreenTimeScreen.kt")
        assertTrue(t.contains("more = true") && t.contains("open = true") && !t.contains("if (open) AppWeekBars"))
        assertTrue(t.contains("AppWeekBars(r.pkg)"))
    }
}

class PlanScheduleWindowTest {
    private fun src(f: String) = java.io.File(TestFiles.code, "com/odak/app/$f").readText()
    @Test fun planAddRowIsCompact() {
        val t = src("plan/PlanCommon.kt")
        val row = t.substring(t.indexOf("fun AddRow("), t.indexOf("if (tplOpen) TemplateDialog(vm)"))
        assertTrue(row.contains("optOpen = true") && row.contains("AlertDialog("))
        // ana satırda yalnız alan + ⋯ + Ekle (3 bileşen); diğer düğmeler pencerede
        val head = row.substring(row.indexOf("Row(verticalAlignment"), row.indexOf("if (optOpen)"))
        assertEquals(2, Regex("ThemedButton\\(").findAll(head).count { true })
        assertEquals(1, Regex("ThemedTextField\\(").findAll(head).count { true })
    }
    @Test fun scheduleEditorIsWindow() {
        val t = src("schedule/ScheduleScreen.kt")
        assertTrue(t.contains("AlertDialog(") && !t.contains("\"‹ \" + stringResource(R.string.sg_back)"))
        assertTrue(!t.contains("        return\n        })"))
    }
}
