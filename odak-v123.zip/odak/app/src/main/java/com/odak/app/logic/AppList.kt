package com.odak.app.logic

/** Uygulama listesi: ek katalog ayrıştırma ve sıralama (saf mantık). */
object AppList {
    class Entry(val name: String, val pkg: String)
    enum class Sort { AZ, ZA, USAGE }

    fun parse(lines: List<String>): List<Entry> = lines.mapNotNull { l ->
        val i = l.lastIndexOf('|')
        if (i <= 0) null else l.substring(0, i).trim().let { n -> val p = l.substring(i + 1).trim(); if (n.isEmpty() || p.isEmpty()) null else Entry(n, p) }
    }

    /** Satırdaki kısa özet rozetleri: ⏱ süre sınırı, 🔢 açma sınırı, 🌙 sessiz saat, 🎯 etkin özellik sayısı. Tam engel zaten onay kutusunda görünür. */
    fun badges(whole: Boolean, limitMin: Int, openLimit: Int, quiet: Boolean, activeFeatures: Int): String =
        listOfNotNull(
            if (limitMin > 0) "⏱$limitMin" else null,
            if (openLimit > 0) "🔢$openLimit" else null,
            if (quiet) "🌙" else null,
            if (!whole && activeFeatures > 0) "🎯$activeFeatures" else null
        ).joinToString(" ")

    fun sortOf(i: Int): Sort = Sort.values().getOrElse(i) { Sort.AZ }

    /** AZ/ZA ada göre (yerel dile uygun), USAGE bugünkü kullanıma göre çoktan aza (eşitlikte ada göre). */
    fun <T> order(items: List<T>, mode: Sort, name: (T) -> String, usage: (T) -> Long): List<T> {
        val col = java.text.Collator.getInstance().apply { strength = java.text.Collator.PRIMARY }
        val az = Comparator<T> { a, b -> col.compare(name(a), name(b)) }
        return when (mode) {
            Sort.AZ -> items.sortedWith(az)
            Sort.ZA -> items.sortedWith(az.reversed())
            Sort.USAGE -> items.sortedWith(compareByDescending<T> { usage(it) }.then(az))
        }
    }
}
