package com.odak.app.logic

/** Engelleme kataloğuna eklenen ek uygulamalar ("Ad|paket"). Paket adları elle derlendi; yanlış bir paket yalnızca eşleşmez. */
object MoreAppsData {
    private const val P0 = """
Twitter Lite|com.twitter.android.lite
LinkedIn Lite|com.linkedin.android.lite
Reddit Boost|com.rubenmayayo.reddit
Relay for Reddit|reddit.news
Infinity for Reddit|ml.docilealligator.infinityforreddit
Sync for Reddit|com.laurencedawson.reddit_sync
Flickr|com.yahoo.mobile.client.android.flickr
500px|com.fivehundredpx.viewer
Behance|com.behance.behancefoundation
Houseparty|com.herzick.houseparty
Parler|com.parler.parler
Mewe|com.mewe
Inoreader|com.innologica.inoreader
Newsbreak|com.particlenews.newsbreak
SmartNews|jp.gocro.smartnews.android
BBC News|bbc.mobile.news.ww
CNN|com.cnn.mobile.android.phone
NY Times|com.nytimes.android
Washington Post|com.washingtonpost.rainbow
Guardian|com.guardian
Reuters|com.thomsonreuters.reuters
Bloomberg|com.bloomberg.android.plus
Al Jazeera|net.aljazeera.english
Vero|co.vero.app.release
MX TakaTak|com.next.innovation.takatak
Helo|app.buzz.share
Truecaller|com.truecaller
Getcontact|app.source.getcontact
Whoscall|gogolook.callgogolook2
Eyecon|com.eyecon.global
ICQ|com.icq.mobile.client
Briar|org.briarproject.briar.android
Zello|com.loudtalks
Voxer|com.rebelvox.voxer
Google Voice|com.google.android.apps.googlevoice
Textfree|com.pinger.textfree
Burner|com.adhoclabs.burner
Hushed|com.hushed.release
QQ|com.tencent.mobileqq
Douyin|com.ss.android.ugc.aweme
Kuaishou|com.smile.gifmaker
Xiaohongshu|com.xingin.xhs
Zhihu|com.zhihu.android
Douban|com.douban.frodo
Tieba|com.baidu.tieba
Baidu|com.baidu.searchbox
Toutiao|com.ss.android.article.news
Pinduoduo|com.xunmeng.pinduoduo
Taobao|com.taobao.taobao
Tmall|com.tmall.wireless
JD|com.jingdong.app.mall
Meituan|com.sankuai.meituan
Dianping|com.dianping.v1
Naver|com.nhn.android.search
Naver Webtoon|com.nhn.android.webtoon
Band|com.nhn.android.band
Daum|net.daum.android.daum
Melon|com.iloen.melon
Bugs|com.neowiz.android.bugs
FLO|skplanet.musicmate
Vibe|com.naver.vibe
Ridibooks|com.initialcoms.ridi
Coupang Eats|com.coupang.mobile.eats
Baemin|com.sampleapp
Toss|viva.republica.toss
KakaoBank|com.kakaobank.channel
Zigzag|com.croquis.zigzag
Musinsa|com.musinsa.store
Ably|com.a.ably
Danggeun|com.towneers.www
Bunjang|kr.co.quicket
Olive Young|com.oliveyoung
Kurly|com.dwarvesv.kurly
Wavve|kr.co.captv.pooq
Tving|net.cj.cjhv.gs.tving
Watcha|com.frograms.wplay
Laftel|net.laftel.app
Afreeca|com.afreecatv.mobile.sch
Chzzk|com.navercorp.android.chzzk
Genie Music|com.ktmusic.geniemusic
Yahoo Mail|com.yahoo.mobile.client.android.mail
Gmail|com.google.android.gm
Outlook|com.microsoft.office.outlook
Proton Mail|ch.protonmail.android
Spark Mail|com.readdle.spark
Tutanota|de.tutao.tutanota
K-9 Mail|com.fsck.k9
Blue Mail|me.bluemail.mail
Edison Mail|com.easilydo.mail
GMX Mail|de.gmx.mobile.android.mail
Mail.ru|ru.mail.mailapp
Yandex Mail|ru.yandex.mail
Yandex|ru.yandex.searchplugin
Yandex Go|ru.yandex.taxi
Yandex Music|ru.yandex.music
Yandex Maps|ru.yandex.yandexmaps
Yandex Disk|ru.yandex.disk
Kinopoisk|ru.kinopoisk
Telegram X Beta|org.thunderdog.challegram.beta
Odnoklassniki|ru.ok.android
VK Video|com.vk.vkvideo
VK Music|com.vkontakte.android.music
VK Messenger|com.vk.im
VK Clips|com.vk.clips
Rutube|ru.rutube.app
Zen|ru.yandex.zen
Pikabu|ru.pikabu.android
Firefox Focus|org.mozilla.focus
Opera Mini|com.opera.mini.native
Opera GX|com.opera.gx
Tor Browser|org.torproject.torbrowser
Via Browser|mark.via.gp
Puffin|com.cloudmosa.puffinFree
Bing|com.microsoft.bing
Aloha Browser|com.aloha.browser
Mi Browser|com.mi.globalbrowser
Cake Browser|com.cake.browser
Dolphin Browser|mobi.mgeek.TunnyBrowser
Phoenix Browser|com.transsion.phoenix
Quetta|net.quetta.browser
"""
    private const val P1 = """
Fennec|org.mozilla.fennec_fdroid
Microsoft Start|com.microsoft.amp.apps.bingnews
Wikipedia|org.wikipedia
Google Translate|com.google.android.apps.translate
Google Maps|com.google.android.apps.maps
Waze|com.waze
Here WeGo|com.here.app.maps
Maps.me|com.mapswithme.maps.pro
Citymapper|com.citymapper.app.release
Moovit|com.tranzmate
Grab|com.grabtaxi.passenger
Ola|com.olacabs.customer
Careem|com.careem.acma
DiDi|com.didiglobal.passenger
Free Now|taxi.android.client
Indriver|sinet.startup.inDriver
Cabify|com.cabify.rider
BiTaksi|com.bitaksi.passenger
Lime|com.limebike
Bird|co.bird.android
Voi|io.voiapp.voi
Dott|io.dott.app
Expedia|com.expedia.bookings
Trivago|com.trivago
Agoda|com.agoda.mobile.consumer
Skyscanner|net.skyscanner.android.main
Momondo|com.momondo.flightsearch
Google Flights|com.google.android.apps.travel.onthego
Hopper|com.hopper.mountainview.play
Trip.com|ctrip.english
Klook|com.klook
Pegasus|com.pegasus.flights
Obilet|com.obilet.androidapp
Ryanair|com.ryanair.cheapflights
Lufthansa|com.lufthansa.android.lufthansa
Emirates|com.emirates.ek.android
Wizz Air|com.wizzair.WizzAirApp
Delta|com.delta.mobile.android
United|com.united.mobile.android
Air France|com.airfrance.android.dinamoprd
KLM|com.afklm.mobile.android.gomobile.klm
Singapore Airlines|com.singaporeair
Cathay Pacific|com.cathaypacific.cx
Qantas|com.qantas.qantas
Flixbus|de.flixbus.app
BlaBlaCar|com.comuto
Trainline|com.thetrainline
Rome2Rio|com.rome2rio.android.r2r
Uber Freight|com.uber.freight
Swiggy|in.swiggy.android
Zomato|com.application.zomato
Deliveroo|com.deliveroo.orderapp
Just Eat|com.justeat.app.uk
Foodpanda|com.global.foodpanda.android
Talabat|com.talabat
Zepto|com.zeptoconsumerapp
Blinkit|com.grofers.customerapp
BigBasket|com.bigbasket.mobileapp
Flink|com.goflink.flink
Yemeksepeti Express|com.yemeksepeti.express
Migros|com.migros.sanalmarket
Migros Hemen|com.migros.hemen
Starbucks|com.starbucks.mobilecard
Burger King|com.emn8.mobilem8.nativeapp.bk
Domino's|com.dominospizza
Pizza Hut|com.yum.pizzahut
Subway|com.subway.mobile.subwayapp03
Dunkin|com.dunkinbrands.otgo
Taco Bell|com.yum.tacobell
Chick-fil-A|com.chickfila.cfaflagship
Wendy's|com.wendys.nutritiontool
Little Caesars|com.littlecaesars
Fortnite|com.epicgames.fortnite
Epic Games|com.epicgames.portal
Valorant Mobile|com.riotgames.valorant
Legends of Runeterra|com.riotgames.legendsofruneterra
Teamfight Tactics|com.riotgames.league.teamfighttactics
Arena of Valor|com.garena.game.kgtw
Garena|com.garena.msdk
Fifa Mobile|com.ea.gp.fifamobile.global
Madden NFL|com.ea.gp.madden19
NBA 2K|com.t2ksports.nba2kmobile
NBA Live|com.ea.gp.nbamobile
Need for Speed No Limits|com.ea.game.nfsmw_row
The Sims Mobile|com.ea.gp.simsmobile
SimCity BuildIt|com.ea.game.simcitymobile_row
Apex Legends Mobile|com.ea.gp.apexlegendsmobilefps
Star Wars Galaxy of Heroes|com.ea.game.starwarscapital_row
Asphalt 8|com.gameloft.android.ANMP.GloftA8HM
Modern Combat 5|com.gameloft.android.ANMP.GloftM5HM
Disney Magic Kingdoms|com.gameloft.android.ANMP.GloftDMKHM
Minion Rush|com.gameloft.android.ANMP.GloftMRHM
Brawlhalla|com.ubisoft.brawlhalla
Rainbow Six Mobile|com.ubisoft.rainbowsixmobile.r6.fps.pvp.shooter
Assassin's Creed Rebellion|com.ubisoft.acrebellion
Hungry Dragon|com.ubisoft.hungrydragon
Brawl Stars Beta|com.supercell.brawlstars.beta
Clash Mini|com.supercell.clashmini
Call of Duty Warzone Mobile|com.activision.callofduty.warzone
Candy Crush Jelly|com.king.candycrushjellysaga
Farm Heroes Saga|com.king.farmheroessaga
Bubble Witch 3|com.king.bubblewitch3
Diamond Digger|com.king.diamonddiggersaga
Angry Birds Dream Blast|com.rovio.dream
Angry Birds Journey|com.rovio.angrybirdsjourney
Cut the Rope|com.zeptolab.ctr.ads
Jetpack Joyride|com.halfbrick.jetpackjoyride
Temple Run|com.imangi.templerun
Subway Surfers Tag|com.kiloo.subwaysurf2
Hill Climb Racing 2|com.fingersoft.hcr2
Crossy Road|com.yodo1.crossyroad
Flappy Bird|com.dotgears.flappybird
2048|com.estoty.game2048
Stack Ball|com.azurgames.stackball
Helix Jump|com.h8games.helixjump
Color Switch|com.fortafy.colorswitch
Piano Tiles 2|com.cmplay.tiles2
Magic Tiles 3|com.amanotes.magictiles3
Beatstar|com.space.ape.beatstar
Rhythm Hive|com.superbstudio.rhythmhive
"""
    private const val P2 = """
Tiles Hop|com.amanotes.tileshop
Among Us 3D|com.innersloth.amongus3d
Impostor Factory|com.innersloth.impostor
Subway Princess Runner|com.sybogames.subwayprincess
Roblox Studio|com.roblox.studio
Minecraft Education|com.mojang.minecraftedu
Don't Starve|com.kleientertainment.doNotStarvePocket
Dead Cells|com.playdigious.deadcells.mobile
Hades|com.supergiant.hades
Genshin Impact Cloud|com.miHoYo.cloudgames
Honkai Impact 3rd|com.miHoYo.bh3oversea
Black Desert Mobile|com.pearlabyss.blackdesertm
Lineage 2 Revolution|com.netmarble.lineageII
Lineage M|com.ncsoft.lineagem19
Lineage W|com.ncsoft.lineagew
Vikings War of Clans|com.plarium.vikings
Stormfall|com.plarium.stormfall
Evony|com.topgamesinc.evony
Last Shelter Survival|com.camelgames.ldsurvival
Kingshot|com.run.tower.defense
Mobile Legends Adventure|com.moonton.mobilelegendsadventure
Marvel Contest of Champions|com.kabam.marvelbattle
Marvel Strike Force|com.foxnextgames.m3
Hearthstone|com.blizzard.wtcg.hearthstone
Warcraft Rumble|com.blizzard.wowrumble
Yu-Gi-Oh Master Duel|jp.konami.masterduel
Yu-Gi-Oh Duel Links|jp.konami.duellinks
Pokemon Unite|jp.pokemon.pokemonunite
Pokemon Home|jp.pokemon.pokemonhome
Pokemon Masters EX|com.dena.pokemonmasters
Pokemon TCG Pocket|jp.pokemon.pokemontcgp
Monster Strike|jp.co.mixi.monster_strike
Dragon Ball Legends|com.bandainamcoent.dblegends_ww
Dragon Ball Z Dokkan Battle|com.bandainamcogames.dbzdokkanww
Naruto Slugfest|com.vng.naruto
One Piece Bounty Rush|com.bandainamcoent.opbrww
Girls Frontline|com.sunborn.girlsfrontline.en
Azur Lane|com.YoStarEN.AzurLane
Arknights|com.YoStarEN.Arknights
Epic Seven|com.stove.epic7.google
Summoners War|com.com2us.smon.normal.freefull.google.kr.android.common
Clash of Kings|com.elex.coq.gp
Mafia City|com.yottagames.mafiacity
King of Avalon|com.diandian.gog
Puzzles and Survival|com.proximabeta.puzzles.survival
Gunship Battle|com.joycity.gunship
Mobile Strike|com.epicwaronline.ms
Game of Sultans|com.gof.sultan
Empires and Puzzles|com.smallgiantgames.empires
Merge Mansion|com.metacoregames.mergemansion
Merge Magic|com.tiltingpoint.mergemagic
Gardenscapes Beta|com.playrix.gardenscapes.beta
Fishdom|com.playrix.fishdomdd.gplay
Manor Matters|com.playrix.manormatters
Wildscapes|com.playrix.wildscapes
Matchington Mansion|com.matchington.mansion
Toon Blast|net.peakgames.toonblast
Toy Blast|net.peakgames.toyblast
Lords and Knights|com.xyrality.lordsandknights
Hustle Castle|ru.hustlecastle
Gods of Olympus|com.plarium.godsofolympus
Idle Heroes|com.droidhang.ad
AFK Arena|com.lilithgames.hgame.gp
Rise of Empires|com.rise.empires
RAID Shadow|com.plarium.raidlegendsfree
Soul Knight|com.ChillyRoom.DungeonShooter
Archero|com.habby.archero
Vampire Survivors|com.poncle.vampiresurvivors
Survivor.io|com.dxx.firenow
Zombie Catchers|com.deadmageddon.zc
Plague Inc|com.miniclip.plagueinc
Agar.io|com.miniclip.agar.io
Slither.io|air.com.hypah.io.slither
Paper.io 2|io.voodoo.paper2
Hole.io|io.voodoo.holeio
Stumble Guys Beta|com.kitkagames.fallbuddies.beta
Fall Guys|com.mediatonic.fallguys
Pubg New State|com.pubg.newstate
Pubg Lite|com.tencent.iglite
Free Fire India|com.dts.freefireind
Call of Duty Legends|com.activision.callofduty.legends
Critical Ops|com.criticalforceentertainment.criticalops
Modern Strike Online|com.pasha.modernstrike
Bullet Force|com.blayzegames.iosfps
Shadowgun Legends|com.madfingergames.legends
Real Cricket|com.nautilus.RealCricket
Cricket League|com.miniclip.cricketleague
Dream11|com.app.dream11Pro
Football Manager Mobile|com.sega.fm.mobile
Score Hero|com.firsttouchgames.story
Top Eleven|com.nordeus.topeleven.android
Soccer Stars|com.miniclip.sstars
Golf Clash|com.miniclip.golfbattle
Basketball Stars|com.miniclip.basketballstars
Archery King|com.miniclip.archeryking
Ludo Club|com.ludo.club
Ludo Star|com.ludo.star
Parchisi Star|com.parchisi.star
Teen Patti Gold|com.moonfrog.teenpatti
Poker Texas Holdem|com.texas.holdem
Governor of Poker|com.youdagames.governorofpoker3
Huuuge Casino|com.huuuge.casino.slots
Jackpot World|com.jackpotworld.slots
House of Fun|com.playtika.houseoffun
Cashman Casino|com.productmadness.cashmancasino
Bingo Blitz|com.playtika.bingoblitz
Bingo Bash|com.gsn.bingobash
Solitaire Grand Harvest|com.supertreat.solitaire
Spider Solitaire|com.mobilityware.spider
Microsoft Solitaire|com.mseries.solitaire
Wordle|com.nyt.wordle
Words With Friends|com.zynga.words
Word Connect|com.wordgame.connect
4 Pics 1 Word|de.lotum.whatsinthefoto.us
Trivia Crack|com.etermax.preguntados.lite
Kahoot|no.mobitroll.kahoot.android
QuizUp|com.plainvanilla.quizup
Ruzzle|se.maginteractive.ruzzle
Draw Something|com.omgpop.dstfree
Scrabble Go|com.scopely.scrabblego
"""
    private const val P3 = """
Uno|com.matteljv.uno
Monopoly|com.ea.game.monopoly
Chess.com|com.chess
Lichess|org.lichess.mobileapp
Chess Free|uk.co.aifactory.chessfree
Okey Plus|com.zynga.okeyplus
101 Yüzbir Okey Plus|com.yuzbir.okeyplus
Batak Online|com.batak.online
Tavla Plus|com.tavla.plus
Pişti|com.pisti.online
King Online|com.king.online.turk
Mynet Oyun|com.mynet.oyun
Mynet Okey|com.mynet.okey
Metin2 Mobile|com.gameforge.metin2
Rise Online|com.rise.online
Mount and Blade|com.taleworlds.mountandblade
Babbel|com.babbel.mobile.android.en
Busuu|com.busuu.android.enc
Memrise|com.memrise.android.memrisecompanion
Rosetta Stone|com.rosettastone.mobile.CoursePlayer
Mondly|com.atistudios.mondly.languages
HelloTalk|com.hellotalk
Tandem|com.tandem
Cambly|com.cambly.cambly
Khan Academy|org.khanacademy.android
Coursera|org.coursera.android
edX|org.edx.mobile
Skillshare|com.skillshare.Skillshare
Brilliant|org.brilliant.android
Quizlet|com.quizlet.quizletandroid
Anki|com.ichi2.anki
Photomath|com.microblink.photomath
Socratic|org.socratic.android
Brainly|co.brainly
Chegg|com.chegg
Gauthmath|com.bytedance.gauthmath
Mathway|com.bagatrix.mathway.android
Symbolab|com.devsense.symbolab
Wolfram Alpha|com.wolfram.android.alpha
Google Classroom|com.google.android.apps.classroom
Moodle|com.moodle.moodlemobile
Canvas Student|com.instructure.candroid
Blackboard|com.blackboard.android.bbstudent
Seesaw|org.seesaw.seesaw
Remind|com.remind101
Edmodo|com.edmodo
Kindle Lite|com.amazon.kindle.lite
Google Play Books|com.google.android.apps.books
Audible Lite|com.audible.application.lite
Libby|com.overdrive.mobile.android.libby
Scribd|com.scribd.app.reader3
Everand|com.scribd.app.everand
BookBeat|com.bookbeat
Wattpad Webnovel|com.webnovel.books
Radish Fiction|com.radish.fiction
Dreame|com.dreame.reader
GoodNovel|com.goodnovel.reader
Kuku FM|com.vlv.aravali
Spotify Lite|com.spotify.lite
Spotify Kids|com.spotify.kids
YouTube Studio|com.google.android.apps.youtube.creator
Google Podcasts|com.google.android.apps.podcasts
Castbox|fm.castbox.audiobook.radio.podcast
Overcast|fm.overcast.android
iHeartRadio|com.clearchannel.iheartradio.controller
TuneIn|tunein.player
Radio.net|de.radio.android
SoundHound|com.melodis.midomiMusicIdentifier.freemium
Napster|com.rhapsody
Qobuz|com.qobuz.music
Audiomack|com.audiomack
Wynk Music|com.bsbportal.music
Resso|com.moonvideo.android.resso
YouTube Go|com.google.android.apps.youtube.mango
Fizy|com.turkcell.fizy
Muud|com.turkcell.muud
BluTV|com.dogan.blutv
Tabii|tr.com.trt.tabii
Tivibu|com.turktelekom.tivibu
JioCinema|com.jio.media.ondemand
Voot|com.tv.v18.viola
VLC|org.videolan.vlc
Jellyfin|org.jellyfin.mobile
Stremio|com.stremio.one
YouTube TV|com.google.android.apps.youtube.unplugged
Hulu Live|com.hulu.livingroomplus
fuboTV|com.fubo.firetv.screen
Sling TV|com.sling
Philo|com.philo.philo
Crackle|com.sonyericsson.crackle
Peacock TV|com.peacocktv.peacockandroid.global
Apple TV|com.apple.atve.androidtv.appletv
Discovery Plus|com.discovery.discoveryplus.mobile
Paramount Plus|com.cbs.ca
Starz|com.starz.starzplay.android
Showtime|com.showtime.standalone
HBO Max|com.hbo.hbonow
Rakuten Viki|com.viki.rakuten
Youku|com.youku.phone
Mango TV|com.hunantv.imgo.activity
Hotstar|in.startv.hotstar.dplus
Netflix Games|com.netflix.NGP.Games
Dailymotion Lite|com.dailymotion.dailymotion.lite
Twitch Mobile|tv.twitch.android.viewer
Vimeo Create|com.vimeo.create
Snapseed|com.niksoftware.snapseed
VSCO Cam|com.vsco.cam.pro
Lightroom|com.adobe.lrmobile
Photoshop Express|com.adobe.psmobile
PicsArt|com.picsart.studio
Canva|com.canva.editor
Facetune|com.lightricks.facetune.free
Remini|com.bigwinepot.nwdn.international
FaceApp|io.faceapp
Meitu|com.mt.mtxx.mtxx
BeautyPlus|com.commsource.beautyplus
YouCam Perfect|com.cyberlink.youperfect
Snow|com.campmobile.snow
B612|com.linecorp.b612.android
Ulike|com.mt.ulike
"""
    private const val P4 = """
Camera360|vStudio.Android.Camera360
Candy Camera|com.joeware.android.gpulumera
Retrica|com.venticake.retrica
Snap Camera|com.snap.camera
InShot|com.camerasideas.instashot
KineMaster|com.nexstreaming.app.kinemasterfree
VN Video Editor|com.vlite.vn
Filmora|com.wondershare.filmorago
VivaVideo|com.quvideo.xiaoying
Capcut Lite|com.lemon.lvoverseas.lite
Alight Motion|com.alightcreative.motion
LumaFusion|com.luma.fusion
PowerDirector|com.cyberlink.powerdirector.DRA140225_01
Videoleap|com.lightricks.videoleap
Splice|com.splice.video.editor
Quik|com.stupeflix.replay
Adobe Premiere Rush|com.adobe.premiererush.videoeditor
Likee Video|video.like.beta
Vigo Video|com.ss.android.ugc.boom
TikTok Studio|com.zhiliaoapp.musically.go.studio
Triller Lite|co.triller.droid.lite
Dubsmash|com.mobilemotion.dubsmash
Smule|com.smule.singandroid
StarMaker|com.starmakerinteractive.starmaker
Yokee|com.yokee.piano.keyboard
Joox|com.tencent.ibg.joox
Tencent Video|com.tencent.qqlive
NetEase Music|com.netease.cloudmusic
QQ Music|com.tencent.qqmusic
Kuwo|cn.kuwo.player
Xiami|fm.xiami.main
Himalaya|com.ximalaya.ting.android
Dedao|com.luojilab.player
Weread|com.tencent.weread
Qidian|com.qidian.QDReader
Fanqie|com.dragon.read
Jinjiang|com.jjwxc.reader
Zhangyue|com.chaozh.iReaderFree
PayPal|com.paypal.android.p2pmobile
Venmo|com.venmo
Cash App|com.squareup.cash
Zelle|com.zellepay.zelle
Revolut|com.revolut.revolut
N26|de.number26.android
Monzo|co.uk.getmondo
Chime|com.chime.chimemobile
Webull|com.webull.trade
eToro|com.etoro.openbook
Binance|com.binance.dev
Kraken|com.kraken.trade
OKX|com.okinc.okex.gp
KuCoin|com.kubi.kucoin
Crypto.com|co.mona.android
Bitfinex|com.bitfinex.mobileapp
Bitget|com.bitget.exchange
MEXC|com.mexcpro.client
Gate.io|com.gateio.gateio
Huobi|pro.huobi
HTX|com.huobi.global
Trust Wallet|com.wallet.crypto.trustapp
MetaMask|io.metamask
Phantom|app.phantom
Exodus|exodusmovement.exodus
Ledger Live|com.ledger.live
Papara|com.mobillium.papara
Ininal|com.ininal.wallet
Paycell|com.turkcell.paycell
Garanti BBVA|com.garanti.cepsubesi
İş Cep|com.pozitron.iscep
Ziraat Mobil|com.ziraat.ziraatmobil
Akbank|com.akbank.android.apps.akbank_direkt
QNB Finansbank|com.finansbank.mobile.cepsube
Halkbank|com.tmob.halkbank
Denizbank|com.denizbank.mobildeniz
TEB|com.teb
Kuveyt Türk|com.kuveytturk.mobil
Papara Kart|com.papara.card
Bank of America|com.infonow.bofa
Chase|com.chase.sig.android
Wells Fargo|com.wf.wellsfargomobile
Citi|com.citi.citimobile
Capital One|com.konylabs.capitalone
American Express|com.americanexpress.android.acctsvcs.us
US Bank|com.usbank.mobilebanking
PNC|com.pnc.ecommerce.mobile
TD Bank|com.td
Barclays|com.barclays.android.barclaysmobilebanking
HSBC|uk.co.hsbc.hsbcukmobilebanking
Lloyds|com.grppl.android.shell.CMBlloydsTSB73
Santander|es.cm.android
BBVA|com.bbva.bbvacontigo
ING Bank|com.ing.banking
Deutsche Bank|com.db.pbc.miabanking
Commerzbank|de.commerzbanking.mobil
Sparkasse|com.starfinanz.smob.android.sfinanzstatus
Klarna|com.myklarnamobile
Affirm|com.affirm.central
Mint|com.mint
YNAB|com.youneedabudget.evergreen.paid
Rocket Money|com.truebill
Stash|com.stash.stashinvest
Moomoo|com.moomoo.trade
TradingView|com.tradingview.tradingviewapp
Investing.com|com.fusionmedia.investing
Yahoo Finance|com.yahoo.mobile.client.android.finance
Bloomberg Markets|com.bloomberg.markets
CoinGecko|com.coingecko.coingeckoapp
Blockfolio|com.blockfolio.blockfolio
Delta Investment|io.getdelta.android
Etoro Club|com.etoro.club
Google Pay|com.google.android.apps.nbu.paisa.user
Paytm|net.one97.paytm
Amazon Pay|in.amazon.mShop.android.shopping
Samsung Pay|com.samsung.android.spay
Samsung Wallet|com.samsung.android.spay.wallet
Alipay|com.eg.android.AlipayGphone
WeChat Pay|com.tencent.mm.pay
PayPay|jp.ne.paypay.android.app
Rakuten Pay|jp.co.rakuten.pay
Line Pay|jp.naver.line.android.pay
"""
    private const val P5 = """
GCash|com.globe.gcash.android
Maya|com.paymaya
Gopay|com.gojek.gopay
OVO|ovo.id
Dana|id.dana
ShopeePay|com.shopee.id.pay
Shopee|com.shopee.id
Tokopedia|com.tokopedia.tkpd
Blibli|blibli.mobile.commerce
Ajio|com.ril.ajio
Nykaa|com.fsn.nykaa
Snapdeal|com.snapdeal.main
Jio Mart|com.jpl.jiomart
Mercado Pago|com.mercadopago.wallet
Americanas|br.com.lojasamericanas.app
Magalu|com.luizalabs.mlapp
OLX|com.olx.southasia
Zalando Lounge|de.zalando.lounge
About You|de.aboutyou.aboutyou
Otto|de.otto.app
Kaufland|com.kaufland.app
Lidl Plus|com.lidlplus.app
Aldi|com.aldi.app
IKEA|com.ikea.app
H&M|com.hm.goe
Shein Lite|com.zzkko.lite
Boohoo|com.boohoo.app
ASOS|com.asos.app
Fashion Nova|com.fashionnova.app
Romwe|com.romwe
Banggood|com.banggood.client
Mercari|com.mercariapp.mercari
Facebook Marketplace|com.facebook.marketplace
Craigslist|org.craigslist.CraigslistMobile
Kleinanzeigen|com.ebay.kleinanzeigen
Subito|it.subito
Leboncoin|fr.leboncoin
Wallapop|com.wallapop
Marktplaats|nl.marktplaats.android
Home Depot|com.thehomedepot
Lowe's|com.lowes.android
Costco|com.costco.app.android
Walmart Grocery|com.walmart.grocery
Sam's Club|com.samsclub.android
Macy's|com.macys.android
Nordstrom|com.nordstrom.app
Adidas|com.adidas.app
Puma|com.puma.android
Decathlon|com.decathlon.app
Sephora|com.sephora
Ulta|com.ulta
Overstock|com.overstock
AliExpress Lite|com.alibaba.aliexpresshd.lite
1688|com.alibaba.wireless
Xianyu|com.taobao.idlefish
Hepsiburada Lite|com.pozitron.hepsiburada.lite
N11|com.dmall.n11
Gittigidiyor|com.gittigidiyor
Sephora Türkiye|com.sephora.tr
Minds|com.minds.mobile
Fox News|com.foxnews.android
Hiya|com.hiya.android
Talkatone|com.talkatone.android
Kakao Page|com.kakaopage.android
Coupang|com.coupang.mobile
Avito|com.avito.android
Ecosia|com.ecosia.android
Gojek|com.gojek.app
Hotels.com|com.hcom.android
Kayak|com.kayak.android
GetYourGuide|com.getyourguide.android
Hostelworld|com.hostelworld.app
Vrbo|com.vrbo.android
Turkish Airlines|com.turkishairlines.mobile
easyJet|com.easyjet.android
American Airlines|com.aa.android
Southwest|com.southwestairlines.mobile
British Airways|com.ba.mobile
Wolt|com.wolt.android
McDonald's|com.mcdonalds.app
Papa John's|com.papajohns.android
italki|com.italki.app
Udemy|com.udemy.android
MasterClass|com.masterclass.android
ClassDojo|com.classdojo.android
Nextory|com.nextory.android
Kobo Books|com.kobobooks.android
Shazam|com.shazam.android
TED|com.ted.android
Kugou|com.kugou.android
Wise|com.transferwise.android
SoFi|com.sofi.mobile
Robinhood|com.robinhood.android
Coinbase|com.coinbase.android
Yapı Kredi|com.ykb.android
Discover|com.discoverfinancial.mobile
Acorns|com.acorns.android
CoinMarketCap|com.coinmarketcap.android
Phone Pe|com.phonepe.app
Kakao Pay|com.kakaopay.app
Bukalapak|com.bukalapak.android
Gumtree|com.gumtree.android
Kroger|com.kroger.mobile
Chewy|com.chewy.android
Newegg|com.newegg.app
"""
    val ALL: List<String> = listOf(P0, P1, P2, P3, P4, P5).flatMap { it.lines() }
}
