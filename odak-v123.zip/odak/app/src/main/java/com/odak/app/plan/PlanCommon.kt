package com.odak.app.plan

import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.odak.app.R
import com.odak.app.theme.ClickSound
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.SoundKind
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedTextField
import com.odak.app.theme.plainClick
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.WeekFields
import java.util.Locale
import java.time.format.TextStyle as JTextStyle

enum class Period { DAY, WEEK, MONTH }

class PlanVm(
    val items: List<PlanItem>,
    val period: Period,
    val anchor: LocalDate,
    val today: LocalDate,
    val setPeriod: (Period) -> Unit,
    val setAnchor: (LocalDate) -> Unit,
    val step: (Int) -> Unit,
    val add: (String, Int, Int, Int) -> Unit,
    val toggle: (PlanItem, Boolean) -> Unit,
    val remove: (PlanItem) -> Unit,
    val startEdit: (PlanItem) -> Unit,
    val copyDay: () -> Unit = {}
) {
    val dayItems: List<PlanItem>
        get() = items.filter { it.date == anchor }
            .sortedBy { if (it.hasTime) it.startMin else Int.MAX_VALUE }

    val weekStart: LocalDate get() = anchor.with(DayOfWeek.MONDAY)
    val month: YearMonth get() = YearMonth.from(anchor)

    /** Haftalık görünümde bir güne dokununca o günün Gün görünümüne geç. */
    val pickDay: (LocalDate) -> Unit = {
        setAnchor(it)
        setPeriod(Period.DAY)
    }
}

@Composable
fun periodLabels(): List<String> = listOf(
    stringResource(R.string.plan_day),
    stringResource(R.string.plan_week),
    stringResource(R.string.plan_month)
)

fun rangeLabel(vm: PlanVm): String {
    val loc = Locale.getDefault()
    val full = DateTimeFormatter.ofPattern("d MMM yyyy", loc)
    val short = DateTimeFormatter.ofPattern("d MMM", loc)
    return when (vm.period) {
        Period.DAY -> vm.anchor.format(full)
        Period.WEEK -> "${vm.weekStart.format(short)} – ${vm.weekStart.plusDays(6).format(full)}"
        Period.MONTH -> vm.anchor.format(DateTimeFormatter.ofPattern("LLLL yyyy", loc))
    }
}

fun monthName(date: LocalDate): String =
    date.month.getDisplayName(JTextStyle.FULL_STANDALONE, Locale.getDefault())

fun weekNumber(date: LocalDate): Int = date.get(WeekFields.ISO.weekOfWeekBasedYear())

fun dayName(date: LocalDate, style: JTextStyle): String =
    date.dayOfWeek.getDisplayName(style, Locale.getDefault())

fun timeOf(p: PlanItem): String = if (p.hasTime) fmtTime(p.startMin) else ""

/** ‹ tarih › satırı. */
@Composable
fun NavRow(vm: PlanVm) {
    Row(
        Modifier.fillMaxWidth(),
        Arrangement.SpaceBetween,
        Alignment.CenterVertically
    ) {
        ThemedButton("‹", { vm.step(-1) })
        Text(
            rangeLabel(vm),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.weight(1f)
        )
        ThemedButton("›", { vm.step(1) })
    }
    if (vm.period == Period.DAY) DayInfo(vm)
}

/** Gün ilerlemesi (yapılan/toplam) ve "şimdi / sıradaki" satırı. */
@Composable
private fun DayInfo(vm: PlanVm) {
    val list = vm.dayItems
    if (list.isEmpty()) return
    val done = list.count { it.done }
    val t = LocalDesign.current.tokens
    Spacer(Modifier.height(6.dp))
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxWidth().height(4.dp).background(t.text.copy(alpha = 0.12f))
    ) {
        androidx.compose.foundation.layout.Box(
            Modifier.fillMaxWidth(done / list.size.toFloat()).height(4.dp).background(t.primary)
        )
    }
    Text("✔ $done/${list.size}", fontSize = 11.sp, color = t.text.copy(alpha = 0.7f))
    val timed = list.filter { it.hasTime }
    if (timed.isNotEmpty()) {
        val total = com.odak.app.logic.Pure.totalPlanned(timed.map { it.durMin })
        Text(
            stringResource(R.string.plan_total, com.odak.app.logic.Pure.fmtDur(total)),
            fontSize = 11.sp, color = t.text.copy(alpha = 0.7f)
        )
        val bad = com.odak.app.logic.Pure.conflictIndexes(timed.map { it.startMin to it.durMin })
        if (bad.isNotEmpty()) Text(
            "⚠ " + bad.sorted().joinToString(", ") { timed[it].title },
            fontSize = 11.sp, color = androidx.compose.ui.graphics.Color(0xFFE53935)
        )
        val nowM = java.time.LocalTime.now().let { it.hour * 60 + it.minute }
        val from = if (vm.anchor == vm.today) maxOf(nowM, 6 * 60) else 8 * 60
        com.odak.app.logic.Pure.freeSlot(timed.map { it.startMin to it.durMin }, from, 22 * 60, 30)?.let { f ->
            Text(
                "🕓 " + stringResource(R.string.plan_free, fmtTime(f)),
                fontSize = 11.sp, color = t.text.copy(alpha = 0.7f)
            )
        }
    }
    if (vm.anchor == vm.today) {
        val nowMin = java.time.LocalTime.now().let { it.hour * 60 + it.minute }
        val cur = list.firstOrNull { it.hasTime && !it.done && nowMin >= it.startMin && nowMin < it.startMin + it.durMin }
        val next = list.filter { it.hasTime && !it.done && it.startMin > nowMin }.minByOrNull { it.startMin }
        val pick = cur ?: next
        if (pick != null) {
            val mins = if (cur != null) cur.startMin + cur.durMin - nowMin else pick.startMin - nowMin
            Text(
                (if (cur != null) "▶ " else "⏭ ") + timeOf(pick) + " " + pick.title + " · " +
                    stringResource(R.string.fmt_min, mins),
                fontSize = 12.sp, color = t.primary
            )
        }
    }
}

/** Yeni plan: başlık + isteğe bağlı saat + süre + tekrar. */
@Composable
fun AddRow(vm: PlanVm) {
    var title by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var dur by remember { mutableStateOf(60) }
    var rep by remember { mutableStateOf(0) }
    var tplOpen by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    val durations = listOf(30, 60, 90, 120)
    val repLabel = when (rep) {
        1 -> "↻ " + stringResource(R.string.rep_daily)
        2 -> "↻ " + stringResource(R.string.rep_weekly)
        else -> stringResource(R.string.rep_none)
    }
    var optOpen by remember { mutableStateOf(false) }
    // Sade ekleme satırı: başlık + ⋯ (saat, süre, tekrar, araçlar pencerede) + Ekle
    Row(verticalAlignment = Alignment.CenterVertically) {
        ThemedTextField(
            value = title,
            onValueChange = { title = it },
            placeholder = stringResource(R.string.plan_hint),
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(6.dp))
        ThemedButton(if (time.isNotBlank() || rep != 0) "⋯ •" else "⋯", { optOpen = true })
        Spacer(Modifier.width(6.dp))
        ThemedButton(
            text = stringResource(R.string.plan_add),
            onClick = {
                val t = title.trim()
                if (t.isNotEmpty()) {
                    vm.add(t, parseTime(time) ?: -1, dur, rep)
                    title = ""
                    time = ""
                }
            },
            sound = SoundKind.SUCCESS
        )
    }
    if (optOpen) androidx.compose.material3.AlertDialog(
        onDismissRequest = { optOpen = false },
        confirmButton = { ThemedButton(stringResource(R.string.pin_ok), { optOpen = false }) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemedTextField(
                    value = time,
                    onValueChange = { time = it },
                    placeholder = "09:30",
                    modifier = Modifier.fillMaxWidth()
                )
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ThemedButton("⏱ $dur'", { dur = durations[(durations.indexOf(dur) + 1) % durations.size] })
                    ThemedButton(repLabel, { rep = (rep + 1) % 3 })
                }
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ThemedButton("📋", { optOpen = false; tplOpen = true })
                    ThemedButton("📑", { vm.copyDay(); optOpen = false })
                    ThemedButton("🔍", { optOpen = false; searchOpen = true })
                }
            }
        }
    )
    if (tplOpen) TemplateDialog(vm) { tplOpen = false }
    if (searchOpen) SearchDialog(vm) { searchOpen = false }
}

private class Tpl(val label: Int, val steps: List<Triple<Int, Int, Int>>)

private val Templates = listOf(
    Tpl(R.string.tpl_morning, listOf(
        Triple(R.string.tpl_wake, 7 * 60, 15), Triple(R.string.tpl_workout, 7 * 60 + 15, 30),
        Triple(R.string.tpl_breakfast, 7 * 60 + 45, 30))),
    Tpl(R.string.tpl_studyday, listOf(
        Triple(R.string.tpl_planday, 9 * 60, 15), Triple(R.string.tpl_study, 9 * 60 + 15, 90),
        Triple(R.string.tpl_break, 10 * 60 + 45, 15), Triple(R.string.tpl_study, 11 * 60, 90))),
    Tpl(R.string.tpl_evening, listOf(
        Triple(R.string.tpl_read, 21 * 60, 45), Triple(R.string.tpl_sleep, 22 * 60 + 30, 30)))
)

@Composable
private fun TemplateDialog(vm: PlanVm, onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = { ThemedButton("✕", onDismiss) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Templates.forEach { tp ->
                    ThemedButton(stringResource(tp.label), {
                        tp.steps.forEach { (name, start, dur) -> vm.add(ctx.getString(name), start, dur, 0) }
                        onDismiss()
                    }, sound = SoundKind.SUCCESS)
                }
            }
        }
    )
}

@Composable
fun DeleteMark(color: Color, onDelete: () -> Unit) {
    val style = LocalDesign.current.style
    Text(
        "✕",
        color = color,
        fontSize = 16.sp,
        modifier = Modifier
            .plainClick {
                ClickSound.play(style, SoundKind.DELETE)
                onDelete()
            }
            .padding(8.dp)
    )
}

/** Plan düzenleme: başlık, saat, not. */
@Composable
fun EditPlanDialog(p: PlanItem, onDismiss: () -> Unit, onSave: (PlanItem) -> Unit) {
    var title by remember { mutableStateOf(p.title) }
    var time by remember { mutableStateOf(if (p.hasTime) fmtTime(p.startMin) else "") }
    var note by remember { mutableStateOf(p.note) }
    var color by remember { mutableStateOf(p.color) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            ThemedButton(stringResource(R.string.pin_ok), {
                val t = title.trim()
                if (t.isNotEmpty()) onSave(p.copy(title = t, startMin = parseTime(time) ?: -1, note = note.trim(), color = color))
            })
        },
        dismissButton = { ThemedButton("✕", onDismiss) },
        text = {
            androidx.compose.foundation.layout.Column(
                Modifier.verticalScroll(rememberScrollState())
            ) {
                ThemedTextField(title, { title = it }, stringResource(R.string.plan_hint), Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                ThemedTextField(time, { time = it }, "09:30", Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                ThemedTextField(note, { note = it }, "📝", Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    androidx.compose.foundation.layout.Box(
                        Modifier.size(30.dp)
                            .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f), androidx.compose.foundation.shape.CircleShape)
                            .plainClick { color = 0 },
                        contentAlignment = Alignment.Center
                    ) { Text(if (color == 0) "✓" else "∅", fontSize = 14.sp) }
                    PlanPalette.forEachIndexed { i, c ->
                        androidx.compose.foundation.layout.Box(
                            Modifier.size(30.dp)
                                .background(c, androidx.compose.foundation.shape.CircleShape)
                                .plainClick { color = i + 1 },
                            contentAlignment = Alignment.Center
                        ) { if (color == i + 1) Text("✓", color = Color.White, fontSize = 15.sp) }
                    }
                }
                Spacer(Modifier.height(6.dp))
                val tagCtx = androidx.compose.ui.platform.LocalContext.current
                val tags = remember { PlanEmoji.list(tagCtx) }
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    tags.forEach { e ->
                        ThemedButton(e, { title = PlanEmoji.tagged(title, e, tags) })
                    }
                }
            }
        }
    )
}

@Composable
private fun SearchDialog(vm: PlanVm, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val res = if (q.isBlank()) emptyList()
    else vm.items.filter { it.title.contains(q.trim(), ignoreCase = true) }.sortedByDescending { it.date }.take(30)
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = { ThemedButton("✕", onDismiss) },
        text = {
            Column {
                ThemedTextField(q, { q = it }, "🔍", Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                androidx.compose.foundation.lazy.LazyColumn(
                    Modifier.heightIn(max = 360.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(res.size) { idx ->
                        val p = res[idx]
                        ThemedButton(
                            p.date.format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())) +
                                "  " + (if (p.hasTime) fmtTime(p.startMin) + " " else "") + p.title,
                            { vm.pickDay(p.date); onDismiss() },
                            Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    )
}
