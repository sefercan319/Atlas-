package com.odak.app.block

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.app.AppOpsManager
import android.os.PowerManager
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.odak.app.logic.PermNeeds
import com.odak.app.logic.PermStep
import com.odak.app.theme.ThemedCard
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.Launch
import com.odak.app.R
import com.odak.app.logic.PermKind
import com.odak.app.logic.PermPlan
import com.odak.app.theme.QuietAction
import com.odak.app.theme.Text
import com.odak.app.theme.ThemedButton

/** "İzin ver" → doğru ayar sayfasını doğrudan açar (ara menü yok), ne yapılacağını kısa bir mesajla söyler. */
object PermGo {
    private fun new(a: String) = Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun granted(c: Context, kind: PermKind): Boolean = try {
        when (kind) {
            PermKind.ACC -> BlockStore.a11yEnabled(c)
            PermKind.USAGE -> BlockStore.usageAccess(c)
            PermKind.NOTIF -> androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
            PermKind.BATT -> (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
        }
    } catch (e: Exception) { false }

    /** Yan yüklenen uygulamada Android 13+ "kısıtlı ayar" engeli var mı (bilinmiyorsa false). */
    fun restricted(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 33) return false
        return try {
            val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val m = ops.unsafeCheckOpNoThrow("android:access_restricted_settings", android.os.Process.myUid(), c.packageName)
            m == AppOpsManager.MODE_ERRORED || m == AppOpsManager.MODE_IGNORED
        } catch (e: Exception) { false }
    }

    private fun stepText(c: Context, kind: PermKind): String {
        val detail = PermPlan.hasDetailPage(kind, Build.VERSION.SDK_INT)
        return c.getString(when (PermPlan.stepKey(kind, detail)) {
            "pg_acc_steps_d" -> R.string.pg_acc_steps_d
            "pg_acc_steps" -> R.string.pg_acc_steps
            "pg_usage_steps" -> R.string.pg_usage_steps
            "pg_notif_steps_d" -> R.string.pg_notif_steps_d
            "pg_notif_steps" -> R.string.pg_notif_steps
            else -> R.string.pg_batt_steps
        })
    }

    /** İzin verme düğmesi: tek dokunuşla doğru sayfa + ne yapılacağı. */
    fun grant(c: Context, kind: PermKind) {
        if (granted(c, kind)) { Toast.makeText(c, c.getString(R.string.pg_done), Toast.LENGTH_SHORT).show(); return }
        if (PermPlan.firstStep(kind, Build.VERSION.SDK_INT, restricted(c)) == PermStep.APP_INFO) {
            appInfo(c)
            Toast.makeText(c, c.getString(R.string.pg_restricted), Toast.LENGTH_LONG).show()
            return
        }
        open(c, kind)
        Toast.makeText(c, stepText(c, kind), Toast.LENGTH_LONG).show()
    }

    fun open(c: Context, kind: PermKind): Boolean {
        val sdk = Build.VERSION.SDK_INT
        return when (kind) {
            PermKind.ACC -> {
                val cn = ComponentName(c, OdakAccessibilityService::class.java)
                (sdk >= 34 && Launch.go(c, new("android.settings.ACCESSIBILITY_DETAIL_SETTINGS")
                    .putExtra(Intent.EXTRA_COMPONENT_NAME, cn.flattenToString()))) ||
                    Launch.go(c, new(Settings.ACTION_ACCESSIBILITY_SETTINGS).also { highlight(it, cn) })
            }
            PermKind.USAGE ->
                Launch.go(c, new(Settings.ACTION_USAGE_ACCESS_SETTINGS).setData(Uri.parse("package:" + c.packageName))) ||
                    Launch.go(c, new(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            PermKind.NOTIF -> {
                val cn = ComponentName(c, OdakNotifService::class.java)
                (sdk >= 30 && Launch.go(c, new(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                    .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, cn.flattenToString()))) ||
                    Launch.go(c, new(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).also { highlight(it, cn) })
            }
            PermKind.BATT ->
                Launch.go(c, new(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).setData(Uri.parse("package:" + c.packageName))) ||
                    Launch.go(c, new(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    /** Liste sayfasında Atlas satırını işaretlemeyi dener (destekleyen telefonlarda). */
    private fun highlight(i: Intent, cn: ComponentName) {
        val key = cn.flattenToString()
        i.putExtra(":settings:fragment_args_key", key)
        i.putExtra(":settings:show_fragment_args", Bundle().apply { putString(":settings:fragment_args_key", key) })
    }

    fun appInfo(c: Context) = Launch.go(c, new(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + c.packageName)))
}

/** Eski çağrı yerleri için: görününce izin sayfasını hemen açar (pencere yok), sonra kendini kapatır. */
@Composable
fun PermGrantNow(kind: PermKind, onDone: () -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(kind) { PermGo.grant(ctx, kind); onDone() }
}

/** Bir özelliğin gereken izinlerini durumlarıyla listeler; her satırda tek dokunuşla doğru ayar sayfasına götüren düğme. */
@Composable
fun PermNeedCard(needs: List<Pair<PermKind, Boolean>>) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(emptySet<PermKind>()) }
    LaunchedEffect(Unit) {
        while (true) {
            granted = PermKind.values().filter { PermGo.granted(ctx, it) }.toSet()
            kotlinx.coroutines.delay(1000)
        }
    }
    val missing = PermNeeds.missing(needs, granted)
    if (missing.isEmpty()) return
    val sdk = Build.VERSION.SDK_INT
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.pw_title))
        for ((kind, required) in needs) {
            Spacer(Modifier.height(10.dp))
            val ok = kind in granted
            val name = stringResource(when (kind) { PermKind.ACC -> R.string.perm_acc; PermKind.USAGE -> R.string.perm_usagename; PermKind.NOTIF -> R.string.notif_hide; PermKind.BATT -> R.string.perm_batt })
            val why = stringResource(when (kind) { PermKind.ACC -> R.string.pw_acc; PermKind.USAGE -> R.string.pw_usage; PermKind.NOTIF -> R.string.pw_notif; PermKind.BATT -> R.string.pw_batt })
            val tag = stringResource(if (required) R.string.perm_required else R.string.perm_optional)
            Text((if (ok) "✔ " else "✖ ") + name + " · " + tag)
            Text(why)
            if (!ok) {
                Spacer(Modifier.height(6.dp))
                ThemedButton(stringResource(R.string.block_grant), { PermGo.grant(ctx, kind) })
                if (PermPlan.mayBeRestricted(kind, sdk)) QuietAction(stringResource(R.string.pg_appinfo_gray), { PermGo.appInfo(ctx) })
            }
        }
    }
}
