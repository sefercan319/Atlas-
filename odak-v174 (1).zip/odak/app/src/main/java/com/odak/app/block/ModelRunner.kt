package com.odak.app.block

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.odak.app.logic.ModelPure
import java.io.File

/** İndirilen .litertlm modelini LiteRT-LM ile cihazda çalıştırır. Motor bir kez yüklenir, sonraki sorularda yeniden kullanılır. */
object ModelRunner {
    private var engine: Engine? = null
    private var enginePath: String? = null

    fun available(c: Context): Boolean = ModelDownloader.find(c, ".litertlm") != null

    @Synchronized private fun engineFor(c: Context, f: File): Engine {
        engine?.let { if (enginePath == f.path) return it }
        release()
        val cfg = EngineConfig(modelPath = f.path, backend = Backend.GPU(), cacheDir = c.cacheDir.path)
        val e = Engine(cfg); e.initialize()
        engine = e; enginePath = f.path
        return e
    }

    /** Bellek gerekirse (veya model silinirse) motoru kapatır. */
    @Synchronized fun release() { try { engine?.close() } catch (t: Throwable) { }; engine = null; enginePath = null }

    @Synchronized fun ask(c: Context, prompt: String): Result<String> = try {
        val f: File = ModelDownloader.find(c, ".litertlm") ?: error("model yok")
        if (!ModelPure.runnable(f.name)) error(".litertlm değil")
        val e = engineFor(c, f)
        e.createConversation().use { cv -> Result.success(cv.sendMessage(prompt).toString()) }
    } catch (t: Throwable) { release(); Result.failure(t) }

    /** Adaylardan modelin seçtikleri (en çok 3). */
    fun rank(c: Context, feature: String, app: String, entries: List<String>): List<String> {
        val shown = entries.take(12)
        val r = ask(c, ModelPure.probePrompt(feature, app, shown)).getOrNull() ?: return emptyList()
        return ModelPure.parsePicks(r, shown.size).map { shown[it] }
    }
}
