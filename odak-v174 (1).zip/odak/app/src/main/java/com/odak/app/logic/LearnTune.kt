package com.odak.app.logic

/**
 * Eğitim araç takımı (saf mantık): otomatik hiperparametre ayarı (çapraz doğrulamalı ızgara araması),
 * öğrenme eğrisi (veri arttıkça F1) ve sürüm kontrol noktaları (kötüleşen eğitimi geri alma).
 */
object LearnTune {
    const val MIN_EXAMPLES = 40
    class Params(val lr: Double, val l2: Double)
    class Tuned(val best: Params, val f1: Int, val tried: Int)

    val LRS = listOf(0.02, 0.05, 0.1)
    val L2S = listOf(0.0003, 0.001, 0.01)

    /** k katlı çapraz doğrulamada ortalama F1 (%) — verilen parametrelerle Adam eğitimi. */
    fun cvF1(ex: List<LearnPure.Ex>, p: Params, k: Int = 4, epochs: Int = 15): Int {
        var s = 0
        val seen = IntArray(2)   // sınıf içi sıra: katlar her iki sınıftan dengeli (dönüşümlü sıralı veride de)
        val fold = IntArray(ex.size) { i -> val c = if (ex[i].label) 1 else 0; (seen[c]++) % k }
        for (f in 0 until k) {
            val va = ex.filterIndexed { i, _ -> fold[i] == f }; val tr = ex.filterIndexed { i, _ -> fold[i] != f }
            s += LearnPure.metrics(LearnPlus.trainAdam(tr, epochs, null, 0, null, p.l2, p.lr), va).f1
        }
        return s / k
    }

    /** Izgara araması; beraberlikte daha güçlü düzenlileştirme (daha genel model) kazanır. Az veride null. */
    fun tune(ex: List<LearnPure.Ex>): Tuned? {
        if (ex.size < MIN_EXAMPLES || ex.none { it.label } || ex.all { it.label }) return null
        var best = Params(0.05, 0.001); var bf = -1; var n = 0
        for (lr in LRS) for (l2 in L2S) {
            val f = cvF1(ex, Params(lr, l2)); n++
            if (f > bf || (f == bf && l2 > best.l2)) { bf = f; best = Params(lr, l2) }
        }
        return Tuned(best, bf, n)
    }

    /** Veri oranlarına göre F1 (%); her oranda ilk [frac] kısmıyla eğitilir, sabit doğrulama kümesinde (her 5. örnek) ölçülür. */
    fun curve(ex: List<LearnPure.Ex>, fracs: List<Double> = listOf(0.25, 0.5, 0.75, 1.0)): List<Int>? {
        if (ex.size < MIN_EXAMPLES) return null
        val (tr, va) = LearnPure.split(ex)
        if (va.none { it.label } || tr.none { it.label }) return null
        return fracs.map { fr -> LearnPure.metrics(LearnPlus.trainAdam(tr.take(maxOf(4, (tr.size * fr).toInt())), 25), va).f1 }
    }

    /** 1: daha çok veri yardım eder (son adımlarda hâlâ yükseliyor), 2: doygun. */
    fun verdict(curve: List<Int>): Int = if (curve.size >= 3 && curve.last() - curve[curve.size - 3] >= 5) 1 else 2

    class Ckpt(val ts: Long, val f1: Int, val w: DoubleArray)
    fun encode(c: Ckpt) = "${c.ts}\t${c.f1}\t${LearnPure.encodeW(c.w)}"
    fun decode(l: String): Ckpt? = try { l.split('\t').let { Ckpt(it[0].toLong(), it[1].toInt(), LearnPure.decodeW(it[2]) ?: return null) } } catch (e: Exception) { null }
    fun push(list: List<Ckpt>, c: Ckpt, max: Int = 3): List<Ckpt> = (list + c).takeLast(max)

    /** Yeni eğitimin F1'i son sürümden [tol] puandan fazla kötüyse eski sürüm korunur. */
    fun rollbackNeeded(newF1: Int, last: Ckpt?, tol: Int = 8): Boolean = last != null && newF1 < last.f1 - tol
}
