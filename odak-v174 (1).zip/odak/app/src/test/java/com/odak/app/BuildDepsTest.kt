package com.odak.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class BuildDepsTest {
    private val root: File get() = File(TestFiles.main, "../../..").canonicalFile
    private val gradle get() = File(root, "app/build.gradle.kts").readText()

    @Test fun mlLibrariesDeclared() {
        assertTrue(gradle.contains("com.google.ai.edge.litertlm:litertlm-android"))
        assertTrue(gradle.contains("com.github.haifengl:smile-core")); assertTrue(gradle.contains("org.apache.commons:commons-math3")); assertTrue(gradle.contains("com.microsoft.onnxruntime:onnxruntime-android")); assertTrue(gradle.contains("org.tensorflow:tensorflow-lite") && gradle.contains("org.pytorch:pytorch_android_lite") && gradle.contains("org.pytorch:executorch-android"))
        assertTrue(gradle.contains("exclude(group = \"org.bytedeco\")"))
    }
    @Test fun packagingAndAbiKeepApkInstallable() {
        assertTrue(gradle.contains("abiFilters += listOf(\"arm64-v8a\")"))
        assertTrue(gradle.contains("packaging") && gradle.contains("META-INF/DEPENDENCIES") && gradle.contains("pickFirsts"))
    }
    @Test fun workflowKeepsLogsAndFallback() {
        val wf = File(root, ".github/workflows/build-apk.yml").readText()
        assertTrue(wf.contains("build-logs") && wf.contains("PIPESTATUS") && wf.contains("if-no-files-found: error"))
        assertTrue(wf.contains("bir önceki zip deneniyor"))
    }
    @Test fun gradleMemoryRaised() {
        assertTrue(File(root, "gradle.properties").readText().contains("-Xmx4096m"))
    }

    @Test fun noUnescapedApostropheInStrings() {
        val bad = ArrayList<String>()
        File(root, "app/src/main/res").listFiles { f -> f.name.startsWith("values") }!!.forEach { d ->
            File(d, "strings.xml").takeIf { it.exists() }?.readLines()?.forEachIndexed { i, l ->
                val m = Regex("<string[^>]*>(.*)</string>").find(l) ?: return@forEachIndexed
                if (Regex("(?<!\\\\)'").containsMatchIn(m.groupValues[1])) bad.add("${d.name}:${i + 1}")
            }
        }
        assertTrue("kaçışsız kesme işareti: $bad", bad.isEmpty())
    }
    @Test fun everyComposableFileImportsComposable() {
        val bad = File(root, "app/src/main/java").walkTopDown().filter { it.extension == "kt" }.filter { f ->
            val t = f.readText(); t.contains("@Composable") && !t.contains("import androidx.compose.runtime.Composable") && !t.contains("import androidx.compose.runtime.*")
        }.map { it.name }.toList()
        assertTrue("Composable import eksik: $bad", bad.isEmpty())
    }

    @Test fun knownUnresolvedApisStayFixed() {
        val perm = File(root, "app/src/main/java/com/odak/app/block/PermGuide.kt").readText()
        assertTrue(!perm.contains("Settings.ACTION_ACCESSIBILITY_DETAIL_SETTINGS") && perm.contains("android.settings.ACCESSIBILITY_DETAIL_SETTINGS"))
        val mr = File(root, "app/src/main/java/com/odak/app/block/ModelRunner.kt").readText()
        assertTrue(!mr.contains("sendMessage(prompt).text") && mr.contains("sendMessage(prompt).toString()"))
    }

    @Test fun duplicateClassAndNativeLibGuards() {
        assertTrue(gradle.contains("fbjni-java-only") && gradle.contains("configurations.all"))
        for (lib in listOf("libtensorflowlite_jni.so", "libonnxruntime.so", "libfbjni.so", "libc++_shared.so")) assertTrue(lib, gradle.contains(lib))
    }
}
