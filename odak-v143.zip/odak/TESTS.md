# Testler

Çalıştırma (GitHub Actions bunu her derlemeden önce otomatik yapar):

    gradle testDebugUnitTest --no-daemon

## Ne test ediliyor

| Dosya | Kapsam |
|---|---|
| `PureLogicTest` | Kural eşleştirme (+istisna), sessiz saat, süre limiti/uyarı eşiği, saat çevirme, emoji etiketi, alışkanlık serisi |
| `RulesFileTest` | `block_rules.json` ↔ katalog tutarlılığı; her özelliğin kuralı var mı; çok genel parça yok mu |
| `CatalogSourceTest` | Uygulama kataloğu: tekrarlı id/paket, geçersiz paket adı, ≥65 uygulama, büyük uygulamaların özellik sayısı |
| `ResourcesTest` | 8 dilde aynı anahtarlar, boş çeviri, `%d` yer tutucuları, kodda kullanılan her `R.string` tanımlı mı, manifest sınıfları, ses dosyaları |

## Kural: her yeni şeyde test ekle

1. Yeni mantık → `logic/Pure.kt` içine koy, `PureLogicTest`'e en az bir olumlu, bir olumsuz, bir sınır durumu testi yaz.
2. Yeni uygulama / özellik → kataloğa ekle **ve** `block_rules.json`'a kural yaz (aksi halde `everyFeatureHasARule` kırılır).
3. Yeni metin → 8 dilde de ekle (aksi halde `everyLanguageHasSameKeys` kırılır).
4. Yeni tasarım → 4 ses dosyası ekle (`everySoundResourceExistsForEveryDesign`).
5. Yeni sınıf (servis/alıcı) → manifest'e ekle (`manifestClassesExist`).

## Kural doğrulama durumu

`block_rules.json` içindeki `_verified` listesi, açık kaynak projelerde (short-video-rules, Scrollhalt) belgelenmiş
kimliklerle uyuşan kuralları gösterir. Listede olmayanlar tahmindir; yanlış çıkarsa "Ekran kimliklerini kaydet" ile
gerçek kimlikleri toplayıp düzeltin.

## v0.36 eklenenler
- Snap eşleşmesi (`desc:` / `text:` / kimlik, istisna, boş önek), `Pure.derive` (Kural Lab türetme), `Pure.topSlices`, `Pure.pctChange` — PureLogicTest.
- Yeni stringler (rl_*, st_unlocks/st_avg/st_other) ResourcesTest ile 9 dilde doğrulanır.
- Elle: Kural Lab (🎯) ile bir bölümü kaydet; user_rules.json oluşur ve engelleme çalışır.

## v0.37
- staleDayKey (günlük anahtar temizliği) PureLogicTest; ManifestTest (alarm yeniden kurma eylemleri, servis izinleri).

## v0.38
- Katalog >=135 uygulama; Pure.nameMatches (arama).

## v0.39
- Katalog >=190 uygulama (paketler Play Store ile doğrulandı).
- 20 yeni özellik: Pure.nightMs/perUnlockMs/barFractions/pct/todoOrder/isOverdue/moveOverdue/parseQuickDue/weekRate/bestStreak/waterFraction/overlaps/conflictIndexes/freeSlot/totalPlanned/fmtDur/summaryText testli.

## v0.40
- Pure.niceStepMin/axisMaxMs/slicePct (grafik ekseni) testli.

## v0.41
- Pure.isLandscape (yatay düzen eşiği), ManifestTest: MainActivity configChanges (dönünce yeniden oluşturulmaz, yön kilitli değil).
- Elle dene: telefonu yan çevir; yan şerit, Ekran Süresi iki sütun, Görev/Engel/Ayar 720dp ortalı.

## v0.42
- Pure.winClass/useRail/contentMaxDp/pomoLeftMs, ManifestTest: resizeableActivity, alarm/boot izinleri.
- Elle dene: çok pencere/katlanır/tablet; Pomodoro başlat, uygulamayı kapat, bildirimin geldiğini ve sayacın doğru devam ettiğini gör.

## v0.44 — Özel bildirim/uyarı metinleri
- PureLogicTest.fillTplReplacesPlaceholders / msgOrDefaultFallsBack
- MsgsSourceTest (her tür bağlı + tüm dillerde etiket)

## v0.45 — +334 test (BulkLogicTest)
Tablo tabanlı: parseTime/fmtTime/inQuiet, autoScale/effectiveScale, pct/slicePct/perUnlock/nightMs/barFractions, winClass/useRail/isLandscape/contentMaxDp, niceStep/axisMax, fmtDur/totalPlanned/overlaps/freeSlot, nameMatches/fillTpl/msgOrDefault, waterFraction, inWarnWindow/limitReached, staleDayKey, pomoLeft, pctChange, streak; 9 dil dosyası × 5 kontrol. Toplam 414 test.

## v0.46 — +323 test (AppIntegrityTest)
- Katalogdaki her uygulama için ayrı test (ad, geçerli paket adı, kendi paketimiz değil) — 194 test
- Her Kotlin kaynak dosyası için 3 test: paket adı yolla uyumlu, parantez/süslü parantez dengeli (yorum ve dizgeler çıkarılarak), kalıntı println/TODO/printStackTrace yok — 129 test

## v0.47 — Hata avı düzeltmeleri (BugFixTest)
- Sessiz saat: gece yarısını aşan aralıkta sabah saatleri bir önceki günün seçimine bağlı (quietActive)
- Ekran süresi: aynı uygulamada etkinlik geçişi yeni "açılış" sayılmaz; hâlâ açık uygulamanın süresi aralık sonuna kadar eklenir
- Özellik süre sınırı: uygulamadan ayrılıp dönünce haksız +3 sn eklenmez (featDelta)

## v0.48 — Tam yedek v2 (BackupTest)
- Yedek artık engel ayarları, renkler, özel metinler, ölçek vb. tüm tercihleri içerir; PIN dahil edilmez
- İçe aktarma önce doğrular (tür, dosya izin listesi, JSON dizisi), sonra yazar; hatalı dosyada hiçbir şey değişmez
- Dışa/içe aktarma hataları artık çökmez, ✗ gösterir

## v0.49 — Bildirim eylemi (NotifActionsTest)
- Plan hatırlatma bildirimine "Tamamlandı" düğmesi (planı bildirimden bitirir, pencere öğesi yenilenir)
- Sabah özetinde geciken görev sayısı (⚠ n) ve {overdue} yer tutucusu

## v0.50 — Belgeler okuyucusu (DocParseTest, DocUiSourceTest)
- Okunan biçimler: PDF (Android PdfRenderer), docx/dotx/docm, pptx/potx/ppsx/pptm, xlsx/xlsm, vsdx, odt/odp/ods/odg/odf, rtf, txt/csv/md, Google (.gdoc/.gsheet/.gslides/.gform → bağlantı), eski ikili (doc/ppt/xls/wps/dps/et → kaba metin), pub/one/odb → yalnızca "başka uygulamada aç"
- Gerçek zip/XML üretilerek 61 ayrıştırma testi; XXE/DOCTYPE, bozuk dosya, boş girdi, 40 MB sınırı sınanır
- "Başka uygulamada aç" ve VIEW filtresi (dosya yöneticisinden Odak ile aç)

## v0.51 — Eski biçimler, Publisher, OneNote, Base (OleDocTest)
- docs/OleDoc.kt: OLE/CFB okuyucu; .doc (parça tablosuyla birebir metin), .xls (SST+CONTINUE, sayı/RK/formül önbelleği/mantık), .ppt (slayt metinleri). WPS (.wps/.et/.dps) aynı yapıyı kullanır
- Gerçek LibreOffice dosyaları src/test/fixtures/ içinde (fx.doc, fx.xls, fx.ppt); Türkçe karakter, tablo, 2500 satırlık CONTINUE kaydı sınanır
- .pub: Quill/Contents akışından kaba metin; .one: UTF-16 kaba metin (gerçek dosyayla SINANMADI)
- .odb: HSQLDB betiğinden tablo ve satırlar (gerçek .odb ile SINANMADI; satırlar ikili dosyada tutulmuşsa yalnızca tablo yapısı görünür)

## v0.52 — sağlamlaştırma ve toplu testler
Düzeltmeler:
- `Pure.fillTpl`: tek geçişli doldurma (bir değerin içindeki `{x}` yeniden doldurulmaz); 200 karakter sınırı vekil çiftini bölmez.
- `DocParse.safeGoogleUrl`: ters eğik çizgi, boşluk, `@` (kullanıcı bilgisi) ve geçersiz karakterli adresler reddedilir; alan adı küçük harfe çevrilir.

Yeni test dosyaları (4533 test, beklenen değerler bağımsız Python hesabından):
- ScaleGenTest (318): autoScale / effectiveScale ızgarası
- QuietGenTest (2240): sessiz saat + gün maskesi (gece yarısını aşan aralıklar dahil)
- TplGenTest (175): bildirim şablonları, varsayılan metin, uzunluk sınırı
- OpenFeatGenTest (135): isNewOpen / featDelta
- BackupGenTest (25): yedek dosya izin listesi, JSON dizisi ön kontrolü
- DocGenTest (1640): uzantı/imza tespiti, colIndex, Google adres güvenliği, son açılanlar

Sandbox toplamı: 5403 geçti, 0 kalan. Cihazda çalıştırılmadı.

## v0.53 — özellik süresi dolunca ana sayfaya dön
- `Pure.isHomeLabel`, `Pure.featExit`: ana sayfa sekmesi etiketleri (8 dil) ve çıkış kararı (ayar açık + en çok 2 deneme → ana sekme, aksi halde geri tuşu).
- Servis: süre/engel dolunca önce ana sayfa sekmesine tıklar; bulamazsa geri tuşuna düşer. Özellik ekrandan çıkınca deneme sayacı sıfırlanır.
- Ayar: Uyarılar ekranında "Özelliğin süresi bitince uygulamada kal, ana sayfaya dön" (varsayılan açık).
- HomeExitTest (51): etiketler, karar tablosu, kaynak bağlantıları, 9 dilde metin.
Sandbox toplamı: 5454 geçti, 0 kalan. Cihazda çalıştırılmadı.

## v0.54 — Not defteri (Samsung Notes tarzı) + belge okuyucu birleşik
Yeni: `notes/` (NotePure, NoteStore, NoteEditor, NotesList, NotesActivity). Ayarlar → Not defteri; iki sekme: Notlar / Belgeler (belge okuyucu burada).
- Notlar: başlık + metin, yapılacak maddeleri (☐/☑), el yazısı (kalem, fosforlu, kurşun kalem, silgi, geri al/yinele, 6 mürekkep rengi, 3 kalınlık, kaydırma aracı), 4 kâğıt türü (düz/çizgili/kareli/noktalı), not rengi, sabitleme, klasör, arama, PIN ile kilit, 30 gün çöp kutusu, metin olarak paylaşma, otomatik kaydetme.
- Saklama: her not ayrı dosya (`files/notes/<id>.odn`), atomik yazma, bozuk dosya yalnızca kendini etkiler.
Testler: NotePureTest (55, el yazımı), NoteGenTest (1905: 800 gidiş-dönüş/özellik testi rastgele notlarla + Python hesaplı tablolar).
Sandbox toplamı: 7413 geçti. Compose ekranları yalnızca sözdizimi denetiminden geçti; cihazda ve derlemede denenmedi.

## v0.55 — Not defteri: kalem basıncı, resim, ses kaydı, PDF üstüne yazma, resim/PDF paylaşma
- Kalem basıncı: yalnızca kalemle (stylus) gelen basınç kaydedilir (`Pt.p`); çizgi kalınlığı `pressW` ile %35–%100 arası değişir. Parmakta ve fosforlu kalemde sabit.
- Resim: galeriden seç, 1600 px'e küçült, sayfada taşı/büyüt/küçült/sil (✥ aracı).
- Ses kaydı: mikrofon izni istenir, m4a (AAC), en çok 1 saat, listeden dinle/sil.
- PDF üstüne yazma: PDF uygulama klasörüne kopyalanır (en çok 100 MB, doğrulanır), sayfalar tembel çizilir; çizgiler sayfa yerleşimine göre saklanır; "PDF olarak paylaş" çizimlerle yeni PDF üretir.
- Resim olarak paylaş: not (kâğıt+resim+çizim) PNG; FileProvider yalnızca cache/share.
- Güvenlik: dosya adları `safeFile` ile doğrulanır (yol kaçışı yok), kalıcı silmede ekler de silinir.
Testler: NoteMediaTest (27), NoteMediaGenTest (1162: gidiş-dönüş, basınç, fitSize, süre, PDF yerleşimi, resim taşıma/ölçekleme, dosya adı), NoteMediaSourceTest (15).
Sandbox toplamı: 8618 geçti, 0 kalan. Compose/Android kodu (kayıt, PDF, paylaşım) yalnızca sözdizimi denetiminden geçti; cihazda denenmedi.

## v0.56 — Atlas + dosya dönüştürme
- Uygulama adı **Atlas** (9 dilde app_name ve görünen metinler; gradle kök adı, APK artifact adı). Sınıf/paket adları değişmedi.
- Dönüştürme: TXT, MD, HTML, CSV, RTF, DOCX, XLSX, PPTX, ODT, ODS, ODP, PDF; PDF kaynak → sayfa PNG'leri (zip). Yalnızca metin ve tablolar taşınır; düzen, resim, biçim taşınmaz. PDF'ten metin çıkarılamaz. Google/okunamayan dosyalar dönüştürülemez.
- Yazıcılar saf Kotlin (`DocWrite`), PDF Android `PdfDocument` ile (`DocPdf`). Kaydetme: sistem "Farklı kaydet" penceresi.
- Doğrulama: python-docx/openpyxl/python-pptx/LibreOffice ile açıldı.
Testler: DocWriteTest (64), DocWriteGenTest (4: 60 rastgele belge × 8 biçim gidiş-dönüş, XML geçerliliği, kontrol karakterleri).
Sandbox toplamı: 8686 geçti, 0 kalan. ConvertBar/DocPdf cihazda denenmedi.

## v0.56.1 — PDF → tüm biçimler, büyük dosya
- PDF'ten yazı çıkarılır (pdfbox-android, geçici dosya modu) ve TXT/MD/HTML/CSV/RTF/DOCX/XLSX/PPTX/ODT/ODS/ODP'ye çevrilir; PNG zip de durur. Taranmış (resim) PDF'te yazı yoktur → "taranmış olabilir" uyarısı (OCR yok).
- Sınırlar: PDF açma/dönüştürme boyut sınırsız (dosyadan akıtılır). Diğer belgeler bellekte okunur: 40 → 256 MB, `largeHeap` açık. 2 GB bellekte mümkün değil.
Testler: DocWriteTest +8 (toplam 72), DocParseTest sınır testi küçük tavanla. Sandbox toplamı: 8694 geçti, 0 kalan. pdfbox ve arayüz cihazda denenmedi.

## v0.56.2 — 3 GB+ dosya
- Belge 32 MB üstündeyse bellekte tutulmaz: /proc/self/fd üzerinden (kopyasız) ya da cache'e akıtılarak açılır; DOCX/XLSX/PPTX/ODF için `ZipFile` (ZIP64, rastgele erişim) ile yalnız XML parçaları okunur, resim/medya hiç açılmaz. Gerçek denemede 3,3 GB'lık DOCX 128 MB yığınla 39 ms'de açıldı.
- Düz metin 256 MB üstünde: ilk 64 MB okunur, "eksik olabilir" uyarısı. Eski OLE (DOC/XLS/PPT) 256 MB'a kadar. PDF sınırsız.
- XML girdisi 128 MB üstündeyse reddedilir (zip bombası koruması).
Testler: DocBigFileTest (11). Sandbox toplamı: 8705 geçti, 0 kalan. Telefonda denenmedi (fd yolu sağlayıcıya göre değişebilir).

## v0.56.3 — büyük dosyada resim, grafik, diyagram; çok büyük düz metin
- Belgedeki **resimler** (DOCX/PPTX/XLSX/ODF) yalnız ekrana gelince, küçültülerek (örnekleme) zip'ten okunur; dokununca tam ekran/yakınlaştırma. Büyük dosyada ZipFile oturum boyunca açık kalır. Android'in çözemediği biçimler (EMF/WMF/SVG/TIFF) için uyarı gösterilir.
- **Grafikler** (çubuk, yatay çubuk*, çizgi, alan, pasta/halka, dağılım) hem OOXML (DOCX/PPTX/XLSX) hem ODF (ODS/ODT/ODP) için veriden çizilir; dokununca veri tablosu. (*yatay çubuk şimdilik dikey çizilir.) Grafikte kayıtlı (önbellek) veri yoksa gösterilemez.
- **Diyagramlar**: SmartArt (kayıtlı çizim) ve Visio (.vsdx) şekilleri/bağlantıları kutu-çizgi olarak çizilir. Slayt şekilleri, çizim tuvalleri, formül nesneleri çizilmez.
- Resim/grafik/diyagram sayfa metninden sonra gösterilir (metin içindeki yerine değil). Arama yaparken gizlenir.
- 256 MB üstü **düz metin** (GB'lar): 1 MB'lık pencereler, sürgü, ◀ ▶, dosya içinde arama; tamamı belleğe alınmaz. UTF-8 varsayılır.
Testler: DocVisualTest (64), DocVisualGenTest (5: 300 rastgele grafik gidiş-dönüş, aralık/pasta özellikleri, Visio, yol çözümü), BigTextTest (21: pencere örtüşmesiz tam kapsama, çok baytlı karakter, 3 GB üstü ofset, parça sınırında arama).
Sandbox toplamı: 8795 geçti, 0 kalan. Gerçek DOCX/PPTX/XLSX (python-docx/pptx/openpyxl) ve LibreOffice ODF dosyalarıyla doğrulandı. Compose çizimleri (ImageBlock/ChartBlock/DiagramBlock/BigTextView) cihazda denenmedi.

## v0.56.4 — Kodlama doğrulama, TIFF / EMF / WMF / SVG
- BigTextTest (36): BOM, UTF-16 (BOM'suz dahil), UTF-8 geçerlilik örneklemesi (baş/orta/son), Windows-1254 geri dönüşü, pencere/arama kodlamaya duyarlı.
- TiffDecoderTest (10): PIL/ImageMagick ile piksel-piksel eşleşen gerçek TIFF'ler (sıkıştırmasız, PackBits, LZW, Deflate, paletli, 16-bit, RGBA).
- MetafileTest (~50): LibreOffice'in ürettiği gerçek EMF/WMF dosyaları (şekil, renk, metin, bitmap yönü), elle üretilmiş kayıtlar (eşleme modları, pencere başlangıcı, dünya dönüşümü, yollar, ARCTO, DIB 1/4/8/24/32, STRETCHDIBITS, WMF kayıtları), bozuk/kesik girdi asla hata fırlatmaz (fuzz).
- Düzeltilen hata: 16-bit çokgen/çizgi kayıtlarında y koordinatı yanlış ofsetten okunuyordu.
- DocVisualTest: imageKind (bitmap/tiff/meta/svg), isDecodable güncellendi; kaynak denetimleri: decodeSampled yönlendirmesi, androidsvg bağımlılığı.
- Doğrulanmadı: MetaRender/SvgRender (Android çizimi) yalnızca sözdizimi denetimli.

## v0.56.5 — TIFF (CCITT, JPEG, BigTIFF) ve EMF/WMF eklentileri
- TiffExtTest (13): libtiff/ImageMagick/PIL ile üretilmiş gerçek dosyalar — CCITT MH, Group 3 (1B ve 2B), Group 4 (şeritli, uzun >2560 koşular) piksel-piksel; BigTIFF (ham, LZW, döşemeli, şeritli, G4); JPEG-içi-TIFF (şerit, döşeme, gri; ImageIO ile çözülüp referansa yakınlık); çözücüsüz null, çözücü hata fırlatırsa çökmez, bozuk/kesik girdi (fuzz), Ccitt doğrudan (G4, 1B, çöp veri, saçma boyut).
- MetafileExtTest (~60): RLE8/RLE4 (mutlak, delta, bozuk); kırpma (INTERSECT/EXCLUDE rect, yol, bölge, WMF) ve Save/Restore; desenli fırçalar (tarama, DIB, mono, WMF); GRADIENTFILL; çizgi stilleri; EMF+ (yalnız-EMF+ ve dual ayrımı, dolgu/çizim kayıtları, yol nesneleri, bezier/eğriler, dünya/sayfa dönüşümü, Save/Restore, kırpma, doğrusal gradyan, tarama fırçası, DrawString, resim: piksel/kırpma/sıkıştırılmış, parçalı nesne, fuzz); LibreOffice EMF'inde kırpma/Save dengesi.
- Düzeltme: TIFF CCITT'de siyah koşu = bit 1 (libtiff ile aynı), fotometrik yorumu sonra uygulanır.
- Doğrulanmadı: Android çizim kodu (MetaRender: kırpma, BitmapShader, LinearGradient, DashPathEffect, Img) yalnız sözdizimi denetimli; EMF+ gerçek Windows çıktısıyla değil, şartnameye göre üretilen kayıtlarla test edildi.

## v0.56.6 — Uygulama listesi ve uygulama içi özellik engelleme
- BlockExtTest (19): `sel:` kuralı (alt çubukta SEÇİLİ sekme etiketi; seçili olmayan eşleşmez, büyük/küçük harf, istisnayla birlikte, eski Snap kurucuları), `Pure.deriveSel` (RuleLab artık seçili sekmeden de kural öğretir), katalog ≥ 290 uygulama (105 yeni), yeni özellikler (LinkedIn video/iş ilanları, Netflix oyunlar), kural dosyasında çok dilli sekme etiketleri, doğrulanmış kuralların korunması, servis kaynak denetimi, yeni metinler 8 dilde.
- Doğrulanmadı: `sel:` etiketleri ve yeni uygulama paket adları cihazda denenmedi (etiketler uygulamanın dil/sürümüne göre değişebilir; tutmazsa "Kural öğret" ile düzeltilir).

## v0.56.7 — Skeuomorphism, Neumorphism, Glassmorphism tasarımları
- NewStylesTest (27): enum kaydı (9 tasarım, benzersiz ad/anahtar, taban renkleri); her `when (DesignStyle)` bloğunun (else yoksa) 9 tasarımı da kapsaması (tarayıcı yanlış-pozitif/negatif kendini de sınar); 12 yeni WAV (tap/success/delete/notify × 3) mono PCM16, süre aralıkları, kırpma yok / duyulabilir, tıksız başlangıç-bitiş, hepsi birbirinden ve eski tasarımların seslerinden farklı; WCAG kontrastı: Neumorphism metin ≥ 7:1, vurgu ≥ 4.5:1; Skeuomorphism metin ≥ 7:1 (masa + kâğıt), deri düğme yazısı ≥ 4.5:1; Glassmorphism beyaz metin her küre × her gradyan durağı × cam panel en açık köşesinde ≥ 4.5:1; kaynak denetimi: çift gölge + inset, doku/parlama/kabartma kenar, cam kenar/ışık süpürmesi/bulanık küreler, PressFx'te üç ayrı tepki, hareket/şekil/geçiş fonksiyonlarında üç dal, bileşenlerde dallar, plan ekranı yönlendirmesi, bildirim kanalı (tasarıma özel ses) ve eski tasarımların eski kanalda kalması, durum çubuğu rengi, kayıtlı tasarım adı uyumu.
- Doğrulanmadı: çizimler (gölgeler, doku, cam, animasyonlar), plan ekranları ve bildirim kanalı sesi cihazda görülmedi; GitHub Actions derlemesi bekleniyor. Cam panellerin arkası gerçek "arka plan bulanıklığı" değil; arkadaki renkli küreler bulanıktır, paneller yarı saydamdır. Sesler sentezlenmiştir (gerçek kayıt değil).

## v0.56.8 — Y2K, Aurora UI, Claymorphism, Dark Mode tasarımları
- NewStyles2Test (18): enum 13 tasarım ve yeni anahtarlar, taban renkleri; 16 yeni WAV (mono PCM16, süre aralıkları, kırpma yok, tıksız başlangıç/bitiş) ve 13 tasarım × 4 sesin hepsinin birbirinden farklı olması; WCAG kontrastı: Y2K metin ≥ 7:1 (aqua/lavanta/pembe/yüzey), vurgu ve jel düğme yazısı ≥ 4.5:1; Clay metin ≥ 7:1 tüm pastellerde (doymuş lavanta ≥ 4.5), mercan düğme + koyu yazı ≥ 4.5:1, ClayInk ≥ 4.5:1; Dark #121212 (saf siyah/saf beyaz değil), metin ≥ 7:1, vurgu ≥ 4.5:1, yükseklik formülü; Aurora beyaz metin her bulut × örtü × panelde ≥ 4.5:1, düğme yazısı ≥ 4.5:1; araştırılan gölge/degrade tariflerinin kaynakta bulunması; PressFx'te dört ayrı tepki; hareket/şekil/geçiş dalları; bileşen/gezinme/seçici/başlık dalları; plan ekranı yönlendirmesi; koyu/açık durum çubuğu; bildirim kanalı kapsamı; arka plan katmanları.
- NewStylesTest güncellendi (13 tasarım); `when (DesignStyle)` kapsam denetimi artık 13 tasarımı da zorunlu kılıyor.
- Doğrulanmadı: çizimler, animasyonlar, plan ekranları ve kanal sesleri cihazda görülmedi; GitHub Actions derlemesi bekleniyor. Claymorphism yuvarlak sans yazı tipi sistemde yok, varsayılan sans kullanılır. Sesler sentezlenmiştir.

## v0.56.9 — Cosmic Dark, Sci-Fi HUD, Cyber-Industrial, Neoclassical tasarımları
- NewStyles3Test (17): enum 17 tasarım ve yeni anahtarlar, taban renkleri; 16 yeni WAV (mono PCM16, süre aralıkları, kırpma yok, tıksız başlangıç/bitiş) ve hepsinin birbirinden farklı olması; WCAG kontrastı: Cosmic metin her nebula bulutu × örtü üzerinde ≥ 4.5:1, yüzey ≥ 7:1, lavanta düğme koyu yazı ≥ 7:1; HUD amber/camgöbeği ≥ 7:1, bugün hücresi ≥ 7:1; Cyber sarı plaka + siyah yazı ≥ 7:1, çelik üstü metin ≥ 7:1; Neoklasik mürekkep/fildişi ≥ 7:1, koyu altın ≥ 4.5:1, bugün hücresi ≥ 6.5:1; yardımcı çizim fonksiyonlarının ve nebula blur'unun kaynakta bulunması; PressFx'te dört ayrı tepki (warp halkaları, kilitlenme, piston inişi, yükselen altın); hareket/şekil/geçiş dalları; bileşen/gezinme/seçici/başlık dalları ve NewLookStyles kapsamı; plan ekranı yönlendirmesi ve 4 ızgara görünümü; bildirim kanalı, durum çubuğu ve koyu-doğal tasarım listesi; Roma rakamı kuralı.
- NewStylesTest ve NewStyles2Test güncellendi (17 tasarım; 17 × 4 ses).
- Doğrulanmadı: çizimler, animasyonlar (yıldız alanı, radar taraması), plan ekranları ve kanal sesleri cihazda görülmedi; GitHub Actions derlemesi bekleniyor. Sürekli animasyonlar pil tüketir. Sesler sentezlenmiştir.

## v0.56.10 — Ekran süresi / engelleme: odak modunu uzatma
- FocusExtendTest (5): süren odak modu mevcut bitişten uzar; süresi dolmuş olan şimdiden uzar; varsayılan adım 10 dk; bitiş asla geriye gitmez; `focus_extend` ve `focus_ends` dizgileri 9 dilde var; BlockScreen'de uzat düğmesi ve bitiş saati bağlı, bildirim yeniden kuruluyor.
- Doğrulanmadı: düğmenin ve bitiş saatinin cihazda görünümü, bildirimin yeni saatte çalışması; GitHub Actions derlemesi bekleniyor. "Uzat" çevirisi DeepL'den geldi; Azerbaycanca "Uzadın" (geçmiş zaman) bir yazım kontrolü ister.

## v0.56.11 — Ekran süresi / engelleme: günlük sınır uyarısı
- LimitRowTest (4): sınıra tam ulaşınca ve aşınca uyarı, altındayken yok, 0 = sınırsız asla uyarmaz; LimitRow'da uyarının hem renk hem ✖ işaretiyle gösterildiği kaynak denetimi.
- Doğrulanmadı: kırmızı metin ve ✖ işaretinin cihazda görünümü; GitHub Actions derlemesi bekleniyor.

## v0.56.12 — Ekran süresi: günlük hedef kartında kullanım/hedef gösterimi
- GoalCardTest (1): hedef kartı "kullanılan / hedef" biçiminde gösterir; hedef aşılınca ✖ işareti ve hata rengi; hedef 0 iken uyarı yok.
- Doğrulanmadı: görünüm cihazda kontrol edilmedi; GitHub Actions derlemesi bekleniyor.
- Bilinen sınır: seri (🔥) sayacı yalnızca son 7 güne bakıyor; uzun seriler 6 günde kesilir. Düzeltmek için geçmiş verisinin daha uzun okunması gerekir; bu sürümde değişmedi.

## v0.56.13 — Ekran süresi: hedef serisi (🔥) tüm geçmişe bakıyor
- Düzeltilen sorun: seri sayacı en fazla 13 gün geriye bakıyordu (grafik penceresi 14 gündü). Artık 60 günlük ayrı bir geçmiş okunuyor; grafik ve gün gezgini eskisi gibi 14 günde kalıyor.
- Yeni `Pure.goalStreak` (saf mantık): bugün sayılmaz, eşitlik hedefin altında sayılır, ilk aşan gün seriyi keser, hedef 0 iken seri 0.
- GoalStreakTest (9): boş geçmiş, sıfır hedef, tüm günler altında, bugün aşılsa da seri korunur, geriye yürürken ilk aşımda kesilme, tam hedef eşitliği, 60 gün sınırı, ekran kodunun yeni yolu kullandığının kaynak denetimi.
- Doğrulanmadı: 60 günlük okuma IO iş parçacığında ~60 sorgu yapar; cihazda gecikme ölçülmedi. Veri olmayan günler (uygulama izni kapalıyken veya telefon kapalıyken) 0 sayılır ve seriyi uzatır; bu eski davranıştır, değişmedi.

## v0.56.14 — Ekran süresi / engelleme: sessiz saatler
- Sessiz saat kartına anlık durum satırı eklendi: "Şu an sessiz saat aktif", "Şu an sessiz saat dışında" ya da başlangıç ve bitiş aynıysa kırmızı "aralık kapalı" uyarısı. Mantık `Pure.quietState` içinde (OFF / SAME_TIMES / ACTIVE / IDLE).
- Saat ayarı 30 dk yerine 15 dk adımla değişiyor; `Pure.stepTime` 24 saate sarıyor (23:50 + 15 = 00:05, 00:00 − 15 = 23:45). 96 adım tam 24 saat eder.
- QuietStateTest (7): kapalı, aralık kapalı, gece aralığında aktif, aralık dışı / izinsiz günde beklemede, iki yöne sarma, 15 dk adım ve tam gün, 9 dilde durum dizgileri, kart bağlantısı.
- Doğrulanmadı: durum satırının ve 15 dk adımın cihazda görünümü; mevcut sessiz saat mantığı (`quietActive`) değişmedi ve önceki testleri geçiyor. GitHub Actions derlemesi bekleniyor.
- Dikkat: "Şu an sessiz saat dışında" İngilizce çevirisi DeepL'den geldi ve biraz dolambaçlı; gözden geçirilmeli.

## v0.56.15 — Ekran süresi / engelleme: uygulama arama ve seçici
- Arama artık ortak `Pure.nameMatches` ile yapılıyor (uygulama listesi ve "Kendi uygulamanı ekle" seçici). Küçük harf, Türkçe ı/i, İ (birleşik nokta dahil), ş/ğ/ü/ö/ç/â/î/û aksanları yok sayılıyor: "ışık" ↔ "isik", "İSTANBUL" ↔ "istanbul".
- Seçicide paket adıyla da arama yapılıyor (ör. "whatsapp" → com.whatsapp) ve her satırda paket adı gösteriliyor; aynı adlı uygulamalar artık ayırt edilebiliyor.
- Sonuç yoksa "Sonuç bulunamadı" gösteriliyor (9 dilde).
- AppSearchTest (9): boş sorgu, büyük/küçük harf, Türkçe harf ve aksan toleransı, İ katlaması, paket adı araması, eski iki parametreli çağrının çalışması, seçici ve arama bağlantısının kaynak denetimi, dizgilerin 9 dilde varlığı.
- Doğrulanmadı: seçicinin iki satırlı düğme görünümü ve uzun paket adlarının kesilmesi cihazda kontrol edilmedi; GitHub Actions derlemesi bekleniyor.

## v0.56.16 — Ekran süresi / engelleme: PIN özeti güçlendirildi
- Sorun: PIN, tek turlu SHA-256 (tuz + PIN) ile saklanıyordu. 4–8 haneli bir PIN bu özetle çok hızlı denenebilir.
- Yeni `logic/PinHash.kt` (saf mantık): yeni PIN'ler PBKDF2-HMAC-SHA256, 120 000 tur, 256 bit, rastgele 16 baytlık tuzla saklanır (sürüm 2).
- Eski kayıtlar (sürüm bilgisi yok = 1) doğrulanmaya devam eder. Doğru PIN girildiğinde kayıt otomatik olarak sürüm 2'ye yükseltilir. Kullanıcının PIN'i değişmez; ekranda bir şey görünmez.
- PIN yedeklenmez kuralı ve `odak_pin` dosya adı değişmedi.
- PinHashTest (10): PBKDF2 belirleyiciliği ve 64 hex uzunluğu, PIN/tuz değişince özet değişimi, tur sayısı ≥ 100 000, eski özetin korunması, sürüme göre doğrulama, yükseltme kuralı, rastgele tuz, Pin.kt kaynak denetimi, yedek dışı kalması.
- Doğrulanmadı: cihazda PIN ayarlama, girme ve eski PIN ile yükseltmenin gerçekten çalıştığı; PBKDF2 süresi (120 000 tur) düşük sınıf telefonlarda bir–iki saniye sürebilir, bu ölçülmedi. GitHub Actions derlemesi bekleniyor.

## v0.56.17 — Ekran süresi / engelleme: öğrenilen kuralları görme ve silme
- Sorun: Kural Laboratuvarı'nda öğrenilen kurallar görünmüyordu; kaydedilmiş kuralı silmenin yolu yoktu. Yeniden öğrenme ise eski kuralları sessizce üzerine yazıyordu.
- Kural laboratuvarı artık bölüm için kayıtlı kimlik sayısını gösteriyor ("Kayıtlı kural: N kimlik") ve kural oluşturulunca sayıyı yeniler.
- "Kayıtlı kuralı sil" yalnızca bölüm engelli değilken görünür: engel kapatma akışındaki bekleme süresi atlanamasın diye. Silme iki adımlı onay ister (ilk dokunuş "Emin misin?" der). Silme engeli kapatmaz; kural yoksa engel de bir şey yapmaz.
- Pure.ruleKey ile dosya anahtarı tek yerde.
- LearnedRuleTest (6): anahtar biçimi, silme düğmesinin engelliyken gizlenmesi, iki adımlı onay ve engeli kapatmama, sayının gösterilmesi ve yenilenmesi, RuleLab yardımcıları, 9 dilde dizgiler.
- Doğrulanmadı: diyalogun cihazda görünümü ve JSON okuma/yazma (org.json) gerçek cihazda denenmedi; GitHub Actions derlemesi bekleniyor.

## v0.56.18 — Ekran süresi / engelleme: bildirim gizleme
- Devam eden bildirimler (müzik, arama, konum) artık gizlenmiyor. Bunlar iptal edilemiyordu ve kontrol düğmelerini de kaybettiriyordu.
- Günlük süre sınırı dolan uygulamanın bildirimleri de gizleniyor. Önceden yalnızca tam engel, odak ve sessiz saat dikkate alınıyordu; sınır engeliyle tutarlı oldu. Kullanım izni yoksa bu kontrol atlanır.
- Karar `Pure.hideNotification` içinde (engelli && devam eden değil && geçici izin yok).
- NotifHideTest (5): karar tablosu (engelli gizlenir, engelsiz gizlenmez, devam eden korunur, geçici izinde korunur) ve servis bağlantısı kaynak denetimi.
- Doğrulanmadı: bildirim gizlemenin cihazda davranışı; sınır kontrolü her bildirimde kullanım sorgusu yapar, pil/gecikme ölçülmedi. GitHub Actions derlemesi bekleniyor.

## v0.56.19 — Belge okuma: Türkçe harf toleranslı arama, sonuç sayacı ve vurgu
- Sorun: belge araması `ignoreCase` ile yapılıyordu; "isik" "Işık"ı, "cicek" "Çiçek"i bulamıyordu. Eşleşen yerler işaretlenmiyor, toplam sonuç sayısı da gösterilmiyordu.
- `Pure.matchStarts` (saf mantık): aynı katlama kuralı uygulama aramasıyla ortak (`foldForSearch`). Sorgu boşsa eşleşme yok; örtüşmeyen eşleşmeler soldan sağa bulunur.
- Belge görünümü: paragraf ve tablo eşleşmelerini sayan "N sonuç" satırı; paragraflarda eşleşen yerler açık sarı zeminle işaretleniyor, yazı rengi koyu tutuluyor (iki temada okunur).
- Bilinen sınır: büyük İ gibi katlamanın metin uzunluğunu değiştirdiği paragraflarda vurgu konumu küçük harf üzerinden hesaplanır; bu paragraflarda aksan toleransı yoktur. Tablo satırları vurgulanmıyor (yalnızca sayılıyor ve filtreleniyor).
- DocSearchTest (9): boş sorgu, örtüşmesiz eşleşme, büyük/küçük harf, Türkçe ı/i ve aksan toleransı, İ katlaması, bulunamama, DocParse'ın ortak eşleştiriciyi kullandığı, görünümün sayaç ve vurguyu bağladığı (kaynak denetimi), 9 dilde sayaç dizgisi.
- Doğrulanmadı: vurgunun ve sayaç satırının cihazda görünümü; uzun belgede aramanın hızı ölçülmedi. GitHub Actions derlemesi bekleniyor.

## v0.56.20 — Notlar: sıralama seçimi (son değişen / oluşturulma / A-Z)
- Sorun: Not listesinde sıralama sabit "son değişen"di; `NotePure.sorted` içinde oluşturulma ve A-Z modları vardı ama hiçbir yerden seçilemiyordu. A-Z de Türkçe alfabeye uymuyordu (Ç, Ğ, ı, İ, Ş, Ö, Ü yanlış yerdeydi).
- Liste üstünde üç seçenek çipi eklendi; seçili olan "✔" ile gösteriliyor. Seçim `odak_notes` tercih dosyasında saklanıyor, uygulama kapanıp açılınca korunuyor.
- A-Z sıralaması Türkçe `Collator` ile yapılıyor (Ağaç, Çay, Ilık, Şeker, Ütü, Zeytin).
- Bilinmeyen kayıtlı değer son değişen moduna düşüyor. Sabitlenen notlar her modda en üstte.
- BackupTest: yedek dosya listesine `odak_notes` eklendi (sıralama tercihi yedeğe girer); sayı 6'dan 7'ye çıktı.
- NoteSortTest (7): üç mod, Türkçe alfabe, sabitlenenler, bilinmeyen değer, liste bağlantısı ve kalıcılık, 9 dilde dizgiler.
- Doğrulanmadı: çiplerin cihazda görünümü ve Türkçe Collator'ün Android'de JVM ile aynı sonucu vermesi (test JVM'de geçti; Android ICU farklı olabilir); GitHub Actions derlemesi bekleniyor.

## v0.56.21 — Notlar: Türkçe harf toleranslı arama
- Sorun: not araması `contains(ignoreCase = true)` kullanıyordu; "isik" "Işık"ı, "is" "İş" klasörünü (büyük İ) tutarlı bulamıyordu.
- `NotePure.matches` artık ortak `Pure.foldForSearch` ile arıyor: başlık, klasör ve gövde aynı kuralla. Kilitli notların gövdesi yine aranmaz; yalnızca başlık ve klasör.
- NoteSearchTest (6): boş sorgu, başlık/klasör/gövde kapsamı, Türkçe ı/i ve aksan toleransı, büyük İ, kilitli not kuralı, eşleşmeyen sorgu, arama bağlantısının kaynak denetimi.
- Doğrulanmadı: cihazdaki arama sonuçları ve uzun notlarda arama hızı ölçülmedi; GitHub Actions derlemesi bekleniyor. Arama hâlâ tam metin taramasıdır (indeks yok); çok büyük not koleksiyonlarında yavaşlayabilir.

## v0.56.22 — Notlar: yapılacaklar listesinde Enter ile sonraki madde
- Sorun: yapılacaklar notunda Enter yeni satırı açıyordu ama "[ ] " öneki eklenmiyordu; her madde için kullanıcının önekini elle yazması gerekiyordu. Boş maddede Enter de listeyi bitirmiyordu.
- `NotePure.enterInList` (saf mantık): Enter bir işaretli/işaretsiz maddenin içinde ya da sonunda basılırsa yeni satıra "[ ] " eklenir (kuyruk metin yeni maddeye taşınır). Boş maddede Enter, önek kaldırarak listeyi bitirir. Yapıştırma ve harf yazma olduğu gibi kalır.
- Notlar düzenleyicisi bu kuralı `onValueChange` içinde kullanıyor.
- ChecklistEnterTest (8): işaretli/işaretsiz madde sonunda Enter, düz satır, boş madde, madde ortasında Enter, ilk satır, yazma ve yapıştırma, düzenleyici bağlantısı.
- Bilinen sorunlar (bu sürümde düzeltilmedi): yapılacaklar notunda işaretli satırlar hem üstte tıklanabilir satır olarak hem de altta düzenleme alanında ham metin olarak görünüyor (çift gösterim). Enter ile imleç ortada basılırsa imlecin sona atlaması ihtimali var; cihazda kontrol edilmeli.
- Doğrulanmadı: cihazda Enter davranışı ve imleç konumu; GitHub Actions derlemesi bekleniyor.

## v0.56.23 — Notlar: paylaşılan metinde yapılacak glifleri ve temiz biçim
- Sorun: not paylaşılınca yapılacak satırları ham önekle ("[ ] süt", "[x] ekmek") gidiyordu; sondaki boş satırlar da metinle birlikte taşınıyordu.
- `NotePure.exportText`: yapılacak satırları ☐ / ☑ olarak yazılır; sondaki boşluklar atılır; başlık boşsa gövde doğrudan başlar, gövde boşsa yalnızca başlık gider.
- NoteExportTest (6): başlık+gövde birleşimi, boş başlık, boş gövde, ☐/☑ dönüşümü, sondaki boşluklar, paylaşım bağlantısı.
- Not: bu sürümde yapılacak notundaki çift gösterim sorunu (üstte satır, altta ham metin) hâlâ açık; düzenleme modeli değiştirilmeden çözülemiyor.
- Doğrulanmadı: paylaşılan metnin hedef uygulamada (ör. mesajlaşma) ☐/☑ karakterlerini gösterdiği cihazda kontrol edilmedi; GitHub Actions derlemesi bekleniyor.

## v0.56.24 — Grafikler: yatay çubuk, pasta etiket kontrastı, ekran okuyucu özeti
- Sorun: `BAR` ve `HBAR` aynı kod yolunda çizilyordu; yatay çubuk grafikler dikey sütun olarak görünüyordu. Pasta dilimi üstündeki beyaz yüzde etiketleri açık renkli dilimlerde (sarı, turuncu, yeşil) okunmuyordu. Grafik erişilebilirlik özeti taşımıyordu; ekran okuyucu yalnızca boş bir tuval görüyordu. Yatay çubuklarda kategori sayısı arttığında çubuklar çok incelip sığmıyordu.
- `VisualPure` (saf mantık, docs/DocVisual.kt): `frac` ve `barSpan` (çubuğun sıfırdan değere uzanan oranı, negatif değerler dahil), `chartHeightDp` (pasta 220, çubuk/çizgi 240, yatay çubuk kategori başına 22 dp, 240–640 arası), `contrastRatio` (WCAG) ve `labelOn` (dilim üstü için beyaz ya da koyu yazı, yüksek kontrastlı olan), `maxEntry` (erişilebilirlik için en yüksek değer), ortak `PALETTE`.
- Arayüz (docs/DocVisualUi.kt): `drawHBar` ayrı çizer: kategoriler solda (12 karakterde kısaltılır, satır yüksekliğine sığmazsa atlanır), çubuklar sıfırdan değere yatay uzanır, değer ızgarası alt eksende; aralıkta negatif değer varsa sıfır çizgisi çizilir. Pasta etiketleri `labelOn` ile renklenir. Tuval `semantics { contentDescription }` ile "Grafik. En yüksek: X (Y)." özetini okutur.
- Yeni metin: `chart_a11y` (9 dil; DeepL ile çevrildi; tr/tr-values dahil).
- DocChartTest (18): oran ve sınır durumları, çubuk aralığı (negatif dahil), yükseklikler, kontrast oranı, her palet rengi için 4.5 üstü etiket kontrastı, en yüksek değer (çoklu seri, NaN/null atlama, eksik kategori), arayüz bağlantılarının kaynak doğrulaması, 9 dilde `chart_a11y` ve iki yer tutucu.
- Sürüm: versionCode 81, versionName 0.56.24.
- Doğrulanmadı: yatay çubuğun cihazda doğru çizildiği, etiketlerin dar ekranda taşmadığı ve pasta kontrastının görsel olarak uygun olduğu cihazda kontrol edilmedi. Compose kodu yalnızca ayrıştırıldı (Android SDK yok); GitHub Actions derlemesi bekleniyor.
- Bilinen açık konu (değiştirilmedi): dikey çizgi/alan grafiklerinde eksen etiketleri yine 7 karakterde kısaltılıyor; tablo satırlarında belge içi arama vurgusu yok.

## v0.56.25 — Derleme düzeltmeleri: fr tırnak kaçışı, MainActivity dp importu
- Sorun (GitHub Actions, v81 zip'i): `values-fr/strings.xml` içinde `quiet_state_same` satırında kaçışsız tek tırnak (`l'intervalle`) AAPT'yi düşürüyordu ("Invalid unicode escape sequence"); `MainActivity.kt` içinde `.dp` kullanılıyor ama `androidx.compose.ui.unit.dp` import edilmemişti ("Unresolved reference 'dp'").
- Düzeltme: fr metninde `l\'intervalle`; `MainActivity.kt`'ye `import androidx.compose.ui.unit.dp` eklendi.
- BuildFixTest (4): tüm dillerde kaçışsız tek tırnak yok, geçersiz `\u` kaçışı yok, fr düzeltmesi yerinde, MainActivity kullandığı `dp`'yi import ediyor.
- Sürüm: versionCode 82, versionName 0.56.25.
- Doğrulanmadı: GitHub Actions derlemesi bu sürüm için henüz çalıştırılmadı. Log'da ayrıca uyarılar var (compileSdk 37 için AGP uyarısı, setup-java v4 kullanımdan kaldırma uyarısı); bunlar derlemeyi durdurmuyor.

## v0.56.26 — GitHub uyarıları: Node 24 action sürümleri ve compileSdk bastırma
- Log'daki iki uyarı: (1) setup-java@v4 kullanımdan kaldırma uyarısı, (2) checkout@v4, setup-java@v4, setup-gradle@v4 için Node 20 kullanımdan kaldırma uyarısı. Ayrıca AGP'nin compileSdk 37 için "tested up to 36.1" uyarısı vardı.
- Düzeltme: workflow'da actions/checkout@v5, actions/setup-java@v5, gradle/actions/setup-gradle@v5 (Node 24). gradle.properties içinde `android.suppressUnsupportedCompileSdk=37,37.0` (uyarının önerdiği biçim; önceki `37` değeri eşleşmiyordu). compileSdk 37 korundu.
- BuildFixTest'e 3 test eklendi: Node 24 sürümleri kullanılıyor, zip açma adımı var, compileSdk uyarısı bastırılmış.
- Sürüm: versionCode 83, versionName 0.56.26.
- Doğrulanmadı: GitHub derlemesi henüz çalıştırılmadı. v5 action sürümlerinin girdileri (gradle-version, distribution, java-version) önceki sürümle aynı kabul edildi; derleme logunda kontrol edilmeli. AGP 9.0.1 compileSdk 37'yi resmi olarak test etmiş değil; uyarı bastırıldı ama derleme sorunu çıkarsa compileSdk 36'ya dönmek gerekebilir.

## v0.56.27 — Ayarlar kategorilere ayrıldı, minimal ana ekran sadeleştirildi, logo taslakları
- Sorun: Ayarlar tek uzun sütundu (15 kart + tema listesi + renk + yazı tipi); ana ekran (varsayılan Minimal stil) üstte gün adı, dönem seçici, gün şeridi ve ‹ › satırını üst üste gösteriyordu.
- Ayarlar (settings/SettingsScreen.kt): ana sayfada 5 kategori kartı (Görünüm ve dil, Bildirim ve ses, Planlama, Notlar ve yedek, Güvenlik ve izinler). Kategoriye dokununca kendi sayfası açılır; ‹ Geri düğmesi ve sistem geri hareketi (BackHandler) ana sayfaya döner. Kart fonksiyonlarının kendisi değişmedi, yalnızca çağrı yerleri gruplara taşındı.
- Ana ekran (plan/PlanThemes.kt, MinimalPlan): gün adı satırı kaldırıldı, dönem seçici sağa yaslandı, gün modunda haftalık şerit kaldırıldı (‹ › satırı tarihi zaten gösteriyor). Haftalık ve aylık görünümler aynen kaldı. Diğer 15 stil bu sürümde değişmedi.
- Strings: sg_look, sg_sound, sg_plan, sg_data, sg_security, sg_back (9 dil; DeepL ile çevrildi).
- Logo: 4 taslak (A zaman halkası, B harita pimi, C dağ A, D kalkan saat). SVG ve PNG önizleme üretildi; uygulamaya henüz bağlanmadı. Seçim sonrası launcher ikonu olarak eklenecek.
- UiSimplifyTest (5): her ayar kartı tam bir kez çağrılıyor, 5 kategori ve geri davranışı var, 9 dilde sg_ anahtarları var, minimal gün görünümünde şerit/gün adı yok, navigasyon ve ekleme satırı duruyor.
- Sürüm: versionCode 84, versionName 0.56.27.
- Doğrulanmadı: cihazda kategori geçişleri, geri hareketi ve sadeleşmiş ana ekranın okunabilirliği kontrol edilmedi. Compose kodu yalnızca ayrıştırıldı; GitHub Actions derlemesi bekleniyor. Diğer stillerdeki ana ekran hâlâ eski düzende.

## v0.56.28 — 4 sekmeli menü, "Diğer" sayfası, tüm stiller için tek ana ekran
- İstek: arayüz karmaşık; düzenli, kategorili, erişilebilir olsun; Not defteri ve Belgeler bulunamıyordu.
- Menü: alt çubukta 4 sekme (Plan, Yapılacaklar, Engel, Diğer). "Diğer" (settings/MoreScreen.kt) Ekran süresi, Not defteri, Belgeler ve Ayarlar'ı tek listede gösterir; Ekran süresi ve Ayarlar alt sayfa olarak açılır, geri düğmesi ve geri hareketi listeye döner; Not defteri ve Belgeler doğrudan açılır. Ayarlar kendi içinde 5 kategoriye bölünmüş durumda (v0.56.27).
- Ana ekran: 17 stilin tamamı artık plan/UnifiedPlan.kt'deki tek düzeni kullanır (dönem seçici, tarih satırı, gün listesi / hafta / ay ızgarası, ekleme satırı). Stil kimliği renk, şekil, yazı tipi ve ızgara kaplamasından gelir. Eski stile özel düzen fonksiyonları (FuturisticPlan, CosmicPlan vb.) kodda duruyor ama artık çağrılmıyor; stillerin özel süsleri (yıldız, ışıltı vb.) ana ekrandan kalktı.
- Metin: tab_more (9 dil, DeepL; "Diğer").
- NavMoreTest (5): 4 sekme ve sırası, sayfa yönlendirme, Diğer listesi ve geri, tüm stiller tek düzende, 9 dilde metin. NewStylesTest, NewStyles2Test, NewStyles3Test'teki stile özel yönlendirme kontrolleri yeni davranışa göre güncellendi.
- Doğrulanmadı: cihazda görünüm; Yapılacaklar, Engel ve Ekran süresi ekranlarının içi bu sürümde yeniden tasarlanmadı. Compose yalnızca ayrıştırıldı; GitHub Actions bekleniyor. Logo seçimi henüz yapılmadı.

## v0.56.29 — Yapılacaklar ekranı sadeleştirildi
- Sorun: ekranın üstü Pomodoro, Alışkanlık, Su kartları + 12'den fazla düğme + 3 sıra seçenekle doluydu.
- Düzen: araçlar (Pomodoro, Alışkanlık, Su) "🧰" açılır grubunda; ekleme satırı yalnızca alan, "⋯" ve "+"; öncelik/tarih/kategori/tekrar "⋯" grubunda; filtre, elle sıralama ve sıralama modu özet satırındaki "⇅" grubunda. Üç grup kapalı başlar. Mantık (sıralama, tekrar, ertele, geri al) değişmedi.
- TodoLayoutTest (5): üç grup kapalı başlıyor, araç kartları yalnızca araç grubunda, ekleme satırında 2 düğme, yeni öğe seçenekleri ve liste seçenekleri kendi gruplarında.
- Sürüm: versionCode 86, versionName 0.56.29.
- Doğrulanmadı: cihazda görünüm ve açılır grupların davranışı; GitHub Actions bekleniyor. Engel ve Ekran süresi ekranları henüz düzenlenmedi.

## v0.56.30 — Engel ekranı sekmeli, uygulama listeleri 15'er yüklenir
- Sorun: Engel ekranı tek uzun sütundu (odak, uyarılar, ekranlar, sessiz saat, tüm uygulamalar üst üste); uygulama listeleri uzundu ve kaydırınca otomatik 20'şer yükleniyordu.
- Düzen: 4 sekme — Uygulamalar (arama, "yalnızca etkin", liste, özel uygulama ekle), Odak modu (odak kartı, bugün engellenen), Sessiz saat, Ek ayarlar (uyarılar, ekranlar, bildirim gizleme, kural öğrenme).
- Liste: 15'er uygulamayla açılır; altında "Daha fazla göster (kalan)" ve "Tümünü göster" düğmeleri. Otomatik yükleme kaldırıldı. Arama/filtre değişince 15'e döner. Aynı mantık Ekran süresi listesinde (gün değişince 15'e döner) ve özel uygulama seçicide.
- Saf mantık (Pure): APP_PAGE=15, appsNextShown, appsVisible, appsRemaining.
- Metinler: blk_tab_apps, blk_tab_quiet, blk_tab_adv, blk_more, blk_all (9 dil, DeepL).
- BlockPagingTest (10): sayfa boyutu, sonraki sayı ve üst sınır, görünen sayı, kalan, sayfa sayfa sona yürüme (47 → 3 adım), ekran bağlantıları, 4 sekme içerikleri, Ekran süresi ve seçici sayfalaması, 9 dilde metin.
- Sürüm: versionCode 87, versionName 0.56.30.
- Doğrulanmadı: cihazda sekme geçişleri ve düğmeler; sekme etiketi uzunluğu dar ekranda ("Ek ayarlar" uzun) kontrol edilmeli. GitHub Actions bekleniyor.

## v0.56.31 — Dosya türleri, kolay erişim, Notlar
- Dosya türleri: HTML/XHTML ve EPUB (bölümler OPF sırasıyla) okunur; yaml, toml, sql, srt, vtt, ics, vcf, tex, rst, gpx, kml, rss vb. metin olarak açılır. DocFormatsTest (15).
- Kolay erişim: ana ekran simgesine uzun basınca "Not defteri" ve "Belgeler" kısayolları (res/xml/shortcuts.xml); NotesActivity dışarıya açık. Başka uygulamadan "birlikte aç" için html, epub, markdown, tsv, ics, vcard MIME süzgeçleri eklendi. ShortcutsTest (3).
- Notlar: renk süzgeci (listede kullanılan renklerden biri seçilir, tekrar dokununca kalkar), editörde kelime sayısı ve okuma süresi (dk, 200 kelime/dk). NotePure: readMinutes, byColor, colorsUsed. NotesExtraTest (4); NoteSortTest güncellendi. Metin: notes_read_min (9 dil, DeepL).
- Sürüm: versionCode 88, versionName 0.56.31.
- Doğrulanmadı: cihazda kısayollar (başlatıcıya göre değişir), HTML/EPUB gerçek dosyalarla, renk süzgeci görünümü. Compose dosyaları yalnızca söz dizimi denetimli.

## v0.56.32 — 19 değiştirilebilir uygulama simgesi
- Pusula simgesi 19 renk varyasyonuyla eklendi (A01–A19, mipmap-nodpi 512 px). Her biri bir activity-alias; yalnızca A01 varsayılan açık. MainActivity artık başlatıcı girişi değil; kısayollar (shortcuts) alias'lara taşındı.
- Ayarlar > Görünüm'de "Uygulama simgesi" kartı: 19 küçük simge, dokununca seçilir (PackageManager.setComponentEnabledSetting, önce seçilen açılır sonra diğerleri kapatılır, DONT_KILL_APP).
- Saf mantık: LogoPure (clamp, code, aliasName, resName, toDisable). Metin: logo_title, logo_note (9 dil, DeepL).
- LogoTest (6): sayı, adlar/sınır, kapatma listesi, her alias için simge+başlatıcı+tek açık, MainActivity'de başlatıcı yok, kart bağlantısı ve 9 dilde metin.
- Sürüm: versionCode 89, versionName 0.56.32.
- Doğrulanmadı: cihazda simge değişimi (bazı başlatıcılar yenilemek için gecikir veya uygulamayı kapatabilir), ana ekran kısayollarının alias ile çalışması. Simgeler düz PNG (uyarlanabilir simge değil), bazı başlatıcılarda kare/yuvarlak kesilebilir.

## v0.56.33 — "Diğer" bölümlü kartlar, Ekran süresi sekmeli
- Diğer: tek uzun liste yerine 3 bölüm (Kullanım takibi / Araçlar / Uygulama), 2 sütunlu büyük kartlar; her kartta simge, ad ve tek satır açıklama. Düzen saf mantıkta (MoreLayout).
- Ekran süresi (dikey): başlık ve gün gezgini sabit; altında 3 sekme — Özet (toplam, halka, hedef), Grafikler (saat, kategori, hafta), Uygulamalar (15'er liste). Yatayda eski iki bölme korunur.
- MoreHubTest (5): her giriş tek bölümde, en çok 2 sütun, hub bağlantısı, 3 sekme ve panolar, 9 dilde 10 metin (DeepL; Fransızca/Rusça bölüm başlığı ikinci denemede düzeltildi).
- Sürüm: versionCode 90, versionName 0.56.33.
- Doğrulanmadı: cihazda kart yüksekliği/hizası, sekme etiketleri dar ekranda ("✔ Grafikler" gibi) taşabilir; Compose yalnızca söz dizimi denetimli.

## v0.56.34 — Profesyonel ilkelere göre sadeleştirme (5 sekme, altta sabit ekleme)
- Araştırma (kaynaklar sohbette): ilerleyen açıklama (progressive disclosure) — "azı göster, çoğunu sakla; özellik değil karmaşa kaldırılır", sık kullanılanlar önde, ikincil olanlar bir dokunuş ötede; alt gezinme en çok 5 hedef, kısa etiketler, her sekme doğrudan bir hedefe gider, sık eylemler başparmak bölgesinde (altta).
- Uygulama: (1) Not defteri (Notlar+Belgeler) 5. ana sekme oldu; "Diğer" yalnız ikincil olanları tutuyor: Ekran süresi, Belgeler, Ayarlar (2 bölüm: Araçlar, Uygulama). (2) Plan: ekleme satırı kaydırma alanının dışında, altta sabit. (3) NotesHub(embedded) çift sistem çubuğu boşluğunu önler; Activity olarak da çalışır (kısayollar).
- ProNavTest (5); NavMoreTest ve MoreHubTest güncellendi (5 sekme, 3 giriş, 2 bölüm).
- Sürüm: versionCode 91, versionName 0.56.34.
- Doğrulanmadı: 5 sekmede "Yapılacaklar" etiketi dar ekranda kısalabilir; Notlar sekmesinde editör açıkken alt çubuğun görünmesi; sabit ekleme satırı klavye açılınca. Cihazda denenmedi.

## v0.56.35 — Hata kapatma ve küçük iyileştirmeler
- Sekme etiketi "Yapılacaklar" 5 sekmede taşabiliyordu: alt çubukta kısa "Görevler" (tab_todo_s, 9 dil, DeepL; ekranın kendi başlığı aynı kaldı).
- Not editörü açıkken alt çubuk (ve yatayda yan şerit) gizlenir; editörden çıkınca geri gelir; başka sekmeye geçişte sıfırlanır.
- Plan ekleme satırı klavye açılınca klavyenin üstüne çıkar (imePadding).
- ProNavTest 8 teste çıktı (kısa etiket ≤10 karakter her dilde, çubuk gizleme, imePadding). NavMoreTest tab_todo_s'e uyarlandı.
- Sürüm: versionCode 92, versionName 0.56.35.
- Bilinen, değiştirilmedi: eski stil başına plan işlevleri (PlanThemes/PlanNewStyles*) artık çağrılmıyor ama duruyor (~1700 satır); silmek çok testi etkiler, ayrı iş. Cihazda denenmedi.

## v0.56.36 — Erişilebilirlik ve veri güvenliği
- Ekran okuyucu: yalnız simge içeren düğmeler (←, ‹, ›, +, −, ✕, ⋯, 🗑, ↶, ↷, 📌/📍, 🔍, 📋, 📑, ↗, ↺, ⏹, 🧰, ⇅, ↕, 🔁, ∗) artık anlamlı ad okur (24 etiket + Pomodoro "başlat", 9 dil, DeepL; yanlış çıkan çeviriler yeniden denendi). ✔/⚠ işaretleri okunmaz, seçili düğme "seçili" bildirir, Terminal stilindeki [ ] süsü okunmaz. Mantık A11yPure (saf).
- Dokunma hedefi: tüm düğmelerde en az 48×48 dp (önce 40 dp yüksekti).
- Veri güvenliği: Plan/Yapılacaklar kaydında okunamayan kayıt varsa (veya JSON bozuksa) ham veri "items_bak" anahtarına yedeklenir; sonraki kayıt eskiyi ezip sessiz kayıp yapmaz.
- Not listesi: süzülen renkte not kalmadıysa süzgeç otomatik kalkar (eskiden boş liste ve temizleyecek çip kalmıyordu).
- A11yTest (7), StoreSafetyTest (3), NotesExtraTest +1; NoteSortTest uyarlandı.
- Sürüm: versionCode 93, versionName 0.56.36.
- Doğrulanmadı: TalkBack ile gerçek cihazda okunuşlar; 48 dp minimum genişlik bazı sıkışık satırlarda düzeni genişletebilir (özellikle −/+ ve ‹ › düğmeleri). Yedek anahtarı şimdilik yalnız saklanır, arayüzden geri yükleme yok.

## v0.56.37 — Ekran okuyucu (TalkBack) desteği kaldırıldı
- İstek: TalkBack'e gerek yok. Kaldırılanlar: simge düğmesi etiketleri (a11y paketi, 25 a11y_* metni), düğme semantiği ve 48 dp minimum (40 dp'ye geri döndü), grafik özeti (chart_a11y metni ve semantics).
- Korunanlar: Engel özelliğinin kullandığı Erişilebilirlik Servisi (OdakAccessibilityService, accessibility_config) — o ekran okuyucu değil, uygulama engelleme motorudur; kaldırılırsa engel çalışmaz. Grafik kontrast etiketleri görsel olduğu için duruyor.
- Veri yedeği (items_bak) ve not renk süzgeci düzeltmesi duruyor.
- A11yTest silindi; DocChartTest'te özet testi "ekran okuyucu kodu kalmadı" testine çevrildi.
- Sürüm: versionCode 94, versionName 0.56.37.

## v0.56.38 — 6 yeni belge türü (okuma, açma, dönüştürme)
- Yeni türler (docs/DocMore.kt, saf Kotlin): E-posta (.eml: üstbilgiler, RFC 2047 başlık kodları, MIME çok parçalı, quoted-printable/base64, ekler "📎" ile listelenir), web arşivi (.mht/.mhtml: HTML kısmı okunur), FB2 e-kitap (.fb2: bölümler sayfa, yazar/başlık, şiir dizeleri, kodlama bildirimi), Jupyter (.ipynb: markdown + kod + çıktı, ANSI renk kodları temizlenir), arşiv içeriği (.zip/.cbz/.jar: ad ve boyut tablosu; Office içeriği olan zip Office olarak açılır), biçimli JSON (.json/.geojson: 2 boşluk girintili; bozuksa ham satırlar; 8 MB üstü biçimlenmez).
- Küçük bir JSON okuyucu (sıralı, sayı özgün yazımıyla, derinlik sınırı 200) yazıldı; org.json kullanılmadı, JVM'de sınanır.
- Dönüştürme: yeni türlerin hepsi mevcut hedeflere (TXT, MD, HTML, CSV, RTF, DOCX, XLSX, PPTX, ODT/ODS/ODP, PDF) çevrilebilir; arşiv tablosu XLSX/CSV'ye de gider.
- Açma: manifest VIEW süzgeçleri eklendi (message/rfc822, fictionbook, ipynb, json, zip, cbz, jar, mimearchive). Dikkat: application/zip ve json süzgeci Atlas'ı bu dosyaların "birlikte aç" listesine koyar.
- Belgeler ekranındaki ipucu metni (doc_hint) 9 dilde yeni türleri sayıyor (DeepL).
- DocMoreTest (29): uzantılar, JSON (ayrıştırma, kaçışlar, bozuk/derin/BOM), EML (başlık, QP, base64, ek, HTML-only, bozuk girdi, iç içe mesaj sınırı, RFC 2047), MHTML, FB2, IPYNB, arşiv (bayt/dosya, Office-zip, uzantısız zip, boyut biçimi), dönüştürme hedefleri, manifest, büyük JSON önizleme.
- DocGenTest.detSig_1521 beklentisi UNKNOWN → ARCHIVE olarak güncellendi (a.zip artık arşiv).
- Sürüm: versionCode 95, versionName 0.56.38.
- Doğrulanmadı: gerçek e-posta/MHTML/FB2 dosyalarıyla (yalnız örnek dizgilerle denendi); cihazda açma ve paylaşım menüsü. CBZ'de resimler gösterilmez, yalnız liste. MHTML'de gömülü resimler gösterilmez. Apple Pages/Numbers/Keynote ve MOBI/AZW eklenmedi (içerikleri düz metin değil).

## v0.56.39 — Biçim koruyan dönüştürme, Tam görünüm, 6 yeni belge türü
- Biçim modeli (docs/Rich.kt, saf Kotlin): paragraf (hizalama, başlık, liste imi, girinti, aralık, çizgi aralığı, kenarlık, gölge, sayfa sonu), çalışma (kalın, italik, altı çizili, üstü çizili, renk, vurgu, boyut, yazı tipi, üst/alt simge, bağlantı), tablo (sütun genişlikleri, hücre kenarlıkları, gölge, yatay/dikey birleştirme, dikey hizalama), sayfa boyutu ve kenar boşlukları.
- Okuma: DOCX (RichDocx: styles.xml kalıtımı, numbering.xml liste imleri, tablo/hücre kenarlıkları, gridSpan/vMerge, sectPr), ODT + OpenOffice .sxw + düz ODF .fodt (RichOdt: otomatik/adlandırılmış stiller, liste stilleri, sütun genişlikleri, birleşik hücreler, sayfa düzeni), Markdown (DocMore2.mdRich: başlık, kalın/italik/kod/üstü çizili, liste, görev listesi, alıntı, kod bloğu, tablo, çizgi, bağlantı).
- Yazma (RichWrite): HTML (CSS), DOCX, RTF, ODT (styles.xml sayfa düzeni dahil) ve PDF (DocPdfRich, Android tuvali) biçimi korur. Biçimsiz kaynaklarda eski düz yol aynen çalışır; karışık belgelerde sayfa bazında seçilir.
- Tam görünüm: Belgeler ekranında biçimli belgede "Tam görünüm" düğmesi → WebView (JavaScript kapalı, dosya erişimi kapalı, bağlantıya gitmez, yakınlaştırma açık). "Metin görünümü" düğmesi aramalı eski görünüme döner. Dönüştürme notu biçimli belgede conv_note_rich.
- 6 yeni tür (DocMore2): CSV/TSV (ayraç tespiti , ; TAB |, tırnak/çift tırnak, 3000 satır sınırı → tablo), Markdown, vCard (.vcf: kişi tablosu, QP, katlanmış satır), iCalendar (.ics: olay/görev tablosu, tarih biçimi, sıralı), MBOX (.mbox: her ileti bir sayfa, ≤500 ileti), OpenOffice 1.x (.sxw/.sxc/.sxi/.sxd) ve düz ODF (.fodt/.fods/.fodp/.fodg).
- Ek: e-posta başlıkları geçerli UTF-8 ise UTF-8 okunur (SMTPUTF8), değilse Latin-1.
- Manifest VIEW süzgeçlerine csv, tsv, markdown, mbox, sun.xml.*, flat-xml MIME türleri eklendi. doc_hint ve yeni metinler (doc_full, doc_textview, conv_note_rich) 9 dilde (DeepL; ES/RU "Metin görünümü" çevirisi hatalı çıktığı için elle düzeltildi).
- DocRichTest (38): DOCX stil/tablo/liste/sayfa okuma, çizgisiz tablo, düz metin değişmezliği, HTML (stil, birleşme, kaçış, güvenli bağlantı), DOCX/ODT turu (yaz → oku, XML geçerliliği), RTF anahtar sözcükleri, karışık sayfalar, ODT/FODT/SXW okuma, Markdown, CSV, vCard, iCalendar, MBOX, uzantılar, manifest, WebView güvenlik ayarları, PDF çizicinin bağlanması, 9 dil.
- Güncellenen testler: csv/tsv/md/ics/vcf artık TEXT değil (DocGenTest, DocFormatsTest), büyük metin kontrolü isTextKind (DocMoreTest).
- LibreOffice ile gerçek denendi: python-docx ile üretilen örnek DOCX → bizim DOCX/ODT/RTF çıktılarımız PDF'e çevrilip özgün ile karşılaştırıldı (başlık, kalın/italik/renk, liste, tablo çizgisi, birleşik hücre, gölge korundu); HTML Chromium'da ekran görüntüsüyle bakıldı.
- Sürüm: versionCode 96, versionName 0.56.39.
- Doğrulanmadı / sınırlar: Cihazda WebView ve PDF çizici çalıştırılmadı (PDF çizici yalnız sözdizimi denetimi; GitHub derlemesi doğrulanmadı). Resimler, üst/alt bilgi, dipnot, metin kutuları, tablo stili koşullu biçimleri (zebra/başlık rengi), yazı tipi gömme aktarılmaz; PDF'de yazı tipi Android'in 3 ailesine (sans/serif/mono) eşlenir, iki yana yaslama yoktur. ODS/ODP/PPTX/XLSX hücre biçimi (renk, kenarlık) aktarılmaz — yalnız Word/ODT/Markdown biçimlidir. PDF → başka biçim hâlâ yalnız sayfa resmi.

## v0.56.40 — Resim, üst/alt bilgi, dipnot, tablo stili, Excel biçimi, e-kitap (EPUB/FB2/MOBI)
`DocRich2Test` (18 test):
- mediaWantedCaps: yalnız png/jpg/gif medya okunur.
- docxImageParsed / docxImageRoundTrips: DOCX resmi → HTML data URI; DOCX/ODT/RTF/HTML yazımı; DOCX ve ODT geri okunca resim korunur; RTF `\pngblip`.
- docxHeaderFooterFootnote: üst/alt bilgi ve dipnot okunur, HTML'de görünür, DOCX gidiş-dönüşte korunur.
- docxTableStyleBanding: tablo stilinin ilk satır / zebra dolguları.
- xlsxRichFormat: Excel hücre dolgusu ve kalın yazı.
- epubStructure / epubReadsBackAndKeepsText / epubImagesIncluded: mimetype ilk ve sıkıştırmasız, container/opf/nav/ncx, bölümlere ayırma, XML geçerliliği, resim.
- fb2RoundTrip, fbzZipped, ebookTargets: FB2 yazma/okuma, .fbz/.fb2.zip, hedef listeleri, dosya adları.
- palmDecompressVectors, mobiUncompressedAndCompressed, mobiUnsupportedAndBroken: PalmDOC açma, MOBI okuma, desteklenmeyen/bozuk dosya.
- pdfSourceChecks, fullViewSourceChecks, stringsInAllLocales: Android dosyaları için kaynak denetimi (telefonda çalıştırılmadı), 9 dilde metinler.

## v0.56.41 — Program (saatli liste + bildirim), not listesi, ayarlar sekmeleri
`ScheduleTest`: sonraki bildirim zamanı (bugün/yarın/gün maskesi/kapalı), sıralama ve gün süzme, en yakın kayıt, gün etiketi ve gün aç-kapa, kayıt biçimi gidiş-dönüş (| ve satır sonu kaçışı), bozuk satırlar ve sınırlar, Android bağlantı denetimleri (alıcı, manifest, Diğer ekranı, yeniden kurulum), not listesi sırala/renk panelinin kapanabilirliği, Görünüm grubunun 4 sekmeye bölünmesi, 5 yeni metin 9 dilde. Yedek listesine `odak_sched` eklendi (BackupTest).

## v0.56.42 — PPTX biçimi, metin kutuları, Excel biçimleri, e-kitap resimleri, MOBI Huffman, yazı tipi aileleri
- `NumFmtTest` (9): Excel sayı/tarih/saat/yüzde/bilimsel/para/negatif bölümleri, yerleşik kimlikler, General yuvarlama.
- `DocRich3Test` (14): HtmlRich (satır içi biçim, başlık, liste, tablo, resim, style), EPUB resimli bölüm ve dönüştürme, FB2 `<binary>` resmi, Markdown data-URI resmi, MOBI HUFF/CDIC (düz ve iç içe) + MOBI resim kaydı, bozuk Huffman çökmez, XLSX tarih/sayı biçimi (düz tablo = zengin tablo).
- `DocRich4Test` (9): PPTX (konuma göre sıra, başlık/renk/yazı tipi/boyut, madde imi, şekil dolgusu, resim, tablo, birleşik hücre, arka plan, HTML/DOCX'e aktarma), DOCX ve ODT metin kutuları (Fallback kopyası yok), `FontMap` aileleri, PDF kaynak denetimi.

## v0.56.43
- EpubCssTest (3): CSS sınıf/etiket/kimlik kuralları, display:none, EPUB bağlı .css + <style>.
- DocFormatsTest: .css artık zip'ten okunur.
- NumFmt2Test: kesir (# ?/?) ve koşullu bölüm ([>100]).

## v0.56.44
- DocRich5Test (4): KF8/AZW3 — `kindle:embed` taban-32 indeksi, salt KF8, birleşik MOBI6+KF8 (EXTH 121), bozuk dosya çökmez.
- CssSelectorTest (3): ata/çocuk seçiciler, özgüllük, desteklenmeyen seçiciler yok sayılır.
- PptxEffectsTest (7): döndürme/gradyan/gölge (HTML çıktısı dahil), iç içe grup + lumMod/lumOff, resim kırpma, sütun/çizgi/pasta grafiği, bozuk grafik, FontMap.asset + PDF kaynak denetimi.
- EpubCssTest: seçici sayısı 5 olarak güncellendi.

## v0.56.45
- DocRich6Test (11): CSS özellik/:first-child/+/~ seçicileri, düzlemde kardeş izleme; PPTX flip + radyal gradyan + gölge parametreleri, metinli şekilde flip yok, grup döndürme; alan ve dağılım grafiği; DOCX anchor + wrapSquare yüzen kutu (sağ/sol), satır içi eski davranış; ODT svg:x yüzen kutu; yazı tipi dosyaları + görüntüleyici bağlantısı (@font-face, shouldInterceptRequest, güvenli yol listesi).
- DocRich5Test: pasta artık tek kutuda (conic-gradient), Georgia/Arial/Times → Gelasio/Arimo/Tinos.

## v0.56.46
- DocRich7Test (14): CSS :nth-child(odd/even/n/an+b/-n+b), :last-child, :only-child, ::before/::after (content, kaçış, attr()); gradyan durak konumu; radar, balon, borsa (yüksek-düşük-kapanış), halkalı pasta, dağılım çizgisi (noFill'de yok), pürüzsüz alan grafiği; 6 yeni yazı tipi ailesi + dosya/lisans denetimi; dışa aktarılan HTML'e yalnız kullanılan yazı yüzleri gömülür; DOCX/ODT yüzen kutuda dikey ofset.
- CssSelectorTest, PptxEffectsTest, DocRich6Test: yeni seçici/gradyan çıktısına göre güncellendi.

## v0.56.47
- DocRich8Test (12): CSS :not(), :nth-last-child, :nth-of-type, :last/first/only-of-type, :empty, :link (hover/focus/visited bilerek yok sayılır); yazı tipi bütçesi (<7,5 MB, dosya başı <700 KB), TrueType imzası ve cmap'te Türkçe/Azerice/Kiril harfleri; eksik yüzlerin taklidi (sahte kalın/eğik, HTML'de tarayıcıya bırakma); Palatino/Franklin/Century Gothic/script eşleşmeleri; DOCX/ODT sayfaya göre sabit konum (resolveAt, sayfa/kenar boşluğu, hizalama, paragrafa göre → yok) ve PDF'te `at` ile çizim.
- DocRich7Test: borsa çubuk genişliği 40.

## v0.56.48
- DocRich9Test (13): CSS :hover/:focus/:visited/:active/:focus-within/:target/:checked/:disabled hiç eşleşmez (`:not(:hover)` her zaman eşleşir), iç içe :not(), :is()/:where(), :not(a, b), virgüllü seçici listesi; Symbol/Wingdings/ZapfDingbats → Unicode (DOCX `w:sym` dahil, U+F0xx, bilinmeyen simge → •); yedek yazı tipi: çalışma eksik harf sınırlarında bölünür (Kiril, Yunanca, Ə, İ, Ğ), serif→Tinos, mono→Cousine, diğer→Arimo, Arapça→Noto Naskh Arabic; HTML'de yedek yüz; eksik tablosu gerçek yazı tipi cmap'iyle birebir doğrulanır; Naskh Arapça kapsamı + lisans; DOCX paragrafa göre konum (wrapNone → `at` 5. eleman 1, PDF `lastParaTop`; wrapSquare akışta kalır).
- DocRich8Test, CssSelectorTest: yeni davranışa göre güncellendi.

## v0.56.49
- DocRich10Test (8): LibreOffice'in ürettiği gerçek DOCX ve ODT (paragrafa göre, wrapNone/run-through) → kutu `at` 5. eleman 1, doğru x/y, demirli paragrafın hemen arkasında; ODT `parallel` sarma akışta kalır; RtlText (paragraf yönü, parça görsel sırası: Arapça, karışık Latin/Arapça), HTML `dir="rtl"`, PDF bağlantısı; Naskh Latin-1/Ext-A, noktalama, Arapça virgül/soru işareti kapsamı.

## v0.56.50
- DocRich10Test (+3): `Anchors.split` (kutu en yakın önceki paragrafa bağlanır, sayfa-göreli ayrılmaz, paragrafsız kalırsa akışta), `Anchors.top` (sayfa altına/üstüne taşmaz), PDF kodunda kutunun paragrafın başladığı sayfada (ilk satır ensure'dan sonra) çizildiği.

## v0.56.51
- UiPolishTest (4): MoreRecents (öne alma, en fazla 2, bilinmeyen ad, kodla/çöz), 5 yeni metin 9 dil dosyasında var ve kesme işareti kaçışlı, EmptyState Yapılacaklar/Ekran süresi/Notlar/Belge ekranlarına ve son kullanılanlar "Diğer"e bağlı.

## v0.56.52
- UiPolishTest (+3, 7): NavMemory (son sekme, aralık dışı → 0); Plan'daki 14 boş durum yazısı ortak `PlanEmpty`'ye geçti, düz Text kalmadı; Engelleme: aktif kural sayısı + boş sonuç/filtre ipucu; MainActivity son sekmeyi saklar; 3 yeni metin 9 dilde.

## v0.56.53
- ContrastTest (7): WCAG oranı, yarı saydam karışım, `readable` (iyi renge dokunmaz, kötüyü siyah/beyaza çevirir; kullanıcının seçtiği açık/koyu ana renk), `alphaFor`, hata kırmızısı (açık/koyu zeminde ≥4.5), 17 stilin metin/zemin ve metin/yüzey kontrastı ≥4.5 (DesignStyle.kt'den okunur), açık Plan görünümlerinde (Minimal, Modern, Aero) saat/gün yazıları ≥4.5, düğme/sekme/Material/PIN hata yazısı bağlantıları.

## v0.56.54
- ColorCustomTest (7): HSV↔ARGB (ana renkler, palet gidiş-dönüş), `#RGB/#RRGGBB` ayrıştırma, 24 benzersiz palet rengi; kullanıcı arka planı → okunur yüzey + yazı (otomatik düzeltme); EmojiSplit (renkli emoji / metin simgesi ayrımı, ZWJ, ten tonu, FE0F); tüm arayüz dosyaları sarmalı `Text`'i kullanır (koyu/açık modda emoji iki kez çevrilir); 4 etkinlikte `LocalInverted`; ColorPrefs arka plan + yazı; ayarlarda palet + özel renk seçici; 4 yeni metin 9 dilde.

## v0.56.55
- ColorSlotTest (8): 7 renk yuvası (eski kayıt anahtarları p/a/b/t korunur), `Recolor` matrisi (taban renk tam hedef olur, açık/koyu yapı korunur, alfa dokunulmaz, 32 palet rengi, gain), arka planın stilin desenini koruyup boyanması (içerik boyanmaz, eski düz-renk kodu yok), düğme arka planı/yazısı ve kart rengi bağlantıları, genel sıfırlama yok: her renk kendi "↺" düğmesiyle sıfırlanır.
- ColorCustomTest: palet 32 renk, yeni metinler 9 dilde.

## v0.56.83 — Özellik engelleme simülasyonu
- BlockEngineSimTest: gerçek block_rules.json ile her kural girdisi tek başına özelliği engeller; ana/boş ekran engellemez; negatif veto (YouTube canlı); kardeş özellik sızması yok; featDelta/featExit/isHomeLabel.
