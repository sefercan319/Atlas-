plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.odak.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.odak.app"
        minSdk = 33
        targetSdk = 37
        versionCode = 141
        versionName = "0.56.84"
    }

    // Sabit imza: her derlemede aynı anahtar kullanılır, böylece yeni APK eskinin üstüne güncelleme olarak kurulur.
    signingConfigs {
        create("atlas") {
            storeFile = file("atlas-release.jks")
            storePassword = "atlas2026"
            keyAlias = "atlas"
            keyPassword = "atlas2026"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("atlas") }
        getByName("release") { signingConfig = signingConfigs.getByName("atlas") }
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.10.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.caverock:androidsvg-aar:1.4")

    testImplementation("junit:junit:4.13.2")
}
