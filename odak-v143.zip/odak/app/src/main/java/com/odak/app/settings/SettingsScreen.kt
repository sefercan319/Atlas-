package com.odak.app.settings

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import com.odak.app.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import androidx.compose.ui.graphics.toArgb
import com.odak.app.block.Pin
import com.odak.app.theme.ThemedTextField
import com.odak.app.theme.ClickSound
import androidx.compose.ui.draw.alpha
import com.odak.app.theme.ColorPrefs
import com.odak.app.theme.ColorSlot
import com.odak.app.theme.plainClick
import com.odak.app.theme.DesignStyle
import com.odak.app.theme.SoundKind
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedHeader
import com.odak.app.theme.tokensFor
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.width

/** Ayar kategorileri: ana sayfada birer kart, dokununca kendi alt sayfası açılır. */
enum class SettingsGroup(val icon: String, val titleRes: Int) {
    LOOK("🎨", R.string.sg_look),
    SOUND("🔔", R.string.sg_sound),
    PLAN("📅", R.string.sg_plan),
    DATA("💾", R.string.sg_data),
    SECURITY("🔐", R.string.sg_security)
}

@Composable
fun SettingsScreen(
    current: DesignStyle,
    fontScale: Float,
    mode: Int,
    onMode: (Int) -> Unit,
    onFontScale: (Float) -> Unit,
    onSelect: (DesignStyle) -> Unit
) {
    var group by remember { mutableStateOf<SettingsGroup?>(null) }
    BackHandler(enabled = group != null) { group = null }
    val open = group
    if (open == null) {
        SettingsHub(onOpen = { group = it })
    } else {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            com.odak.app.theme.QuietAction("‹ " + stringResource(R.string.sg_back), { group = null })
            Spacer(Modifier.height(12.dp))
            ThemedHeader(stringResource(open.titleRes))
            Spacer(Modifier.height(12.dp))
            when (open) {
                SettingsGroup.LOOK -> LookGroup(current, fontScale, mode, onMode, onFontScale, onSelect)
                SettingsGroup.SOUND -> SoundGroup()
                SettingsGroup.PLAN -> PlanGroup()
                SettingsGroup.DATA -> DataGroup()
                SettingsGroup.SECURITY -> SecurityGroup()
            }
        }
    }
}

@Composable
private fun SettingsHub(onOpen: (SettingsGroup) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        SettingsGroup.entries.forEach { g ->
            ThemedCard(
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                onClick = { onOpen(g) }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(g.icon, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        stringResource(g.titleRes),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Text("›", style = MaterialTheme.typography.titleLarge)
                }
            }
        }
    }
}

@Composable
private fun LookGroup(
    current: DesignStyle,
    fontScale: Float,
    mode: Int,
    onMode: (Int) -> Unit,
    onFontScale: (Float) -> Unit,
    onSelect: (DesignStyle) -> Unit
) {
    // Alt bölümler: tek uzun sayfa yerine dört küçük sekme.
    var sub by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableIntStateOf(0) }
    val names = listOf("🎨 " + stringResource(R.string.theme_title), "🖌 " + stringResource(R.string.colors_title), "Aa", "🌐 " + stringResource(R.string.lang_title), "🖼 " + stringResource(R.string.logo_title))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        names.forEachIndexed { i, n -> com.odak.app.theme.QuietAction((if (sub == i) "✔ " else "") + n, { sub = i }) }
    }
    Spacer(Modifier.height(12.dp))
    when (sub) {
        0 -> {
    DesignStyle.entries.forEach { s ->
        val tk = tokensFor(s)
        ThemedCard(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            selected = s == current,
            onClick = {
                ClickSound.play(s, SoundKind.TAP)
                onSelect(s)
            }
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (s == current) "✔ ${s.label}" else s.label,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                listOf(tk.background, tk.primary, tk.accent, tk.text).forEach { c ->
                    Box(
                        Modifier
                            .padding(start = 4.dp)
                            .size(20.dp)
                            .background(c, CircleShape)
                            .border(1.dp, Color(0x33000000), CircleShape)
                    )
                }
            }
            // Önizleme yalnız seçili stilde: liste sade ve hızlı kalır
            if (s == current) {
                Spacer(Modifier.height(10.dp))
                com.odak.app.theme.ThemePreview(s, Modifier.fillMaxWidth())
            }
        }
    }
        }
        1 -> {
    ColorsCard(current)
    Spacer(Modifier.height(12.dp))
    ThemedCard(Modifier.fillMaxWidth()) {
        Text("🌓", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("🎨", "☀", "🌙").forEachIndexed { i, e ->
                com.odak.app.theme.QuietAction(if (mode == i) "✔ $e" else e, { onMode(i) })
            }
        }
    }
        }
        2 -> {
            FontCard(fontScale, onFontScale)
            Spacer(Modifier.height(12.dp))
            ScaleCard()
        }
        3 -> LanguageCard()
        else -> com.odak.app.logo.LogoCard()
    }
}

@Composable
private fun SoundGroup() {
    DailyCard()
    Spacer(Modifier.height(12.dp))
    MsgsCard()
    Spacer(Modifier.height(12.dp))
    LeadCard()
    Spacer(Modifier.height(12.dp))
    SoundCard()
    Spacer(Modifier.height(16.dp))
    Text("🔊", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ThemedButton("👆", {}, sound = SoundKind.TAP)
        ThemedButton("✔", {}, sound = SoundKind.SUCCESS)
        ThemedButton("🗑", {}, sound = SoundKind.DELETE)
        ThemedButton("🔔", {}, sound = SoundKind.NOTIFY)
    }
}

@Composable
private fun PlanGroup() {
    StatsCard()
    Spacer(Modifier.height(12.dp))
    EmojiCard()
    Spacer(Modifier.height(12.dp))
    SummaryCard()
}

@Composable
private fun DataGroup() {
    NotesCard()
    Spacer(Modifier.height(12.dp))
    BackupCard()
}

@Composable
private fun SecurityGroup() {
    PinCard()
    Spacer(Modifier.height(12.dp))
    PermCard()
}

@Composable
private fun NotifCard() {
    val ctx = LocalContext.current
    var ok by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok = it }
    if (ok) return
    Spacer(Modifier.height(12.dp))
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.notif_perm))
        Spacer(Modifier.height(10.dp))
        ThemedButton(stringResource(R.string.block_grant), { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) })
    }
}

private val Palette = listOf(
    0xFF00E5FF, 0xFF7C4DFF, 0xFFFF2A6D, 0xFF05D9E8, 0xFF2FA52A, 0xFFFFA000, 0xFF0067C0, 0xFF111111
).map { Color(it) }

@Composable
private fun ColorsCard(style: DesignStyle) {
    val ctx = LocalContext.current
    val tk = tokensFor(style)
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.colors_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        @Composable
        fun row(labelRes: Int, slot: ColorSlot, shown: Color) {
            SwatchRow(
                stringResource(labelRes), shown, ColorPrefs.get(style, slot) != null,
                { ColorPrefs.set(ctx, style, slot, it.toArgb()) }, { ColorPrefs.clear(ctx, style, slot) }
            )
        }
        row(R.string.colors_primary, ColorSlot.PRIMARY, tk.primary)
        row(R.string.colors_accent, ColorSlot.ACCENT, tk.accent)
        row(R.string.colors_background, ColorSlot.BACKGROUND, tk.background)
        row(R.string.colors_surface, ColorSlot.SURFACE, tk.surface)
        row(R.string.colors_text, ColorSlot.TEXT, tk.text)
        row(R.string.colors_button, ColorSlot.BUTTON, tk.buttonBg ?: tk.primary)
        row(R.string.colors_button_text, ColorSlot.BUTTON_TEXT, tk.buttonText ?: tk.text)
        Text(stringResource(R.string.colors_auto_note), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp).alpha(0.7f))
    }
}

@Composable
private fun SwatchRow(label: String, current: Color, custom: Boolean, onPick: (Color) -> Unit, onReset: () -> Unit) {
    // Sade satır: ad + geçerli renk; dokununca renk penceresi açılır
    var open by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(top = 6.dp).plainClick { open = true }.padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label + if (custom) "  ✎" else "", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Box(Modifier.size(26.dp).background(current, CircleShape).border(1.dp, Color(0x55808080), CircleShape))
    }
    if (open) androidx.compose.material3.AlertDialog(
        onDismissRequest = { open = false },
        title = { Text(label) },
        text = { androidx.compose.foundation.layout.Column(Modifier.verticalScroll(rememberScrollState())) { com.odak.app.settings.SwatchPalette(current, onPick) } },
        confirmButton = { ThemedButton(stringResource(R.string.pin_ok), { open = false }) },
        dismissButton = { if (custom) com.odak.app.theme.QuietAction("↺ " + stringResource(R.string.colors_reset), { onReset(); open = false }) }
    )
}

@Composable
private fun PinCard() {
    val ctx = LocalContext.current
    var isSet by remember { mutableStateOf(Pin.isSet(ctx)) }
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.pin_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        ThemedTextField(
            value = pin,
            onValueChange = { pin = it.filter(Char::isDigit).take(8); wrong = false },
            placeholder = stringResource(R.string.pin_enter),
            modifier = Modifier.fillMaxWidth(),
            secret = true
        )
        val lockLeft = ((Pin.lockRemainingMs(ctx) + 999) / 1000).toInt()
        if (wrong && lockLeft > 0) Text(stringResource(R.string.pin_locked, lockLeft), color = com.odak.app.theme.errorColor())
        else if (wrong) Text(stringResource(R.string.pin_wrong), color = com.odak.app.theme.errorColor())
        Spacer(Modifier.height(8.dp))
        ThemedButton(
            stringResource(if (isSet) R.string.pin_remove else R.string.pin_set),
            {
                if (isSet) {
                    if (Pin.check(ctx, pin)) { Pin.clear(ctx); isSet = false; pin = "" } else wrong = true
                } else if (pin.length >= 4) {
                    Pin.set(ctx, pin); isSet = true; pin = ""
                }
            }
        )
    }
}
