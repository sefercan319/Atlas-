package com.odak.app.plan

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.odak.app.R
import com.odak.app.theme.DesignStyle
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.PeriodSelector
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck

/** Tüm stiller için tek, sade ana ekran düzeni. Stil kimliği renk, şekil, yazı tipi ve ızgara kaplamasından gelir. */
object UnifiedPlanLayout {
    /** Sabit sıra: dönem seçici, tarih satırı, içerik, ekleme satırı. */
    val sections = listOf("period", "nav", "content", "add")
}

@Composable
fun UnifiedPlan(vm: PlanVm, style: DesignStyle) {
    val t = LocalDesign.current.tokens
    val skin = skinFor(style)
    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            PeriodSelector(periodLabels(), vm.period.ordinal, { vm.setPeriod(Period.entries[it]) }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            NavRow(vm)
            Spacer(Modifier.height(12.dp))
            when (vm.period) {
                Period.DAY -> UnifiedList(vm)
                Period.WEEK -> WeekGrid(vm.items, vm.weekStart, vm.today, skin, hourHeight = 38.dp, onPickDay = vm.pickDay)
                Period.MONTH -> {
                    MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 56.dp, onPickDay = vm.setAnchor)
                    Spacer(Modifier.height(12.dp))
                    UnifiedList(vm)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        // Ekleme satırı altta sabit: başparmakla her zaman ulaşılır, listeyle birlikte kaymaz.
        Column(Modifier.imePadding().padding(horizontal = 16.dp, vertical = 8.dp)) { AddRow(vm) }
    }
}

@Composable
private fun UnifiedList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) {
        com.odak.app.theme.PlanEmpty(t.text.copy(alpha = 0.6f))
        return
    }
    list.forEach { p ->
        ThemedCard(Modifier.fillMaxWidth().padding(vertical = 4.dp), onClick = { vm.startEdit(p) }) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Text(
                    titleWithDot(p),
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (p.done) t.text.copy(alpha = 0.5f) else t.text,
                    textDecoration = if (p.done) TextDecoration.LineThrough else null,
                    modifier = Modifier.weight(1f)
                )
                Text(timeOf(p), style = MaterialTheme.typography.bodySmall, color = t.text.copy(alpha = 0.6f))
                DeleteMark(t.text.copy(alpha = 0.5f)) { vm.remove(p) }
            }
        }
    }
}
