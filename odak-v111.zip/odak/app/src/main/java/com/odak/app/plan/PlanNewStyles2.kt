package com.odak.app.plan

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.odak.app.R
import com.odak.app.theme.AuroraMint
import com.odak.app.theme.AuroraViolet
import com.odak.app.theme.DesignStyle
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.PeriodSelector
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.Y2kPink
import com.odak.app.theme.auroraPanel
import com.odak.app.theme.clayWell
import com.odak.app.theme.claySurface
import com.odak.app.theme.darkElevation
import com.odak.app.theme.plainClick
import com.odak.app.theme.y2kGel
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Dönem seçici + gezinme + takvim/ızgara + (gün/ay için) liste: dört stilin ortak iskeleti. */
@Composable
internal fun PlanBody(vm: PlanVm, style: DesignStyle, gap: Int, list: @Composable () -> Unit) {
    val skin = skinFor(style)
    PeriodSelector(periodLabels(), vm.period.ordinal, { vm.setPeriod(Period.entries[it]) })
    Spacer(Modifier.height((gap - 2).dp))
    NavRow(vm)
    Spacer(Modifier.height(gap.dp))
    when (vm.period) {
        Period.DAY -> {
            ThemedCard(Modifier.fillMaxWidth()) {
                MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 36.dp, marks = Marks.DOTS, onPickDay = vm.setAnchor)
            }
            Spacer(Modifier.height((gap + 2).dp))
            list()
        }
        Period.WEEK -> ThemedCard(Modifier.fillMaxWidth()) {
            WeekGrid(vm.items, vm.weekStart, vm.today, skin, hourHeight = 38.dp, onPickDay = vm.pickDay)
        }
        Period.MONTH -> {
            ThemedCard(Modifier.fillMaxWidth()) {
                MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 66.dp, onPickDay = vm.setAnchor)
            }
            Spacer(Modifier.height((gap + 2).dp))
            list()
        }
    }
    Spacer(Modifier.height(16.dp))
    AddRow(vm)
}

// =====================================================================
// Y2K: "Plan.exe" penceresi, jel balonlar, sticker rozeti
// =====================================================================
@Composable
fun Y2kPlan(vm: PlanVm) {
    val list = vm.dayItems
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        val shape = RoundedCornerShape(14.dp)
        Column(Modifier.fillMaxWidth().border(2.dp, Color.White, shape).clip(shape)) {
            // Pencere başlık çubuğu
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(Color(0xFF1F46D6), Color(0xFF7FE8FF))))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "✦ " + stringResource(R.string.tab_plan).uppercase(Locale.getDefault()) + ".EXE",
                    fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = Color.White, modifier = Modifier.weight(1f)
                )
                listOf("–", "▢", "✕").forEach {
                    Box(
                        Modifier.padding(start = 4.dp).size(20.dp)
                            .y2kGel(RoundedCornerShape(6.dp), Color.White, Color(0xFFE3E9F8), Color(0xFFB9C4DE)),
                        contentAlignment = Alignment.Center
                    ) { Text(it, fontSize = 10.sp, color = Color(0xFF1B1F4B)) }
                }
            }
            Row(
                Modifier.fillMaxWidth().background(Color(0xCCFFFFFF)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    vm.anchor.format(DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault())),
                    fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B1F4B), modifier = Modifier.weight(1f)
                )
                // sticker rozeti
                Box(
                    Modifier.y2kGel(RoundedCornerShape(50), Color(0xFFFFB3E0), Y2kPink, Color(0xFFC0106F))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) { Text("${list.count { it.done }}/${list.size}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White) }
            }
        }
        Spacer(Modifier.height(14.dp))
        PlanBody(vm, DesignStyle.Y2K, 10) { Y2kList(vm) }
    }
}

@Composable
private fun Y2kList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) {
        com.odak.app.theme.PlanEmpty(t.text.copy(alpha = 0.8f))
        return
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.forEach { p ->
            Row(
                Modifier.fillMaxWidth()
                    .y2kGel(RoundedCornerShape(22.dp), Color.White, Color(0xFFF1EBFF), Color(0xFFD9CCFF))
                    .plainClick { vm.startEdit(p) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p), fontSize = 15.sp, color = t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text(timeOf(p), fontSize = 11.sp, color = t.accent, fontFamily = FontFamily.Monospace)
                }
                DeleteMark(t.text.copy(alpha = 0.7f)) { vm.remove(p) }
            }
        }
    }
}

// =====================================================================
// AURORA: ışık şeridi ilerleme, koyu ışıklı paneller
// =====================================================================
@Composable
fun AuroraPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    val frac = if (list.isEmpty()) 0f else list.count { it.done }.toFloat() / list.size
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(
            vm.anchor.format(DateTimeFormatter.ofPattern("EEEE", Locale.getDefault())),
            fontSize = 13.sp, letterSpacing = 3.sp, color = AuroraMint
        )
        Text(
            vm.anchor.format(DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault())),
            fontSize = 32.sp, fontWeight = FontWeight.Light, color = t.text
        )
        Spacer(Modifier.height(10.dp))
        // ışık şeridi
        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)).background(Color(0x33FFFFFF))) {
            Box(
                Modifier.fillMaxWidth(frac).fillMaxHeight()
                    .background(Brush.horizontalGradient(listOf(AuroraMint, AuroraViolet)), RoundedCornerShape(50))
            )
        }
        Spacer(Modifier.height(16.dp))
        PlanBody(vm, DesignStyle.AURORA, 12) { AuroraList(vm) }
    }
}

@Composable
private fun AuroraList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) {
        com.odak.app.theme.PlanEmpty(t.text.copy(alpha = 0.8f))
        return
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        list.forEach { p ->
            Row(
                Modifier.fillMaxWidth()
                    .auroraPanel(RoundedCornerShape(18.dp), if (p.done) 0.1f else 0.45f)
                    .plainClick { vm.startEdit(p) }
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p), fontSize = 15.sp,
                        color = if (p.done) t.text.copy(alpha = 0.6f) else t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text(timeOf(p), fontSize = 11.sp, color = AuroraMint)
                }
                DeleteMark(t.text.copy(alpha = 0.7f)) { vm.remove(p) }
            }
        }
    }
}

// =====================================================================
// CLAYMORPHISM: pastel kil kartlar, sayaç topları, biten görev çukura döner
// =====================================================================
private val ClayPastels = listOf(
    Color(0xFFE0D6FF), Color(0xFFCDEEDD), Color(0xFFFFD9D2), Color(0xFFD3E8FA), Color(0xFFFCE9A8), Color(0xFFF8D3E4)
)

@Composable
fun ClayPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    val done = list.count { it.done }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(stringResource(R.string.tab_plan), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = t.text, modifier = Modifier.padding(start = 6.dp))
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            listOf(
                Triple(done, "✓", Color(0xFFCDEEDD)),
                Triple(list.size - done, "…", Color(0xFFFFD9D2)),
                Triple(list.size, "Σ", Color(0xFFE0D6FF))
            ).forEach { (n, sym, c) ->
                Column(
                    Modifier.weight(1f).claySurface(RoundedCornerShape(24.dp), c, 1f, 6.dp, 14.dp).padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("$n", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = t.text)
                    Text(sym, fontSize = 13.sp, color = t.text.copy(alpha = 0.8f))
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        PlanBody(vm, DesignStyle.CLAYMORPHISM, 16) { ClayList(vm) }
    }
}

@Composable
private fun ClayList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) {
        com.odak.app.theme.PlanEmpty(t.text.copy(alpha = 0.75f))
        return
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        list.forEachIndexed { i, p ->
            val c = ClayPastels[i % ClayPastels.size]
            val look = if (p.done) Modifier.clayWell(RoundedCornerShape(24.dp), t.background)
            else Modifier.claySurface(RoundedCornerShape(24.dp), c)
            Row(
                Modifier.fillMaxWidth().then(look).plainClick { vm.startEdit(p) }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p), fontSize = 15.sp, fontWeight = FontWeight.Bold,
                        color = if (p.done) t.text.copy(alpha = 0.6f) else t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text(timeOf(p), fontSize = 11.sp, color = t.accent)
                }
                DeleteMark(t.accent) { vm.remove(p) }
            }
        }
    }
}

// =====================================================================
// DARK: Material koyu tema; yükseklik = yüzey açıklığı, gölge yok
// =====================================================================
@Composable
fun DarkPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    val frac = if (list.isEmpty()) 0f else list.count { it.done }.toFloat() / list.size
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(stringResource(R.string.tab_plan), fontSize = 24.sp, fontWeight = FontWeight.Medium, color = t.text)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(50)).background(Color(0xFF2C2C2C))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(t.primary, RoundedCornerShape(50)))
        }
        Spacer(Modifier.height(14.dp))
        PlanBody(vm, DesignStyle.DARK, 10) { DarkList(vm) }
    }
}

@Composable
private fun DarkList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    val head = vm.anchor.format(DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault()))
    Text("$head · ${list.count { it.done }}/${list.size}", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = t.text.copy(alpha = 0.7f))
    Spacer(Modifier.height(8.dp))
    if (list.isEmpty()) {
        com.odak.app.theme.PlanEmpty(t.text.copy(alpha = 0.6f))
        return
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(darkElevation(1))) {
        list.forEachIndexed { i, p ->
            Row(
                Modifier.fillMaxWidth().plainClick { vm.startEdit(p) }.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p), fontSize = 15.sp,
                        color = if (p.done) t.text.copy(alpha = 0.5f) else t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text(timeOf(p), fontSize = 11.sp, color = t.accent)
                }
                DeleteMark(t.text.copy(alpha = 0.6f)) { vm.remove(p) }
            }
            if (i < list.lastIndex) Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x14FFFFFF)))
        }
    }
}
