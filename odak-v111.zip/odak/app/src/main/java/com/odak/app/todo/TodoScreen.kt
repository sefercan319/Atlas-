package com.odak.app.todo

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.odak.app.R
import com.odak.app.plan.DeleteMark
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.SoundKind
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.ThemedHeader
import com.odak.app.theme.ThemedTextField
import com.odak.app.theme.plainClick

private val PrioColors = listOf(Color(0xFF4CAF50), Color(0xFFFFA000), Color(0xFFE53935))
private val PrioMarks = listOf("!", "!!", "!!!")
private val Cats = listOf("•", "🏠", "💼", "🎓", "❤")

@Composable
fun TodoScreen() {
    val ctx = LocalContext.current
    val t = LocalDesign.current.tokens
    val sp = remember { ctx.getSharedPreferences("odak_app", android.content.Context.MODE_PRIVATE) }
    var all by remember { mutableStateOf(TodoStore.load(ctx)) }
    var title by remember { mutableStateOf("") }
    var prio by remember { mutableStateOf(1) }
    var cat by remember { mutableStateOf(0) }
    var rep by remember { mutableStateOf(false) }
    var filterCat by remember { mutableStateOf(-1) }
    var manual by remember { mutableStateOf(sp.getBoolean("todo_manual", false)) }
    var dueMode by remember { mutableStateOf(0) }
    var sortMode by remember { mutableStateOf(sp.getInt("todo_sort", 0)) }
    var query by remember { mutableStateOf("") }
    var showTools by remember { mutableStateOf(false) }
    var showNew by remember { mutableStateOf(false) }
    var showList by remember { mutableStateOf(false) }
    var lastDeleted by remember { mutableStateOf<TodoItem?>(null) }
    val today = java.time.LocalDate.now()
    val dueLabel = stringResource(
        when (dueMode) { 1 -> R.string.due_today; 2 -> R.string.due_tomorrow; 3 -> R.string.due_week; else -> R.string.due_none }
    )
    val overdueText = stringResource(R.string.due_overdue)

    fun save(l: List<TodoItem>) {
        all = l
        TodoStore.save(ctx, l)
    }
    fun upd(id: String, f: (TodoItem) -> TodoItem) = save(all.map { if (it.id == id) f(it) else it })
    fun move(id: String, dir: Int) {
        val i = all.indexOfFirst { it.id == id }
        val j = i + dir
        if (i < 0 || j < 0 || j >= all.size) return
        val m = all.toMutableList()
        val x = m[i]; m[i] = m[j]; m[j] = x
        save(m)
    }

    val filtered = all.filter {
        (query.isBlank() || it.title.contains(query.trim(), ignoreCase = true)) &&
            (filterCat < 0 || it.cat == filterCat)
    }
    val shown = if (manual) filtered
    else com.odak.app.logic.Pure.todoOrder(filtered.map { com.odak.app.logic.Pure.SortKey(it.done, it.due, it.prio, it.title) }, sortMode)
        .map { filtered[it] }
    val overdueN = all.count { com.odak.app.logic.Pure.isOverdue(it.due, it.done, today) }
    val done = all.count { it.done }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Spacer(Modifier.height(16.dp))
            ThemedHeader(stringResource(R.string.tab_todo))
            val quotes = listOf(R.string.motiv_1, R.string.motiv_2, R.string.motiv_3, R.string.motiv_4, R.string.motiv_5, R.string.motiv_6)
            Text(stringResource(quotes[today.dayOfYear % quotes.size]), fontSize = 12.sp, color = t.text.copy(alpha = 0.6f))
            Spacer(Modifier.height(10.dp))
            ThemedButton(if (showTools) "▾ 🧰" else "▸ 🧰", { showTools = !showTools })
            if (showTools) {
                Spacer(Modifier.height(10.dp))
                PomodoroCard()
                Spacer(Modifier.height(10.dp))
                HabitCard()
                Spacer(Modifier.height(10.dp))
                WaterCard()
            }
            Spacer(Modifier.height(10.dp))
            if (all.size > 5) {
                ThemedTextField(value = query, onValueChange = { query = it }, placeholder = "🔍", modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                ThemedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = stringResource(R.string.todo_hint),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(6.dp))
                ThemedButton(if (showNew) "▾" else "⋯", { showNew = !showNew })
                Spacer(Modifier.width(6.dp))
                ThemedButton("+", {
                    val (s, quick) = com.odak.app.logic.Pure.parseQuickDue(title)
                    if (s.isNotEmpty()) {
                        val due = when (dueMode) {
                            1 -> today
                            2 -> today.plusDays(1)
                            3 -> today.plusDays(7)
                            else -> quick?.let { today.plusDays(it.toLong()) }
                        }?.toString()
                        save(all + TodoItem(title = s, prio = prio, due = due, cat = cat, rep = rep))
                        title = ""
                    }
                }, sound = SoundKind.SUCCESS)
            }
            lastDeleted?.let { d ->
                Spacer(Modifier.height(6.dp))
                ThemedButton("↩ " + stringResource(R.string.undo_delete), { save(all + d); lastDeleted = null })
            }
            if (showNew) {
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ThemedButton(PrioMarks[prio], { prio = (prio + 1) % 3 })
                    ThemedButton("📅 $dueLabel", { dueMode = (dueMode + 1) % 4 })
                    ThemedButton(Cats[cat], { cat = (cat + 1) % Cats.size })
                    ThemedButton(if (rep) "🔁 ✔" else "🔁", { rep = !rep })
                }
            }
            if (overdueN > 0) {
                Spacer(Modifier.height(6.dp))
                Text(stringResource(R.string.todo_overdue_n, overdueN), color = androidx.compose.ui.graphics.Color(0xFFE53935))
                ThemedButton("➡ " + stringResource(R.string.todo_move_today), {
                    save(all.map { it.copy(due = com.odak.app.logic.Pure.moveOverdue(it.due, it.done, today)) })
                })
            }
            if (all.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text("$done / ${all.size}  (${com.odak.app.logic.Pure.pct(done, all.size)}%)")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (done > 0) ThemedButton(stringResource(R.string.todo_clear), {
                            save(all.filter { !it.done })
                        }, sound = SoundKind.DELETE)
                        ThemedButton(if (showList) "▾ ⇅" else "▸ ⇅", { showList = !showList })
                    }
                }
            }
            if (showList) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ThemedButton(if (filterCat == -1) "✔ ∗" else "∗", { filterCat = -1 })
                    Cats.forEachIndexed { i, e ->
                        ThemedButton(if (filterCat == i) "✔ $e" else e, { filterCat = i })
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ThemedButton(if (manual) "↕ ✔" else "↕", {
                        manual = !manual
                        sp.edit().putBoolean("todo_manual", manual).apply()
                    })
                    if (!manual) ThemedButton(
                        "⇅ " + when (sortMode) {
                            1 -> stringResource(R.string.sort_prio)
                            2 -> stringResource(R.string.sort_alpha)
                            3 -> stringResource(R.string.sort_due)
                            else -> "📅 + !"
                        },
                        { sortMode = (sortMode + 1) % 4; sp.edit().putInt("todo_sort", sortMode).apply() }
                    )
                }
            }
        }
        if (all.isEmpty()) {
            item { com.odak.app.theme.EmptyState("☑", stringResource(R.string.todo_empty), stringResource(R.string.empty_todo_hint)) }
        }
        items(shown, key = { it.id }) { p ->
            var open by remember(p.id) { mutableStateOf(false) }
            var newSub by remember(p.id) { mutableStateOf("") }
            val overdue = !p.done && p.due != null && p.due < today.toString()
            ThemedCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ThemedCheck(p.done) { c ->
                        if (c && !p.done) {
                            sp.edit().putInt("todo_done_total", sp.getInt("todo_done_total", 0) + 1).apply()
                        }
                        if (c && !p.done && p.rep) {
                            val base = p.due?.let { d -> runCatching { java.time.LocalDate.parse(d) }.getOrNull() } ?: today
                            val nextDue = (if (base.isBefore(today)) today else base).plusDays(1).toString()
                            val dup = all.any { !it.done && it.rep && it.title == p.title && it.due == nextDue }
                            save(
                                all.map { if (it.id == p.id) it.copy(done = true) else it } +
                                    (if (dup) emptyList() else listOf(p.copy(id = java.util.UUID.randomUUID().toString(), done = false, due = nextDue,
                                        subs = p.subs.map { s0 -> Sub(s0.t, false) })))
                            )
                        } else upd(p.id) { it.copy(done = c) }
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.width(8.dp).height(8.dp).background(PrioColors[p.prio], CircleShape))
                    Spacer(Modifier.width(6.dp))
                    if (p.cat > 0) Text(Cats[p.cat] + " ")
                    Column(Modifier.weight(1f).plainClick { open = !open }) {
                        Text(
                            p.title,
                            color = if (p.done) t.text.copy(alpha = 0.45f) else t.text,
                            textDecoration = if (p.done) TextDecoration.LineThrough else null
                        )
                        val meta = buildList {
                            if (p.rep) add("🔁")
                            p.due?.let { add(if (overdue) "$it · $overdueText" else it) }
                            if (p.subs.isNotEmpty()) add("☑ ${p.subs.count { s -> s.d }}/${p.subs.size}")
                        }.joinToString("  ")
                        if (meta.isNotEmpty()) {
                            Text(
                                meta,
                                fontSize = 11.sp,
                                color = if (overdue) Color(0xFFE53935) else t.text.copy(alpha = 0.6f)
                            )
                        }
                    }
                    if (manual) {
                        Text("▲", Modifier.plainClick { move(p.id, -1) }.padding(6.dp))
                        Text("▼", Modifier.plainClick { move(p.id, 1) }.padding(6.dp))
                    } else {
                        Text(
                            "📅",
                            Modifier.plainClick {
                                val plans = com.odak.app.plan.PlanStore.load(ctx)
                                val date = p.due?.let { runCatching { java.time.LocalDate.parse(it) }.getOrNull() } ?: today
                                com.odak.app.plan.PlanStore.save(
                                    ctx, plans + com.odak.app.plan.PlanItem(title = p.title, date = date)
                                )
                                save(all.filter { it.id != p.id })
                            }.padding(6.dp)
                        )
                        Text(
                            "⏭",
                            Modifier.plainClick {
                                val base = p.due?.let { runCatching { java.time.LocalDate.parse(it) }.getOrNull() }
                                    ?.let { if (it.isBefore(today)) today else it } ?: today
                                upd(p.id) { it.copy(due = base.plusDays(1).toString()) }
                            }.padding(6.dp)
                        )
                    }
                    DeleteMark(t.text.copy(alpha = 0.5f)) { lastDeleted = p; save(all.filter { it.id != p.id }) }
                }
                if (open) {
                    Spacer(Modifier.height(6.dp))
                    p.subs.forEachIndexed { i, s ->
                        Row(Modifier.fillMaxWidth().padding(start = 24.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            ThemedCheck(s.d) { c ->
                                upd(p.id) { it.copy(subs = it.subs.mapIndexed { k, x -> if (k == i) Sub(x.t, c) else x }) }
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                s.t,
                                Modifier.weight(1f),
                                textDecoration = if (s.d) TextDecoration.LineThrough else null,
                                color = if (s.d) t.text.copy(alpha = 0.45f) else t.text
                            )
                            DeleteMark(t.text.copy(alpha = 0.5f)) {
                                upd(p.id) { it.copy(subs = it.subs.filterIndexed { k, _ -> k != i }) }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(start = 24.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        ThemedTextField(newSub, { newSub = it }, "☑", Modifier.weight(1f))
                        Spacer(Modifier.width(6.dp))
                        ThemedButton("+", {
                            val s = newSub.trim()
                            if (s.isNotEmpty()) {
                                upd(p.id) { it.copy(subs = it.subs + Sub(s, false)) }
                                newSub = ""
                            }
                        })
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}
