package com.odak.app.settings

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.odak.app.R
import androidx.compose.ui.graphics.toArgb
import com.odak.app.block.Pin
import com.odak.app.theme.ThemedTextField
import com.odak.app.theme.ClickSound
import com.odak.app.theme.ColorPrefs
import com.odak.app.theme.plainClick
import com.odak.app.theme.DesignStyle
import com.odak.app.theme.SoundKind
import com.odak.app.theme.ThemedButton
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedHeader
import com.odak.app.theme.tokensFor
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.width

/** Ayar kategorileri: ana sayfada birer kart, dokununca kendi alt sayfası açılır. */
enum class SettingsGroup(val icon: String, val titleRes: Int) {
    LOOK("🎨", R.string.sg_look),
    SOUND("🔔", R.string.sg_sound),
    PLAN("📅", R.string.sg_plan),
    DATA("💾", R.string.sg_data),
    SECURITY("🔐", R.string.sg_security)
}

@Composable
fun SettingsScreen(
    current: DesignStyle,
    fontScale: Float,
    mode: Int,
    onMode: (Int) -> Unit,
    onFontScale: (Float) -> Unit,
    onSelect: (DesignStyle) -> Unit
) {
    var group by remember { mutableStateOf<SettingsGroup?>(null) }
    BackHandler(enabled = group != null) { group = null }
    val open = group
    if (open == null) {
        SettingsHub(onOpen = { group = it })
    } else {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            ThemedButton("‹ " + stringResource(R.string.sg_back), { group = null })
            Spacer(Modifier.height(12.dp))
            ThemedHeader(stringResource(open.titleRes))
            Spacer(Modifier.height(12.dp))
            when (open) {
                SettingsGroup.LOOK -> LookGroup(current, fontScale, mode, onMode, onFontScale, onSelect)
                SettingsGroup.SOUND -> SoundGroup()
                SettingsGroup.PLAN -> PlanGroup()
                SettingsGroup.DATA -> DataGroup()
                SettingsGroup.SECURITY -> SecurityGroup()
            }
        }
    }
}

@Composable
private fun SettingsHub(onOpen: (SettingsGroup) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        SettingsGroup.entries.forEach { g ->
            ThemedCard(
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                onClick = { onOpen(g) }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(g.icon, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        stringResource(g.titleRes),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Text("›", style = MaterialTheme.typography.titleLarge)
                }
            }
        }
    }
}

@Composable
private fun LookGroup(
    current: DesignStyle,
    fontScale: Float,
    mode: Int,
    onMode: (Int) -> Unit,
    onFontScale: (Float) -> Unit,
    onSelect: (DesignStyle) -> Unit
) {
    // Alt bölümler: tek uzun sayfa yerine dört küçük sekme.
    var sub by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableIntStateOf(0) }
    val names = listOf("🎨 " + stringResource(R.string.theme_title), "Aa", "🌐 " + stringResource(R.string.lang_title), "🖼 " + stringResource(R.string.logo_title))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        names.forEachIndexed { i, n -> ThemedButton((if (sub == i) "✔ " else "") + n, { sub = i }) }
    }
    Spacer(Modifier.height(12.dp))
    when (sub) {
        0 -> {
    DesignStyle.entries.forEach { s ->
        val tk = tokensFor(s)
        ThemedCard(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            selected = s == current,
            onClick = {
                ClickSound.play(s, SoundKind.TAP)
                onSelect(s)
            }
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (s == current) "✔ ${s.label}" else s.label,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                listOf(tk.background, tk.primary, tk.accent, tk.text).forEach { c ->
                    Box(
                        Modifier
                            .padding(start = 4.dp)
                            .size(20.dp)
                            .background(c, CircleShape)
                            .border(1.dp, Color(0x33000000), CircleShape)
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            com.odak.app.theme.ThemePreview(s, Modifier.fillMaxWidth())
        }
    }
    Spacer(Modifier.height(16.dp))
    ColorsCard(current)
    Spacer(Modifier.height(12.dp))
    ThemedCard(Modifier.fillMaxWidth()) {
        Text("🌓", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("🎨", "☀", "🌙").forEachIndexed { i, e ->
                ThemedButton(if (mode == i) "✔ $e" else e, { onMode(i) })
            }
        }
    }
        }
        1 -> {
            FontCard(fontScale, onFontScale)
            Spacer(Modifier.height(12.dp))
            ScaleCard()
        }
        2 -> LanguageCard()
        else -> com.odak.app.logo.LogoCard()
    }
}

@Composable
private fun SoundGroup() {
    DailyCard()
    Spacer(Modifier.height(12.dp))
    MsgsCard()
    Spacer(Modifier.height(12.dp))
    LeadCard()
    Spacer(Modifier.height(12.dp))
    SoundCard()
    Spacer(Modifier.height(16.dp))
    Text("🔊", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ThemedButton("👆", {}, sound = SoundKind.TAP)
        ThemedButton("✔", {}, sound = SoundKind.SUCCESS)
        ThemedButton("🗑", {}, sound = SoundKind.DELETE)
        ThemedButton("🔔", {}, sound = SoundKind.NOTIFY)
    }
}

@Composable
private fun PlanGroup() {
    StatsCard()
    Spacer(Modifier.height(12.dp))
    EmojiCard()
    Spacer(Modifier.height(12.dp))
    SummaryCard()
}

@Composable
private fun DataGroup() {
    NotesCard()
    Spacer(Modifier.height(12.dp))
    BackupCard()
}

@Composable
private fun SecurityGroup() {
    PinCard()
    Spacer(Modifier.height(12.dp))
    PermCard()
}

@Composable
private fun NotifCard() {
    val ctx = LocalContext.current
    var ok by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok = it }
    if (ok) return
    Spacer(Modifier.height(12.dp))
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.notif_perm))
        Spacer(Modifier.height(10.dp))
        ThemedButton(stringResource(R.string.block_grant), { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) })
    }
}

private val Palette = listOf(
    0xFF00E5FF, 0xFF7C4DFF, 0xFFFF2A6D, 0xFF05D9E8, 0xFF2FA52A, 0xFFFFA000, 0xFF0067C0, 0xFF111111
).map { Color(it) }

@Composable
private fun ColorsCard(style: DesignStyle) {
    val ctx = LocalContext.current
    val tk = tokensFor(style)
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.colors_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        SwatchRow(stringResource(R.string.colors_primary), tk.primary) { ColorPrefs.setPrimary(ctx, style, it.toArgb()) }
        SwatchRow(stringResource(R.string.colors_accent), tk.accent) { ColorPrefs.setAccent(ctx, style, it.toArgb()) }
        Spacer(Modifier.height(8.dp))
        ThemedButton(stringResource(R.string.colors_reset), { ColorPrefs.reset(ctx, style) })
    }
}

@Composable
private fun SwatchRow(label: String, current: Color, onPick: (Color) -> Unit) {
    Text(label, style = MaterialTheme.typography.bodySmall)
    Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Palette.forEach { c ->
            Box(
                Modifier
                    .size(28.dp)
                    .background(c, CircleShape)
                    .border(if (c == current) 3.dp else 1.dp, if (c == current) Color.White else Color(0x33000000), CircleShape)
                    .plainClick { onPick(c) }
            )
        }
    }
}

@Composable
private fun PinCard() {
    val ctx = LocalContext.current
    var isSet by remember { mutableStateOf(Pin.isSet(ctx)) }
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    ThemedCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.pin_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        ThemedTextField(
            value = pin,
            onValueChange = { pin = it.filter(Char::isDigit).take(8); wrong = false },
            placeholder = stringResource(R.string.pin_enter),
            modifier = Modifier.fillMaxWidth(),
            secret = true
        )
        if (wrong) Text(stringResource(R.string.pin_wrong), color = Color(0xFFE53935))
        Spacer(Modifier.height(8.dp))
        ThemedButton(
            stringResource(if (isSet) R.string.pin_remove else R.string.pin_set),
            {
                if (isSet) {
                    if (Pin.check(ctx, pin)) { Pin.clear(ctx); isSet = false; pin = "" } else wrong = true
                } else if (pin.length >= 4) {
                    Pin.set(ctx, pin); isSet = true; pin = ""
                }
            }
        )
    }
}
