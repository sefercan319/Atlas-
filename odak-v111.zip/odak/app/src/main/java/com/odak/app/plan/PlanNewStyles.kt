package com.odak.app.plan

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.odak.app.R
import com.odak.app.theme.DesignStyle
import com.odak.app.theme.Grain
import com.odak.app.theme.LocalDesign
import com.odak.app.theme.PeriodSelector
import com.odak.app.theme.ThemedCard
import com.odak.app.theme.ThemedCheck
import com.odak.app.theme.glassPanel
import com.odak.app.theme.neuSurface
import com.odak.app.theme.plainClick
import com.odak.app.theme.skeuoSurface
import java.time.format.DateTimeFormatter
import java.util.Locale

// =====================================================================
// SKEUOMORPHISM: deri kapaklı, spiral halkalı, çizgili kâğıtlı ajanda
// =====================================================================
@Composable
fun SkeuoPlan(vm: PlanVm) {
    val skin = skinFor(DesignStyle.SKEUOMORPHISM)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Box(
            Modifier.fillMaxWidth().skeuoSurface(
                RoundedCornerShape(10.dp), Color(0xFF8A5A33), Color(0xFF4F3019),
                grain = Grain.LEATHER, elevation = 6.dp, stitch = Color(0x66FFF3D6), gloss = false
            ).padding(horizontal = 18.dp, vertical = 16.dp)
        ) {
            Text(
                stringResource(R.string.tab_plan),
                fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFF3D6),
                style = LocalTextStyle.current.copy(shadow = Shadow(Color(0xCC000000), Offset(0f, -1.5f), 1f))
            )
        }
        // metal spiral halkalar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 28.dp).offset(y = (-12).dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            repeat(6) {
                Box(
                    Modifier.width(10.dp).height(26.dp).skeuoSurface(
                        RoundedCornerShape(5.dp), Color(0xFFF2F2F2), Color(0xFF8C8C8C),
                        grain = Grain.METAL, elevation = 2.dp
                    )
                )
            }
        }
        PeriodSelector(periodLabels(), vm.period.ordinal, { vm.setPeriod(Period.entries[it]) })
        Spacer(Modifier.height(10.dp))
        NavRow(vm)
        Spacer(Modifier.height(10.dp))
        when (vm.period) {
            Period.DAY -> {
                ThemedCard(Modifier.fillMaxWidth()) {
                    MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 36.dp, marks = Marks.DOTS, onPickDay = vm.setAnchor)
                }
                Spacer(Modifier.height(14.dp))
                PaperList(vm)
            }
            Period.WEEK -> ThemedCard(Modifier.fillMaxWidth()) {
                WeekGrid(vm.items, vm.weekStart, vm.today, skin, hourHeight = 38.dp, onPickDay = vm.pickDay)
            }
            Period.MONTH -> {
                ThemedCard(Modifier.fillMaxWidth()) {
                    MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 66.dp, onPickDay = vm.setAnchor)
                }
                Spacer(Modifier.height(14.dp))
                PaperList(vm)
            }
        }
        Spacer(Modifier.height(16.dp))
        AddRow(vm)
    }
}

/** Çizgili defter kâğıdı: kırmızı kenar çizgisi, her satır 48dp (çizgilerle hizalı). */
@Composable
private fun PaperList(vm: PlanVm) {
    val list = vm.dayItems
    Box(
        Modifier.fillMaxWidth().skeuoSurface(
            RoundedCornerShape(6.dp), Color(0xFFFFFBEF), Color(0xFFF1E6CA),
            grain = Grain.PAPER, elevation = 4.dp, gloss = false
        ).drawBehind {
            val step = 48.dp.toPx()
            var y = step
            while (y < size.height) {
                drawLine(Color(0x334F7AB8), Offset(0f, y), Offset(size.width, y), 1f)
                y += step
            }
            val mx = 40.dp.toPx()
            drawLine(Color(0x55C0392B), Offset(mx, 0f), Offset(mx, size.height), 2f)
        }
    ) {
        Column(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp)) {
            if (list.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(48.dp).padding(start = 44.dp), contentAlignment = Alignment.CenterStart) {
                    com.odak.app.theme.PlanEmpty(Color(0xFF6B5638))
                }
            }
            list.forEach { p ->
                Row(
                    Modifier.fillMaxWidth().height(48.dp).plainClick { vm.startEdit(p) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.width(32.dp), contentAlignment = Alignment.Center) { ThemedCheck(p.done) { vm.toggle(p, it) } }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            titleWithDot(p), fontSize = 15.sp, maxLines = 1,
                            color = if (p.done) Color(0xFF8A7A62) else Color(0xFF2B1D12),
                            textDecoration = if (p.done) TextDecoration.LineThrough else null
                        )
                        if (p.hasTime) Text(timeOf(p), fontSize = 11.sp, color = Color(0xFF6B5638))
                    }
                    DeleteMark(Color(0xFF8A6A44)) { vm.remove(p) }
                }
            }
        }
    }
}

// =====================================================================
// NEUMORPHISM: kabarık kartlar, çukur ilerleme kadranı, basılı biten görevler
// =====================================================================
@Composable
fun NeuPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val skin = skinFor(DesignStyle.NEUMORPHISM)
    val list = vm.dayItems
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.tab_plan), fontSize = 26.sp, fontWeight = FontWeight.SemiBold,
                color = t.text, modifier = Modifier.weight(1f)
            )
            NeuDial(list.count { it.done }, list.size)
        }
        Spacer(Modifier.height(18.dp))
        PeriodSelector(periodLabels(), vm.period.ordinal, { vm.setPeriod(Period.entries[it]) })
        Spacer(Modifier.height(16.dp))
        NavRow(vm)
        Spacer(Modifier.height(14.dp))
        when (vm.period) {
            Period.DAY -> {
                ThemedCard(Modifier.fillMaxWidth()) {
                    MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 36.dp, marks = Marks.DOTS, onPickDay = vm.setAnchor)
                }
                Spacer(Modifier.height(20.dp))
                NeuList(vm)
            }
            Period.WEEK -> ThemedCard(Modifier.fillMaxWidth()) {
                WeekGrid(vm.items, vm.weekStart, vm.today, skin, hourHeight = 38.dp, onPickDay = vm.pickDay)
            }
            Period.MONTH -> {
                ThemedCard(Modifier.fillMaxWidth()) {
                    MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 66.dp, onPickDay = vm.setAnchor)
                }
                Spacer(Modifier.height(20.dp))
                NeuList(vm)
            }
        }
        Spacer(Modifier.height(20.dp))
        AddRow(vm)
    }
}

/** Kabarık kadran: içinde çukur halka, yapılan/toplam oranı. */
@Composable
private fun NeuDial(done: Int, total: Int) {
    val t = LocalDesign.current.tokens
    val frac = if (total == 0) 0f else done.toFloat() / total
    Box(
        Modifier.size(68.dp).neuSurface(CircleShape, t.surface, 0f, 5.dp, 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.size(50.dp).neuSurface(CircleShape, t.surface, 1f, 3.dp, 6.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(44.dp)) {
                val sw = 5.dp.toPx()
                drawArc(
                    t.primary, -90f, 360f * frac, false,
                    topLeft = Offset(sw / 2, sw / 2), size = Size(size.width - sw, size.height - sw),
                    style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
            Text("$done/$total", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = t.text)
        }
    }
}

@Composable
private fun NeuList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) {
        com.odak.app.theme.PlanEmpty(t.text.copy(alpha = 0.7f))
        return
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        list.forEach { p ->
            Row(
                Modifier.fillMaxWidth()
                    .neuSurface(RoundedCornerShape(18.dp), t.surface, if (p.done) 1f else 0f, 5.dp, 10.dp)
                    .plainClick { vm.startEdit(p) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p), fontSize = 15.sp, fontWeight = FontWeight.Medium,
                        color = if (p.done) t.text.copy(alpha = 0.55f) else t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text(timeOf(p), fontSize = 11.sp, color = t.accent)
                }
                DeleteMark(t.accent) { vm.remove(p) }
            }
        }
    }
}

// =====================================================================
// GLASSMORPHISM: cam hero panel, ilerleme çubuğu, yüzen cam satırlar
// =====================================================================
@Composable
fun GlassPlan(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val skin = skinFor(DesignStyle.GLASSMORPHISM)
    val list = vm.dayItems
    val done = list.count { it.done }
    val frac = if (list.isEmpty()) 0f else done.toFloat() / list.size
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Box(Modifier.fillMaxWidth().glassPanel(RoundedCornerShape(28.dp), Color.White, 0.18f).padding(20.dp)) {
            Column {
                Text(
                    vm.anchor.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())),
                    fontSize = 22.sp, fontWeight = FontWeight.Light, color = t.text
                )
                Spacer(Modifier.height(4.dp))
                Text("$done/${list.size}", fontSize = 13.sp, color = t.text.copy(alpha = 0.8f))
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.2f))) {
                    Box(
                        Modifier.fillMaxWidth(frac).fillMaxHeight()
                            .background(Brush.horizontalGradient(listOf(t.primary, t.accent)), RoundedCornerShape(50))
                    )
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        PeriodSelector(periodLabels(), vm.period.ordinal, { vm.setPeriod(Period.entries[it]) })
        Spacer(Modifier.height(12.dp))
        NavRow(vm)
        Spacer(Modifier.height(10.dp))
        when (vm.period) {
            Period.DAY -> {
                ThemedCard(Modifier.fillMaxWidth()) {
                    MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 36.dp, marks = Marks.DOTS, onPickDay = vm.setAnchor)
                }
                Spacer(Modifier.height(12.dp))
                GlassList(vm)
            }
            Period.WEEK -> ThemedCard(Modifier.fillMaxWidth()) {
                WeekGrid(vm.items, vm.weekStart, vm.today, skin, hourHeight = 38.dp, onPickDay = vm.pickDay)
            }
            Period.MONTH -> {
                ThemedCard(Modifier.fillMaxWidth()) {
                    MonthGrid(vm.items, vm.month, vm.today, vm.anchor, skin, cellHeight = 66.dp, onPickDay = vm.setAnchor)
                }
                Spacer(Modifier.height(12.dp))
                GlassList(vm)
            }
        }
        Spacer(Modifier.height(16.dp))
        AddRow(vm)
    }
}

@Composable
private fun GlassList(vm: PlanVm) {
    val t = LocalDesign.current.tokens
    val list = vm.dayItems
    if (list.isEmpty()) {
        com.odak.app.theme.PlanEmpty(t.text.copy(alpha = 0.8f))
        return
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.forEach { p ->
            Row(
                Modifier.fillMaxWidth()
                    .glassPanel(RoundedCornerShape(18.dp), if (p.done) t.primary else Color.White, if (p.done) 0.12f else 0.16f)
                    .plainClick { vm.startEdit(p) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ThemedCheck(p.done) { vm.toggle(p, it) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        titleWithDot(p), fontSize = 15.sp,
                        color = if (p.done) t.text.copy(alpha = 0.6f) else t.text,
                        textDecoration = if (p.done) TextDecoration.LineThrough else null
                    )
                    if (p.hasTime) Text(timeOf(p), fontSize = 11.sp, color = t.primary)
                }
                DeleteMark(t.text.copy(alpha = 0.7f)) { vm.remove(p) }
            }
        }
    }
}
