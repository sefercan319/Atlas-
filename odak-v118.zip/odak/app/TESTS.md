
## v0.43 — Otomatik arayüz ölçeği
- PureLogicTest.autoScaleGrowsWithScreen / effectiveScaleManualOverridesAndClamps
- ManifestTest.mainActivityHandlesDensityChangeWithoutRecreate

## v0.56.56 — Stil başına boyama profili
- RecolorProfileTest: 17 stil × 3 parça × 6 hedef (siyah, koyu lacivert, mor, sarı, açık gri, beyaz) — desen aralığının ≥%80'i korunur; Aero düğmesinde beyaz parlama boyanmadan kalır; mat stillerde (Clay, Minimal) parlama katmanı yok.
- ColorSlotTest güncellendi (türetimli düğme stilleri, kenar hedef toleransı).
- Doğrulanmadı: telefonda gerçek görünüm (yalnız JVM mantığı + PIL önizleme).

## v0.56.57 — Günlük açma sınırı (Engelleme)
- OpenLimitTest: 30 sn aralık kuralı, sayaç limit+1'de durur, tam `limit` kez açmaya izin, servis/arayüz bağlantısı, 9 dilde metinler.
- Doğrulanmadı: telefonda gerçek davranış (yalnız JVM mantığı + sözdizimi).

## v0.56.58 — Hata düzeltme
- BlockActivity: yeni engel gelince açık kalan çarpma sorusu/"yanlış" mesajı sıfırlanır (BlockScreenResetTest).

## v0.56.59 — Engelleme iyileştirmeleri
- Açma sınırı dolunca engel ekranı kendi başlığını gösterir ("Açma sınırı doldu"); uygulama başlığında bugünkü açılış sayısı (örn. "12m · 3×") görünür. OpenLimitScreenTest.
