package com.odak.app

import com.odak.app.logic.Pure
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OpenLimitTest {
    @Test fun newOpenAfterGap() {
        assertTrue(Pure.isFreshOpen(0L, 1000L))
        assertFalse(Pure.isFreshOpen(1000L, 20_000L))
        assertTrue(Pure.isFreshOpen(1000L, 40_000L))
    }
    @Test fun counterStopsAtLimitPlusOne() {
        var n = 0
        repeat(10) { n = Pure.nextOpens(n, 3) }
        assertEquals(4, n)
        assertEquals(1, Pure.nextOpens(0, 0)) // sınırsızken sayılır ama engel yok
    }
    @Test fun limitAllowsExactlyLimitOpens() {
        assertFalse(Pure.openLimitHit(3, 3)); assertTrue(Pure.openLimitHit(4, 3)); assertFalse(Pure.openLimitHit(99, 0))
    }
    @Test fun wiredInServiceAndUi() {
        val d = TestFiles.code
        val svc = java.io.File(d, "com/odak/app/block/OdakAccessibilityService.kt").readText()
        assertTrue(svc.contains("Pure.openLimitHit(n, openLim)") && svc.contains("registerOpen"))
        assertTrue(java.io.File(d, "com/odak/app/block/BlockScreen.kt").readText().contains("CountRow("))
    }
    @Test fun stringsInAllLocales() {
        for (l in listOf("", "-tr", "-en", "-de", "-fr", "-es", "-ar", "-ru", "-az")) {
            val f = java.io.File(TestFiles.main, "res/values$l/strings.xml")
            assertTrue(l, f.readText().contains("name=\"limit_opens\"") && f.readText().contains("name=\"fmt_times\""))
        }
    }
}

class BlockScreenResetTest {
    @Test fun newBlockResetsQuizState() {
        val s = java.io.File(TestFiles.code, "com/odak/app/block/BlockActivity.kt").readText()
        assertTrue(s.contains("quiz = false; wrong = false; ans = \"\""))
    }
}

class OpenLimitScreenTest {
    private fun src(f: String) = java.io.File(TestFiles.code, "com/odak/app/block/$f").readText()
    @Test fun openLimitHasOwnTitle() {
        assertTrue(src("OdakAccessibilityService.kt").contains("limit = true, opens = true") && src("OdakAccessibilityService.kt").contains(".putExtra(\"opens\", opens)"))
        assertTrue(src("BlockActivity.kt").contains("if (opensHit) R.string.open_limit_reached"))
        for (l in listOf("", "-tr", "-en", "-de", "-fr", "-es", "-ar", "-ru", "-az"))
            assertTrue(l, java.io.File(TestFiles.main, "res/values$l/strings.xml").readText().contains("name=\"open_limit_reached\""))
    }
    @Test fun appHeaderShowsOpenCount() { assertTrue(src("BlockScreen.kt").contains("BlockStore.opensToday(ctx, app.id)") && src("BlockScreen.kt").contains("\${oc}×")) }
}
